import 'pixi.js/unsafe-eval'
import type { SidecarViewState } from '../core/poller'
import type { SoulDockPhase } from '../core/phases'
import { PHASE_PRESENTATION } from '../core/phases'
import {
  createLocalCompanionState,
  resolveLocalCompanionEvent,
  type LocalCompanionEvent,
  type LocalCompanionMotionHint,
} from '../core/local-companion'
import type { ChatEvent, WorkspaceTaskEvent } from '../core/protocol'
import type { ChatUiState } from '../core/chat-controller'
import { SidecarChatController } from '../core/chat-controller'
import type { WorkspaceUiState } from '../core/workspace-controller'
import { SidecarWorkspaceController } from '../core/workspace-controller'
import { AvatarHost, type AvatarAction } from './avatar-host'
import {
  beginPetFlick,
  beginPetWalk,
  createPetMotionState,
  dragPet,
  stepPetMotion,
  stopPetMotion,
  type PetMotionState,
} from './pet-motion'
import { createSpriteAvatar } from './sprite-avatar'
import { createLocalVrmAvatar } from './adapters/vrm'
import {
  EdgeTtsIpcOutputProvider,
  VoicevoxIpcOutputProvider,
  WebSpeechSynthesisProvider,
  type VoiceOutputProvider,
} from './adapters/voice'
import { isClickLikePointerGesture } from './upstream/airi/vrm-interaction'
import './styles.css'

function requiredElement<T extends HTMLElement>(id: string): T {
  const element = document.getElementById(id)
  if (!element) throw new Error(`Missing renderer element #${id}`)
  return element as T
}

function pointInside(element: HTMLElement, x: number, y: number): boolean {
  const bounds = element.getBoundingClientRect()
  return x >= bounds.left && x <= bounds.right && y >= bounds.top && y <= bounds.bottom
}

function codePointLength(value: string): number {
  return [...value].length
}

const shell = requiredElement<HTMLElement>('pet-shell')
const stage = requiredElement<HTMLDivElement>('avatar-stage')
const panel = requiredElement<HTMLElement>('conversation-panel')
const personaName = requiredElement<HTMLElement>('persona-name')
const conversationStatus = requiredElement<HTMLElement>('conversation-status')
const voiceButton = requiredElement<HTMLButtonElement>('voice-toggle-button')
const collapseButton = requiredElement<HTMLButtonElement>('collapse-button')
const exitButton = requiredElement<HTMLButtonElement>('exit-button')
const avatarMenuButton = requiredElement<HTMLButtonElement>('avatar-menu-button')
const avatarMenu = requiredElement<HTMLElement>('avatar-menu')
const spriteButton = requiredElement<HTMLButtonElement>('use-sprite-button')
const vrmRights = requiredElement<HTMLInputElement>('vrm-rights-confirm')
const chooseVrmButton = requiredElement<HTMLButtonElement>('choose-vrm-button')
const vrmInput = requiredElement<HTMLInputElement>('vrm-file-input')
const avatarStatus = requiredElement<HTMLDivElement>('avatar-status')
const avatarMetadata = requiredElement<HTMLDivElement>('avatar-metadata')
const ambientInteractionsToggle = requiredElement<HTMLInputElement>('ambient-interactions-toggle')
const chatHistory = requiredElement<HTMLDivElement>('chat-history')
const typingRow = requiredElement<HTMLDivElement>('typing-row')
const chatError = requiredElement<HTMLDivElement>('chat-error')
const chatForm = requiredElement<HTMLFormElement>('chat-form')
const chatInput = requiredElement<HTMLTextAreaElement>('chat-input')
const inputCounter = requiredElement<HTMLSpanElement>('input-counter')
const sendButton = requiredElement<HTMLButtonElement>('send-button')
const cancelButton = requiredElement<HTMLButtonElement>('cancel-button')
const companionModeButton = requiredElement<HTMLButtonElement>('companion-mode-button')
const workspaceModeButton = requiredElement<HTMLButtonElement>('workspace-mode-button')
const companionView = requiredElement<HTMLElement>('companion-view')
const workspaceView = requiredElement<HTMLElement>('workspace-view')
const workspacePickButton = requiredElement<HTMLButtonElement>('workspace-pick-button')
const workspaceEmptyPickButton = requiredElement<HTMLButtonElement>('workspace-empty-pick-button')
const workspaceBackButton = requiredElement<HTMLButtonElement>('workspace-back-button')
const workspaceNewTaskButton = requiredElement<HTMLButtonElement>('workspace-new-task-button')
const workspaceTaskList = requiredElement<HTMLDivElement>('workspace-task-list')
const workspaceListEmpty = requiredElement<HTMLDivElement>('workspace-list-empty')
const workspaceTaskTitle = requiredElement<HTMLElement>('workspace-task-title')
const workspaceTaskPath = requiredElement<HTMLElement>('workspace-task-path')
const workspaceHistory = requiredElement<HTMLDivElement>('workspace-history')
const workspaceTypingRow = requiredElement<HTMLDivElement>('workspace-typing-row')
const workspaceError = requiredElement<HTMLDivElement>('workspace-error')
const workspaceForm = requiredElement<HTMLFormElement>('workspace-form')
const workspaceInput = requiredElement<HTMLTextAreaElement>('workspace-input')
const workspaceInputCounter = requiredElement<HTMLSpanElement>('workspace-input-counter')
const workspaceCancelButton = requiredElement<HTMLButtonElement>('workspace-cancel-button')
const workspaceSendButton = requiredElement<HTMLButtonElement>('workspace-send-button')

let rendererFailed = false

function showRendererFailure(error: unknown): void {
  if (rendererFailed) return
  rendererFailed = true
  const message = error instanceof Error ? error.message : String(error)
  shell.dataset.open = 'true'
  panel.setAttribute('aria-hidden', 'false')
  stage.setAttribute('aria-expanded', 'true')
  conversationStatus.textContent = '桌宠启动失败'
  chatError.textContent = message.slice(0, 500)
  chatError.hidden = false
  sendButton.disabled = true
  console.error('Jingling renderer failure', error)
}

window.addEventListener('error', event => showRendererFailure(event.error ?? event.message))
window.addEventListener('unhandledrejection', event => showRendererFailure(event.reason))

async function bootstrap(): Promise<void> {
  const avatar = new AvatarHost(stage)
  await avatar.switchTo(createSpriteAvatar)

  let voice: VoiceOutputProvider | undefined
  try {
    const voiceConfig = await window.soulDockSidecar.voice.getConfig()
    const systemVoice = 'speechSynthesis' in window
      ? new WebSpeechSynthesisProvider(window.speechSynthesis)
      : undefined
    voice = voiceConfig.provider === 'voicevox-local'
      ? new VoicevoxIpcOutputProvider(window.soulDockSidecar.voice)
      : voiceConfig.provider === 'edge-tts'
        ? new EdgeTtsIpcOutputProvider(window.soulDockSidecar.voice, undefined, systemVoice)
        : systemVoice
  }
  catch (error) {
    console.warn('Unable to read voice configuration; falling back to Web Speech', error)
    voice = 'speechSynthesis' in window ? new WebSpeechSynthesisProvider(window.speechSynthesis) : undefined
  }

  const chat = new SidecarChatController(window.soulDockSidecar.chat)
  const workspace = new SidecarWorkspaceController(window.soulDockSidecar.workspace)
  let chatState = chat.state
  let workspaceState = workspace.state
  let presenceState: SidecarViewState = { connection: 'connecting' }
  let currentPhase: SoulDockPhase = 'idle'
  let conversationOpen = false
  let activeSurface: 'companion' | 'workspace' = localStorage.getItem('souldock:surface') === 'workspace'
    ? 'workspace'
    : 'companion'
  let workspaceDetailVisible = false
  let petInteractive = false
  let speechMuted = localStorage.getItem('souldock:speech-muted') === 'true'
  let pointerDown = false
  let dragging = false
  let pointerStart = { x: 0, y: 0 }
  let dragStart = { left: 0, top: 0 }
  let pointerSamples: Array<{ x: number; y: number; at: number }> = []
  let localCompanionState = createLocalCompanionState()
  let ambientInteractions = localStorage.getItem('souldock:ambient-interactions') === 'true'
  let motionState = createPetMotionState(
    { x: stage.getBoundingClientRect().left, y: stage.getBoundingClientRect().top },
    { width: Math.max(1, stage.getBoundingClientRect().width), height: Math.max(1, stage.getBoundingClientRect().height) },
    { width: window.innerWidth, height: window.innerHeight },
  )
  let motionFrame: number | undefined
  let motionFrameAt: number | undefined
  let localBubble: HTMLElement | undefined
  let localBubbleTimer: number | undefined
  let localReactionTimer: number | undefined
  let localReactionSerial = 0
  let localActionOverride: AvatarAction | undefined
  let restAnimationTimer: number | undefined
  let ambientWalkTimer: number | undefined
  let ambientGreetingTimer: number | undefined
  let ambientProactiveTimer: number | undefined
  let pointerNearPet = false

  function petSize(): { width: number; height: number } {
    const bounds = stage.getBoundingClientRect()
    return { width: Math.max(1, bounds.width), height: Math.max(1, bounds.height) }
  }

  function petViewport(): { width: number; height: number } {
    return { width: Math.max(1, window.innerWidth), height: Math.max(1, window.innerHeight) }
  }

  function reducedMotion(): boolean {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches
  }

  function isQuietNight(): boolean {
    const hour = new Date().getHours()
    return hour >= 23 || hour < 7
  }

  function desiredAvatarAction(): AvatarAction | undefined {
    if (motionState.mode === 'walking') return 'walk'
    if (localActionOverride !== undefined) return localActionOverride
    // Sleep is local presence only: it never pretends that a DSH error or an
    // approval request means the character is asleep.
    if (!conversationOpen && !pointerDown && !dragging && currentPhase === 'idle' && isQuietNight()) return 'sleep'
    return undefined
  }

  function syncAvatarAnimation(): void {
    avatar.setPhase(currentPhase)
    avatar.setAction(desiredAvatarAction())
  }

  function applyPetPosition(position: { x: number; y: number }): void {
    const size = petSize()
    // The shell is deliberately larger than the visible avatar so it can host
    // the panel. Convert the avatar's visual coordinate back to its shell
    // coordinate so drag/flick/walk are bounded by the visible pet, not the
    // invisible panel area.
    const shellOffsetX = Math.max(0, shell.offsetWidth - size.width)
    const shellOffsetY = Math.max(0, shell.offsetHeight - size.height)
    shell.style.right = 'auto'
    shell.style.bottom = 'auto'
    shell.style.left = `${Math.round(position.x - shellOffsetX)}px`
    shell.style.top = `${Math.round(position.y - shellOffsetY)}px`
  }

  function applyMotion(next: PetMotionState): void {
    motionState = next
    applyPetPosition(next.position)
  }

  function stopMotion(): void {
    if (motionFrame !== undefined) window.cancelAnimationFrame(motionFrame)
    motionFrame = undefined
    motionFrameAt = undefined
    const stopped = stopPetMotion(motionState.position, petSize(), petViewport(), { reducedMotion: reducedMotion() })
    applyMotion(stopped)
    syncAvatarAnimation()
  }

  function advanceMotion(frameAt: number): void {
    const previous = motionFrameAt ?? frameAt
    motionFrameAt = frameAt
    applyMotion(stepPetMotion({
      state: motionState,
      elapsedMs: frameAt - previous,
      size: petSize(),
      viewport: petViewport(),
      options: { reducedMotion: reducedMotion(), edgePaddingPx: 8 },
    }))
    if (motionState.mode === 'idle') {
      motionFrame = undefined
      motionFrameAt = undefined
      syncAvatarAnimation()
      return
    }
    motionFrame = window.requestAnimationFrame(advanceMotion)
  }

  function beginMotion(next: PetMotionState): void {
    if (motionFrame !== undefined) window.cancelAnimationFrame(motionFrame)
    motionFrame = undefined
    motionFrameAt = undefined
    applyMotion(next)
    syncAvatarAnimation()
    if (next.mode === 'idle') return
    motionFrame = window.requestAnimationFrame(advanceMotion)
  }

  function hideLocalBubble(): void {
    if (localBubbleTimer !== undefined) window.clearTimeout(localBubbleTimer)
    localBubbleTimer = undefined
    localBubble?.remove()
    localBubble = undefined
  }

  function showLocalBubble(text: string, tone: string): void {
    hideLocalBubble()
    const bubble = document.createElement('div')
    bubble.className = 'local-reaction-bubble'
    bubble.dataset.tone = tone
    bubble.setAttribute('role', 'status')
    bubble.textContent = text
    shell.appendChild(bubble)
    localBubble = bubble
    localBubbleTimer = window.setTimeout(() => {
      if (localBubble === bubble) hideLocalBubble()
    }, 4_500)
  }

  function playLocalMotion(hint: LocalCompanionMotionHint): void {
    const serial = ++localReactionSerial
    if (localReactionTimer !== undefined) window.clearTimeout(localReactionTimer)
    if (hint === 'walk') {
      localActionOverride = undefined
      syncAvatarAnimation()
      return
    }
    localActionOverride = 'click'
    syncAvatarAnimation()
    localReactionTimer = window.setTimeout(() => {
      if (serial !== localReactionSerial || motionState.mode === 'walking') return
      localActionOverride = undefined
      syncAvatarAnimation()
    }, 850)
  }

  function localEventForAvatarTarget(target: string): LocalCompanionEvent {
    if (target === 'head') return { type: 'head' }
    if (target === 'tail') return { type: 'tail' }
    if (target === 'lower' || target.endsWith('foot') || target.endsWith('leg')) return { type: 'lower' }
    return { type: 'body' }
  }

  function dispatchLocalEvent(event: LocalCompanionEvent, source: 'explicit' | 'ambient'): void {
    const result = resolveLocalCompanionEvent(event, localCompanionState, {
      nowMs: Date.now(),
      hour: new Date().getHours(),
      random: Math.random,
    }, {
      // Explicit interaction is allowed to answer. Ambient activity is an
      // opt-in preference, preserving the avatar-only collapsed default.
      activeBubbles: source === 'explicit' || ambientInteractions,
    })
    localCompanionState = result.state
    playLocalMotion(result.intent.motion)
    if (result.intent.kind !== 'bubble') return
    showLocalBubble(result.intent.text, result.intent.tone)
    // Background presence never speaks; a deliberate user interaction may
    // use the selected TTS provider, then falls back to the system voice.
    if (source === 'explicit' && !speechMuted) {
      void Promise.resolve(voice?.speak({ text: result.intent.text, lang: 'zh-CN', mode: 'replace' }))
        .catch(error => console.warn('Local voice output failed', error))
    }
  }

  function ambientEligible(): boolean {
    return ambientInteractions && !conversationOpen && !pointerDown && !dragging
      && motionState.mode === 'idle' && !document.hidden
  }

  function clearAmbientTimers(): void {
    if (ambientWalkTimer !== undefined) window.clearTimeout(ambientWalkTimer)
    if (ambientGreetingTimer !== undefined) window.clearTimeout(ambientGreetingTimer)
    if (ambientProactiveTimer !== undefined) window.clearTimeout(ambientProactiveTimer)
    ambientWalkTimer = undefined
    ambientGreetingTimer = undefined
    ambientProactiveTimer = undefined
  }

  function scheduleAmbientWalk(): void {
    if (!ambientInteractions) return
    if (ambientWalkTimer !== undefined) window.clearTimeout(ambientWalkTimer)
    ambientWalkTimer = window.setTimeout(() => {
      ambientWalkTimer = undefined
      if (ambientEligible()) {
        const size = petSize()
        const viewport = petViewport()
        const horizontal = Math.max(0, viewport.width - size.width)
        const vertical = Math.max(0, viewport.height - size.height)
        const target = {
          x: Math.min(horizontal, Math.max(8, motionState.position.x + (Math.random() - 0.5) * 280)),
          y: Math.min(vertical, Math.max(8, motionState.position.y + (Math.random() - 0.5) * 100)),
        }
        const next = beginPetWalk({
          position: motionState.position,
          target,
          size,
          viewport,
          options: { reducedMotion: reducedMotion(), edgePaddingPx: 8 },
        })
        if (next.mode === 'walking') {
          dispatchLocalEvent({ type: 'walk' }, 'ambient')
          beginMotion(next)
        }
      }
      scheduleAmbientWalk()
    }, 45_000 + Math.floor(Math.random() * 45_000))
  }

  function scheduleAmbientGreeting(delayMs = 15_000): void {
    if (!ambientInteractions) return
    if (ambientGreetingTimer !== undefined) window.clearTimeout(ambientGreetingTimer)
    ambientGreetingTimer = window.setTimeout(() => {
      ambientGreetingTimer = undefined
      if (ambientEligible()) dispatchLocalEvent({ type: 'time-greeting' }, 'ambient')
      scheduleAmbientGreeting(60 * 60_000)
    }, delayMs)
  }

  function scheduleAmbientProactive(): void {
    if (!ambientInteractions) return
    if (ambientProactiveTimer !== undefined) window.clearTimeout(ambientProactiveTimer)
    ambientProactiveTimer = window.setTimeout(() => {
      ambientProactiveTimer = undefined
      if (ambientEligible()) dispatchLocalEvent({ type: 'proactive' }, 'ambient')
      scheduleAmbientProactive()
    }, 180_000 + Math.floor(Math.random() * 180_000))
  }

  function refreshAmbientBehaviors(): void {
    clearAmbientTimers()
    if (!ambientInteractions || conversationOpen) return
    scheduleAmbientWalk()
    scheduleAmbientGreeting()
    scheduleAmbientProactive()
  }

  function updateVoiceButton(): void {
    voiceButton.disabled = voice === undefined
    voiceButton.setAttribute('aria-pressed', String(speechMuted))
    voiceButton.setAttribute('aria-label', speechMuted ? '开启回复朗读' : '关闭回复朗读')
    voiceButton.title = voice === undefined ? '当前没有可用的朗读服务' : (speechMuted ? '开启回复朗读' : '关闭回复朗读')
    voiceButton.textContent = speechMuted ? '⊘' : '◖'
  }

  function statusText(): string {
    if (presenceState.connection === 'disconnected') return 'DSH 暂时离线'
    if (presenceState.connection !== 'connected') return '正在连接 DSH'
    if (activeSurface === 'workspace') {
      switch (workspaceState.status) {
        case 'loading': return '正在载入文件夹任务'
        case 'running': return '正在处理当前任务'
        case 'needs-input': return '需要在 DSH 中确认'
        case 'error': return '工作任务需要处理'
        case 'idle': return workspaceState.activeTask ? '可继续 · 仅此文件夹' : '选择文件夹开始工作'
        default: return '文件夹任务与对话相互隔离'
      }
    }
    switch (chatState.status) {
      case 'opening': return '正在打开专用会话'
      case 'running': return '正在回应'
      case 'error': return '连接需要重试'
      case 'idle': return '在线 · 点击角色可收起'
      default: return '在线 · 本地桌面伙伴'
    }
  }

  function updateHeader(): void {
    if (activeSurface === 'workspace') {
      personaName.textContent = workspaceState.activeTask?.workspaceName ?? '工作区'
      conversationStatus.textContent = statusText()
      return
    }
    // Keep the public companion identity stable even while connected to an
    // older compatible DSH installation that still reports a legacy persona
    // label such as "SoulDock" or "灵栖".
    personaName.textContent = '鲸灵'
    conversationStatus.textContent = statusText()
  }

  function createEmptyConversation(): HTMLElement {
    const empty = document.createElement('div')
    empty.id = 'empty-conversation'
    const mark = document.createElement('span')
    mark.textContent = '✦'
    const title = document.createElement('strong')
    title.textContent = '我在这里'
    const copy = document.createElement('p')
    copy.textContent = '和我说句话吧。这里没有文件、终端或工作区权限。'
    empty.append(mark, title, copy)
    return empty
  }

  function createMessage(role: 'user' | 'assistant', text: string, partial = false): HTMLElement {
    const item = document.createElement('article')
    item.className = 'chat-message'
    item.dataset.role = role
    if (partial) item.dataset.partial = 'true'
    const body = document.createElement('span')
    body.textContent = text
    item.appendChild(body)
    return item
  }

  function renderChat(state: ChatUiState, event?: ChatEvent): void {
    chatState = state
    updateHeader()
    const wasNearBottom = chatHistory.scrollHeight - chatHistory.scrollTop - chatHistory.clientHeight < 80
    chatHistory.replaceChildren()
    if (state.messages.length === 0 && !state.partial) {
      chatHistory.appendChild(createEmptyConversation())
    }
    else {
      for (const message of state.messages) {
        chatHistory.appendChild(createMessage(message.role, message.text))
      }
      if (state.partial) chatHistory.appendChild(createMessage('assistant', state.partial, true))
    }

    typingRow.hidden = state.status !== 'running' || Boolean(state.partial)
    cancelButton.hidden = state.status !== 'running'
    chatError.hidden = !state.error
    chatError.textContent = state.error ?? ''
    chatInput.maxLength = state.inputCodePoints
    sendButton.disabled = state.status === 'opening'
    updateInputCounter()

    if (wasNearBottom || event?.type === 'assistant-final' || event?.type === 'user-message') {
      chatHistory.scrollTop = chatHistory.scrollHeight
    }

    if (conversationOpen && activeSurface === 'companion' && event?.type === 'assistant-final' && !speechMuted) {
      void Promise.resolve(voice?.speak({ text: event.text, lang: 'zh-CN', mode: 'replace' }))
        .catch(error => console.warn('Voice output failed', error))
    }
  }

  function workspaceStatusLabel(status: 'idle' | 'running' | 'needs-input' | 'error'): string {
    if (status === 'running') return '进行中'
    if (status === 'needs-input') return '需要你'
    if (status === 'error') return '出错'
    return '可继续'
  }

  function workspaceStatusPriority(status: 'idle' | 'running' | 'needs-input' | 'error'): number {
    if (status === 'needs-input') return 0
    if (status === 'error') return 1
    if (status === 'running') return 2
    return 3
  }

  function compactWorkspacePath(value: string): string {
    const pieces = value.replace(/[\\/]+$/, '').split(/[\\/]/).filter(Boolean)
    return pieces.slice(-2).join(' › ') || value
  }

  function createWorkspaceWelcome(): HTMLElement {
    const welcome = document.createElement('div')
    welcome.id = 'workspace-welcome'
    const mark = document.createElement('span')
    mark.textContent = '⌁'
    const title = document.createElement('strong')
    title.textContent = '选择文件夹开始工作'
    const copy = document.createElement('p')
    copy.textContent = '每个成果使用独立任务；陪伴人格与记忆不会自动进入这里。'
    welcome.append(mark, title, copy)
    return welcome
  }

  function renderWorkspace(state: WorkspaceUiState, event?: WorkspaceTaskEvent): void {
    workspaceState = state
    updateHeader()
    workspaceView.dataset.detail = String(workspaceDetailVisible)
    const wasNearBottom = workspaceHistory.scrollHeight - workspaceHistory.scrollTop - workspaceHistory.clientHeight < 80
    workspaceTaskList.replaceChildren()
    const taskCount = state.workspaces.reduce((count, item) => count + item.tasks.length, 0)
    workspaceListEmpty.hidden = taskCount > 0
    workspaceTaskList.hidden = taskCount === 0

    for (const workspaceItem of state.workspaces) {
      if (workspaceItem.tasks.length === 0) continue
      const group = document.createElement('section')
      group.className = 'workspace-group'
      const heading = document.createElement('div')
      heading.className = 'workspace-group-heading'
      heading.textContent = workspaceItem.title
      heading.title = workspaceItem.path
      group.appendChild(heading)
      const orderedTasks = [...workspaceItem.tasks].sort((left, right) => (
        workspaceStatusPriority(left.status) - workspaceStatusPriority(right.status)
        || right.updatedAt - left.updatedAt
      ))
      for (const task of orderedTasks) {
        const button = document.createElement('button')
        button.type = 'button'
        button.className = 'workspace-task-button'
        button.dataset.active = String(state.activeTask?.taskId === task.taskId)
        button.dataset.status = task.status
        const title = document.createElement('strong')
        title.textContent = task.title
        const path = document.createElement('span')
        path.textContent = compactWorkspacePath(task.workspacePath)
        path.title = task.workspacePath
        const status = document.createElement('small')
        status.textContent = workspaceStatusLabel(task.status)
        button.append(title, path, status)
        button.addEventListener('click', () => {
          workspaceDetailVisible = true
          workspaceView.dataset.detail = 'true'
          void workspace.open(task.taskId)
            .then(() => workspaceInput.focus())
            .catch(showWorkspaceActionError)
        })
        group.appendChild(button)
      }
      workspaceTaskList.appendChild(group)
    }

    const activeTask = state.activeTask
    workspaceTaskTitle.textContent = activeTask?.title ?? '选择一个工作任务'
    workspaceTaskPath.textContent = activeTask
      ? `${activeTask.workspaceName} · ${compactWorkspacePath(activeTask.workspacePath)}`
      : '陪伴记忆不会自动带入工作区'
    workspaceTaskPath.title = activeTask?.workspacePath ?? ''
    workspaceNewTaskButton.disabled = activeTask === undefined

    workspaceHistory.replaceChildren()
    if (!activeTask || (state.messages.length === 0 && !state.partial)) {
      workspaceHistory.appendChild(createWorkspaceWelcome())
    }
    else {
      for (const message of state.messages) {
        workspaceHistory.appendChild(createMessage(message.role, message.text))
      }
      if (state.partial) workspaceHistory.appendChild(createMessage('assistant', state.partial, true))
    }

    workspaceTypingRow.hidden = state.status !== 'running' || Boolean(state.partial)
    workspaceCancelButton.hidden = state.status !== 'running'
    const workspaceNotice = state.status === 'needs-input'
      ? '需要在 DSH 中确认或补充信息后，任务才会继续。'
      : state.error
    workspaceError.hidden = !workspaceNotice
    workspaceError.textContent = workspaceNotice ?? ''
    workspaceInput.disabled = activeTask === undefined || state.status === 'loading'
    workspaceInput.placeholder = activeTask ? '描述要在这个文件夹中完成的任务…' : '先选择工作区…'
    workspaceInput.maxLength = state.inputCodePoints
    updateWorkspaceInputCounter()

    if (wasNearBottom || event?.type === 'assistant-final' || event?.type === 'user-message') {
      workspaceHistory.scrollTop = workspaceHistory.scrollHeight
    }
  }

  function renderPresence(state: SidecarViewState): void {
    presenceState = state
    shell.dataset.connection = state.connection
    updateHeader()
    const snapshot = state.snapshot
    if (!snapshot) return
    const phase = snapshot.runtime.phase
    const presentation = PHASE_PRESENTATION[phase]
    shell.dataset.phase = phase
    shell.style.setProperty('--phase-color', `#${presentation.color.toString(16).padStart(6, '0')}`)
    currentPhase = phase
    syncAvatarAnimation()
  }

  async function setPetInteractive(interactive: boolean): Promise<void> {
    if (petInteractive === interactive) return
    petInteractive = interactive
    try { await window.soulDockSidecar.setPetInteractive(interactive) }
    catch { /* Main may already be closing; interaction fails shut. */ }
  }

  function closeAvatarMenu(): void {
    avatarMenu.hidden = true
    avatarMenuButton.setAttribute('aria-expanded', 'false')
  }

  function showWorkspaceActionError(error: unknown): void {
    const message = error instanceof Error ? error.message : String(error)
    workspaceError.textContent = message.slice(0, 500)
    workspaceError.hidden = false
    console.warn('Jingling workspace action failed', error)
  }

  function syncSurfaceUi(): void {
    const companionActive = activeSurface === 'companion'
    panel.dataset.surface = activeSurface
    companionModeButton.setAttribute('aria-selected', String(companionActive))
    workspaceModeButton.setAttribute('aria-selected', String(!companionActive))
    companionModeButton.tabIndex = companionActive ? 0 : -1
    workspaceModeButton.tabIndex = companionActive ? -1 : 0
    companionView.hidden = !companionActive
    workspaceView.hidden = companionActive
    workspaceView.dataset.detail = String(workspaceDetailVisible)
    updateHeader()
  }

  async function activateSurface(surface: 'companion' | 'workspace', focus = true): Promise<void> {
    const changed = activeSurface !== surface
    activeSurface = surface
    localStorage.setItem('souldock:surface', surface)
    if (changed && surface === 'workspace') {
      void Promise.resolve(voice?.cancel()).catch(() => undefined)
    }
    syncSurfaceUi()
    if (!conversationOpen) return

    if (surface === 'companion') {
      if (chatState.status === 'error') await chat.close()
      await chat.open()
      if (focus) requestAnimationFrame(() => chatInput.focus())
      return
    }

    try {
      if (workspaceState.status === 'error' && workspaceState.activeTask) {
        await workspace.open(workspaceState.activeTask.taskId)
      }
      else {
        await workspace.refresh()
      }
      if (focus) requestAnimationFrame(() => {
        if (workspaceDetailVisible && workspaceState.activeTask) workspaceInput.focus()
        else workspacePickButton.focus()
      })
    }
    catch (error) {
      showWorkspaceActionError(error)
    }
  }

  async function openConversation(showAppearance = false): Promise<void> {
    if (conversationOpen) {
      if (showAppearance) {
        avatarMenu.hidden = false
        avatarMenuButton.setAttribute('aria-expanded', 'true')
      }
      return
    }
    stopMotion()
    clearAmbientTimers()
    conversationOpen = true
    syncAvatarAnimation()
    shell.dataset.open = 'true'
    panel.setAttribute('aria-hidden', 'false')
    stage.setAttribute('aria-expanded', 'true')
    await window.soulDockSidecar.setConversationOpen(true)
    syncSurfaceUi()
    await activateSurface(activeSurface, false)
    if (showAppearance) {
      avatarMenu.hidden = false
      avatarMenuButton.setAttribute('aria-expanded', 'true')
    }
    requestAnimationFrame(() => {
      if (showAppearance) avatarMenuButton.focus()
      else if (activeSurface === 'workspace') workspacePickButton.focus()
      else chatInput.focus()
    })
  }

  async function closeConversation(): Promise<void> {
    if (!conversationOpen) return
    conversationOpen = false
    closeAvatarMenu()
    hideLocalBubble()
    stopMotion()
    shell.dataset.open = 'false'
    panel.setAttribute('aria-hidden', 'true')
    stage.setAttribute('aria-expanded', 'false')
    void Promise.resolve(voice?.cancel()).catch(() => undefined)
    workspaceDetailVisible = false
    workspaceView.dataset.detail = 'false'
    petInteractive = false
    try { await window.soulDockSidecar.setConversationOpen(false) }
    catch { /* The renderer is already fail-closed; main may be exiting. */ }
    await Promise.allSettled([chat.close(), workspace.close()])
    refreshAmbientBehaviors()
  }

  function toggleConversation(): void {
    if (conversationOpen) void closeConversation().catch(error => console.warn('Unable to close Jingling panel', error))
    else void openConversation().catch(showRendererFailure)
  }

  function updateInputCounter(): void {
    const used = codePointLength(chatInput.value)
    inputCounter.textContent = `${used} / ${chatState.inputCodePoints}`
    sendButton.disabled = chatState.status === 'opening' || used === 0 || used > chatState.inputCodePoints
    chatInput.style.height = 'auto'
    chatInput.style.height = `${Math.min(chatInput.scrollHeight, 116)}px`
  }

  function updateWorkspaceInputCounter(): void {
    const used = codePointLength(workspaceInput.value)
    workspaceInputCounter.textContent = `${used} / ${workspaceState.inputCodePoints}`
    const unavailable = workspaceState.activeTask === undefined
      || workspaceState.status === 'loading'
      || workspaceState.status === 'running'
      || workspaceState.status === 'needs-input'
    workspaceSendButton.disabled = unavailable || used === 0 || used > workspaceState.inputCodePoints
    workspaceInput.style.height = 'auto'
    workspaceInput.style.height = `${Math.min(workspaceInput.scrollHeight, 116)}px`
  }

  async function pickAndCreateWorkspace(): Promise<void> {
    workspacePickButton.disabled = true
    workspaceEmptyPickButton.disabled = true
    try {
      const picked = await workspace.pickDirectory()
      if (!picked) return
      workspaceDetailVisible = true
      workspaceView.dataset.detail = 'true'
      await workspace.create(picked.path)
      workspaceInput.focus()
    }
    catch (error) {
      showWorkspaceActionError(error)
    }
    finally {
      workspacePickButton.disabled = false
      workspaceEmptyPickButton.disabled = false
    }
  }

  async function createTaskInActiveWorkspace(): Promise<void> {
    const activeTask = workspaceState.activeTask
    if (!activeTask) return
    workspaceNewTaskButton.disabled = true
    workspaceDetailVisible = true
    workspaceView.dataset.detail = 'true'
    try {
      await workspace.create(activeTask.workspacePath)
      workspaceInput.focus()
    }
    catch (error) {
      showWorkspaceActionError(error)
    }
    finally {
      workspaceNewTaskButton.disabled = workspaceState.activeTask === undefined
    }
  }

  stage.addEventListener('pointerdown', (event) => {
    if (event.button !== 0 || !avatar.hitTest(event.clientX, event.clientY)) return
    stopMotion()
    pointerDown = true
    syncAvatarAnimation()
    dragging = false
    pointerStart = { x: event.clientX, y: event.clientY }
    const petBounds = stage.getBoundingClientRect()
    dragStart = { left: petBounds.left, top: petBounds.top }
    motionState = createPetMotionState(
      { x: petBounds.left, y: petBounds.top },
      petSize(),
      petViewport(),
      { edgePaddingPx: 8 },
    )
    pointerSamples = [{ x: event.clientX, y: event.clientY, at: performance.now() }]
    stage.setPointerCapture(event.pointerId)
    void setPetInteractive(true)
  })

  stage.addEventListener('pointermove', (event) => {
    if (!pointerDown) return
    if (!dragging && isClickLikePointerGesture(pointerStart, { x: event.clientX, y: event.clientY })) return
    dragging = true
    shell.dataset.dragging = 'true'
    pointerSamples.push({ x: event.clientX, y: event.clientY, at: performance.now() })
    if (pointerSamples.length > 5) pointerSamples.shift()
    applyMotion(dragPet({
      origin: { x: dragStart.left, y: dragStart.top },
      pointerStart,
      pointerCurrent: { x: event.clientX, y: event.clientY },
      size: petSize(),
      viewport: petViewport(),
      options: { edgePaddingPx: 8 },
    }))
  })

  function finishPointer(event: PointerEvent): void {
    if (!pointerDown) return
    const hit = avatar.hitTest(event.clientX, event.clientY)
    const click = !dragging
      && isClickLikePointerGesture(pointerStart, { x: event.clientX, y: event.clientY })
      && hit !== null
    const wasDragging = dragging
    pointerDown = false
    dragging = false
    shell.dataset.dragging = 'false'
    syncAvatarAnimation()
    if (stage.hasPointerCapture(event.pointerId)) stage.releasePointerCapture(event.pointerId)
    if (click && hit) {
      dispatchLocalEvent(localEventForAvatarTarget(hit.target), 'explicit')
      toggleConversation()
      return
    }
    if (!wasDragging) return
    const latest = pointerSamples.at(-1) ?? { x: event.clientX, y: event.clientY, at: performance.now() }
    const previous = pointerSamples.at(-2) ?? { x: pointerStart.x, y: pointerStart.y, at: latest.at - 16 }
    const elapsedSeconds = Math.max(0.016, (latest.at - previous.at) / 1_000)
    const velocity = {
      x: (latest.x - previous.x) / elapsedSeconds,
      y: (latest.y - previous.y) / elapsedSeconds,
    }
    const speed = Math.hypot(velocity.x, velocity.y)
    const next = beginPetFlick({
      position: motionState.position,
      releaseVelocity: velocity,
      size: petSize(),
      viewport: petViewport(),
      options: { reducedMotion: reducedMotion(), edgePaddingPx: 8 },
    })
    if (speed >= 240 && next.mode === 'flicking') dispatchLocalEvent({ type: 'flick' }, 'explicit')
    beginMotion(next)
  }

  stage.addEventListener('pointerup', finishPointer)
  stage.addEventListener('pointercancel', (event) => {
    pointerDown = false
    dragging = false
    pointerSamples = []
    shell.dataset.dragging = 'false'
    if (stage.hasPointerCapture(event.pointerId)) stage.releasePointerCapture(event.pointerId)
    stopMotion()
  })

  stage.addEventListener('contextmenu', (event) => {
    if (!avatar.hitTest(event.clientX, event.clientY)) return
    event.preventDefault()
    void openConversation(true)
  })

  stage.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return
    event.preventDefault()
    dispatchLocalEvent({ type: 'body' }, 'explicit')
    toggleConversation()
  })

  document.addEventListener('mousemove', (event) => {
    const overPanel = conversationOpen && pointInside(panel, event.clientX, event.clientY)
    const overAvatar = avatar.hitTest(event.clientX, event.clientY) !== null
    void setPetInteractive(dragging || overPanel || overAvatar)
    const bounds = stage.getBoundingClientRect()
    const dx = Math.max(bounds.left - event.clientX, 0, event.clientX - bounds.right)
    const dy = Math.max(bounds.top - event.clientY, 0, event.clientY - bounds.bottom)
    const near = Math.hypot(dx, dy) <= 72
    if (near && !pointerNearPet && ambientEligible()) dispatchLocalEvent({ type: 'near' }, 'ambient')
    pointerNearPet = near
  })

  document.addEventListener('dragover', (event) => {
    if (!pointInside(stage, event.clientX, event.clientY)) return
    event.preventDefault()
  })
  document.addEventListener('drop', (event) => {
    if (!pointInside(stage, event.clientX, event.clientY)) return
    event.preventDefault()
    const fileName = event.dataTransfer?.files.item(0)?.name
    dispatchLocalEvent({ type: 'file-drop', ...(fileName ? { fileName } : {}) }, 'explicit')
  })
  window.addEventListener('resize', () => {
    const next = stopPetMotion(motionState.position, petSize(), petViewport(), { edgePaddingPx: 8 })
    applyMotion(next)
    if (motionFrame !== undefined) {
      window.cancelAnimationFrame(motionFrame)
      motionFrame = undefined
      motionFrameAt = undefined
      syncAvatarAnimation()
    }
  })

  companionModeButton.addEventListener('click', () => {
    void activateSurface('companion').catch(error => console.warn('Unable to open companion conversation', error))
  })
  workspaceModeButton.addEventListener('click', () => {
    void activateSurface('workspace').catch(showWorkspaceActionError)
  })

  const modeTabs = [companionModeButton, workspaceModeButton] as const
  for (const [index, tab] of modeTabs.entries()) {
    tab.addEventListener('keydown', (event) => {
      let nextIndex: number | undefined
      if (event.key === 'ArrowRight' || event.key === 'ArrowDown') nextIndex = (index + 1) % modeTabs.length
      if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') nextIndex = (index - 1 + modeTabs.length) % modeTabs.length
      if (event.key === 'Home') nextIndex = 0
      if (event.key === 'End') nextIndex = modeTabs.length - 1
      if (nextIndex === undefined) return
      event.preventDefault()
      const next = modeTabs[nextIndex]
      if (!next) return
      next.focus()
      void activateSurface(next === companionModeButton ? 'companion' : 'workspace', false)
        .catch(error => console.warn('Unable to switch Jingling mode', error))
    })
  }

  workspacePickButton.addEventListener('click', () => void pickAndCreateWorkspace())
  workspaceEmptyPickButton.addEventListener('click', () => void pickAndCreateWorkspace())
  workspaceNewTaskButton.addEventListener('click', () => void createTaskInActiveWorkspace())
  workspaceBackButton.addEventListener('click', () => {
    workspaceDetailVisible = false
    workspaceView.dataset.detail = 'false'
    requestAnimationFrame(() => {
      const target = workspaceTaskList.querySelector<HTMLElement>('[data-active="true"]')
        ?? workspaceTaskList.querySelector<HTMLElement>('button')
        ?? (workspaceListEmpty.hidden ? workspacePickButton : workspaceEmptyPickButton)
      target.focus()
    })
  })

  chatForm.addEventListener('submit', (event) => {
    event.preventDefault()
    const text = chatInput.value
    if (!text.trim()) return
    chatInput.value = ''
    updateInputCounter()
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
    void chat.send(text, timeZone).catch(() => {
      chatInput.value = text
      updateInputCounter()
      chatInput.focus()
    })
  })

  chatInput.addEventListener('input', updateInputCounter)
  chatInput.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.preventDefault()
      void closeConversation()
      return
    }
    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
      event.preventDefault()
      chatForm.requestSubmit()
    }
  })

  workspaceForm.addEventListener('submit', (event) => {
    event.preventDefault()
    const text = workspaceInput.value
    if (!text.trim()) return
    const submittedTaskId = workspaceState.activeTask?.taskId
    workspaceInput.value = ''
    updateWorkspaceInputCounter()
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone
    void workspace.send(text, timeZone).catch(() => {
      if (!submittedTaskId || workspaceState.activeTask?.taskId !== submittedTaskId) return
      workspaceInput.value = text
      updateWorkspaceInputCounter()
      workspaceInput.focus()
    })
  })
  workspaceInput.addEventListener('input', updateWorkspaceInputCounter)
  workspaceInput.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      event.preventDefault()
      void closeConversation()
      return
    }
    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
      event.preventDefault()
      workspaceForm.requestSubmit()
    }
  })
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && conversationOpen) void closeConversation()
  })

  collapseButton.addEventListener('click', () => void closeConversation())
  exitButton.addEventListener('click', () => {
    exitButton.disabled = true
    void window.soulDockSidecar.quit().catch(() => { exitButton.disabled = false })
  })
  cancelButton.addEventListener('click', () => {
    cancelButton.disabled = true
    void chat.cancel().finally(() => { cancelButton.disabled = false })
  })
  workspaceCancelButton.addEventListener('click', () => {
    workspaceCancelButton.disabled = true
    void workspace.cancel()
      .catch(showWorkspaceActionError)
      .finally(() => { workspaceCancelButton.disabled = false })
  })
  voiceButton.addEventListener('click', () => {
    speechMuted = !speechMuted
    localStorage.setItem('souldock:speech-muted', String(speechMuted))
    if (speechMuted) void Promise.resolve(voice?.cancel()).catch(() => undefined)
    updateVoiceButton()
  })

  avatarMenuButton.addEventListener('click', () => {
    avatarMenu.hidden = !avatarMenu.hidden
    avatarMenuButton.setAttribute('aria-expanded', String(!avatarMenu.hidden))
  })
  ambientInteractionsToggle.checked = ambientInteractions
  ambientInteractionsToggle.addEventListener('change', () => {
    ambientInteractions = ambientInteractionsToggle.checked
    localStorage.setItem('souldock:ambient-interactions', String(ambientInteractions))
    if (!ambientInteractions) {
      hideLocalBubble()
      stopMotion()
    }
    refreshAmbientBehaviors()
  })
  vrmRights.addEventListener('change', () => { chooseVrmButton.disabled = !vrmRights.checked })
  chooseVrmButton.addEventListener('click', () => { if (vrmRights.checked) vrmInput.click() })

  function showAvatarMetadata(title: string, rows: ReadonlyArray<{ label: string; value: string }>): void {
    avatarMetadata.replaceChildren()
    const heading = document.createElement('strong')
    heading.textContent = title
    avatarMetadata.appendChild(heading)
    for (const row of rows) {
      const line = document.createElement('span')
      line.textContent = `${row.label}：${row.value}`
      avatarMetadata.appendChild(line)
    }
    avatarMetadata.hidden = false
  }

  spriteButton.addEventListener('click', () => {
    avatarStatus.textContent = '正在切换到鲸灵立绘…'
    void avatar.switchTo(createSpriteAvatar).then(result => {
      if (!result.applied) return
      avatarStatus.textContent = '当前：鲸灵立绘'
      avatarMetadata.hidden = true
    }).catch(error => {
      avatarStatus.textContent = `鲸灵立绘切换失败：${error instanceof Error ? error.message : String(error)}`
    })
  })

  vrmInput.addEventListener('change', () => {
    const file = vrmInput.files?.[0]
    vrmInput.value = ''
    if (!file || !vrmRights.checked) return
    avatarStatus.textContent = `正在本地加载 ${file.name}…`
    void avatar.switchTo(container => createLocalVrmAvatar(container, file)).then(result => {
      if (!result.applied) return
      avatarStatus.textContent = '当前：本地 VRM（仅本次运行）'
      if (result.metadata) showAvatarMetadata(result.metadata.title, result.metadata.rows)
    }).catch(error => {
      avatarStatus.textContent = `VRM 未切换：${error instanceof Error ? error.message : String(error)}`
    })
  })

  updateVoiceButton()
  updateInputCounter()
  updateWorkspaceInputCounter()
  syncSurfaceUi()
  refreshAmbientBehaviors()
  const unsubscribeChat = chat.subscribe(renderChat)
  const unsubscribeWorkspace = workspace.subscribe(renderWorkspace)
  renderPresence(await window.soulDockSidecar.getState())
  restAnimationTimer = window.setInterval(syncAvatarAnimation, 60_000)
  const unsubscribePresence = window.soulDockSidecar.onState(renderPresence)

  window.addEventListener('beforeunload', () => {
    clearAmbientTimers()
    hideLocalBubble()
    if (motionFrame !== undefined) window.cancelAnimationFrame(motionFrame)
    if (localReactionTimer !== undefined) window.clearTimeout(localReactionTimer)
    if (restAnimationTimer !== undefined) window.clearInterval(restAnimationTimer)
    unsubscribeChat()
    unsubscribeWorkspace()
    unsubscribePresence()
    void chat.close()
    void workspace.close()
    void Promise.resolve(voice?.dispose?.() ?? voice?.cancel()).catch(() => undefined)
    void avatar.destroy()
  })
}

void bootstrap().catch(showRendererFailure)
