import type { AssistantMessageEvent, SidecarEvent } from '../core/protocol'

export class AssistantEventCursor {
  #epoch: number | undefined
  #snapshotSequence: number | undefined
  #assistantSequence = -1

  take(epoch: number | undefined, snapshotSequence: number, events: readonly SidecarEvent[]): AssistantMessageEvent[] {
    const epochChanged = this.#epoch !== undefined && epoch !== this.#epoch
    const sequenceRolledBack = this.#snapshotSequence !== undefined && snapshotSequence < this.#snapshotSequence
    if (epochChanged || sequenceRolledBack) this.#assistantSequence = -1

    this.#epoch = epoch
    this.#snapshotSequence = snapshotSequence

    const assistantEvents: AssistantMessageEvent[] = []
    for (const event of [...events].sort((a, b) => a.sequence - b.sequence)) {
      if (event.type !== 'assistant-message' || event.sequence <= this.#assistantSequence) continue
      this.#assistantSequence = event.sequence
      assistantEvents.push(event)
    }
    return assistantEvents
  }
}
