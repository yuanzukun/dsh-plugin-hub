import type { SoulDockPhase } from '../../core/phases'

/**
 * Deliberately runtime-only Live2D seam.
 *
 * SoulDock does NOT distribute Cubism Core, Cubism SDK, sample models, or model
 * motion/audio files. A user may separately install and license those pieces,
 * then provide a bridge implementing this contract.
 */
export interface UserLive2DRuntime {
  mount: (container: HTMLElement, modelUrl: string) => Promise<UserLive2DController>
}

export interface UserLive2DController {
  setPhase: (phase: SoulDockPhase) => void
  resize?: () => void
  dispose: () => void | Promise<void>
}

export async function mountUserProvidedLive2D(
  runtime: UserLive2DRuntime,
  container: HTMLElement,
  modelUrl: string,
): Promise<UserLive2DController> {
  if (!modelUrl) throw new Error('A user-provided Live2D model URL is required')
  return runtime.mount(container, modelUrl)
}

