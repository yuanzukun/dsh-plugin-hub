import type { RendererVoiceBridge } from '../../core/voice-config'
import { BrowserVoicevoxWavPlayback, type VoicevoxWavPlayback } from './voicevox-local'

export type SpeechQueueMode = 'enqueue' | 'replace'

export interface SpeechRequest {
  text: string
  lang?: string
  rate?: number
  pitch?: number
  volume?: number
  mode?: SpeechQueueMode
}

export interface VoiceOutputProvider {
  readonly id: 'web-speech' | 'voicevox-local' | 'edge-tts' | 'airi' | 'unspeech'
  readonly capabilities: {
    tts: boolean
    stt: false
    fullDuplex: false
  }
  speak: (request: SpeechRequest) => void | Promise<void>
  cancel: () => void | Promise<void>
  dispose?: () => void | Promise<void>
}

export class VoicevoxIpcOutputProvider implements VoiceOutputProvider {
  readonly id = 'voicevox-local' as const
  readonly capabilities = { tts: true, stt: false, fullDuplex: false } as const
  readonly #bridge: Pick<RendererVoiceBridge, 'synthesize' | 'cancel'>
  readonly #playback: VoicevoxWavPlayback
  #generation = 0
  #active?: AbortController

  constructor(
    bridge: Pick<RendererVoiceBridge, 'synthesize' | 'cancel'>,
    playback: VoicevoxWavPlayback = new BrowserVoicevoxWavPlayback(),
  ) {
    this.#bridge = bridge
    this.#playback = playback
  }

  async speak(request: SpeechRequest): Promise<void> {
    const text = request.text.trim()
    if (!text) return

    const generation = ++this.#generation
    this.#active?.abort(new Error('VOICEVOX speech replaced'))
    this.#active = undefined
    const stopped = this.#playback.stop()
    if (request.mode === 'replace') await this.#bridge.cancel()
    await stopped
    if (generation !== this.#generation) return

    const active = new AbortController()
    this.#active = active
    try {
      const wav = await this.#bridge.synthesize(text)
      if (generation !== this.#generation) return
      const bytes = Uint8Array.from(wav)
      await this.#playback.play(new Blob([bytes.buffer], { type: 'audio/wav' }), active.signal)
    }
    catch (error) {
      if (generation === this.#generation) throw error
    }
    finally {
      if (this.#active === active) this.#active = undefined
    }
  }

  async cancel(): Promise<void> {
    this.#generation += 1
    this.#active?.abort(new Error('VOICEVOX speech cancelled'))
    this.#active = undefined
    await Promise.all([
      this.#bridge.cancel(),
      Promise.resolve(this.#playback.stop()),
    ])
  }

  async dispose(): Promise<void> {
    await this.cancel()
  }
}

/**
 * Plays MP3 data made by the user-installed Python edge-tts package. When the
 * optional process is unavailable or fails, the provided local Web Speech
 * provider speaks the same text instead. This keeps remote TTS opt-in while
 * ensuring a normal system voice remains usable offline.
 */
export class EdgeTtsIpcOutputProvider implements VoiceOutputProvider {
  readonly id = 'edge-tts' as const
  readonly capabilities = { tts: true, stt: false, fullDuplex: false } as const
  readonly #bridge: Pick<RendererVoiceBridge, 'synthesize' | 'cancel'>
  readonly #playback: VoicevoxWavPlayback
  readonly #fallback?: Pick<VoiceOutputProvider, 'speak' | 'cancel'>
  #generation = 0
  #active?: AbortController

  constructor(
    bridge: Pick<RendererVoiceBridge, 'synthesize' | 'cancel'>,
    playback: VoicevoxWavPlayback = new BrowserVoicevoxWavPlayback(),
    fallback?: Pick<VoiceOutputProvider, 'speak' | 'cancel'>,
  ) {
    this.#bridge = bridge
    this.#playback = playback
    this.#fallback = fallback
  }

  async speak(request: SpeechRequest): Promise<void> {
    const text = request.text.trim()
    if (!text) return

    const generation = ++this.#generation
    this.#active?.abort(new Error('Edge TTS speech replaced'))
    this.#active = undefined
    const stopped = this.#playback.stop()
    if (request.mode === 'replace') {
      await Promise.all([
        this.#bridge.cancel(),
        Promise.resolve(this.#fallback?.cancel()),
      ])
    }
    await stopped
    if (generation !== this.#generation) return

    const active = new AbortController()
    this.#active = active
    try {
      const audio = await this.#bridge.synthesize(text)
      if (generation !== this.#generation || active.signal.aborted) return
      const bytes = Uint8Array.from(audio)
      await this.#playback.play(new Blob([bytes.buffer], { type: 'audio/mpeg' }), active.signal)
    }
    catch (error) {
      if (generation !== this.#generation || active.signal.aborted) return
      if (!this.#fallback) throw error
      await Promise.resolve(this.#fallback.speak({ ...request, text, mode: 'replace' }))
    }
    finally {
      if (this.#active === active) this.#active = undefined
    }
  }

  async cancel(): Promise<void> {
    this.#generation += 1
    this.#active?.abort(new Error('Edge TTS speech cancelled'))
    this.#active = undefined
    await Promise.all([
      this.#bridge.cancel(),
      Promise.resolve(this.#playback.stop()),
      Promise.resolve(this.#fallback?.cancel()),
    ])
  }

  async dispose(): Promise<void> {
    await this.cancel()
  }
}

export interface VadAdapter {
  readonly id: string
  start: (callbacks: { onSpeechStart: () => void; onSpeechEnd: () => void }) => Promise<void>
  stop: () => Promise<void>
}

export class WebSpeechSynthesisProvider implements VoiceOutputProvider {
  readonly id = 'web-speech' as const
  readonly capabilities = { tts: true, stt: false, fullDuplex: false } as const
  readonly #synthesis: SpeechSynthesis

  constructor(synthesis: SpeechSynthesis = window.speechSynthesis) {
    this.#synthesis = synthesis
  }

  speak(request: SpeechRequest): void {
    const text = request.text.trim()
    if (!text) return
    if (request.mode === 'replace') this.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    if (request.lang) utterance.lang = request.lang
    if (request.rate !== undefined) utterance.rate = request.rate
    if (request.pitch !== undefined) utterance.pitch = request.pitch
    if (request.volume !== undefined) utterance.volume = request.volume
    this.#synthesis.speak(utterance)
  }

  cancel(): void {
    this.#synthesis.cancel()
  }
}

/** AIRI currently exposes no stable public speak(text) API; inject a bridge when one is available. */
export function reserveAiriVoiceProvider(delegate: Omit<VoiceOutputProvider, 'id' | 'capabilities'>): VoiceOutputProvider {
  return {
    id: 'airi',
    capabilities: { tts: true, stt: false, fullDuplex: false },
    ...delegate,
  }
}

/** UnSpeech wiring is intentionally injected so API keys never live in this renderer bundle. */
export function reserveUnspeechVoiceProvider(delegate: Omit<VoiceOutputProvider, 'id' | 'capabilities'>): VoiceOutputProvider {
  return {
    id: 'unspeech',
    capabilities: { tts: true, stt: false, fullDuplex: false },
    ...delegate,
  }
}
