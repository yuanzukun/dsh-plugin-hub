export interface VoicevoxAudioQuery extends Record<string, unknown> {}

export interface VoicevoxSynthesisRequest {
  text: string
  speaker?: number
  signal?: AbortSignal
  deadlineMilliseconds?: number
  enableInterrogativeUpspeak?: boolean
  transformAudioQuery?: (query: VoicevoxAudioQuery) => VoicevoxAudioQuery
}

export interface VoicevoxLocalClientOptions {
  baseUrl?: string
  defaultSpeaker?: number
  defaultDeadlineMilliseconds?: number
  fetch?: typeof fetch
}

export interface VoicevoxWavPlayback {
  play: (wav: Blob, signal: AbortSignal) => Promise<void>
  stop: () => void | Promise<void>
}

export interface VoicevoxLocalProviderOptions extends VoicevoxLocalClientOptions {
  playback?: VoicevoxWavPlayback
}

export class VoicevoxHttpError extends Error {
  readonly status: number
  readonly endpoint: 'audio_query' | 'synthesis'

  constructor(endpoint: 'audio_query' | 'synthesis', status: number, detail: string) {
    super(`VOICEVOX ${endpoint} failed with HTTP ${status}${detail ? `: ${detail}` : ''}`)
    this.name = 'VoicevoxHttpError'
    this.status = status
    this.endpoint = endpoint
  }
}

const DEFAULT_BASE_URL = 'http://127.0.0.1:50021/'
const DEFAULT_DEADLINE_MILLISECONDS = 60_000
const LOOPBACK_HOSTS = new Set(['localhost', '127.0.0.1', '[::1]'])

export function normalizeVoicevoxLoopbackBaseUrl(input: string): URL {
  const url = new URL(input)
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    throw new TypeError('VOICEVOX base URL must use HTTP or HTTPS')
  }
  if (!LOOPBACK_HOSTS.has(url.hostname)) {
    throw new TypeError('VOICEVOX base URL must be loopback-only')
  }
  if (url.username || url.password) {
    throw new TypeError('VOICEVOX base URL must not contain credentials')
  }
  url.pathname = '/'
  url.search = ''
  url.hash = ''
  return url
}

function validSpeaker(value: number): number {
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new TypeError('VOICEVOX speaker must be a non-negative safe integer')
  }
  return value
}

function validDeadline(value: number): number {
  if (!Number.isFinite(value) || value <= 0) {
    throw new TypeError('VOICEVOX deadline must be a positive finite number')
  }
  return value
}

function abortReason(signal: AbortSignal): unknown {
  return signal.reason ?? new DOMException('The operation was aborted', 'AbortError')
}

function deadlineSignal(callerSignal: AbortSignal | undefined, milliseconds: number): {
  signal: AbortSignal
  cleanup: () => void
} {
  const controller = new AbortController()
  const timeout = setTimeout(() => {
    controller.abort(new Error(`VOICEVOX synthesis exceeded ${milliseconds} ms deadline`))
  }, milliseconds)
  const forwardAbort = (): void => controller.abort(abortReason(callerSignal!))

  if (callerSignal?.aborted) forwardAbort()
  else callerSignal?.addEventListener('abort', forwardAbort, { once: true })

  return {
    signal: controller.signal,
    cleanup: () => {
      clearTimeout(timeout)
      callerSignal?.removeEventListener('abort', forwardAbort)
    },
  }
}

async function responseDetail(response: Response): Promise<string> {
  try {
    return (await response.text()).replace(/\s+/g, ' ').trim().slice(0, 300)
  }
  catch {
    return ''
  }
}

export class VoicevoxLocalClient {
  readonly #baseUrl: URL
  readonly #defaultSpeaker: number
  readonly #defaultDeadlineMilliseconds: number
  readonly #fetch: typeof fetch

  constructor(options: VoicevoxLocalClientOptions = {}) {
    this.#baseUrl = normalizeVoicevoxLoopbackBaseUrl(options.baseUrl ?? DEFAULT_BASE_URL)
    this.#defaultSpeaker = validSpeaker(options.defaultSpeaker ?? 1)
    this.#defaultDeadlineMilliseconds = validDeadline(
      options.defaultDeadlineMilliseconds ?? DEFAULT_DEADLINE_MILLISECONDS,
    )
    this.#fetch = options.fetch ?? fetch
  }

  async synthesize(request: VoicevoxSynthesisRequest): Promise<Blob> {
    const text = request.text.trim()
    if (!text) throw new TypeError('VOICEVOX text must not be empty')

    const speaker = validSpeaker(request.speaker ?? this.#defaultSpeaker)
    const milliseconds = validDeadline(
      request.deadlineMilliseconds ?? this.#defaultDeadlineMilliseconds,
    )
    const deadline = deadlineSignal(request.signal, milliseconds)

    try {
      deadline.signal.throwIfAborted()
      const queryUrl = new URL('audio_query', this.#baseUrl)
      queryUrl.searchParams.set('text', text)
      queryUrl.searchParams.set('speaker', String(speaker))
      const queryResponse = await this.#fetch(queryUrl, {
        method: 'POST',
        headers: { Accept: 'application/json' },
        credentials: 'omit',
        cache: 'no-store',
        redirect: 'error',
        signal: deadline.signal,
      })
      if (!queryResponse.ok) {
        throw new VoicevoxHttpError('audio_query', queryResponse.status, await responseDetail(queryResponse))
      }

      const rawQuery: unknown = await queryResponse.json()
      if (rawQuery === null || typeof rawQuery !== 'object' || Array.isArray(rawQuery)) {
        throw new TypeError('VOICEVOX audio_query returned a non-object response')
      }
      const audioQuery = request.transformAudioQuery
        ? request.transformAudioQuery(rawQuery as VoicevoxAudioQuery)
        : rawQuery as VoicevoxAudioQuery
      if (audioQuery === null || typeof audioQuery !== 'object' || Array.isArray(audioQuery)) {
        throw new TypeError('VOICEVOX transformed audio query must be an object')
      }

      deadline.signal.throwIfAborted()
      const synthesisUrl = new URL('synthesis', this.#baseUrl)
      synthesisUrl.searchParams.set('speaker', String(speaker))
      if (request.enableInterrogativeUpspeak !== undefined) {
        synthesisUrl.searchParams.set(
          'enable_interrogative_upspeak',
          String(request.enableInterrogativeUpspeak),
        )
      }
      const synthesisResponse = await this.#fetch(synthesisUrl, {
        method: 'POST',
        headers: {
          Accept: 'audio/wav',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(audioQuery),
        credentials: 'omit',
        cache: 'no-store',
        redirect: 'error',
        signal: deadline.signal,
      })
      if (!synthesisResponse.ok) {
        throw new VoicevoxHttpError('synthesis', synthesisResponse.status, await responseDetail(synthesisResponse))
      }

      const wav = await synthesisResponse.blob()
      if (wav.size === 0) throw new TypeError('VOICEVOX synthesis returned empty audio')
      return wav
    }
    finally {
      deadline.cleanup()
    }
  }
}

export class BrowserVoicevoxWavPlayback implements VoicevoxWavPlayback {
  #audio?: HTMLAudioElement
  #objectUrl?: string

  async play(wav: Blob, signal: AbortSignal): Promise<void> {
    await this.stop()
    signal.throwIfAborted()

    const objectUrl = URL.createObjectURL(wav)
    const audio = new Audio(objectUrl)
    this.#objectUrl = objectUrl
    this.#audio = audio

    await new Promise<void>((resolve, reject) => {
      let settled = false
      const finish = (error?: unknown): void => {
        if (settled) return
        settled = true
        signal.removeEventListener('abort', onAbort)
        audio.onended = null
        audio.onerror = null
        if (this.#audio === audio) this.#release()
        if (error !== undefined) reject(error)
        else resolve()
      }
      const onAbort = (): void => {
        audio.pause()
        finish(abortReason(signal))
      }

      signal.addEventListener('abort', onAbort, { once: true })
      audio.onended = () => finish()
      audio.onerror = () => finish(new Error('VOICEVOX audio playback failed'))
      void audio.play().catch(finish)
    })
  }

  stop(): void {
    this.#audio?.pause()
    this.#release()
  }

  #release(): void {
    this.#audio = undefined
    if (this.#objectUrl) URL.revokeObjectURL(this.#objectUrl)
    this.#objectUrl = undefined
  }
}

export class VoicevoxLocalTtsProvider {
  readonly id = 'voicevox-local' as const
  readonly capabilities = { tts: true, stt: false, fullDuplex: false } as const
  readonly #client: VoicevoxLocalClient
  readonly #playback: VoicevoxWavPlayback
  #active?: AbortController

  constructor(options: VoicevoxLocalProviderOptions = {}) {
    this.#client = new VoicevoxLocalClient(options)
    this.#playback = options.playback ?? new BrowserVoicevoxWavPlayback()
  }

  async speak(request: VoicevoxSynthesisRequest): Promise<void> {
    this.#active?.abort(new Error('VOICEVOX speech replaced'))
    const stopped = this.#playback.stop()
    const active = new AbortController()
    this.#active = active
    const forwardAbort = (): void => active.abort(abortReason(request.signal!))
    if (request.signal?.aborted) forwardAbort()
    else request.signal?.addEventListener('abort', forwardAbort, { once: true })

    try {
      await stopped
      active.signal.throwIfAborted()
      const wav = await this.#client.synthesize({ ...request, signal: active.signal })
      await this.#playback.play(wav, active.signal)
    }
    finally {
      request.signal?.removeEventListener('abort', forwardAbort)
      if (this.#active === active) this.#active = undefined
    }
  }

  async cancel(): Promise<void> {
    this.#active?.abort(new Error('VOICEVOX speech cancelled'))
    this.#active = undefined
    await this.#playback.stop()
  }

  async dispose(): Promise<void> {
    await this.cancel()
  }
}
