import { VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm'
import type { VRM } from '@pixiv/three-vrm'
import {
  AmbientLight,
  Box3,
  Clock,
  DirectionalLight,
  PerspectiveCamera,
  Raycaster,
  Scene,
  Vector2,
  Vector3,
  WebGLRenderer,
} from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
import type { SoulDockPhase } from '../../core/phases'
import type { AvatarMetadata, AvatarMount } from '../avatar-host'
import {
  createVrmInteractionColliders,
  getVrmInteractionTargetFromObjectName,
  type VrmInteractionColliderSet,
  type VrmInteractionTarget,
} from '../upstream/airi/vrm-interaction'

export const MAX_VRM_FILE_BYTES = 200 * 1024 * 1024

export interface LocalVrmFileDescriptor {
  readonly name: string
  readonly size: number
}

export function validateLocalVrmFile(file: LocalVrmFileDescriptor): void {
  if (!file.name.toLocaleLowerCase().endsWith('.vrm')) throw new Error('请选择 .vrm 模型文件')
  if (file.size <= 0) throw new Error('所选 VRM 文件为空')
  if (file.size > MAX_VRM_FILE_BYTES) throw new Error('VRM 文件超过 200 MB 限制')
}

function displayValue(value: unknown): string | undefined {
  if (typeof value === 'string' && value.trim()) return value.trim()
  return undefined
}

function metadataFor(vrm: VRM, fallbackName: string): AvatarMetadata {
  const meta = vrm.meta
  if (meta.metaVersion === '1') {
    const rows = [
      { label: '作者', value: meta.authors.filter(Boolean).join('、') || '模型未声明' },
      { label: '版权', value: displayValue(meta.copyrightInformation) ?? '模型未声明' },
      { label: '许可', value: displayValue(meta.licenseUrl) ?? '模型未声明' },
      { label: '使用者范围', value: displayValue(meta.avatarPermission) ?? '模型未声明' },
      { label: '商业使用', value: displayValue(meta.commercialUsage) ?? '模型未声明' },
    ]
    return { title: displayValue(meta.name) ?? fallbackName, rows }
  }

  const rows = [
    { label: '作者', value: displayValue(meta.author) ?? '模型未声明' },
    { label: '许可', value: displayValue(meta.licenseName) ?? '模型未声明' },
    { label: '许可链接', value: displayValue(meta.otherLicenseUrl) ?? '模型未声明' },
    { label: '使用者范围', value: displayValue(meta.allowedUserName) ?? '模型未声明' },
    { label: '商业使用', value: displayValue(meta.commercialUssageName) ?? '模型未声明' },
  ]
  return { title: displayValue(meta.title) ?? fallbackName, rows }
}

/**
 * Optional VRM renderer. SoulDock ships no avatar model: callers must provide
 * their own licensed local .vrm file. The adapter creates a short-lived blob
 * URL internally and never receives an arbitrary remote URL from the UI.
 */
export class UserVrmAdapter {
  readonly #renderer: WebGLRenderer
  readonly #scene = new Scene()
  readonly #camera = new PerspectiveCamera(28, 1, 0.1, 20)
  readonly #clock = new Clock()
  readonly #pickingRaycaster = new Raycaster()
  readonly #pickingPoint = new Vector2()
  readonly #resizeObserver: ResizeObserver
  #frame?: number
  #vrm?: VRM
  #interactionColliders?: VrmInteractionColliderSet
  #phase: SoulDockPhase = 'idle'
  #baseY = 0

  constructor(container: HTMLElement) {
    this.#renderer = new WebGLRenderer({ alpha: true, antialias: true, premultipliedAlpha: true })
    this.#renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
    this.#renderer.setClearAlpha(0)
    container.replaceChildren(this.#renderer.domElement)
    this.#camera.position.set(0, 1.35, 3.2)
    this.#scene.add(new AmbientLight(0xffffff, 2.2))
    const key = new DirectionalLight(0xffffff, 2.6)
    key.position.set(1.5, 2.5, 3)
    this.#scene.add(key)

    this.#resizeObserver = new ResizeObserver(() => this.#resize(container))
    this.#resizeObserver.observe(container)
    this.#resize(container)
    this.#render()
  }

  async loadFile(file: File): Promise<AvatarMetadata> {
    validateLocalVrmFile(file)
    const modelUrl = URL.createObjectURL(file)
    try {
      return await this.#load(modelUrl, file.name.replace(/\.vrm$/i, ''))
    }
    finally {
      URL.revokeObjectURL(modelUrl)
    }
  }

  async #load(modelUrl: string, fallbackName: string): Promise<AvatarMetadata> {
    const loader = new GLTFLoader()
    loader.register(parser => new VRMLoaderPlugin(parser))
    const gltf = await loader.loadAsync(modelUrl)
    const vrm = gltf.userData.vrm as VRM | undefined
    if (!vrm) throw new Error('The selected file does not contain a VRM model')
    if (this.#vrm) {
      this.#interactionColliders?.dispose()
      this.#interactionColliders = undefined
      this.#scene.remove(this.#vrm.scene)
      VRMUtils.deepDispose(this.#vrm.scene)
    }
    VRMUtils.removeUnnecessaryVertices(vrm.scene)
    VRMUtils.removeUnnecessaryJoints(vrm.scene)
    VRMUtils.rotateVRM0(vrm)
    this.#vrm = vrm
    this.#scene.add(vrm.scene)
    vrm.scene.updateMatrixWorld(true)
    const bounds = new Box3().setFromObject(vrm.scene)
    const size = bounds.getSize(new Vector3())
    const center = bounds.getCenter(new Vector3())
    const height = Math.max(size.y, 0.5)
    this.#camera.position.set(center.x, center.y + height * 0.04, center.z + Math.max(height * 1.35, 1.8))
    this.#camera.near = Math.max(height / 100, 0.01)
    this.#camera.far = Math.max(height * 20, 20)
    this.#camera.lookAt(center)
    this.#camera.updateProjectionMatrix()
    this.#baseY = vrm.scene.position.y
    this.#interactionColliders = createVrmInteractionColliders(vrm)
    vrm.scene.updateMatrixWorld(true)
    return metadataFor(vrm, fallbackName)
  }

  setPhase(phase: SoulDockPhase): void {
    this.#phase = phase
  }

  hitTest(clientX: number, clientY: number): VrmInteractionTarget | null {
    if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return null
    const colliders = this.#interactionColliders?.colliders
    if (!this.#vrm || !colliders?.length) return null

    const rect = this.#renderer.domElement.getBoundingClientRect()
    if (rect.width <= 0 || rect.height <= 0) return null
    if (clientX < rect.left || clientX > rect.right || clientY < rect.top || clientY > rect.bottom) return null

    this.#pickingPoint.x = ((clientX - rect.left) / rect.width) * 2 - 1
    this.#pickingPoint.y = -((clientY - rect.top) / rect.height) * 2 + 1
    this.#camera.updateMatrixWorld()
    this.#vrm.scene.updateMatrixWorld(true)
    this.#pickingRaycaster.setFromCamera(this.#pickingPoint, this.#camera)

    const intersections = this.#pickingRaycaster.intersectObjects([...colliders])
    return getVrmInteractionTargetFromObjectName(intersections[0]?.object.name ?? '')
  }

  dispose(): void {
    if (this.#frame !== undefined) cancelAnimationFrame(this.#frame)
    this.#resizeObserver.disconnect()
    this.#interactionColliders?.dispose()
    this.#interactionColliders = undefined
    if (this.#vrm) VRMUtils.deepDispose(this.#vrm.scene)
    this.#renderer.dispose()
    this.#renderer.domElement.remove()
  }

  #resize(container: HTMLElement): void {
    const width = Math.max(container.clientWidth, 1)
    const height = Math.max(container.clientHeight, 1)
    this.#renderer.setSize(width, height, false)
    this.#camera.aspect = width / height
    this.#camera.updateProjectionMatrix()
  }

  #render = (): void => {
    const delta = Math.min(this.#clock.getDelta(), 0.1)
    if (this.#vrm) {
      this.#vrm.update(delta)
      const amplitude = this.#phase === 'celebrating' ? 0.045 : this.#phase === 'concerned' ? 0.008 : 0.018
      this.#vrm.scene.position.y = this.#baseY + Math.sin(this.#clock.elapsedTime * 2.4) * amplitude
      const expressions = this.#vrm.expressionManager
      expressions?.setValue('happy', this.#phase === 'celebrating' ? 0.75 : 0)
      expressions?.setValue('sad', this.#phase === 'concerned' ? 0.6 : 0)
      expressions?.setValue('surprised', this.#phase === 'approval' ? 0.45 : 0)
    }
    this.#renderer.render(this.#scene, this.#camera)
    this.#frame = requestAnimationFrame(this.#render)
  }
}

export async function createLocalVrmAvatar(container: HTMLElement, file: File): Promise<AvatarMount> {
  const adapter = new UserVrmAdapter(container)
  try {
    const metadata = await adapter.loadFile(file)
    return {
      controller: {
        kind: 'vrm',
        hitTest: (clientX, clientY) => adapter.hitTest(clientX, clientY),
        setPhase: phase => adapter.setPhase(phase),
        destroy: () => adapter.dispose(),
      },
      metadata,
    }
  }
  catch (error) {
    adapter.dispose()
    throw error
  }
}
