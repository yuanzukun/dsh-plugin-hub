import 'pixi.js/unsafe-eval'
import { Application, Assets, AnimatedSprite, Container, Texture } from 'pixi.js'
import type { AvatarAction, AvatarMount } from './avatar-host'

/**
 * The public Jingling avatar is a local frame-animation loop: the character
 * frames under assets/whalegirl/ (idle / walk / sleep / click, four aligned
 * frames each) are the authorized Jingling image set. The frames are
 * pre-aligned so that the character's vertical axis and baseline are fixed;
 * DSH phase updates and local companion actions select which loop plays.
 *
 * The packaged sidecar loads the renderer over file:// (the portable build
 * unpacks to a %TEMP% directory), where fetch() cannot read file:// URLs and
 * img elements cannot reach arbitrary paths, so the trusted main process
 * reads the bundled frames and hands them back as data URLs.
 */
Assets.setPreferences({ preferWorkers: false })
const STABLE_DISPLAY_SIZE = 304

const ACTION_FRAMES: Record<AvatarAction, readonly string[]> = {
  idle: ['idle_0.png', 'idle_1.png', 'idle_2.png', 'idle_3.png'],
  walk: ['walk_0.png', 'walk_1.png', 'walk_2.png', 'walk_3.png'],
  sleep: ['sleep_0.png', 'sleep_1.png', 'sleep_2.png', 'sleep_3.png'],
  click: ['click_0.png', 'click_1.png', 'click_2.png', 'click_3.png'],
}

const ACTION_SPEED: Record<AvatarAction, number> = {
  idle: 0.05,
  walk: 0.05,
  sleep: 0.05,
  click: 0.05,
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Jingling avatar initialization timed out')), timeoutMs)
    void promise.then(
      value => {
        clearTimeout(timer)
        resolve(value)
      },
      error => {
        clearTimeout(timer)
        reject(error)
      },
    )
  })
}

export async function createSpriteAvatar(container: HTMLElement): Promise<AvatarMount> {
  const application = new Application()
  try {
    await withTimeout(application.init({
      preference: 'webgl',
      resizeTo: container,
      backgroundAlpha: 0,
      antialias: true,
      autoDensity: true,
      resolution: Math.min(devicePixelRatio, 2),
    }), 8_000)
  }
  catch (error) {
    application.destroy(true)
    throw error
  }
  container.replaceChildren(application.canvas)

  const groupTextures: Record<AvatarAction, Texture[]> = {
    idle: [], walk: [], sleep: [], click: [],
  }
  try {
      await withTimeout((async () => {
      const frames = await window.soulDockSidecar.readAvatarFrames()
      if (!frames) throw new Error('桌宠帧资源不可用：主进程未返回鲸灵动画帧')
      const missing = Object.values(ACTION_FRAMES).flat().filter(name => !frames[name])
      if (missing.length > 0) throw new Error(`桌宠帧资源不完整：缺少 ${missing.join(', ')}`)
      await Promise.all(Object.entries(ACTION_FRAMES).map(async ([action, names]) => {
        groupTextures[action as AvatarAction] = await Promise.all(
          names.map(name => Assets.load<Texture>(frames[name]!)),
        )
      }))
    })(), 12_000)
  }
  catch (error) {
    application.destroy(true)
    throw error
  }

  const root = new Container()
  const animated = new AnimatedSprite(groupTextures.idle)
  animated.anchor.set(0.5, 1)

  function applyScale(): void {
    const texture = animated.texture
    const size = Math.max(1, texture.width, texture.height)
    animated.scale.set(STABLE_DISPLAY_SIZE / size)
  }

  let activeAction: AvatarAction = 'idle'
  function playAction(action: AvatarAction): void {
    activeAction = action
    animated.textures = groupTextures[action]
    animated.animationSpeed = ACTION_SPEED[action]
    animated.loop = action !== 'click'
    animated.onComplete = action === 'click'
      ? () => { if (activeAction === 'click') playAction('idle') }
      : undefined
    animated.gotoAndPlay(0)
    applyScale()
  }

  root.addChild(animated)
  application.stage.addChild(root)
  playAction('idle')

  function layout(): void {
    root.x = application.screen.width / 2
    root.y = application.screen.height - 15
  }

  function hitTest(clientX: number, clientY: number): string | null {
    if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return null
    const rect = application.canvas.getBoundingClientRect()
    if (rect.width <= 0 || rect.height <= 0) return null
    if (clientX < rect.left || clientX > rect.right || clientY < rect.top || clientY > rect.bottom) return null

    // Pixi's world coordinates use logical screen pixels even when autoDensity
    // gives the backing canvas a higher device-pixel resolution.
    const x = (clientX - rect.left) * application.screen.width / rect.width
    const y = (clientY - rect.top) * application.screen.height / rect.height
    const bounds = animated.getBounds()
    if (!bounds.containsPoint(x, y)) return null
    const relativeX = (x - bounds.x) / bounds.width
    const relativeY = (y - bounds.y) / bounds.height
    if (relativeY < 0.38) return 'head'
    // The lower-right silhouette is treated as the tail area for the local
    // companion reaction table; the frames themselves remain unchanged.
    if (relativeY > 0.56 && relativeX > 0.54) return 'tail'
    return relativeY > 0.73 ? 'lower' : 'body'
  }

  layout()
  application.renderer.on('resize', layout)

  return {
    controller: {
      kind: 'sprite',
      hitTest,
      // DSH phase updates select which loop is live via AvatarHost.setAction
      // (walk while moving, click reactions, sleep at quiet night); phases
      // themselves never pretend the character is asleep or working.
      setPhase: () => undefined,
      setAction: (action) => playAction(action ?? 'idle'),
      destroy: () => {
        application.renderer.off('resize', layout)
        animated.destroy()
        root.destroy({ children: true })
        application.destroy(true)
      },
    },
  }
}