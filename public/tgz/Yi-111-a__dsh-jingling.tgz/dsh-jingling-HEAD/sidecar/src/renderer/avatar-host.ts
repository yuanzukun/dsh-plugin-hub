import type { SoulDockPhase } from '../core/phases'

export type AvatarKind = 'sprite' | 'vrm' | 'live2d'
export const AVATAR_ACTIONS = ['idle', 'click', 'walk', 'sleep'] as const
export type AvatarAction = (typeof AVATAR_ACTIONS)[number]

export interface AvatarController {
  readonly kind: AvatarKind
  /** Returns the renderer-specific region at a viewport client coordinate. */
  readonly hitTest?: (clientX: number, clientY: number) => string | null
  setPhase: (phase: SoulDockPhase) => void
  /** Optional local action override for renderers that own frame animation. */
  readonly setAction?: (action: AvatarAction | undefined) => void
  destroy: () => void | Promise<void>
}

export interface AvatarInteraction {
  readonly kind: AvatarKind
  readonly target: string
}

export interface AvatarMetadata {
  readonly title: string
  readonly rows: ReadonlyArray<{ label: string; value: string }>
}

export interface AvatarMount {
  readonly controller: AvatarController
  readonly metadata?: AvatarMetadata
}

export type AvatarFactory = (container: HTMLElement) => Promise<AvatarMount>

export interface AvatarLayer {
  readonly container: HTMLElement
  show: () => void
  remove: () => void
}

export interface AvatarStageDriver {
  createHiddenLayer: () => AvatarLayer
}

export interface AvatarSwitchResult {
  readonly applied: boolean
  readonly metadata?: AvatarMetadata
}

export function createBrowserAvatarStage(stage: HTMLElement): AvatarStageDriver {
  return {
    createHiddenLayer: () => {
      const container = document.createElement('div')
      container.className = 'avatar-layer avatar-layer--staging'
      container.setAttribute('aria-hidden', 'true')
      stage.appendChild(container)
      return {
        container,
        show: () => {
          container.classList.remove('avatar-layer--staging')
          container.classList.add('avatar-layer--active')
          container.removeAttribute('aria-hidden')
        },
        remove: () => container.remove(),
      }
    },
  }
}

/**
 * Owns the active renderer and applies replacements transactionally. A new
 * avatar finishes loading in a hidden layer; only the latest successful load
 * is allowed to replace the currently visible controller.
 */
export class AvatarHost {
  readonly #driver: AvatarStageDriver
  #active?: { layer: AvatarLayer; controller: AvatarController }
  #generation = 0
  #phase: SoulDockPhase = 'idle'
  #action: AvatarAction | undefined
  #destroyed = false

  constructor(stage: HTMLElement, driver: AvatarStageDriver = createBrowserAvatarStage(stage)) {
    this.#driver = driver
  }

  get activeKind(): AvatarController['kind'] | undefined {
    return this.#active?.controller.kind
  }

  setPhase(phase: SoulDockPhase): void {
    this.#phase = phase
    this.#active?.controller.setPhase(phase)
  }

  /**
   * Keeps a transient, local animation (click / walk / sleep) separate from
   * the durable DSH phase. Renderers without action support simply ignore it.
   */
  setAction(action: AvatarAction | undefined): void {
    this.#action = action
    this.#active?.controller.setAction?.(action)
  }

  /** Delegates pointer picking to whichever renderer is currently visible. */
  hitTest(clientX: number, clientY: number): AvatarInteraction | null {
    if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return null
    const controller = this.#active?.controller
    if (!controller?.hitTest) return null
    const target = controller.hitTest(clientX, clientY)
    return target ? { kind: controller.kind, target } : null
  }

  async switchTo(factory: AvatarFactory): Promise<AvatarSwitchResult> {
    if (this.#destroyed) throw new Error('AvatarHost is already destroyed')
    const generation = ++this.#generation
    const layer = this.#driver.createHiddenLayer()
    let mount: AvatarMount

    try {
      mount = await factory(layer.container)
    }
    catch (error) {
      layer.remove()
      if (generation !== this.#generation) return { applied: false }
      throw error
    }

    if (this.#destroyed || generation !== this.#generation) {
      await mount.controller.destroy()
      layer.remove()
      return { applied: false }
    }

    mount.controller.setPhase(this.#phase)
    mount.controller.setAction?.(this.#action)
    const previous = this.#active
    this.#active = { layer, controller: mount.controller }
    layer.show()

    if (previous) {
      previous.layer.remove()
      await previous.controller.destroy()
    }

    return { applied: true, metadata: mount.metadata }
  }

  async destroy(): Promise<void> {
    if (this.#destroyed) return
    this.#destroyed = true
    this.#generation += 1
    const active = this.#active
    this.#active = undefined
    if (active) {
      active.layer.remove()
      await active.controller.destroy()
    }
  }
}
