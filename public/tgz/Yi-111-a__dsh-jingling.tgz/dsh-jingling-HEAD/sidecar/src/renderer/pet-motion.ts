/**
 * Pure, bounded desktop-pet motion helpers.
 *
 * The renderer owns pointer capture and animation frames. This module only
 * turns injected measurements into next state, making drag, flick, and walk
 * behavior testable without DOM or Electron APIs.
 */

export type PetMotionMode = 'idle' | 'dragging' | 'flicking' | 'walking'

export interface PetPoint {
  readonly x: number
  readonly y: number
}

export interface PetSize {
  readonly width: number
  readonly height: number
}

export interface PetViewport {
  readonly width: number
  readonly height: number
}

export interface PetMotionState {
  readonly position: PetPoint
  /** Velocity is expressed in CSS pixels per second. */
  readonly velocity: PetPoint
  readonly mode: PetMotionMode
  readonly walkTarget?: PetPoint
}

export interface PetMotionOptions {
  /** Disables autonomous travel and inertial throw effects. User dragging remains available. */
  readonly reducedMotion?: boolean
  readonly edgePaddingPx?: number
  readonly maxFlickSpeedPxPerSecond?: number
  readonly flickDecelerationPxPerSecondSquared?: number
  readonly walkSpeedPxPerSecond?: number
  readonly stopSpeedPxPerSecond?: number
  /** Large elapsed values are capped so a stalled frame cannot launch the pet. */
  readonly maxFrameMs?: number
}

export interface PetDragInput {
  readonly origin: PetPoint
  readonly pointerStart: PetPoint
  readonly pointerCurrent: PetPoint
  readonly size: PetSize
  readonly viewport: PetViewport
  readonly options?: PetMotionOptions
}

export interface PetFlickInput {
  readonly position: PetPoint
  readonly releaseVelocity: PetPoint
  readonly size: PetSize
  readonly viewport: PetViewport
  readonly options?: PetMotionOptions
}

export interface PetWalkInput {
  readonly position: PetPoint
  readonly target: PetPoint
  readonly size: PetSize
  readonly viewport: PetViewport
  readonly options?: PetMotionOptions
}

export interface PetMotionStepInput {
  readonly state: PetMotionState
  readonly elapsedMs: number
  readonly size: PetSize
  readonly viewport: PetViewport
  readonly options?: PetMotionOptions
}

export const PET_MOTION_DEFAULTS: Required<PetMotionOptions> = {
  reducedMotion: false,
  edgePaddingPx: 0,
  maxFlickSpeedPxPerSecond: 920,
  flickDecelerationPxPerSecondSquared: 1_700,
  walkSpeedPxPerSecond: 165,
  stopSpeedPxPerSecond: 18,
  maxFrameMs: 64,
}

export function createPetMotionState(
  position: PetPoint,
  size: PetSize,
  viewport: PetViewport,
  options?: PetMotionOptions,
): PetMotionState {
  return {
    position: clampPetPosition(position, size, viewport, options),
    velocity: { x: 0, y: 0 },
    mode: 'idle',
  }
}

/** Keeps the whole pet inside a finite viewport, including when it is larger than the viewport. */
export function clampPetPosition(
  position: PetPoint,
  size: PetSize,
  viewport: PetViewport,
  options?: Pick<PetMotionOptions, 'edgePaddingPx'>,
): PetPoint {
  const padding = nonNegative(options?.edgePaddingPx, PET_MOTION_DEFAULTS.edgePaddingPx)
  const xRange = axisRange(viewport.width, size.width, padding)
  const yRange = axisRange(viewport.height, size.height, padding)
  return {
    x: clamp(finite(position.x), xRange.minimum, xRange.maximum),
    y: clamp(finite(position.y), yRange.minimum, yRange.maximum),
  }
}

/** Applies direct, user-controlled dragging; drag movement is never animated. */
export function dragPet(input: PetDragInput): PetMotionState {
  const desired = {
    x: finite(input.origin.x) + finite(input.pointerCurrent.x) - finite(input.pointerStart.x),
    y: finite(input.origin.y) + finite(input.pointerCurrent.y) - finite(input.pointerStart.y),
  }
  return {
    position: clampPetPosition(desired, input.size, input.viewport, input.options),
    velocity: { x: 0, y: 0 },
    mode: 'dragging',
  }
}

/** Starts a bounded inertia motion after a flick. Reduced-motion mode ends it immediately. */
export function beginPetFlick(input: PetFlickInput): PetMotionState {
  const options = resolveOptions(input.options)
  const position = clampPetPosition(input.position, input.size, input.viewport, options)
  if (options.reducedMotion) return idleAt(position)

  const velocity = capVector(input.releaseVelocity, options.maxFlickSpeedPxPerSecond)
  return vectorLength(velocity) <= options.stopSpeedPxPerSecond
    ? idleAt(position)
    : { position, velocity, mode: 'flicking' }
}

/** Starts an automatic walk toward a clamped point, unless reduced motion is enabled. */
export function beginPetWalk(input: PetWalkInput): PetMotionState {
  const options = resolveOptions(input.options)
  const position = clampPetPosition(input.position, input.size, input.viewport, options)
  const target = clampPetPosition(input.target, input.size, input.viewport, options)
  if (options.reducedMotion || options.walkSpeedPxPerSecond === 0 || distance(position, target) === 0) return idleAt(position)
  return { position, velocity: { x: 0, y: 0 }, mode: 'walking', walkTarget: target }
}

/** Stops any autonomous motion while retaining a viewport-safe position. */
export function stopPetMotion(
  position: PetPoint,
  size: PetSize,
  viewport: PetViewport,
  options?: PetMotionOptions,
): PetMotionState {
  return idleAt(clampPetPosition(position, size, viewport, options))
}

/**
 * Steps a flick or walk by caller-provided time. The returned state is always
 * bounded; wall collisions stop the relevant axis instead of bouncing.
 */
export function stepPetMotion(input: PetMotionStepInput): PetMotionState {
  const options = resolveOptions(input.options)
  const position = clampPetPosition(input.state.position, input.size, input.viewport, options)
  if (options.reducedMotion) return idleAt(position)

  const elapsedMs = clamp(finite(input.elapsedMs), 0, options.maxFrameMs)
  const seconds = elapsedMs / 1_000
  if (input.state.mode === 'flicking') {
    return stepFlick(position, input.state.velocity, seconds, input.size, input.viewport, options)
  }
  if (input.state.mode === 'walking') {
    return stepWalk(position, input.state.walkTarget, seconds, input.size, input.viewport, options)
  }
  if (input.state.mode === 'dragging') {
    return { position, velocity: { x: 0, y: 0 }, mode: 'dragging' }
  }
  return idleAt(position)
}

function stepFlick(
  position: PetPoint,
  sourceVelocity: PetPoint,
  seconds: number,
  size: PetSize,
  viewport: PetViewport,
  options: Required<PetMotionOptions>,
): PetMotionState {
  const velocity = capVector(sourceVelocity, options.maxFlickSpeedPxPerSecond)
  const desired = {
    x: position.x + velocity.x * seconds,
    y: position.y + velocity.y * seconds,
  }
  const nextPosition = clampPetPosition(desired, size, viewport, options)
  const hitX = nextPosition.x !== desired.x
  const hitY = nextPosition.y !== desired.y
  const deceleration = options.flickDecelerationPxPerSecondSquared * seconds
  const nextVelocity = {
    x: hitX ? 0 : decelerate(velocity.x, deceleration),
    y: hitY ? 0 : decelerate(velocity.y, deceleration),
  }
  return vectorLength(nextVelocity) <= options.stopSpeedPxPerSecond
    ? idleAt(nextPosition)
    : { position: nextPosition, velocity: nextVelocity, mode: 'flicking' }
}

function stepWalk(
  position: PetPoint,
  target: PetPoint | undefined,
  seconds: number,
  size: PetSize,
  viewport: PetViewport,
  options: Required<PetMotionOptions>,
): PetMotionState {
  if (!target) return idleAt(position)
  const safeTarget = clampPetPosition(target, size, viewport, options)
  const remaining = distance(position, safeTarget)
  if (remaining === 0 || seconds === 0) {
    return remaining === 0
      ? idleAt(safeTarget)
      : { position, velocity: { x: 0, y: 0 }, mode: 'walking', walkTarget: safeTarget }
  }
  // A caller can deliberately set walk speed to zero. Treat that as a safe
  // stop rather than keeping a perpetual zero-velocity animation alive.
  if (options.walkSpeedPxPerSecond === 0) return idleAt(position)

  const travel = Math.min(remaining, options.walkSpeedPxPerSecond * seconds)
  const unitX = (safeTarget.x - position.x) / remaining
  const unitY = (safeTarget.y - position.y) / remaining
  const nextPosition = clampPetPosition({
    x: position.x + unitX * travel,
    y: position.y + unitY * travel,
  }, size, viewport, options)

  if (travel >= remaining || distance(nextPosition, safeTarget) < 0.001) return idleAt(safeTarget)
  return {
    position: nextPosition,
    velocity: { x: unitX * options.walkSpeedPxPerSecond, y: unitY * options.walkSpeedPxPerSecond },
    mode: 'walking',
    walkTarget: safeTarget,
  }
}

function resolveOptions(options: PetMotionOptions | undefined): Required<PetMotionOptions> {
  return {
    reducedMotion: options?.reducedMotion === true,
    edgePaddingPx: nonNegative(options?.edgePaddingPx, PET_MOTION_DEFAULTS.edgePaddingPx),
    maxFlickSpeedPxPerSecond: nonNegative(options?.maxFlickSpeedPxPerSecond, PET_MOTION_DEFAULTS.maxFlickSpeedPxPerSecond),
    flickDecelerationPxPerSecondSquared: nonNegative(
      options?.flickDecelerationPxPerSecondSquared,
      PET_MOTION_DEFAULTS.flickDecelerationPxPerSecondSquared,
    ),
    walkSpeedPxPerSecond: nonNegative(options?.walkSpeedPxPerSecond, PET_MOTION_DEFAULTS.walkSpeedPxPerSecond),
    stopSpeedPxPerSecond: nonNegative(options?.stopSpeedPxPerSecond, PET_MOTION_DEFAULTS.stopSpeedPxPerSecond),
    maxFrameMs: nonNegative(options?.maxFrameMs, PET_MOTION_DEFAULTS.maxFrameMs),
  }
}

function axisRange(viewportSize: number, petSize: number, requestedPadding: number): { minimum: number; maximum: number } {
  const available = Math.max(0, finite(viewportSize) - Math.max(0, finite(petSize)))
  const padding = Math.min(Math.max(0, requestedPadding), available / 2)
  return { minimum: padding, maximum: available - padding }
}

function capVector(value: PetPoint, maximumLength: number): PetPoint {
  const vector = { x: finite(value.x), y: finite(value.y) }
  const length = vectorLength(vector)
  if (length === 0 || length <= maximumLength) return vector
  const multiplier = maximumLength / length
  return { x: vector.x * multiplier, y: vector.y * multiplier }
}

function decelerate(value: number, amount: number): number {
  if (value > 0) return Math.max(0, value - amount)
  if (value < 0) return Math.min(0, value + amount)
  return 0
}

function idleAt(position: PetPoint): PetMotionState {
  return { position, velocity: { x: 0, y: 0 }, mode: 'idle' }
}

function distance(a: PetPoint, b: PetPoint): number {
  return Math.hypot(a.x - b.x, a.y - b.y)
}

function vectorLength(value: PetPoint): number {
  return Math.hypot(value.x, value.y)
}

function finite(value: number): number {
  return Number.isFinite(value) ? value : 0
}

function nonNegative(value: number | undefined, fallback: number): number {
  return value !== undefined && Number.isFinite(value) ? Math.max(0, value) : fallback
}

function clamp(value: number, minimum: number, maximum: number): number {
  return Math.min(Math.max(value, minimum), Math.max(minimum, maximum))
}
