import type { ChatEvent, ChatMessage, ChatOpen, ChatPoll } from './protocol'

export interface SidecarChatPort {
  open(signal?: AbortSignal): Promise<ChatOpen>
  send(payload: { chatId: string; clientMessageId: string; text: string; clientTimeZone?: string }, signal?: AbortSignal): Promise<{ accepted: true; clientMessageId: string }>
  poll(payload: { chatId: string; afterSequence: number; timeoutMilliseconds: number }, signal?: AbortSignal): Promise<ChatPoll>
  cancel(payload: { chatId: string }, signal?: AbortSignal): Promise<{ accepted: true }>
  close(payload: { chatId: string }, signal?: AbortSignal): Promise<{ closed: true }>
}

export type ChatUiStatus = 'closed' | 'opening' | 'idle' | 'running' | 'error'

export interface ChatUiState {
  status: ChatUiStatus
  persona: { id: string; name: string }
  messages: ChatMessage[]
  partial: string
  hasOlder: boolean
  inputCodePoints: number
  error?: string
}

export type ChatStateListener = (state: ChatUiState, event?: ChatEvent) => void

const CLOSED_STATE: ChatUiState = {
  status: 'closed',
  // Keep the opaque protocol identifier for compatibility, while the public
  // companion label is Jingling.
  persona: { id: 'souldock', name: '鲸灵' },
  messages: [],
  partial: '',
  hasOlder: false,
  inputCodePoints: 8000,
}

function codePoints(value: string): number {
  return [...value].length
}

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function browserRandomId(): string {
  return globalThis.crypto.randomUUID()
}

export class SidecarChatController {
  readonly #port: SidecarChatPort
  readonly #listeners = new Set<ChatStateListener>()
  readonly #id: () => string
  #state: ChatUiState = structuredClone(CLOSED_STATE)
  #chatId?: string
  #sequence = 0
  #pollController?: AbortController
  #generation = 0

  constructor(port: SidecarChatPort, id: () => string = browserRandomId) {
    this.#port = port
    this.#id = id
  }

  get state(): ChatUiState {
    return structuredClone(this.#state)
  }

  subscribe(listener: ChatStateListener): () => void {
    this.#listeners.add(listener)
    listener(this.state)
    return () => this.#listeners.delete(listener)
  }

  async open(): Promise<void> {
    if (this.#state.status !== 'closed') return
    const generation = ++this.#generation
    this.#publish({ ...this.#state, status: 'opening', error: undefined })
    try {
      const opened = await this.#port.open()
      if (generation !== this.#generation) return
      this.#chatId = opened.chatId
      this.#sequence = opened.sequence
      this.#publish({
        status: opened.status,
        persona: opened.persona,
        messages: opened.messages,
        partial: opened.partial?.text ?? '',
        hasOlder: opened.hasOlder,
        inputCodePoints: opened.limits.inputCodePoints,
      })
      const controller = new AbortController()
      this.#pollController = controller
      void this.#pollLoop(generation, opened.chatId, controller.signal)
    }
    catch (error) {
      if (generation !== this.#generation) return
      this.#publish({ ...this.#state, status: 'error', error: errorText(error) })
    }
  }

  async close(): Promise<void> {
    const chatId = this.#chatId
    this.#generation += 1
    this.#pollController?.abort(new Error('Jingling chat closed'))
    this.#pollController = undefined
    this.#chatId = undefined
    this.#sequence = 0
    this.#publish({ ...CLOSED_STATE, persona: this.#state.persona, messages: this.#state.messages })
    if (chatId) {
      try { await this.#port.close({ chatId }) }
      catch { /* Closing is local-first; a stale server handle expires independently. */ }
    }
  }

  async send(rawText: string, clientTimeZone?: string): Promise<void> {
    const chatId = this.#chatId
    if (!chatId) throw new Error('Jingling chat is not open')
    const text = rawText.trim()
    if (!text) throw new Error('Message is empty')
    if (codePoints(text) > this.#state.inputCodePoints) {
      throw new Error(`Message exceeds ${this.#state.inputCodePoints} characters`)
    }
    if (text.startsWith('/')) throw new Error('Slash commands are unavailable in the desktop companion')

    const clientMessageId = `sidecar-${this.#id()}`
    const optimistic: ChatMessage = { id: clientMessageId, role: 'user', text, at: Date.now() }
    this.#publish({
      ...this.#state,
      status: 'running',
      error: undefined,
      messages: [...this.#state.messages, optimistic],
    })
    try {
      await this.#port.send({ chatId, clientMessageId, text, clientTimeZone })
    }
    catch (error) {
      this.#publish({
        ...this.#state,
        status: 'error',
        error: errorText(error),
        messages: this.#state.messages.filter(message => message.id !== clientMessageId),
      })
      throw error
    }
  }

  async cancel(): Promise<void> {
    if (!this.#chatId) return
    await this.#port.cancel({ chatId: this.#chatId })
  }

  #publish(state: ChatUiState, event?: ChatEvent): void {
    this.#state = structuredClone(state)
    for (const listener of this.#listeners) listener(this.state, event)
  }

  #applyEvent(event: ChatEvent): void {
    if (event.type === 'user-message') {
      const existing = this.#state.messages.some(message => (
        message.id === event.messageId || (event.clientMessageId && message.id === event.clientMessageId)
      ))
      const messages = existing
        ? this.#state.messages.map(message => message.id === event.clientMessageId
          ? { id: event.messageId, role: 'user' as const, text: event.text, at: event.at }
          : message)
        : [...this.#state.messages, { id: event.messageId, role: 'user', text: event.text, at: event.at } as ChatMessage]
      this.#publish({ ...this.#state, messages }, event)
      return
    }
    if (event.type === 'assistant-delta') {
      this.#publish({ ...this.#state, status: 'running', partial: `${this.#state.partial}${event.delta}` }, event)
      return
    }
    if (event.type === 'assistant-final') {
      const withoutSame = this.#state.messages.filter(message => message.id !== event.messageId)
      this.#publish({
        ...this.#state,
        status: 'idle',
        partial: '',
        messages: [...withoutSame, { id: event.messageId, role: 'assistant', text: event.text, at: event.at }],
      }, event)
      return
    }
    if (event.type === 'status') {
      const retainedError = event.status === 'idle' && this.#state.status === 'error'
        ? this.#state.error
        : undefined
      this.#publish({ ...this.#state, status: event.status, error: retainedError }, event)
      return
    }
    this.#publish({ ...this.#state, status: 'error', error: event.message, partial: '' }, event)
  }

  async #pollLoop(generation: number, chatId: string, signal: AbortSignal): Promise<void> {
    while (!signal.aborted && generation === this.#generation) {
      try {
        const result = await this.#port.poll({ chatId, afterSequence: this.#sequence, timeoutMilliseconds: 20_000 }, signal)
        if (signal.aborted || generation !== this.#generation) return
        if (result.resetRequired) {
          this.#generation += 1
          this.#pollController = undefined
          this.#chatId = undefined
          this.#publish({ ...CLOSED_STATE, status: 'error', error: '聊天连接已刷新，请重新点击角色。' })
          return
        }
        for (const event of result.events) {
          if (event.sequence <= this.#sequence) continue
          this.#sequence = event.sequence
          this.#applyEvent(event)
        }
        this.#sequence = Math.max(this.#sequence, result.sequence)
      }
      catch (error) {
        if (signal.aborted || generation !== this.#generation) return
        this.#publish({ ...this.#state, status: 'error', error: errorText(error) })
        await new Promise(resolve => setTimeout(resolve, 1000))
      }
    }
  }
}
