import { randomUUID } from 'node:crypto'
import type { ZodType } from 'zod'
import {
  chatCancelSchema,
  chatCloseSchema,
  chatOpenSchema,
  chatPollSchema,
  chatSendSchema,
  sidecarPollSchema,
  sidecarStatusSchema,
  workspaceListSchema,
  workspaceTaskCancelSchema,
  workspaceTaskCloseSchema,
  workspaceTaskOpenSchema,
  workspaceTaskPollSchema,
  workspaceTaskSendSchema,
} from './protocol'
import type {
  ChatCancel,
  ChatClose,
  ChatOpen,
  ChatPoll,
  ChatSend,
  ClientRequestEnvelope,
  PollRequest,
  SidecarPoll,
  SidecarStatus,
  WorkspaceList,
  WorkspaceTaskCancel,
  WorkspaceTaskClose,
  WorkspaceTaskOpen,
  WorkspaceTaskPoll,
  WorkspaceTaskSend,
} from './protocol'

type FetchLike = typeof fetch

export interface DshSidecarClientOptions {
  baseUrl?: string
  fetch?: FetchLike
  rpcId?: () => string
  statusDeadlineMilliseconds?: number
  pollDeadlineBufferMilliseconds?: number
  chatDeadlineMilliseconds?: number
}

const LOOPBACK_HOSTS = new Set(['127.0.0.1', 'localhost', '::1', '[::1]'])

export function normalizeLoopbackBaseUrl(raw: string): URL {
  const parsed = new URL(raw)
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error('DSH sidecar endpoint must use HTTP or HTTPS')
  }
  if (!LOOPBACK_HOSTS.has(parsed.hostname.toLowerCase())) {
    throw new Error(`DSH sidecar endpoint must be loopback, received ${parsed.hostname}`)
  }
  if (parsed.username || parsed.password) {
    throw new Error('Credentials are not allowed inside the DSH base URL')
  }
  return new URL(parsed.origin)
}

function errorMessage(value: unknown, fallback: string): string {
  if (value && typeof value === 'object') {
    const candidate = value as Record<string, unknown>
    if (typeof candidate.message === 'string' && candidate.message) return candidate.message
    if (typeof candidate.error === 'string' && candidate.error) return candidate.error
    if (candidate.error && typeof candidate.error === 'object') {
      const nested = candidate.error as Record<string, unknown>
      if (typeof nested.message === 'string' && nested.message) return nested.message
    }
  }
  return fallback
}

function unwrapServerResponse<T>(raw: unknown, expectedRpcId: string, schema: ZodType<T>): T {
  if (!raw || typeof raw !== 'object') throw new Error('DSH returned a non-object RPC response')
  const response = raw as Record<string, unknown>
  if (response.type !== 'server-response') throw new Error('DSH returned the wrong RPC envelope type')
  if (response.rpcId !== expectedRpcId) throw new Error('DSH returned a mismatched rpcId')

  const outer = response.result
  if (!outer || typeof outer !== 'object') throw new Error('DSH RPC response is missing result')
  const outerResult = outer as Record<string, unknown>
  if (outerResult.ok !== true) throw new Error(errorMessage(outerResult, 'DSH rejected the sidecar RPC'))

  const inner = outerResult.value
  if (!inner || typeof inner !== 'object') throw new Error('DSH RPC response is missing the plugin result')
  const innerResult = inner as Record<string, unknown>
  if (innerResult.ok !== true) throw new Error(errorMessage(innerResult, 'Jingling rejected the sidecar RPC'))

  return schema.parse(innerResult.value)
}

export class DshSidecarClient {
  readonly #baseUrl: URL
  readonly #fetch: FetchLike
  readonly #rpcId: () => string
  readonly #statusDeadlineMilliseconds: number
  readonly #pollDeadlineBufferMilliseconds: number
  readonly #chatDeadlineMilliseconds: number

  constructor(options: DshSidecarClientOptions = {}) {
    this.#baseUrl = normalizeLoopbackBaseUrl(options.baseUrl ?? 'http://127.0.0.1:3080')
    this.#fetch = options.fetch ?? globalThis.fetch
    this.#rpcId = options.rpcId ?? randomUUID
    this.#statusDeadlineMilliseconds = positiveDeadline(
      options.statusDeadlineMilliseconds ?? 5_000,
      'statusDeadlineMilliseconds',
    )
    this.#pollDeadlineBufferMilliseconds = positiveDeadline(
      options.pollDeadlineBufferMilliseconds ?? 5_000,
      'pollDeadlineBufferMilliseconds',
    )
    this.#chatDeadlineMilliseconds = positiveDeadline(
      options.chatDeadlineMilliseconds ?? 10_000,
      'chatDeadlineMilliseconds',
    )
  }

  status(signal?: AbortSignal): Promise<SidecarStatus> {
    return this.#request(
      '/souldock/sidecar/status',
      'sidecar/status',
      {},
      sidecarStatusSchema,
      this.#statusDeadlineMilliseconds,
      signal,
    )
  }

  poll(payload: PollRequest, signal?: AbortSignal): Promise<SidecarPoll> {
    if (!Number.isInteger(payload.afterSequence) || payload.afterSequence < 0) {
      return Promise.reject(new Error('afterSequence must be a non-negative integer'))
    }
    if (!Number.isInteger(payload.timeoutMilliseconds) || payload.timeoutMilliseconds < 0 || payload.timeoutMilliseconds > 30_000) {
      return Promise.reject(new Error('timeoutMilliseconds must be an integer from 0 through 30000'))
    }
    return this.#request(
      '/souldock/sidecar/poll',
      'sidecar/poll',
      { ...payload },
      sidecarPollSchema,
      payload.timeoutMilliseconds + this.#pollDeadlineBufferMilliseconds,
      signal,
    )
  }

  chatOpen(signal?: AbortSignal): Promise<ChatOpen> {
    return this.#request('/souldock/chat/open', 'chat/open', {}, chatOpenSchema, this.#chatDeadlineMilliseconds, signal)
  }

  chatSend(
    payload: { chatId: string; clientMessageId: string; text: string; clientTimeZone?: string },
    signal?: AbortSignal,
  ): Promise<ChatSend> {
    return this.#request(
      '/souldock/chat/send',
      'chat/send',
      { ...payload },
      chatSendSchema,
      this.#chatDeadlineMilliseconds,
      signal,
    )
  }

  chatPoll(
    payload: { chatId: string; afterSequence: number; timeoutMilliseconds: number },
    signal?: AbortSignal,
  ): Promise<ChatPoll> {
    if (!Number.isInteger(payload.afterSequence) || payload.afterSequence < 0) {
      return Promise.reject(new Error('afterSequence must be a non-negative integer'))
    }
    if (!Number.isInteger(payload.timeoutMilliseconds) || payload.timeoutMilliseconds < 0 || payload.timeoutMilliseconds > 25_000) {
      return Promise.reject(new Error('timeoutMilliseconds must be an integer from 0 through 25000'))
    }
    return this.#request(
      '/souldock/chat/poll',
      'chat/poll',
      { ...payload },
      chatPollSchema,
      payload.timeoutMilliseconds + this.#pollDeadlineBufferMilliseconds,
      signal,
    )
  }

  chatCancel(payload: { chatId: string }, signal?: AbortSignal): Promise<ChatCancel> {
    return this.#request(
      '/souldock/chat/cancel',
      'chat/cancel',
      { ...payload },
      chatCancelSchema,
      this.#chatDeadlineMilliseconds,
      signal,
    )
  }

  chatClose(payload: { chatId: string }, signal?: AbortSignal): Promise<ChatClose> {
    return this.#request(
      '/souldock/chat/close',
      'chat/close',
      { ...payload },
      chatCloseSchema,
      this.#chatDeadlineMilliseconds,
      signal,
    )
  }

  workspaceList(signal?: AbortSignal): Promise<WorkspaceList> {
    return this.#request(
      '/souldock/workspace/list',
      'workspace/list',
      {},
      workspaceListSchema,
      this.#chatDeadlineMilliseconds,
      signal,
    )
  }

  workspaceTaskCreate(
    payload: { cwd: string; title?: string },
    signal?: AbortSignal,
  ): Promise<WorkspaceTaskOpen> {
    return this.#request(
      '/souldock/workspace/task/create',
      'workspace/task/create',
      { ...payload },
      workspaceTaskOpenSchema,
      this.#chatDeadlineMilliseconds,
      signal,
    )
  }

  workspaceTaskOpen(payload: { taskId: string }, signal?: AbortSignal): Promise<WorkspaceTaskOpen> {
    return this.#request(
      '/souldock/workspace/task/open',
      'workspace/task/open',
      { ...payload },
      workspaceTaskOpenSchema,
      this.#chatDeadlineMilliseconds,
      signal,
    )
  }

  workspaceTaskSend(
    payload: { taskId: string; clientMessageId: string; text: string; clientTimeZone?: string },
    signal?: AbortSignal,
  ): Promise<WorkspaceTaskSend> {
    return this.#request(
      '/souldock/workspace/task/send',
      'workspace/task/send',
      { ...payload },
      workspaceTaskSendSchema,
      this.#chatDeadlineMilliseconds,
      signal,
    )
  }

  workspaceTaskPoll(
    payload: { taskId: string; afterSequence: number; timeoutMilliseconds: number },
    signal?: AbortSignal,
  ): Promise<WorkspaceTaskPoll> {
    if (!Number.isInteger(payload.afterSequence) || payload.afterSequence < 0) {
      return Promise.reject(new Error('afterSequence must be a non-negative integer'))
    }
    if (!Number.isInteger(payload.timeoutMilliseconds) || payload.timeoutMilliseconds < 0 || payload.timeoutMilliseconds > 25_000) {
      return Promise.reject(new Error('timeoutMilliseconds must be an integer from 0 through 25000'))
    }
    return this.#request(
      '/souldock/workspace/task/poll',
      'workspace/task/poll',
      { ...payload },
      workspaceTaskPollSchema,
      payload.timeoutMilliseconds + this.#pollDeadlineBufferMilliseconds,
      signal,
    )
  }

  workspaceTaskCancel(payload: { taskId: string }, signal?: AbortSignal): Promise<WorkspaceTaskCancel> {
    return this.#request(
      '/souldock/workspace/task/cancel',
      'workspace/task/cancel',
      { ...payload },
      workspaceTaskCancelSchema,
      this.#chatDeadlineMilliseconds,
      signal,
    )
  }

  workspaceTaskClose(payload: { taskId: string }, signal?: AbortSignal): Promise<WorkspaceTaskClose> {
    return this.#request(
      '/souldock/workspace/task/close',
      'workspace/task/close',
      { ...payload },
      workspaceTaskCloseSchema,
      this.#chatDeadlineMilliseconds,
      signal,
    )
  }

  async #request<T>(
    pathname: string,
    method: ClientRequestEnvelope['method'],
    payload: Record<string, unknown>,
    schema: ZodType<T>,
    deadlineMilliseconds: number,
    signal?: AbortSignal,
  ): Promise<T> {
    const rpcId = this.#rpcId()
    const envelope: ClientRequestEnvelope = {
      type: 'client-request',
      rpcId,
      method,
      payload,
    }
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    }
    const request = deadlineSignal(signal, deadlineMilliseconds)
    try {
      const response = await this.#fetch(new URL(pathname, this.#baseUrl), {
        method: 'POST',
        headers,
        body: JSON.stringify(envelope),
        signal: request.signal,
      })
      if (!response.ok) {
        const snippet = (await response.text()).slice(0, 256)
        throw new Error(`DSH sidecar RPC failed with HTTP ${response.status}${snippet ? `: ${snippet}` : ''}`)
      }
      return unwrapServerResponse(await response.json(), rpcId, schema)
    }
    finally {
      request.dispose()
    }
  }
}

export const __testing = { unwrapServerResponse }

function positiveDeadline(value: number, name: string): number {
  if (!Number.isSafeInteger(value) || value <= 0 || value > 60_000) {
    throw new Error(`${name} must be an integer from 1 through 60000`)
  }
  return value
}

function deadlineSignal(parent: AbortSignal | undefined, milliseconds: number): {
  signal: AbortSignal
  dispose: () => void
} {
  const controller = new AbortController()
  const onParentAbort = (): void => controller.abort(parent?.reason ?? new Error('DSH sidecar request aborted'))
  if (parent?.aborted) onParentAbort()
  else parent?.addEventListener('abort', onParentAbort, { once: true })

  const timer = setTimeout(() => {
    controller.abort(new Error(`DSH sidecar request exceeded ${milliseconds} ms deadline`))
  }, milliseconds)

  return {
    signal: controller.signal,
    dispose: () => {
      clearTimeout(timer)
      parent?.removeEventListener('abort', onParentAbort)
    },
  }
}
