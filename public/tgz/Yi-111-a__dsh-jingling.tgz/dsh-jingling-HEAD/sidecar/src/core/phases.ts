export const SOULDOCK_PHASES = [
  'idle',
  'listening',
  'thinking',
  'working',
  'approval',
  'celebrating',
  'concerned',
] as const

export type SoulDockPhase = (typeof SOULDOCK_PHASES)[number]

export interface PhasePresentation {
  label: string
  hint: string
  color: number
  animationSpeed: number
  scale: number
}

export const PHASE_PRESENTATION: Record<SoulDockPhase, PhasePresentation> = {
  idle: {
    label: '待命',
    hint: '我在这里',
    color: 0x91a7ff,
    animationSpeed: 0.08,
    scale: 1,
  },
  listening: {
    label: '倾听',
    hint: '正在听你说',
    color: 0x75e6da,
    animationSpeed: 0.13,
    scale: 1.03,
  },
  thinking: {
    label: '思考',
    hint: '正在整理思路',
    color: 0xb986ff,
    animationSpeed: 0.16,
    scale: 0.98,
  },
  working: {
    label: '工作',
    hint: '正在处理任务',
    color: 0x66c8ff,
    animationSpeed: 0.22,
    scale: 1.02,
  },
  approval: {
    label: '等待授权',
    hint: '需要你来决定',
    color: 0xffcc66,
    animationSpeed: 0.09,
    scale: 1.05,
  },
  celebrating: {
    label: '完成',
    hint: '任务已完成',
    color: 0xff8bc2,
    animationSpeed: 0.3,
    scale: 1.08,
  },
  concerned: {
    label: '需要注意',
    hint: '我们遇到了问题',
    color: 0xff786f,
    animationSpeed: 0.06,
    scale: 0.96,
  },
}

export function isSoulDockPhase(value: unknown): value is SoulDockPhase {
  return typeof value === 'string' && (SOULDOCK_PHASES as readonly string[]).includes(value)
}

