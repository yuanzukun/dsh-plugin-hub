import type { DshSidecarClient } from './dsh-client'
import type { SidecarEvent, SidecarStatus } from './protocol'

export type ConnectionState = 'connecting' | 'connected' | 'disconnected'

export interface SidecarViewState {
  connection: ConnectionState
  /** Increments after every successful status handshake, including DSH restarts. */
  epoch?: number
  snapshot?: SidecarStatus
  events?: SidecarEvent[]
  error?: string
  updatedAt?: string
}

export type SidecarStateListener = (state: SidecarViewState) => void

function abortableDelay(milliseconds: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) {
      reject(signal.reason ?? new Error('Aborted'))
      return
    }
    const timer = setTimeout(resolve, milliseconds)
    signal.addEventListener('abort', () => {
      clearTimeout(timer)
      reject(signal.reason ?? new Error('Aborted'))
    }, { once: true })
  })
}

export class SidecarPoller {
  readonly #client: DshSidecarClient
  readonly #listeners = new Set<SidecarStateListener>()
  #controller?: AbortController
  #state: SidecarViewState = { connection: 'connecting' }

  constructor(client: DshSidecarClient) {
    this.#client = client
  }

  get state(): SidecarViewState {
    return this.#state
  }

  subscribe(listener: SidecarStateListener): () => void {
    this.#listeners.add(listener)
    listener(this.#state)
    return () => this.#listeners.delete(listener)
  }

  start(): void {
    if (this.#controller) return
    this.#controller = new AbortController()
    void this.#run(this.#controller.signal)
  }

  stop(): void {
    this.#controller?.abort(new Error('SoulDock sidecar poller stopped'))
    this.#controller = undefined
  }

  #publish(next: SidecarViewState): void {
    this.#state = next
    for (const listener of this.#listeners) listener(next)
  }

  async #run(signal: AbortSignal): Promise<void> {
    let afterSequence = 0
    let epoch = 0
    while (!signal.aborted) {
      try {
        this.#publish({ ...this.#state, connection: 'connecting', error: undefined })
        const status = await this.#client.status(signal)
        epoch += 1
        afterSequence = status.sequence
        this.#publish({
          connection: 'connected',
          epoch,
          snapshot: status,
          events: [],
          updatedAt: new Date().toISOString(),
        })

        while (!signal.aborted) {
          const next = await this.#client.poll({
            afterSequence,
            timeoutMilliseconds: 20_000,
          }, signal)
          afterSequence = next.sequence
          this.#publish({
            connection: 'connected',
            epoch,
            snapshot: next,
            events: next.events,
            updatedAt: new Date().toISOString(),
          })
        }
      }
      catch (error) {
        if (signal.aborted) return
        this.#publish({
          ...this.#state,
          connection: 'disconnected',
          error: error instanceof Error ? error.message : String(error),
          updatedAt: new Date().toISOString(),
        })
        try {
          await abortableDelay(1_500, signal)
        }
        catch {
          return
        }
      }
    }
  }
}
