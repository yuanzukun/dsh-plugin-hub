export type SanitizedVoiceConfig =
  | { provider: 'web-speech' }
  | { provider: 'voicevox-local', speaker: number }
  | { provider: 'edge-tts', voice: string }

export interface RendererVoiceBridge {
  getConfig: () => Promise<SanitizedVoiceConfig>
  synthesize: (text: string) => Promise<Uint8Array>
  cancel: () => Promise<void>
}
