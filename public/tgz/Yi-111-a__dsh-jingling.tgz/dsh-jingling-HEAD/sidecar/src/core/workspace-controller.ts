import type {
  ChatMessage,
  WorkspaceList,
  WorkspaceSummary,
  WorkspaceTaskEvent,
  WorkspaceTaskOpen,
  WorkspaceTaskPoll,
  WorkspaceTaskSummary,
} from './protocol'

export interface PickedWorkspaceDirectory {
  path: string
  name: string
}

/** The complete renderer-visible workspace capability surface. */
export interface SidecarWorkspacePort {
  pickDirectory(): Promise<PickedWorkspaceDirectory | null>
  list(signal?: AbortSignal): Promise<WorkspaceList>
  create(payload: { cwd: string; title?: string }, signal?: AbortSignal): Promise<WorkspaceTaskOpen>
  open(payload: { taskId: string }, signal?: AbortSignal): Promise<WorkspaceTaskOpen>
  send(
    payload: { taskId: string; clientMessageId: string; text: string; clientTimeZone?: string },
    signal?: AbortSignal,
  ): Promise<{ accepted: true; clientMessageId: string }>
  poll(
    payload: { taskId: string; afterSequence: number; timeoutMilliseconds: number },
    signal?: AbortSignal,
  ): Promise<WorkspaceTaskPoll>
  cancel(payload: { taskId: string }, signal?: AbortSignal): Promise<{ accepted: true }>
  close(payload: { taskId: string }, signal?: AbortSignal): Promise<{ closed: true }>
}

export type WorkspaceUiStatus = 'closed' | 'loading' | 'idle' | 'running' | 'needs-input' | 'error'

export interface WorkspaceUiState {
  status: WorkspaceUiStatus
  workspaces: WorkspaceSummary[]
  activeTask?: WorkspaceTaskSummary
  messages: ChatMessage[]
  partial: string
  hasOlder: boolean
  inputCodePoints: number
  error?: string
}

export type WorkspaceStateListener = (state: WorkspaceUiState, event?: WorkspaceTaskEvent) => void

const CLOSED_STATE: WorkspaceUiState = {
  status: 'closed',
  workspaces: [],
  messages: [],
  partial: '',
  hasOlder: false,
  inputCodePoints: 8000,
}

function codePoints(value: string): number {
  return [...value].length
}

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function browserRandomId(): string {
  return globalThis.crypto.randomUUID()
}

function upsertTask(workspaces: WorkspaceSummary[], task: WorkspaceTaskSummary): WorkspaceSummary[] {
  let foundWorkspace = false
  const updated = workspaces.map((workspace) => {
    if (workspace.path !== task.workspacePath) return workspace
    foundWorkspace = true
    const foundTask = workspace.tasks.some(candidate => candidate.taskId === task.taskId)
    return {
      ...workspace,
      tasks: foundTask
        ? workspace.tasks.map(candidate => candidate.taskId === task.taskId ? task : candidate)
        : [task, ...workspace.tasks],
    }
  })
  if (foundWorkspace) return updated
  return [{
    workspaceId: `sidecar:${task.workspacePath}`,
    title: task.workspaceName,
    path: task.workspacePath,
    tasks: [task],
  }, ...updated]
}

function taskWithStatus(task: WorkspaceTaskSummary, status: WorkspaceTaskSummary['status'], updatedAt: number): WorkspaceTaskSummary {
  return { ...task, status, updatedAt: Math.max(task.updatedAt, updatedAt) }
}

export class SidecarWorkspaceController {
  readonly #port: SidecarWorkspacePort
  readonly #listeners = new Set<WorkspaceStateListener>()
  readonly #id: () => string
  #state: WorkspaceUiState = structuredClone(CLOSED_STATE)
  #taskId?: string
  #sequence = 0
  #pollController?: AbortController
  #generation = 0
  #refreshGeneration = 0
  #activationTargetTaskId?: string

  constructor(port: SidecarWorkspacePort, id: () => string = browserRandomId) {
    this.#port = port
    this.#id = id
  }

  get state(): WorkspaceUiState {
    return structuredClone(this.#state)
  }

  subscribe(listener: WorkspaceStateListener): () => void {
    this.#listeners.add(listener)
    listener(this.state)
    return () => this.#listeners.delete(listener)
  }

  pickDirectory(): Promise<PickedWorkspaceDirectory | null> {
    return this.#port.pickDirectory()
  }

  async refresh(): Promise<void> {
    const refreshGeneration = ++this.#refreshGeneration
    const taskGeneration = this.#generation
    const isInactive = !this.#state.activeTask
    if (isInactive) this.#publish({ ...this.#state, status: 'loading', error: undefined })
    try {
      const listed = await this.#port.list()
      if (refreshGeneration !== this.#refreshGeneration || taskGeneration !== this.#generation) return
      const activeTask = this.#state.activeTask
        ? listed.workspaces.flatMap(workspace => workspace.tasks)
          .find(task => task.taskId === this.#state.activeTask?.taskId) ?? this.#state.activeTask
        : undefined
      this.#publish({
        ...this.#state,
        status: activeTask ? this.#state.status : 'closed',
        workspaces: listed.workspaces,
        ...(activeTask ? { activeTask } : {}),
        error: undefined,
      })
    }
    catch (error) {
      if (refreshGeneration !== this.#refreshGeneration || taskGeneration !== this.#generation) return
      this.#publish({ ...this.#state, status: 'error', error: errorText(error) })
      throw error
    }
  }

  create(cwd: string, title?: string): Promise<void> {
    return this.#activate(signal => this.#port.create({ cwd, ...(title ? { title } : {}) }, signal))
  }

  open(taskId: string): Promise<void> {
    if (taskId === this.#taskId && this.#state.status !== 'error') return Promise.resolve()
    return this.#activate(signal => this.#port.open({ taskId }, signal), taskId)
  }

  async send(rawText: string, clientTimeZone?: string): Promise<void> {
    const taskId = this.#taskId
    if (!taskId) throw new Error('Jingling workspace task is not open')
    const generation = this.#generation
    const text = rawText.trim()
    if (!text) throw new Error('Message is empty')
    if (codePoints(text) > this.#state.inputCodePoints) {
      throw new Error(`Message exceeds ${this.#state.inputCodePoints} characters`)
    }

    const clientMessageId = `sidecar-workspace-${this.#id()}`
    const at = Date.now()
    const optimistic: ChatMessage = { id: clientMessageId, role: 'user', text, at }
    this.#setActiveTaskStatus('running', at)
    this.#publish({
      ...this.#state,
      status: 'running',
      error: undefined,
      messages: [...this.#state.messages, optimistic],
    })
    try {
      await this.#port.send({ taskId, clientMessageId, text, ...(clientTimeZone ? { clientTimeZone } : {}) })
    }
    catch (error) {
      if (generation === this.#generation && taskId === this.#taskId) {
        this.#setActiveTaskStatus('error', Date.now())
        this.#publish({
          ...this.#state,
          status: 'error',
          error: errorText(error),
          messages: this.#state.messages.filter(message => message.id !== clientMessageId),
        })
      }
      throw error
    }
  }

  async cancel(): Promise<void> {
    if (!this.#taskId) return
    await this.#port.cancel({ taskId: this.#taskId })
  }

  async close(): Promise<void> {
    const taskId = this.#taskId
    this.#generation += 1
    this.#pollController?.abort(new Error('Jingling workspace task closed'))
    this.#pollController = undefined
    this.#taskId = undefined
    this.#activationTargetTaskId = undefined
    this.#sequence = 0
    this.#publish({ ...CLOSED_STATE, workspaces: this.#state.workspaces })
    if (taskId) {
      try { await this.#port.close({ taskId }) }
      catch { /* Closing is local-first; a stale server handle expires independently. */ }
    }
  }

  #publish(state: WorkspaceUiState, event?: WorkspaceTaskEvent): void {
    this.#state = structuredClone(state)
    for (const listener of this.#listeners) listener(this.state, event)
  }

  #setActiveTaskStatus(status: WorkspaceTaskSummary['status'], updatedAt: number): void {
    if (!this.#state.activeTask) return
    const task = taskWithStatus(this.#state.activeTask, status, updatedAt)
    this.#state = {
      ...this.#state,
      activeTask: task,
      workspaces: upsertTask(this.#state.workspaces, task),
    }
  }

  async #activate(
    openTask: (signal: AbortSignal) => Promise<WorkspaceTaskOpen>,
    targetTaskId?: string,
  ): Promise<void> {
    const oldTaskId = this.#taskId
    const generation = ++this.#generation
    this.#activationTargetTaskId = targetTaskId
    this.#pollController?.abort(new Error('Jingling workspace task changed'))
    this.#pollController = undefined
    this.#publish({
      ...this.#state,
      status: 'loading',
      activeTask: undefined,
      messages: [],
      partial: '',
      hasOlder: false,
      error: undefined,
    })
    const opening = new AbortController()
    try {
      const opened = await openTask(opening.signal)
      if (generation !== this.#generation) {
        if (opened.task.taskId !== this.#activationTargetTaskId) {
          void this.#port.close({ taskId: opened.task.taskId }).catch(() => undefined)
        }
        return
      }
      this.#taskId = opened.task.taskId
      this.#activationTargetTaskId = opened.task.taskId
      this.#sequence = opened.sequence
      this.#publish({
        status: opened.status,
        workspaces: upsertTask(this.#state.workspaces, opened.task),
        activeTask: opened.task,
        messages: opened.messages,
        partial: opened.partial?.text ?? '',
        hasOlder: opened.hasOlder,
        inputCodePoints: opened.limits.inputCodePoints,
      })
      if (oldTaskId && oldTaskId !== opened.task.taskId) {
        void this.#port.close({ taskId: oldTaskId }).catch(() => undefined)
      }
      const controller = new AbortController()
      this.#pollController = controller
      void this.#pollLoop(generation, opened.task.taskId, controller.signal)
    }
    catch (error) {
      if (generation !== this.#generation) return
      this.#taskId = undefined
      this.#activationTargetTaskId = undefined
      if (oldTaskId) void this.#port.close({ taskId: oldTaskId }).catch(() => undefined)
      this.#publish({ ...this.#state, status: 'error', error: errorText(error) })
      throw error
    }
  }

  #applyEvent(event: WorkspaceTaskEvent): void {
    if (event.type === 'user-message') {
      const existing = this.#state.messages.some(message => (
        message.id === event.messageId || (event.clientMessageId && message.id === event.clientMessageId)
      ))
      const messages = existing
        ? this.#state.messages.map(message => message.id === event.clientMessageId
          ? { id: event.messageId, role: 'user' as const, text: event.text, at: event.at }
          : message)
        : [...this.#state.messages, { id: event.messageId, role: 'user', text: event.text, at: event.at } as ChatMessage]
      this.#publish({ ...this.#state, messages }, event)
      return
    }
    if (event.type === 'assistant-delta') {
      this.#publish({ ...this.#state, status: 'running', partial: `${this.#state.partial}${event.delta}` }, event)
      return
    }
    if (event.type === 'assistant-final') {
      this.#setActiveTaskStatus('idle', event.at)
      const withoutSame = this.#state.messages.filter(message => message.id !== event.messageId)
      this.#publish({
        ...this.#state,
        status: 'idle',
        partial: '',
        messages: [...withoutSame, { id: event.messageId, role: 'assistant', text: event.text, at: event.at }],
      }, event)
      return
    }
    if (event.type === 'status') {
      this.#setActiveTaskStatus(event.status, event.at)
      const retainedError = event.status === 'idle' && this.#state.status === 'error'
        ? this.#state.error
        : undefined
      this.#publish({ ...this.#state, status: event.status, error: retainedError }, event)
      return
    }
    this.#setActiveTaskStatus('error', event.at)
    this.#publish({ ...this.#state, status: 'error', error: event.message, partial: '' }, event)
  }

  async #pollLoop(generation: number, taskId: string, signal: AbortSignal): Promise<void> {
    while (!signal.aborted && generation === this.#generation) {
      try {
        const result = await this.#port.poll({ taskId, afterSequence: this.#sequence, timeoutMilliseconds: 20_000 }, signal)
        if (signal.aborted || generation !== this.#generation) return
        if (result.resetRequired) {
          this.#generation += 1
          this.#pollController = undefined
          this.#taskId = undefined
          this.#publish({
            ...CLOSED_STATE,
            status: 'error',
            workspaces: this.#state.workspaces,
            error: '工作区任务连接已刷新，请重新打开任务。',
          })
          return
        }
        for (const event of result.events) {
          if (event.sequence <= this.#sequence) continue
          this.#sequence = event.sequence
          this.#applyEvent(event)
        }
        this.#sequence = Math.max(this.#sequence, result.sequence)
      }
      catch (error) {
        if (signal.aborted || generation !== this.#generation) return
        this.#publish({ ...this.#state, status: 'error', error: errorText(error) })
        await new Promise(resolve => setTimeout(resolve, 1000))
      }
    }
  }
}
