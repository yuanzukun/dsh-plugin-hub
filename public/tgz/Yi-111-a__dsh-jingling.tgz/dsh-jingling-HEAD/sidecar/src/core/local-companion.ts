/**
 * Local, non-model companion reactions.
 *
 * This module deliberately has no DOM, network, clock, or random-number
 * dependencies. The renderer supplies a clock and a random source, which
 * keeps local reactions deterministic in tests and prevents this feature
 * from gaining any access to DSH conversations or workspace data.
 */

export const LOCAL_COMPANION_EVENT_TYPES = [
  'head',
  'body',
  'tail',
  'lower',
  'flick',
  'near',
  'file-drop',
  'walk',
  'time-greeting',
  'proactive',
] as const

export type LocalCompanionEventType = (typeof LOCAL_COMPANION_EVENT_TYPES)[number]

export type LocalCompanionEvent =
  | { readonly type: 'head' }
  | { readonly type: 'body' }
  | { readonly type: 'tail' }
  | { readonly type: 'lower' }
  | { readonly type: 'flick' }
  | { readonly type: 'near' }
  /**
   * The caller may pass a browser File.name or a path-like value. Only a
   * sanitized basename is ever returned in an intent; paths are never kept
   * in LocalCompanionState.
   */
  | { readonly type: 'file-drop'; readonly fileName?: string }
  | { readonly type: 'walk' }
  | { readonly type: 'time-greeting' }
  | { readonly type: 'proactive' }

export type LocalCompanionTone = 'warm' | 'calm' | 'curious' | 'surprised' | 'encouraging'
export type LocalCompanionMotionHint = 'nod' | 'settle' | 'notice' | 'startled' | 'walk'
export type LocalGreetingPeriod = 'morning' | 'daytime' | 'evening' | 'night'

/** Explicitly injected time and randomness for a pure, reproducible decision. */
export interface LocalCompanionContext {
  /** Monotonic-enough application timestamp in milliseconds, supplied by the caller. */
  readonly nowMs: number
  /** Local hour (0 through 23), supplied by the caller instead of read from Date. */
  readonly hour: number
  /** A caller-owned random source. Invalid outputs safely resolve to the first line. */
  readonly random: () => number
}

/**
 * Active bubbles are deliberately opt-in. With the default policy, a local
 * event only returns a silent motion hint and never exposes a line of text.
 */
export interface LocalCompanionPolicy {
  readonly activeBubbles?: boolean
  readonly interactionCooldownMs?: number
  readonly nearCooldownMs?: number
  readonly proactiveCooldownMs?: number
  readonly greetingCooldownMs?: number
}

export interface LocalCompanionState {
  readonly lastBubbleAtMs?: number
  readonly lastByTypeMs: Readonly<Partial<Record<LocalCompanionEventType, number>>>
  readonly lastGreetingPeriod?: LocalGreetingPeriod
  readonly lastLineKey?: string
}

export interface LocalCompanionSilentIntent {
  readonly kind: 'silent'
  readonly eventType: LocalCompanionEventType
  readonly motion: LocalCompanionMotionHint
  readonly reason: 'bubbles-disabled'
}

export interface LocalCompanionSuppressedIntent {
  readonly kind: 'suppressed'
  readonly eventType: LocalCompanionEventType
  readonly motion: LocalCompanionMotionHint
  readonly reason: 'cooldown' | 'greeting-already-shown'
}

export interface LocalCompanionBubbleIntent {
  readonly kind: 'bubble'
  readonly source: 'local'
  readonly eventType: LocalCompanionEventType
  readonly text: string
  readonly tone: LocalCompanionTone
  readonly motion: LocalCompanionMotionHint
  /** Present only for a file-drop event and always basename-only. */
  readonly fileName?: string
}

export type LocalCompanionIntent =
  | LocalCompanionSilentIntent
  | LocalCompanionSuppressedIntent
  | LocalCompanionBubbleIntent

export interface LocalCompanionResult {
  readonly intent: LocalCompanionIntent
  readonly state: LocalCompanionState
}

export const LOCAL_COMPANION_DEFAULT_POLICY: Required<LocalCompanionPolicy> = {
  activeBubbles: false,
  interactionCooldownMs: 7_000,
  nearCooldownMs: 45_000,
  proactiveCooldownMs: 30 * 60_000,
  greetingCooldownMs: 2 * 60 * 60_000,
}

interface LocalLine {
  readonly key: string
  readonly tone: LocalCompanionTone
  readonly text: (fileName?: string) => string
}

// Original SoulDock-local copy. It intentionally does not mirror any
// third-party desktop-pet script or character dialogue.
const LOCAL_LINES: Record<Exclude<LocalCompanionEventType, 'time-greeting'>, readonly LocalLine[]> = {
  head: [
    { key: 'listen', tone: 'curious', text: () => '嗯？我在听。' },
    { key: 'gentle', tone: 'warm', text: () => '轻一点，我会好好回应。' },
    { key: 'here', tone: 'calm', text: () => '这里呀。' },
  ],
  body: [
    { key: 'beside', tone: 'warm', text: () => '我在这边陪着。' },
    { key: 'steady', tone: 'calm', text: () => '今天也稳稳地来。' },
    { key: 'received', tone: 'encouraging', text: () => '收到，继续吧。' },
  ],
  lower: [
    { key: 'steady', tone: 'calm', text: () => '站稳就好。' },
    { key: 'near', tone: 'warm', text: () => '我没有走远。' },
    { key: 'careful', tone: 'curious', text: () => '下面也碰到了呀。' },
  ],
  tail: [
    { key: 'tail-gentle', tone: 'surprised', text: () => '尾巴也怕痒呀。' },
    { key: 'tail-careful', tone: 'warm', text: () => '轻一点，尾巴在这里。' },
    { key: 'tail-sway', tone: 'curious', text: () => '尾巴晃了一下。' },
  ],
  flick: [
    { key: 'slow', tone: 'surprised', text: () => '慢一点，我还在这里。' },
    { key: 'back', tone: 'warm', text: () => '呀——我回来了。' },
    { key: 'gentle', tone: 'calm', text: () => '下次轻些，好吗？' },
  ],
  near: [
    { key: 'seen', tone: 'curious', text: () => '看到你靠近了。' },
    { key: 'waiting', tone: 'calm', text: () => '我在这边。' },
    { key: 'ask', tone: 'warm', text: () => '需要我就点一下。' },
  ],
  'file-drop': [
    { key: 'saw', tone: 'curious', text: fileName => `我看到《${fileName ?? '这个文件'}》了。` },
    { key: 'arrived', tone: 'warm', text: fileName => `《${fileName ?? '这个文件'}》到这里啦。` },
    { key: 'notice', tone: 'calm', text: fileName => `注意到《${fileName ?? '这个文件'}》。` },
  ],
  walk: [
    { key: 'steps', tone: 'encouraging', text: () => '走两步，换换心情。' },
    { key: 'patrol', tone: 'warm', text: () => '小步巡逻中。' },
    { key: 'nearby', tone: 'calm', text: () => '我就在附近。' },
  ],
  proactive: [
    { key: 'present', tone: 'calm', text: () => '我在这里。' },
    { key: 'call', tone: 'warm', text: () => '如果需要，就叫我。' },
    { key: 'quiet', tone: 'calm', text: () => '先陪你安静一会儿。' },
  ],
}

const GREETING_LINES: Record<LocalGreetingPeriod, readonly LocalLine[]> = {
  morning: [
    { key: 'slow-start', tone: 'warm', text: () => '早呀，慢慢开始就好。' },
    { key: 'morning', tone: 'encouraging', text: () => '早上好，先做最重要的一件事。' },
  ],
  daytime: [
    { key: 'water', tone: 'warm', text: () => '下午好，记得喝口水。' },
    { key: 'steady', tone: 'calm', text: () => '下午也稳稳地来。' },
  ],
  evening: [
    { key: 'tired', tone: 'warm', text: () => '晚上好，今天辛苦了。' },
    { key: 'wrap', tone: 'calm', text: () => '傍晚了，给今天收个尾吧。' },
  ],
  night: [
    { key: 'rest', tone: 'warm', text: () => '夜深了，留一点休息给自己。' },
    { key: 'quiet', tone: 'calm', text: () => '夜里安静些，我陪你。' },
  ],
}

const MOTION_BY_EVENT: Record<LocalCompanionEventType, LocalCompanionMotionHint> = {
  head: 'nod',
  body: 'settle',
  tail: 'startled',
  lower: 'settle',
  flick: 'startled',
  near: 'notice',
  'file-drop': 'notice',
  walk: 'walk',
  'time-greeting': 'nod',
  proactive: 'notice',
}

export function createLocalCompanionState(): LocalCompanionState {
  return { lastByTypeMs: {} }
}

export function isLocalCompanionEventType(value: unknown): value is LocalCompanionEventType {
  return typeof value === 'string' && (LOCAL_COMPANION_EVENT_TYPES as readonly string[]).includes(value)
}

/** Returns a local greeting period without reading the system clock. */
export function localGreetingPeriod(hour: number): LocalGreetingPeriod {
  const safeHour = normalizeHour(hour)
  if (safeHour < 6) return 'night'
  if (safeHour < 12) return 'morning'
  if (safeHour < 18) return 'daytime'
  if (safeHour < 22) return 'evening'
  return 'night'
}

/**
 * Converts a browser File.name or path-like input to safe display text. This
 * function never returns a slash or backslash and bounds the displayed name.
 */
export function localFileNameOnly(value: unknown, fallback = '这个文件'): string {
  if (typeof value !== 'string') return fallback
  const finalSegment = value.split(/[\\/]+/u).filter(Boolean).at(-1) ?? ''
  const cleaned = finalSegment.replace(/[\u0000-\u001f\u007f]+/gu, ' ').trim()
  if (!cleaned || cleaned === '.' || cleaned === '..') return fallback
  const characters = [...cleaned]
  return characters.length > 72 ? `${characters.slice(0, 71).join('')}…` : characters.join('')
}

/**
 * Evaluate one local event. No global state is mutated: retain result.state
 * in the renderer and feed it into the next call.
 */
export function resolveLocalCompanionEvent(
  event: LocalCompanionEvent,
  state: LocalCompanionState,
  context: LocalCompanionContext,
  policy: LocalCompanionPolicy = {},
): LocalCompanionResult {
  const motion = MOTION_BY_EVENT[event.type]
  const effectivePolicy = mergePolicy(policy)
  const nowMs = normalizeMilliseconds(context.nowMs)

  // This is intentionally a strict boolean check. Undefined, false, and
  // truthy non-boolean values all stay silent until the user actively opts in.
  if (effectivePolicy.activeBubbles !== true) {
    return {
      intent: { kind: 'silent', eventType: event.type, motion, reason: 'bubbles-disabled' },
      state,
    }
  }

  const greetingPeriod = event.type === 'time-greeting' ? localGreetingPeriod(context.hour) : undefined
  if (greetingPeriod && state.lastGreetingPeriod === greetingPeriod) {
    return {
      intent: { kind: 'suppressed', eventType: event.type, motion, reason: 'greeting-already-shown' },
      state,
    }
  }

  const cooldownMs = cooldownFor(event.type, effectivePolicy)
  const previousBubble = state.lastBubbleAtMs
  if (previousBubble !== undefined && nowMs - previousBubble < cooldownMs) {
    return {
      intent: { kind: 'suppressed', eventType: event.type, motion, reason: 'cooldown' },
      state,
    }
  }

  const safeFileName = event.type === 'file-drop' ? localFileNameOnly(event.fileName) : undefined
  const lines = event.type === 'time-greeting'
    ? GREETING_LINES[greetingPeriod ?? 'daytime']
    : LOCAL_LINES[event.type]
  const line = chooseLine(lines, context.random, state.lastLineKey, event.type)
  const lineKey = `${event.type}:${line.key}`
  const nextState: LocalCompanionState = {
    lastBubbleAtMs: nowMs,
    lastByTypeMs: { ...state.lastByTypeMs, [event.type]: nowMs },
    lastGreetingPeriod: greetingPeriod ?? state.lastGreetingPeriod,
    lastLineKey: lineKey,
  }

  return {
    intent: {
      kind: 'bubble',
      source: 'local',
      eventType: event.type,
      text: line.text(safeFileName),
      tone: line.tone,
      motion,
      ...(safeFileName ? { fileName: safeFileName } : {}),
    },
    state: nextState,
  }
}

function mergePolicy(policy: LocalCompanionPolicy): Required<LocalCompanionPolicy> {
  return {
    activeBubbles: policy.activeBubbles === true,
    interactionCooldownMs: nonNegative(policy.interactionCooldownMs, LOCAL_COMPANION_DEFAULT_POLICY.interactionCooldownMs),
    nearCooldownMs: nonNegative(policy.nearCooldownMs, LOCAL_COMPANION_DEFAULT_POLICY.nearCooldownMs),
    proactiveCooldownMs: nonNegative(policy.proactiveCooldownMs, LOCAL_COMPANION_DEFAULT_POLICY.proactiveCooldownMs),
    greetingCooldownMs: nonNegative(policy.greetingCooldownMs, LOCAL_COMPANION_DEFAULT_POLICY.greetingCooldownMs),
  }
}

function cooldownFor(type: LocalCompanionEventType, policy: Required<LocalCompanionPolicy>): number {
  if (type === 'near') return Math.max(policy.interactionCooldownMs, policy.nearCooldownMs)
  if (type === 'proactive') return Math.max(policy.interactionCooldownMs, policy.proactiveCooldownMs)
  if (type === 'time-greeting') return Math.max(policy.interactionCooldownMs, policy.greetingCooldownMs)
  return policy.interactionCooldownMs
}

function chooseLine(
  lines: readonly LocalLine[],
  random: () => number,
  previousLineKey: string | undefined,
  eventType: LocalCompanionEventType,
): LocalLine {
  const randomValue = safeRandom(random)
  let index = Math.min(lines.length - 1, Math.floor(randomValue * lines.length))
  let line = lines[index]
  if (!line) throw new Error(`Local companion is missing lines for ${eventType}`)

  // A deterministic random source may repeat. Rotate once to keep two
  // adjacent local bubbles from sounding identical when alternatives exist.
  if (lines.length > 1 && `${eventType}:${line.key}` === previousLineKey) {
    index = (index + 1) % lines.length
    line = lines[index]
    if (!line) throw new Error(`Local companion is missing a fallback line for ${eventType}`)
  }
  return line
}

function safeRandom(random: () => number): number {
  try {
    const value = random()
    if (!Number.isFinite(value)) return 0
    return Math.min(0.999_999_999, Math.max(0, value))
  }
  catch {
    return 0
  }
}

function normalizeMilliseconds(value: number): number {
  return Number.isFinite(value) ? Math.max(0, value) : 0
}

function normalizeHour(value: number): number {
  return Number.isFinite(value) ? Math.min(23, Math.max(0, Math.floor(value))) : 12
}

function nonNegative(value: number | undefined, fallback: number): number {
  return value !== undefined && Number.isFinite(value) ? Math.max(0, value) : fallback
}
