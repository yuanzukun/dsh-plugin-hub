import { z } from 'zod'
import { SOULDOCK_PHASES } from './phases'

const phaseSchema = z.enum(SOULDOCK_PHASES)

const sidecarEventBaseSchema = z.object({
  sequence: z.number().int().nonnegative(),
  at: z.union([z.string().min(1), z.number().finite()]),
})

const assistantMessageEventSchema = sidecarEventBaseSchema.extend({
  type: z.literal('assistant-message'),
  sessionId: z.string().nullable(),
  messageId: z.string().min(1),
  text: z.string().trim().min(1).max(6000),
  completed: z.literal(true),
})

const activityEventSchema = sidecarEventBaseSchema.extend({
  type: z.literal('activity'),
  sessionId: z.string().nullable(),
  runtime: z.object({
    phase: phaseSchema,
    detail: z.string().nullable().optional(),
    lastEvent: z.string().nullable().optional(),
    updatedAt: z.string().nullable().optional(),
  }),
})

export const sidecarEventSchema = z.discriminatedUnion('type', [
  assistantMessageEventSchema,
  activityEventSchema,
])

export const sidecarStatusSchema = z.object({
  version: z.number().int().positive(),
  sequence: z.number().int().nonnegative(),
  persona: z.object({
    id: z.string().min(1),
    name: z.string().min(1),
  }).passthrough(),
  runtime: z.object({
    phase: phaseSchema,
    detail: z.string().nullable().optional(),
    lastEvent: z.string().nullable().optional(),
    updatedAt: z.string().nullable().optional(),
  }).passthrough(),
  capabilities: z.object({
    assistantText: z.boolean(),
    voiceOutput: z.boolean(),
    voiceInput: z.literal(false),
  }).passthrough(),
  privacy: z.string().min(1),
}).passthrough()

export const sidecarPollSchema = sidecarStatusSchema.extend({
  events: z.array(sidecarEventSchema),
})

export const chatMessageSchema = z.object({
  id: z.string().min(1).max(240),
  role: z.enum(['user', 'assistant']),
  text: z.string().max(12_000),
  at: z.number().finite(),
})

export const chatStatusSchema = z.enum(['idle', 'running', 'error'])
export const workspaceTaskStatusSchema = z.enum(['idle', 'running', 'needs-input', 'error'])

export const chatOpenSchema = z.object({
  version: z.literal(1),
  chatId: z.string().min(1).max(240),
  sequence: z.number().int().nonnegative(),
  status: chatStatusSchema,
  persona: z.object({
    id: z.string().min(1).max(160),
    name: z.string().min(1).max(160),
  }),
  messages: z.array(chatMessageSchema).max(200),
  partial: z.object({
    turn: z.number().int().nonnegative(),
    step: z.number().int().nonnegative(),
    text: z.string().max(12_000),
  }).optional(),
  hasOlder: z.boolean(),
  limits: z.object({ inputCodePoints: z.number().int().positive().max(20_000) }),
})

export const chatSendSchema = z.object({
  accepted: z.literal(true),
  clientMessageId: z.string().min(1).max(240),
})

const chatEventBaseSchema = z.object({
  sequence: z.number().int().nonnegative(),
  at: z.number().finite(),
})

const chatUserMessageEventSchema = chatEventBaseSchema.extend({
  type: z.literal('user-message'),
  sourceSeq: z.number().int().nonnegative(),
  messageId: z.string().min(1).max(240),
  clientMessageId: z.string().min(1).max(240).optional(),
  text: z.string().max(12_000),
})

const chatAssistantDeltaEventSchema = chatEventBaseSchema.extend({
  type: z.literal('assistant-delta'),
  sourceSeq: z.number().int().nonnegative(),
  turn: z.number().int().nonnegative(),
  step: z.number().int().nonnegative(),
  delta: z.string().max(12_000),
})

const chatAssistantFinalEventSchema = chatEventBaseSchema.extend({
  type: z.literal('assistant-final'),
  sourceSeq: z.number().int().nonnegative(),
  turn: z.number().int().nonnegative(),
  step: z.number().int().nonnegative(),
  messageId: z.string().min(1).max(240),
  text: z.string().max(12_000),
})

const chatStatusEventSchema = chatEventBaseSchema.extend({
  type: z.literal('status'),
  status: z.enum(['idle', 'running']),
})

const chatErrorEventSchema = chatEventBaseSchema.extend({
  type: z.literal('error'),
  code: z.enum(['aborted', 'blocked', 'failed', 'max-tokens']),
  message: z.string().min(1).max(1000),
})

export const chatEventSchema = z.discriminatedUnion('type', [
  chatUserMessageEventSchema,
  chatAssistantDeltaEventSchema,
  chatAssistantFinalEventSchema,
  chatStatusEventSchema,
  chatErrorEventSchema,
])

export const chatPollSchema = z.object({
  version: z.literal(1),
  sequence: z.number().int().nonnegative(),
  status: chatStatusSchema,
  events: z.array(chatEventSchema).max(256),
  resetRequired: z.literal(true).optional(),
})

export const chatCancelSchema = z.object({ accepted: z.literal(true) })
export const chatCloseSchema = z.object({ closed: z.literal(true) })

export const workspaceTaskSummarySchema = z.object({
  taskId: z.string().min(1).max(240),
  title: z.string().min(1).max(240),
  workspacePath: z.string().min(1).max(4096),
  workspaceName: z.string().min(1).max(240),
  updatedAt: z.number().finite(),
  status: workspaceTaskStatusSchema,
})

export const workspaceSummarySchema = z.object({
  workspaceId: z.string().min(1).max(240),
  title: z.string().min(1).max(240),
  path: z.string().min(1).max(4096),
  tasks: z.array(workspaceTaskSummarySchema).max(200),
})

export const workspaceListSchema = z.object({
  version: z.literal(1),
  workspaces: z.array(workspaceSummarySchema).max(100),
})

export const workspaceTaskOpenSchema = z.object({
  version: z.literal(1),
  task: workspaceTaskSummarySchema,
  sequence: z.number().int().nonnegative(),
  status: workspaceTaskStatusSchema,
  messages: z.array(chatMessageSchema).max(200),
  partial: z.object({
    turn: z.number().int().nonnegative(),
    step: z.number().int().nonnegative(),
    text: z.string().max(12_000),
  }).optional(),
  hasOlder: z.boolean(),
  limits: z.object({ inputCodePoints: z.number().int().positive().max(20_000) }),
})

// Workspace task output intentionally shares the filtered chat event vocabulary.
// Raw DSH tool calls, reasoning, memory, session ids, and filesystem data never
// cross this DTO boundary.
const workspaceTaskStatusEventSchema = chatEventBaseSchema.extend({
  type: z.literal('status'),
  status: z.enum(['idle', 'running', 'needs-input']),
})

export const workspaceTaskEventSchema = z.discriminatedUnion('type', [
  chatUserMessageEventSchema,
  chatAssistantDeltaEventSchema,
  chatAssistantFinalEventSchema,
  workspaceTaskStatusEventSchema,
  chatErrorEventSchema,
])

export const workspaceTaskPollSchema = z.object({
  version: z.literal(1),
  sequence: z.number().int().nonnegative(),
  status: workspaceTaskStatusSchema,
  events: z.array(workspaceTaskEventSchema).max(256),
  resetRequired: z.literal(true).optional(),
})
export const workspaceTaskSendSchema = chatSendSchema
export const workspaceTaskCancelSchema = chatCancelSchema
export const workspaceTaskCloseSchema = chatCloseSchema

const localPathSchema = z.string().min(1).max(4096).refine(value => !value.includes('\0'), {
  message: 'Path must not contain a null byte',
})

export const workspaceTaskCreateRequestSchema = z.object({
  cwd: localPathSchema,
  title: z.string().trim().min(1).max(240).optional(),
}).strict()

export const workspaceTaskOpenRequestSchema = z.object({
  taskId: z.string().min(1).max(240),
}).strict()

export const workspaceTaskSendRequestSchema = z.object({
  taskId: z.string().min(1).max(240),
  clientMessageId: z.string().min(1).max(240),
  text: z.string().min(1).max(12_000),
  clientTimeZone: z.string().min(1).max(160).optional(),
}).strict()

export const workspaceTaskPollRequestSchema = z.object({
  taskId: z.string().min(1).max(240),
  afterSequence: z.number().int().nonnegative(),
  timeoutMilliseconds: z.number().int().min(0).max(25_000),
}).strict()

export const workspaceTaskIdRequestSchema = workspaceTaskOpenRequestSchema

export type SidecarEvent = z.infer<typeof sidecarEventSchema>
export type AssistantMessageEvent = Extract<SidecarEvent, { type: 'assistant-message' }>
export type SidecarStatus = z.infer<typeof sidecarStatusSchema>
export type SidecarPoll = z.infer<typeof sidecarPollSchema>
export type ChatMessage = z.infer<typeof chatMessageSchema>
export type ChatOpen = z.infer<typeof chatOpenSchema>
export type ChatEvent = z.infer<typeof chatEventSchema>
export type ChatPoll = z.infer<typeof chatPollSchema>
export type ChatSend = z.infer<typeof chatSendSchema>
export type ChatCancel = z.infer<typeof chatCancelSchema>
export type ChatClose = z.infer<typeof chatCloseSchema>
export type WorkspaceTaskSummary = z.infer<typeof workspaceTaskSummarySchema>
export type WorkspaceSummary = z.infer<typeof workspaceSummarySchema>
export type WorkspaceList = z.infer<typeof workspaceListSchema>
export type WorkspaceTaskOpen = z.infer<typeof workspaceTaskOpenSchema>
export type WorkspaceTaskEvent = z.infer<typeof workspaceTaskEventSchema>
export type WorkspaceTaskPoll = z.infer<typeof workspaceTaskPollSchema>
export type WorkspaceTaskSend = z.infer<typeof workspaceTaskSendSchema>
export type WorkspaceTaskCancel = z.infer<typeof workspaceTaskCancelSchema>
export type WorkspaceTaskClose = z.infer<typeof workspaceTaskCloseSchema>

export interface ClientRequestEnvelope {
  type: 'client-request'
  rpcId: string
  method:
    | 'sidecar/status'
    | 'sidecar/poll'
    | 'chat/open'
    | 'chat/send'
    | 'chat/poll'
    | 'chat/cancel'
    | 'chat/close'
    | 'workspace/list'
    | 'workspace/task/create'
    | 'workspace/task/open'
    | 'workspace/task/send'
    | 'workspace/task/poll'
    | 'workspace/task/cancel'
    | 'workspace/task/close'
  payload: Record<string, unknown>
}

export interface PollRequest {
  afterSequence: number
  timeoutMilliseconds: number
}
