import assert from 'node:assert/strict'
import test from 'node:test'
import {
  EdgeTtsIpcOutputProvider,
  VoicevoxIpcOutputProvider,
  type VoiceOutputProvider,
} from '../src/renderer/adapters/voice'
import type { VoicevoxWavPlayback } from '../src/renderer/adapters/voicevox-local'

test('VOICEVOX renderer provider cancels before replace, then plays IPC WAV', async () => {
  const calls: string[] = []
  const playback: VoicevoxWavPlayback = {
    play: async (wav) => { calls.push(`play:${wav.size}`) },
    stop: () => { calls.push('stop') },
  }
  const provider = new VoicevoxIpcOutputProvider({
    cancel: async () => { calls.push('ipc-cancel') },
    synthesize: async (text) => {
      calls.push(`synthesize:${text}`)
      return new Uint8Array([82, 73, 70, 70])
    },
  }, playback)

  await provider.speak({ text: '  hello  ', mode: 'replace' })
  assert.deepEqual(calls, ['stop', 'ipc-cancel', 'synthesize:hello', 'play:4'])
})

test('VOICEVOX renderer cancel stops both main synthesis and local playback', async () => {
  const calls: string[] = []
  const provider = new VoicevoxIpcOutputProvider({
    cancel: async () => { calls.push('ipc-cancel') },
    synthesize: async () => new Uint8Array([1]),
  }, {
    play: async () => undefined,
    stop: () => { calls.push('stop') },
  })

  await provider.cancel()
  assert.deepEqual(calls, ['ipc-cancel', 'stop'])
})

test('Edge TTS renderer provider falls back to the local system provider after a synthesis failure', async () => {
  const calls: string[] = []
  const systemVoice: VoiceOutputProvider = {
    id: 'web-speech',
    capabilities: { tts: true, stt: false, fullDuplex: false },
    speak: request => { calls.push(`system-speak:${request.text}:${request.mode}`) },
    cancel: () => { calls.push('system-cancel') },
  }
  const provider = new EdgeTtsIpcOutputProvider({
    cancel: async () => { calls.push('ipc-cancel') },
    synthesize: async () => { throw new Error('Python edge-tts unavailable') },
  }, {
    play: async () => { calls.push('play') },
    stop: () => { calls.push('stop') },
  }, systemVoice)

  await provider.speak({ text: '  使用本地回退  ', mode: 'replace', lang: 'zh-CN' })
  assert.deepEqual(calls, [
    'stop',
    'ipc-cancel',
    'system-cancel',
    'system-speak:使用本地回退:replace',
  ])
})

test('Edge TTS renderer cancellation stops the optional process, MP3 playback and system fallback', async () => {
  const calls: string[] = []
  const provider = new EdgeTtsIpcOutputProvider({
    cancel: async () => { calls.push('ipc-cancel') },
    synthesize: async () => new Uint8Array([73, 68, 51]),
  }, {
    play: async () => undefined,
    stop: () => { calls.push('stop') },
  }, {
    speak: () => undefined,
    cancel: () => { calls.push('system-cancel') },
  })

  await provider.cancel()
  assert.deepEqual(calls, ['ipc-cancel', 'stop', 'system-cancel'])
})
