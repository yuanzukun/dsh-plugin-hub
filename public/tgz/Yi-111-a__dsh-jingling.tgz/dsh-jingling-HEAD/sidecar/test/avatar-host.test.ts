import assert from 'node:assert/strict'
import test from 'node:test'
import type { SoulDockPhase } from '../src/core/phases'
import {
  AvatarHost,
  type AvatarAction,
  type AvatarController,
  type AvatarLayer,
  type AvatarMount,
  type AvatarStageDriver,
} from '../src/renderer/avatar-host'

function deferred<T>(): { promise: Promise<T>; resolve: (value: T) => void } {
  let resolve!: (value: T) => void
  const promise = new Promise<T>(done => { resolve = done })
  return { promise, resolve }
}

function fakeDriver(): AvatarStageDriver & { layers: Array<AvatarLayer & { shown: boolean; removed: boolean }> } {
  const layers: Array<AvatarLayer & { shown: boolean; removed: boolean }> = []
  return {
    layers,
    createHiddenLayer: () => {
      const layer = {
        container: {} as HTMLElement,
        shown: false,
        removed: false,
        show() { this.shown = true },
        remove() { this.removed = true },
      }
      layers.push(layer)
      return layer
    },
  }
}

function controller(kind: AvatarController['kind'], log: string[]): AvatarController {
  return {
    kind,
    setPhase: (phase: SoulDockPhase) => log.push(`${kind}:phase:${phase}`),
    destroy: () => { log.push(`${kind}:destroy`) },
  }
}

test('first successful avatar becomes visible and receives current phase', async () => {
  const driver = fakeDriver()
  const log: string[] = []
  const host = new AvatarHost({} as HTMLElement, driver)
  host.setPhase('thinking')

  const result = await host.switchTo(async () => ({ controller: controller('sprite', log) }))

  assert.equal(result.applied, true)
  assert.equal(host.activeKind, 'sprite')
  assert.equal(driver.layers[0]?.shown, true)
  assert.deepEqual(log, ['sprite:phase:thinking'])
})

test('local action override survives a renderer switch and is optional for non-Sprite avatars', async () => {
  const driver = fakeDriver()
  const log: string[] = []
  const host = new AvatarHost({} as HTMLElement, driver)
  host.setAction('sleep')

  const sprite: AvatarController = {
    kind: 'sprite',
    setPhase: phase => log.push(`sprite:phase:${phase}`),
    setAction: (action: AvatarAction | undefined) => log.push(`sprite:action:${action ?? 'none'}`),
    destroy: () => undefined,
  }
  await host.switchTo(async () => ({ controller: sprite }))
  host.setAction('click')
  await host.switchTo(async () => ({ controller: controller('vrm', log) }))

  assert.deepEqual(log, [
    'sprite:phase:idle',
    'sprite:action:sleep',
    'sprite:action:click',
    'vrm:phase:idle',
  ])
})

test('failed staged load leaves the current Sprite active', async () => {
  const driver = fakeDriver()
  const log: string[] = []
  const host = new AvatarHost({} as HTMLElement, driver)
  await host.switchTo(async () => ({ controller: controller('sprite', log) }))

  await assert.rejects(host.switchTo(async () => { throw new Error('bad vrm') }), /bad vrm/)

  assert.equal(host.activeKind, 'sprite')
  assert.equal(driver.layers[1]?.removed, true)
  assert.equal(log.includes('sprite:destroy'), false)
})

test('generation prevents a late stale load from replacing the newest avatar', async () => {
  const driver = fakeDriver()
  const log: string[] = []
  const host = new AvatarHost({} as HTMLElement, driver)
  const first = deferred<AvatarMount>()
  const second = deferred<AvatarMount>()

  const firstSwitch = host.switchTo(() => first.promise)
  const secondSwitch = host.switchTo(() => second.promise)
  second.resolve({ controller: controller('vrm', log) })
  assert.equal((await secondSwitch).applied, true)
  first.resolve({ controller: controller('live2d', log) })
  assert.equal((await firstSwitch).applied, false)

  assert.equal(host.activeKind, 'vrm')
  assert.equal(driver.layers[0]?.removed, true)
  assert.ok(log.includes('live2d:destroy'))
  assert.equal(log.includes('vrm:destroy'), false)
})

test('successful replacement disposes the previous controller and returns neutral metadata', async () => {
  const driver = fakeDriver()
  const log: string[] = []
  const host = new AvatarHost({} as HTMLElement, driver)
  await host.switchTo(async () => ({ controller: controller('sprite', log) }))

  const result = await host.switchTo(async () => ({
    controller: controller('vrm', log),
    metadata: { title: 'Local model', rows: [{ label: '许可', value: '模型未声明' }] },
  }))

  assert.equal(result.applied, true)
  assert.deepEqual(result.metadata, {
    title: 'Local model',
    rows: [{ label: '许可', value: '模型未声明' }],
  })
  assert.ok(log.includes('sprite:destroy'))
  assert.equal(driver.layers[0]?.removed, true)
})

test('hitTest delegates client coordinates to only the active avatar controller', async () => {
  const driver = fakeDriver()
  const host = new AvatarHost({} as HTMLElement, driver)
  const calls: Array<[number, number]> = []

  assert.equal(host.hitTest(12, 34), null)
  await host.switchTo(async () => ({
    controller: {
      kind: 'vrm',
      hitTest: (clientX, clientY) => {
        calls.push([clientX, clientY])
        return clientX === 12 && clientY === 34 ? 'head' : null
      },
      setPhase: () => undefined,
      destroy: () => undefined,
    },
  }))

  assert.deepEqual(host.hitTest(12, 34), { kind: 'vrm', target: 'head' })
  assert.equal(host.hitTest(99, 100), null)
  assert.equal(host.hitTest(Number.NaN, 0), null)
  assert.deepEqual(calls, [[12, 34], [99, 100]])

  await host.destroy()
  assert.equal(host.hitTest(12, 34), null)
})
