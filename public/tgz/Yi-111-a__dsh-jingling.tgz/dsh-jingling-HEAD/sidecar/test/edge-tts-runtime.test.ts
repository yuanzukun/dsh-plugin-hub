import assert from 'node:assert/strict'
import { access, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import test from 'node:test'
import type { WebContents } from 'electron'
import {
  createEdgeTtsIpcHandlers,
  createEdgeTtsRuntime,
  type EdgeTtsCommandOptions,
} from '../electron/edge-tts-runtime'

test('Edge TTS is explicit opt-in and rejects unsafe executable or voice settings', () => {
  assert.deepEqual(createEdgeTtsRuntime({}).config, { provider: 'web-speech' })
  assert.deepEqual(createEdgeTtsRuntime({ SOULDOCK_TTS_PROVIDER: 'EDGE-TTS' }).config, { provider: 'web-speech' })

  const malformedVoice = createEdgeTtsRuntime({
    SOULDOCK_TTS_PROVIDER: 'edge-tts',
    SOULDOCK_EDGE_TTS_VOICE: 'zh-CN-XiaoxiaoNeural --write-media elsewhere.mp3',
  })
  assert.deepEqual(malformedVoice.config, { provider: 'web-speech' })
  assert.match(malformedVoice.configurationError ?? '', /voice identifier/)

  const malformedExecutable = createEdgeTtsRuntime({
    SOULDOCK_TTS_PROVIDER: 'edge-tts',
    SOULDOCK_EDGE_TTS_PYTHON: '\u0000',
  })
  assert.deepEqual(malformedExecutable.config, { provider: 'web-speech' })
  assert.match(malformedExecutable.configurationError ?? '', /Python executable/)
})

test('trusted Edge TTS IPC exposes sanitized config and invokes only Python module arguments without a shell', async () => {
  let executable = ''
  let arguments_: readonly string[] = []
  let options: EdgeTtsCommandOptions | undefined
  let mediaPath = ''
  const runtime = createEdgeTtsRuntime({
    SOULDOCK_TTS_PROVIDER: 'edge-tts',
    SOULDOCK_EDGE_TTS_PYTHON: 'C:\\Python\\python.exe',
  }, {
    runner: async (receivedExecutable, receivedArguments, receivedOptions) => {
      executable = receivedExecutable
      arguments_ = receivedArguments
      options = receivedOptions
      const mediaIndex = receivedArguments.indexOf('--write-media')
      mediaPath = receivedArguments[mediaIndex + 1] ?? ''
      assert.ok(mediaPath)
      await writeFile(mediaPath, new Uint8Array([73, 68, 51, 4]))
    },
  })
  const trusted = { id: 'trusted' } as unknown as WebContents
  const untrusted = { id: 'untrusted' } as unknown as WebContents
  const handlers = createEdgeTtsIpcHandlers(runtime, sender => sender === trusted)

  assert.deepEqual(handlers.getConfig(trusted), { provider: 'edge-tts', voice: 'zh-CN-XiaoxiaoNeural' })
  assert.equal(handlers.getConfig(untrusted), undefined)
  assert.deepEqual(await handlers.synthesize(trusted, '  你好，灵栖。  '), new Uint8Array([73, 68, 51, 4]))
  assert.equal(executable, 'C:\\Python\\python.exe')
  assert.deepEqual(arguments_.slice(0, 6), [
    '-m', 'edge_tts', '--voice', 'zh-CN-XiaoxiaoNeural', '--text', '你好，灵栖。',
  ])
  assert.equal(arguments_[6], '--write-media')
  assert.match(mediaPath, /souldock-edge-tts-/)
  assert.equal(options?.shell, false)
  assert.equal(options?.windowsHide, true)
  assert.equal(options?.timeout, 60_000)
  assert.equal(options?.maxBuffer, 1024 * 1024)
  assert.equal(options?.cwd, dirname(mediaPath))
  await assert.rejects(access(mediaPath))

  assert.equal(await handlers.synthesize(untrusted, 'must not launch Python'), undefined)
})

test('Edge TTS cancellation aborts the current child process and rejects invalid renderer input before launch', async () => {
  let launches = 0
  let started: (() => void) | undefined
  const launched = new Promise<void>(resolve => { started = resolve })
  const runtime = createEdgeTtsRuntime({ SOULDOCK_TTS_PROVIDER: 'edge-tts' }, {
    runner: async (_executable, _arguments, options) => {
      launches += 1
      started?.()
      await new Promise<void>((_resolve, reject) => {
        const stop = (): void => reject(options.signal.reason ?? new Error('aborted'))
        if (options.signal.aborted) stop()
        else options.signal.addEventListener('abort', stop, { once: true })
      })
    },
  })
  const sender = {} as WebContents
  const handlers = createEdgeTtsIpcHandlers(runtime, () => true)
  await assert.rejects(handlers.synthesize(sender, { text: 'object' }), /must be a string/)
  await assert.rejects(handlers.synthesize(sender, '   '), /must not be empty/)
  await assert.rejects(handlers.synthesize(sender, 'x'.repeat(6_001)), /exceeds 6000/)
  assert.equal(launches, 0)

  const pending = handlers.synthesize(sender, 'cancel this')
  await launched
  handlers.cancel(sender)
  await assert.rejects(pending, /cancelled/)
  assert.equal(launches, 1)
})
