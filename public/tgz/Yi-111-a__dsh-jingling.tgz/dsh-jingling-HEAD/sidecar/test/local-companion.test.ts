import assert from 'node:assert/strict'
import test from 'node:test'
import {
  createLocalCompanionState,
  localFileNameOnly,
  localGreetingPeriod,
  resolveLocalCompanionEvent,
  type LocalCompanionContext,
} from '../src/core/local-companion'

function context(nowMs: number, hour = 12, random = () => 0): LocalCompanionContext {
  return { nowMs, hour, random }
}

test('local companion is strictly silent until active bubbles are explicitly enabled', () => {
  const state = createLocalCompanionState()
  const result = resolveLocalCompanionEvent({ type: 'head' }, state, context(1_000))

  assert.deepEqual(result.intent, {
    kind: 'silent',
    eventType: 'head',
    motion: 'nod',
    reason: 'bubbles-disabled',
  })
  assert.equal('text' in result.intent, false)
  assert.equal(result.state, state)
})

test('an opted-in head interaction produces an original local bubble and respects global cooldown', () => {
  const first = resolveLocalCompanionEvent(
    { type: 'head' },
    createLocalCompanionState(),
    context(10_000),
    { activeBubbles: true, interactionCooldownMs: 1_000 },
  )
  assert.equal(first.intent.kind, 'bubble')
  if (first.intent.kind === 'bubble') {
    assert.equal(first.intent.source, 'local')
    assert.equal(first.intent.text, '嗯？我在听。')
    assert.equal(first.intent.motion, 'nod')
  }

  const blocked = resolveLocalCompanionEvent(
    { type: 'body' },
    first.state,
    context(10_999),
    { activeBubbles: true, interactionCooldownMs: 1_000 },
  )
  assert.deepEqual(blocked.intent, {
    kind: 'suppressed',
    eventType: 'body',
    motion: 'settle',
    reason: 'cooldown',
  })

  const next = resolveLocalCompanionEvent(
    { type: 'body' },
    first.state,
    context(11_000),
    { activeBubbles: true, interactionCooldownMs: 1_000 },
  )
  assert.equal(next.intent.kind, 'bubble')
})

test('tail interactions remain distinct from head and body reactions', () => {
  const result = resolveLocalCompanionEvent(
    { type: 'tail' },
    createLocalCompanionState(),
    context(15_000),
    { activeBubbles: true, interactionCooldownMs: 0 },
  )
  assert.equal(result.intent.kind, 'bubble')
  if (result.intent.kind === 'bubble') {
    assert.equal(result.intent.eventType, 'tail')
    assert.equal(result.intent.motion, 'startled')
    assert.match(result.intent.text, /尾巴/u)
  }
})

test('file drop output is basename-only and never retains a supplied path', () => {
  const result = resolveLocalCompanionEvent(
    { type: 'file-drop', fileName: 'C:\\private\\receipts\\august-plan.md' },
    createLocalCompanionState(),
    context(20_000),
    { activeBubbles: true, interactionCooldownMs: 0 },
  )

  assert.equal(result.intent.kind, 'bubble')
  if (result.intent.kind === 'bubble') {
    assert.equal(result.intent.fileName, 'august-plan.md')
    assert.match(result.intent.text, /august-plan\.md/u)
    assert.doesNotMatch(result.intent.text, /private|receipts|C:/u)
  }
  assert.doesNotMatch(JSON.stringify(result.state), /private|receipts|C:/u)
  assert.equal(localFileNameOnly('\\network/share/../keep.txt'), 'keep.txt')
  assert.equal(localFileNameOnly('../..'), '这个文件')
})

test('greetings use injected hour and only show once per local time period', () => {
  const first = resolveLocalCompanionEvent(
    { type: 'time-greeting' },
    createLocalCompanionState(),
    context(30_000, 8),
    { activeBubbles: true, interactionCooldownMs: 0, greetingCooldownMs: 0 },
  )
  assert.equal(first.intent.kind, 'bubble')
  if (first.intent.kind === 'bubble') assert.match(first.intent.text, /早/u)

  const repeatedMorning = resolveLocalCompanionEvent(
    { type: 'time-greeting' },
    first.state,
    context(31_000, 11),
    { activeBubbles: true, interactionCooldownMs: 0, greetingCooldownMs: 0 },
  )
  assert.deepEqual(repeatedMorning.intent, {
    kind: 'suppressed',
    eventType: 'time-greeting',
    motion: 'nod',
    reason: 'greeting-already-shown',
  })

  const afternoon = resolveLocalCompanionEvent(
    { type: 'time-greeting' },
    first.state,
    context(32_000, 14),
    { activeBubbles: true, interactionCooldownMs: 0, greetingCooldownMs: 0 },
  )
  assert.equal(afternoon.intent.kind, 'bubble')
  assert.equal(localGreetingPeriod(5), 'night')
  assert.equal(localGreetingPeriod(6), 'morning')
  assert.equal(localGreetingPeriod(12), 'daytime')
  assert.equal(localGreetingPeriod(18), 'evening')
})

test('injected randomness picks a deterministic line and repeated local line rotates to an alternative', () => {
  const first = resolveLocalCompanionEvent(
    { type: 'walk' },
    createLocalCompanionState(),
    context(40_000, 12, () => 0.99),
    { activeBubbles: true, interactionCooldownMs: 0 },
  )
  assert.equal(first.intent.kind, 'bubble')
  if (first.intent.kind === 'bubble') assert.equal(first.intent.text, '我就在附近。')

  const second = resolveLocalCompanionEvent(
    { type: 'walk' },
    first.state,
    context(40_001, 12, () => 0.99),
    { activeBubbles: true, interactionCooldownMs: 0 },
  )
  assert.equal(second.intent.kind, 'bubble')
  if (second.intent.kind === 'bubble') assert.equal(second.intent.text, '走两步，换换心情。')
})
