import assert from 'node:assert/strict'
import test from 'node:test'
import type { WebContents } from 'electron'
import { createVoicevoxIpcHandlers, createVoicevoxRuntime } from '../electron/voicevox-runtime'

const audioQuery = {
  accent_phrases: [],
  speedScale: 1,
  pitchScale: 0,
  intonationScale: 1,
  volumeScale: 1,
  prePhonemeLength: 0.1,
  postPhonemeLength: 0.1,
  outputSamplingRate: 24_000,
  outputStereo: false,
}

test('VOICEVOX runtime is opt-in and invalid local settings fail closed to Web Speech', () => {
  assert.deepEqual(createVoicevoxRuntime({}).config, { provider: 'web-speech' })
  assert.deepEqual(createVoicevoxRuntime({ SOULDOCK_TTS_PROVIDER: 'VOICEVOX' }).config, { provider: 'web-speech' })

  const remote = createVoicevoxRuntime({
    SOULDOCK_TTS_PROVIDER: 'voicevox-local',
    SOULDOCK_VOICEVOX_URL: 'https://voicevox.example',
  })
  assert.deepEqual(remote.config, { provider: 'web-speech' })
  assert.match(remote.configurationError ?? '', /loopback-only/)

  const invalidSpeaker = createVoicevoxRuntime({
    SOULDOCK_TTS_PROVIDER: 'voicevox-local',
    SOULDOCK_VOICEVOX_SPEAKER: '-1',
  })
  assert.deepEqual(invalidSpeaker.config, { provider: 'web-speech' })
  assert.match(invalidSpeaker.configurationError ?? '', /non-negative integer/)
})

test('trusted IPC exposes only sanitized config and WAV bytes through the two-step engine flow', async () => {
  const urls: URL[] = []
  const fetchMock = (async (input: string | URL | Request) => {
    urls.push(new URL(String(input)))
    if (urls.length === 1) return Response.json(audioQuery)
    return new Response(new Uint8Array([82, 73, 70, 70]))
  }) as typeof fetch
  const runtime = createVoicevoxRuntime({
    SOULDOCK_TTS_PROVIDER: 'voicevox-local',
    SOULDOCK_VOICEVOX_URL: 'http://localhost:50021/private/path',
    SOULDOCK_VOICEVOX_SPEAKER: '7',
  }, { fetch: fetchMock })
  const trusted = { id: 'trusted' } as unknown as WebContents
  const untrusted = { id: 'untrusted' } as unknown as WebContents
  const handlers = createVoicevoxIpcHandlers(runtime, sender => sender === trusted)

  assert.deepEqual(handlers.getConfig(trusted), { provider: 'voicevox-local', speaker: 7 })
  assert.equal(handlers.getConfig(untrusted), undefined)
  const wav = await handlers.synthesize(trusted, '  IPC test  ')
  assert.deepEqual(wav, new Uint8Array([82, 73, 70, 70]))
  assert.deepEqual(urls.map(url => url.pathname), ['/audio_query', '/synthesis'])
  assert.equal(urls[0]?.searchParams.get('speaker'), '7')
  assert.equal(urls[0]?.searchParams.get('text'), 'IPC test')

  assert.equal(await handlers.synthesize(untrusted, 'must not reach engine'), undefined)
  assert.equal(urls.length, 2)
})

test('main service cancellation aborts an in-flight local request', async () => {
  const fetchMock = (async (_input: string | URL | Request, init?: RequestInit) => (
    await new Promise<Response>((_resolve, reject) => {
      const signal = init?.signal
      if (!signal) return reject(new Error('missing signal'))
      const onAbort = (): void => reject(signal.reason ?? new Error('aborted'))
      if (signal.aborted) onAbort()
      else signal.addEventListener('abort', onAbort, { once: true })
    })
  )) as typeof fetch
  const runtime = createVoicevoxRuntime({ SOULDOCK_TTS_PROVIDER: 'voicevox-local' }, { fetch: fetchMock })
  const sender = { id: 'trusted' } as unknown as WebContents
  const handlers = createVoicevoxIpcHandlers(runtime, candidate => candidate === sender)
  const pending = handlers.synthesize(sender, 'cancel this')
  handlers.cancel(sender)
  await assert.rejects(pending, /cancelled/)
})

test('main service rejects non-string, empty and oversized renderer input before fetch', async () => {
  let requests = 0
  const runtime = createVoicevoxRuntime(
    { SOULDOCK_TTS_PROVIDER: 'voicevox-local' },
    { fetch: (async () => { requests += 1; return Response.json(audioQuery) }) as typeof fetch },
  )
  const sender = {} as WebContents
  const handlers = createVoicevoxIpcHandlers(runtime, () => true)
  await assert.rejects(handlers.synthesize(sender, { text: 'object' }), /must be a string/)
  await assert.rejects(handlers.synthesize(sender, '   '), /must not be empty/)
  await assert.rejects(handlers.synthesize(sender, 'x'.repeat(6_001)), /exceeds 6000/)
  assert.equal(requests, 0)
})
