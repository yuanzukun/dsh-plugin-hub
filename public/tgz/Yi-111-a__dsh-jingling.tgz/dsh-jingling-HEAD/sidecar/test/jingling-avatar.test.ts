import assert from 'node:assert/strict'
import { access, readFile } from 'node:fs/promises'
import test from 'node:test'

const rendererRoot = new URL('../src/renderer/', import.meta.url)

test('the public built-in avatar is the aligned Jingling frame set under whalegirl/', async () => {
  const [source, preload, mainSource] = await Promise.all([
    readFile(new URL('sprite-avatar.ts', rendererRoot), 'utf8'),
    readFile(new URL('../electron/preload.ts', import.meta.url), 'utf8'),
    readFile(new URL('../electron/main.ts', import.meta.url), 'utf8'),
  ])
  assert.match(source, /readAvatarFrames\(\)/)
  assert.match(source, /const STABLE_DISPLAY_SIZE = 304/)
  assert.match(source, /setAction: \(action\) => playAction\(action \?\? 'idle'\)/)
  assert.match(source, /setPhase: \(\) => undefined/)
  assert.match(source, /return 'tail'/)
  assert.match(source, /ACTION_FRAMES/)
  assert.match(preload, /readAvatarFrames/)
  assert.match(mainSource, /souldock-sidecar:avatar:read-frames/)
  assert.match(mainSource, /\.\.\/renderer\/whalegirl/)
  for (const action of ['idle', 'walk', 'sleep', 'click']) {
    for (let i = 0; i < 4; i++) {
      await access(new URL(`public/whalegirl/${action}_${i}.png`, rendererRoot))
    }
  }
})

test('the legacy loose frames and sprite sheets are gone from public/', async () => {
  const gitignore = await readFile(new URL('../.gitignore', import.meta.url), 'utf8')
  assert.doesNotMatch(gitignore, /whalegirl\/\*_sheet_generated_\*\.png/)
  assert.doesNotMatch(gitignore, /^src\/renderer\/assets\/whalegirl\/$/m)
  assert.match(gitignore, /^src\/renderer\/assets\/kenney-platformer\/$/m)
  for (const bad of ['idle_sheet.png', 'walk_sheet.png', 'idle_0_old.png']) {
    await assert.rejects(access(new URL(`public/whalegirl/${bad}`, rendererRoot)))
  }
})