import assert from 'node:assert/strict'
import test from 'node:test'
import { applyClickThroughOverlay, createSidecarWindowOptions, isTrustedSidecarSender } from '../electron/window-contract'

test('window contract is transparent, always-on-top, isolated, and absent from taskbar', () => {
  const options = createSidecarWindowOptions({ x: 0, y: 0, width: 1920, height: 1040 }, 'C:\\safe\\preload.mjs')
  assert.equal(options.title, '鲸灵 Sidecar')
  assert.equal(options.transparent, true)
  assert.equal(options.alwaysOnTop, true)
  assert.equal(options.skipTaskbar, true)
  assert.equal(options.frame, false)
  assert.equal(options.focusable, false)
  assert.equal(options.webPreferences?.sandbox, true)
  assert.equal(options.webPreferences?.contextIsolation, true)
  assert.equal(options.webPreferences?.nodeIntegration, false)
})

test('overlay isolation enables click-through, defaults content protection off, and uses all workspaces', () => {
  const calls: unknown[][] = []
  applyClickThroughOverlay({
    setIgnoreMouseEvents: (...args: unknown[]) => { calls.push(['ignore', ...args]) },
    setAlwaysOnTop: (...args: unknown[]) => { calls.push(['top', ...args]) },
    setContentProtection: (...args: unknown[]) => { calls.push(['protect', ...args]) },
    setVisibleOnAllWorkspaces: (...args: unknown[]) => { calls.push(['workspaces', ...args]) },
  } as never)
  assert.deepEqual(calls, [
    ['ignore', true, { forward: true }],
    ['top', true, 'screen-saver'],
    ['protect', false],
    ['workspaces', true, { visibleOnFullScreen: true }],
  ])
})

test('content protection can be enabled explicitly', () => {
  const calls: unknown[][] = []
  applyClickThroughOverlay({
    setIgnoreMouseEvents: (...args: unknown[]) => { calls.push(['ignore', ...args]) },
    setAlwaysOnTop: (...args: unknown[]) => { calls.push(['top', ...args]) },
    setContentProtection: (...args: unknown[]) => { calls.push(['protect', ...args]) },
    setVisibleOnAllWorkspaces: (...args: unknown[]) => { calls.push(['workspaces', ...args]) },
  } as never, { contentProtection: true })
  assert.deepEqual(calls.find(call => call[0] === 'protect'), ['protect', true])
})

test('privileged IPC accepts only the exact sidecar webContents sender', () => {
  const webContents = { identity: 'sidecar' }
  const window = { webContents } as never
  assert.equal(isTrustedSidecarSender(webContents, window), true)
  assert.equal(isTrustedSidecarSender({ identity: 'sidecar' }, window), false)
  assert.equal(isTrustedSidecarSender(webContents, undefined), false)
})
