import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

const rendererRoot = new URL('../src/renderer/', import.meta.url)

test('strict renderer CSP permits only the Pixi blob worker and local model blobs', async () => {
  const html = await readFile(new URL('index.html', rendererRoot), 'utf8')
  assert.match(html, /script-src 'self'/)
  assert.match(html, /worker-src 'self' blob:/)
  assert.match(html, /connect-src 'self' blob:/)
  assert.doesNotMatch(html, /script-src[^;]*'unsafe-eval'/)
  assert.doesNotMatch(html, /https?:\/\//)
})

test('renderer uses the strict-CSP Pixi polyfill without a top-level await', async () => {
  const source = await readFile(new URL('main.ts', rendererRoot), 'utf8')
  assert.match(source, /import 'pixi\.js\/unsafe-eval'/)
  assert.match(source, /async function bootstrap\(\)/)
  assert.match(source, /void bootstrap\(\)\.catch/)
  const bootstrapOffset = source.indexOf('async function bootstrap')
  assert.ok(bootstrapOffset > 0)
  assert.doesNotMatch(source.slice(0, bootstrapOffset), /\bawait\b/)
})

test('production renderer keeps avatar frames as local files instead of data URIs', async () => {
  const config = await readFile(new URL('../electron.vite.config.ts', import.meta.url), 'utf8')
  assert.match(config, /assetsInlineLimit:\s*0/)
})

test('collapsed desktop state renders only the avatar and hides all conversation chrome', async () => {
  const [html, css, source] = await Promise.all([
    readFile(new URL('index.html', rendererRoot), 'utf8'),
    readFile(new URL('styles.css', rendererRoot), 'utf8'),
    readFile(new URL('main.ts', rendererRoot), 'utf8'),
  ])
  assert.match(html, /id="pet-shell"[^>]*data-open="false"/)
  assert.match(html, /id="avatar-stage"/)
  assert.doesNotMatch(html, /id="speech-bubble"|id="connection-chip"/)
  assert.match(css, /#pet-shell\[data-open="false"\] #conversation-panel/)
  assert.match(css, /visibility:\s*hidden/)
  assert.match(source, /avatar\.hitTest\(event\.clientX, event\.clientY\)/)
  assert.match(source, /setConversationOpen\(true\)/)
  assert.match(source, /isClickLikePointerGesture/)
  assert.match(html, /id="ambient-interactions-toggle"/)
  assert.match(source, /activeBubbles: source === 'explicit' \|\| ambientInteractions/)
  assert.match(source, /document\.createElement\('div'\)/)
  assert.match(source, /local-reaction-bubble/)
})

test('expanded panel exposes isolated companion and workspace modes with compact navigation', async () => {
  const [html, css, source] = await Promise.all([
    readFile(new URL('index.html', rendererRoot), 'utf8'),
    readFile(new URL('styles.css', rendererRoot), 'utf8'),
    readFile(new URL('main.ts', rendererRoot), 'utf8'),
  ])
  assert.match(html, /id="surface-switcher" role="tablist"/)
  assert.match(html, /id="companion-mode-button"[^>]*role="tab"/)
  assert.match(html, /id="workspace-mode-button"[^>]*role="tab"/)
  assert.match(html, /鲸灵陪伴/)
  assert.match(html, /文件夹任务/)
  assert.match(html, /仅此文件夹/)
  assert.doesNotMatch(html, /像 Codex 一样|工作 Agent/)
  assert.match(css, /@media \(max-width: 780px\)/)
  assert.match(css, /#workspace-view\[data-detail="false"\] #workspace-task-pane/)
  assert.match(source, /new SidecarChatController/)
  assert.match(source, /new SidecarWorkspaceController/)
  assert.match(source, /ArrowRight.*ArrowDown/)
  assert.match(source, /Home/)
  assert.match(source, /End/)
})
