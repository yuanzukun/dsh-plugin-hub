import assert from 'node:assert/strict'
import test from 'node:test'
import { SidecarChatController, type SidecarChatPort } from '../src/core/chat-controller'
import type { ChatOpen, ChatPoll } from '../src/core/protocol'

function waitFor(predicate: () => boolean, timeoutMilliseconds = 1000): Promise<void> {
  const started = Date.now()
  return new Promise((resolve, reject) => {
    const check = (): void => {
      if (predicate()) return resolve()
      if (Date.now() - started > timeoutMilliseconds) return reject(new Error('Timed out waiting for chat state'))
      setTimeout(check, 2)
    }
    check()
  })
}

class FakeChatPort implements SidecarChatPort {
  readonly sends: Array<{ chatId: string; clientMessageId: string; text: string; clientTimeZone?: string }> = []
  closeCalls = 0
  pending?: { resolve: (value: ChatPoll) => void; reject: (error: unknown) => void }

  async open(): Promise<ChatOpen> {
    return {
      version: 1,
      chatId: 'chat-capability',
      sequence: 0,
      status: 'idle',
      persona: { id: 'lingqi', name: '灵栖' },
      messages: [],
      hasOlder: false,
      limits: { inputCodePoints: 8000 },
    }
  }

  async send(payload: { chatId: string; clientMessageId: string; text: string; clientTimeZone?: string }): Promise<{ accepted: true; clientMessageId: string }> {
    this.sends.push(payload)
    return { accepted: true, clientMessageId: payload.clientMessageId }
  }

  poll(_payload: { chatId: string; afterSequence: number; timeoutMilliseconds: number }, signal?: AbortSignal): Promise<ChatPoll> {
    return new Promise((resolve, reject) => {
      this.pending = { resolve, reject }
      signal?.addEventListener('abort', () => reject(signal.reason), { once: true })
    })
  }

  async cancel(): Promise<{ accepted: true }> {
    return { accepted: true }
  }

  async close(): Promise<{ closed: true }> {
    this.closeCalls += 1
    return { closed: true }
  }

  push(value: ChatPoll): void {
    const pending = this.pending
    this.pending = undefined
    if (!pending) throw new Error('No chat poll is pending')
    pending.resolve(value)
  }
}

test('chat controller opens a dedicated chat, reconciles optimistic user text, and applies a final reply', async () => {
  const port = new FakeChatPort()
  const controller = new SidecarChatController(port, () => 'client-1')
  await controller.open()
  assert.equal(controller.state.status, 'idle')
  assert.equal(controller.state.persona.name, '灵栖')

  await controller.send('你好', 'Asia/Shanghai')
  assert.equal(controller.state.messages[0]?.id, 'sidecar-client-1')
  assert.equal(port.sends[0]?.text, '你好')
  await waitFor(() => port.pending !== undefined)

  port.push({
    version: 1,
    sequence: 3,
    status: 'idle',
    events: [
      {
        sequence: 1,
        sourceSeq: 1,
        at: 1000,
        type: 'user-message',
        messageId: 'session-message-1',
        clientMessageId: 'sidecar-client-1',
        text: '你好',
      },
      {
        sequence: 2,
        sourceSeq: 2,
        at: 1100,
        type: 'assistant-delta',
        turn: 1,
        step: 1,
        delta: '你',
      },
      {
        sequence: 3,
        sourceSeq: 3,
        at: 1200,
        type: 'assistant-final',
        turn: 1,
        step: 1,
        messageId: 'assistant-1',
        text: '你好，我在。',
      },
    ],
  })

  await waitFor(() => controller.state.messages.some(message => message.id === 'assistant-1'))
  assert.deepEqual(controller.state.messages.map(message => [message.role, message.text]), [
    ['user', '你好'],
    ['assistant', '你好，我在。'],
  ])
  assert.equal(controller.state.partial, '')
  assert.equal(controller.state.status, 'idle')
  await controller.close()
  assert.equal(port.closeCalls, 1)
  assert.equal(controller.state.status, 'closed')
})

test('chat controller rejects slash commands before they reach DSH', async () => {
  const port = new FakeChatPort()
  const controller = new SidecarChatController(port, () => 'client-2')
  await controller.open()
  await assert.rejects(controller.send(' /reset'), /Slash commands/)
  assert.equal(port.sends.length, 0)
  await controller.close()
})

test('chat controller keeps the public generation error visible after the idle status edge', async () => {
  const port = new FakeChatPort()
  const controller = new SidecarChatController(port, () => 'client-error')
  await controller.open()
  await waitFor(() => port.pending !== undefined)

  port.push({
    version: 1,
    sequence: 2,
    status: 'idle',
    events: [
      { sequence: 1, at: 1000, type: 'error', code: 'failed', message: '生成失败，请稍后重试。' },
      { sequence: 2, at: 1001, type: 'status', status: 'idle' },
    ],
  })

  await waitFor(() => controller.state.error !== undefined)
  assert.equal(controller.state.status, 'idle')
  assert.equal(controller.state.error, '生成失败，请稍后重试。')
  await controller.close()
})
