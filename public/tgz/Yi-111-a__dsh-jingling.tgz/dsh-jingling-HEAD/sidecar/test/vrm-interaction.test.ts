import assert from 'node:assert/strict'
import test from 'node:test'
import type { VRM } from '@pixiv/three-vrm'
import { Bone, Group } from 'three'
import {
  createVrmInteractionColliders,
  getVrmInteractionTargetFromObjectName,
  isClickLikePointerGesture,
} from '../src/renderer/upstream/airi/vrm-interaction'

test('maps AIRI collider names to typed VRM interaction targets', () => {
  assert.equal(getVrmInteractionTargetFromObjectName('vrm_interaction_leftUpperArm'), 'leftUpperArm')
  assert.equal(getVrmInteractionTargetFromObjectName('vrm_interaction_rightHand'), 'rightHand')
  assert.equal(getVrmInteractionTargetFromObjectName('avatar_mesh'), null)
  assert.equal(getVrmInteractionTargetFromObjectName('vrm_interaction_unknown'), null)
})

test('uses AIRI click threshold to keep dragging distinct from interaction', () => {
  assert.equal(isClickLikePointerGesture({ x: 10, y: 10 }, { x: 15, y: 13 }), true)
  assert.equal(isClickLikePointerGesture({ x: 10, y: 10 }, { x: 20, y: 10 }), false)
  assert.equal(isClickLikePointerGesture({ x: 0, y: 0 }, { x: 3, y: 4 }, 5), true)
})

test('creates colliders only for available normalized bones and disposes them idempotently', () => {
  const scene = new Group()
  const head = new Bone()
  const rightHand = new Bone()
  scene.add(head, rightHand)
  const bones = new Map<string, Bone>([
    ['head', head],
    ['rightHand', rightHand],
  ])
  const vrm = {
    scene,
    humanoid: {
      getNormalizedBoneNode: (name: string) => bones.get(name) ?? null,
    },
  } as unknown as VRM

  const colliderSet = createVrmInteractionColliders(vrm)
  assert.deepEqual(colliderSet.colliders.map(collider => collider.name), [
    'vrm_interaction_head',
    'vrm_interaction_rightHand',
  ])
  assert.equal(colliderSet.colliders[0]?.parent, head)
  assert.equal(colliderSet.colliders[1]?.parent, rightHand)

  colliderSet.dispose()
  assert.equal(colliderSet.colliders.length, 0)
  assert.equal(head.children.length, 0)
  assert.equal(rightHand.children.length, 0)
  assert.doesNotThrow(() => colliderSet.dispose())
})
