import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'
import {
  workspaceTaskCreateRequestSchema,
  workspaceTaskOpenSchema,
  workspaceTaskPollRequestSchema,
} from '../src/core/protocol'

test('workspace IPC request DTOs reject ambient authority and malformed poll values', () => {
  assert.deepEqual(
    workspaceTaskCreateRequestSchema.parse({ cwd: 'C:\\work\\demo', title: 'Demo' }),
    { cwd: 'C:\\work\\demo', title: 'Demo' },
  )
  assert.throws(() => workspaceTaskCreateRequestSchema.parse({
    cwd: 'C:\\work\\demo',
    fileContents: 'secret',
  }))
  assert.throws(() => workspaceTaskCreateRequestSchema.parse({ cwd: 'C:\0work' }))
  assert.throws(() => workspaceTaskPollRequestSchema.parse({
    taskId: 'task-1',
    afterSequence: -1,
    timeoutMilliseconds: 20_000,
  }))
})

test('workspace task response schema strips host-only identifiers', () => {
  const parsed = workspaceTaskOpenSchema.parse({
    version: 1,
    sessionId: 'must-not-cross-the-bridge',
    task: {
      taskId: 'task-1',
      title: 'Demo',
      workspacePath: 'C:\\work\\demo',
      workspaceName: 'demo',
      updatedAt: 1000,
      status: 'idle',
      sessionId: 'also-private',
    },
    sequence: 0,
    status: 'idle',
    messages: [],
    hasOlder: false,
    limits: { inputCodePoints: 8000 },
  })
  assert.equal('sessionId' in parsed, false)
  assert.equal('sessionId' in parsed.task, false)
})

test('native picker is directory-only, strict-sender guarded, and performs no file read', async () => {
  const source = await readFile(new URL('../electron/main.ts', import.meta.url), 'utf8')
  const start = source.indexOf("ipcMain.handle('souldock-sidecar:workspace:pick-directory'")
  const end = source.indexOf("ipcMain.handle('souldock-sidecar:workspace:list'", start)
  assert.ok(start >= 0 && end > start)
  const picker = source.slice(start, end)
  assert.match(picker, /isTrustedSidecarSender/)
  assert.match(picker, /properties:\s*\['openDirectory', 'createDirectory'\]/)
  assert.doesNotMatch(picker, /readFile|readdir|createReadStream/)
  assert.match(source, /allowedWorkspaceDirectories\.add\(workspaceDirectoryKey\(path\)\)/)
  assert.match(source, /Workspace directory must be selected by the user first/)
})
