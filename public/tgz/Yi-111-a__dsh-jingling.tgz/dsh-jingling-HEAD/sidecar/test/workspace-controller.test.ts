import assert from 'node:assert/strict'
import test from 'node:test'
import {
  SidecarWorkspaceController,
  type PickedWorkspaceDirectory,
  type SidecarWorkspacePort,
} from '../src/core/workspace-controller'
import type {
  WorkspaceList,
  WorkspaceTaskOpen,
  WorkspaceTaskPoll,
  WorkspaceTaskSummary,
} from '../src/core/protocol'

function waitFor(predicate: () => boolean, timeoutMilliseconds = 1000): Promise<void> {
  const started = Date.now()
  return new Promise((resolve, reject) => {
    const check = (): void => {
      if (predicate()) return resolve()
      if (Date.now() - started > timeoutMilliseconds) return reject(new Error('Timed out waiting for workspace state'))
      setTimeout(check, 2)
    }
    check()
  })
}

function task(taskId = 'task-1', path = 'C:\\work\\demo'): WorkspaceTaskSummary {
  return {
    taskId,
    title: taskId === 'task-1' ? 'Inspect project' : 'Second task',
    workspacePath: path,
    workspaceName: 'demo',
    updatedAt: 1000,
    status: 'idle',
  }
}

function opened(value = task()): WorkspaceTaskOpen {
  return {
    version: 1,
    task: value,
    sequence: 0,
    status: 'idle',
    messages: [],
    hasOlder: false,
    limits: { inputCodePoints: 8000 },
  }
}

class FakeWorkspacePort implements SidecarWorkspacePort {
  readonly sends: Array<{ taskId: string; clientMessageId: string; text: string; clientTimeZone?: string }> = []
  readonly closeCalls: string[] = []
  pending?: { resolve: (value: WorkspaceTaskPoll) => void; reject: (error: unknown) => void }

  async pickDirectory(): Promise<PickedWorkspaceDirectory> {
    return { path: 'C:\\work\\demo', name: 'demo' }
  }

  async list(): Promise<WorkspaceList> {
    return {
      version: 1,
      workspaces: [{
        workspaceId: 'workspace-1',
        title: 'demo',
        path: 'C:\\work\\demo',
        tasks: [task()],
      }],
    }
  }

  async create(payload: { cwd: string; title?: string }): Promise<WorkspaceTaskOpen> {
    return opened(task('task-1', payload.cwd))
  }

  async open(payload: { taskId: string }): Promise<WorkspaceTaskOpen> {
    return opened(task(payload.taskId))
  }

  async send(payload: { taskId: string; clientMessageId: string; text: string; clientTimeZone?: string }): Promise<{ accepted: true; clientMessageId: string }> {
    this.sends.push(payload)
    return { accepted: true, clientMessageId: payload.clientMessageId }
  }

  poll(_payload: { taskId: string; afterSequence: number; timeoutMilliseconds: number }, signal?: AbortSignal): Promise<WorkspaceTaskPoll> {
    return new Promise((resolve, reject) => {
      this.pending = { resolve, reject }
      signal?.addEventListener('abort', () => reject(signal.reason), { once: true })
    })
  }

  async cancel(): Promise<{ accepted: true }> {
    return { accepted: true }
  }

  async close(payload: { taskId: string }): Promise<{ closed: true }> {
    this.closeCalls.push(payload.taskId)
    return { closed: true }
  }

  push(value: WorkspaceTaskPoll): void {
    const pending = this.pending
    this.pending = undefined
    if (!pending) throw new Error('No workspace poll is pending')
    pending.resolve(value)
  }
}

test('workspace controller lists folders and runs a filtered task conversation', async () => {
  const port = new FakeWorkspacePort()
  const controller = new SidecarWorkspaceController(port, () => 'client-1')

  assert.deepEqual(await controller.pickDirectory(), { path: 'C:\\work\\demo', name: 'demo' })
  await controller.refresh()
  assert.equal(controller.state.workspaces[0]?.tasks[0]?.taskId, 'task-1')
  await controller.create('C:\\work\\demo', 'Inspect project')
  assert.equal(controller.state.activeTask?.workspacePath, 'C:\\work\\demo')

  await controller.send('Run the tests', 'Asia/Shanghai')
  assert.equal(port.sends[0]?.text, 'Run the tests')
  assert.equal(controller.state.messages[0]?.id, 'sidecar-workspace-client-1')
  await waitFor(() => port.pending !== undefined)

  port.push({
    version: 1,
    sequence: 3,
    status: 'idle',
    events: [
      {
        sequence: 1,
        sourceSeq: 1,
        at: 1100,
        type: 'user-message',
        messageId: 'user-1',
        clientMessageId: 'sidecar-workspace-client-1',
        text: 'Run the tests',
      },
      {
        sequence: 2,
        sourceSeq: 2,
        at: 1200,
        type: 'assistant-delta',
        turn: 1,
        step: 1,
        delta: 'All ',
      },
      {
        sequence: 3,
        sourceSeq: 3,
        at: 1300,
        type: 'assistant-final',
        turn: 1,
        step: 1,
        messageId: 'assistant-1',
        text: 'All tests pass.',
      },
    ],
  })

  await waitFor(() => controller.state.messages.some(message => message.id === 'assistant-1'))
  assert.deepEqual(controller.state.messages.map(message => [message.role, message.text]), [
    ['user', 'Run the tests'],
    ['assistant', 'All tests pass.'],
  ])
  assert.equal(controller.state.activeTask?.status, 'idle')
  assert.equal(controller.state.partial, '')
  await controller.close()
  assert.deepEqual(port.closeCalls, ['task-1'])
  assert.equal(controller.state.status, 'closed')
  assert.equal(controller.state.workspaces.length, 1)
})

test('opening another workspace task closes only the previous task handle', async () => {
  const port = new FakeWorkspacePort()
  const controller = new SidecarWorkspaceController(port)
  await controller.open('task-1')
  await waitFor(() => port.pending !== undefined)
  await controller.open('task-2')
  await waitFor(() => port.closeCalls.includes('task-1'))
  assert.equal(controller.state.activeTask?.taskId, 'task-2')
  assert.equal(port.closeCalls.includes('task-2'), false)
  await controller.close()
})

test('workspace controller exposes only the safe needs-input status edge', async () => {
  const port = new FakeWorkspacePort()
  const controller = new SidecarWorkspaceController(port)
  await controller.open('task-1')
  await waitFor(() => port.pending !== undefined)
  port.push({
    version: 1,
    sequence: 1,
    status: 'needs-input',
    events: [{ sequence: 1, at: 1200, type: 'status', status: 'needs-input' }],
  })
  await waitFor(() => controller.state.status === 'needs-input')
  assert.equal(controller.state.activeTask?.status, 'needs-input')
  assert.equal(controller.state.error, undefined)
  await controller.close()
})

test('a stale workspace refresh cannot overwrite a task opened while listing', async () => {
  const port = new FakeWorkspacePort()
  let resolveList!: (value: WorkspaceList) => void
  port.list = () => new Promise(resolve => { resolveList = resolve })
  const controller = new SidecarWorkspaceController(port)

  const refreshing = controller.refresh()
  await waitFor(() => controller.state.status === 'loading')
  await controller.open('task-2')
  resolveList({
    version: 1,
    workspaces: [{
      workspaceId: 'workspace-1',
      title: 'demo',
      path: 'C:\\work\\demo',
      tasks: [task('task-1')],
    }],
  })
  await refreshing

  assert.equal(controller.state.activeTask?.taskId, 'task-2')
  assert.equal(controller.state.status, 'idle')
  await controller.close()
})

test('a failed send from an old task cannot mark the newly opened task as failed', async () => {
  const port = new FakeWorkspacePort()
  let rejectSend!: (error: unknown) => void
  port.send = () => new Promise((_resolve, reject) => { rejectSend = reject })
  const controller = new SidecarWorkspaceController(port, () => 'stale-send')

  await controller.open('task-1')
  const sending = controller.send('Only for task one').catch(error => error)
  assert.equal(controller.state.status, 'running')
  await controller.open('task-2')
  rejectSend(new Error('task one failed late'))
  await sending

  assert.equal(controller.state.activeTask?.taskId, 'task-2')
  assert.equal(controller.state.status, 'idle')
  assert.equal(controller.state.error, undefined)
  assert.equal(controller.state.messages.length, 0)
  await controller.close()
})
