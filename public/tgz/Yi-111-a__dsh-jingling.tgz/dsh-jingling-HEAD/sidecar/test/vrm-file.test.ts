import assert from 'node:assert/strict'
import test from 'node:test'
import { MAX_VRM_FILE_BYTES, validateLocalVrmFile } from '../src/renderer/adapters/vrm'

test('accepts only non-empty local .vrm files inside the bounded size', () => {
  assert.doesNotThrow(() => validateLocalVrmFile({ name: 'companion.VRM', size: 1024 }))
  assert.throws(() => validateLocalVrmFile({ name: 'companion.glb', size: 1024 }), /\.vrm/)
  assert.throws(() => validateLocalVrmFile({ name: 'companion.vrm', size: 0 }), /为空/)
  assert.throws(
    () => validateLocalVrmFile({ name: 'companion.vrm', size: MAX_VRM_FILE_BYTES + 1 }),
    /200 MB/,
  )
})
