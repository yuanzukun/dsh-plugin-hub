import assert from 'node:assert/strict'
import test from 'node:test'
import {
  VoicevoxHttpError,
  VoicevoxLocalClient,
  VoicevoxLocalTtsProvider,
  normalizeVoicevoxLoopbackBaseUrl,
  type VoicevoxWavPlayback,
} from '../src/renderer/adapters/voicevox-local'

const audioQuery = {
  accent_phrases: [],
  speedScale: 1,
  pitchScale: 0,
  intonationScale: 1,
  volumeScale: 1,
  prePhonemeLength: 0.1,
  postPhonemeLength: 0.1,
  outputSamplingRate: 24_000,
  outputStereo: false,
}

test('accepts only credential-free loopback HTTP(S) base URLs', () => {
  assert.equal(normalizeVoicevoxLoopbackBaseUrl('http://localhost:50021/docs?q=x').href, 'http://localhost:50021/')
  assert.equal(normalizeVoicevoxLoopbackBaseUrl('http://[::1]:50021').href, 'http://[::1]:50021/')
  assert.throws(() => normalizeVoicevoxLoopbackBaseUrl('https://voicevox.example'), /loopback-only/)
  assert.throws(() => normalizeVoicevoxLoopbackBaseUrl('file:///voicevox'), /HTTP or HTTPS/)
  assert.throws(() => normalizeVoicevoxLoopbackBaseUrl('http://user:secret@127.0.0.1:50021'), /credentials/)
})

test('calls audio_query then synthesis with the official minimum API flow and no auth', async () => {
  const requests: Array<{ url: URL, init?: RequestInit }> = []
  const fetchMock = (async (input: string | URL | Request, init?: RequestInit) => {
    requests.push({ url: new URL(String(input)), init })
    if (requests.length === 1) return Response.json(audioQuery)
    return new Response(new Uint8Array([82, 73, 70, 70]), {
      headers: { 'Content-Type': 'audio/wav' },
    })
  }) as typeof fetch
  const client = new VoicevoxLocalClient({ fetch: fetchMock, defaultSpeaker: 3 })

  const wav = await client.synthesize({
    text: '  こんにちは & SoulDock  ',
    enableInterrogativeUpspeak: false,
    transformAudioQuery: query => ({ ...query, speedScale: 1.25 }),
  })

  assert.equal(wav.size, 4)
  assert.equal(requests[0]?.url.pathname, '/audio_query')
  assert.equal(requests[0]?.url.searchParams.get('text'), 'こんにちは & SoulDock')
  assert.equal(requests[0]?.url.searchParams.get('speaker'), '3')
  assert.equal(requests[1]?.url.pathname, '/synthesis')
  assert.equal(requests[1]?.url.searchParams.get('speaker'), '3')
  assert.equal(requests[1]?.url.searchParams.get('enable_interrogative_upspeak'), 'false')
  assert.equal(requests[0]?.init?.method, 'POST')
  assert.equal(requests[1]?.init?.method, 'POST')
  assert.equal(requests[0]?.init?.credentials, 'omit')
  assert.equal(requests[1]?.init?.credentials, 'omit')
  assert.equal(requests[0]?.init?.redirect, 'error')
  assert.equal(requests[1]?.init?.redirect, 'error')
  assert.equal(new Headers(requests[0]?.init?.headers).has('authorization'), false)
  assert.equal(new Headers(requests[1]?.init?.headers).has('authorization'), false)
  assert.equal(JSON.parse(String(requests[1]?.init?.body)).speedScale, 1.25)
})

function abortingFetch(): typeof fetch {
  return (async (_input: string | URL | Request, init?: RequestInit) => await new Promise<Response>((_resolve, reject) => {
    const signal = init?.signal
    if (!signal) return reject(new Error('missing request signal'))
    const onAbort = (): void => reject(signal.reason ?? new Error('aborted'))
    if (signal.aborted) onAbort()
    else signal.addEventListener('abort', onAbort, { once: true })
  })) as typeof fetch
}

test('enforces one total deadline across synthesis requests', async () => {
  const client = new VoicevoxLocalClient({ fetch: abortingFetch(), defaultDeadlineMilliseconds: 10 })
  await assert.rejects(client.synthesize({ text: '期限テスト' }), /exceeded 10 ms deadline/)
})

test('the same total deadline also aborts a stalled synthesis step', async () => {
  let call = 0
  const fetchMock = (async (_input: string | URL | Request, init?: RequestInit) => {
    if (++call === 1) return Response.json(audioQuery)
    return await new Promise<Response>((_resolve, reject) => {
      const signal = init?.signal
      if (!signal) return reject(new Error('missing request signal'))
      const onAbort = (): void => reject(signal.reason ?? new Error('aborted'))
      if (signal.aborted) onAbort()
      else signal.addEventListener('abort', onAbort, { once: true })
    })
  }) as typeof fetch
  const client = new VoicevoxLocalClient({ fetch: fetchMock, defaultDeadlineMilliseconds: 10 })
  await assert.rejects(client.synthesize({ text: '二段階の期限テスト' }), /exceeded 10 ms deadline/)
  assert.equal(call, 2)
})

test('forwards caller abort without waiting for the deadline', async () => {
  const controller = new AbortController()
  const client = new VoicevoxLocalClient({ fetch: abortingFetch(), defaultDeadlineMilliseconds: 10_000 })
  const pending = client.synthesize({ text: '中止テスト', signal: controller.signal })
  controller.abort(new Error('caller stopped'))
  await assert.rejects(pending, /caller stopped/)
})

test('surfaces bounded endpoint errors and rejects empty engine audio', async () => {
  const failed = new VoicevoxLocalClient({
    fetch: (async () => new Response('engine unavailable', { status: 503 })) as typeof fetch,
  })
  await assert.rejects(
    failed.synthesize({ text: 'test' }),
    error => error instanceof VoicevoxHttpError
      && error.endpoint === 'audio_query'
      && error.status === 503,
  )

  let call = 0
  const emptyAudio = new VoicevoxLocalClient({
    fetch: (async () => ++call === 1 ? Response.json(audioQuery) : new Response()) as typeof fetch,
  })
  await assert.rejects(emptyAudio.synthesize({ text: 'test' }), /empty audio/)
})

test('provider cancellation aborts synthesis and stops playback', async () => {
  let stopped = 0
  const playback: VoicevoxWavPlayback = {
    play: async () => undefined,
    stop: () => { stopped += 1 },
  }
  const provider = new VoicevoxLocalTtsProvider({
    fetch: abortingFetch(),
    playback,
    defaultDeadlineMilliseconds: 10_000,
  })
  const pending = provider.speak({ text: 'cancel me' })
  await provider.cancel()
  await assert.rejects(pending, /cancelled/)
  assert.equal(stopped, 2)
})
