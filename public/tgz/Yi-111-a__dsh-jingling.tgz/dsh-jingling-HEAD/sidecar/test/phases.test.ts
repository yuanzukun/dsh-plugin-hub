import assert from 'node:assert/strict'
import test from 'node:test'
import { isSoulDockPhase, PHASE_PRESENTATION, SOULDOCK_PHASES } from '../src/core/phases'

test('all seven SoulDock phases have a renderer presentation', () => {
  assert.equal(SOULDOCK_PHASES.length, 7)
  assert.deepEqual(Object.keys(PHASE_PRESENTATION), [...SOULDOCK_PHASES])
  for (const phase of SOULDOCK_PHASES) {
    assert.equal(isSoulDockPhase(phase), true)
    assert.ok(PHASE_PRESENTATION[phase].animationSpeed > 0)
  }
  assert.equal(isSoulDockPhase('speaking'), false)
})

