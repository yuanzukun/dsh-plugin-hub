import assert from 'node:assert/strict'
import test from 'node:test'
import { AssistantEventCursor } from '../src/renderer/assistant-events'
import type { SidecarEvent } from '../src/core/protocol'

function assistant(sequence: number, text = `message-${sequence}`): SidecarEvent {
  return {
    sequence,
    type: 'assistant-message',
    at: '2026-08-14T00:00:00.000Z',
    sessionId: 'session-a',
    messageId: `session-a:${sequence}`,
    text,
    completed: true,
  }
}

test('deduplicates assistant events inside one DSH connection epoch', () => {
  const cursor = new AssistantEventCursor()
  assert.deepEqual(cursor.take(1, 5, [assistant(5), assistant(4)]).map(event => event.sequence), [4, 5])
  assert.deepEqual(cursor.take(1, 5, [assistant(5)]), [])
})

test('accepts low sequences after DSH sequence rollback', () => {
  const cursor = new AssistantEventCursor()
  cursor.take(1, 20, [assistant(20)])
  assert.deepEqual(cursor.take(1, 1, [assistant(1, 'after restart')]).map(event => event.sequence), [1])
})

test('accepts a reused sequence after a new connection epoch', () => {
  const cursor = new AssistantEventCursor()
  cursor.take(1, 7, [assistant(7, 'old epoch')])
  assert.deepEqual(cursor.take(2, 7, [assistant(7, 'new epoch')]).map(event => event.text), ['new epoch'])
})
