import assert from 'node:assert/strict'
import test from 'node:test'
import { DshSidecarClient, normalizeLoopbackBaseUrl } from '../src/core/dsh-client'

const status = {
  version: 1,
  sequence: 7,
  persona: { id: 'default', name: 'Mochi' },
  runtime: { phase: 'thinking', detail: null, lastEvent: null, updatedAt: null },
  capabilities: { assistantText: true, voiceOutput: true, voiceInput: false },
  privacy: 'No memories, proposals, persona prompt, tool arguments, screen, camera, microphone, or clipboard data.',
}

function serverResponse(rpcId: string, value: unknown): Response {
  return Response.json({
    type: 'server-response',
    rpcId,
    result: { ok: true, value: { ok: true, value } },
  })
}

test('status sends the exact DSH Connection envelope and unwraps both ok layers', async () => {
  const requests: Array<{ url: string; init?: RequestInit }> = []
  const fetchMock = (async (input: string | URL | Request, init?: RequestInit) => {
    requests.push({ url: String(input), init })
    return serverResponse('rpc-fixed', status)
  }) as typeof fetch
  const client = new DshSidecarClient({ fetch: fetchMock, rpcId: () => 'rpc-fixed' })

  assert.deepEqual(await client.status(), status)
  assert.equal(requests[0]?.url, 'http://127.0.0.1:3080/souldock/sidecar/status')
  assert.equal(requests[0]?.init?.method, 'POST')
  assert.deepEqual(JSON.parse(String(requests[0]?.init?.body)), {
    type: 'client-request',
    rpcId: 'rpc-fixed',
    method: 'sidecar/status',
    payload: {},
  })
})

test('poll sends afterSequence and timeoutMilliseconds', async () => {
  let body: unknown
  const fetchMock = (async (_input: string | URL | Request, init?: RequestInit) => {
    body = JSON.parse(String(init?.body))
    return serverResponse('poll-id', {
      ...status,
      sequence: 8,
      events: [{
        sequence: 8,
        type: 'assistant-message',
        at: '2026-08-14T00:00:00.000Z',
        sessionId: 'session-a',
        messageId: 'session-a:8',
        text: 'Hello from DSH',
        completed: true,
      }],
    })
  }) as typeof fetch
  const client = new DshSidecarClient({ fetch: fetchMock, rpcId: () => 'poll-id' })

  const result = await client.poll({ afterSequence: 7, timeoutMilliseconds: 20_000 })
  assert.equal(result.sequence, 8)
  assert.deepEqual(body, {
    type: 'client-request',
    rpcId: 'poll-id',
    method: 'sidecar/poll',
    payload: { afterSequence: 7, timeoutMilliseconds: 20_000 },
  })
})

test('rejects non-loopback URLs before any network request', () => {
  assert.throws(() => normalizeLoopbackBaseUrl('https://example.com'), /must be loopback/)
  assert.throws(() => normalizeLoopbackBaseUrl('file:///tmp/dsh'), /HTTP or HTTPS/)
  assert.equal(normalizeLoopbackBaseUrl('http://localhost:3080/path').href, 'http://localhost:3080/')
})

test('rejects mismatched rpcId', async () => {
  const fetchMock = (async () => serverResponse('wrong-id', status)) as typeof fetch
  const client = new DshSidecarClient({ fetch: fetchMock, rpcId: () => 'expected-id' })
  await assert.rejects(client.status(), /mismatched rpcId/)
})

test('rejects an inner plugin error and malformed DTO phase', async () => {
  const errorFetch = (async () => Response.json({
    type: 'server-response',
    rpcId: 'rpc-id',
    result: { ok: true, value: { ok: false, error: { message: 'not authorized' } } },
  })) as typeof fetch
  await assert.rejects(new DshSidecarClient({ fetch: errorFetch, rpcId: () => 'rpc-id' }).status(), /not authorized/)

  const malformedFetch = (async () => serverResponse('rpc-id', {
    ...status,
    runtime: { phase: 'unknown-phase' },
  })) as typeof fetch
  await assert.rejects(new DshSidecarClient({ fetch: malformedFetch, rpcId: () => 'rpc-id' }).status())
})

function abortingFetch(): typeof fetch {
  return ((async (_input: string | URL | Request, init?: RequestInit) => await new Promise<Response>((_resolve, reject) => {
    const signal = init?.signal
    if (!signal) return reject(new Error('missing request signal'))
    const rejectAbort = (): void => reject(signal.reason ?? new Error('aborted'))
    if (signal.aborted) rejectAbort()
    else signal.addEventListener('abort', rejectAbort, { once: true })
  })) as typeof fetch)
}

test('status has its own network deadline', async () => {
  const client = new DshSidecarClient({
    fetch: abortingFetch(),
    rpcId: () => 'deadline-status',
    statusDeadlineMilliseconds: 10,
  })
  await assert.rejects(client.status(), /exceeded 10 ms deadline/)
})

test('poll deadline includes the requested long-poll time and configured buffer', async () => {
  const client = new DshSidecarClient({
    fetch: abortingFetch(),
    rpcId: () => 'deadline-poll',
    pollDeadlineBufferMilliseconds: 10,
  })
  await assert.rejects(
    client.poll({ afterSequence: 0, timeoutMilliseconds: 0 }),
    /exceeded 10 ms deadline/,
  )
})

test('caller abort is forwarded to an in-flight request', async () => {
  const controller = new AbortController()
  const client = new DshSidecarClient({
    fetch: abortingFetch(),
    rpcId: () => 'caller-abort',
    statusDeadlineMilliseconds: 1_000,
  })
  const pending = client.status(controller.signal)
  controller.abort(new Error('caller stopped'))
  await assert.rejects(pending, /caller stopped/)
})

test('chat methods use only the filtered SoulDock chat surface', async () => {
  const requests: Array<{ url: string; body: unknown }> = []
  const fetchMock = (async (input: string | URL | Request, init?: RequestInit) => {
    const body = JSON.parse(String(init?.body)) as { rpcId: string; method: string }
    requests.push({ url: String(input), body })
    if (body.method === 'chat/open') {
      return serverResponse(body.rpcId, {
        version: 1,
        chatId: 'chat-1',
        sequence: 0,
        status: 'idle',
        persona: { id: 'lingqi', name: '灵栖' },
        messages: [],
        hasOlder: false,
        limits: { inputCodePoints: 8000 },
      })
    }
    return serverResponse(body.rpcId, { accepted: true, clientMessageId: 'client-1' })
  }) as typeof fetch
  const client = new DshSidecarClient({ fetch: fetchMock, rpcId: () => 'chat-rpc' })

  const opened = await client.chatOpen()
  assert.equal(opened.chatId, 'chat-1')
  await client.chatSend({ chatId: opened.chatId, clientMessageId: 'client-1', text: 'hello' })
  assert.deepEqual(requests.map(item => new URL(item.url).pathname), [
    '/souldock/chat/open',
    '/souldock/chat/send',
  ])
  assert.deepEqual(requests.map(item => (item.body as { method: string }).method), ['chat/open', 'chat/send'])
  assert.equal(requests.some(item => item.url.includes('/api/')), false)
})

test('workspace methods use only the sidecar-owned task surface', async () => {
  const requests: Array<{ url: string; body: { rpcId: string; method: string; payload: Record<string, unknown> } }> = []
  const task = {
    taskId: 'task-1',
    title: 'Fix the build',
    workspacePath: 'C:\\work\\demo',
    workspaceName: 'demo',
    updatedAt: 1000,
    status: 'idle',
  }
  const opened = {
    version: 1,
    task,
    sequence: 0,
    status: 'idle',
    messages: [],
    hasOlder: false,
    limits: { inputCodePoints: 8000 },
  }
  const fetchMock = (async (input: string | URL | Request, init?: RequestInit) => {
    const body = JSON.parse(String(init?.body)) as { rpcId: string; method: string; payload: Record<string, unknown> }
    requests.push({ url: String(input), body })
    if (body.method === 'workspace/list') {
      return serverResponse(body.rpcId, {
        version: 1,
        workspaces: [{ workspaceId: 'workspace-1', title: 'demo', path: 'C:\\work\\demo', tasks: [task] }],
      })
    }
    if (body.method === 'workspace/task/create' || body.method === 'workspace/task/open') {
      return serverResponse(body.rpcId, opened)
    }
    if (body.method === 'workspace/task/poll') {
      return serverResponse(body.rpcId, { version: 1, sequence: 0, status: 'idle', events: [] })
    }
    if (body.method === 'workspace/task/close') return serverResponse(body.rpcId, { closed: true })
    if (body.method === 'workspace/task/cancel') return serverResponse(body.rpcId, { accepted: true })
    return serverResponse(body.rpcId, { accepted: true, clientMessageId: 'client-1' })
  }) as typeof fetch
  const client = new DshSidecarClient({ fetch: fetchMock, rpcId: () => 'workspace-rpc' })

  assert.equal((await client.workspaceList()).workspaces[0]?.tasks[0]?.taskId, 'task-1')
  assert.equal((await client.workspaceTaskCreate({ cwd: 'C:\\work\\demo' })).task.workspaceName, 'demo')
  await client.workspaceTaskOpen({ taskId: 'task-1' })
  await client.workspaceTaskSend({ taskId: 'task-1', clientMessageId: 'client-1', text: 'inspect tests' })
  await client.workspaceTaskPoll({ taskId: 'task-1', afterSequence: 0, timeoutMilliseconds: 0 })
  await client.workspaceTaskCancel({ taskId: 'task-1' })
  await client.workspaceTaskClose({ taskId: 'task-1' })

  assert.deepEqual(requests.map(item => new URL(item.url).pathname), [
    '/souldock/workspace/list',
    '/souldock/workspace/task/create',
    '/souldock/workspace/task/open',
    '/souldock/workspace/task/send',
    '/souldock/workspace/task/poll',
    '/souldock/workspace/task/cancel',
    '/souldock/workspace/task/close',
  ])
  assert.deepEqual(requests.map(item => item.body.method), [
    'workspace/list',
    'workspace/task/create',
    'workspace/task/open',
    'workspace/task/send',
    'workspace/task/poll',
    'workspace/task/cancel',
    'workspace/task/close',
  ])
  assert.deepEqual(requests[1]?.body.payload, { cwd: 'C:\\work\\demo' })
  assert.equal(requests.some(item => item.url.includes('/api/')), false)
})
