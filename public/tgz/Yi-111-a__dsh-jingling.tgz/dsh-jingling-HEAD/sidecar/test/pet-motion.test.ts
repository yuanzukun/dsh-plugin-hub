import assert from 'node:assert/strict'
import test from 'node:test'
import {
  beginPetFlick,
  beginPetWalk,
  clampPetPosition,
  dragPet,
  stepPetMotion,
} from '../src/renderer/pet-motion'

const size = { width: 100, height: 80 } as const
const viewport = { width: 300, height: 200 } as const

test('clampPetPosition keeps the entire pet inside the viewport with safe edge padding', () => {
  assert.deepEqual(
    clampPetPosition({ x: -200, y: 999 }, size, viewport, { edgePaddingPx: 10 }),
    { x: 10, y: 110 },
  )
  assert.deepEqual(
    clampPetPosition({ x: 99, y: 20 }, { width: 400, height: 500 }, viewport, { edgePaddingPx: 20 }),
    { x: 0, y: 0 },
  )
})

test('dragging is direct and bounded without inertial carry-over', () => {
  const state = dragPet({
    origin: { x: 50, y: 40 },
    pointerStart: { x: 20, y: 20 },
    pointerCurrent: { x: 1_000, y: -1_000 },
    size,
    viewport,
    options: { edgePaddingPx: 8 },
  })
  assert.deepEqual(state, {
    position: { x: 192, y: 8 },
    velocity: { x: 0, y: 0 },
    mode: 'dragging',
  })
})

test('flick velocity is capped, frame time is capped, and wall collisions stop instead of escaping', () => {
  const start = beginPetFlick({
    position: { x: 190, y: 50 },
    releaseVelocity: { x: 9_999, y: 0 },
    size,
    viewport,
    options: { maxFlickSpeedPxPerSecond: 200, maxFrameMs: 64, stopSpeedPxPerSecond: 0 },
  })
  assert.equal(start.mode, 'flicking')
  assert.equal(Math.round(Math.hypot(start.velocity.x, start.velocity.y)), 200)

  const collided = stepPetMotion({
    state: start,
    elapsedMs: 99_999,
    size,
    viewport,
    options: { maxFlickSpeedPxPerSecond: 200, maxFrameMs: 64, stopSpeedPxPerSecond: 0 },
  })
  assert.deepEqual(collided, {
    position: { x: 200, y: 50 },
    velocity: { x: 0, y: 0 },
    mode: 'idle',
  })
})

test('reduced-motion mode disables flick and autonomous walk while retaining safe user drag', () => {
  const flick = beginPetFlick({
    position: { x: 40, y: 40 },
    releaseVelocity: { x: 500, y: 100 },
    size,
    viewport,
    options: { reducedMotion: true },
  })
  assert.deepEqual(flick, {
    position: { x: 40, y: 40 },
    velocity: { x: 0, y: 0 },
    mode: 'idle',
  })

  const walk = beginPetWalk({
    position: { x: 40, y: 40 },
    target: { x: 150, y: 80 },
    size,
    viewport,
    options: { reducedMotion: true },
  })
  assert.deepEqual(walk, flick)

  const noSpeedWalk = beginPetWalk({
    position: { x: 40, y: 40 },
    target: { x: 150, y: 80 },
    size,
    viewport,
    options: { walkSpeedPxPerSecond: 0 },
  })
  assert.equal(noSpeedWalk.mode, 'idle')

  const drag = dragPet({
    origin: { x: 40, y: 40 },
    pointerStart: { x: 0, y: 0 },
    pointerCurrent: { x: 50, y: 25 },
    size,
    viewport,
    options: { reducedMotion: true },
  })
  assert.deepEqual(drag.position, { x: 90, y: 65 })
  assert.equal(drag.mode, 'dragging')
})

test('walk steps toward a clamped target and finishes at a bounded idle state', () => {
  const walking = beginPetWalk({
    position: { x: 0, y: 0 },
    target: { x: 1_000, y: 1_000 },
    size,
    viewport,
    options: { walkSpeedPxPerSecond: 1_000, maxFrameMs: 1_000 },
  })
  assert.equal(walking.mode, 'walking')
  assert.deepEqual(walking.walkTarget, { x: 200, y: 120 })

  const done = stepPetMotion({
    state: walking,
    elapsedMs: 1_000,
    size,
    viewport,
    options: { walkSpeedPxPerSecond: 1_000, maxFrameMs: 1_000 },
  })
  assert.deepEqual(done, {
    position: { x: 200, y: 120 },
    velocity: { x: 0, y: 0 },
    mode: 'idle',
  })
})
