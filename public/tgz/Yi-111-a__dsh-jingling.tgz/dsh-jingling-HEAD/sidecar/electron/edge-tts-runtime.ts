import { execFile as execFileCallback } from 'node:child_process'
import { mkdtemp, readFile, rm, stat } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { promisify } from 'node:util'
import type { WebContents } from 'electron'
import type { SanitizedVoiceConfig } from '../src/core/voice-config'

const DEFAULT_EDGE_TTS_VOICE = 'zh-CN-XiaoxiaoNeural'
const DEFAULT_PYTHON_EXECUTABLE = 'python'
const MAX_TEXT_LENGTH = 6_000
const MAX_AUDIO_BYTES = 64 * 1024 * 1024
const COMMAND_TIMEOUT_MILLISECONDS = 60_000
const MAX_DIAGNOSTIC_BYTES = 1024 * 1024

export interface EdgeTtsCommandOptions {
  readonly cwd: string
  readonly timeout: number
  readonly maxBuffer: number
  readonly windowsHide: boolean
  readonly shell: false
  readonly signal: AbortSignal
}

/**
 * Narrow, injectable process boundary for tests. The renderer never controls
 * the executable, arguments, output path, or process options.
 */
export type EdgeTtsCommandRunner = (
  executable: string,
  arguments_: readonly string[],
  options: EdgeTtsCommandOptions,
) => Promise<void>

const execFile = promisify(execFileCallback)

const runEdgeTtsCommand: EdgeTtsCommandRunner = async (executable, arguments_, options) => {
  await execFile(executable, [...arguments_], {
    cwd: options.cwd,
    timeout: options.timeout,
    maxBuffer: options.maxBuffer,
    windowsHide: options.windowsHide,
    shell: options.shell,
    signal: options.signal,
  })
}

export interface EdgeTtsRuntime {
  readonly config: SanitizedVoiceConfig
  readonly service?: EdgeTtsMainService
  readonly configurationError?: string
}

export interface EdgeTtsRuntimeOptions {
  readonly runner?: EdgeTtsCommandRunner
}

function parsePythonExecutable(input: string | undefined): string {
  const executable = (input ?? DEFAULT_PYTHON_EXECUTABLE).trim()
  if (!executable || executable.includes('\0')) {
    throw new TypeError('SOULDOCK_EDGE_TTS_PYTHON must name a Python executable')
  }
  return executable
}

function parseVoice(input: string | undefined): string {
  const voice = (input ?? DEFAULT_EDGE_TTS_VOICE).trim()
  // Microsoft neural voice identifiers consist solely of ASCII letters,
  // digits, and hyphens. Keeping this narrow makes the CLI argument contract
  // auditable even though execFile never invokes a shell.
  if (!/^[A-Za-z0-9-]{3,128}$/.test(voice)) {
    throw new TypeError('SOULDOCK_EDGE_TTS_VOICE must be a supported voice identifier')
  }
  return voice
}

export function createEdgeTtsRuntime(
  environment: Readonly<Record<string, string | undefined>>,
  options: EdgeTtsRuntimeOptions = {},
): EdgeTtsRuntime {
  if (environment.SOULDOCK_TTS_PROVIDER !== 'edge-tts') {
    return { config: { provider: 'web-speech' } }
  }

  try {
    const executable = parsePythonExecutable(environment.SOULDOCK_EDGE_TTS_PYTHON)
    const voice = parseVoice(environment.SOULDOCK_EDGE_TTS_VOICE)
    return {
      config: { provider: 'edge-tts', voice },
      service: new EdgeTtsMainService(executable, voice, options.runner ?? runEdgeTtsCommand),
    }
  }
  catch (error) {
    return {
      config: { provider: 'web-speech' },
      configurationError: error instanceof Error ? error.message : 'Invalid Edge TTS configuration',
    }
  }
}

export class EdgeTtsMainService {
  readonly #executable: string
  readonly #voice: string
  readonly #runner: EdgeTtsCommandRunner
  #active?: AbortController

  constructor(executable: string, voice: string, runner: EdgeTtsCommandRunner = runEdgeTtsCommand) {
    this.#executable = executable
    this.#voice = voice
    this.#runner = runner
  }

  async synthesize(input: unknown): Promise<Uint8Array> {
    if (typeof input !== 'string') throw new TypeError('Edge TTS text must be a string')
    const text = input.trim()
    if (!text) throw new TypeError('Edge TTS text must not be empty')
    if (text.length > MAX_TEXT_LENGTH) {
      throw new TypeError(`Edge TTS text exceeds ${MAX_TEXT_LENGTH} characters`)
    }

    this.cancel()
    const active = new AbortController()
    this.#active = active
    let temporaryDirectory: string | undefined
    try {
      temporaryDirectory = await mkdtemp(join(tmpdir(), 'souldock-edge-tts-'))
      const mediaPath = join(temporaryDirectory, 'speech.mp3')
      await this.#runner(this.#executable, [
        '-m',
        'edge_tts',
        '--voice',
        this.#voice,
        '--text',
        text,
        '--write-media',
        mediaPath,
      ], {
        // Keep Python away from the app/current workspace. The package must
        // resolve from the user's configured Python environment instead.
        cwd: temporaryDirectory,
        timeout: COMMAND_TIMEOUT_MILLISECONDS,
        maxBuffer: MAX_DIAGNOSTIC_BYTES,
        windowsHide: true,
        shell: false,
        signal: active.signal,
      })
      if (active.signal.aborted) throw active.signal.reason
      const mediaInfo = await stat(mediaPath)
      if (!mediaInfo.isFile()) throw new TypeError('Edge TTS synthesis did not produce an audio file')
      if (mediaInfo.size > MAX_AUDIO_BYTES) throw new TypeError('Edge TTS audio exceeds the IPC size limit')
      const audio = await readFile(mediaPath)
      if (audio.byteLength === 0) throw new TypeError('Edge TTS synthesis returned empty audio')
      if (audio.byteLength > MAX_AUDIO_BYTES) throw new TypeError('Edge TTS audio exceeds the IPC size limit')
      return new Uint8Array(audio)
    }
    catch (error) {
      if (active.signal.aborted) {
        throw active.signal.reason instanceof Error
          ? active.signal.reason
          : new Error('Edge TTS speech cancelled')
      }
      throw error
    }
    finally {
      if (this.#active === active) this.#active = undefined
      if (temporaryDirectory) {
        await rm(temporaryDirectory, { recursive: true, force: true }).catch(() => undefined)
      }
    }
  }

  cancel(): void {
    this.#active?.abort(new Error('Edge TTS speech cancelled'))
    this.#active = undefined
  }
}

export interface EdgeTtsIpcHandlers {
  getConfig: (sender: WebContents) => SanitizedVoiceConfig | undefined
  synthesize: (sender: WebContents, text: unknown) => Promise<Uint8Array | undefined>
  cancel: (sender: WebContents) => void
}

export function createEdgeTtsIpcHandlers(
  runtime: EdgeTtsRuntime,
  isTrustedSender: (sender: WebContents) => boolean,
): EdgeTtsIpcHandlers {
  return {
    getConfig: sender => isTrustedSender(sender) ? runtime.config : undefined,
    synthesize: async (sender, text) => {
      if (!isTrustedSender(sender) || !runtime.service) return undefined
      return await runtime.service.synthesize(text)
    },
    cancel: sender => {
      if (isTrustedSender(sender)) runtime.service?.cancel()
    },
  }
}
