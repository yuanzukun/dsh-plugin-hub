import type { WebContents } from 'electron'
import type { SanitizedVoiceConfig } from '../src/core/voice-config'
import {
  VoicevoxLocalClient,
  normalizeVoicevoxLoopbackBaseUrl,
} from '../src/renderer/adapters/voicevox-local'

const DEFAULT_VOICEVOX_URL = 'http://127.0.0.1:50021/'
const DEFAULT_VOICEVOX_SPEAKER = 1
const MAX_TEXT_LENGTH = 6_000
const MAX_WAV_BYTES = 64 * 1024 * 1024

export interface VoicevoxRuntime {
  readonly config: SanitizedVoiceConfig
  readonly service?: VoicevoxMainService
  readonly configurationError?: string
}

export interface VoicevoxRuntimeOptions {
  fetch?: typeof fetch
}

function parseSpeaker(input: string | undefined): number {
  if (input === undefined || input === '') return DEFAULT_VOICEVOX_SPEAKER
  if (!/^(0|[1-9]\d*)$/.test(input)) {
    throw new TypeError('SOULDOCK_VOICEVOX_SPEAKER must be a non-negative integer')
  }
  const speaker = Number(input)
  if (!Number.isSafeInteger(speaker)) {
    throw new TypeError('SOULDOCK_VOICEVOX_SPEAKER exceeds the safe integer range')
  }
  return speaker
}

export function createVoicevoxRuntime(
  environment: Readonly<Record<string, string | undefined>>,
  options: VoicevoxRuntimeOptions = {},
): VoicevoxRuntime {
  if (environment.SOULDOCK_TTS_PROVIDER !== 'voicevox-local') {
    return { config: { provider: 'web-speech' } }
  }

  try {
    const speaker = parseSpeaker(environment.SOULDOCK_VOICEVOX_SPEAKER)
    const baseUrl = normalizeVoicevoxLoopbackBaseUrl(
      environment.SOULDOCK_VOICEVOX_URL ?? DEFAULT_VOICEVOX_URL,
    ).href
    const client = new VoicevoxLocalClient({ baseUrl, defaultSpeaker: speaker, fetch: options.fetch })
    return {
      config: { provider: 'voicevox-local', speaker },
      service: new VoicevoxMainService(client, speaker),
    }
  }
  catch (error) {
    return {
      config: { provider: 'web-speech' },
      configurationError: error instanceof Error ? error.message : 'Invalid VOICEVOX configuration',
    }
  }
}

export class VoicevoxMainService {
  readonly #client: VoicevoxLocalClient
  readonly #speaker: number
  #active?: AbortController

  constructor(client: VoicevoxLocalClient, speaker: number) {
    this.#client = client
    this.#speaker = speaker
  }

  async synthesize(input: unknown): Promise<Uint8Array> {
    if (typeof input !== 'string') throw new TypeError('VOICEVOX text must be a string')
    const text = input.trim()
    if (!text) throw new TypeError('VOICEVOX text must not be empty')
    if (text.length > MAX_TEXT_LENGTH) {
      throw new TypeError(`VOICEVOX text exceeds ${MAX_TEXT_LENGTH} characters`)
    }

    this.cancel()
    const active = new AbortController()
    this.#active = active
    try {
      const wav = await this.#client.synthesize({ text, speaker: this.#speaker, signal: active.signal })
      if (wav.size > MAX_WAV_BYTES) throw new TypeError('VOICEVOX audio exceeds the IPC size limit')
      return new Uint8Array(await wav.arrayBuffer())
    }
    finally {
      if (this.#active === active) this.#active = undefined
    }
  }

  cancel(): void {
    this.#active?.abort(new Error('VOICEVOX speech cancelled'))
    this.#active = undefined
  }
}

export interface VoicevoxIpcHandlers {
  getConfig: (sender: WebContents) => SanitizedVoiceConfig | undefined
  synthesize: (sender: WebContents, text: unknown) => Promise<Uint8Array | undefined>
  cancel: (sender: WebContents) => void
}

export function createVoicevoxIpcHandlers(
  runtime: VoicevoxRuntime,
  isTrustedSender: (sender: WebContents) => boolean,
): VoicevoxIpcHandlers {
  return {
    getConfig: sender => isTrustedSender(sender) ? runtime.config : undefined,
    synthesize: async (sender, text) => {
      if (!isTrustedSender(sender) || !runtime.service) return undefined
      return await runtime.service.synthesize(text)
    },
    cancel: sender => {
      if (isTrustedSender(sender)) runtime.service?.cancel()
    },
  }
}
