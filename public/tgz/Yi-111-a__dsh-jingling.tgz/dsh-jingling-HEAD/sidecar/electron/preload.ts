import { contextBridge, ipcRenderer } from 'electron'
import type { SidecarViewState } from '../src/core/poller'
import type { RendererVoiceBridge } from '../src/core/voice-config'
import type { SidecarChatPort } from '../src/core/chat-controller'
import type { SidecarWorkspacePort } from '../src/core/workspace-controller'

const voice: RendererVoiceBridge = {
  getConfig: () => ipcRenderer.invoke('souldock-sidecar:voice:get-config'),
  synthesize: (text: string) => {
    if (typeof text !== 'string') return Promise.reject(new TypeError('TTS text must be a string'))
    return ipcRenderer.invoke('souldock-sidecar:voice:synthesize', text)
  },
  cancel: () => ipcRenderer.invoke('souldock-sidecar:voice:cancel'),
}

const chat: SidecarChatPort = {
  open: () => ipcRenderer.invoke('souldock-sidecar:chat:open'),
  send: payload => ipcRenderer.invoke('souldock-sidecar:chat:send', payload),
  poll: payload => ipcRenderer.invoke('souldock-sidecar:chat:poll', payload),
  cancel: payload => ipcRenderer.invoke('souldock-sidecar:chat:cancel', payload.chatId),
  close: payload => ipcRenderer.invoke('souldock-sidecar:chat:close', payload.chatId),
}

const workspace: SidecarWorkspacePort = {
  pickDirectory: () => ipcRenderer.invoke('souldock-sidecar:workspace:pick-directory'),
  list: () => ipcRenderer.invoke('souldock-sidecar:workspace:list'),
  create: payload => ipcRenderer.invoke('souldock-sidecar:workspace:task:create', payload),
  open: payload => ipcRenderer.invoke('souldock-sidecar:workspace:task:open', payload),
  send: payload => ipcRenderer.invoke('souldock-sidecar:workspace:task:send', payload),
  poll: payload => ipcRenderer.invoke('souldock-sidecar:workspace:task:poll', payload),
  cancel: payload => ipcRenderer.invoke('souldock-sidecar:workspace:task:cancel', payload),
  close: payload => ipcRenderer.invoke('souldock-sidecar:workspace:task:close', payload),
}

const api = {
  getState: (): Promise<SidecarViewState> => ipcRenderer.invoke('souldock-sidecar:get-state'),
  readAvatarFrames: (): Promise<Record<string, string> | undefined> => (
    ipcRenderer.invoke('souldock-sidecar:avatar:read-frames')
  ),
  setPetInteractive: (interactive: boolean): Promise<void> => ipcRenderer.invoke(
    'souldock-sidecar:set-pet-interactive',
    interactive === true,
  ),
  setConversationOpen: (open: boolean): Promise<void> => ipcRenderer.invoke(
    'souldock-sidecar:set-conversation-open',
    open === true,
  ),
  quit: (): Promise<void> => ipcRenderer.invoke('souldock-sidecar:quit'),
  voice,
  chat,
  workspace,
  onState: (listener: (state: SidecarViewState) => void): (() => void) => {
    const wrapped = (_event: Electron.IpcRendererEvent, state: SidecarViewState): void => listener(state)
    ipcRenderer.on('souldock-sidecar:state', wrapped)
    return () => ipcRenderer.removeListener('souldock-sidecar:state', wrapped)
  },
}

contextBridge.exposeInMainWorld('soulDockSidecar', api)
