import { app, BrowserWindow, dialog, ipcMain, screen, type WebContents } from 'electron'
import { readFile } from 'node:fs/promises'
import { basename, dirname, join, normalize } from 'node:path'
import { fileURLToPath } from 'node:url'
import { DshSidecarClient } from '../src/core/dsh-client'
import { SidecarPoller } from '../src/core/poller'
import {
  workspaceTaskCreateRequestSchema,
  workspaceTaskIdRequestSchema,
  workspaceTaskOpenRequestSchema,
  workspaceTaskPollRequestSchema,
  workspaceTaskSendRequestSchema,
} from '../src/core/protocol'
import { applyClickThroughOverlay, createSidecarWindowOptions, isTrustedSidecarSender } from './window-contract'
import { createEdgeTtsIpcHandlers, createEdgeTtsRuntime } from './edge-tts-runtime'
import { createVoicevoxIpcHandlers, createVoicevoxRuntime } from './voicevox-runtime'

const currentDirectory = dirname(fileURLToPath(import.meta.url))
const client = new DshSidecarClient({
  baseUrl: process.env.SOULDOCK_DSH_BASE_URL ?? 'http://127.0.0.1:3080',
})
const poller = new SidecarPoller(client)
const edgeTtsSelected = process.env.SOULDOCK_TTS_PROVIDER === 'edge-tts'
const edgeTtsRuntime = edgeTtsSelected ? createEdgeTtsRuntime(process.env) : undefined
const voicevoxRuntime = edgeTtsSelected ? undefined : createVoicevoxRuntime(process.env)
const voiceRuntime = edgeTtsRuntime ?? voicevoxRuntime!
if (voiceRuntime.configurationError) {
  console.warn(`${edgeTtsSelected ? 'Edge TTS' : 'VOICEVOX'} disabled: ${voiceRuntime.configurationError}`)
}
let sidecarWindow: BrowserWindow | undefined
let conversationOpen = false
const allowedWorkspaceDirectories = new Set<string>()

const WHALEGIRL_FRAMES = [
  'idle_0.png', 'idle_1.png', 'idle_2.png', 'idle_3.png',
  'walk_0.png', 'walk_1.png', 'walk_2.png', 'walk_3.png',
  'sleep_0.png', 'sleep_1.png', 'sleep_2.png', 'sleep_3.png',
  'click_0.png', 'click_1.png', 'click_2.png', 'click_3.png',
] as const

function workspaceDirectoryKey(path: string): string {
  return normalize(path).toLocaleLowerCase('en-US')
}

function createWindow(): BrowserWindow {
  const preloadPath = join(currentDirectory, '../preload/index.cjs')
  const window = new BrowserWindow(createSidecarWindowOptions(screen.getPrimaryDisplay().workArea, preloadPath))

  applyClickThroughOverlay(window, { contentProtection: process.env.SOULDOCK_CONTENT_PROTECTION === 'true' })
  window.setMenuBarVisibility(false)
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }))
  window.webContents.on('will-navigate', (event) => event.preventDefault())
  window.once('ready-to-show', () => window.showInactive())

  const rendererUrl = process.env.ELECTRON_RENDERER_URL
  if (rendererUrl) void window.loadURL(rendererUrl)
  else void window.loadFile(join(currentDirectory, '../renderer/index.html'))

  return window
}

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) app.quit()
else {
  app.on('second-instance', () => {
    if (sidecarWindow && !sidecarWindow.isDestroyed()) {
      sidecarWindow.showInactive()
    } else {
      sidecarWindow = createWindow()
    }
  })

  void app.whenReady().then(() => {
    app.setAppUserModelId('dev.souldock.sidecar')
    sidecarWindow = createWindow()
    const isTrustedVoiceSender = (sender: WebContents): boolean => (
      isTrustedSidecarSender(sender, sidecarWindow)
    )
    const voiceHandlers = edgeTtsSelected
      ? createEdgeTtsIpcHandlers(edgeTtsRuntime!, isTrustedVoiceSender)
      : createVoicevoxIpcHandlers(voicevoxRuntime!, isTrustedVoiceSender)
    ipcMain.handle('souldock-sidecar:get-state', event => (
      isTrustedSidecarSender(event.sender, sidecarWindow) ? poller.state : undefined
    ))
    ipcMain.handle('souldock-sidecar:set-pet-interactive', (event, interactive: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow) || !sidecarWindow || sidecarWindow.isDestroyed()) return
      sidecarWindow.setIgnoreMouseEvents(interactive !== true, { forward: true })
    })
    ipcMain.handle('souldock-sidecar:set-conversation-open', (event, open: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow) || !sidecarWindow || sidecarWindow.isDestroyed()) return
      conversationOpen = open === true
      sidecarWindow.setFocusable(conversationOpen)
      sidecarWindow.setIgnoreMouseEvents(!conversationOpen, { forward: true })
      if (conversationOpen) {
        sidecarWindow.show()
        sidecarWindow.focus()
      }
    })
    ipcMain.handle('souldock-sidecar:quit', (event) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) return
      app.quit()
    })
    ipcMain.handle('souldock-sidecar:avatar:read-frames', async (event) => {
      // The renderer runs over file:// in the packaged build, where fetch()
      // cannot read URLs and img elements cannot reach arbitrary paths, so
      // the trusted main process reads the bundled frames and hands them back
      // as data URLs. Data URLs load fine through every pixi code path.
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) return undefined
      const candidates = [
        join(currentDirectory, '../renderer/whalegirl'),
        join(currentDirectory, '../../src/renderer/public/whalegirl'),
      ]
      const frames: Record<string, string> = {}
      for (const name of WHALEGIRL_FRAMES) {
        let loaded = false
        for (const dir of candidates) {
          try {
            const bytes = await readFile(join(dir, name))
            frames[name] = `data:image/png;base64,${bytes.toString('base64')}`
            loaded = true
            break
          }
          catch { /* try the next candidate location */ }
        }
        if (!loaded) return undefined
      }
      return frames
    })
    ipcMain.handle('souldock-sidecar:voice:get-config', event => voiceHandlers.getConfig(event.sender))
    ipcMain.handle('souldock-sidecar:voice:synthesize', (event, text: unknown) => (
      voiceHandlers.synthesize(event.sender, text)
    ))
    ipcMain.handle('souldock-sidecar:voice:cancel', event => voiceHandlers.cancel(event.sender))
    ipcMain.handle('souldock-sidecar:chat:open', event => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling chat sender')
      return client.chatOpen()
    })
    ipcMain.handle('souldock-sidecar:chat:send', (event, payload: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling chat sender')
      if (!payload || typeof payload !== 'object') throw new Error('Invalid Jingling chat payload')
      const value = payload as { chatId?: unknown; clientMessageId?: unknown; text?: unknown; clientTimeZone?: unknown }
      if (typeof value.chatId !== 'string' || typeof value.clientMessageId !== 'string' || typeof value.text !== 'string') {
        throw new Error('Invalid Jingling chat send payload')
      }
      return client.chatSend({
        chatId: value.chatId,
        clientMessageId: value.clientMessageId,
        text: value.text,
        ...(typeof value.clientTimeZone === 'string' ? { clientTimeZone: value.clientTimeZone } : {}),
      })
    })
    ipcMain.handle('souldock-sidecar:chat:poll', (event, payload: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling chat sender')
      if (!payload || typeof payload !== 'object') throw new Error('Invalid Jingling chat poll payload')
      const value = payload as { chatId?: unknown; afterSequence?: unknown; timeoutMilliseconds?: unknown }
      if (typeof value.chatId !== 'string' || typeof value.afterSequence !== 'number' || typeof value.timeoutMilliseconds !== 'number') {
        throw new Error('Invalid Jingling chat poll payload')
      }
      return client.chatPoll({
        chatId: value.chatId,
        afterSequence: value.afterSequence,
        timeoutMilliseconds: value.timeoutMilliseconds,
      })
    })
    ipcMain.handle('souldock-sidecar:chat:cancel', (event, chatId: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow) || typeof chatId !== 'string') {
        throw new Error('Invalid Jingling chat cancel request')
      }
      return client.chatCancel({ chatId })
    })
    ipcMain.handle('souldock-sidecar:chat:close', (event, chatId: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow) || typeof chatId !== 'string') {
        throw new Error('Invalid Jingling chat close request')
      }
      return client.chatClose({ chatId })
    })
    ipcMain.handle('souldock-sidecar:workspace:pick-directory', async (event) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow) || !sidecarWindow || sidecarWindow.isDestroyed()) {
        throw new Error('Untrusted Jingling workspace sender')
      }
      const result = await dialog.showOpenDialog(sidecarWindow, {
        title: '选择工作区文件夹',
        buttonLabel: '选择文件夹',
        properties: ['openDirectory', 'createDirectory'],
      })
      if (result.canceled || result.filePaths.length !== 1) return null
      const path = result.filePaths[0]
      if (!path) return null
      // Only the user-selected directory identity crosses IPC. No directory
      // listing or file content is read by the sidecar picker.
      allowedWorkspaceDirectories.add(workspaceDirectoryKey(path))
      return { path, name: basename(path) || path }
    })
    ipcMain.handle('souldock-sidecar:workspace:list', async (event) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling workspace sender')
      const result = await client.workspaceList()
      for (const workspace of result.workspaces) {
        allowedWorkspaceDirectories.add(workspaceDirectoryKey(workspace.path))
      }
      return result
    })
    ipcMain.handle('souldock-sidecar:workspace:task:create', (event, payload: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling workspace sender')
      const request = workspaceTaskCreateRequestSchema.parse(payload)
      if (!allowedWorkspaceDirectories.has(workspaceDirectoryKey(request.cwd))) {
        throw new Error('Workspace directory must be selected by the user first')
      }
      return client.workspaceTaskCreate(request)
    })
    ipcMain.handle('souldock-sidecar:workspace:task:open', (event, payload: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling workspace sender')
      return client.workspaceTaskOpen(workspaceTaskOpenRequestSchema.parse(payload))
    })
    ipcMain.handle('souldock-sidecar:workspace:task:send', (event, payload: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling workspace sender')
      return client.workspaceTaskSend(workspaceTaskSendRequestSchema.parse(payload))
    })
    ipcMain.handle('souldock-sidecar:workspace:task:poll', (event, payload: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling workspace sender')
      return client.workspaceTaskPoll(workspaceTaskPollRequestSchema.parse(payload))
    })
    ipcMain.handle('souldock-sidecar:workspace:task:cancel', (event, payload: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling workspace sender')
      return client.workspaceTaskCancel(workspaceTaskIdRequestSchema.parse(payload))
    })
    ipcMain.handle('souldock-sidecar:workspace:task:close', (event, payload: unknown) => {
      if (!isTrustedSidecarSender(event.sender, sidecarWindow)) throw new Error('Untrusted Jingling workspace sender')
      return client.workspaceTaskClose(workspaceTaskIdRequestSchema.parse(payload))
    })
    poller.subscribe((state) => {
      if (sidecarWindow && !sidecarWindow.isDestroyed()) {
        sidecarWindow.webContents.send('souldock-sidecar:state', state)
      }
    })
    poller.start()
  })
}

app.on('before-quit', () => {
  poller.stop()
  voiceRuntime.service?.cancel()
  ipcMain.removeHandler('souldock-sidecar:get-state')
  ipcMain.removeHandler('souldock-sidecar:set-pet-interactive')
  ipcMain.removeHandler('souldock-sidecar:set-conversation-open')
  ipcMain.removeHandler('souldock-sidecar:quit')
  ipcMain.removeHandler('souldock-sidecar:avatar:read-frames')
  ipcMain.removeHandler('souldock-sidecar:voice:get-config')
  ipcMain.removeHandler('souldock-sidecar:voice:synthesize')
  ipcMain.removeHandler('souldock-sidecar:voice:cancel')
  ipcMain.removeHandler('souldock-sidecar:chat:open')
  ipcMain.removeHandler('souldock-sidecar:chat:send')
  ipcMain.removeHandler('souldock-sidecar:chat:poll')
  ipcMain.removeHandler('souldock-sidecar:chat:cancel')
  ipcMain.removeHandler('souldock-sidecar:chat:close')
  ipcMain.removeHandler('souldock-sidecar:workspace:pick-directory')
  ipcMain.removeHandler('souldock-sidecar:workspace:list')
  ipcMain.removeHandler('souldock-sidecar:workspace:task:create')
  ipcMain.removeHandler('souldock-sidecar:workspace:task:open')
  ipcMain.removeHandler('souldock-sidecar:workspace:task:send')
  ipcMain.removeHandler('souldock-sidecar:workspace:task:poll')
  ipcMain.removeHandler('souldock-sidecar:workspace:task:cancel')
  ipcMain.removeHandler('souldock-sidecar:workspace:task:close')
})

app.on('window-all-closed', () => app.quit())
