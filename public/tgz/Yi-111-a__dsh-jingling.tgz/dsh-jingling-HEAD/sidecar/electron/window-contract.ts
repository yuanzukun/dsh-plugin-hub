import type { BrowserWindow, BrowserWindowConstructorOptions, Rectangle } from 'electron'

export function isTrustedSidecarSender(
  sender: unknown,
  window: Pick<BrowserWindow, 'webContents'> | undefined,
): boolean {
  return window !== undefined && sender === window.webContents
}

/**
 * Window behavior is adapted from AIRI's MIT-licensed desktop overlay contract:
 * apps/stage-tamagotchi/src/main/windows/desktop-overlay/window-contract.ts
 * at commit 71dd65cb99b14eb24602eecfa43f0e571f011a13.
 *
 * AIRI copyright and its full MIT text are retained in THIRD_PARTY_NOTICES.md.
 * Jingling keeps this function pure so its security-sensitive flags are testable
 * without launching Electron.
 */
export function createSidecarWindowOptions(bounds: Rectangle, preloadPath: string): BrowserWindowConstructorOptions {
  return {
    title: '鲸灵 Sidecar',
    width: bounds.width,
    height: bounds.height,
    x: bounds.x,
    y: bounds.y,
    show: false,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    hasShadow: false,
    roundedCorners: false,
    focusable: false,
    backgroundColor: '#00000000',
    webPreferences: {
      preload: preloadPath,
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false,
      backgroundThrottling: false,
    },
  }
}

export function applyClickThroughOverlay(
  window: Pick<BrowserWindow, 'setAlwaysOnTop' | 'setContentProtection' | 'setIgnoreMouseEvents' | 'setVisibleOnAllWorkspaces'>,
  options: { contentProtection?: boolean } = {},
): void {
  window.setIgnoreMouseEvents(true, { forward: true })
  window.setAlwaysOnTop(true, 'screen-saver')
  window.setContentProtection(options.contentProtection === true)
  window.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true })
}
