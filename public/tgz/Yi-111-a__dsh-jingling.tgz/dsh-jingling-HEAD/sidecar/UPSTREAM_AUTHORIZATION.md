# Jingling public avatar authorization record

## Authorized public asset

On 2026-08-14, the user expressly authorized public use of **only the
top-left character cell** from the image they supplied in this Codex session,
for the public repository `Yi-111-a/jingling`.

The public source tree and production renderer include that exact transparent
RGBA PNG, without visual modification, at:

`src/renderer/assets/jingling/jingling-idle.png`

Its selection is the exact `627 x 627` top-left cell from the supplied `2 x 2`
image. Its SHA-256 is:

`A6E4F3D40D4195BE7ECA211A504EDD99C48DCBBB708A0F8BE4537600B390B9EE`

The asset is used only as Jingling's built-in static desktop avatar and README
illustration. It must not be presented as an official DeepSeek character,
DeepSeek product, or affiliated work.

## Explicit exclusions

This public handoff does **not** include, build from, or redistribute any other
character image, generated Sprite Sheet, animation frame, third-party model,
or local historical art asset. Those local-only materials are ignored by Git
and are not referenced by the public renderer.

This record identifies the scope of the user's authorization for this public
repository; it does not grant unrelated recipients rights to excluded assets
or to any independently supplied model, voice, or runtime.
