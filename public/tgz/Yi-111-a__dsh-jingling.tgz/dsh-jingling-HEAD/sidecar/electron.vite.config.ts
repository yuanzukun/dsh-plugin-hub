import { resolve } from 'node:path'
import { defineConfig } from 'electron-vite'

export default defineConfig({
  main: {
    build: {
      lib: {
        entry: {
          index: resolve(import.meta.dirname, 'electron/main.ts'),
        },
      },
    },
  },
  preload: {
    build: {
      lib: {
        entry: {
          index: resolve(import.meta.dirname, 'electron/preload.ts'),
        },
      },
      rollupOptions: {
        output: {
          format: 'cjs',
          entryFileNames: '[name].cjs',
        },
      },
    },
  },
  renderer: {
    root: resolve(import.meta.dirname, 'src/renderer'),
    base: './',
    build: {
      // Pixi's image-bitmap worker cannot reliably load Vite's small data-URI
      // assets under a strict file:// CSP. Keep every bundled avatar frame as a
      // local file so the production loader follows one tested path.
      assetsInlineLimit: 0,
      rollupOptions: {
        input: resolve(import.meta.dirname, 'src/renderer/index.html'),
      },
    },
  },
})
