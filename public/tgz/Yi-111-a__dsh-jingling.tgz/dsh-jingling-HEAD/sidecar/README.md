# 鲸灵 Sidecar / Jingling Sidecar

<p align="center">
  <img src="src/renderer/assets/jingling/jingling-idle.png" width="260" alt="鲸灵的透明待机立绘" />
</p>

鲸灵 Sidecar 是 `dsh-jingling` 的 Windows 透明桌面伙伴。
收起时，桌面上只保留角色本体；点击角色才会打开贴身的聊天与工作区面板，
再次点击或按 <kbd>Esc</kbd> 即收起。

`0.1.0-alpha.10` 是一个可运行的本地开发候选版本。它不是 AIRI 的发行版，
也不宣传尚未实现的麦克风、STT、Live2D runtime 或全双工实时语音。

## 内置形象与公开素材边界

鲸灵只内置一张透明 PNG：用户在 2026-08-14 明确授权公开使用的原图**左上角单体角色**。
文件为 [`src/renderer/assets/jingling/jingling-idle.png`](src/renderer/assets/jingling/jingling-idle.png)，
SHA-256 为
`A6E4F3D40D4195BE7ECA211A504EDD99C48DCBBB708A0F8BE4537600B390B9EE`。

- 此立绘以静态方式渲染；DSH 回复状态、点击、走路与睡眠等本地行为不会交换角色帧，避免回答时抖动或左右摆动。
- 不包含其它角色图、上游帧、Sprite Sheet 或动画素材；本地遗留素材已被 Git 忽略，也不会被生产构建引用。
- 角色的点击分区、拖动、甩飞、文件拖放、靠近问候与本地台词仍然可用；它们改变的是交互与位置，而不是未授权的角色画面。

完整的素材来源、精确选择范围与公开授权记录在
[`UPSTREAM_AUTHORIZATION.md`](UPSTREAM_AUTHORIZATION.md) 和
[`upstream.lock.json`](upstream.lock.json)。鲸灵不是 DeepSeek 官方角色、产品或合作项目。

## 能做什么

- 全工作区透明置顶窗口，任务栏隐藏；角色和展开面板以外的区域鼠标穿透。
- 点击角色打开对话面板；收起时无状态点、品牌文字、气泡或控制按钮。
- 对话与工作区严格分开：工作区只能使用你在系统目录选择器中明确选中的文件夹。
- 点击头部、身体、尾巴触发不同本地反应；拖动、甩飞、鼠标靠近与文件拖放不会把内容发送给 DSH 或模型。
- 主动陪伴默认关闭；开启后才允许随机散步、时段问候和本地轻提示。后台提示不调用模型，也不朗读。
- DSH 最终回复可用系统 SpeechSynthesis 朗读；可选本机 VOICEVOX 或用户自行安装的 `edge-tts`（默认微软晓晓）。Edge TTS 失败会回退到系统朗读。
- 角色菜单支持一次性的本地 `.vrm` 选择；VRM 仅在本次运行读取，不上传、不保存。Live2D 仅预留受信任运行时接口，不捆绑 Cubism Core、SDK 或模型。

## 运行

需要 Node.js 22+、已启动的 DSH，以及已安装的鲸灵 DSH 插件：

```powershell
dsh plugin --profile web add dsh-jingling
dsh --profile web

cd souldock-sidecar
npm ci
npm test
npm run build
npm start
```

默认 DSH 地址为 `http://127.0.0.1:3080`。若需修改，只能设置为另一个 loopback 地址：

```powershell
$env:SOULDOCK_DSH_BASE_URL='http://127.0.0.1:3080'
npm start
```

`SOULDOCK_*`、`souldock-sidecar:*` IPC 名称和 `/souldock/*` RPC 路径是兼容标识，
不会在界面中作为产品名展示；不要为改名而改动它们。

### 语音

默认使用系统 Web Speech。若自行合法安装并启动 VOICEVOX ENGINE，可显式启用：

```powershell
$env:SOULDOCK_TTS_PROVIDER='voicevox-local'
$env:SOULDOCK_VOICEVOX_URL='http://127.0.0.1:50021/'
$env:SOULDOCK_VOICEVOX_SPEAKER='1'
npm start
```

若希望使用 Edge TTS，需由你自己安装 Python 和
[`edge-tts`](https://github.com/rany2/edge-tts)：

```powershell
$env:SOULDOCK_TTS_PROVIDER='edge-tts'
$env:SOULDOCK_EDGE_TTS_PYTHON='python'
$env:SOULDOCK_EDGE_TTS_VOICE='zh-CN-XiaoxiaoNeural'
npm start
```

所有语音请求都由隔离的 Electron 主进程处理。VOICEVOX 只接受无凭据的 loopback
HTTP(S) 地址；Edge TTS 通过无 shell 的 `execFile` 启动，Sidecar 不下载、安装、
捆绑或保存 Python、语音资源、模型或密钥。

### Windows portable 包

```powershell
npm run dist:win
```

产物会写入 `release/`。该目录以及历史本地构建目录被 Git 忽略；公开仓库只提交可重建的源码和获授权的单张立绘。

## DSH 权限边界

Sidecar 只通过窄化的 loopback 路径访问 DSH：

- `/souldock/sidecar/status` 与 `/souldock/sidecar/poll`：在场状态。
- `/souldock/chat/open|send|poll|cancel|close`：专用聊天会话，只投影可见文本和脱敏状态。
- `/souldock/workspace/list` 与 `/souldock/workspace/task/*`：仅列出或操作 Sidecar 创建的独立工作任务。

主进程只连接 `127.0.0.1`、`localhost` 或 `::1`，并验证 DSH RPC 的 `type`、`rpcId` 和两层 `ok`。
renderer 无法获得任意 sessionId、通用 `/api`、斜杠命令、工具参数、审批正文、推理内容、记忆账本或任意文件路径。

## 致谢与许可

- AIRI 的透明桌面覆盖层、交互结构与 VRM 命中逻辑作为 MIT 参考迁移；完整告知见 [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md)。
- Electron、PixiJS、Three.js、`@pixiv/three-vrm` 与 Zod 的精确版本记录在 [`upstream.lock.json`](upstream.lock.json)。
- 本项目代码采用 [MIT License](LICENSE)。单张鲸灵立绘的公开使用范围以 [`UPSTREAM_AUTHORIZATION.md`](UPSTREAM_AUTHORIZATION.md) 的用户授权记录为准。
