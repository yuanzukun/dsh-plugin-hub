# 鲸灵 Jingling：第三方来源、许可与 Clean-room 边界

> 核验快照：2026-08-14（Asia/Shanghai）  
> 本文件是工程合规清单，不构成法律意见。Star、默认分支和许可证都可能变化；任何实际复用都必须锁定 commit/tag 后重新核验。

> **当前公开分发范围：** `dsh-jingling` 只包含 DSH 插件源码、文档与 `assets/jingling-idle.png` 这一张仓库权利人明确授权的待机头像。它不包含 Electron Sidecar、Live2D / VRM 模型、声音、动画素材、第三方角色或二进制；本文件中提到的 Sidecar 仅为独立研发与合规研究记录。

## 1. 默认政策

鲸灵的默认实现策略是：

1. 产品需求可以来自公开可观察行为和公开文档。
2. 核心代码、提示词、关系算法、记忆 schema、协议和 UI 默认原创。
3. 直接复用只优先考虑许可证清晰的 MIT/Apache-2.0 代码，并保留所有必要声明。
4. GPL/AGPL 或自定义限制许可证项目默认只用于研究和互操作规格，不将其代码混入计划中的宽松许可或闭源发行物。
5. 代码许可证不自动覆盖模型、角色、图片、Live2D/VRM、动作、字体、音频、声音、数据集或商标。
6. 将代码放到另一个进程、插件、Web 服务或 IPC 后面，不等于自动消除许可证义务。
7. 任何用户导入内容只代表用户提供，不代表鲸灵获得再分发权。

## 2. 当前来源登记

风险级别是鲸灵的工程发布风险，不是对许可证有效性的法律判断。

| 来源 | 快照 Stars | 核验许可 | 许可/声明 URL | 鲸灵允许的默认用途 | 风险 |
|---|---:|---|---|---|---|
| [moeru-ai/airi](https://github.com/moeru-ai/airi) | 47,855 | MIT | [LICENSE](https://github.com/moeru-ai/airi/blob/main/LICENSE) | 行为研究；审计后可选择性复用代码并保留声明 | 中：大仓依赖复杂，资产需另审 |
| [Open-LLM-VTuber/Open-LLM-VTuber](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber) | 13,225 | 主仓 LICENSE 为 MIT | [主仓 LICENSE](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber/blob/main/LICENSE) | 研究语音协议；审计后可复用明确位于主仓 MIT 边界内的代码 | 中高：前端和 Live2D 另有边界 |
| [Open-LLM-VTuber-Web](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber-Web) | 不并入主仓 Star | 自定义 Open-LLM-VTuber License 1.0，基于 Apache-2.0 但附加商业限制 | [Web LICENSE](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber-Web/blob/main/LICENSE) | 默认只做行为研究 | 高：收费访问、商业托管、商业再分发/改牌及商业嵌入等场景需单独许可 |
| [semperai/amica](https://github.com/semperai/amica) | 1,588 | 代码 MIT；3D 模型和图片按各作者许可 | [LICENSE](https://github.com/semperai/amica/blob/master/LICENSE) | 优先评估的 VRM/Tauri 代码参考 | 中：素材不能随代码许可推定 |
| [SillyTavern/SillyTavern](https://github.com/SillyTavern/SillyTavern) | 32,061 | AGPL-3.0 | [LICENSE](https://github.com/SillyTavern/SillyTavern/blob/release/LICENSE) | 公开格式兼容、行为研究 | 高：不复制代码、测试、内置提示词或 UI |
| [kwaroran/Risuai](https://github.com/kwaroran/Risuai) | 1,604 | GPL-3.0 | [LICENSE](https://github.com/kwaroran/Risuai/blob/main/LICENSE) | 公开格式兼容、行为研究 | 高：不混入默认核心 |
| [jofizcd/Soul-of-Waifu](https://github.com/jofizcd/Soul-of-Waifu) | 1,180 | GPL-3.0 | [LICENSE](https://github.com/jofizcd/Soul-of-Waifu/blob/main/LICENSE) | 需求研究与独立规格 | 高：记忆、关系、提示词和实现必须 clean-room |
| [etherfunlab/eros-engine](https://github.com/etherfunlab/eros-engine) | 41 | AGPL-3.0-only；README 另述商业许可 | [LICENSE](https://github.com/etherfunlab/eros-engine/blob/main/LICENSE) | 公开行为研究；或签署合适商业许可后再评估直接使用 | 高：官方 Eros Chat Web 客户端闭源 |
| [elizaOS/eliza](https://github.com/elizaOS/eliza) | 19,040 | MIT | [LICENSE](https://github.com/elizaOS/eliza/blob/develop/LICENSE) | 接口模式研究；审计后可复用小型独立组件 | 低至中：不要无必要嵌套完整 runtime |
| [letta-ai/letta](https://github.com/letta-ai/letta) | 24,231 | Apache-2.0 | [LICENSE](https://github.com/letta-ai/letta/blob/main/LICENSE) | 记忆服务接口参考 | 中：当前主仓为 legacy V1 server |
| [letta-ai/letta-code](https://github.com/letta-ai/letta-code) | 3,000 | Apache-2.0 | [LICENSE](https://github.com/letta-ai/letta-code/blob/main/LICENSE) | 记忆整理、MemFS、睡眠工作流研究；可选适配 | 低至中：不应嵌入第二套完整 harness |
| [mem0ai/mem0](https://github.com/mem0ai/mem0) | 63,207 | Apache-2.0 | [LICENSE](https://github.com/mem0ai/mem0/blob/main/LICENSE) | 推荐的可选 MemoryProvider | 中：开源和托管平台功能/指标不同 |
| [The-Lab-by-Ordinary-Company/utsuwa](https://github.com/The-Lab-by-Ordinary-Company/utsuwa) | 70 | 当前 AGPL-3.0-or-later；发布 0.12.0 及以前为 MIT | [LICENSE](https://github.com/The-Lab-by-Ordinary-Company/utsuwa/blob/main/LICENSE) | 公开行为研究；对旧版代码复用必须锁定旧 tag 并追溯文件来源 | 高：不能仅凭文件首次出现时间猜测许可 |

## 3. 关键许可证判定

### 3.1 可优先评估的宽松许可来源

#### AIRI — MIT

允许在满足 MIT 条件时复用代码，但在发行物中必须保留适用的版权和许可声明。AIRI 是多包仓库，直接复用前还要检查：

- 目标文件是否确实由该仓库许可覆盖；
- 子目录是否有额外 LICENSE、NOTICE 或第三方清单；
- npm、Rust、模型运行时等依赖的各自许可证；
- Live2D/VRM、声音、动作、图标、字体和示例角色是否允许再分发；
- 商标、角色形象或上游素材是否另有限制。

默认选择：参考架构，只复用小而独立、来源清楚的代码片段或包。

#### Amica — MIT 代码，素材分离

Amica README 明确区分代码与 3D 模型/图片权利。允许评估 renderer、Tauri glue 或事件状态机等代码，不允许把展示用模型和图片自动视为 MIT。

默认选择：作为 VRM Sidecar 的代码参考；当前发行包不带任何模型，未来任何单独分发的模型都必须先取得明确再分发授权。

#### elizaOS — MIT

Plugin、action、provider、evaluator、service 等接口思想可自由独立实现；如果直接复用具体代码，保留 MIT 声明并审计依赖。

默认选择：借鉴接口边界，不引入完整 Agent runtime。

#### Letta / Letta Code / Mem0 — Apache-2.0

Apache-2.0 通常适合商业使用和修改，但直接分发时仍需：

- 附上 Apache-2.0 文本；
- 保留适用的版权、归属和 NOTICE 内容；
- 标明对文件的重大修改；
- 注意其专利条款与商标不授权条款；
- 对传递依赖分别审计。

默认选择：通过可替换 adapter 连接，不让任何一个记忆后端成为角色数据的唯一存储格式。

### 3.2 Open-LLM-VTuber 必须拆分判断

不能只写“Open-LLM-VTuber 是 MIT”然后整体搬运：

1. Open-LLM-VTuber 主仓当前根 LICENSE 是 MIT。
2. 主仓另有 [LICENSE-Live2D.md](https://github.com/Open-LLM-VTuber/Open-LLM-VTuber/blob/main/LICENSE-Live2D.md)，示例 Live2D 资产有独立条件。
3. Open-LLM-VTuber-Web 使用自定义 Open-LLM-VTuber License 1.0。许可证允许个人非商业使用，也提到以广告、赞助或捐赠变现的 VTuber 内容；但对收费产品访问、商业托管、商业再分发/改牌和商业产品嵌入要求另行取得商业许可。

因此：

- 允许：阅读公开 UI 行为，独立写鲸灵界面；研究主仓公开协议；在锁定 commit 后复用明确 MIT 文件并保留声明。
- 默认禁止：把 Web 前端代码或其衍生 UI 直接用于鲸灵商业发行；打包示例 Live2D 模型；把前后端合称 MIT。
- 若业务模式尚未确定，也按未来可能商业化的高风险路径管理。

### 3.3 GPL 与 AGPL 来源

SillyTavern、RisuAI、Soul-of-Waifu、Eros Engine 和当前 Utsuwa 都处于 copyleft 风险区。GPL/AGPL 并非“不能商用”，但直接复制、修改、链接、组合或网络部署可能带来对应源代码提供、许可传递等义务，具体边界取决于事实与司法辖区。

鲸灵默认政策：

- 不从这些仓库复制源代码、测试、schema 实现、提示词、内置角色文本、UI 文案、CSS、图标或素材；
- 不通过翻译语言、改变量名、让模型改写或放进另一个进程来规避来源；
- 若未来决定以 GPL/AGPL 兼容方式发布相应组合，必须单独做架构和发行法律审查；
- 若直接采用 Eros Engine 的商业许可，保存合同范围、版本、部署数量和再分发权记录。

特别提醒：AGPL 程序通过网络向用户提供服务时可能触发额外源代码提供义务。把 AGPL 服务放到 localhost 或远程 API 后面并不是自动安全结论，也不能把 IPC 当作“洗许可证”的手段。

### 3.4 Utsuwa 的版本分界

Utsuwa 说明 0.12.0 及以前为 MIT，后续为 AGPL-3.0-or-later。工程上必须：

1. 锁定要研究或复用的具体 tag/commit；
2. 对每个文件确认它在该 tag 的许可证和来源；
3. 不把后续 AGPL 改动回移到旧 MIT 快照；
4. 不依据文件名相同就认定后续实现仍为 MIT；
5. 在 SBOM 中记录实际 commit。

若无法完成逐文件追溯，按当前 AGPL 高风险处理。

## 4. Clean-room 实施协议

### 阶段 A：行为研究

研究人员可以：

- 阅读 README、公开用户文档、演示视频和许可证；
- 运行官方发行版观察输入、输出和用户可见行为；
- 记录功能目标、性能指标、错误条件和互操作格式；
- 保存直接 URL、核验日期和版本。

研究记录不得包含：

- 可直接还原源代码的逐行描述；
- 项目私有或内置提示词全文；
- 大段复制的 schema、测试向量、UI 文案或 CSS；
- 未获授权的角色、图片、模型或声音。

### 阶段 B：独立功能规格

将研究结论重写为不依赖具体代码结构的需求，例如：

- 合格：“关系包含多个维度，每次变化必须指向一个用户可见事件，并有冷却与上限。”
- 不合格：“照抄 Eros/Soul 的字段名、常量、计算公式、提示词和更新顺序。”
- 合格：“语音被打断时，只把已播放文本写入可见历史。”
- 不合格：“复制 Open-LLM-VTuber 或 Eros 的端点、状态机代码和测试。”

规格必须解释为什么鲸灵选择自己的字段、阈值、状态机和安全边界。

### 阶段 C：来源隔离实现

实现人员以鲸灵独立规格和公开标准为输入。对 GPL/AGPL/自定义限制来源：

- 编码阶段不打开其源代码；
- 不让代码生成模型以该仓库文件作为改写输入；
- commit/PR 说明引用鲸灵需求编号，而不是“从某文件移植”；
- 若实现不可避免需要阅读协议代码，先暂停并升级为兼容性/法律评审。

理想情况下，研究人与实现人分离。人员不足时，也至少应将行为研究和实现分成有记录的两个阶段，并在开始实现前冻结独立规格。

### 阶段 D：相似性与来源审查

发布前检查：

- 文件名、类名、字段名、常量、注释和错误文本是否异常相似；
- 是否出现第三方版权头、角色名、独特 UI 文案或提示词；
- 依赖树是否引入 GPL/AGPL 或未知许可包；
- 生成文件、vendor、WASM、native binary 是否被常规扫描漏掉；
- 文档和截图是否包含无权分发的角色资产。

发现相似性时不能仅靠再改一次变量名解决；应追溯来源，必要时删除并根据独立规格重新实现。

## 5. 互操作与角色内容

### 5.1 Character Card / Lorebook

格式兼容本身不授权复制应用代码或公开分发内容。鲸灵导入器应：

- 根据公开格式文档和独立测试样本实现；
- 对未知字段无损保留；
- 不执行卡片中携带的脚本；
- 限制解压大小、媒体类型和嵌套深度；
- 默认把用户导入的角色设为私有；
- 导出时保留来源和权利说明字段；
- 不建立包含未知版权动漫角色、名人声音或付费提示词的官方素材库。

### 5.2 Live2D / VRM

渲染 SDK、模型格式和具体模型是不同权利层：

- Live2D Cubism SDK 有其自己的许可与分发条件；
- Live2D 模型的角色、美术、纹理和动作另行授权；
- VRM 格式或开源 renderer 不代表任何 VRM 模型可商用；
- 模型作者允许个人使用不等于允许捆绑、改造、训练或商业再分发。

当前 `dsh-jingling` 发行包只包含 `assets/jingling-idle.png` 这一张仓库权利人明确授权的待机头像，不包含模型或第三方角色。任何第三方模型应由用户自行导入，或在单独分发前由鲸灵与作者取得明确授权。

### 5.3 声音、TTS 与克隆声音

必须分别确认：

- TTS 引擎/SDK 许可；
- 声学模型和权重许可；
- 训练数据与声音人格权；
- 输出音频的商业使用条款；
- 用户是否有权克隆目标声音。

官方模板不得模拟在世人物或未经授权的配音演员。用户自定义声音应有权利确认、明显标识、删除入口和滥用举报机制。

### 5.4 用户生成与导入内容

用户提供内容不应被自动上传、公开市场化或用于训练。最低控制：

- 本地默认；
- 发布到市场前单独确认权利；
- 敏感内容和未成年人安全策略；
- 删除与下架机制；
- 角色包内记录 creator、source_url、license、allowed_uses、attribution。

## 6. 第三方登记模板

未来每次直接复用应在本文件或项目指定的依赖清单中填写：

| 字段 | 必填内容 |
|---|---|
| 名称 | 上游项目/包/资产名称 |
| 类型 | source、dependency、binary、model、asset、font、audio、dataset |
| 精确来源 | 仓库 URL + commit/tag，或下载 URL + 校验和 |
| 使用文件 | 鲸灵内路径或发行物位置 |
| 上游许可 | SPDX ID 或自定义许可证完整名称 |
| 许可证据 | 直接 LICENSE/NOTICE URL |
| 修改 | 是否修改、主要改动 |
| 发行义务 | LICENSE、NOTICE、源码提供、归属、链接或其他条件 |
| 资产权利 | 角色、美术、声音、模型是否另行授权 |
| 审查人/日期 | 完成核验的人和日期 |

不能填写精确来源和许可证据的组件不得进入发布包。

## 7. 发布闸门

每个 release 必须完成：

- [ ] 锁定所有依赖版本与 commit。
- [ ] 生成包含 JS、Rust、Python、native、WASM、模型和素材的 SBOM。
- [ ] 扫描未知、GPL、AGPL、自定义和 source-available 许可证。
- [ ] 人工检查自动扫描无法识别的 LICENSE/NOTICE。
- [ ] 在发行包中放入要求的第三方声明。
- [ ] 验证 Apache-2.0 NOTICE 与修改声明。
- [ ] 验证 MIT 版权和许可文本。
- [ ] 确认未带入 Open-LLM-VTuber-Web 受限代码。
- [ ] 确认未带入 SillyTavern、RisuAI、Soul-of-Waifu、Eros Engine 或当前 Utsuwa 代码。
- [ ] 逐个核验 Live2D/VRM、声音、动作、图片、字体和模型。
- [ ] 搜索仓库与构建产物中的第三方独特文本、版权头和角色名。
- [ ] 验证角色卡和用户导入内容没有进入官方发布包或测试快照。
- [ ] 记录每项豁免的负责人、理由、适用版本和截止日期。

任一高风险项无法确认时，发布应移除该组件，而不是以“以后补许可”放行。

## 8. 当前明确允许与禁止

### 默认允许

- 根据公开文档写原创多维关系系统；
- 用原创代码实现 Character Card/Lorebook 互操作；
- 审计后复用 Amica/AIRI/elizaOS 的明确 MIT 文件并保留声明；
- 通过 Apache-2.0 合规 adapter 接入 Mem0、Letta；
- 学习“允许角色保持沉默”“打断后只记录已播放内容”等通用产品思想；
- 发行原创 VRM 占位角色。

### 默认禁止

- 复制 Eros Engine 或 Soul-of-Waifu 的关系公式、提示词、schema 或实现；
- 将 Open-LLM-VTuber-Web 前端放入潜在商业产品而未取得相应许可；
- 从 GPL/AGPL 项目复制代码后用 AI 改写以掩盖来源；
- 把服务拆到 sidecar、localhost 或云端后宣称许可证不再适用；
- 捆绑来源不清的动漫角色、Live2D/VRM 模型、配音、动作、字体或图片；
- 用 Mem0 托管平台宣传数据为鲸灵开源适配背书；
- 将用户导入角色自动公开或作为训练数据。

## 9. 需要法律评审的触发条件

出现以下任何情况时，在编码或发布前进行专门评审：

- 要直接采用 GPL/AGPL 代码或其修改版；
- 要将鲸灵作为收费托管服务部署含 AGPL 组件的组合；
- 要复用 Open-LLM-VTuber-Web；
- 要使用 Eros Engine 商业许可；
- 要分发 Live2D Cubism SDK 或第三方模型；
- 要提供声音克隆、名人/配音演员声音；
- 要开设角色/插件市场并抽成；
- 要把用户对话、记忆或屏幕内容用于训练；
- 要将插件与 DSH 以何种许可证、链接方式或商店条款共同发布仍不明确。

研究层面的产品判断与功能证据见 [docs/RESEARCH.md](docs/RESEARCH.md)。

## 10. Electron Sidecar 研发采用清单（不属于 `dsh-jingling` 分发物）

下表只记录独立 `souldock-sidecar` 研发阶段可评估的技术边界；它不表示任何条目、素材或二进制已被 `dsh-jingling` 采用或随本公开仓库分发。任何独立桌面 release 都必须以自己的 lock、SBOM、构建产物和资产授权记录为准。

| 组件 | 锁定基线 | 许可 | 采用方式 |
|---|---:|---|---|
| [AIRI](https://github.com/moeru-ai/airi) `stage-tamagotchi` | 稳定窗口基线 `0.11.3` / `71dd65cb99b14eb24602eecfa43f0e571f011a13`；交互与聊天核对 `cc791fab954fbcfbef0bcb8d49ff75514f549c74` | MIT | 复用透明窗口、置顶、点击穿透、Controls Island / InteractiveArea 结构和 VRM 身体碰撞算法；不复制本机 dirty 工作树，不捆绑 AIRI 默认角色 / 模型；逐文件映射以 sidecar lock 为准 |
| [Electron](https://github.com/electron/electron) | `41.10.5` | MIT | 直接依赖，独立于 DSH host 进程；选择已修复当前 npm 审计问题的 41.x 版本 |
| [PixiJS](https://github.com/pixijs/pixijs) | sidecar lock 为准 | MIT | 直接依赖 `AnimatedSprite`，只搭配独立登记的 CC0 素材 |
| [Kenney Platformer Characters](https://www.kenney.nl/assets/platformer-characters) | 页面版本 1.0 | CC0 | 可选默认 Sprite；记录原始下载 URL、归档 SHA-256 和实际抽取文件，不使用 Kenney logo |
| `three` + [`@pixiv/three-vrm`](https://github.com/pixiv/three-vrm) | `three 0.184.0` / `three-vrm 3.5.5` | MIT | 直接依赖；只读取用户本次选择的本地 `.vrm`，展示内嵌 meta 但不把它当授权证明，不随包分发模型 |
| [`pixi-live2d-display`](https://github.com/guansss/pixi-live2d-display) | 未依赖 | MIT（库本体） | 稳定版面向 Pixi 6、beta 面向 Pixi 7，与当前 Pixi 8 不匹配；只保留受信任 provider seam，不执行用户选择的 runtime.js，不分发 Cubism Core、SDK 或模型 |
| AIRI `pipelines-audio` | 固定上游 tag / commit 后再 vendor | MIT / private workspace package | 可复用队列、取消和替换逻辑并保留 notice；它不是 npm 公共依赖，也不代表 AIRI 已提供外部 `speak(text)` API |
| Web SpeechSynthesis | 系统 API | 浏览器 / OS 能力 | alpha 的零密钥输出；支持停止，不等于实时对话或离线保证 |
| [`@ricky0123/vad-web`](https://github.com/ricky0123/vad) | `0.0.30` | ISC；Silero 模型 MIT | 后续可选输入打断信号；默认不启用麦克风，VAD 不等于 STT |
| VOICEVOX Engine | 用户已启动的本机服务 | LGPL-3.0 / 商业双许可，音库另有条款 | 只做 `127.0.0.1:50021` provider，不重分发官方完整应用 |
| Fish Audio / Fish Speech | API provider only | SDK 与权重许可不同；Fish Speech/S2 权重无默认商业权 | 只允许用户自填 API；核心包不 vendor 代码或权重 |

Open-LLM-VTuber-Web、自带 Live2D 模型、Spine runtime、来源不清的动漫 Sprite、AIRI / Amica 展示模型都不进入默认 sidecar。所谓“直接搬”必须同时满足固定来源、宽松许可、必要声明、可复现校验和与资产再分发权，不能只因仓库开源就整体复制。
