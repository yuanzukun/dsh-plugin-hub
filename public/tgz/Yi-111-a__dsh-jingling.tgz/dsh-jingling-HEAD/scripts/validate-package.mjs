import { access, readFile } from 'node:fs/promises'

const root = new URL('../', import.meta.url)
const pkg = JSON.parse(await readFile(new URL('package.json', root), 'utf8'))
const packageName = 'dsh-jingling'
const required = [
  'lib/index.js',
  'lib/agent.js',
  'lib/client.js',
  'lib/client.js.map',
  'cordis.patch.yml',
  'README.md',
  'README.en.md',
  'assets/jingling-idle.png',
]
await Promise.all(required.map(file => access(new URL(file, root))))

if (pkg.name !== packageName) throw new Error(`package name must be ${packageName}`)
if (pkg.dsh?.bundle?.patch !== './cordis.patch.yml') throw new Error('dsh.bundle.patch is missing')
if (pkg.dsh?.client?.platform !== 'web') throw new Error('dsh.client.platform must be web')
if (pkg.exports?.['./client'] !== './lib/client.js') throw new Error('./client export is missing')

const client = await readFile(new URL('lib/client.js', root), 'utf8')
if (!client.includes('window.__ModuleLoader__.load')) throw new Error('client bundle lacks DSH loader handoff')
if (!client.includes(`id: "${packageName}"`)) throw new Error('client bundle id does not match package name')

const patch = await readFile(new URL('cordis.patch.yml', root), 'utf8')
if (!/id:\s+souldock(?:\s|$)[\s\S]*?name:\s+dsh-jingling(?:\s|$)/.test(patch)) {
  throw new Error('bundle patch must activate dsh-jingling through the stable souldock id')
}

for (const file of ['src/index.js', 'src/agent.js', 'src/core.js']) {
  const source = await readFile(new URL(file, root), 'utf8')
  if (/session\.append\(\s*['"](?:companion|souldock)\//.test(source)) {
    throw new Error(`${file} appends an unsafe out-of-tree Session event`)
  }
}

const preset = await readFile(new URL('presets/souldock/agent.cordis.yml', root), 'utf8')
for (const requiredRow of ['@deepseek-ai/dsh-persona', 'dsh-jingling/agent']) {
  if (!preset.includes(requiredRow)) throw new Error(`companion preset lacks ${requiredRow}`)
}
for (const forbiddenRow of ['dsh-tool-bash', 'dsh-tool-pwsh', 'dsh-tool-fs', 'dsh-tool-web', 'dsh-tool-subagent', 'dsh-tool-schedule']) {
  if (preset.includes(forbiddenRow)) throw new Error(`companion preset must not include ${forbiddenRow}`)
}

const agent = await readFile(new URL('src/agent.js', root), 'utf8')
if (/\bsensitivity\s*:/.test(agent)) throw new Error('model-facing memory proposal must not expose a sensitivity downgrade parameter')
for (const forbiddenTool of ['companion_memory_forget', 'companion_character_import', 'companion_profile_update']) {
  if (agent.includes(`name: '${forbiddenTool}'`)) throw new Error(`model plane must not register self-confirming tool ${forbiddenTool}`)
}

const host = await readFile(new URL('src/index.js', root), 'utf8')
for (const service of ['storageDomain', 'agents', 'agentPresets', 'sessions', 'sessionPersistence']) {
  if (!host.includes(`'${service}'`)) throw new Error(`host inject lacks ${service}`)
}

const rpc = await readFile(new URL('src/rpc.js', root), 'utf8')
for (const endpoint of ['state/get', 'export/soul-pack', 'export/moment-card', 'export/private-archive', 'data/reset']) {
  if (!rpc.includes(`'${endpoint}'`)) throw new Error(`RPC lacks ${endpoint}`)
}

const readme = await readFile(new URL('README.md', root), 'utf8')
if (!readme.includes('# 鲸灵 Jingling') || !readme.includes('assets/jingling-idle.png')) {
  throw new Error('public README must identify Jingling and reference its approved avatar')
}

console.log('Jingling package validation passed.')
