import { cp, mkdir, stat } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const argument = process.argv.indexOf('--dsh-home')
const supplied = argument >= 0 ? process.argv[argument + 1] : undefined
if (argument >= 0 && !supplied) throw new Error('--dsh-home requires a directory')
const dshHome = resolve(supplied || process.env.DSH_HOME || join(homedir(), '.dsh'))
const source = fileURLToPath(new URL('../presets/souldock/', import.meta.url))
const root = join(dshHome, '.agent-presets')
const destination = join(root, 'souldock')

try {
  await stat(destination)
  throw new Error(`Refusing to overwrite existing preset: ${destination}`)
} catch (error) {
  if (error?.code !== 'ENOENT') throw error
}

await mkdir(root, { recursive: true })
await cp(source, destination, { recursive: true, errorOnExist: true, force: false })
console.log(`Installed Jingling preset at ${destination} (stable compatibility id: souldock)`)
