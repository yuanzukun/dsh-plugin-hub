import { mkdir, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { build } from 'esbuild'

const externalHost = ['@deepseek-ai/*']
const externalClient = [
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-connection/client',
  '@deepseek-ai/dsh-client-ui-conversation/client',
  'react',
  'react-dom',
  'react/jsx-runtime',
]

const libUrl = new URL('../lib/', import.meta.url)
const libPath = fileURLToPath(libUrl)

await mkdir(libUrl, { recursive: true })

await build({
  entryPoints: {
    index: fileURLToPath(new URL('../src/index.js', import.meta.url)),
    agent: fileURLToPath(new URL('../src/agent.js', import.meta.url)),
  },
  outdir: libPath,
  bundle: true,
  platform: 'node',
  target: 'node22',
  format: 'esm',
  external: externalHost,
  sourcemap: false,
  logLevel: 'info',
})

const client = await build({
  entryPoints: [fileURLToPath(new URL('../src/client/index.jsx', import.meta.url))],
  outfile: fileURLToPath(new URL('../lib/client.js', import.meta.url)),
  bundle: true,
  platform: 'browser',
  target: ['es2022'],
  format: 'cjs',
  external: externalClient,
  write: false,
  sourcemap: 'external',
  sourcesContent: true,
  jsx: 'automatic',
  loader: { '.png': 'dataurl' },
  footer: { js: '\n//# sourceMappingURL=client.js.map' },
  logLevel: 'info',
})

const javascript = client.outputFiles.find(file => file.path.endsWith('.js'))
const map = client.outputFiles.find(file => file.path.endsWith('.js.map'))
if (!javascript || !map) throw new Error('client build did not emit JavaScript and source map')

const body = new TextDecoder().decode(javascript.contents)
const wrapped = [
  'window.__ModuleLoader__.load({',
  '  id: "dsh-jingling",',
  '  factory: (require) => {',
  '    var module = { exports: {} }; var exports = module.exports;',
  body,
  '    return module.exports;',
  '  },',
  '});',
].join('\n')

await writeFile(new URL('../lib/client.js', import.meta.url), wrapped)
await writeFile(new URL('../lib/client.js.map', import.meta.url), map.contents)
