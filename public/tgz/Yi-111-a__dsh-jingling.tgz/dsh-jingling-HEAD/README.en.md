# 🐋 Jingling

> Your little DSH desktop companion · local-first · quietly present · never snooping

![Jingling idle avatar: blue-haired desktop companion](assets/jingling-idle.png)

**Jingling（鲸灵）** is a companion plugin for [DeepSeek Harness (DSH)](https://github.com/topics/dsh-plugin). She lives in your local environment, remembers only what you let her remember, and helps you organize your thoughts — but she never sneaks around and does things for you.

Current version: `dsh-jingling@0.1.0-alpha.13`, targeting DSH `0.1.0-rc.6`.

---

## ✨ What she can do

| Capability | Description |
| --- | --- |
| 🧠 **Reviewable memory** | She only remembers what you confirm. You can edit or forget it anytime. |
| 🎭 **Character Card import** | Supports Character Card V2 JSON. Imported content is treated as plain text and never executed. |
| 🖥️ **Browser companion page** | A gentle companion panel right inside the DSH Web interface. |
| 🪟 **Optional desktop body** | The DSH plugin already exposes the desktop-pet sidecar interface (status, polling, chat); this repository also includes the Windows transparent desktop-pet source under `sidecar/`, which can be launched with one click from the DSH Web UI after building. |
| 🔒 **Permission isolation** | Companion and work modes are separated. Real work uses a DSH `standard` session, with you choosing the folder and granting approval. |

---

## 🚀 Quick install

### From npm (recommended)

```powershell
dsh plugin --profile web add dsh-jingling
```

Then run the preset installer once:

```powershell
npm run install:preset
```

### From source

```powershell
git clone https://github.com/Yi-111-a/dsh-jingling.git
cd dsh-jingling
npm install --ignore-scripts
npm run check
npm pack --ignore-scripts
dsh plugin --profile web add .\dsh-jingling-0.1.0-alpha.13.tgz
npm run install:preset
dsh --profile web
```

Create a new session, select the **鲸灵 · Jingling** preset, send your first message, and she will appear.

---

## 🪟 Desktop companion (Windows Sidecar)

The sidecar source has been merged into this repository under `sidecar/`. Build it once:

```powershell
cd sidecar
npm ci
npm run dist:win
```

The build artifact will appear at `sidecar/release/jingling-sidecar-*.exe`. Then go back to the DSH Web Jingling page and click **“打开桌面伙伴”** (Launch Desktop Companion) to bring her to your desktop as a transparent window.

If you place the Sidecar elsewhere, set `sidecarExecutablePath` in your DSH config.

---

## 🛡️ Safety boundaries

- She does not read your screen, camera, microphone, clipboard, files, or browsing history.
- Memories must be **proposed and confirmed**; nothing is silently collected.
- She has no Shell, filesystem, network, or MCP access.
- Romantic styling is only available after explicitly enabling adult settings locally; not suitable for public services.

See the full notes in [docs/SAFETY.md](docs/SAFETY.md).

---

## 🏷️ A small note on names

The public name, npm package, and UI all say **鲸灵 / Jingling / dsh-jingling**. However, some low-level identifiers still use `souldock` (plugin ID, RPC path, preset directory, etc.) to keep early preview profiles compatible. This is not a second product — it just avoids disturbing your existing local data.

---

## 📦 Tags

`dsh` · `dsh-plugin` · `deepseek` · `deepseek-harness` · `deepseek-harness-plugin` · `ai-companion` · `desktop-pet` · `character-card` · `local-first` · `privacy` · `jingling` · `鲸灵`

---

## 📄 License

Jingling's own code is released under the [MIT](LICENSE) license. The public repository and npm package only redistribute the single owner-authorized Jingling idle avatar shown above. Imported character cards, avatars, models, and voices remain under their own licenses.

For more technical details, see [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and [docs/PRODUCT.md](docs/PRODUCT.md).
