/** DSH storage-domain declaration for the Jingling sidecar state. */

import { z } from 'zod'
import { defineDomain } from '@deepseek-ai/dsh-storage-domain'
import { createDefaultState, STATE_VERSION } from './core.js'

// The domain version protects the physical layout.  The state object's own
// version protects semantic migrations.  Core transitions always write the
// complete normalized object; passthrough lets future minor fields survive an
// older reader while the literal version still fails incompatible data loud.
export const soulDockStateSchema = z.object({
  version: z.literal(STATE_VERSION),
}).passthrough()

export const soulDockDomainSpec = defineDomain({
  name: 'souldock',
  version: 1,
  global: {
    schema: soulDockStateSchema,
    initial: createDefaultState(0),
  },
  tables: {},
})
