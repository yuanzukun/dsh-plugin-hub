/** Loopback-only Connection RPC adapter. */

function success(value) {
  return { ok: true, value: { ok: true, value } }
}

function rejected(error) {
  return {
    ok: true,
    value: {
      ok: false,
      error: { message: error instanceof Error ? error.message : String(error) },
    },
  }
}

function objectPayload(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new Error('request payload must be an object')
  }
  return payload
}

function requiredString(value, field, max = 1000) {
  if (typeof value !== 'string' || !value.trim()) throw new Error(`${field} must be a non-empty string`)
  if (value.length > max) throw new Error(`${field} exceeds ${max} characters`)
  return value.trim()
}

function resolveChat(chat) {
  const value = typeof chat === 'function' ? chat() : chat
  if (!value) throw new Error('Jingling desktop chat bridge is unavailable')
  return value
}

function resolveWorkspace(workspace) {
  const value = typeof workspace === 'function' ? workspace() : workspace
  if (!value) throw new Error('Jingling workspace bridge is unavailable')
  return value
}

export function createSoulDockRpcHandler(service, chat, workspace) {
  return async (endpoint, rawPayload, signal) => {
    try {
      if (signal.aborted) throw new Error('request cancelled')
      const payload = objectPayload(rawPayload ?? {})
      switch (endpoint) {
        case 'chat/open':
          if (Object.keys(payload).length !== 0) throw new Error('chat/open payload must be empty')
          return success(await resolveChat(chat).open(signal))
        case 'chat/send':
          return success(await resolveChat(chat).send(payload, signal))
        case 'chat/poll':
          return success(await resolveChat(chat).poll(payload, signal))
        case 'chat/cancel':
          return success(await resolveChat(chat).cancel(payload, signal))
        case 'chat/close':
          return success(resolveChat(chat).close(payload))
        case 'workspace/list':
          if (Object.keys(payload).length !== 0) throw new Error('workspace/list payload must be empty')
          return success(await resolveWorkspace(workspace).list(signal))
        case 'workspace/task/create':
          return success(await resolveWorkspace(workspace).create(payload, signal))
        case 'workspace/task/open':
          return success(await resolveWorkspace(workspace).open(payload, signal))
        case 'workspace/task/send':
          return success(await resolveWorkspace(workspace).send(payload, signal))
        case 'workspace/task/poll':
          return success(await resolveWorkspace(workspace).poll(payload, signal))
        case 'workspace/task/cancel':
          return success(await resolveWorkspace(workspace).cancel(payload, signal))
        case 'workspace/task/close':
          return success(resolveWorkspace(workspace).close(payload))
        case 'sidecar/status':
          return success(service.sidecarStatus())
        case 'sidecar/launch':
          return success(service.launchSidecar(payload.executablePath))
        case 'sidecar/poll':
          return success(await service.pollSidecar(
            payload.afterSequence ?? 0,
            payload.timeoutMilliseconds ?? 20_000,
            signal,
          ))
        case 'state/get':
          return success(service.clientState())
        case 'memory/create':
          return success(await service.createMemory(payload))
        case 'memory/confirm':
          return success(await service.confirmProposal(requiredString(payload.id, 'id', 100)))
        case 'memory/reject':
          return success(await service.rejectProposal(requiredString(payload.id, 'id', 100)))
        case 'memory/forget':
          return success(await service.forget(requiredString(payload.id, 'id', 100)))
        case 'character/preview':
          return success(service.previewCharacterCard(payload.card))
        case 'character/import':
          return success(await service.importCharacter(payload.card))
        case 'persona/update':
          return success(await service.updatePersona(payload.patch ?? {}))
        case 'persona/activate':
          return success(await service.activatePersona(requiredString(payload.id, 'id', 160)))
        case 'settings/update':
          return success(await service.updatePreferences(payload.patch ?? {}))
        case 'export/soul-pack':
          return success(service.soulPack())
        case 'export/moment-card':
          return success(service.momentCard(payload))
        case 'export/private-archive':
          if (payload.confirm !== 'PRIVATE_EXPORT') throw new Error('private export requires explicit confirmation')
          return success(service.privateArchive())
        case 'data/reset':
          if (payload.confirm !== 'DELETE') throw new Error('data reset requires confirm="DELETE"')
          return success(await service.resetAll())
        default:
          throw new Error(`unknown Jingling endpoint: ${endpoint}`)
      }
    } catch (error) {
      return rejected(error)
    }
  }
}
