/**
 * Least-privilege desktop chat bridge over DSH's in-process ApiProxy.
 *
 * The bridge deliberately does not expose the ApiProxy itself. It owns one
 * process-local capability handle, addresses only dedicated Jingling sessions,
 * and projects raw DSH history/events into user-visible text. Memory ledgers,
 * prompt context, reasoning, tools, attachments, approvals, and arbitrary
 * session ids never cross this boundary.
 */

import { randomUUID } from 'node:crypto'

export const CHAT_SESSION_PREFIX = 'souldock-sidecar-'
export const CHAT_PRESET_ID = 'souldock'
export const CHAT_INPUT_MAX_CODE_POINTS = 8_000
export const CHAT_OUTPUT_MAX_CODE_POINTS = 12_000
export const CHAT_HISTORY_MESSAGES = 40
export const CHAT_EVENT_BUFFER = 256
export const CHAT_POLL_MAX_MILLISECONDS = 25_000

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function stringCodePoints(value) {
  return [...String(value)]
}

function truncateCodePoints(value, maximum) {
  const points = stringCodePoints(value)
  if (points.length <= maximum) return points.join('')
  return `${points.slice(0, Math.max(0, maximum - 1)).join('')}…`
}

function visibleText(message) {
  const content = message?.content
  if (!Array.isArray(content)) return ''
  return truncateCodePoints(content
    .filter(block => block?.type === 'text' && typeof block.text === 'string')
    .map(block => block.text)
    .join('\n')
    .replace(/\u0000/g, '')
    .trim(), CHAT_OUTPUT_MAX_CODE_POINTS)
}

function safeIdentifier(value, maximum = 180) {
  const text = String(value ?? '').trim()
  return /^[a-zA-Z0-9._:-]+$/.test(text) && text.length <= maximum ? text : undefined
}

function eventTime(event) {
  return Number.isFinite(event?.time) ? event.time : Date.now()
}

function eventSequence(event) {
  return Number.isSafeInteger(event?.seq) && event.seq >= 0 ? event.seq : undefined
}

function streamKey(turn, step) {
  return `${String(turn)}:${String(step)}`
}

function surfaceEvents(events) {
  const surface = []
  for (const event of events) {
    if (!['user/message', 'assistant/message', 'tool/result'].includes(event?.type)) continue
    const operation = event.surfaceOp
    if (!isRecord(operation) || operation.op !== 'replace') {
      surface.push(event)
      continue
    }
    const start = surface.findIndex(item => item.seq === operation.start)
    const end = surface.findIndex(item => item.seq === operation.end)
    if (start >= 0 && end >= start) surface.splice(start, end - start + 1, event)
    else {
      const retained = surface.filter(item => item.seq < operation.start || item.seq > operation.end)
      surface.splice(0, surface.length, ...retained, event)
    }
  }
  return surface
}

function messageFromSurfaceEvent(event) {
  if (event.type === 'user/message') {
    if (event.data?.source?.kind !== 'user') return undefined
    const text = visibleText(event.data)
    const id = safeIdentifier(event.data?.id, 200)
    if (!text || !id) return undefined
    return { id, role: 'user', text, at: eventTime(event) }
  }
  if (event.type === 'assistant/message') {
    const message = event.data?.message
    const text = visibleText(message)
    const id = safeIdentifier(message?.id, 200)
    if (!text || !id) return undefined
    return { id, role: 'assistant', text, at: eventTime(event) }
  }
  return undefined
}

/** Convert one history tail into the only transcript shape the sidecar may see. */
export function projectChatHistory(entries, limit = CHAT_HISTORY_MESSAGES) {
  const events = Array.isArray(entries)
    ? entries.map(entry => entry?.event ?? entry).filter(isRecord).sort((a, b) => (a.seq ?? 0) - (b.seq ?? 0))
    : []
  const projected = surfaceEvents(events).map(messageFromSurfaceEvent).filter(Boolean)
  const partials = new Map()
  let lastSourceSeq = -1

  for (const event of events) {
    const sourceSeq = eventSequence(event)
    if (sourceSeq !== undefined) lastSourceSeq = Math.max(lastSourceSeq, sourceSeq)
    if (event.type === 'assistant/chunk') {
      const chunk = event.data?.chunk
      if (chunk?.type !== 'text-delta' || typeof chunk.text !== 'string' || !chunk.text) continue
      const key = streamKey(event.data?.turn, event.data?.step)
      const current = partials.get(key) ?? {
        turn: event.data?.turn,
        step: event.data?.step,
        text: '',
        sourceSeq: -1,
      }
      current.text = truncateCodePoints(`${current.text}${chunk.text.replace(/\u0000/g, '')}`, CHAT_OUTPUT_MAX_CODE_POINTS)
      current.sourceSeq = sourceSeq ?? current.sourceSeq
      partials.set(key, current)
    }
    else if (event.type === 'assistant/message') {
      partials.delete(streamKey(event.data?.turn, event.data?.step))
    }
  }

  const partial = [...partials.values()].filter(item => item.text.trim()).sort((a, b) => a.sourceSeq - b.sourceSeq).at(-1)
  const boundedLimit = Number.isSafeInteger(limit) && limit > 0 ? limit : CHAT_HISTORY_MESSAGES
  return {
    messages: projected.slice(-boundedLimit),
    partial: partial === undefined ? undefined : {
      turn: partial.turn,
      step: partial.step,
      text: partial.text,
    },
    truncated: projected.length > boundedLimit,
    lastSourceSeq,
  }
}

function requireObject(value, name) {
  if (!isRecord(value)) throw new Error(`${name} must be an object`)
  return value
}

function assertOnlyKeys(value, allowed, name) {
  const extras = Object.keys(value).filter(key => !allowed.includes(key))
  if (extras.length > 0) throw new Error(`${name} contains unsupported fields: ${extras.join(', ')}`)
}

function requireIdentifier(value, name) {
  const id = safeIdentifier(value)
  if (!id) throw new Error(`${name} must be a safe non-empty identifier`)
  return id
}

function requireInputText(value) {
  if (typeof value !== 'string') throw new Error('text must be a string')
  if (value.includes('\u0000')) throw new Error('text must not contain NUL characters')
  if (!value.trim()) throw new Error('text must not be empty')
  if (stringCodePoints(value).length > CHAT_INPUT_MAX_CODE_POINTS) {
    throw new Error(`text exceeds ${CHAT_INPUT_MAX_CODE_POINTS} Unicode code points`)
  }
  if (value.trimStart().startsWith('/')) throw new Error('slash commands are not available in desktop chat')
  return value
}

function requireTimeZone(value) {
  if (value === undefined) return undefined
  if (typeof value !== 'string' || !value.trim() || value.length > 100 || value.includes('\u0000')) {
    throw new Error('clientTimeZone must be a non-empty string of at most 100 characters')
  }
  return value.trim()
}

function abortError() {
  return new Error('request cancelled')
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError()
}

function publicApiError(code) {
  if (code === 'model-unavailable') return '当前 DSH 模型不可用，请先在 DSH 中完成模型配置。'
  if (code === 'session-not-found') return '桌宠会话已失效，请重新打开聊天。'
  if (code === 'cancelled') return '请求已取消。'
  return 'DSH 拒绝了桌宠聊天请求。'
}

function mergePostHistory(snapshot, events) {
  const messages = [...snapshot.messages]
  const known = new Set(messages.map(message => message.id))
  let partial = snapshot.partial === undefined ? undefined : { ...snapshot.partial }

  for (const event of events) {
    if (event.type === 'user-message') {
      if (known.has(event.messageId)) continue
      known.add(event.messageId)
      messages.push({ id: event.messageId, role: 'user', text: event.text, at: event.at })
    }
    else if (event.type === 'assistant-delta') {
      if (partial?.turn !== event.turn || partial?.step !== event.step) {
        partial = { turn: event.turn, step: event.step, text: '' }
      }
      partial.text = truncateCodePoints(`${partial.text}${event.delta}`, CHAT_OUTPUT_MAX_CODE_POINTS)
    }
    else if (event.type === 'assistant-final') {
      if (!known.has(event.messageId)) {
        known.add(event.messageId)
        messages.push({ id: event.messageId, role: 'assistant', text: event.text, at: event.at })
      }
      if (partial?.turn === event.turn && partial?.step === event.step) partial = undefined
    }
  }

  return {
    messages: messages.slice(-CHAT_HISTORY_MESSAGES),
    partial,
    truncated: snapshot.truncated || messages.length > CHAT_HISTORY_MESSAGES,
  }
}

export class SoulDockChatBridge {
  constructor(ctx, service, apiProxy) {
    if (!apiProxy?.sessions) throw new Error('souldock chat requires DSH apiProxy.sessions')
    this.ctx = ctx
    this.service = service
    this.api = apiProxy
    this.handles = new Map()
    this.openOperation = undefined
  }

  ownsSession(sessionId) {
    return typeof sessionId === 'string' && sessionId.startsWith(CHAT_SESSION_PREFIX)
  }

  async open(signal) {
    if (this.openOperation !== undefined) return this.openOperation
    const operation = this.openOnce(signal)
    this.openOperation = operation
    try {
      return await operation
    }
    finally {
      if (this.openOperation === operation) this.openOperation = undefined
    }
  }

  async openOnce(signal) {
    throwIfAborted(signal)
    const listed = await this.invoke('session.list', request => this.api.sessions.list(request), {})
    throwIfAborted(signal)
    const candidates = Array.isArray(listed?.items) ? listed.items.filter(item => (
      this.ownsSession(item?.sessionId)
      && item.agentPreset === CHAT_PRESET_ID
      && item.parentSessionId === undefined
      && item.origin !== 'subagent'
    )).sort((left, right) => Number(right.updatedAt ?? 0) - Number(left.updatedAt ?? 0)) : []

    let sessionId
    let running = false
    let cwd
    if (candidates.length > 0) {
      sessionId = candidates[0].sessionId
      running = candidates[0].running === true
      cwd = candidates[0].cwd
    }
    else {
      sessionId = `${CHAT_SESSION_PREFIX}${randomUUID()}`
      const created = await this.invoke('session.create', request => this.api.sessions.create(request), {
        sessionId,
        agentPreset: CHAT_PRESET_ID,
      })
      if (created?.sessionId !== sessionId || created?.agentPreset !== CHAT_PRESET_ID) {
        throw new Error('DSH did not create the requested Jingling desktop session')
      }
    }
    throwIfAborted(signal)

    this.closeAll(new Error('chat handle replaced'))
    const handle = this.createHandle(sessionId, running ? 'running' : 'idle', cwd)
    this.handles.set(handle.chatId, handle)
    try {
      const history = await this.invoke('session.history', request => this.api.sessions.history(request), {
        sessionId,
        maxMessages: 120,
      })
      throwIfAborted(signal)
      const snapshot = projectChatHistory(history?.events)
      const postHistory = handle.events.filter(event => event.sourceSeq === undefined || event.sourceSeq > snapshot.lastSourceSeq)
      const merged = mergePostHistory(snapshot, postHistory)
      const persona = this.service.sidecarStatus().persona
      return {
        version: 1,
        chatId: handle.chatId,
        sequence: handle.sequence,
        status: handle.status,
        persona: { id: String(persona.id), name: String(persona.name) },
        messages: merged.messages,
        ...(merged.partial === undefined ? {} : { partial: merged.partial }),
        hasOlder: history?.hasMore === true || merged.truncated,
        limits: { inputCodePoints: CHAT_INPUT_MAX_CODE_POINTS },
      }
    }
    catch (error) {
      this.closeHandle(handle, error)
      throw error
    }
  }

  async send(rawPayload, signal) {
    const payload = requireObject(rawPayload, 'chat/send payload')
    assertOnlyKeys(payload, ['chatId', 'clientMessageId', 'text', 'clientTimeZone'], 'chat/send payload')
    const handle = this.requireHandle(requireIdentifier(payload.chatId, 'chatId'))
    const clientMessageId = requireIdentifier(payload.clientMessageId, 'clientMessageId')
    const text = requireInputText(payload.text)
    const clientTimeZone = requireTimeZone(payload.clientTimeZone)
    throwIfAborted(signal)
    const fingerprint = JSON.stringify([text, clientTimeZone ?? null])
    const acceptedFingerprint = handle.acceptedMessages.get(clientMessageId)
    if (acceptedFingerprint !== undefined) {
      if (acceptedFingerprint !== fingerprint) throw new Error('clientMessageId was already used for different text')
      return { accepted: true, clientMessageId }
    }
    const pending = handle.pendingSends.get(clientMessageId)
    if (pending !== undefined) {
      if (pending.fingerprint !== fingerprint) throw new Error('clientMessageId is already sending different text')
      return pending.promise
    }

    const promise = this.sendOnce(handle, { clientMessageId, text, clientTimeZone, fingerprint }, signal)
    handle.pendingSends.set(clientMessageId, { fingerprint, promise })
    try {
      return await promise
    }
    finally {
      if (handle.pendingSends.get(clientMessageId)?.promise === promise) handle.pendingSends.delete(clientMessageId)
    }
  }

  async sendOnce(handle, { clientMessageId, text, clientTimeZone, fingerprint }, signal) {
    // Re-adopt the exact preset immediately before dispatch. rc.6 create is
    // idempotent for the same identity/cwd and rejects a blank session whose
    // preset was switched, closing the only race between open and first send.
    const ensured = await this.invoke('session.create', request => this.api.sessions.create(request), {
      sessionId: handle.sessionId,
      agentPreset: CHAT_PRESET_ID,
      ...(handle.cwd === undefined ? {} : { cwd: handle.cwd }),
    })
    if (ensured?.sessionId !== handle.sessionId || ensured?.agentPreset !== CHAT_PRESET_ID) {
      throw new Error('desktop chat session no longer uses the Jingling preset')
    }
    throwIfAborted(signal)
    const value = await this.invoke('session.prompt', request => this.api.sessions.prompt(request), {
      sessionId: handle.sessionId,
      mode: 'queue',
      content: [{ type: 'text', text }],
      ...(clientTimeZone === undefined ? {} : { clientTimeZone }),
    }, clientMessageId)
    throwIfAborted(signal)
    if (value?.accepted !== true || value.command !== undefined) throw new Error('DSH did not accept the desktop chat prompt')
    handle.acceptedMessages.set(clientMessageId, fingerprint)
    if (handle.acceptedMessages.size > 128) handle.acceptedMessages.delete(handle.acceptedMessages.keys().next().value)
    return { accepted: true, clientMessageId }
  }

  async poll(rawPayload, signal) {
    const payload = requireObject(rawPayload, 'chat/poll payload')
    assertOnlyKeys(payload, ['chatId', 'afterSequence', 'timeoutMilliseconds'], 'chat/poll payload')
    const chatId = requireIdentifier(payload.chatId, 'chatId')
    const afterSequence = Number(payload.afterSequence)
    const timeoutMilliseconds = Number(payload.timeoutMilliseconds)
    if (!Number.isSafeInteger(afterSequence) || afterSequence < 0) {
      throw new Error('afterSequence must be a non-negative safe integer')
    }
    if (!Number.isSafeInteger(timeoutMilliseconds) || timeoutMilliseconds < 0 || timeoutMilliseconds > CHAT_POLL_MAX_MILLISECONDS) {
      throw new Error(`timeoutMilliseconds must be an integer from 0 through ${CHAT_POLL_MAX_MILLISECONDS}`)
    }
    let handle = this.requireHandle(chatId)
    if (afterSequence > handle.sequence) throw new Error('afterSequence is ahead of the chat stream')
    const oldest = handle.events[0]?.sequence
    if (oldest !== undefined && afterSequence < oldest - 1) {
      return { version: 1, sequence: handle.sequence, status: handle.status, events: [], resetRequired: true }
    }
    let available = handle.events.filter(event => event.sequence > afterSequence)
    if (available.length === 0 && timeoutMilliseconds > 0) {
      await this.waitForEvent(handle, afterSequence, timeoutMilliseconds, signal)
      handle = this.requireHandle(chatId)
      available = handle.events.filter(event => event.sequence > afterSequence)
    }
    throwIfAborted(signal)
    return { version: 1, sequence: handle.sequence, status: handle.status, events: structuredClone(available) }
  }

  async cancel(rawPayload, signal) {
    const payload = requireObject(rawPayload, 'chat/cancel payload')
    assertOnlyKeys(payload, ['chatId'], 'chat/cancel payload')
    const handle = this.requireHandle(requireIdentifier(payload.chatId, 'chatId'))
    throwIfAborted(signal)
    const value = await this.invoke('session.cancel', request => this.api.sessions.cancel(request), {
      sessionId: handle.sessionId,
    })
    throwIfAborted(signal)
    if (value?.accepted !== true) throw new Error('DSH did not accept chat cancellation')
    return { accepted: true }
  }

  close(rawPayload) {
    const payload = requireObject(rawPayload, 'chat/close payload')
    assertOnlyKeys(payload, ['chatId'], 'chat/close payload')
    const handle = this.requireHandle(requireIdentifier(payload.chatId, 'chatId'))
    this.closeHandle(handle, new Error('chat closed'))
    return { closed: true }
  }

  acceptSessionEvent(session, event) {
    const sessionId = String(session?.id ?? '')
    if (!this.ownsSession(sessionId) || !isRecord(event)) return
    for (const handle of this.handles.values()) {
      if (handle.sessionId !== sessionId) continue
      this.projectEvent(handle, event)
    }
  }

  acceptStatus(agent, status) {
    const sessionId = String(agent?.id ?? '')
    if (!this.ownsSession(sessionId) || !['running', 'idle'].includes(status)) return
    for (const handle of this.handles.values()) {
      if (handle.sessionId === sessionId) this.setStatus(handle, status)
    }
  }

  acceptError(agent) {
    const sessionId = String(agent?.id ?? '')
    if (!this.ownsSession(sessionId)) return
    for (const handle of this.handles.values()) {
      if (handle.sessionId !== sessionId) continue
      handle.status = 'error'
      this.appendError(handle, { type: 'error', at: Date.now(), code: 'failed', message: '生成失败，请稍后重试。' })
    }
  }

  dispose() {
    this.closeAll(new Error('chat bridge disposed'))
  }

  createHandle(sessionId, status, cwd) {
    return {
      chatId: `chat-${randomUUID()}`,
      sessionId,
      cwd,
      status,
      sequence: 0,
      events: [],
      waiters: new Set(),
      acceptedMessages: new Map(),
      pendingSends: new Map(),
      streamLengths: new Map(),
    }
  }

  requireHandle(chatId) {
    const handle = this.handles.get(chatId)
    if (!handle) throw new Error('chat handle is missing or expired; reopen the desktop chat')
    return handle
  }

  closeAll(error) {
    for (const handle of [...this.handles.values()]) this.closeHandle(handle, error)
  }

  closeHandle(handle, error) {
    if (!this.handles.delete(handle.chatId)) return
    for (const waiter of [...handle.waiters]) waiter.finish(error)
  }

  setStatus(handle, status) {
    if (handle.status === status) return
    handle.status = status
    this.append(handle, { type: 'status', at: Date.now(), status })
  }

  projectEvent(handle, event) {
    const sourceSeq = eventSequence(event)
    const at = eventTime(event)
    if (event.type === 'turn/start') {
      this.setStatus(handle, 'running')
      return
    }
    if (event.type === 'turn/end') {
      const kind = event.data?.reason?.kind
      if (kind && kind !== 'completed') {
        const code = ['aborted', 'blocked', 'max-tokens'].includes(kind) ? kind : 'failed'
        const message = code === 'aborted'
          ? '回答已停止。'
          : code === 'blocked'
            ? '本次回答被安全策略阻止。'
            : code === 'max-tokens'
              ? '回答达到长度上限。'
              : '生成失败，请稍后重试。'
        this.appendError(handle, { type: 'error', at, ...(sourceSeq === undefined ? {} : { sourceSeq }), code, message })
      }
      this.setStatus(handle, 'idle')
      return
    }
    if (event.type === 'user/message') {
      if (event.data?.source?.kind !== 'user') return
      const text = visibleText(event.data)
      const messageId = safeIdentifier(event.data?.id, 200)
      if (!text || !messageId) return
      const clientMessageId = safeIdentifier(event.data?.source?.rpcId)
      this.append(handle, {
        type: 'user-message', at,
        ...(sourceSeq === undefined ? {} : { sourceSeq }),
        messageId,
        ...(clientMessageId === undefined ? {} : { clientMessageId }),
        text,
      })
      return
    }
    if (event.type === 'assistant/chunk') {
      const chunk = event.data?.chunk
      if (chunk?.type !== 'text-delta' || typeof chunk.text !== 'string' || !chunk.text) return
      const key = streamKey(event.data?.turn, event.data?.step)
      const used = handle.streamLengths.get(key) ?? 0
      const remaining = CHAT_OUTPUT_MAX_CODE_POINTS - used
      if (remaining <= 0) return
      const delta = stringCodePoints(chunk.text.replace(/\u0000/g, '')).slice(0, remaining).join('')
      if (!delta) return
      handle.streamLengths.set(key, used + stringCodePoints(delta).length)
      this.append(handle, {
        type: 'assistant-delta', at,
        ...(sourceSeq === undefined ? {} : { sourceSeq }),
        turn: event.data?.turn,
        step: event.data?.step,
        delta,
      })
      return
    }
    if (event.type === 'assistant/message') {
      const message = event.data?.message
      const text = visibleText(message)
      const messageId = safeIdentifier(message?.id, 200)
      const key = streamKey(event.data?.turn, event.data?.step)
      handle.streamLengths.delete(key)
      if (!text || !messageId) return
      this.append(handle, {
        type: 'assistant-final', at,
        ...(sourceSeq === undefined ? {} : { sourceSeq }),
        turn: event.data?.turn,
        step: event.data?.step,
        messageId,
        text,
      })
    }
  }

  append(handle, event) {
    const entry = { ...event, sequence: ++handle.sequence }
    handle.events.push(entry)
    if (handle.events.length > CHAT_EVENT_BUFFER) {
      handle.events.splice(0, handle.events.length - CHAT_EVENT_BUFFER)
    }
    for (const waiter of [...handle.waiters]) {
      if (entry.sequence > waiter.afterSequence) waiter.finish()
    }
    return entry
  }

  appendError(handle, event) {
    const previous = handle.events.at(-1)
    if (
      previous?.type === 'error'
      && previous.code === event.code
      && previous.message === event.message
      && Math.abs(Number(event.at) - Number(previous.at)) <= 5_000
    ) return previous
    return this.append(handle, event)
  }

  waitForEvent(handle, afterSequence, timeoutMilliseconds, signal) {
    throwIfAborted(signal)
    return new Promise((resolve, reject) => {
      let timer
      const waiter = {
        afterSequence,
        finish: (error) => {
          if (!handle.waiters.delete(waiter)) return
          if (timer !== undefined) clearTimeout(timer)
          signal?.removeEventListener('abort', onAbort)
          if (error) reject(error)
          else resolve()
        },
      }
      const onAbort = () => waiter.finish(abortError())
      handle.waiters.add(waiter)
      signal?.addEventListener('abort', onAbort, { once: true })
      timer = setTimeout(() => waiter.finish(), timeoutMilliseconds)
      timer.unref?.()
    })
  }

  async invoke(label, call, payload, rpcId = `chat-${randomUUID()}`) {
    let response
    try {
      response = await call({ rpcId, payload })
    }
    catch (error) {
      this.ctx?.logger?.warn?.(`souldock chat: ${label} transport failed: ${String(error)}`)
      throw new Error('无法连接 DSH 聊天服务。')
    }
    if (!isRecord(response) || response.rpcId !== rpcId || !isRecord(response.result)) {
      this.ctx?.logger?.warn?.(`souldock chat: ${label} returned an invalid response envelope`)
      throw new Error('DSH 返回了无效的聊天响应。')
    }
    if (response.result.ok !== true) {
      const code = String(response.result.error?.code ?? 'internal')
      this.ctx?.logger?.warn?.(`souldock chat: ${label} rejected (${code}): ${String(response.result.error?.message ?? '')}`)
      throw new Error(publicApiError(code))
    }
    return response.result.value
  }
}
