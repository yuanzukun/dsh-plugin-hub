/** Durable Jingling service shared by the DSH agent adapter and browser RPC. */

import { randomUUID } from 'node:crypto'
import { spawn, execFileSync } from 'node:child_process'
import { readdirSync, existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { basename, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  activatePersona,
  activePersona,
  addConfirmedMemory,
  buildCompanionContext,
  companionSummary,
  createDefaultState,
  evaluateProactiveCheckIn,
  forgetMemory,
  importCharacterCard,
  normalizeState,
  parseCharacterCardV2,
  proposeMemory,
  publicSoulPack,
  publicMomentCard,
  recordProactiveCheckIn,
  recallMemories,
  stateForClient,
  updateActivePersona,
  updateSettings,
} from './core.js'

const SIDECAR_EXE = /^(?:jingling|souldock)-sidecar-(.+)\.exe$/i

function versionKey(name) {
  const match = name.match(SIDECAR_EXE)
  if (!match) return []
  return (match[1].match(/(\d+)/g) ?? []).map(Number)
}

function compareVersions(a, b) {
  const len = Math.max(a.length, b.length)
  for (let i = 0; i < len; i++) {
    const diff = (a[i] ?? 0) - (b[i] ?? 0)
    if (diff !== 0) return diff
  }
  return 0
}

function nowIso() {
  return new Date().toISOString()
}

export class SoulDockService {
  constructor(globalState, options = {}) {
    this.globalState = globalState
    this.operationTail = Promise.resolve()
    // Assistant proposals are deliberately process-memory-only. They vanish
    // on DSH exit and never enter storage-domain before loopback UI approval.
    this.pendingProposals = []
    // The desktop sidecar stream is deliberately process-memory-only. It
    // contains coarse activity plus optional assistant text, never memory,
    // persona prompts, tool arguments, or durable conversation history.
    this.sidecar = {
      sequence: 0,
      events: [],
      waiters: new Set(),
      shareAssistantText: options.shareAssistantText === true,
      executablePath: options.sidecarExecutablePath || '',
      process: null,
    }
    this.activity = {
      phase: 'idle',
      lastEvent: null,
      detail: '鲸灵已就绪',
      updatedAt: nowIso(),
    }
  }

  async initialize() {
    const state = normalizeState(this.globalState.get())
    // Persist normalization so expired/private legacy proposals and unsafe
    // legacy personas are removed from the durable document, not merely hidden
    // from one read.
    await this.globalState.set(state.createdAt === new Date(0).toISOString() ? createDefaultState() : state)
  }

  read() {
    return normalizeState(this.globalState.get())
  }

  clientState() {
    this.prunePendingProposals()
    const view = stateForClient(this.read(), this.activity)
    view.proposals = structuredClone(this.pendingProposals.filter(item => item.personaId === view.activePersonaId))
    return view
  }

  summary() {
    return companionSummary(this.read(), this.activity)
  }

  sidecarStatus() {
    const persona = activePersona(this.read())
    return {
      version: 1,
      sequence: this.sidecar.sequence,
      persona: { id: persona.id, name: persona.name },
      runtime: structuredClone(this.activity),
      capabilities: {
        assistantText: this.sidecar.shareAssistantText,
        voiceOutput: this.sidecar.shareAssistantText,
        voiceInput: false,
      },
      privacy: 'No memories, proposals, persona prompt, tool arguments, screen, camera, microphone, or clipboard data.',
    }
  }

  async pollSidecar(afterSequence = 0, timeoutMilliseconds = 20_000, signal) {
    const after = Number(afterSequence)
    if (!Number.isSafeInteger(after) || after < 0) throw new Error('afterSequence must be a non-negative safe integer')
    const timeout = Math.max(0, Math.min(25_000, Number(timeoutMilliseconds) || 0))
    const available = this.sidecar.events.filter(event => event.sequence > after)
    if (available.length > 0 || timeout === 0) {
      return { ...this.sidecarStatus(), events: structuredClone(available) }
    }
    if (signal?.aborted) throw new Error('request cancelled')

    await new Promise((resolve, reject) => {
      let timer
      const waiter = {
        after,
        finish: (error) => {
          if (!this.sidecar.waiters.delete(waiter)) return
          if (timer !== undefined) clearTimeout(timer)
          signal?.removeEventListener('abort', onAbort)
          if (error) reject(error)
          else resolve()
        },
      }
      const onAbort = () => waiter.finish(new Error('request cancelled'))
      this.sidecar.waiters.add(waiter)
      signal?.addEventListener('abort', onAbort, { once: true })
      timer = setTimeout(() => waiter.finish(), timeout)
      timer.unref?.()
    })

    return {
      ...this.sidecarStatus(),
      events: structuredClone(this.sidecar.events.filter(event => event.sequence > after)),
    }
  }

  /**
   * Launch the Windows desktop sidecar process.
   * Accepts an explicit executable path; otherwise discovers the newest
   * `*-sidecar-*-x64.exe` across known locations.
   */
  launchSidecar(explicitPath) {
    const exe = explicitPath ? String(explicitPath) : (this.sidecar.executablePath || this.#findSidecarExecutable())
    if (!exe || !existsSync(exe)) {
      throw new Error(`找不到桌面伙伴程序：${exe ?? '未配置路径，且常见目录中未发现构建产物（可先运行 sidecar 目录下的 npm run dist:win）'}`)
    }

    const current = this.sidecar.process
    if (current && !current.killed && current.exitCode === null) {
      return { launched: false, alreadyRunning: true, pid: current.pid }
    }
    this.sidecar.process = undefined

    // The single-instance sidecar may have been started outside this plugin
    // (double-click, other harness, a previous plugin reload). A second
    // portable exe then fails its extraction/single-instance lock and can
    // surface a native error dialog, so detect a live process with the same
    // executable name before spawning.
    const exeName = basename(exe).toLowerCase()
    if (this.#isProcessRunning(exeName)) {
      return { launched: false, alreadyRunning: true, pid: null }
    }

    const child = spawn(exe, [], {
      detached: true,
      stdio: 'ignore',
      windowsHide: false,
    })
    child.on('error', (error) => { console.error('Jingling sidecar spawn error:', error.message) })
    child.on('exit', () => { if (this.sidecar.process === child) this.sidecar.process = undefined })
    child.unref()

    this.sidecar.process = child
    return { launched: true, pid: child.pid, path: exe }
  }

  #isProcessRunning(exeName) {
    try {
      const listing = execFileSync('tasklist', ['/FO', 'CSV', '/NH'], { encoding: 'utf8', windowsHide: true })
      return listing.split(/\r?\n/).some(line => line.toLowerCase().includes(exeName))
    }
    catch {
      return false
    }
  }

  #findSidecarExecutable() {
    const here = dirname(fileURLToPath(import.meta.url))
    const candidates = [
      join(here, '..', 'sidecar', 'release'),
      join(here, '..', '..', 'souldock-sidecar', 'release'),
      join(homedir(), 'Desktop', '插件', 'souldock-sidecar', 'release'),
      join(homedir(), 'souldock-sidecar', 'release'),
      join(homedir(), 'AppData', 'Local', 'Jingling', 'release'),
    ]
    let best = null
    for (const dir of candidates) {
      if (!existsSync(dir)) continue
      for (const name of readdirSync(dir)) {
        if (!/^(?:jingling|souldock)-sidecar-.*-x64\.exe$/i.test(name)) continue
        const candidate = { name, path: join(dir, name), key: versionKey(name) }
        if (!best || compareVersions(candidate.key, best.key) > 0) best = candidate
      }
    }
    return best?.path ?? null
  }

  promptContext() {
    return buildCompanionContext(this.read())
  }

  persona() {
    return activePersona(this.read())
  }

  recall(query, limit) {
    return recallMemories(this.read(), query, limit)
  }

  propose(input) {
    this.prunePendingProposals()
    const result = proposeMemory(this.read(), input, { makeId: randomUUID })
    if (result.duplicate) return { proposal: null, duplicate: true, durable: false }
    const pending = this.pendingProposals.find(item => item.personaId === result.proposal.personaId && item.content === result.proposal.content)
    if (pending) return { proposal: null, duplicate: true, durable: false }
    this.pendingProposals.push(structuredClone(result.proposal))
    return { proposal: structuredClone(result.proposal), duplicate: false, durable: false }
  }

  createMemory(input) {
    return this.mutate(state => {
      const result = addConfirmedMemory(state, input, { makeId: randomUUID })
      return {
        state: result.state,
        value: { memory: result.memory, duplicate: result.duplicate, superseded: result.superseded },
      }
    })
  }

  confirmProposal(id) {
    this.prunePendingProposals()
    const proposal = this.pendingProposals.find(item => item.id === id)
    if (!proposal) throw new Error('pending memory proposal not found')
    return this.mutate(state => {
      const result = addConfirmedMemory(state, proposal, { makeId: randomUUID, sourceKind: 'assistant-proposal-confirmed' })
      return { state: result.state, value: { memory: result.memory, superseded: result.superseded } }
    }).then(value => {
      this.pendingProposals = this.pendingProposals.filter(item => item.id !== id)
      return value
    })
  }

  rejectProposal(id) {
    this.prunePendingProposals()
    const before = this.pendingProposals.length
    this.pendingProposals = this.pendingProposals.filter(item => item.id !== id)
    if (this.pendingProposals.length === before) throw new Error('pending memory proposal not found')
    return { rejected: true }
  }

  forget(id) {
    this.prunePendingProposals()
    const before = this.pendingProposals.length
    this.pendingProposals = this.pendingProposals.filter(item => item.id !== id)
    if (this.pendingProposals.length !== before) return { forgotten: true, pending: true }
    return this.mutate(state => ({ state: forgetMemory(state, id), value: { forgotten: true } }))
  }

  previewCharacterCard(card) {
    return parseCharacterCardV2(card)
  }

  importCharacter(card) {
    return this.mutate(state => {
      const result = importCharacterCard(state, card, { makeId: randomUUID })
      return { state: result.state, value: { persona: result.persona, warnings: result.warnings } }
    })
  }

  updatePersona(patch) {
    return this.mutate(state => ({ state: updateActivePersona(state, patch), value: { updated: true } }))
  }

  activatePersona(id) {
    return this.mutate(state => ({ state: activatePersona(state, id), value: { activated: true } }))
  }

  updatePreferences(patch) {
    return this.mutate(state => ({ state: updateSettings(state, patch), value: { updated: true } }))
  }

  soulPack() {
    return publicSoulPack(this.read())
  }

  momentCard(input) {
    return publicMomentCard(this.read(), input)
  }

  privateArchive() {
    return {
      format: 'souldock-private-data-archive',
      version: 1,
      exportedAt: nowIso(),
      warning: 'Private Jingling-domain export: contains personas, memory content, provenance, settings, and audit metadata. It is not a complete DSH history export. Keep it local.',
      data: this.read(),
    }
  }

  recordCheckIn(sessionId, now = Date.now()) {
    return this.mutate(state => {
      const result = recordProactiveCheckIn(state, { sessionId }, { now, makeId: randomUUID })
      return { state: result.state, value: { entry: result.entry } }
    })
  }

  admitCheckIn(sessionId, lastInteractionAt, now = Date.now()) {
    return this.mutate(state => {
      const decision = evaluateProactiveCheckIn(state, { now, lastInteractionAt })
      if (!decision.allowed) return { state, value: decision }
      const result = recordProactiveCheckIn(state, { sessionId }, { now, makeId: randomUUID })
      return {
        state: result.state,
        value: { allowed: true, reason: 'eligible', entry: result.entry },
      }
    })
  }

  resetAll() {
    return this.mutate(() => ({ state: createDefaultState(), value: { reset: true } })).then(value => {
      this.pendingProposals = []
      return value
    })
  }

  prunePendingProposals(now = Date.now()) {
    this.pendingProposals = this.pendingProposals.filter(item => {
      const expiresAt = Date.parse(String(item.expiresAt ?? ''))
      return Number.isFinite(expiresAt) && expiresAt > now
    })
  }

  publishActivity(activity, eventType, metadata = {}) {
    this.activity = {
      phase: activity.phase,
      detail: activity.detail,
      lastEvent: eventType,
      updatedAt: nowIso(),
    }
    this.appendSidecarEvent({
      type: 'activity',
      sessionId: this.safeSessionId(metadata.sessionId),
      runtime: structuredClone(this.activity),
    })
  }

  publishAssistantMessage(input = {}) {
    if (!this.sidecar.shareAssistantText) return false
    const text = String(input.text ?? '').replace(/\u0000/g, '').trim().slice(0, 6000)
    if (!text) return false
    this.appendSidecarEvent({
      type: 'assistant-message',
      sessionId: this.safeSessionId(input.sessionId),
      messageId: this.safeMessageId(input.messageId),
      text,
      completed: true,
    })
    return true
  }

  safeSessionId(value) {
    const text = String(value ?? '').trim()
    return /^[a-zA-Z0-9._:-]{1,160}$/.test(text) ? text : null
  }

  safeMessageId(value) {
    const text = String(value ?? '').trim()
    return /^[a-zA-Z0-9._:-]{1,200}$/.test(text) ? text : `sidecar-${this.sidecar.sequence + 1}`
  }

  appendSidecarEvent(event) {
    const entry = {
      ...event,
      sequence: ++this.sidecar.sequence,
      at: nowIso(),
    }
    this.sidecar.events.push(entry)
    if (this.sidecar.events.length > 64) {
      this.sidecar.events.splice(0, this.sidecar.events.length - 64)
    }
    for (const waiter of [...this.sidecar.waiters]) {
      if (entry.sequence > waiter.after) waiter.finish()
    }
    return entry
  }

  mutate(operation) {
    const result = this.operationTail.then(async () => {
      const current = this.read()
      const transition = operation(current)
      const next = normalizeState(transition.state)
      await this.globalState.set(next)
      return transition.value
    })
    this.operationTail = result.then(() => {}, () => {})
    return result
  }
}
