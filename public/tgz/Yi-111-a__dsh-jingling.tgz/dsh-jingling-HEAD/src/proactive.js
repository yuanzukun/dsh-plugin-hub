/** Opt-in proactive check-ins for one preferred live Jingling root agent. */

import { evaluateProactiveCheckIn, isProactiveStopRequest } from './core.js'

const PRESET_ID = 'souldock'

function isHuman(message) {
  return message?.source?.kind === 'user'
}

function messageText(message) {
  if (typeof message?.content === 'string') return message.content
  if (!Array.isArray(message?.content)) return ''
  return message.content
    .filter(part => part?.type === 'text' && typeof part.text === 'string')
    .map(part => part.text)
    .join('\n')
}

function liveHumanAt(agent) {
  // firstLiveSeq is this process lifecycle, unlike seedLength (fork ancestry).
  for (let index = agent.session.events.length - 1; index >= agent.session.firstLiveSeq; index -= 1) {
    const event = agent.session.events[index]
    if (event.type === 'user/message' && isHuman(event.data)) return event.time
    if (event.type === 'agent/inbox/spliced' && event.data?.inserted?.some(isHuman)) return event.time
  }
  return undefined
}

function checkInMessage(createUserMessage, boundContextSummary) {
  return createUserMessage({
    content: [{
      type: 'text',
      text: [
        '<souldock-proactive-check-in>',
        'This is a Jingling plugin trigger, not a message written by the user.',
        'The user explicitly opted in to one brief optional check-in. Reply in one warm sentence.',
        'Do not imply surveillance, urgency, loneliness, exclusivity, or that the user owes a response. Do not mention how long they were away, ask for approval, store memory, call a tool, or invent an event.',
        '</souldock-proactive-check-in>',
      ].join('\n'),
    }],
    source: {
      kind: 'plugin',
      plugin: 'dsh-jingling',
      form: 'notice',
      summary: boundContextSummary('鲸灵主动问候'),
    },
  })
}

class ProactiveRuntime {
  constructor(ctx, service, agent, isPreferred, pollMilliseconds, llm) {
    this.ctx = ctx
    this.service = service
    this.agent = agent
    this.isPreferred = isPreferred
    this.pollMilliseconds = pollMilliseconds
    this.llm = llm
    this.lastHumanAt = liveHumanAt(agent)
    this.explicitlyStopped = false
    this.stopping = false
    this.requested = false
    this.run = undefined
    this.idleWait = undefined
    this.interval = undefined
    this.stop = Promise.withResolvers()
    this.stops = []
  }

  isLiveSoulDock() {
    return !this.stopping
      && this.ctx.agents.get(this.agent.id) === this.agent
      && this.ctx.agents.roots().includes(this.agent)
      && this.ctx.agentPresets.composedPreset(this.agent.ctx) === PRESET_ID
  }

  noteHuman(message, at = Date.now()) {
    this.lastHumanAt = Math.max(this.lastHumanAt ?? 0, new Date(at).getTime())
    if (isProactiveStopRequest(messageText(message))) {
      this.explicitlyStopped = true
      void this.service.updatePreferences({ proactive: { enabled: false } })
        .catch(error => this.ctx.logger.warn(`souldock: failed to persist proactive stop: ${String(error)}`))
      return
    }
    this.requestDrive()
  }

  start() {
    this.stops.push(this.agent.ctx.on('agent/inbox/inserted', ({ agent, message }) => {
      if (agent === this.agent && isHuman(message)) this.noteHuman(message)
    }))
    this.stops.push(this.agent.ctx.on('session/event', (session, event) => {
      if (session === this.agent.session && event.type === 'user/message' && isHuman(event.data)) {
        this.noteHuman(event.data, event.time)
      }
    }))
    this.stops.push(this.agent.ctx.on('agent/status', ({ agent, status }) => {
      if (agent === this.agent && status === 'idle') this.requestDrive()
    }))
    this.interval = setInterval(() => this.requestDrive(), this.pollMilliseconds)
    this.interval.unref?.()
    this.requestDrive()
  }

  requestDrive() {
    if (this.stopping) return
    this.requested = true
    if (this.run !== undefined) return
    const current = this.drain()
    this.run = current
    void current.then(
      () => this.retire(current),
      error => {
        this.ctx.logger.warn(`souldock: proactive driver failed for agent "${this.agent.id}": ${String(error)}`)
        this.retire(current)
      },
    )
  }

  retire(current) {
    if (this.run !== current) return
    this.run = undefined
    if (this.requested && !this.stopping) this.requestDrive()
  }

  async drain() {
    while (this.requested && !this.stopping) {
      this.requested = false
      await this.driveOnce()
    }
  }

  waitForIdle() {
    if (this.idleWait !== undefined || this.stopping) return
    const wait = Promise.race([this.agent.whenIdle(), this.stop.promise])
    this.idleWait = wait
    void wait.then(
      () => {
        if (this.idleWait === wait) this.idleWait = undefined
        if (!this.stopping) this.requestDrive()
      },
      error => {
        if (this.idleWait === wait) this.idleWait = undefined
        if (!this.stopping) this.ctx.logger.warn(`souldock: idle wait failed: ${String(error)}`)
      },
    )
  }

  async driveOnce() {
    const observedHumanAt = this.lastHumanAt
    if (observedHumanAt === undefined || this.explicitlyStopped || !this.isLiveSoulDock() || !this.isPreferred()) return
    if (this.agent.status !== 'idle') { this.waitForIdle(); return }
    if (this.agent.inbox.hasPending) return
    if (!evaluateProactiveCheckIn(this.service.read(), { now: Date.now(), lastInteractionAt: observedHumanAt }).allowed) return

    let maintenance
    try {
      maintenance = this.agent.runMaintenance(async signal => {
        signal.throwIfAborted()
        if (this.explicitlyStopped || !this.isLiveSoulDock() || !this.isPreferred()
          || this.lastHumanAt !== observedHumanAt || this.agent.inbox.hasPending) return false
        // Atomic evaluate + reservation keeps multiple live sessions inside one
        // global daily budget. At-most-once is intentional: a crash may consume
        // one slot, but must never duplicate an emotional notification.
        const admission = await this.service.admitCheckIn(this.agent.id, observedHumanAt, Date.now())
        if (!admission.allowed) return false
        signal.throwIfAborted()
        if (!this.isLiveSoulDock() || !this.isPreferred()
          || this.lastHumanAt !== observedHumanAt || this.agent.inbox.hasPending) return false
        this.agent.followup(checkInMessage(this.llm.createUserMessage, this.llm.boundContextSummary))
        try {
          if (!await this.ctx.sessions.flush(this.agent.session)) {
            this.ctx.logger.warn(`souldock: no persistence listener acknowledged check-in for "${this.agent.id}"`)
          }
        } catch (error) {
          this.ctx.logger.warn(`souldock: check-in persistence uncertain for "${this.agent.id}": ${String(error)}`)
        }
        return true
      })
    } catch {
      this.waitForIdle()
      return
    }
    try { await maintenance } catch (error) {
      if (!this.stopping) this.ctx.logger.warn(`souldock: check-in admission failed: ${String(error)}`)
    }
  }

  async dispose() {
    if (this.stopping) return
    this.stopping = true
    this.requested = false
    if (this.interval !== undefined) clearInterval(this.interval)
    for (const stop of this.stops.splice(0)) stop()
    this.stop.resolve()
    if (this.run !== undefined) await Promise.allSettled([this.run])
  }
}

export function installProactiveRuntime(ctx, service, {
  pollMilliseconds = 60000,
  createUserMessage,
  boundContextSummary,
} = {}) {
  if (typeof createUserMessage !== 'function' || typeof boundContextSummary !== 'function') {
    throw new Error('souldock: proactive runtime requires DSH message constructors')
  }
  const llm = { createUserMessage, boundContextSummary }
  const records = new Map()
  let stopping = false

  const isRootSoulDock = agent => ctx.agents.get(agent.id) === agent
    && ctx.agents.roots().includes(agent)
    && ctx.agentPresets.composedPreset(agent.ctx) === PRESET_ID

  const preferred = () => {
    let best
    for (const [agent, record] of records) {
      const at = record.runtime.lastHumanAt
      if (at === undefined || !isRootSoulDock(agent)) continue
      if (best === undefined || at > best.at) best = { agent, at }
    }
    return best?.agent
  }

  const detach = agent => {
    const record = records.get(agent)
    if (!record) return
    records.delete(agent)
    try {
      const outcome = record.cleanup === undefined ? record.runtime.dispose() : record.cleanup()
      void Promise.resolve(outcome)
        .catch(error => ctx.logger.warn(`souldock: proactive cleanup failed: ${String(error)}`))
    } catch (error) {
      ctx.logger.warn(`souldock: proactive cleanup failed: ${String(error)}`)
    }
  }

  const reconcile = agent => {
    if (stopping || !isRootSoulDock(agent)) { detach(agent); return }
    if (records.has(agent)) return
    const runtime = new ProactiveRuntime(ctx, service, agent, () => preferred() === agent, pollMilliseconds, llm)
    const record = { runtime, cleanup: undefined }
    records.set(agent, record)
    try {
      record.cleanup = agent.ctx.effect(() => {
        runtime.start()
        return async () => {
          await runtime.dispose()
          if (records.get(agent) === record) records.delete(agent)
        }
      }, 'souldock: proactive agent runtime')
    } catch (error) {
      records.delete(agent)
      void runtime.dispose()
      ctx.logger.warn(`souldock: proactive attach failed for "${agent.id}": ${String(error)}`)
    }
  }

  ctx.effect(() => {
    const stopCreated = ctx.on('agent/created', ({ agent }) => {
      try { reconcile(agent) } catch (error) { ctx.logger.warn(`souldock: reconcile failed: ${String(error)}`) }
    })
    const stopSelected = ctx.on('agent-preset/selected', (sessionId, _agentPreset) => {
      try {
        const agent = ctx.agents.get(sessionId)
        if (agent !== undefined) reconcile(agent)
      } catch (error) { ctx.logger.warn(`souldock: preset reconcile failed: ${String(error)}`) }
    })
    for (const agent of ctx.agents.roots()) {
      try { reconcile(agent) } catch (error) { ctx.logger.warn(`souldock: initial reconcile failed: ${String(error)}`) }
    }
    return async () => {
      stopping = true
      stopSelected(); stopCreated()
      const cleanups = [...records.values()].map(record => record.cleanup ?? (() => record.runtime.dispose()))
      records.clear()
      await Promise.allSettled(cleanups.map(cleanup => Promise.resolve().then(cleanup)))
    }
  }, 'souldock: proactive lifecycle')
}
