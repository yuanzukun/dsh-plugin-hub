/**
 * Least-privilege workspace/task bridge for the standalone Jingling window.
 *
 * The public identifiers below are stable one-way aliases. Raw DSH workspace
 * ids, Session ids, tool payloads, reasoning, prompt context, approvals,
 * questions, credentials, and arbitrary sessions never cross this boundary.
 */

import { createHash, randomUUID } from 'node:crypto'
import { isAbsolute } from 'node:path'

import {
  CHAT_INPUT_MAX_CODE_POINTS,
  CHAT_OUTPUT_MAX_CODE_POINTS,
  projectChatHistory,
} from './chat.js'

export const WORKSPACE_SESSION_PREFIX = 'souldock-workspace-'
export const WORKSPACE_PRESET_ID = 'standard'
export const WORKSPACE_INPUT_MAX_CODE_POINTS = CHAT_INPUT_MAX_CODE_POINTS
export const WORKSPACE_HISTORY_MESSAGES = 80
export const WORKSPACE_EVENT_BUFFER = 256
export const WORKSPACE_POLL_MAX_MILLISECONDS = 25_000
export const WORKSPACE_LIST_MAX = 100
export const WORKSPACE_TASKS_PER_WORKSPACE_MAX = 200

const OWNED_SESSION_PATTERN = /^souldock-workspace-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/
const PUBLIC_TASK_PATTERN = /^task-[0-9a-f]{32}$/
const PUBLIC_WORKSPACE_PATTERN = /^workspace-[0-9a-f]{32}$/

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function codePoints(value) {
  return [...String(value)]
}

function truncateCodePoints(value, maximum) {
  const points = codePoints(value)
  if (points.length <= maximum) return points.join('')
  return `${points.slice(0, Math.max(0, maximum - 1)).join('')}…`
}

function publicKey(kind, internalId) {
  const digest = createHash('sha256')
    .update(`souldock-workspace-v1\0${kind}\0${String(internalId)}`, 'utf8')
    .digest('hex')
    .slice(0, 32)
  return `${kind}-${digest}`
}

function taskIdForSession(sessionId) {
  return publicKey('task', sessionId)
}

function workspaceIdForInternal(workspaceId) {
  return publicKey('workspace', workspaceId)
}

function safeInternalId(value, maximum = 256) {
  const text = String(value ?? '')
  return text.length > 0 && text.length <= maximum && !text.includes('\u0000') ? text : undefined
}

function safeDisplayText(value, fallback, maximum = 240) {
  if (typeof value !== 'string') return fallback
  const text = value
    .replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  return text ? truncateCodePoints(text, maximum) : fallback
}

function visibleText(message) {
  const content = message?.content
  if (!Array.isArray(content)) return ''
  return truncateCodePoints(content
    .filter(block => block?.type === 'text' && typeof block.text === 'string')
    .map(block => block.text)
    .join('\n')
    .replace(/\u0000/g, '')
    .trim(), CHAT_OUTPUT_MAX_CODE_POINTS)
}

function eventTime(event) {
  return Number.isFinite(event?.time) ? event.time : Date.now()
}

function eventSequence(event) {
  return Number.isSafeInteger(event?.seq) && event.seq >= 0 ? event.seq : undefined
}

function eventPosition(value) {
  return Number.isSafeInteger(value) && value >= 0 ? value : undefined
}

function streamKey(turn, step) {
  return `${String(turn)}:${String(step)}`
}

function requireObject(value, name) {
  if (!isRecord(value)) throw new Error(`${name} must be an object`)
  return value
}

function assertOnlyKeys(value, allowed, name) {
  const extras = Object.keys(value).filter(key => !allowed.includes(key))
  if (extras.length > 0) throw new Error(`${name} contains unsupported fields: ${extras.join(', ')}`)
}

function requirePublicTaskId(value) {
  if (typeof value !== 'string' || !PUBLIC_TASK_PATTERN.test(value)) {
    throw new Error('taskId must be a valid Jingling task identifier')
  }
  return value
}

function requireClientMessageId(value) {
  const text = String(value ?? '').trim()
  if (!/^[a-zA-Z0-9._:-]+$/.test(text) || text.length > 180) {
    throw new Error('clientMessageId must be a safe non-empty identifier')
  }
  return text
}

function requireWorkspacePath(value) {
  if (typeof value !== 'string' || !value.trim()) throw new Error('cwd must be a non-empty string')
  if (value.includes('\u0000')) throw new Error('cwd must not contain NUL characters')
  if (codePoints(value).length > 4_096) throw new Error('cwd is too long')
  if (!isAbsolute(value)) throw new Error('cwd must be an absolute path selected by the user')
  return value
}

function requireTaskTitle(value) {
  if (value === undefined) return undefined
  if (typeof value !== 'string' || !value.trim()) throw new Error('title must be a non-empty string')
  if (value.includes('\u0000')) throw new Error('title must not contain NUL characters')
  if (codePoints(value).length > 160) throw new Error('title exceeds 160 Unicode code points')
  return value
}

function requireInputText(value) {
  if (typeof value !== 'string') throw new Error('text must be a string')
  if (value.includes('\u0000')) throw new Error('text must not contain NUL characters')
  if (!value.trim()) throw new Error('text must not be empty')
  if (codePoints(value).length > WORKSPACE_INPUT_MAX_CODE_POINTS) {
    throw new Error(`text exceeds ${WORKSPACE_INPUT_MAX_CODE_POINTS} Unicode code points`)
  }
  if (value.trimStart().startsWith('/')) throw new Error('slash commands are not available in Jingling workspace tasks')
  return value
}

function requireTimeZone(value) {
  if (value === undefined) return undefined
  if (typeof value !== 'string' || !value.trim() || value.length > 100 || value.includes('\u0000')) {
    throw new Error('clientTimeZone must be a non-empty string of at most 100 characters')
  }
  return value.trim()
}

function abortError() {
  return new Error('request cancelled')
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError()
}

function publicApiError(code) {
  if (code === 'workspace-not-found') return '工作区已失效，请重新选择文件夹。'
  if (code === 'directory-not-found' || code === 'directory-not-directory') return '所选工作区文件夹不可用。'
  if (code === 'model-unavailable') return '当前 DSH 模型不可用，请先在 DSH 中完成模型配置。'
  if (code === 'session-not-found') return '任务已失效，请重新打开。'
  if (code === 'cancelled') return '请求已取消。'
  return 'DSH 拒绝了工作区请求。'
}

function titleFromSessionSummary(summary) {
  return safeDisplayText(summary?.projections?.values?.title, '新任务', 160)
}

function mergePostHistory(snapshot, events) {
  const messages = [...snapshot.messages]
  const known = new Set(messages.map(message => message.id))
  let partial = snapshot.partial === undefined ? undefined : { ...snapshot.partial }

  for (const event of events) {
    if (event.type === 'user-message') {
      if (known.has(event.messageId)) continue
      known.add(event.messageId)
      messages.push({ id: event.messageId, role: 'user', text: event.text, at: event.at })
    }
    else if (event.type === 'assistant-delta') {
      if (partial?.turn !== event.turn || partial?.step !== event.step) {
        partial = { turn: event.turn, step: event.step, text: '' }
      }
      partial.text = truncateCodePoints(`${partial.text}${event.delta}`, CHAT_OUTPUT_MAX_CODE_POINTS)
    }
    else if (event.type === 'assistant-final') {
      if (!known.has(event.messageId)) {
        known.add(event.messageId)
        messages.push({ id: event.messageId, role: 'assistant', text: event.text, at: event.at })
      }
      if (partial?.turn === event.turn && partial?.step === event.step) partial = undefined
    }
  }

  return {
    messages: messages.slice(-WORKSPACE_HISTORY_MESSAGES),
    partial,
    truncated: snapshot.truncated || messages.length > WORKSPACE_HISTORY_MESSAGES,
  }
}

/** Host-side BFF for explicitly selected coding workspaces. */
export class SoulDockWorkspaceBridge {
  constructor(ctx, apiProxy) {
    if (!apiProxy?.sessions || !apiProxy?.workspace) {
      throw new Error('souldock workspace requires DSH apiProxy sessions and workspace domains')
    }
    this.ctx = ctx
    this.api = apiProxy
    this.handles = new Map()
    this.pendingInteractions = new Map()
    this.streamAbort = undefined
    this.streamTask = undefined
    this.startNeedsInputStream()
  }

  ownsSession(sessionId) {
    return typeof sessionId === 'string' && OWNED_SESSION_PATTERN.test(sessionId)
  }

  async list(signal) {
    const inventory = await this.inventory(signal)
    return {
      version: 1,
      workspaces: inventory.workspaces.map(workspace => this.publicWorkspace(workspace, inventory)),
    }
  }

  async create(rawPayload, signal) {
    const payload = requireObject(rawPayload, 'workspace/task/create payload')
    assertOnlyKeys(payload, ['cwd', 'title'], 'workspace/task/create payload')
    const cwd = requireWorkspacePath(payload.cwd)
    const requestedTitle = requireTaskTitle(payload.title)
    throwIfAborted(signal)

    const adopted = await this.invoke('workspace.create', request => this.api.workspace.create(request), { path: cwd })
    const workspace = adopted?.workspace
    const internalWorkspaceId = safeInternalId(workspace?.workspaceId)
    if (!internalWorkspaceId || typeof workspace?.path !== 'string' || typeof workspace?.title !== 'string') {
      throw new Error('DSH did not adopt the selected workspace')
    }

    const sessionId = `${WORKSPACE_SESSION_PREFIX}${randomUUID()}`
    const created = await this.invoke('session.create', request => this.api.sessions.create(request), {
      workspaceId: internalWorkspaceId,
      sessionId,
      agentPreset: WORKSPACE_PRESET_ID,
    })
    if (created?.sessionId !== sessionId || created?.agentPreset !== WORKSPACE_PRESET_ID) {
      throw new Error('DSH did not create the requested standard workspace task')
    }

    let title = '新任务'
    if (requestedTitle !== undefined) {
      const renamed = await this.invoke('session.rename', request => this.api.sessions.rename(request), {
        sessionId,
        title: requestedTitle,
      })
      title = safeDisplayText(renamed?.title, '新任务', 160)
    }
    throwIfAborted(signal)

    const summary = {
      sessionId,
      updatedAt: Date.now(),
      running: false,
      blank: true,
      cwd: workspace.path,
      agentPreset: WORKSPACE_PRESET_ID,
      projections: { values: { title } },
    }
    const attachedWorkspace = {
      ...workspace,
      sessionIds: [...new Set([...(Array.isArray(workspace.sessionIds) ? workspace.sessionIds : []), sessionId])],
    }
    return this.openResolved(summary, attachedWorkspace, signal, title)
  }

  async open(rawPayload, signal) {
    const payload = requireObject(rawPayload, 'workspace/task/open payload')
    assertOnlyKeys(payload, ['taskId'], 'workspace/task/open payload')
    const taskId = requirePublicTaskId(payload.taskId)
    const inventory = await this.inventory(signal)
    const resolved = inventory.tasks.get(taskId)
    if (!resolved) throw new Error('task is missing or is not owned by Jingling workspace mode')
    return this.openResolved(resolved.summary, resolved.workspace, signal)
  }

  async openResolved(summary, workspace, signal, forcedTitle) {
    throwIfAborted(signal)
    const taskId = taskIdForSession(summary.sessionId)
    const old = this.handles.get(taskId)
    if (old) this.closeHandle(old, new Error('workspace task handle replaced'))
    const pending = this.pendingInteractions.get(summary.sessionId)
    const initialStatus = pending?.size > 0 ? 'needs-input' : summary.running === true ? 'running' : 'idle'
    const handle = this.createHandle(taskId, summary.sessionId, workspace.workspaceId, initialStatus, forcedTitle)
    this.handles.set(taskId, handle)
    try {
      const history = await this.invoke('session.history', request => this.api.sessions.history(request), {
        sessionId: summary.sessionId,
        maxMessages: 180,
      })
      throwIfAborted(signal)
      const snapshot = projectChatHistory(history?.events, WORKSPACE_HISTORY_MESSAGES)
      snapshot.messages = snapshot.messages.map(message => ({
        ...message,
        id: publicKey('message', message.id),
      }))
      if (
        snapshot.partial !== undefined
        && (eventPosition(snapshot.partial.turn) === undefined || eventPosition(snapshot.partial.step) === undefined)
      ) snapshot.partial = undefined
      const postHistory = handle.events.filter(event => event.sourceSeq === undefined || event.sourceSeq > snapshot.lastSourceSeq)
      const merged = mergePostHistory(snapshot, postHistory)
      return {
        version: 1,
        task: this.publicTask(summary, workspace, handle),
        sequence: handle.sequence,
        status: handle.status,
        messages: merged.messages,
        ...(merged.partial === undefined ? {} : { partial: merged.partial }),
        hasOlder: history?.hasMore === true || merged.truncated,
        limits: { inputCodePoints: WORKSPACE_INPUT_MAX_CODE_POINTS },
      }
    }
    catch (error) {
      this.closeHandle(handle, error)
      throw error
    }
  }

  async send(rawPayload, signal) {
    const payload = requireObject(rawPayload, 'workspace/task/send payload')
    assertOnlyKeys(payload, ['taskId', 'clientMessageId', 'text', 'clientTimeZone'], 'workspace/task/send payload')
    const handle = this.requireHandle(requirePublicTaskId(payload.taskId))
    const clientMessageId = requireClientMessageId(payload.clientMessageId)
    const text = requireInputText(payload.text)
    const clientTimeZone = requireTimeZone(payload.clientTimeZone)
    throwIfAborted(signal)
    const fingerprint = JSON.stringify([text, clientTimeZone ?? null])
    const acceptedFingerprint = handle.acceptedMessages.get(clientMessageId)
    if (acceptedFingerprint !== undefined) {
      if (acceptedFingerprint !== fingerprint) throw new Error('clientMessageId was already used for different text')
      return { accepted: true, clientMessageId }
    }
    const pending = handle.pendingSends.get(clientMessageId)
    if (pending !== undefined) {
      if (pending.fingerprint !== fingerprint) throw new Error('clientMessageId is already sending different text')
      return pending.promise
    }

    const promise = this.sendOnce(handle, { clientMessageId, text, clientTimeZone, fingerprint }, signal)
    handle.pendingSends.set(clientMessageId, { fingerprint, promise })
    try {
      return await promise
    }
    finally {
      if (handle.pendingSends.get(clientMessageId)?.promise === promise) handle.pendingSends.delete(clientMessageId)
    }
  }

  async sendOnce(handle, { clientMessageId, text, clientTimeZone, fingerprint }, signal) {
    const ensured = await this.invoke('session.create', request => this.api.sessions.create(request), {
      workspaceId: handle.internalWorkspaceId,
      sessionId: handle.sessionId,
      agentPreset: WORKSPACE_PRESET_ID,
    })
    if (ensured?.sessionId !== handle.sessionId || ensured?.agentPreset !== WORKSPACE_PRESET_ID) {
      throw new Error('workspace task no longer uses the standard preset')
    }
    throwIfAborted(signal)
    const value = await this.invoke('session.prompt', request => this.api.sessions.prompt(request), {
      sessionId: handle.sessionId,
      mode: 'queue',
      content: [{ type: 'text', text }],
      ...(clientTimeZone === undefined ? {} : { clientTimeZone }),
    }, clientMessageId)
    throwIfAborted(signal)
    if (value?.accepted !== true || value.command !== undefined) throw new Error('DSH did not accept the workspace task prompt')
    handle.acceptedMessages.set(clientMessageId, fingerprint)
    if (handle.acceptedMessages.size > 128) handle.acceptedMessages.delete(handle.acceptedMessages.keys().next().value)
    return { accepted: true, clientMessageId }
  }

  async poll(rawPayload, signal) {
    const payload = requireObject(rawPayload, 'workspace/task/poll payload')
    assertOnlyKeys(payload, ['taskId', 'afterSequence', 'timeoutMilliseconds'], 'workspace/task/poll payload')
    const taskId = requirePublicTaskId(payload.taskId)
    const afterSequence = Number(payload.afterSequence)
    const timeoutMilliseconds = Number(payload.timeoutMilliseconds)
    if (!Number.isSafeInteger(afterSequence) || afterSequence < 0) {
      throw new Error('afterSequence must be a non-negative safe integer')
    }
    if (!Number.isSafeInteger(timeoutMilliseconds) || timeoutMilliseconds < 0 || timeoutMilliseconds > WORKSPACE_POLL_MAX_MILLISECONDS) {
      throw new Error(`timeoutMilliseconds must be an integer from 0 through ${WORKSPACE_POLL_MAX_MILLISECONDS}`)
    }
    let handle = this.requireHandle(taskId)
    if (afterSequence > handle.sequence) throw new Error('afterSequence is ahead of the task stream')
    const oldest = handle.events[0]?.sequence
    if (oldest !== undefined && afterSequence < oldest - 1) {
      return { version: 1, sequence: handle.sequence, status: handle.status, events: [], resetRequired: true }
    }
    let available = handle.events.filter(event => event.sequence > afterSequence)
    if (available.length === 0 && timeoutMilliseconds > 0) {
      await this.waitForEvent(handle, afterSequence, timeoutMilliseconds, signal)
      handle = this.requireHandle(taskId)
      available = handle.events.filter(event => event.sequence > afterSequence)
    }
    throwIfAborted(signal)
    return { version: 1, sequence: handle.sequence, status: handle.status, events: structuredClone(available) }
  }

  async cancel(rawPayload, signal) {
    const payload = requireObject(rawPayload, 'workspace/task/cancel payload')
    assertOnlyKeys(payload, ['taskId'], 'workspace/task/cancel payload')
    const handle = this.requireHandle(requirePublicTaskId(payload.taskId))
    throwIfAborted(signal)
    const value = await this.invoke('session.cancel', request => this.api.sessions.cancel(request), {
      sessionId: handle.sessionId,
    })
    throwIfAborted(signal)
    if (value?.accepted !== true) throw new Error('DSH did not accept workspace task cancellation')
    return { accepted: true }
  }

  close(rawPayload) {
    const payload = requireObject(rawPayload, 'workspace/task/close payload')
    assertOnlyKeys(payload, ['taskId'], 'workspace/task/close payload')
    const handle = this.requireHandle(requirePublicTaskId(payload.taskId))
    this.closeHandle(handle, new Error('workspace task closed'))
    return { closed: true }
  }

  acceptSessionEvent(session, event) {
    const sessionId = String(session?.id ?? '')
    if (!this.ownsSession(sessionId) || !isRecord(event)) return
    if (event.type === 'approval/asked') {
      const approvalId = safeInternalId(event.data?.id)
      if (approvalId) this.setInteraction(sessionId, `a:${approvalId}`, true)
    }
    else if (event.type === 'approval/decided') {
      const approvalId = safeInternalId(event.data?.id)
      if (approvalId) this.setInteraction(sessionId, `a:${approvalId}`, false)
    }
    for (const handle of this.handles.values()) {
      if (handle.sessionId === sessionId) this.projectEvent(handle, event)
    }
  }

  acceptStatus(agent, status) {
    const sessionId = String(agent?.id ?? '')
    if (!this.ownsSession(sessionId) || !['running', 'idle'].includes(status)) return
    if (this.pendingInteractions.get(sessionId)?.size > 0) return
    for (const handle of this.handles.values()) {
      if (handle.sessionId === sessionId) this.setStatus(handle, status)
    }
  }

  acceptError(agent) {
    const sessionId = String(agent?.id ?? '')
    if (!this.ownsSession(sessionId)) return
    for (const handle of this.handles.values()) {
      if (handle.sessionId !== sessionId) continue
      handle.status = 'error'
      this.appendError(handle, { type: 'error', at: Date.now(), code: 'failed', message: '任务执行失败，请稍后重试。' })
    }
  }

  dispose() {
    this.streamAbort?.abort(new Error('workspace bridge disposed'))
    this.streamAbort = undefined
    this.closeAll(new Error('workspace bridge disposed'))
    this.pendingInteractions.clear()
  }

  async inventory(signal) {
    throwIfAborted(signal)
    const [workspaceValue, sessionValue] = await Promise.all([
      this.invoke('workspace.list', request => this.api.workspace.list(request), {}),
      this.invoke('session.list', request => this.api.sessions.list(request), {}),
    ])
    throwIfAborted(signal)
    const sessions = Array.isArray(sessionValue?.items) ? sessionValue.items : []
    const ownedByInternal = new Map()
    for (const summary of sessions) {
      if (!this.ownsSession(summary?.sessionId)) continue
      if (summary.agentPreset !== WORKSPACE_PRESET_ID) continue
      if (summary.parentSessionId !== undefined || summary.origin === 'subagent') continue
      ownedByInternal.set(summary.sessionId, summary)
    }
    const archived = new Set(Array.isArray(workspaceValue?.archivedSessionIds) ? workspaceValue.archivedSessionIds : [])
    const workspaces = []
    const tasks = new Map()
    for (const workspace of Array.isArray(workspaceValue?.items) ? workspaceValue.items : []) {
      const internalWorkspaceId = safeInternalId(workspace?.workspaceId)
      if (!internalWorkspaceId || !Array.isArray(workspace?.sessionIds)) continue
      const owned = []
      for (const sessionId of workspace.sessionIds) {
        if (archived.has(sessionId)) continue
        const summary = ownedByInternal.get(sessionId)
        if (!summary) continue
        const taskId = taskIdForSession(sessionId)
        const resolved = { summary, workspace }
        tasks.set(taskId, resolved)
        owned.push(resolved)
      }
      if (owned.length > 0 && workspaces.length < WORKSPACE_LIST_MAX) {
        workspaces.push({ ...workspace, owned: owned.slice(0, WORKSPACE_TASKS_PER_WORKSPACE_MAX) })
      }
    }
    return { workspaces, tasks }
  }

  publicWorkspace(workspace, inventory) {
    const workspaceId = workspaceIdForInternal(workspace.workspaceId)
    if (!PUBLIC_WORKSPACE_PATTERN.test(workspaceId)) throw new Error('failed to project workspace identifier')
    const tasks = workspace.owned
      .map(({ summary }) => this.publicTask(summary, workspace, this.handles.get(taskIdForSession(summary.sessionId))))
      .sort((left, right) => right.updatedAt - left.updatedAt)
    return {
      workspaceId,
      title: safeDisplayText(workspace.title, '工作区', 160),
      path: typeof workspace.path === 'string' ? truncateCodePoints(workspace.path, 4_096) : '',
      tasks,
    }
  }

  publicTask(summary, workspace, handle) {
    const taskId = taskIdForSession(summary.sessionId)
    const pending = this.pendingInteractions.get(summary.sessionId)
    const status = pending?.size > 0
      ? 'needs-input'
      : handle?.status ?? (summary.running === true ? 'running' : 'idle')
    return {
      taskId,
      title: handle?.title ?? titleFromSessionSummary(summary),
      workspacePath: truncateCodePoints(typeof workspace.path === 'string' ? workspace.path : String(summary.cwd ?? ''), 4_096),
      workspaceName: safeDisplayText(workspace.title, '工作区', 160),
      updatedAt: Number.isFinite(summary.updatedAt) ? summary.updatedAt : 0,
      status,
    }
  }

  createHandle(taskId, sessionId, internalWorkspaceId, status, title) {
    return {
      taskId,
      sessionId,
      internalWorkspaceId,
      status,
      ...(title === undefined ? {} : { title }),
      sequence: 0,
      events: [],
      waiters: new Set(),
      acceptedMessages: new Map(),
      pendingSends: new Map(),
      streamLengths: new Map(),
    }
  }

  requireHandle(taskId) {
    const handle = this.handles.get(taskId)
    if (!handle) throw new Error('task handle is missing or expired; reopen the workspace task')
    return handle
  }

  closeAll(error) {
    for (const handle of [...this.handles.values()]) this.closeHandle(handle, error)
  }

  closeHandle(handle, error) {
    if (!this.handles.delete(handle.taskId)) return
    for (const waiter of [...handle.waiters]) waiter.finish(error)
  }

  setStatus(handle, status) {
    if (handle.status === status) return
    handle.status = status
    this.append(handle, { type: 'status', at: Date.now(), status })
  }

  setInteraction(sessionId, key, pending) {
    let entries = this.pendingInteractions.get(sessionId)
    if (pending) {
      if (!entries) this.pendingInteractions.set(sessionId, entries = new Set())
      const before = entries.size
      entries.add(key)
      if (before === entries.size) return
      for (const handle of this.handles.values()) {
        if (handle.sessionId === sessionId) this.setStatus(handle, 'needs-input')
      }
      return
    }
    if (!entries?.delete(key)) return
    if (entries.size > 0) return
    this.pendingInteractions.delete(sessionId)
    for (const handle of this.handles.values()) {
      if (handle.sessionId === sessionId) this.setStatus(handle, 'running')
    }
  }

  projectEvent(handle, event) {
    const sourceSeq = eventSequence(event)
    const at = eventTime(event)
    if (event.type === 'turn/start') {
      if (this.pendingInteractions.get(handle.sessionId)?.size === 0 || !this.pendingInteractions.has(handle.sessionId)) {
        this.setStatus(handle, 'running')
      }
      return
    }
    if (event.type === 'turn/end') {
      const kind = event.data?.reason?.kind
      if (kind && kind !== 'completed') {
        const code = ['aborted', 'blocked', 'max-tokens'].includes(kind) ? kind : 'failed'
        const message = code === 'aborted'
          ? '任务已停止。'
          : code === 'blocked'
            ? '本次任务被安全策略阻止。'
            : code === 'max-tokens'
              ? '任务回答达到长度上限。'
              : '任务执行失败，请稍后重试。'
        this.appendError(handle, { type: 'error', at, ...(sourceSeq === undefined ? {} : { sourceSeq }), code, message })
      }
      if (this.pendingInteractions.get(handle.sessionId)?.size > 0) this.setStatus(handle, 'needs-input')
      else this.setStatus(handle, 'idle')
      return
    }
    if (event.type === 'user/message') {
      if (event.data?.source?.kind !== 'user') return
      const text = visibleText(event.data)
      const messageId = safeInternalId(event.data?.id, 200)
      if (!text || !messageId) return
      const clientMessageId = safeInternalId(event.data?.source?.rpcId, 180)
      this.append(handle, {
        type: 'user-message', at,
        ...(sourceSeq === undefined ? {} : { sourceSeq }),
        messageId: publicKey('message', messageId),
        ...(clientMessageId === undefined ? {} : { clientMessageId }),
        text,
      })
      return
    }
    if (event.type === 'assistant/chunk') {
      const chunk = event.data?.chunk
      if (chunk?.type !== 'text-delta' || typeof chunk.text !== 'string' || !chunk.text) return
      const turn = eventPosition(event.data?.turn)
      const step = eventPosition(event.data?.step)
      if (turn === undefined || step === undefined) return
      const key = streamKey(turn, step)
      const used = handle.streamLengths.get(key) ?? 0
      const remaining = CHAT_OUTPUT_MAX_CODE_POINTS - used
      if (remaining <= 0) return
      const delta = codePoints(chunk.text.replace(/\u0000/g, '')).slice(0, remaining).join('')
      if (!delta) return
      handle.streamLengths.set(key, used + codePoints(delta).length)
      this.append(handle, {
        type: 'assistant-delta', at,
        ...(sourceSeq === undefined ? {} : { sourceSeq }),
        turn,
        step,
        delta,
      })
      return
    }
    if (event.type === 'assistant/message') {
      const message = event.data?.message
      const text = visibleText(message)
      const messageId = safeInternalId(message?.id, 200)
      const turn = eventPosition(event.data?.turn)
      const step = eventPosition(event.data?.step)
      if (turn === undefined || step === undefined) return
      const key = streamKey(turn, step)
      handle.streamLengths.delete(key)
      if (!text || !messageId) return
      this.append(handle, {
        type: 'assistant-final', at,
        ...(sourceSeq === undefined ? {} : { sourceSeq }),
        turn,
        step,
        messageId: publicKey('message', messageId),
        text,
      })
    }
  }

  append(handle, event) {
    const entry = { ...event, sequence: ++handle.sequence }
    handle.events.push(entry)
    if (handle.events.length > WORKSPACE_EVENT_BUFFER) {
      handle.events.splice(0, handle.events.length - WORKSPACE_EVENT_BUFFER)
    }
    for (const waiter of [...handle.waiters]) {
      if (entry.sequence > waiter.afterSequence) waiter.finish()
    }
    return entry
  }

  appendError(handle, event) {
    const previous = handle.events.at(-1)
    if (
      previous?.type === 'error'
      && previous.code === event.code
      && previous.message === event.message
      && Math.abs(Number(event.at) - Number(previous.at)) <= 5_000
    ) return previous
    return this.append(handle, event)
  }

  waitForEvent(handle, afterSequence, timeoutMilliseconds, signal) {
    throwIfAborted(signal)
    return new Promise((resolve, reject) => {
      let timer
      const waiter = {
        afterSequence,
        finish: (error) => {
          if (!handle.waiters.delete(waiter)) return
          if (timer !== undefined) clearTimeout(timer)
          signal?.removeEventListener('abort', onAbort)
          if (error) reject(error)
          else resolve()
        },
      }
      const onAbort = () => waiter.finish(abortError())
      handle.waiters.add(waiter)
      signal?.addEventListener('abort', onAbort, { once: true })
      timer = setTimeout(() => waiter.finish(), timeoutMilliseconds)
      timer.unref?.()
    })
  }

  startNeedsInputStream() {
    if (typeof this.api.events?.mux !== 'function') return
    const controller = new AbortController()
    this.streamAbort = controller
    this.streamTask = (async () => {
      try {
        const rpcId = `workspace-stream-${randomUUID()}`
        for await (const envelope of this.api.events.mux({ rpcId, payload: {} }, controller.signal)) {
          if (controller.signal.aborted || !isRecord(envelope?.payload)) break
          const frame = envelope.payload
          if (!this.ownsSession(frame.sessionId)) continue
          if (frame.type === 'approval/requested') {
            const id = safeInternalId(frame.approvalId)
            if (id) this.setInteraction(frame.sessionId, `a:${id}`, true)
          }
          else if (frame.type === 'approval/resolved') {
            const id = safeInternalId(frame.approvalId)
            if (id) this.setInteraction(frame.sessionId, `a:${id}`, false)
          }
          else if (frame.type === 'question/requested') {
            this.setInteraction(frame.sessionId, `q:${String(envelope.rpcId)}`, true)
          }
          else if (frame.type === 'question/resolved') {
            this.setInteraction(frame.sessionId, `q:${String(frame.questionRpcId)}`, false)
          }
        }
      }
      catch (error) {
        if (!controller.signal.aborted) {
          this.ctx?.logger?.warn?.(`souldock workspace: needs-input stream stopped: ${String(error)}`)
        }
      }
    })()
  }

  async invoke(label, call, payload, rpcId = `workspace-${randomUUID()}`) {
    let response
    try {
      response = await call({ rpcId, payload })
    }
    catch (error) {
      this.ctx?.logger?.warn?.(`souldock workspace: ${label} transport failed: ${String(error)}`)
      throw new Error('无法连接 DSH 工作区服务。')
    }
    if (!isRecord(response) || response.rpcId !== rpcId || !isRecord(response.result)) {
      this.ctx?.logger?.warn?.(`souldock workspace: ${label} returned an invalid response envelope`)
      throw new Error('DSH 返回了无效的工作区响应。')
    }
    if (response.result.ok !== true) {
      const code = String(response.result.error?.code ?? 'internal')
      this.ctx?.logger?.warn?.(`souldock workspace: ${label} rejected (${code}): ${String(response.result.error?.message ?? '')}`)
      throw new Error(publicApiError(code))
    }
    return response.result.value
  }
}
