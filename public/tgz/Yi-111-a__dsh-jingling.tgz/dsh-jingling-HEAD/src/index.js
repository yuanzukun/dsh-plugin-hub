/**
 * Jingling host half: durable state, event-only presence, and protected RPC.
 */

import Schema from '@deepseek-ai/schemastery'
import { boundContextSummary, createUserMessage } from '@deepseek-ai/dsh-llm'
import { activityFromSessionEvent } from './core.js'
import { SoulDockChatBridge } from './chat.js'
import { SoulDockWorkspaceBridge, WORKSPACE_PRESET_ID } from './workspace.js'
import { createSoulDockRpcHandler } from './rpc.js'
import { SoulDockService } from './service.js'
import { soulDockDomainSpec } from './storage.js'
import { installProactiveRuntime } from './proactive.js'

export const name = 'souldock'
export const inject = ['storageDomain', 'agents', 'agentPresets', 'sessions', 'sessionPersistence']

export const Config = Schema.object({
  trackDshActivity: Schema.boolean().default(true),
  proactivePollSeconds: Schema.number().default(60),
  sidecarExecutablePath: Schema.string().default(''),
})

function isSoulDockAgent(ctx, agent) {
  return agent !== undefined
    && ctx.agents.get(agent.id) === agent
    && ctx.agents.roots().includes(agent)
    && ctx.agentPresets.composedPreset(agent.ctx) === 'souldock'
}

export async function apply(ctx, config = {}) {
  const domain = await ctx.storageDomain.open(soulDockDomainSpec)
  ctx.effect(() => async () => { await domain.close() }, 'souldock: close durable domain')

  const service = new SoulDockService(domain.global, {
    shareAssistantText: true,
    sidecarExecutablePath: config.sidecarExecutablePath || '',
  })
  await service.initialize()
  ctx.provide('soulDock', service)

  installProactiveRuntime(ctx, service, {
    pollMilliseconds: Math.max(5, Number(config.proactivePollSeconds) || 60) * 1000,
    createUserMessage,
    boundContextSummary,
  })

  // Connection owns Host/Origin/DNS-rebinding checks, the JSON envelope,
  // request-size limits, cancellation, and cleanup. Jingling stays loopback
  // even if another DSH channel is explicitly exposed to a trusted LAN host.
  let chatBridge
  let workspaceBridge
  ctx.inject(['connection'], (connectionCtx) => {
    const dispose = connectionCtx.connection.rpc.handle(
      '/souldock',
      createSoulDockRpcHandler(service, () => chatBridge, () => workspaceBridge),
      { authority: 'loopback' },
    )
    connectionCtx.effect(() => dispose, 'souldock: loopback RPC')
  })

  // Reuse the official rc.6 ApiProxy in-process, then project it down to the
  // five text-only chat RPCs above. The desktop process never receives the
  // generic /api surface or its all-session streams.
  ctx.inject(['apiProxy'], (apiCtx) => {
    const bridge = new SoulDockChatBridge(apiCtx, service, apiCtx.apiProxy)
    const workspaces = new SoulDockWorkspaceBridge(apiCtx, apiCtx.apiProxy)
    chatBridge = bridge
    workspaceBridge = workspaces
    apiCtx.on('session/event', (session, event) => {
      const agent = apiCtx.agents.get(session.id)
      if (bridge.ownsSession(session.id) && isSoulDockAgent(apiCtx, agent)) {
        bridge.acceptSessionEvent(session, event)
      }
      if (
        workspaces.ownsSession(session.id)
        && agent !== undefined
        && apiCtx.agents.get(agent.id) === agent
        && apiCtx.agents.roots().includes(agent)
        && apiCtx.agentPresets.composedPreset(agent.ctx) === WORKSPACE_PRESET_ID
      ) workspaces.acceptSessionEvent(session, event)
    })
    apiCtx.on('agent/status', ({ agent, status }) => {
      if (bridge.ownsSession(agent.id) && isSoulDockAgent(apiCtx, agent)) bridge.acceptStatus(agent, status)
      if (
        workspaces.ownsSession(agent.id)
        && apiCtx.agents.get(agent.id) === agent
        && apiCtx.agents.roots().includes(agent)
        && apiCtx.agentPresets.composedPreset(agent.ctx) === WORKSPACE_PRESET_ID
      ) workspaces.acceptStatus(agent, status)
    })
    apiCtx.on('agent/error', ({ agent }) => {
      if (bridge.ownsSession(agent.id) && isSoulDockAgent(apiCtx, agent)) bridge.acceptError(agent)
      if (
        workspaces.ownsSession(agent.id)
        && apiCtx.agents.get(agent.id) === agent
        && apiCtx.agents.roots().includes(agent)
        && apiCtx.agentPresets.composedPreset(agent.ctx) === WORKSPACE_PRESET_ID
      ) workspaces.acceptError(agent)
    })
    apiCtx.effect(() => () => {
      bridge.dispose()
      workspaces.dispose()
      if (chatBridge === bridge) chatBridge = undefined
      if (workspaceBridge === workspaces) workspaceBridge = undefined
    }, 'souldock: filtered desktop chat and workspace bridges')
  })

  if (config.trackDshActivity !== false) {
    let idleTimer
    const cancelIdle = () => {
      if (idleTimer !== undefined) clearTimeout(idleTimer)
      idleTimer = undefined
    }
    ctx.effect(() => () => cancelIdle(), 'souldock: activity timer')
    ctx.on('session/event', (session, event) => {
      const agent = ctx.agents.get(session.id)
      if (!isSoulDockAgent(ctx, agent)) return
      const activity = activityFromSessionEvent(event.type, event.data)
      if (!activity) return
      cancelIdle()
      service.publishActivity(activity, event.type, { sessionId: session.id })
    })
    ctx.on('agent/status', ({ agent, status }) => {
      if (!isSoulDockAgent(ctx, agent)) return
      cancelIdle()
      if (status === 'running') {
        service.publishActivity(
          { phase: 'thinking', detail: 'DSH 正在处理新回合' },
          'agent/status:running',
          { sessionId: agent.id },
        )
        return
      }
      // Keep completion/error reactions visible briefly instead of replacing
      // them with idle in the same event-loop tick.
      idleTimer = setTimeout(() => {
        idleTimer = undefined
        service.publishActivity(
          { phase: 'idle', detail: '安静陪伴中' },
          'agent/status:idle',
          { sessionId: agent.id },
        )
      }, 3500)
    })
  }
}

export default { name, inject, Config, apply }
