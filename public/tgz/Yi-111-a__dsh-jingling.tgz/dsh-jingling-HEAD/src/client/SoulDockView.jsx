import React, { useCallback, useEffect, useMemo, useState } from 'react'
import idleImage from '../../assets/jingling-idle.png'

const PHASE_LABELS = {
  idle: '安静陪伴中',
  listening: '在听',
  thinking: '在想',
  working: '陪 DSH 忙着',
  approval: '等待你的授权',
  celebrating: '完成啦',
  concerned: '遇到一点问题',
}

const KIND_LABELS = {
  fact: '事实', preference: '偏好', moment: '共同经历', promise: '约定', boundary: '边界',
}

function dateLabel(value) {
  if (!value) return '未知时间'
  try { return new Intl.DateTimeFormat('zh-CN', { dateStyle: 'medium' }).format(new Date(value)) } catch { return value }
}

function downloadJson(name, value) {
  const blob = new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = name
  link.click()
  setTimeout(() => URL.revokeObjectURL(url), 0)
}

function wrapCanvasText(context, text, x, y, maxWidth, lineHeight, maxLines = 4) {
  const units = Array.from(String(text))
  let line = ''
  let row = 0
  for (const unit of units) {
    const candidate = line + unit
    if (context.measureText(candidate).width > maxWidth && line) {
      context.fillText(line, x, y + row * lineHeight)
      row += 1
      if (row >= maxLines) return
      line = unit
    } else line = candidate
  }
  if (line && row < maxLines) context.fillText(line, x, y + row * lineHeight)
}

function downloadMomentPng(card) {
  const canvas = document.createElement('canvas')
  canvas.width = 1200; canvas.height = 630
  const context = canvas.getContext('2d')
  const gradient = context.createLinearGradient(0, 0, 1200, 630)
  gradient.addColorStop(0, '#102f2a'); gradient.addColorStop(0.58, '#1d5547'); gradient.addColorStop(1, '#e5bd79')
  context.fillStyle = gradient; context.fillRect(0, 0, 1200, 630)
  context.globalAlpha = 0.18; context.fillStyle = '#fff3d5'
  for (const [x,y,r] of [[990,80,210],[1100,520,300],[145,555,120]]) { context.beginPath(); context.arc(x,y,r,0,Math.PI*2); context.fill() }
  context.globalAlpha = 1
  context.fillStyle = '#f8efd9'; context.font = '700 30px Georgia, serif'; context.fillText('JINGLING · MOMENT', 72, 78)
  context.fillStyle = '#ffcc8a'; context.font = '700 64px Georgia, serif'; wrapCanvasText(context, card.title, 72, 180, 740, 76, 2)
  context.fillStyle = '#f8efd9'; context.font = '32px system-ui, sans-serif'; wrapCanvasText(context, card.note || '这一刻，被温柔地记在你手里。', 76, 350, 770, 48, 3)
  context.fillStyle = '#102f2a'; context.beginPath(); context.arc(1000,270,112,0,Math.PI*2); context.fill()
  context.fillStyle = '#ffcc8a'; context.beginPath(); context.arc(965,255,10,0,Math.PI*2); context.arc(1035,255,10,0,Math.PI*2); context.fill()
  context.strokeStyle = '#ffcc8a'; context.lineWidth = 8; context.beginPath(); context.arc(1000,285,42,0.25,Math.PI-0.25); context.stroke()
  context.fillStyle = '#fff3d5'; context.font = '700 30px system-ui, sans-serif'; context.textAlign = 'center'; context.fillText(card.companion.name, 1000, 430)
  context.textAlign = 'left'; context.globalAlpha = 0.75; context.font = '20px system-ui, sans-serif'; context.fillText('AI 生成内容 · 不包含聊天、记忆或用户档案', 72, 578)
  const link = document.createElement('a'); link.download = 'jingling-moment-card.png'; link.href = canvas.toDataURL('image/png'); link.click()
}

function MemoryItem({ item, onForget, proposal, onConfirm, onReject }) {
  return <article className={`sd-memory ${proposal ? 'sd-proposal' : ''}`}>
    <div className="sd-memory-top">
      <span className="sd-memory-kind">{KIND_LABELS[item.kind] ?? item.kind}</span>
      <button className="sd-button ghost small" onClick={() => proposal ? onReject(item.id) : onForget(item.id)}>
        {proposal ? '不记' : '忘记'}
      </button>
    </div>
    <p>{item.content}</p>
    <div className="sd-source">
      <span>来源：{item.source?.summary ?? item.sourceSummary ?? '待确认'}</span>
      <span>{dateLabel(item.confirmedAt ?? item.createdAt)}</span>
      {item.sensitivity === 'private' && <span>私密</span>}
    </div>
    {proposal && <div className="sd-inline-actions">
      <button className="sd-button primary small" onClick={() => onConfirm(item.id)}>确认记住</button>
      <span className="sd-muted">确认前不会进入模型记忆</span>
    </div>}
  </article>
}

function Overview({ state, speak, rpc, notify }) {
  const persona = state.personas.find(item => item.id === state.activePersonaId) ?? state.personas[0]
  const active = state.memories.filter(item => item.status === 'active').length
  const superseded = state.memories.filter(item => item.status === 'superseded').length
  const [moment, setMoment] = useState({ title: '今天也一起完成了一件事', note: '' })
  const [momentPreview, setMomentPreview] = useState(null)
  const previewMoment = async () => {
    try { setMomentPreview(await rpc('export/moment-card', moment)); notify('纪念卡已通过凭据与个人信息检查；不会自动分享。') } catch (error) { notify(error.message, true) }
  }
  return <>
    <section className="sd-grid">
      <article className="sd-card third">
        <div className="sd-stat">{active}</div>
        <div className="sd-stat-label">已确认记忆</div>
        <p className="sd-muted">每条都能追溯来源，也能单独遗忘。</p>
      </article>
      <article className="sd-card third">
        <div className="sd-stat">{state.proposals.length}</div>
        <div className="sd-stat-label">等待你确认</div>
        <p className="sd-muted">普通提议只在当前 DSH 进程内暂存，确认前不会用于回忆；命中内置常见敏感模式的提议会被拒绝，规则不是完整 DLP，请逐条审阅。</p>
      </article>
      <article className="sd-card third">
        <div className="sd-stat">{superseded}</div>
        <div className="sd-stat-label">历史修订</div>
        <p className="sd-muted">同一主题的新事实会取代旧版本，不会同时注入。</p>
      </article>
      <article className="sd-card">
        <div className="sd-card-head"><div><h3>为什么它在动</h3><p>只读 DSH 事件，不看你的屏幕。</p></div></div>
        <div className="sd-note">{state.runtime.detail ?? PHASE_LABELS[state.runtime.phase]}。鲸灵只接收“思考 / 工具 / 授权 / 完成 / 出错”等事件类型，不读取屏幕、摄像头、麦克风或剪贴板。</div>
      </article>
      <article className="sd-card">
        <div className="sd-card-head"><div><h3>零配置声音</h3><p>使用浏览器系统朗读，不上传音频。</p></div></div>
        <p className="sd-intro" style={{ fontSize: 14, margin: '0 0 14px' }}>“{persona.firstMessage}”</p>
        <button className="sd-button secondary" onClick={() => speak(persona.firstMessage)}>使用系统合成语音朗读</button>
      </article>
      <article className="sd-card wide">
        <div className="sd-card-head"><div><h3>手工纪念卡</h3><p>先预览，再由你保存；默认不带记忆、聊天或用户档案。</p></div></div>
        <div className="sd-form-row"><label className="sd-field"><span>标题</span><input className="sd-input" value={moment.title} maxLength={120} onChange={e => { setMoment({ ...moment, title: e.target.value }); setMomentPreview(null) }} /></label><label className="sd-field"><span>一句话（可空）</span><input className="sd-input" value={moment.note} maxLength={500} onChange={e => { setMoment({ ...moment, note: e.target.value }); setMomentPreview(null) }} /></label></div>
        {momentPreview && <div className="sd-preview"><strong>{momentPreview.title}</strong><div>{momentPreview.note || '这一刻，被温柔地记在你手里。'}</div><small>AI 生成内容 · {momentPreview.companion.name}</small></div>}
        <div className="sd-inline-actions" style={{ marginTop: 14 }}><button className="sd-button secondary" onClick={previewMoment}>隐私检查预览</button>{momentPreview && <><button className="sd-button primary" onClick={() => downloadMomentPng(momentPreview)}>保存 PNG</button><button className="sd-button ghost" onClick={() => downloadJson('jingling-moment-card.json', momentPreview)}>保存 JSON</button></>}</div>
      </article>
    </section>
  </>
}

function Memories({ state, rpc, refresh, notify }) {
  const [form, setForm] = useState({ kind: 'preference', content: '', subject: '' })
  const active = state.memories.filter(item => item.status === 'active')
  const act = async (endpoint, payload, message) => {
    try { await rpc(endpoint, payload); await refresh(); notify(message) } catch (error) { notify(error.message, true) }
  }
  const create = async event => {
    event.preventDefault()
    if (!form.content.trim()) return
    await act('memory/create', { ...form, sourceSummary: '用户在鲸灵界面中手动确认' }, '已经记住，并保留了来源。')
    setForm(current => ({ ...current, content: '', subject: '' }))
  }
  return <section className="sd-grid">
    <article className="sd-card">
      <div className="sd-card-head"><div><h2>待你确认</h2><p>普通提议只留在当前 DSH 进程内，24 小时、拒绝或退出即消失；确认前不进模型检索。常见敏感模式会拦截，但不是完整 DLP，请逐条审阅。</p></div><span className="sd-stat">{state.proposals.length}</span></div>
      <div className="sd-list">
        {state.proposals.length === 0 && <div className="sd-empty">还没有待确认的记忆</div>}
        {state.proposals.map(item => <MemoryItem key={item.id} item={item} proposal
          onConfirm={id => act('memory/confirm', { id }, '已确认这条记忆。')}
          onReject={id => act('memory/reject', { id }, '已丢弃提议，内容不会保留。')} />)}
      </div>
    </article>
    <article className="sd-card">
      <div className="sd-card-head"><div><h2>我来写一条</h2><p>手动提交等同于明确确认。</p></div></div>
      <form className="sd-form" onSubmit={create}>
        <div className="sd-form-row">
          <label className="sd-field"><span>类型</span><select className="sd-select" value={form.kind} onChange={e => setForm({ ...form, kind: e.target.value })}>
            {Object.entries(KIND_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
          </select></label>
          <label className="sd-field"><span>主题键（用于更新旧事实）</span><input className="sd-input" value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} placeholder="例如：常喝的饮料" /></label>
        </div>
        <label className="sd-field"><span>要记住的内容</span><textarea className="sd-textarea" value={form.content} onChange={e => setForm({ ...form, content: e.target.value })} placeholder="我更喜欢无糖乌龙茶。" maxLength={1000} /></label>
        <div className="sd-warning">鲸灵会拒绝看起来像密码、令牌、私钥或访问密钥的内容。健康、财务、住址等信息会标成私密。</div>
        <button className="sd-button primary" type="submit">确认并记住</button>
      </form>
    </article>
    <article className="sd-card wide">
      <div className="sd-card-head"><div><h2>记忆账本</h2><p>这里只展示当前有效版本；被取代的版本不会发给模型。</p></div><span className="sd-stat">{active.length}</span></div>
      <div className="sd-list">
        {active.length === 0 && <div className="sd-empty">还没有长期记忆。聊过的内容不会自动变成记忆。</div>}
        {active.map(item => <MemoryItem key={item.id} item={item} onForget={id => act('memory/forget', { id }, '已从鲸灵账本和后续提示中移除。既有 DSH 会话历史或备份可能仍保留过去的快照。')} />)}
      </div>
    </article>
  </section>
}

function Persona({ state, rpc, refresh, notify }) {
  const persona = state.personas.find(item => item.id === state.activePersonaId) ?? state.personas[0]
  const [form, setForm] = useState(() => ({
    name: persona.name, description: persona.description, personality: persona.personality,
    scenario: persona.scenario, firstMessage: persona.firstMessage,
  }))
  const [card, setCard] = useState('')
  const [preview, setPreview] = useState(null)
  useEffect(() => setForm({ name: persona.name, description: persona.description, personality: persona.personality, scenario: persona.scenario, firstMessage: persona.firstMessage }), [persona.id, persona.updatedAt])
  const save = async event => {
    event.preventDefault()
    try { await rpc('persona/update', { patch: form }); await refresh(); notify('人格设定已更新。') } catch (error) { notify(error.message, true) }
  }
  const previewCard = async () => {
    try { setPreview(await rpc('character/preview', { card })); notify('角色卡解析完成，危险字段不会执行。') } catch (error) { notify(error.message, true) }
  }
  const importCard = async () => {
    try { await rpc('character/import', { card }); setCard(''); setPreview(null); await refresh(); notify('角色卡已作为新的当前人格导入。') } catch (error) { notify(error.message, true) }
  }
  const activate = async id => {
    try { await rpc('persona/activate', { id }); await refresh(); notify('已切换伙伴；角色之间的记忆互不串联。') } catch (error) { notify(error.message, true) }
  }
  return <section className="sd-grid">
    <article className="sd-card">
      <div className="sd-card-head"><div><h2>当前人格</h2><p>人格塑造语气，不拥有任何权限。</p></div></div>
      <form className="sd-form" onSubmit={save}>
        <label className="sd-field"><span>伙伴</span><select className="sd-select" value={state.activePersonaId} onChange={e => activate(e.target.value)}>{state.personas.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
        <label className="sd-field"><span>名字</span><input className="sd-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label>
        <label className="sd-field"><span>角色简介</span><textarea className="sd-textarea" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></label>
        <label className="sd-field"><span>性格</span><textarea className="sd-textarea" value={form.personality} onChange={e => setForm({ ...form, personality: e.target.value })} /></label>
        <label className="sd-field"><span>相处场景</span><textarea className="sd-textarea" value={form.scenario} onChange={e => setForm({ ...form, scenario: e.target.value })} /></label>
        <label className="sd-field"><span>初次见面</span><textarea className="sd-textarea" value={form.firstMessage} onChange={e => setForm({ ...form, firstMessage: e.target.value })} /></label>
        <button className="sd-button primary" type="submit">保存人格</button>
      </form>
    </article>
    <article className="sd-card">
      <div className="sd-card-head"><div><h2>Character Card V2</h2><p>兼容角色资产，独立 clean-room 解析。</p></div></div>
      <div className="sd-form">
        <label className="sd-field"><span>粘贴 JSON</span><textarea className="sd-textarea code" value={card} onChange={e => { setCard(e.target.value); setPreview(null) }} placeholder={'{"spec":"chara_card_v2","spec_version":"2.0","data":{...}}'} /></label>
        <div className="sd-warning">system_prompt、post_history_instructions、脚本、extensions 与 lorebook 一律忽略；角色素材版权仍由导入者负责。</div>
        <div className="sd-inline-actions"><button className="sd-button secondary" onClick={previewCard} disabled={!card.trim()}>安全预览</button>{preview && <button className="sd-button primary" onClick={importCard}>确认导入</button>}</div>
        {preview && <div className="sd-preview"><strong>{preview.persona.name}</strong><div>{preview.persona.description || '无简介'}</div>{preview.warnings.length > 0 && <ul>{preview.warnings.map((warning, index) => <li key={index}>{warning}</li>)}</ul>}</div>}
      </div>
    </article>
  </section>
}

function Privacy({ state, rpc, refresh, notify }) {
  const [adult, setAdult] = useState(state.settings.adultConfirmed)
  const [style, setStyle] = useState(state.relationship.style)
  const [proactive, setProactive] = useState({ ...state.settings.proactive })
  const [armed, setArmed] = useState(false)
  useEffect(() => {
    setAdult(state.settings.adultConfirmed)
    setStyle(state.relationship.style)
    setProactive({ ...state.settings.proactive })
  }, [
    state.settings.adultConfirmed,
    state.relationship.style,
    state.settings.proactive.enabled,
    state.settings.proactive.dailyLimit,
    state.settings.proactive.quietHoursStart,
    state.settings.proactive.quietHoursEnd,
    state.settings.proactive.idleAfterMinutes,
    state.settings.proactive.minimumGapMinutes,
    state.settings.proactive.timeZone,
    state.settings.proactive.snoozedUntil,
  ])
  const save = async () => {
    try {
      await rpc('settings/update', { patch: { adultConfirmed: adult, relationshipStyle: style, proactive } })
      await refresh(); notify('边界与主动陪伴设置已保存。')
    } catch (error) { notify(error.message, true) }
  }
  const exportPack = async () => {
    try { downloadJson('jingling-soul-pack.json', await rpc('export/soul-pack', {})); notify('已导出经过凭据与个人信息筛查的 Soul Pack。') } catch (error) { notify(error.message, true) }
  }
  const exportPrivate = async () => {
    if (!window.confirm('完整私密归档包含人格、记忆正文、来源、设置与审计元数据。只应保存在可信本机。继续吗？')) return
    try { downloadJson('jingling-private-data-archive.json', await rpc('export/private-archive', { confirm: 'PRIVATE_EXPORT' })); notify('完整私密归档已导出，请妥善保管。') } catch (error) { notify(error.message, true) }
  }
  const reset = async () => {
    if (!armed) { setArmed(true); return }
    try { await rpc('data/reset', { confirm: 'DELETE' }); setArmed(false); await refresh(); notify('鲸灵本地账本已重置；既有 DSH 会话历史与外部备份不在本操作范围。') } catch (error) { notify(error.message, true) }
  }
  return <section className="sd-grid">
    <article className="sd-card">
      <div className="sd-card-head"><div><h2>关系由你定义</h2><p>没有隐藏亲密度，也不会自行升级。</p></div></div>
      <div className="sd-form">
        <label className="sd-field"><span>关系风格</span><select className="sd-select" value={style} onChange={e => setStyle(e.target.value)}>
          <option value="companion">数字伙伴</option><option value="friend">朋友</option><option value="romantic">浪漫伙伴（仅成人）</option>
        </select></label>
        <label className="sd-check"><input type="checkbox" checked={adult} onChange={e => setAdult(e.target.checked)} /><span>我确认自己是成年人，并理解这是 AI 角色互动，不是真实人类关系。此声明不是公开服务所需年龄核验的替代品。</span></label>
        {style === 'romantic' && !adult && <div className="sd-warning">浪漫风格需要先明确成人确认。</div>}
        <button className="sd-button primary" onClick={save}>保存边界</button>
      </div>
    </article>
    <article className="sd-card">
      <div className="sd-card-head"><div><h2>克制的主动陪伴</h2><p>默认关闭；每天最多三次。</p></div></div>
      <div className="sd-form">
        <label className="sd-check"><input type="checkbox" checked={proactive.enabled} onChange={e => setProactive({ ...proactive, enabled: e.target.checked })} /><span>允许基于时间和 DSH 状态主动问候；不读取屏幕、剪贴板或摄像头。</span></label>
        <div className="sd-form-row">
          <label className="sd-field"><span>每日上限</span><select className="sd-select" value={proactive.dailyLimit} onChange={e => setProactive({ ...proactive, dailyLimit: Number(e.target.value) })}>{[0,1,2,3].map(n => <option key={n} value={n}>{n} 次</option>)}</select></label>
          <label className="sd-field"><span>安静时间</span><div style={{ display: 'flex', gap: 6 }}><input className="sd-input" type="time" value={proactive.quietHoursStart} onChange={e => setProactive({ ...proactive, quietHoursStart: e.target.value })} /><input className="sd-input" type="time" value={proactive.quietHoursEnd} onChange={e => setProactive({ ...proactive, quietHoursEnd: e.target.value })} /></div></label>
        </div>
        <div className="sd-form-row">
          <label className="sd-field"><span>离开多久再问候</span><select className="sd-select" value={proactive.idleAfterMinutes} onChange={e => setProactive({ ...proactive, idleAfterMinutes: Number(e.target.value) })}>{[[60,'1 小时'],[180,'3 小时'],[360,'6 小时'],[720,'12 小时']].map(([value,label]) => <option key={value} value={value}>{label}</option>)}</select></label>
          <label className="sd-field"><span>时区</span><input className="sd-input" value={proactive.timeZone} onChange={e => setProactive({ ...proactive, timeZone: e.target.value })} placeholder="Asia/Shanghai" /></label>
        </div>
        <div className="sd-inline-actions"><button className="sd-button ghost" onClick={() => setProactive({ ...proactive, snoozedUntil: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() })}>暂停 24 小时</button>{proactive.snoozedUntil && <button className="sd-button ghost" onClick={() => setProactive({ ...proactive, snoozedUntil: null })}>取消暂停</button>}</div>
        <button className="sd-button secondary" onClick={save}>保存主动设置</button>
      </div>
    </article>
    <article className="sd-card wide">
      <div className="sd-card-head"><div><h2>数据与分享</h2><p>零遥测。导出默认不带用户档案、记忆、历史、凭据或声音。</p></div></div>
      <div className="sd-note">当前存储：DSH 本地 storage-domain。标准记忆只在模型主动调用检索工具时返回，不会整库注入；私密记忆在 v0.1 中永不提供给模型工具，只能在本页查看或删除。普通待确认提议只存在于当前 DSH 进程内，24 小时、拒绝或退出即消失，不写入 storage-domain。</div>
      <div className="sd-inline-actions" style={{ marginTop: 16 }}>
        <button className="sd-button secondary" onClick={exportPack}>导出隐私筛查 Soul Pack</button>
        <button className="sd-button secondary" onClick={exportPrivate}>导出完整私密归档</button>
        <button className="sd-button danger" onClick={reset}>{armed ? '再点一次，清空鲸灵账本' : '重置鲸灵本地账本'}</button>
        {armed && <button className="sd-button ghost" onClick={() => setArmed(false)}>取消</button>}
      </div>
    </article>
  </section>
}

export function SoulDockView({ rpc, isLoopback }) {
  const [state, setState] = useState(null)
  const [tab, setTab] = useState('home')
  const [toast, setToast] = useState(null)
  const [sidecarLaunching, setSidecarLaunching] = useState(false)
  const notify = useCallback((message, error = false) => {
    setToast({ message, error })
    setTimeout(() => setToast(current => current?.message === message ? null : current), 4200)
  }, [])
  const refresh = useCallback(async () => {
    const next = await rpc('state/get', {})
    setState(next)
    return next
  }, [rpc])
  useEffect(() => {
    if (!isLoopback) return undefined
    let disposed = false
    refresh().catch(error => !disposed && notify(error.message, true))
    const timer = setInterval(() => refresh().catch(() => {}), 2500)
    return () => { disposed = true; clearInterval(timer) }
  }, [isLoopback, refresh, notify])
  const speak = useCallback(text => {
    if (!('speechSynthesis' in window)) return notify('这个浏览器没有系统朗读能力。', true)
    window.speechSynthesis.cancel()
    notify('正在使用浏览器提供的系统合成语音；这不是真人录音。')
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = state?.settings.voice.locale ?? 'zh-CN'
    utterance.rate = state?.settings.voice.rate ?? 1
    window.speechSynthesis.speak(utterance)
  }, [notify, state])
  const launchSidecar = useCallback(async () => {
    setSidecarLaunching(true)
    try {
      const result = await rpc('sidecar/launch', {})
      if (result.alreadyRunning) {
        notify('桌面伙伴已经在运行啦～')
      } else {
        notify('桌面伙伴已启动，去看看你的桌面吧 🐋')
      }
    } catch (error) {
      notify(error.message, true)
    } finally {
      setSidecarLaunching(false)
    }
  }, [rpc, notify])
  const persona = useMemo(() => state?.personas.find(item => item.id === state.activePersonaId) ?? state?.personas[0], [state])

  if (!isLoopback) return <div className="sd-root"><div className="sd-lock"><h2>鲸灵只在本机开放</h2><p className="sd-muted">记忆、人设和导出属于私密配置面。当前页面不是 loopback 地址，因此 DSH 的 RPC 围栏拒绝访问。</p></div></div>
  if (!state || !persona) return <div className="sd-root"><div className="sd-loading">正在唤醒鲸灵…</div></div>
  const phase = state.runtime.phase ?? 'idle'
  return <div className="sd-root"><div className="sd-shell">
    <header className="sd-topbar"><div className="sd-brand"><div className="sd-mark" /><div className="sd-brand-copy"><strong>JINGLING</strong><span>鲸灵 · DSH 数字伙伴层</span></div></div><div className="sd-ai-badge">这是 AI，不是真人</div></header>
    <section className="sd-hero">
      <div className={`sd-stage sd-phase--${phase}`}><div className="sd-pet-wrap"><div className="sd-halo" /><div className="sd-pet"><img className="sd-pet-img" src={idleImage} alt="鲸灵" /></div><div className="sd-status-pill">{PHASE_LABELS[phase] ?? phase}</div></div></div>
      <div className="sd-hero-copy"><div className="sd-kicker">Local-first companion presence</div><h1 className="sd-title">{persona.name}</h1><p className="sd-intro">{persona.firstMessage}</p><div className="sd-hero-actions"><button className="sd-button primary" onClick={() => speak(persona.firstMessage)}>系统语音朗读</button><button className="sd-button secondary" onClick={() => setTab('memories')}>看看她记得什么</button><button className="sd-button secondary" onClick={launchSidecar} disabled={sidecarLaunching}>{sidecarLaunching ? '正在唤起…' : '打开桌面伙伴'}</button></div></div>
    </section>
    <nav className="sd-nav" aria-label="Jingling sections">{[['home','此刻'],['memories','记忆账本'],['persona','人格与导入'],['privacy','边界与隐私']].map(([id,label]) => <button key={id} className={tab === id ? 'active' : ''} onClick={() => setTab(id)}>{label}</button>)}</nav>
    {tab === 'home' && <Overview state={state} speak={speak} rpc={rpc} notify={notify} />}
    {tab === 'memories' && <Memories state={state} rpc={rpc} refresh={refresh} notify={notify} />}
    {tab === 'persona' && <Persona state={state} rpc={rpc} refresh={refresh} notify={notify} />}
    {tab === 'privacy' && <Privacy state={state} rpc={rpc} refresh={refresh} notify={notify} />}
    <footer className="sd-footer"><span>0 telemetry · DSH storage-domain · loopback-only RPC</span><span>Live2D / VRM / full-duplex voice are adapters, not bundled in v0.1</span></footer>
    {toast && <div className={`sd-toast ${toast.error ? 'error' : ''}`} role="status">{toast.message}</div>}
  </div></div>
}
