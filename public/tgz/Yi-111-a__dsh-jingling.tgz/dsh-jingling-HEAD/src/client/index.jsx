/** Browser half: one native DSH conversation tab over Connection RPC. */

import React from 'react'
import { SoulDockView } from './SoulDockView.jsx'
import { styles } from './styles.js'

export const inject = ['slots', 'connection']

function installStyles() {
  if (typeof document === 'undefined') return () => {}
  const id = 'dsh-jingling-styles'
  if (document.getElementById(id)) return () => {}
  const tag = document.createElement('style')
  tag.id = id
  tag.dataset.plugin = 'dsh-jingling'
  tag.textContent = styles
  document.head.appendChild(tag)
  return () => tag.remove()
}

function installWellbeingReminder() {
  if (typeof document === 'undefined' || typeof window === 'undefined') return () => {}
  // Preserve the preview key so an upgrade from dsh-souldock does not reset
  // the user's local visible-use reminder interval.
  const storageKey = 'dsh-souldock:visible-use-ms'
  const threshold = 2 * 60 * 60 * 1000
  let accumulated = Math.max(0, Number(window.sessionStorage.getItem(storageKey)) || 0)
  let lastTick = Date.now()
  let wasVisible = document.visibilityState === 'visible'

  const persist = () => window.sessionStorage.setItem(storageKey, String(Math.floor(accumulated)))
  const dismiss = () => {
    accumulated = 0
    persist()
    document.getElementById('dsh-jingling-wellbeing')?.remove()
  }
  const show = () => {
    if (document.getElementById('dsh-jingling-wellbeing')) return
    const banner = document.createElement('aside')
    banner.id = 'dsh-jingling-wellbeing'
    banner.dataset.plugin = 'dsh-jingling'
    banner.setAttribute('role', 'status')
    banner.innerHTML = '<strong>使用时长提醒</strong><span>你已在当前页面可见状态下使用约 2 小时。建议休息、活动一下或看看远处；是否继续由你决定。</span><button type="button">知道了</button>'
    banner.querySelector('button')?.addEventListener('click', dismiss, { once: true })
    document.body.appendChild(banner)
  }
  const tick = () => {
    const now = Date.now()
    // Clamp each interval so sleep, browser shutdown, or throttled background
    // tabs never masquerade as continuous visible use.
    if (wasVisible) accumulated += Math.max(0, Math.min(now - lastTick, 70_000))
    lastTick = now
    wasVisible = document.visibilityState === 'visible'
    persist()
    if (accumulated >= threshold) show()
  }
  const onVisibility = () => tick()
  document.addEventListener('visibilitychange', onVisibility)
  const timer = window.setInterval(tick, 60_000)
  return () => {
    tick()
    window.clearInterval(timer)
    document.removeEventListener('visibilitychange', onVisibility)
    document.getElementById('dsh-jingling-wellbeing')?.remove()
  }
}

function unwrapRpc(result) {
  if (!result?.ok) throw new Error(result?.error?.message ?? 'Jingling RPC failed')
  const app = result.value
  if (!app?.ok) throw new Error(app?.error?.message ?? 'Jingling request was rejected')
  return app.value
}

export function apply(ctx) {
  ctx.effect(() => installStyles(), 'souldock: client styles')
  ctx.effect(() => installWellbeingReminder(), 'souldock: neutral two-hour reminder')
  const rpc = async (endpoint, payload, signal) => unwrapRpc(
    await ctx.connection.rpc.call('/souldock', endpoint, payload, signal),
  )
  ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view',
    id: 'souldock',
    order: 20,
    label: '鲸灵',
    inject: () => ({ rpc, isLoopback: ctx.connection.isLoopback }),
  }, SoulDockView))
}

export default { inject, apply }
