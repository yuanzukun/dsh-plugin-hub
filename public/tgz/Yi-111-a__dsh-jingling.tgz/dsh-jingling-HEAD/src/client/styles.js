export const styles = String.raw`
#dsh-jingling-wellbeing{position:fixed;z-index:2147483000;left:50%;bottom:24px;transform:translateX(-50%);max-width:min(680px,calc(100vw - 32px));display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:12px;padding:14px 16px;border:1px solid rgba(32,91,75,.25);border-radius:16px;background:#f8f4e8;color:#173f36;box-shadow:0 18px 60px rgba(17,55,47,.22);font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}#dsh-jingling-wellbeing strong{white-space:nowrap}#dsh-jingling-wellbeing button{border:0;border-radius:999px;background:#245f50;color:#fff;padding:8px 14px;cursor:pointer}@media(max-width:560px){#dsh-jingling-wellbeing{grid-template-columns:1fr}#dsh-jingling-wellbeing button{justify-self:start}}
:root {
  --sd-ink: #17231f;
  --sd-forest: #21483d;
  --sd-jade: #2d7b65;
  --sd-mint: #b7e2d0;
  --sd-paper: #f6f0e3;
  --sd-cream: #fffaf0;
  --sd-coral: #e8684a;
  --sd-gold: #d8a84d;
  --sd-night: #10231e;
  --sd-line: rgba(31, 70, 58, .15);
  --sd-shadow: 0 24px 60px rgba(16, 35, 30, .14);
}

.sd-root, .sd-root * { box-sizing: border-box; }
.sd-root {
  min-height: 100%;
  color: var(--sd-ink);
  background:
    radial-gradient(circle at 12% 4%, rgba(232, 104, 74, .11), transparent 28rem),
    radial-gradient(circle at 92% 12%, rgba(45, 123, 101, .14), transparent 32rem),
    var(--sd-paper);
  font-family: "Avenir Next", "Noto Sans SC", "Microsoft YaHei", sans-serif;
  padding: clamp(18px, 3.5vw, 48px);
  overflow: auto;
}

.sd-shell { max-width: 1160px; margin: 0 auto; }
.sd-topbar { display: flex; align-items: center; justify-content: space-between; gap: 18px; margin-bottom: 24px; }
.sd-brand { display: flex; align-items: center; gap: 12px; }
.sd-mark { width: 38px; height: 38px; border: 1px solid rgba(33,72,61,.25); border-radius: 14px 14px 18px 18px; display: grid; place-items: center; background: var(--sd-cream); box-shadow: 0 8px 24px rgba(16,35,30,.09); transform: rotate(-3deg); }
.sd-mark::before { content: "栖"; color: var(--sd-forest); font-family: "STKaiti", "KaiTi", serif; font-size: 20px; }
.sd-brand-copy strong { display: block; letter-spacing: .15em; font-size: 13px; }
.sd-brand-copy span { display: block; color: rgba(23,35,31,.58); font-size: 12px; margin-top: 3px; }
.sd-ai-badge { display: inline-flex; align-items: center; gap: 7px; padding: 8px 11px; border-radius: 999px; background: rgba(255,250,240,.78); border: 1px solid var(--sd-line); color: var(--sd-forest); font-size: 12px; font-weight: 700; letter-spacing: .04em; }
.sd-ai-badge::before { content: ""; width: 7px; height: 7px; border-radius: 50%; background: var(--sd-jade); box-shadow: 0 0 0 4px rgba(45,123,101,.12); }

.sd-hero { display: grid; grid-template-columns: minmax(300px, .92fr) minmax(380px, 1.4fr); background: var(--sd-cream); border: 1px solid var(--sd-line); border-radius: 28px; overflow: hidden; box-shadow: var(--sd-shadow); min-height: 360px; }
.sd-stage { position: relative; display: grid; place-items: center; padding: 36px; min-height: 330px; overflow: hidden; background: linear-gradient(145deg, var(--sd-night), #1d4b3e); }
.sd-stage::before { content: ""; position: absolute; inset: 0; opacity: .2; background-image: radial-gradient(rgba(255,255,255,.7) .7px, transparent .7px); background-size: 18px 18px; mask-image: linear-gradient(to bottom, black, transparent 75%); }
.sd-stage::after { content: ""; position: absolute; width: 280px; height: 70px; bottom: 22px; border-radius: 50%; background: rgba(5,18,14,.34); filter: blur(14px); }
.sd-pet-wrap { position: relative; z-index: 2; display: grid; place-items: center; }
.sd-halo { position: absolute; width: 230px; height: 230px; border-radius: 50%; border: 1px solid rgba(183,226,208,.24); box-shadow: inset 0 0 60px rgba(183,226,208,.08), 0 0 80px rgba(216,168,77,.1); animation: sd-breathe 4.8s ease-in-out infinite; }
.sd-pet { position: relative; display: grid; place-items: center; animation: sd-float 4s ease-in-out infinite; }
.sd-pet-img { width: 176px; height: auto; max-height: 200px; border-radius: 18px; filter: drop-shadow(0 18px 30px rgba(2,15,11,.35)); }
.sd-phase--thinking .sd-pet { animation: sd-think 1.1s ease-in-out infinite alternate; }
.sd-phase--working .sd-halo { border-style: dashed; animation: sd-spin 5s linear infinite; }
.sd-phase--working .sd-pet { animation-duration: 1.35s; }
.sd-phase--approval .sd-halo { box-shadow: 0 0 0 12px rgba(232,104,74,.08), 0 0 80px rgba(232,104,74,.28); }
.sd-phase--celebrating .sd-pet { animation: sd-celebrate .8s ease-in-out infinite; }
.sd-status-pill { position: absolute; z-index: 4; bottom: -49px; left: 50%; transform: translateX(-50%); white-space: nowrap; padding: 8px 13px; border-radius: 999px; background: rgba(255,250,240,.94); color: var(--sd-forest); border: 1px solid rgba(255,255,255,.5); box-shadow: 0 8px 24px rgba(0,0,0,.16); font-size: 12px; font-weight: 700; }

.sd-hero-copy { padding: clamp(30px, 5vw, 62px); display: flex; flex-direction: column; justify-content: center; }
.sd-kicker { color: var(--sd-coral); text-transform: uppercase; letter-spacing: .17em; font-size: 11px; font-weight: 800; margin-bottom: 13px; }
.sd-title { font-family: "Iowan Old Style", "Noto Serif SC", "Songti SC", serif; font-size: clamp(40px, 6vw, 72px); font-weight: 500; line-height: .98; letter-spacing: -.045em; margin: 0; color: var(--sd-forest); }
.sd-intro { font-family: "Iowan Old Style", "Noto Serif SC", "Songti SC", serif; font-size: 17px; line-height: 1.7; margin: 24px 0 26px; color: rgba(23,35,31,.74); max-width: 42rem; }
.sd-hero-actions { display: flex; gap: 10px; flex-wrap: wrap; }

.sd-button { appearance: none; border: 0; border-radius: 13px; padding: 11px 15px; font: inherit; font-size: 13px; font-weight: 750; cursor: pointer; transition: transform .16s ease, box-shadow .16s ease, opacity .16s ease, background .16s ease; }
.sd-button:hover:not(:disabled) { transform: translateY(-1px); }
.sd-button:focus-visible { outline: 3px solid rgba(45,123,101,.25); outline-offset: 2px; }
.sd-button:disabled { opacity: .5; cursor: default; }
.sd-button.primary { background: var(--sd-forest); color: #fffaf0; box-shadow: 0 9px 20px rgba(33,72,61,.2); }
.sd-button.secondary { background: #ede5d5; color: var(--sd-forest); }
.sd-button.ghost { background: transparent; color: var(--sd-forest); border: 1px solid var(--sd-line); }
.sd-button.danger { background: #f7dfd9; color: #9d3e2d; }
.sd-button.small { padding: 7px 10px; border-radius: 9px; font-size: 12px; }

.sd-nav { display: flex; gap: 6px; margin: 28px 0 18px; padding: 5px; background: rgba(255,250,240,.64); border: 1px solid var(--sd-line); border-radius: 16px; width: fit-content; max-width: 100%; overflow-x: auto; }
.sd-nav button { appearance: none; border: 0; background: transparent; border-radius: 11px; padding: 9px 13px; color: rgba(23,35,31,.58); font: inherit; font-size: 12px; font-weight: 750; cursor: pointer; white-space: nowrap; }
.sd-nav button.active { color: var(--sd-forest); background: var(--sd-cream); box-shadow: 0 3px 12px rgba(16,35,30,.08); }

.sd-grid { display: grid; grid-template-columns: repeat(12, 1fr); gap: 16px; }
.sd-card { grid-column: span 6; background: rgba(255,250,240,.83); border: 1px solid var(--sd-line); border-radius: 20px; padding: 22px; box-shadow: 0 12px 34px rgba(16,35,30,.055); }
.sd-card.wide { grid-column: 1 / -1; }
.sd-card.third { grid-column: span 4; }
.sd-card h2, .sd-card h3 { margin: 0; font-family: "Iowan Old Style", "Noto Serif SC", serif; color: var(--sd-forest); font-weight: 600; }
.sd-card h2 { font-size: 24px; } .sd-card h3 { font-size: 18px; }
.sd-card-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; margin-bottom: 16px; }
.sd-card-head p, .sd-muted { color: rgba(23,35,31,.56); font-size: 12px; line-height: 1.55; margin: 5px 0 0; }
.sd-stat { font-family: "Iowan Old Style", serif; font-size: 34px; color: var(--sd-coral); }
.sd-stat-label { font-size: 11px; text-transform: uppercase; letter-spacing: .11em; color: rgba(23,35,31,.5); }
.sd-note { padding: 13px 15px; border-radius: 13px; background: rgba(183,226,208,.24); border-left: 3px solid var(--sd-jade); color: rgba(23,35,31,.75); line-height: 1.55; font-size: 12px; }

.sd-list { display: grid; gap: 10px; }
.sd-memory { padding: 14px; border: 1px solid var(--sd-line); border-radius: 14px; background: rgba(255,255,255,.45); }
.sd-memory-top { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
.sd-memory-kind { display: inline-flex; padding: 4px 8px; border-radius: 999px; background: rgba(45,123,101,.1); color: var(--sd-jade); text-transform: uppercase; letter-spacing: .08em; font-size: 9px; font-weight: 900; }
.sd-memory p { margin: 9px 0 7px; line-height: 1.55; font-size: 13px; word-break: break-word; }
.sd-source { color: rgba(23,35,31,.48); font-size: 10px; display: flex; gap: 8px; flex-wrap: wrap; }
.sd-proposal { border-color: rgba(216,168,77,.38); background: rgba(216,168,77,.08); }
.sd-inline-actions { display: flex; gap: 7px; flex-wrap: wrap; margin-top: 10px; }
.sd-empty { padding: 25px; text-align: center; border: 1px dashed rgba(33,72,61,.22); border-radius: 14px; color: rgba(23,35,31,.48); font-size: 12px; }

.sd-form { display: grid; gap: 13px; }
.sd-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.sd-field { display: grid; gap: 6px; }
.sd-field > span { color: rgba(23,35,31,.62); font-size: 11px; font-weight: 750; }
.sd-input, .sd-textarea, .sd-select { width: 100%; border: 1px solid rgba(33,72,61,.19); border-radius: 11px; background: rgba(255,255,255,.62); color: var(--sd-ink); font: inherit; font-size: 13px; padding: 10px 12px; outline: none; }
.sd-textarea { min-height: 104px; line-height: 1.55; resize: vertical; }
.sd-textarea.code { min-height: 180px; font-family: "Cascadia Mono", Consolas, monospace; font-size: 11px; }
.sd-input:focus, .sd-textarea:focus, .sd-select:focus { border-color: var(--sd-jade); box-shadow: 0 0 0 3px rgba(45,123,101,.1); }
.sd-check { display: flex; align-items: flex-start; gap: 9px; color: rgba(23,35,31,.7); font-size: 12px; line-height: 1.45; }
.sd-check input { margin-top: 2px; accent-color: var(--sd-jade); }
.sd-warning { padding: 11px 13px; border-radius: 11px; background: rgba(232,104,74,.1); color: #963f2e; font-size: 11px; line-height: 1.5; }
.sd-preview { padding: 15px; border-radius: 14px; background: var(--sd-night); color: #eef8f3; font-size: 12px; line-height: 1.5; }
.sd-preview strong { display: block; font-family: "Iowan Old Style", serif; font-size: 20px; margin-bottom: 5px; }
.sd-preview ul { margin: 9px 0 0; padding-left: 18px; color: #f2c980; }

.sd-toast { position: fixed; right: 24px; bottom: 24px; z-index: 30; max-width: min(380px, calc(100vw - 48px)); padding: 13px 16px; border-radius: 13px; background: var(--sd-ink); color: #fff; box-shadow: 0 18px 40px rgba(0,0,0,.23); font-size: 12px; line-height: 1.5; animation: sd-in .22s ease-out; }
.sd-toast.error { background: #8b382a; }
.sd-loading { min-height: 420px; display: grid; place-items: center; color: var(--sd-forest); }
.sd-lock { max-width: 560px; margin: 80px auto; padding: 30px; border: 1px solid var(--sd-line); border-radius: 22px; background: var(--sd-cream); text-align: center; }
.sd-lock h2 { font-family: "Iowan Old Style", "Noto Serif SC", serif; color: var(--sd-forest); }
.sd-footer { display: flex; justify-content: space-between; gap: 20px; flex-wrap: wrap; color: rgba(23,35,31,.46); font-size: 10px; margin-top: 22px; padding: 0 4px; }

@keyframes sd-breathe { 50% { transform: scale(1.06); opacity: .75; } }
@keyframes sd-float { 50% { transform: translateY(-9px) rotate(1.2deg); } }
@keyframes sd-think { to { transform: translateY(-6px) rotate(4deg); } }
@keyframes sd-celebrate { 50% { transform: translateY(-14px) rotate(-4deg) scale(1.03); } }
@keyframes sd-spin { to { transform: rotate(360deg); } }
@keyframes sd-in { from { transform: translateY(8px); opacity: 0; } }

@media (max-width: 820px) {
  .sd-root { padding: 16px; }
  .sd-hero { grid-template-columns: 1fr; }
  .sd-stage { min-height: 270px; }
  .sd-hero-copy { padding: 30px 24px; }
  .sd-card, .sd-card.third { grid-column: 1 / -1; }
}

@media (max-width: 520px) {
  .sd-form-row { grid-template-columns: 1fr; }
  .sd-topbar { align-items: flex-start; }
  .sd-ai-badge { max-width: 150px; text-align: left; }
}

@media (prefers-reduced-motion: reduce) {
  .sd-root *, .sd-root *::before, .sd-root *::after { animation-duration: .001ms !important; animation-iteration-count: 1 !important; transition: none !important; }
}
`
