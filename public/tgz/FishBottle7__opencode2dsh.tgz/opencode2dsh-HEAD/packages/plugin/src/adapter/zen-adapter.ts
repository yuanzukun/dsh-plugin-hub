import { createModels, createProvider, type Api, type Context, type Model } from '@earendil-works/pi-ai'
import * as openaiCompletions from '@earendil-works/pi-ai/api/openai-completions'
import * as openaiResponses from '@earendil-works/pi-ai/api/openai-responses'

import { ModelCatalog, ZEN_BASE_URL } from './catalog.ts'
import type { DelegationDelegate } from './delegate.ts'
import { toStreamChunks, type HarnessChunk, type PiDoneMessage, type PiEvent } from './events.ts'
import { deriveRequestIDs, disguiseHeaders } from './ids.ts'
import { ensureFreeLaneShape, ensureResponsesFreeLaneShape, GATE_TOOL_ALIASES, toPiContext, type HarnessGenerateOptions, type PiContext } from './messages.ts'
import { apiForModel, isResponsesModel } from './routing.ts'
export { apiForModel, isResponsesModel } from './routing.ts'
import { routingContext, type RoutingContext } from '../pool/dispatcher.ts'
import { classifyStreamFailure, isRegionBlocked, reportStreamFailure, shouldRotate } from '../pool/rotate.ts'

/**
 * The TS adapter: registers as a DSH LlmAdapter for the `opencode2dsh` route
 * and streams directly from the OpenCode Zen anonymous lane. The wire layer is
 * pi-ai's openai-completions implementation for most models (the same one DSH
 * uses for every OpenAI-compatible provider), plus pi-ai's openai-responses
 * for Responses-only models (muse-spark-*); this module adds the CLI disguise
 * headers, the derived session/request ids, and the free-model catalog.
 *
 * Adapter contract: dsh-llm LlmAdapter (providerInfo/listModels/resolveModel/
 * prepareCall/stream) — structural, no host import.
 */

export const PROVIDER_ID = 'opencode2dsh'

export interface ZenModelInfo {
  id: string
  name: string
  contextWindow: number
  maxTokens: number
}

export interface CatalogLike {
  list(): string[]
  decision(model: string): { allowed: boolean; source: string; known: boolean }
  /**
   * Optional (issue #83): the serving gate for the whitelist. prepareCall/
   * stream consult it BEFORE any wire traffic, so a direct call to an id the
   * whitelist excludes fails fast with a tagged error. Catalogs without the
   * member (structural seam, tests) are unrestricted.
   */
  whitelistAllows?(model: string): boolean
  /**
   * Optional: bounded wait for the first live fetch (issue #45). listModels
   * awaits it so the host's registration-time snapshot is the live roster,
   * never the bootstrap list. Catalogs without it answer immediately from
   * whatever they have.
   */
  warm?(ms?: number): Promise<void>
  reasoningCapability(model: string): { reasoning: boolean; effortValues: string[] } | undefined
  /** Optional: models.dev-declared limits; absent catalogs keep the defaults. */
  limits?(model: string): { contextWindow?: number; maxOutput?: number } | undefined
  /** Optional: models.dev `modalities.input`, the input kinds the model
   *  accepts (["text","image","video",…]). Absent catalogs keep the built-in
   *  vision pattern. */
  modalities?(model: string): string[] | undefined
}

const DEFAULT_CONTEXT_WINDOW = 262144
const DEFAULT_MAX_TOKENS = 32768

/**
 * The #83 serving-gate denial: a direct call to an id the user's whitelist
 * excludes. Distinct and actionable — it names the id and the config field
 * that controls it — and raised BEFORE any wire traffic, so an excluded model
 * never spends anonymous-lane quota. Only the whitelist gates here: probe-
 * pending/blocklisted ids keep today's serving behavior.
 */
export function notInWhitelistError(model: string): Error {
  return new Error(`opencode2dsh: model "${model}" is not in allowedModels; add it to the plugin config (or clear the whitelist) to serve it (issue #83)`)
}

/** The advertised context window: the models.dev declaration when the
 * metadata speaks, the host default otherwise (pending/absent metadata or a
 * model that declares no `limit.context`). */
function contextWindowFor(limits: { contextWindow?: number } | undefined): number {
  const declared = limits?.contextWindow
  return typeof declared === 'number' && Number.isSafeInteger(declared) && declared > 0
    ? declared
    : DEFAULT_CONTEXT_WINDOW
}

/**
 * Use the declared output budget, including models that can answer beyond
 * 32768 tokens. Keep the fallback when metadata cannot provide a valid cap.
 */
function defaultMaxTokensFor(limits: { maxOutput?: number } | undefined): number {
  const declared = limits?.maxOutput
  return typeof declared === 'number' && Number.isSafeInteger(declared) && declared > 0
    ? declared
    : DEFAULT_MAX_TOKENS
}

/**
 * Reasoning-effort vocabulary the adapter owns end to end (dsh-llm treats the
 * ids as opaque: whatever resolveModel advertises comes back on
 * GenerateOptions.reasoningEffort). The ladder mirrors pi-ai's ThinkingLevel
 * so selected levels pass through untouched; `off` is the only id that maps
 * to a different wire spelling.
 */
export const REASONING_EFFORT_LADDER = ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'] as const

/** Levels offered for reasoning models whose metadata declares no ladder. */
const DEFAULT_EFFORT_LADDER: readonly string[] = ['off', 'minimal', 'low', 'medium', 'high']

/** Selectable reasoning effort as dsh-llm's resolveModel contract describes it. */
export interface ZenReasoningEffort {
  id: string
  name: string
  description?: string
}

/**
 * Turn the catalog's models.dev capability into the advertised effort list.
 * A declared ladder (models.dev `reasoning_options` effort values) wins — its
 * values are the upstream-honored spellings, with metadata `none` folded into
 * our `off`. Without a declaration, a reasoning model gets the standard
 * ladder the Zen gateway accepts for every model. Non-reasoning models
 * advertise nothing (the picker then offers only the provider default).
 */
export function reasoningEfforts(capability: { reasoning: boolean; effortValues: string[] } | undefined): ZenReasoningEffort[] | undefined {
  if (!capability?.reasoning) return undefined
  const declared: string[] = []
  for (const value of capability.effortValues) {
    const level = value === 'none' ? 'off' : value
    if ((REASONING_EFFORT_LADDER as readonly string[]).includes(level) && !declared.includes(level)) declared.push(level)
  }
  const levels = declared.length > 0
    ? declared.sort(
        (a, b) =>
          (REASONING_EFFORT_LADDER as readonly string[]).indexOf(a) -
          (REASONING_EFFORT_LADDER as readonly string[]).indexOf(b),
      )
    : DEFAULT_EFFORT_LADDER
  return levels.map((level) => ({ id: level, name: `${level.charAt(0).toUpperCase()}${level.slice(1)}` }))
}

/**
 * The `reasoning_effort` wire value for a selected effort id. The Zen gateway
 * validates the field against `minimal|low|medium|high|xhigh|max|none`
 * (live-probed 2026-09-18: any other value is a hard 400), and `none` is the
 * only spelling that stops the always-think free models from thinking — a
 * mere omission keeps the provider default. So `off` maps to wire `none`,
 * ladder levels pass through verbatim, and unknown ids (never advertised)
 * inject nothing rather than risk the 400.
 */
export function reasoningEffortWire(id: string | undefined): string | undefined {
  if (id === undefined) return undefined
  if (id === 'off') return 'none'
  return (REASONING_EFFORT_LADDER as readonly string[]).includes(id) ? id : undefined
}

/** Anonymous credential: the literal upstream accepts for the free lane. */
const ANONYMOUS_KEY = 'public'

/**
 * Retry policy the host (dsh-llm-retry) runs for this provider. Resolved
 * shape is FLAT (backoff fields at top level — see ResolvedNormalRetryPolicy,
 * dsh-llm index.js:1867 consumes the adapter value verbatim). Retryable codes
 * mirror the host default set so behavior differs only in patience, not in
 * which failures qualify. Cumulative worst case per step:
 * 1+2+4+8+16+20+20+20 ≈ 91s of silent retries before the error surfaces.
 */
export const FREE_LANE_RETRY_POLICY = Object.freeze({
  mode: 'normal' as const,
  maxRetries: 8,
  retryableCodes: Object.freeze(['EMPTY_RESPONSE', 'RATE_LIMIT', 'SERVER', 'TIMEOUT', 'TRANSPORT']),
  initialDelayMs: 1_000,
  maxDelayMs: 20_000,
  jitterRatio: 0.2,
})

/**
 * Stream-liveness watchdogs (live-observed 2026-09-07): neither fetch nor
 * pi-ai owns a body-silence timeout, so a tunnel that stands but never
 * streams hangs the turn forever (70 minutes observed). Both messages
 * carry "timeout" so classifyStreamFailure maps them to 'transport' and
 * the rotate loop gets to move the session to a live exit.
 */
export const WATCHDOG_FIRST_MESSAGE = 'opencode2dsh: first stream event timeout (exit silent before any response)'
export const WATCHDOG_IDLE_MESSAGE = 'opencode2dsh: stream body idle timeout (exit went silent mid-response)'

/** Default watchdog windows (docs/ip-pool.md; test-injectable via constructor). */
export const DEFAULT_FIRST_EVENT_MS = 30_000
export const DEFAULT_BODY_IDLE_MS = 120_000
/**
 * Body-idle window for Responses models (muse-spark-*, issue #7): their
 * chain-of-thought streams pace in bursts with long mid-stream pauses, so
 * the chat default misreads slow reasoning as a dead tunnel. Named and
 * constructor-injectable so tests can exercise the wider window without
 * waiting out five real minutes.
 */
export const RESPONSES_BODY_IDLE_MS = 300_000

/** The terminal error event pi-ai owes but never sent (watchdog teardown). */
function terminalErrorEvent(errorMessage: string, model: Model<Api>): PiEvent {
  return {
    type: 'error',
    error: {
      api: model.api ?? 'openai-completions',
      provider: PROVIDER_ID,
      model: model.id,
      content: [],
      stopReason: 'error',
      errorMessage,
      usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0 },
    },
  }
}

/**
 * Responses-only models on Zen (issue #7): `muse-spark-*` return a bare 500
 * on `POST /zen/v1/chat/completions` but 200 on `POST /zen/v1/responses`
 * (opencode #44659/#44847, DSH #3957). Route by model id; extend this list
 * if Zen moves more models (candidates: gpt-5.6-luna, grok-4.6).
 *
 * Issue #56 (2026-10-09): the gate added a canonical-session-header half on
 * BOTH surfaces (adapter/messages.ts has the probed matrix); the official CLI
 * v2 also calls /inference/openai directly for chat, but /zen/v1 stays the
 * lane of record for this adapter — it answers 200 with the recipe and keeps
 * `Bearer public` valid, which the inference surface 401s.
 */


/**
 * Vision gate: whether a model accepts image input on the Zen lane.
 *
 * models.dev `modalities.input` decides whenever it speaks — the same
 * declaration that already drives `limit.context` / `limit.output` lists the
 * input kinds each model takes, and the free roster rotates constantly, so a
 * family-scoped pattern cannot track it: space-bunny-free,
 * muse-spark-1.*-contributor-free, mimo-v2.5-free, fledge-alpha-free and
 * longcat-2.5-preview-free all declare `image` upstream and are refused today
 * with `Model "<id>" does not support image input.` A declared text-only model
 * stays refused, so the gate still protects the lane in both directions.
 *
 * The built-in pattern remains the fallback for the ids whose image input was
 * live-verified end-to-end on 2026-09-28 (the mimo-v2.6 family), so metadata
 * being pending, absent or silent never changes what those models can do.
 * Models that end up text-only make DSH's attachment gates and pi-ai's image
 * downgrade refuse image parts instead of forwarding them to a model that
 * cannot see them.
 */
export function isVisionModel(id: string, declaredModalities?: string[]): boolean {
  if (Array.isArray(declaredModalities) && declaredModalities.length > 0) {
    return declaredModalities.includes('image')
  }
  return /^mimo-v2\.6/i.test(String(id ?? ''))
}

function toPiModel(id: string, reasoning: boolean, limits?: { contextWindow?: number; maxOutput?: number }, declaredModalities?: string[]): Model<Api> {
  return {
    id,
    name: id,
    api: apiForModel(id),
    provider: PROVIDER_ID,
    baseUrl: `${ZEN_BASE_URL.replace(/\/+$/, '')}/v1`,
    // The honest capability flag: gates pi-ai's reasoning_effort branch and
    // keeps developer-role replay suppressed (the Zen lane's compat detects
    // supportsDeveloperRole=false for opencode.ai, so the system slot is
    // unchanged either way). `image` (see isVisionModel) keeps pi-ai's
    // downgradeUnsupportedImages from dropping the image parts toPiContext
    // loads from the attachment store (the Zen gateway accepts image_url
    // data URLs, live-probed 2026-09-23; full round-trip through
    // DSH 0.1.7-rc.2 with mimo-v2.6-flash-free 2026-09-28).
    reasoning,
    // Issue #96: pi-ai's DeepSeek auto-detection (provider === 'deepseek' ||
    // baseUrl contains deepseek.com) matches neither this provider id nor the
    // Zen baseUrl, so its requiresReasoningContentOnAssistantMessages
    // fallback never fires on its own. Declaring it makes pi-ai write an
    // empty reasoning_content on every replayed assistant message that lacks
    // a signature — histories persisted before the signature round-trip
    // existed, and reasoning from lanes that cannot carry one (the local
    // opencode delegate). Upstream only requires the key to be present.
    compat: { requiresReasoningContentOnAssistantMessages: true },
    input: isVisionModel(id, declaredModalities) ? ['text', 'image'] : ['text'],
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    contextWindow: contextWindowFor(limits),
    maxTokens: defaultMaxTokensFor(limits),
  }
}

function normalizeResponsesEffort(value: string | undefined): string | undefined {
  if (!value || value === 'off' || value === 'none') return undefined
  return (REASONING_EFFORT_LADDER as readonly string[]).includes(value) ? value : undefined
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/** Normalize pi-ai's mixed reasoning shapes before a Responses request. */
export function normalizeResponsesPayload(payload: unknown, requestedEffort?: string): unknown | undefined {
  const shaped = ensureFreeLaneShape(payload)
  const base = shaped ?? payload
  if (!isRecord(base)) return shaped

  const next = { ...base }
  const legacyEffort = typeof next.reasoning_effort === 'string' ? next.reasoning_effort : undefined
  delete next.reasoning_effort

  const reasoning = isRecord(next.reasoning) ? { ...next.reasoning } : {}
  const existingEffort = normalizeResponsesEffort(typeof reasoning.effort === 'string' ? reasoning.effort : undefined)
  const effort = normalizeResponsesEffort(requestedEffort) ?? existingEffort ?? normalizeResponsesEffort(legacyEffort)
  if (effort) reasoning.effort = effort
  else delete reasoning.effort

  if (Object.keys(reasoning).length > 0) next.reasoning = reasoning
  else delete next.reasoning
  return next
}

/**
 * Sibling anonymous-lane host for a configured base URL: `/inference` <-> `/zen`.
 * A base URL carrying neither segment (a custom mirror) falls back to
 * `/inference`, the host the official CLI uses (see #75).
 */
function siblingZenBaseUrl(baseUrl: string): string | null {
  const trimmed = baseUrl.replace(/\/+$/, '')
  const sibling = trimmed.includes('/inference')
    ? trimmed.replace('/inference', '/zen')
    : trimmed.includes('/zen')
      ? trimmed.replace('/zen', '/inference')
      : 'https://opencode.ai/inference'
  const candidate = `${sibling}/v1`
  return candidate === `${trimmed}/v1` ? null : candidate
}

/**
 * True when an anonymous-lane failure is the FreeTierError credential gate
 * (issue #76) — the only refusal class delegation can rescue. Mirrors events.ts
 * classifyError's FREE_TIER_RESTRICTED spelling. Deliberately NOT RegionError:
 * a region block is a different refusal that re-running through a local runtime
 * with the same identity would not lift.
 */
export function isFreeTierRefusal(errorMessage: string): boolean {
  return /\bFreeTierError\b|free tier can only be used from within opencode/i.test(errorMessage)
}

/**
 * The stream surface the adapter needs from a transport. Both a raw pi-ai
 * provider and its Models wrapper satisfy this structurally; the adapter's
 * unit tests inject a scripted object through the same seam (providerOverride).
 */
interface StreamTransport {
  streamSimple(model: unknown, context: unknown, options: unknown): unknown
}

/**
 * Wrap a freshly built pi-ai provider in the Models entry point (#77).
 *
 * pi-ai 0.86.0 narrowed the provider-facing API to a normalized
 * TranscriptContext: tool declarations now ride the leading system message's
 * `toolsAdded` field, and `context.tools` is folded into it ONLY by the
 * Models entry points (0.87.1 dist/models.js:393 `streamSimple` ->
 * `normalizeContext`; dist/utils/transcript.js:23-27,195-203). A DSH profile
 * (`nodeLinker: hoisted`) resolves ONE pi-ai copy for the whole profile —
 * 0.87.1 today — so the adapter's raw `provider.streamSimple(model, context)`
 * call silently dropped every host tool: the wire carried only the injected
 * free-lane gate stubs, with `tool_choice: "none"` as the tell.
 *
 * On 0.82.x the Models wrapper is a pass-through — `streamSimple` hands the
 * context to the provider untouched (0.82.1 dist/models.js:273-279) and the
 * transport reads `context.tools` itself (0.82.1
 * dist/api/openai-completions.js:543-545). Routing through Models is
 * therefore the one code path that preserves host tools on BOTH resolutions.
 * Narrowing our semver range could not help: the hoisted copy is decided by
 * the whole profile, not by this plugin (#40).
 */
function modelsTransport(provider: unknown): StreamTransport {
  const models = createModels()
  models.setProvider(provider as never)
  return models as unknown as StreamTransport
}

export class ZenAdapter {
  readonly #catalog: CatalogLike
  readonly #provider: StreamTransport
  readonly #responsesProvider: StreamTransport | null
  readonly #firstEventMs: number
  readonly #bodyIdleMs: number
  readonly #responsesBodyIdleMs: number
  /** Sibling host for one replay of a refused attempt; null when there is none. */
  readonly #siblingBaseUrl: string | null
  /**
   * Optional local-opencode delegate (issue #76). Armed only when the user
   * opts in via `delegation.enabled`; null/undefined keeps the anonymous path
   * byte-for-byte unchanged.
   */
  readonly #delegate: DelegationDelegate | null

  constructor(catalog: CatalogLike, options: {
    zenBaseUrl?: string
    providerOverride?: unknown
    /** Watchdog windows (tests inject short ones; defaults are live-tuned). */
    firstEventMs?: number
    bodyIdleMs?: number
    /** Overrides RESPONSES_BODY_IDLE_MS (watchdog tests inject short ones). */
    responsesBodyIdleMs?: number
    /** Local-opencode delegate for the persistent FreeTierError fallback. */
    delegate?: DelegationDelegate | null
  } = {}) {
    this.#catalog = catalog
    this.#firstEventMs = options.firstEventMs ?? DEFAULT_FIRST_EVENT_MS
    this.#bodyIdleMs = options.bodyIdleMs ?? DEFAULT_BODY_IDLE_MS
    this.#responsesBodyIdleMs = options.responsesBodyIdleMs ?? RESPONSES_BODY_IDLE_MS
    this.#siblingBaseUrl = siblingZenBaseUrl(options.zenBaseUrl ?? ZEN_BASE_URL)
    this.#delegate = options.delegate ?? null
    if (options.providerOverride !== undefined) {
      this.#provider = options.providerOverride as never
      this.#responsesProvider = null
      return
    }
    const baseUrl = `${(options.zenBaseUrl ?? ZEN_BASE_URL).replace(/\/+$/, '')}/v1`
    const auth = {
      apiKey: {
        name: 'OpenCode Zen anonymous lane',
        resolve: async () => ({ auth: { apiKey: ANONYMOUS_KEY } }),
      },
    }
    this.#provider = modelsTransport(createProvider<Api>({
      id: PROVIDER_ID,
      name: PROVIDER_ID,
      baseUrl,
      auth,
      models: [],
      api: openaiCompletions,
    }))
    this.#responsesProvider = modelsTransport(createProvider<Api>({
      id: PROVIDER_ID,
      name: PROVIDER_ID,
      baseUrl,
      auth,
      models: [],
      api: openaiResponses,
    }))
  }

  providerInfo(provider: string): { id: string; name: string } {
    return { id: provider, name: PROVIDER_ID }
  }

  /**
   * Provider-owned retry policy (dsh-llm calls this unconditionally at
   * registration, index.js:1208). The anonymous free lane 429s in bursts —
   * live-probed 2026-10-09 (issue #51): 5/8 immediate failures on
   * step-5-preview-free, with contention windows that outlast the host
   * default (5 retries over ~15s), so transient throttling surfaced as
   * user-visible errors. This policy stretches the silent absorption window
   * to ~90s per step (8 retries, 1s→20s backoff, wider jitter). Retryable
   * codes mirror the host default set; deterministic failures (AUTH,
   * REGION_BLOCKED, INVALID_REQUEST) stay non-retryable.
   */
  providerRetryPolicy(_provider: string): typeof FREE_LANE_RETRY_POLICY {
    return FREE_LANE_RETRY_POLICY
  }

  /** No image pricing for the free Zen lane. */
  imageRequestPricing(_provider: string, _model: string): undefined {
    return undefined
  }

  /** The input kinds DSH is told about for one model (isVisionModel). */
  #inputModalities(model: string): string[] {
    return isVisionModel(model, this.#catalog.modalities?.(model)) ? ['text', 'image'] : ['text']
  }

  /**
   * Advisory catalog for the DSH model picker (deduped; dsh-llm rejects
   * duplicates). Async on purpose (issue #45): the host awaits this call and
   * caches its answer per host generation, so the first read waits —
   * bounded, inside the catalog — for the live Zen fetch instead of handing
   * the host the staticFreeModels bootstrap list it would then keep showing.
   */
  async listModels(provider: string): Promise<Array<{ provider: string; id: string; name: string; inputModalities: string[] }>> {
    await this.#catalog.warm?.()
    const seen = new Set<string>()
    const models: Array<{ provider: string; id: string; name: string; inputModalities: string[] }> = []
    for (const id of this.#catalog.list()) {
      if (seen.has(id)) continue
      seen.add(id)
      models.push({ provider, id, name: id, inputModalities: this.#inputModalities(id) })
    }
    return models
  }

  resolveModel(provider: string, model: string): {
    provider: string
    id: string
    name: string
    inputModalities: string[]
    context: { contextWindow: number }
    defaultMaxTokens: number
    reasoning?: { efforts: ZenReasoningEffort[] }
  } {
    const resolved: ReturnType<ZenAdapter['resolveModel']> = {
      provider,
      id: model,
      name: model,
      inputModalities: this.#inputModalities(model),
      context: { contextWindow: contextWindowFor(this.#catalog.limits?.(model)) },
      defaultMaxTokens: defaultMaxTokensFor(this.#catalog.limits?.(model)),
    }
    // The thinking-level picker: dsh-llm validates every selected id against
    // this list and echoes the choice back on GenerateOptions.reasoningEffort.
    const declaredEfforts = reasoningEfforts(this.#catalog.reasoningCapability(model))
    const efforts = isResponsesModel(model) ? declaredEfforts?.filter((effort) => effort.id !== 'off') : declaredEfforts
    if (efforts) resolved.reasoning = { efforts }
    return resolved
  }

  /** The #83 whitelist as a serving gate: catalogs without the member are
   * unrestricted (the structural seam keeps legacy fakes/hosts working). */
  #whitelistBlocks(model: string): boolean {
    return this.#catalog.whitelistAllows?.(model) === false
  }

  async prepareCall(provider: string, model: string, _signal?: AbortSignal): Promise<{
    model: ReturnType<ZenAdapter['resolveModel']>
    stream: (options: HarnessGenerateOptions) => AsyncGenerator<HarnessChunk>
  }> {
    if (this.#whitelistBlocks(model)) throw notInWhitelistError(model)
    return {
      model: this.resolveModel(provider, model),
      stream: (options) => this.stream(options),
    }
  }

  /**
   * Recover once from a reasoning-only output limit on models that offer Off.
   * Keep the first attempt's reasoning visible, but withhold its terminal
   * chunks until recovery finishes. Answer/tool events forbid replay; retry
   * blocks get fresh indices and the final usage includes both requests.
   */
  async *stream(options: HarnessGenerateOptions): AsyncGenerator<HarnessChunk> {
    // Issue #83 serving gate: same contract as prepareCall — a direct call to
    // an id the whitelist excludes fails fast, before any wire traffic, on
    // BOTH seams. ONLY the whitelist gates here; probe-pending/blocklisted
    // ids keep today's serving behavior (upstream decides).
    if (this.#whitelistBlocks(options.model)) throw notInWhitelistError(options.model)
    const selectedEffort = options.reasoningEffort ?? options.reasoning
    const canDisableThinking = selectedEffort !== 'off' && selectedEffort !== 'none'
      && this.resolveModel(options.provider, options.model).reasoning?.efforts.some((effort) => effort.id === 'off') === true
    let request = options
    let indexOffset = 0
    let nextIndex = 0
    let priorUsage: Extract<HarnessChunk, { type: 'usage' }>['usage'] | undefined

    for (let attempt = 0; attempt < 2; attempt += 1) {
      let sawReasoning = false
      let sawAnswerOrTool = false
      let usage: Extract<HarnessChunk, { type: 'usage' }> | undefined
      let finish: Extract<HarnessChunk, { type: 'finish' }> | undefined

      for await (const chunk of this.#streamAttempt(request, (message) => {
        for (const block of message.content) {
          if (block.type === 'thinking' && typeof block.thinking === 'string' && block.thinking.length > 0) sawReasoning = true
          if (block.type !== 'thinking' && (block.type !== 'text' || (typeof block.text === 'string' && block.text.length > 0))) sawAnswerOrTool = true
        }
      })) {
        if (chunk.type === 'usage') {
          usage = chunk
          continue
        }
        if (chunk.type === 'finish') {
          finish = chunk
          continue
        }
        if (chunk.type === 'reasoning-delta' && chunk.text.length > 0) sawReasoning = true
        if (chunk.type === 'text-delta' && chunk.text.length > 0) sawAnswerOrTool = true
        if ((chunk.type === 'block-start' && chunk.blockType === 'tool-call') || chunk.type === 'tool-call-delta') sawAnswerOrTool = true
        if (chunk.type === 'block-end') {
          if (chunk.block.type === 'reasoning' && chunk.block.text.length > 0) sawReasoning = true
          if (chunk.block.type === 'tool-call' || (chunk.block.type === 'text' && chunk.block.text.length > 0)) sawAnswerOrTool = true
        }
        if (typeof chunk.index === 'number') nextIndex = Math.max(nextIndex, chunk.index + indexOffset + 1)
        yield indexOffset === 0 ? chunk : { ...chunk, index: chunk.index + indexOffset }
      }

      const recover = attempt === 0 && canDisableThinking && sawReasoning && !sawAnswerOrTool
        && finish?.reason.kind === 'max-tokens' && !options.signal?.aborted
      if (recover) {
        priorUsage = usage?.usage
        indexOffset = nextIndex
        request = { ...options, reasoningEffort: 'off', reasoning: 'off' }
        continue
      }
      if (usage || priorUsage) {
        const current = usage?.usage
        const cacheReadTokens = (priorUsage?.cacheReadTokens ?? 0) + (current?.cacheReadTokens ?? 0)
        const cacheWriteTokens = (priorUsage?.cacheWriteTokens ?? 0) + (current?.cacheWriteTokens ?? 0)
        yield priorUsage === undefined ? usage! : {
          type: 'usage',
          usage: {
            inputTokens: priorUsage.inputTokens + (current?.inputTokens ?? 0),
            outputTokens: priorUsage.outputTokens + (current?.outputTokens ?? 0),
            ...(cacheReadTokens > 0 ? { cacheReadTokens } : {}),
            ...(cacheWriteTokens > 0 ? { cacheWriteTokens } : {}),
          },
        }
      }
      if (finish) yield finish
      return
    }
  }

  /**
   * Run the turn through the local-opencode delegate, all-or-nothing. Returns
   * the complete chunk stream on success, or null when the delegate is not
   * usable (no credential), declines, or fails — in which case the caller falls
   * back to the anonymous lane's honest error. The result is buffered before
   * returning so a partial delegate stream can never leak to the caller.
   */
  async #runDelegation(options: HarnessGenerateOptions, context: PiContext): Promise<HarnessChunk[] | null> {
    const delegate = this.#delegate
    if (!delegate) return null
    try {
      if (!(await delegate.ready())) return null
      const chunks: HarnessChunk[] = []
      for await (const chunk of delegate.stream(options, context)) chunks.push(chunk)
      return chunks
    } catch {
      // The delegate logs its own progress/errors via its log sink; from the
      // adapter's perspective a failed delegation simply means "fall back".
      return null
    }
  }

  /** Stream one attempt from the Zen anonymous lane.
   *
   * IP-7 rotate loop (docs/ip-pool.md §3.4 / §8.1): a stream that dies
   * BEFORE any content landed restarts on a fresh exit — the pool's health
   * marks already degraded the failed exit, so the restarted pick routes
   * elsewhere, and the host's retry budget never sees the intermediate
   * error. Once ANY content event has flowed, rotation stops (§3.4: a
   * partially delivered stream is never replayed). No pool running (or the
   * failure is not exit-shaped) = the original stream surface untouched.
   */
  async *#streamAttempt(options: HarnessGenerateOptions, onTerminal?: (message: PiDoneMessage) => void): AsyncGenerator<HarnessChunk> {
    const context = await toPiContext(options)
    const ids = deriveRequestIDs(options.messages)
    const model = toPiModel(options.model, this.#catalog.reasoningCapability(options.model)?.reasoning === true, this.#catalog.limits?.(options.model), this.#catalog.modalities?.(options.model))
    // IP-pool routing context (docs/ip-pool.md 3.3): pi-ai builds the request
    // body and dispatches it on separate layers with no channel for "which
    // model is this fetch for", so the per-request context rides AsyncLocalStorage.
    const contextStore: RoutingContext = { model: options.model, session: ids.session }
    const self = this
    const MAX_ROTATES = 3
    // Watchdog windows (live-observed 2026-09-07): the OpenAI SDK timeout
    // only covers time-to-response-headers — once headers arrive it clears
    // its timer and NOTHING on any layer owns body silence. FIRST_EVENT: no
    // pi-ai event at all (not even `start`, which only arrives after
    // response headers). BODY_IDLE: content flowing, then a long gap (LLM
    // streams may pace slowly, but minutes of nothing mid-stream is a dead
    // tunnel, not pacing). The race fires the watchdog INTO the pending
    // next() — a background return() could never cancel one (it queues
    // behind the pending request), so timeout-promise racing is the only
    // mechanism that actually interrupts a hung stream.
    const firstEventMs = this.#firstEventMs
    // Responses models (muse-spark-*) get RESPONSES_BODY_IDLE_MS (see the
    // constant); chat models keep the live-tuned default. Derived from
    // model.api — the same routing flag that picked the provider — so the
    // watchdog and the wire layer can never disagree.
    const bodyIdleMs = model.api === 'openai-responses'
      ? Math.max(this.#bodyIdleMs, this.#responsesBodyIdleMs)
      : this.#bodyIdleMs
    const rotateStory: string[] = []
    for (let attempt = 0; ; attempt += 1) {
      const events = routingContext.run(contextStore, () =>
        self.#eventsFor(options, context, ids, model, attempt),
      ) as AsyncIterable<PiEvent>
      let deliveredContent = false
      let preContentFailure: { message: string } | null = null
      const buffered: PiEvent[] = []
      const source = events[Symbol.asyncIterator]()
      // Peek events until the stream proves itself one way or the other:
      // content -> flush and stream through; error before content -> maybe
      // rotate. Content flushes IMMEDIATELY (only the pre-content events are
      // buffered): holding every token hostage to a failure that may never
      // come would also kill streaming for the UI.
      let flushed = false
      let sawAnyEvent = false
      let lastEventAt = Date.now()
      // One deadline timer at a time, re-armed per pull (a timer per pull
      // would accumulate thousands over a long token stream). While no event
      // has arrived at all, the FIRST-EVENT window applies (stricter — the
      // tunnel/connect stage should answer within seconds); once ANY event
      // has landed (start, or content directly), the looser BODY-IDLE
      // window applies so slow TTFT pacing on healthy exits is not misread
      // as a dead tunnel.
      let deadlineTimer: NodeJS.Timeout | undefined
      const raceDeadline = (): Promise<never> => {
        clearTimeout(deadlineTimer)
        const idleWindow = sawAnyEvent ? bodyIdleMs : firstEventMs
        const message = sawAnyEvent ? WATCHDOG_IDLE_MESSAGE : WATCHDOG_FIRST_MESSAGE
        const ms = Math.max(0, idleWindow - (Date.now() - lastEventAt))
        return new Promise<never>((_, reject) => {
          deadlineTimer = setTimeout(() => reject(new Error(message)), ms)
          deadlineTimer.unref?.()
        })
      }
      // The pump the consumer sees after flush: buffered events first, then
      // the live rest of the stream, through ONE toStreamChunks pass so the
      // done/error terminator is never missing (the pre-fix flush fed it a
      // terminator-less slice and threw "ended without done/error").
      const pumpLive = async function* (): AsyncGenerator<PiEvent> {
        for (const e of buffered) yield e
        for (;;) {
          let next: IteratorResult<PiEvent>
          try {
            next = await Promise.race([source.next(), raceDeadline()])
          } catch (err) {
            // watchdog or foreign teardown tore the stream down mid-content:
            // the consumer already saw partial content, so surface the
            // terminal error honestly and stop — never a hang, never a replay.
            // The dispatcher's sentinel is already disarmed this late (headers
            // landed long ago), so nothing else would ever tell the pool the
            // exit died: without this report it kept its `ok` mark and its low
            // latency, i.e. the front of the next pick, and the same exit could
            // tear down the next stream too. Reuse the pool's transport
            // verdict; no rotation — content already went out (§3.4 never
            // replays a partial stream).
            reportStreamFailure(ids.session, options.model)
            yield terminalErrorEvent(err instanceof Error ? err.message : String(err), model)
            return
          }
          if (next.done) {
            clearTimeout(deadlineTimer)
            return
          }
          const event = next.value as PiEvent
          lastEventAt = Date.now()
          if (event.type === 'error' || event.type === 'done') {
            clearTimeout(deadlineTimer)
            onTerminal?.(event.type === 'done' ? event.message : event.error)
            yield event
            return
          }
          yield event
        }
      }
      // Peek phase (pre-content): pull with the first-event deadline armed.
      for (;;) {
        let next: IteratorResult<PiEvent>
        try {
          next = await Promise.race([source.next(), raceDeadline()])
        } catch (err) {
          // pre-content silence: synthesize the terminal error pi-ai never
          // delivered so the rotate decision sees a transport failure
          preContentFailure = { message: err instanceof Error ? err.message : String(err) }
          buffered.push(terminalErrorEvent(preContentFailure.message, model))
          break
        }
        if (next.done) break
        const event = next.value as PiEvent
        lastEventAt = Date.now()
        sawAnyEvent = true
        if (event.type === 'error') {
          onTerminal?.(event.error)
          preContentFailure = { message: event.error.errorMessage ?? 'pi-ai stream error' }
          // the event still flows to the consumer unless we rotate
          buffered.push(event)
          break
        }
        if (event.type === 'done') {
          onTerminal?.(event.message)
          // pi-ai can also deliver the failure on done (stopReason: error)
          if (event.message.stopReason === 'error' && !deliveredContent) {
            preContentFailure = { message: event.message.errorMessage ?? 'pi-ai stream error' }
          }
          buffered.push(event)
          break
        }
        buffered.push(event)
        if (event.type !== 'start') deliveredContent = true
        if (deliveredContent) {
          // first content event: flush everything buffered and go live
          flushed = true
          break
        }
      }
      // peek phase over: whatever path exited the loop, this attempt's
      // deadline timer is spent (pumpLive re-arms its own per pull)
      clearTimeout(deadlineTimer)
      if (preContentFailure === null && deliveredContent) {
        yield* toStreamChunks(pumpLive(), GATE_TOOL_ALIASES)
        return
      }
      if (preContentFailure === null && !deliveredContent) {
        // stream ended cleanly with no content and no error: pass through
        // (pi-ai's empty-response classification owns this case)
        yield* toStreamChunks((async function* pumped() { for (const e of buffered) yield e })(), GATE_TOOL_ALIASES)
        return
      }
      // Exit-shaped failure before content: ask the pool whether rotating is
      // worth another attempt; otherwise surface the buffered events as-is.
      const failureMessage = (preContentFailure as { message: string }).message
      const failure = classifyStreamFailure(failureMessage)
      const deterministic = isRegionBlocked(failureMessage)
      // One pool-less replay on the sibling host when the lane refuses before any
      // content has reached the user; the pool delegate is otherwise the only thing
      // that can make this true.
      const rotate = failure !== null
        && attempt < MAX_ROTATES
        && (shouldRotate(failure, options.model, ids.session, attempt + 1, deterministic)
          || (failure === 'refused' && attempt < 1))
      rotateStory.push(`#${attempt + 1} ${failure ?? 'unknown'}: ${failureMessage.slice(0, 80)}`)
      if (!rotate) {
        // Persistent anonymous-lane refusal (issue #76): when the direct attempt
        // AND the sibling replay both 403'd with the FreeTierError credential
        // gate, and the user opted into delegation, run the turn through the
        // local opencode runtime instead of surfacing the error. Any other
        // failure class, a disabled delegate, a missing credential, or a failed
        // delegation all fall through to the honest error below.
        if (this.#delegate !== null && attempt >= 1 && isFreeTierRefusal(failureMessage)) {
          const delegated = await this.#runDelegation(options, context)
          if (delegated !== null) {
            for (const chunk of delegated) yield chunk
            return
          }
        }
        // last resort: rewrite the terminal error to tell the whole story
        // (the user saw minutes of silence — the surfaced error must say
        // what was tried, not just the last attempt's failure)
        for (let i = 0; i < buffered.length; i += 1) {
          const e = buffered[i] as PiEvent & { error?: { errorMessage?: string }; message?: { errorMessage?: string; stopReason?: string } }
          if (e.type === 'error' && e.error) {
            e.error.errorMessage = rotateStory.length > 1
              ? `${e.error.errorMessage} (opencode2dsh 轮换 ${rotateStory.length - 1} 次后放弃: ${rotateStory.join(' -> ')})`
              : e.error.errorMessage
            break
          }
          if (e.type === 'done' && e.message?.stopReason === 'error') {
            e.message.errorMessage = rotateStory.length > 1
              ? `${e.message.errorMessage} (opencode2dsh 轮换 ${rotateStory.length - 1} 次后放弃: ${rotateStory.join(' -> ')})`
              : e.message.errorMessage!
            break
          }
        }
        yield* toStreamChunks((async function* pumped() { for (const e of buffered) yield e })(), GATE_TOOL_ALIASES)
        return
      }
      // rotate: loop re-runs #eventsFor inside the same ALS store; the pool
      // has already degraded the failed exit, so pick lands elsewhere.
    }
  }

  #eventsFor(
    options: HarnessGenerateOptions,
    context: PiContext,
    ids: ReturnType<typeof deriveRequestIDs>,
    model: ReturnType<typeof toPiModel>,
    attempt = 0,
  ): unknown {
    // Structural boundary: PiContext (own types, unit-tested) -> pi-ai Context.
    const isResponses = model.api === 'openai-responses'
    const requestedReasoning = typeof options.reasoningEffort === 'string'
      ? options.reasoningEffort
      : typeof options.reasoning === 'string'
        ? options.reasoning
        : undefined
    const responseReasoning = isResponses ? normalizeResponsesEffort(requestedReasoning) : undefined
    const effortWire = isResponses ? undefined : reasoningEffortWire(options.reasoningEffort)

    // onPayload injects the free-lane gate tools (adapter/messages.ts) into the
    // serialized body right before dispatch: the anonymous lane 403s a body
    // without the bash+read agent shape, and a host that passes no tools must
    // not leave the injected stubs callable. Host tools now arrive via the
    // context (folded into the transcript by the Models wrapper, #77) and the
    // shaper appends only the gate names the body is missing. The same seam
    // carries the selected reasoning effort: pi-ai has no option with the wire
    // semantics this lane needs (selected off must SEND `none`, not omit), so
    // the effort rides the payload rewrite instead.
    const onPayload =
      isResponses
        ? (payload: unknown): unknown => {
            const normalized = normalizeResponsesPayload(payload, responseReasoning)
            return ensureResponsesFreeLaneShape(normalized ?? payload) ?? normalized
          }
        : effortWire === undefined
        ? ensureFreeLaneShape
        : (payload: unknown): unknown => {
            const shaped = ensureFreeLaneShape(payload)
            if (typeof payload !== 'object' || payload === null || Array.isArray(payload)) return shaped
            return { ...((shaped ?? payload) as Record<string, unknown>), reasoning_effort: effortWire }
          }
    // pi-ai reads the request URL from the model, not from the provider
    // (dist/api/openai-completions.js: `baseURL: model.baseUrl`): a second provider
    // moves nothing, so the sibling replay swaps the model's baseUrl instead.
    const requestModel = attempt % 2 === 1
      && this.#siblingBaseUrl !== null
      && model.baseUrl !== this.#siblingBaseUrl
      ? { ...model, baseUrl: this.#siblingBaseUrl }
      : model
    // Responses-only models (muse-spark-*) must hit /responses, not /chat/completions.
    // Each branch is the Models-wrapped transport (#77); unit tests inject a
    // scripted raw provider through the same override seam.
    const transport = isResponsesModel(model.id) && this.#responsesProvider
      ? this.#responsesProvider
      : this.#provider
    return transport.streamSimple(requestModel, context as unknown as Context, {
      apiKey: ANONYMOUS_KEY,
      sessionId: ids.session,
      headers: disguiseHeaders(ids),
      onPayload,
      signal: options.signal,
      maxRetries: 0,
      temperature: options.temperature,
      maxTokens: options.maxTokens,
      ...(responseReasoning ? { reasoning: responseReasoning } : {}),
    })
  }

  /** Expose the live catalog snapshot for diagnostics. */
  catalogStatus(): { total: number; exposed: number } {
    const list = this.#catalog.list()
    return { total: list.length, exposed: list.length }
  }
}

/** Build the adapter over a live catalog. */
export function createZenAdapter(catalog: ModelCatalog): ZenAdapter {
  return new ZenAdapter(catalog)
}
