/**
 * pi-ai AssistantMessageEvent -> harness StreamChunks. Clean-room port of
 * dsh-llm-pi-ai toStreamChunks (verified against its source, index.js:1342-1452):
 * the chunk stream must end with `usage` then `finish`.
 *
 * `toolNameAlias` (issue #56 seam): inbound wire tool names rewritten before
 * the chunks leave the adapter — e.g. { shell: 'bash' } if a future gate
 * spelling forces the `shell` alias for the host's bash tool. The shipped
 * recipe needs no alias (adapter/messages.ts), so the adapter passes its
 * (empty) GATE_TOOL_ALIASES and names pass through unchanged.
 */

export type HarnessChunk =
  | { type: 'block-start'; index: number; blockType: 'text' | 'reasoning' | 'tool-call' }
  | { type: 'text-delta'; index: number; text: string }
  | { type: 'block-end'; index: number; block: { type: 'text'; text: string } | { type: 'reasoning'; text: string; signature?: string } | { type: 'tool-call'; id: string; name: string; arguments: string } }
  | { type: 'reasoning-delta'; index: number; text: string }
  | { type: 'tool-call-delta'; index: number; id: string; name?: string; argumentsDelta: string }
  | { type: 'usage'; usage: { inputTokens: number; outputTokens: number; cacheReadTokens?: number; cacheWriteTokens?: number } }
  | { type: 'finish'; reason: FinishReason; replayState?: unknown }

export type FinishReason =
  | { kind: 'stop' }
  | { kind: 'max-tokens' }
  | { kind: 'tool-calls' }
  | { kind: 'aborted'; failure: { message: string; code: string } }
  | { kind: 'error'; failure: { message: string; code: string } }

/** pi-ai AssistantMessageEvent vocabulary (subset we consume). */
export type PiEvent =
  | { type: 'start'; partial: PiAssistantPartial }
  | { type: 'text_start'; contentIndex: number; partial: PiAssistantPartial }
  | { type: 'text_delta'; contentIndex: number; delta: string; partial: PiAssistantPartial }
  | { type: 'text_end'; contentIndex: number; content: string; partial: PiAssistantPartial }
  | { type: 'thinking_start'; contentIndex: number; partial: PiAssistantPartial }
  | { type: 'thinking_delta'; contentIndex: number; delta: string; partial: PiAssistantPartial }
  | { type: 'thinking_end'; contentIndex: number; content: string; partial: PiAssistantPartial }
  | { type: 'toolcall_start'; contentIndex: number; partial: PiAssistantPartial }
  | { type: 'toolcall_delta'; contentIndex: number; delta: string; partial: PiAssistantPartial }
  | { type: 'toolcall_end'; contentIndex: number; toolCall: { id: string; name: string; arguments: Record<string, unknown> }; partial: PiAssistantPartial }
  | { type: 'done'; message: PiDoneMessage }
  | { type: 'error'; error: PiDoneMessage }

export interface PiAssistantPartial {
  content: Array<{ type: string; id?: string; name?: string; [key: string]: unknown }>
  [key: string]: unknown
}

/** pi-ai AssistantMessage content block (done/error messages carry these). */
export type PiAssistantBlock = { type: string; [key: string]: unknown }

export interface PiDoneMessage {
  api: string
  provider: string
  model: string
  responseModel?: string
  responseId?: string
  content: PiAssistantBlock[]
  usage: { input: number; output: number; cacheRead: number; cacheWrite: number; totalTokens: number }
  stopReason: 'stop' | 'length' | 'toolUse' | 'error' | 'aborted'
  errorMessage?: string
  [key: string]: unknown
}

import { isStreamTruncation } from './stream-truncation.ts'

const CONTEXT_WINDOW_EXCEEDED = 'CONTEXT_WINDOW_EXCEEDED'
const EMPTY_RESPONSE = 'EMPTY_RESPONSE'
const QUOTA_EXCEEDED = 'QUOTA_EXCEEDED'

function classifyError(text: string): string {
  // Zen uses HTTP 403 for regional availability too. AUTH makes DSH replace
  // the actual upstream message with "API key is invalid".
  if (/\bRegionError\b|not available in your country/i.test(text)) return 'REGION_BLOCKED'
  // This is a client restriction, not a bad credential. Preserve the upstream
  // instruction and keep it outside the host's retryable failures.
  if (/\bFreeTierError\b|free tier can only be used from within OpenCode/i.test(text)) return 'FREE_TIER_RESTRICTED'
  if (/\b(?:401|403)\b/.test(text)) return 'AUTH'
  if (/insufficient|quota|billing/i.test(text)) return QUOTA_EXCEEDED
  if (/\b429\b|rate.?limit/i.test(text)) return 'RATE_LIMIT'
  if (/\b413\b|payload too large|request body too large/i.test(text)) return 'INVALID_REQUEST'
  if (/\b400\b|invalid.?request/i.test(text)) return 'INVALID_REQUEST'
  if (/\b5\d\d\b/.test(text)) return 'SERVER'
  if (/\btime(?:d)?\s*out\b|timeout/i.test(text)) return 'TIMEOUT'
  if (/\b(?:network|connection|socket|fetch)\b|\bECONN[A-Z]+\b|terminated|premature close/i.test(text)) return 'TRANSPORT'
  // Issue #103: pi-ai raises these when the stream dies before its terminal
  // event. The native dsh-llm-pi-ai adapter classifies the same texts as
  // TRANSPORT (its convert.spec.ts:839-855); landing in the UPSTREAM
  // catch-all kept the host's dsh-llm-retry from ever firing. Wording
  // groundings (dist file:line, both pi-ai versions) live in
  // ./stream-truncation.ts.
  if (isStreamTruncation(text)) return 'TRANSPORT'
  return 'UPSTREAM'
}

/**
 * mapStopReason (dsh-llm-pi-ai index.js:1286-1330), with one deliberate
 * divergence (#99): the original classified an error-free `stop` finish as
 * CONTEXT_WINDOW_EXCEEDED whenever usage.input alone exceeded the resolved
 * window (its isContextOverflow). The wire token count runs ~4-5k above the
 * host's history estimate (system prompt + gate tools + serialization), so a
 * history filled to the advertised window reliably tripped the heuristic and
 * fabricated an error out of a turn the upstream had answered. Here a healthy
 * stop is a success at any size; a genuine upstream context refusal arrives
 * as stopReason 'error' and is classified by the message regex below.
 */
function mapStopReason(message: PiDoneMessage): FinishReason {
  if (message.stopReason === 'error' && message.errorMessage !== undefined && /context/i.test(message.errorMessage) && /exceed|window|length|token/i.test(message.errorMessage)) {
    return {
      kind: 'error',
      failure: {
        message: message.errorMessage ?? `pi-ai detected context overflow for model "${message.model}"`,
        code: CONTEXT_WINDOW_EXCEEDED,
      },
    }
  }
  switch (message.stopReason) {
    case 'stop':
      if (message.content.length === 0) {
        return {
          kind: 'error',
          failure: { message: `model "${message.model}" returned a completed response with no content`, code: EMPTY_RESPONSE },
        }
      }
      return { kind: 'stop' }
    case 'length':
      return { kind: 'max-tokens' }
    case 'toolUse':
      return { kind: 'tool-calls' }
    case 'aborted':
      return { kind: 'aborted', failure: { message: message.errorMessage ?? 'pi-ai stream aborted', code: 'ABORTED' } }
    case 'error':
      return {
        kind: 'error',
        failure: { message: message.errorMessage ?? 'pi-ai stream error', code: classifyError(message.errorMessage ?? '') },
      }
  }
}

function mapUsage(usage: PiDoneMessage['usage']): Extract<HarnessChunk, { type: 'usage' }>['usage'] {
  return {
    inputTokens: usage.input,
    outputTokens: usage.output,
    ...(usage.cacheRead > 0 ? { cacheReadTokens: usage.cacheRead } : {}),
    ...(usage.cacheWrite > 0 ? { cacheWriteTokens: usage.cacheWrite } : {}),
  }
}

/**
 * Translate one pi-ai event stream into harness chunks. pi-ai never throws
 * mid-stream: failures arrive as `error` events and become error/aborted
 * finish chunks.
 */
export async function* toStreamChunks(
  events: AsyncIterable<PiEvent>,
  toolNameAlias?: Record<string, string>,
): AsyncGenerator<HarnessChunk> {
  const toolIds = new Map<number, { id: string; name: string }>()
  const mapName = (name: string): string => toolNameAlias?.[name] ?? name
  for await (const event of events) {
    switch (event.type) {
      case 'start':
        break
      case 'text_start':
        yield { type: 'block-start', index: event.contentIndex, blockType: 'text' }
        break
      case 'text_delta':
        yield { type: 'text-delta', index: event.contentIndex, text: event.delta }
        break
      case 'text_end':
        yield { type: 'block-end', index: event.contentIndex, block: { type: 'text', text: event.content } }
        break
      case 'thinking_start':
        yield { type: 'block-start', index: event.contentIndex, blockType: 'reasoning' }
        break
      case 'thinking_delta':
        yield { type: 'reasoning-delta', index: event.contentIndex, text: event.delta }
        break
      case 'thinking_end': {
        // Issue #96: pi-ai records the upstream reasoning field name (the key
        // it will replay the block under, e.g. 'reasoning_content') as the
        // thinking block's thinkingSignature. Carry it on the harness block so
        // the persisted history can hand it back at rebuild time; a replayed
        // assistant message without the field makes thinking-mode upstreams
        // (Zen's DeepSeek) reject the request with a 400.
        const partial = event.partial.content[event.contentIndex]
        const signature = partial?.type === 'thinking' && typeof partial.thinkingSignature === 'string' && partial.thinkingSignature.length > 0
          ? partial.thinkingSignature
          : undefined
        yield {
          type: 'block-end',
          index: event.contentIndex,
          block: { type: 'reasoning', text: event.content, ...(signature !== undefined ? { signature } : {}) },
        }
        break
      }
      case 'toolcall_start': {
        const partial = event.partial.content[event.contentIndex]
        const id = partial?.type === 'toolCall' ? (partial.id ?? '') : ''
        const name = partial?.type === 'toolCall' ? mapName(partial.name ?? '') : ''
        toolIds.set(event.contentIndex, { id, name })
        yield { type: 'block-start', index: event.contentIndex, blockType: 'tool-call' }
        break
      }
      case 'toolcall_delta': {
        const known = toolIds.get(event.contentIndex)
        yield {
          type: 'tool-call-delta',
          index: event.contentIndex,
          id: known?.id ?? '',
          ...(known?.name !== undefined && known.name.length > 0 ? { name: known.name } : {}),
          argumentsDelta: event.delta,
        }
        break
      }
      case 'toolcall_end':
        yield {
          type: 'block-end',
          index: event.contentIndex,
          block: {
            type: 'tool-call',
            id: event.toolCall.id,
            name: mapName(event.toolCall.name),
            arguments: JSON.stringify(event.toolCall.arguments),
          },
        }
        break
      case 'done':
        yield { type: 'usage', usage: mapUsage(event.message.usage) }
        yield { type: 'finish', reason: mapStopReason(event.message) }
        return
      case 'error':
        yield { type: 'usage', usage: mapUsage(event.error.usage) }
        yield { type: 'finish', reason: mapStopReason(event.error) }
        return
    }
  }
  throw new Error('opencode2dsh: pi-ai event stream ended without done/error')
}
