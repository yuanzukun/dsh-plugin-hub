/**
 * 纯函数单元测试。
 *
 * 这些模块不碰网络、不碰进程，只做字符串与路径的算术 —— 但它们决定了
 * 「用户手改配置文件」与「profile 名」这两处最容易被写坏的地方的行为，
 * 所以在 CI 里必须有覆盖。
 *
 * 全部用例把 `DSH_HOME` 指到临时目录，绝不碰真实的 `~/.dsh`。
 */

import assert from 'node:assert/strict'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import test from 'node:test'

const sandbox = mkdtempSync(join(tmpdir(), 'hd-units-'))
process.env.DSH_HOME = sandbox

const { configPath, defaultConfig, publicConfig, readConfig, toFlat, writeConfig } = await import('../lib/config.js')
const { NAME_HINT, dbPathFor, validateProfileName } = await import('../lib/core/profiles.js')
const { findFatal } = await import('../lib/core/daemon.js')
const { findOnPath, normalizePath } = await import('../lib/core/paths.js')
const { IS_WINDOWS, exeName, venvExe } = await import('../lib/core/platform.js')
const { initialStatus, logLine, setPhase } = await import('../lib/core/status.js')

test.after(() => {
	rmSync(sandbox, { recursive: true, force: true })
})

test('defaultConfig 给出一份能直接跑通的默认值', () => {
	const config = defaultConfig()
	assert.equal(config.version, 1)
	assert.equal(config.enabled, true)
	assert.equal(config.autoStart, true)
	assert.equal(config.stopOnExit, true)
	assert.equal(config.apiPort, 9077)
	assert.equal(config.profile, 'coding-agent')
	// 留空表示「由管道按 git 仓库名自动命名」。
	assert.equal(config.bankName, '')
	// 默认走本地 CPU 模型，数据不出机器。
	assert.equal(config.embeddingProvider, 'local')
	assert.equal(config.embeddingModel, 'BAAI/bge-small-en-v1.5')
	assert.equal(config.rerankerProvider, 'local')
	// 默认镜像必须填好，否则国内网络首次安装会卡死。
	assert.match(config.pypiIndex, /^https:/)
	assert.match(config.hfEndpoint, /^https:/)
	// 可执行文件路径默认留空 = 自动探测。
	for (const key of ['uvPath', 'embedPath', 'pgCtlPath', 'pgDataPath']) assert.equal(config[key], '')
	// 每次调用都要是新对象，避免调用方互相污染。
	assert.notEqual(defaultConfig(), config)
	assert.notEqual(defaultConfig().llm, config.llm)
})

test('publicConfig 只回传「密钥是否已设置」，不回传明文', () => {
	const withKey = publicConfig({ ...defaultConfig(), llm: { ...defaultConfig().llm, apiKey: 'sk-secret' } })
	assert.equal(withKey.llm.apiKey, '')
	assert.equal(withKey.llm.apiKeySet, true)
	assert.equal(JSON.stringify(withKey).includes('sk-secret'), false)

	const withoutKey = publicConfig(defaultConfig())
	assert.equal(withoutKey.llm.apiKeySet, false)
	// 其余字段原样透传，前端才能回显表单。
	assert.equal(withoutKey.apiPort, 9077)
})

test('toFlat 把嵌套配置翻成 core 模块用的扁平键名', () => {
	const flat = toFlat({
		...defaultConfig(),
		apiPort: 1234,
		profile: 'work',
		llm: { provider: 'openai', baseUrl: 'https://gw/v1', apiKey: 'k', model: 'm', reasoningEffort: 'low' },
	})
	assert.equal(flat.port, 1234)
	assert.equal(flat.profile, 'work')
	assert.equal(flat.llmBaseUrl, 'https://gw/v1')
	assert.equal(flat.llmApiKey, 'k')
	assert.equal(flat.llmModel, 'm')
	assert.equal(flat.llmReasoningEffort, 'low')
	// 扁平结构里不该再出现嵌套键。
	assert.equal('apiPort' in flat, false)
	assert.equal('llm' in flat, false)
})

test('validateProfileName 挡住路径穿越与奇怪字符', () => {
	assert.equal(validateProfileName('a'), '')
	assert.equal(validateProfileName('work'), '')
	assert.equal(validateProfileName('a.b_c-1'), '')
	assert.equal(validateProfileName('A'.repeat(32)), '')
	// 前后空白先 trim 再判。
	assert.equal(validateProfileName('  ok  '), '')

	assert.equal(validateProfileName(''), '名字不能为空')
	assert.equal(validateProfileName('   '), '名字不能为空')
	assert.equal(validateProfileName(undefined), '名字不能为空')
	assert.equal(validateProfileName('A'.repeat(33)), `名字不合法：${NAME_HINT}`)
	// 首字符必须是字母或数字。
	assert.equal(validateProfileName('.hidden'), `名字不合法：${NAME_HINT}`)
	assert.equal(validateProfileName('-x'), `名字不合法：${NAME_HINT}`)
	// 路径穿越是最要紧的一种。
	assert.equal(validateProfileName('../etc'), `名字不合法：${NAME_HINT}`)
	assert.equal(validateProfileName('a/b'), `名字不合法：${NAME_HINT}`)
	assert.equal(validateProfileName('a b'), `名字不合法：${NAME_HINT}`)
	assert.equal(validateProfileName('记忆'), `名字不合法：${NAME_HINT}`)
})

test('dbPathFor 落在 pg0 的实例目录下', () => {
	const p = dbPathFor('work')
	assert.equal(p.endsWith(join('.pg0', 'instances', 'hindsight-embed-work', 'data')), true)
	// 不同 profile 必须落到不同目录，否则两间仓库会互相覆盖。
	assert.notEqual(dbPathFor('a'), dbPathFor('b'))
})

test('exeName / venvExe 按平台补后缀与目录', () => {
	// 断言的是「与本机平台一致」，这样同一份用例在 Linux CI 上也成立。
	assert.equal(exeName('uv'), IS_WINDOWS ? 'uv.exe' : 'uv')
	const p = venvExe('/tools', 'hindsight-embed', 'python')
	assert.equal(p.includes(join('hindsight-embed', IS_WINDOWS ? 'Scripts' : 'bin')), true)
	// 解释器文件名同样按平台补后缀：Windows 是 python.exe，Linux 是 python。
	assert.equal(p.endsWith(exeName('python')), true)
})

test('normalizePath 把「没填」与「填了空白」都归一成 null', () => {
	assert.equal(normalizePath(''), null)
	assert.equal(normalizePath('   '), null)
	assert.equal(normalizePath(undefined), null)
	assert.equal(normalizePath(null), null)
	assert.equal(normalizePath(123), null)
	assert.equal(normalizePath('  /usr/bin/uv  '), '/usr/bin/uv')
})

test('findOnPath 找不到时返回 null 而不是抛错', () => {
	assert.equal(findOnPath('definitely-not-a-real-binary-xyz'), null)
	// PATH 被清空时也不该炸。
	const saved = process.env.PATH
	process.env.PATH = ''
	try {
		assert.equal(findOnPath('uv'), null)
	} finally {
		process.env.PATH = saved
	}
})

test('findFatal 只认出已知的致命特征串', () => {
	// 判定是大小写敏感的字面包含：上游日志原样输出这些英文串。
	assert.equal(findFatal('ERROR: Address already in use'), 'Address already in use')
	assert.equal(findFatal('LLM API key is required for fact extraction'), 'LLM API key is required')
	assert.equal(findFatal('invalid_api_key'), 'invalid_api_key')
	// 正常启动日志不能被误判成致命错误，否则会被当成启动失败。
	assert.equal(findFatal('INFO: started server on 127.0.0.1:9077'), null)
	assert.equal(findFatal(''), null)
	assert.equal(findFatal(undefined), null)
	assert.equal(findFatal('Loading embedding model BAAI/bge-small-en-v1.5'), null)
})

test('initialStatus 给出一份全新的状态对象', () => {
	const a = initialStatus()
	assert.equal(a.phase, 'idle')
	assert.equal(a.message, '未启动')
	assert.equal(a.detail, '')
	assert.equal(a.pid, null)
	assert.deepEqual(a.logs, [])
	// 两个实例不能共享 logs 数组，否则状态会串。
	a.logs.push('x')
	assert.deepEqual(initialStatus().logs, [])
})

test('logLine 的环形缓冲只保留最近 200 行', () => {
	const status = initialStatus()
	for (let i = 0; i < 250; i += 1) logLine(status, `line-${i}`)
	assert.equal(status.logs.length, 200)
	// 丢掉的是最旧的，留下的是最新的。
	assert.equal(status.logs[0].endsWith('line-50'), true)
	assert.equal(status.logs.at(-1).endsWith('line-249'), true)
	// 每行都带时间戳前缀。
	assert.match(status.logs[0], /^\[\d{2}:\d{2}:\d{2}\] /)
})

test('setPhase 记时间戳并把 detail 并进日志', () => {
	const status = initialStatus()
	setPhase(status, 'starting', '启动中')
	assert.equal(status.phase, 'starting')
	assert.equal(status.message, '启动中')
	assert.equal(status.detail, '')
	assert.equal(status.phaseStartedAt > 0, true)
	assert.equal(status.logs.at(-1).endsWith('启动中'), true)

	setPhase(status, 'error', '启动失败', 'port busy')
	assert.equal(status.detail, 'port busy')
	// 有 detail 时日志里要能同时看到描述与原因。
	assert.equal(status.logs.at(-1).endsWith('启动失败 — port busy'), true)
})

test('配置写入是原子的，读回与原样一致', () => {
	const written = writeConfig({ apiPort: 9999, llm: { model: 'gpt-4o-mini' } })
	assert.equal(written.apiPort, 9999)
	assert.equal(written.llm.model, 'gpt-4o-mini')
	// llm 是局部合并：没传的键保持原值。
	assert.equal(written.llm.provider, 'openai')
	assert.equal(written.llm.reasoningEffort, 'none')

	const read = readConfig()
	assert.equal(read.apiPort, 9999)
	assert.equal(read.llm.model, 'gpt-4o-mini')
	assert.equal(read.version, 1)
})

test('手改坏的配置文件一律回退到默认值，不让插件行为失控', () => {
	// 类型不对：端口是字符串、开关是字符串、profile 是数字。
	writeFileSync(
		configPath(),
		JSON.stringify({ apiPort: 'abc', enabled: 'yes', stopOnExit: 0, profile: 42, llm: 'nope' }),
		'utf8',
	)
	const config = readConfig()
	assert.equal(config.apiPort, 9077)
	assert.equal(config.enabled, true)
	assert.equal(config.stopOnExit, true)
	assert.equal(config.profile, 'coding-agent')
	// llm 整块不是对象时也要退回默认，而不是带上脏值。
	assert.equal(config.llm.provider, 'openai')
	assert.equal(config.llm.baseUrl, '')
})

test('配置文件损坏（非法 JSON）时回到默认值', () => {
	writeFileSync(configPath(), '{ this is not json', 'utf8')
	assert.deepEqual(readConfig(), defaultConfig())
})
