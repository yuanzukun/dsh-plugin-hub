/**
 * 打包与文档的不变量。
 *
 * 这些不是"看看字符串对不对"，而是几个真的会让人装不上的坑：
 *
 *   1. `files` 白名单漏掉入口文件 —— `dsh plugin add` 装出来的包是残的；
 *   2. bundle patch 的 `id` / `name` 与包名对不上 —— 挂不上，或者挂两份；
 *   3. PowerShell 脚本丢了 UTF-8 BOM —— Windows PowerShell 5.1 按 ANSI 解析
 *      中文注释，报 "Missing closing '}'"；
 *   4. README 里的相对链接指向不存在的文件 —— 读者点开是 404。
 */

import assert from 'node:assert/strict'
import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import test from 'node:test'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))

/** 读一个仓库内的文件。 */
function read(relative) {
	return readFileSync(join(root, relative), 'utf8')
}

test('包元数据指向真实存在的入口', () => {
	assert.equal(pkg.type, 'module')
	assert.ok(existsSync(join(root, pkg.main)), `main 指向的 ${pkg.main} 必须存在`)
	assert.ok(existsSync(join(root, pkg.exports['.'].default)), 'exports["."] 的目标必须存在')
	// 浏览器半边由 DSH 的 ModuleLoader 按 exports["./client"] 取，写错就是设置页空白。
	assert.equal(pkg.dsh.client.platform, 'web')
	assert.ok(existsSync(join(root, pkg.exports['./client'].default)), 'exports["./client"] 的目标必须存在')
})

test('files 白名单覆盖所有会被加载的文件', () => {
	const required = ['lib', 'scripts', 'cordis.patch.yml', 'README.md', 'LICENSE']
	for (const entry of required) {
		assert.ok(pkg.files.includes(entry), `files 白名单缺少 ${entry}`)
	}
	// 翻译版 README 也要发出去，否则 npm 页面上的语言切换链接是死的。
	assert.ok(pkg.files.some((entry) => /^README\..+\.md$/.test(entry)), 'files 应包含翻译版 README')
	// 文档随包发出去，README 里的相对链接才不会断。
	for (const wanted of ['CHANGELOG.md', 'CONTRIBUTING.md', 'SECURITY.md', 'docs']) {
		assert.ok(pkg.files.includes(wanted), `files 白名单缺少 ${wanted}`)
	}
	// 测试与 CI 不该进包。
	for (const unwanted of ['tests', '.github']) {
		assert.equal(pkg.files.includes(unwanted), false, `${unwanted} 不该进 npm 包`)
	}
})

test('bundle patch 的 id 与 name 能对上包名', () => {
	const patch = read(pkg.dsh.bundle.patch)
	// 只能有一处 insert，否则 profile 会挂载两份、启动时报 duplicate prefix route。
	const ids = [...patch.matchAll(/^\s*-\s+id:\s*(\S+)\s*$/gm)].map((m) => m[1])
	assert.deepEqual(ids, ['hindsight-daemon'], 'cordis.patch.yml 里应恰好有一个 insert 项')

	// name 必须等于包名：按包名解析才能让 `dsh plugin add` 的版本真正生效。
	const names = [...patch.matchAll(/^\s*name:\s*'([^']+)'\s*$/gm)].map((m) => m[1])
	assert.deepEqual(names, [pkg.name], 'patch 里的 name 必须等于 package.json 的 name')
})

test('PowerShell 脚本保留 UTF-8 BOM 且不被 git 改写', () => {
	// .gitattributes 必须对 ps1 关掉一切转换，否则 BOM 会被 checkout 弄丢。
	assert.match(read('.gitattributes'), /^\*\.ps1\s+-text\s*$/m, '.gitattributes 应对 *.ps1 设 -text')

	const scripts = readdirSync(join(root, 'scripts')).filter((name) => name.endsWith('.ps1'))
	assert.ok(scripts.length > 0, 'scripts/ 下应有 PowerShell 脚本')
	for (const name of scripts) {
		const bytes = readFileSync(join(root, 'scripts', name))
		const bom = bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf
		assert.equal(bom, true, `scripts/${name} 缺少 UTF-8 BOM`)
	}
})

test('README 里的相对链接都指向真实文件', () => {
	const files = readdirSync(root).filter((name) => /^README(\..+)?\.md$/.test(name))
	assert.ok(files.length > 0)

	for (const file of files) {
		const text = read(file)
		const links = [...text.matchAll(/\]\(([^)\s]+)\)/g)].map((m) => m[1])
		for (const link of links) {
			// 外链、锚点、以及带占位符的命令行示例都跳过。
			if (/^(https?:|mailto:|#)/.test(link)) continue
			if (link.includes('<') || link.includes('...')) continue
			const target = join(root, link.split('#')[0])
			assert.ok(existsSync(target), `${file} 里的链接 ${link} 指向不存在的文件`)
		}
	}
})

test('双语文档互相可达', () => {
	const main = read('README.md')
	const zh = read('README.zh-CN.md')
	// 中文版必须能从主 README 点到，反之亦然 —— 否则等于没写。
	assert.match(main, /\[[^\]]+\]\(README\.zh-CN\.md\)/, '英文 README 应链接到中文版')
	assert.match(zh, /\[[^\]]+\]\(README\.md\)/, '中文 README 应链接回英文版')
	for (const doc of ['CONTRIBUTING.md', 'SECURITY.md']) {
		assert.match(main, new RegExp(`\\[[^\\]]+\\]\\(${doc.replace('.', '\\.')}\\)`), `README 应链接到 ${doc}`)
	}
})

test('没有留下已经废弃的文档文件名', () => {
	for (const stale of ['README_EN.md', 'README_CN.md', 'README.en_US.md']) {
		assert.equal(existsSync(join(root, stale)), false, `${stale} 是旧命名，应改名为 README.<locale>.md`)
	}
})
