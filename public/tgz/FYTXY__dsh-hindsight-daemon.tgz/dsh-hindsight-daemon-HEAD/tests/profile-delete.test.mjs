/**
 * 删除仓库（profile）的冒烟测试。
 *
 * 把 HOME 指到临时目录再动态 import，这样 `~/.hindsight` 与 `~/.pg0` 都落在沙箱里，
 * 跑测试不会碰到真实的记忆库。验证四件事：
 *   1. 三处落盘内容（实例目录 / env / 日志）都被删干净；
 *   2. 官方登记表里对应条目被移除，且其他条目与版本号原样保留；
 *   3. 当前在用的仓库被拒绝删除；
 *   4. 非法名字与不存在的仓库给出可读原因。
 */

import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const root = mkdtempSync(join(tmpdir(), 'hd-delete-'))
process.env.USERPROFILE = root
process.env.HOME = root

const { deleteProfile } = await import('../lib/core/profiles.js')

const profilesDir = join(root, '.hindsight', 'profiles')
const instancesDir = join(root, '.pg0', 'instances')
mkdirSync(profilesDir, { recursive: true })
mkdirSync(join(instancesDir, 'hindsight-embed-doomed', 'data'), { recursive: true })
mkdirSync(join(instancesDir, 'hindsight-embed-keeper', 'data'), { recursive: true })

writeFileSync(join(profilesDir, 'doomed.env'), 'HINDSIGHT_API_PORT=9077\n', 'utf8')
writeFileSync(join(profilesDir, 'doomed.log'), 'x'.repeat(2048), 'utf8')
writeFileSync(join(profilesDir, 'metadata.json'), JSON.stringify({
	version: 2,
	profiles: {
		doomed: { created_at: '2026-01-01T00:00:00Z' },
		keeper: { created_at: '2026-01-02T00:00:00Z' },
	},
}), 'utf8')
writeFileSync(join(instancesDir, 'hindsight-embed-doomed', 'data', 'PG_VERSION'), '18\n', 'utf8')
writeFileSync(join(instancesDir, 'hindsight-embed-keeper', 'data', 'PG_VERSION'), '18\n', 'utf8')

/** 记录逐项结果。 */
const failures = []
/**
 * 断言。
 * @param label - 用例名。
 * @param condition - 期望为真的条件。
 */
function check(label, condition) {
	if (condition) {
		console.log(`  ✓ ${label}`)
		return
	}
	failures.push(label)
	console.log(`  ✗ ${label}`)
}

console.log('删除一个普通仓库')
const removed = deleteProfile({ name: 'doomed', currentProfile: 'coding-agent', pgCtl: null })
check('返回 ok', removed.ok === true)
check('实例目录已删', !existsSync(join(instancesDir, 'hindsight-embed-doomed')))
check('env 文件已删', !existsSync(join(profilesDir, 'doomed.env')))
check('日志已删', !existsSync(join(profilesDir, 'doomed.log')))
check('统计到了释放空间', typeof removed.freedBytes === 'number' && removed.freedBytes > 0)

const metadata = JSON.parse(readFileSync(join(profilesDir, 'metadata.json'), 'utf8'))
check('登记表移除了 doomed', metadata.profiles.doomed === undefined)
check('登记表保留了 keeper', metadata.profiles.keeper !== undefined)
check('登记表保留了版本号', metadata.version === 2)
check('其他仓库没被误删', existsSync(join(instancesDir, 'hindsight-embed-keeper')))

console.log('拒绝删除当前正在使用的仓库')
const current = deleteProfile({ name: 'coding-agent', currentProfile: 'coding-agent', pgCtl: null })
check('返回 ok=false', current.ok === false)
check('说明了原因', current.message.includes('当前正在使用'))

console.log('拒绝非法名字')
const illegal = deleteProfile({ name: '../evil', currentProfile: 'coding-agent', pgCtl: null })
check('返回 ok=false', illegal.ok === false)
check('提示了命名规则', illegal.message.includes('字母'))

console.log('不存在的仓库给出可读提示')
const missing = deleteProfile({ name: 'ghost', currentProfile: 'coding-agent', pgCtl: null })
check('返回 ok=false', missing.ok === false)
check('说明不存在', missing.message.includes('不存在'))

rmSync(root, { recursive: true, force: true })

if (failures.length > 0) {
	console.error(`\n失败 ${failures.length} 项：${failures.join('、')}`)
	process.exit(1)
}
console.log('\n全部通过')
