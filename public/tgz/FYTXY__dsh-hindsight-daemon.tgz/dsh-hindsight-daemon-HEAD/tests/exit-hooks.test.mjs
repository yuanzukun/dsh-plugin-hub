/**
 * 退出钩子冒烟测试。
 *
 * 不需要 DSH，也不需要装 daemon：只验证 index.js 的三件事 ——
 * 钩子有没有挂上、disposer 有没有摘干净、清理是否幂等。
 */

import assert from 'node:assert/strict'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'

// 先把 HOME 指到临时目录，再 import 插件：插件在 apply() 时才读配置，
// 但路径模块在导入期就会算 $HOME，所以顺序不能反。
//
// DSH_HOME 必须一起改写。DSH 自己的宿主进程会把它设成真实目录，若不覆盖，
// `config.js` 的 dshHome() 会优先读 DSH_HOME，于是这个测试会读到真实配置
// （enabled/autoStart 均为 true）并真的拉起、再杀掉用户正在用的 daemon。
const home = mkdtempSync(path.join(tmpdir(), 'dsh-hd-smoke-'))
process.env.HOME = home
process.env.USERPROFILE = home
process.env.DSH_HOME = path.join(home, '.dsh')
process.env.DSH_HINDSIGHT_DEBUG = '1'

const cfgDir = path.join(home, '.dsh', 'hindsight-daemon')
mkdirSync(cfgDir, { recursive: true })
writeFileSync(path.join(cfgDir, 'config.json'), JSON.stringify({
	version: 1,
	enabled: true,
	// 关掉自动启动：测试不该真的去拉 daemon。
	autoStart: false,
	stopOnExit: true,
	apiPort: 19077,
	profile: 'smoke',
}))

const mod = await import('../lib/index.js')

assert.equal(typeof mod.apply, 'function', 'apply 必须导出')
assert.equal(mod.name, 'hindsight-daemon', '插件名要对得上 cordis.patch.yml')

/** 假 ctx：插件只用到 logger 与 get 两条通道。 */
const ctx = {
	logger: { info() {}, warn() {}, error() {} },
	get: () => undefined,
}

const SIGNALS = ['SIGTERM', 'SIGINT', 'SIGHUP']
const before = {
	exit: process.listenerCount('exit'),
	...Object.fromEntries(SIGNALS.map((s) => [s, process.listenerCount(s)])),
}

const disposer = mod.apply(ctx)

assert.equal(typeof disposer, 'function', 'apply 必须返回 disposer')
assert.equal(process.listenerCount('exit'), before.exit + 1, 'exit 钩子应 +1')
for (const signal of SIGNALS) {
	assert.equal(process.listenerCount(signal), before[signal] + 1, `${signal} 钩子应 +1`)
}

// disposer 要把自己挂的全摘掉，不能残留。
disposer()

assert.equal(process.listenerCount('exit'), before.exit, 'disposer 后 exit 钩子应复原')
for (const signal of SIGNALS) {
	assert.equal(process.listenerCount(signal), before[signal], `disposer 后 ${signal} 应复原`)
}

// 幂等：再调一次不能抛（DSH 退出路径上 disposer 与 exit 钩子都会进来）。
disposer()

console.log('✔ 钩子注册 / 摘除 / 幂等 全部通过')

const logPath = path.join(home, '.dsh', 'hindsight-daemon', 'debug.log')
assert.ok(existsSync(logPath), 'DSH_HINDSIGHT_DEBUG=1 时应写出 debug.log')
const text = readFileSync(logPath, 'utf8')
assert.match(text, /退出钩子已注册/, 'debug.log 应记录钩子注册')
assert.match(text, /cleanup\(disposer\)/, 'debug.log 应记录 disposer 触发的清理')
console.log('✔ 调试日志落盘正常')

rmSync(home, { recursive: true, force: true })
console.log('全部通过')
