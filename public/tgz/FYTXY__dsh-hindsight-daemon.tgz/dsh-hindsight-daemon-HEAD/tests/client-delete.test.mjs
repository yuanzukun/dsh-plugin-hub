/**
 * 设置页的渲染与交互测试（删除仓库那条链路）。
 *
 * 没有真实浏览器，也没有真实的 React —— 这里用一个最小化的 hooks 实现把
 * `client.js` 真跑一遍，验证的是「点了会怎样」，而不是「字符串里有没有某个词」：
 *   1. 每个仓库后面有「删除」按钮，当前仓库的那个是禁用的；
 *   2. 点「删除」先弹确认框，不会立刻删；
 *   3. 点「取消」什么都不发；点「永久删除」才发出 profile-delete 请求；
 *   4. 宿主回 `{ok:false}` 时要显示错误，而不是假装成功。
 */

import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { runInThisContext } from 'node:vm'

const here = dirname(fileURLToPath(import.meta.url))
const source = readFileSync(join(here, '..', 'lib', 'client.js'), 'utf8')

// ── 最小 hooks 实现 ────────────────────────────────────────────────────
/** 当前正在渲染的组件实例。 */
let currentInstance = null
/** 每个组件实例（按树中的路径区分）的 hook 槽位。 */
const instances = new Map()
/** 是否处于渲染过程中：此时 setState 只能打标记，不能递归重渲染。 */
let rendering = false
/** 渲染期间有 setState 时置位。 */
let needsRender = false
/** 根元素。 */
let rootElement = null
/** 展开后的树。 */
let tree = null
/** 这一轮渲染中出现的组件路径。 */
let usedKeys = new Set()
/** 上一轮渲染中出现的组件路径。 */
let previousKeys = new Set()

/**
 * 取某个路径对应的实例。
 * @param key - 树中路径。
 * @returns 实例对象。
 */
function instanceFor(key) {
	let found = instances.get(key)
	if (found === undefined) {
		found = { hooks: [], cursor: 0 }
		instances.set(key, found)
	}
	return found
}

/**
 * 两个依赖数组是否等价。
 * @param left - 旧依赖。
 * @param right - 新依赖。
 * @returns 是否等价。
 */
function sameDeps(left, right) {
	if (left === undefined || right === undefined) return false
	if (left.length !== right.length) return false
	for (let i = 0; i < left.length; i += 1) {
		if (!Object.is(left[i], right[i])) return false
	}
	return true
}

/**
 * 重新渲染整棵树。
 */
function renderTree() {
	rendering = true
	let guard = 0
	usedKeys = new Set()
	do {
		needsRender = false
		usedKeys = new Set()
		tree = expand(rootElement, 'root')
		guard += 1
	} while (needsRender && guard < 50)
	// 上一轮渲染过、这一轮消失的组件 = 被卸载：跑它们的清理函数。
	for (const key of previousKeys) {
		if (usedKeys.has(key)) continue
		const inst = instances.get(key)
		if (inst === undefined) continue
		for (const hook of inst.hooks) {
			if (hook !== undefined && typeof hook.cleanup === 'function') hook.cleanup()
		}
		instances.delete(key)
	}
	previousKeys = usedKeys
	rendering = false
}

/**
 * 状态变化后请求重渲染。
 */
function scheduleRender() {
	if (rendering) {
		needsRender = true
		return
	}
	renderTree()
}

const FakeReact = {
	/**
	 * 创建元素。
	 * @param type - 标签名或组件函数。
	 * @param props - 属性。
	 * @param children - 子节点。
	 * @returns 元素对象。
	 */
	createElement(type, props, ...children) {
		const flat = []
		/**
		 * 把嵌套的 children 拍平。
		 * @param value - 待处理值。
		 */
		const push = (value) => {
			if (value === null || value === undefined || typeof value === 'boolean') return
			if (Array.isArray(value)) {
				value.forEach(push)
				return
			}
			flat.push(value)
		}
		children.forEach(push)
		return { type, props: { ...(props ?? {}), children: flat } }
	},
	/**
	 * useState。
	 * @param initial - 初值。
	 * @returns `[值, setter]`。
	 */
	useState(initial) {
		const inst = currentInstance
		const index = inst.cursor
		inst.cursor += 1
		if (inst.hooks[index] === undefined) {
			inst.hooks[index] = { value: typeof initial === 'function' ? initial() : initial }
		}
		const slot = inst.hooks[index]
		/**
		 * 更新这个槽位。
		 * @param next - 新值或更新函数。
		 */
		const set = (next) => {
			slot.value = typeof next === 'function' ? next(slot.value) : next
			scheduleRender()
		}
		return [slot.value, set]
	},
	/**
	 * useCallback。
	 * @param fn - 回调。
	 * @param deps - 依赖。
	 * @returns 回调。
	 */
	useCallback(fn, deps) {
		const inst = currentInstance
		const index = inst.cursor
		inst.cursor += 1
		const previous = inst.hooks[index]
		if (previous !== undefined && sameDeps(previous.deps, deps)) return previous.fn
		inst.hooks[index] = { fn, deps }
		return fn
	},
	/**
	 * useEffect：立即执行（等价 useLayoutEffect 语义），够测试用。
	 * @param fn - 副作用。
	 * @param deps - 依赖。
	 */
	useEffect(fn, deps) {
		const inst = currentInstance
		const index = inst.cursor
		inst.cursor += 1
		const previous = inst.hooks[index]
		if (previous !== undefined && sameDeps(previous.deps, deps)) return
		if (previous !== undefined && typeof previous.cleanup === 'function') previous.cleanup()
		const cleanup = fn()
		inst.hooks[index] = { deps, cleanup: typeof cleanup === 'function' ? cleanup : undefined }
	},
	/**
	 * useRef。
	 * @param initial - 初值。
	 * @returns ref 对象。
	 */
	useRef(initial) {
		const inst = currentInstance
		const index = inst.cursor
		inst.cursor += 1
		if (inst.hooks[index] === undefined) inst.hooks[index] = { current: initial }
		return inst.hooks[index]
	},
}

/**
 * 展开一棵元素树：调用函数组件，保留宿主标签。
 * @param node - 元素或文本。
 * @param key - 当前路径。
 * @returns 展开后的节点。
 */
function expand(node, key) {
	if (node === null || node === undefined || typeof node === 'boolean') return null
	if (typeof node === 'string' || typeof node === 'number') return String(node)
	if (Array.isArray(node)) return node.map((child, index) => expand(child, `${key}.${index}`))
	if (typeof node.type === 'function') {
		usedKeys.add(key)
		const inst = instanceFor(key)
		const previous = currentInstance
		currentInstance = inst
		inst.cursor = 0
		let produced
		try {
			produced = node.type(node.props)
		} finally {
			currentInstance = previous
		}
		return expand(produced, key)
	}
	return {
		type: node.type,
		props: { ...node.props, children: expand(node.props.children, `${key}.c`) },
	}
}

/**
 * 遍历展开后的树。
 * @param node - 节点。
 * @param visit - 访问函数。
 */
function walk(node, visit) {
	if (node === null || node === undefined || typeof node === 'string') return
	if (Array.isArray(node)) {
		node.forEach((child) => walk(child, visit))
		return
	}
	visit(node)
	walk(node.props.children, visit)
}

/**
 * 收集节点下的全部文本。
 * @param node - 节点。
 * @returns 拼接后的文本。
 */
function textOf(node) {
	if (node === null || node === undefined || typeof node === 'boolean') return ''
	if (typeof node === 'string') return node
	if (Array.isArray(node)) return node.map(textOf).join('')
	return textOf(node.props.children)
}

/**
 * 所有按钮。
 * @returns 按钮节点数组。
 */
function buttons() {
	const list = []
	walk(tree, (node) => {
		if (node.type === 'button') list.push(node)
	})
	return list
}

/**
 * 按文本找按钮。
 * @param text - 按钮文案。
 * @param enabledOnly - 是否只要可点的。
 * @returns 按钮节点或 undefined。
 */
function findButton(text, enabledOnly = true) {
	return buttons().find(
		(button) => textOf(button) === text && (!enabledOnly || button.props.disabled !== true),
	)
}

// ── 装载插件客户端 ──────────────────────────────────────────────────────
/** 模块加载时交给 factory 的规格。 */
let loaded = null
/** 记录注册过的键盘监听，用来验证 Esc 关闭。 */
const keyListeners = []
globalThis.window = {
	__ModuleLoader__: { load: (spec) => { loaded = spec } },
	addEventListener: (type, handler) => { if (type === 'keydown') keyListeners.push(handler) },
	removeEventListener: (type, handler) => {
		if (type !== 'keydown') return
		const index = keyListeners.indexOf(handler)
		if (index >= 0) keyListeners.splice(index, 1)
	},
}
globalThis.fetch = async () => {
	throw new Error('测试里不应该真的发请求')
}
runInThisContext(source, { filename: 'client.js' })

// react-dom 故意不给：要验证拿不到 portal 时能退回普通渲染。
const moduleExports = loaded.factory((name) => {
	if (name === 'react') return FakeReact
	throw new Error(`unexpected require: ${name}`)
})

/** 捕获注册到设置页的组件。 */
let SectionComponent = null
moduleExports.apply({
	get: () => ({
		inject: (name, factory) => factory(),
		register: (spec, component) => {
			SectionComponent = component
			return () => {}
		},
	}),
	effect: (fn) => fn(),
})

/** 记录所有请求。 */
const requests = []
/** 让宿主返回什么。 */
let hostValue = { ok: true, message: '已删除' }

globalThis.fetch = async (url, init) => {
	const body = typeof init?.body === 'string' ? JSON.parse(init.body) : undefined
	requests.push({ url, body })
	if (url.endsWith('/state')) {
		return { ok: true, json: async () => ({ ok: true, value: snapshot }) }
	}
	if (url.endsWith('/logs')) {
		return { ok: true, json: async () => ({ ok: true, value: { lines: [] } }) }
	}
	return { ok: true, json: async () => ({ ok: true, value: hostValue }) }
}

/** 一份够用的快照。 */
const snapshot = {
	apiVersion: 6,
	phase: 'ready',
	message: '运行中',
	detail: '127.0.0.1:9077',
	logs: [],
	environment: {
		uv: { ready: true, path: 'C:/uv.exe' },
		embed: { ready: true, path: 'C:/hindsight-embed.exe' },
		postgres: { ready: true, pgCtl: 'C:/pg_ctl.exe', dataDir: 'C:/pg/data' },
		check: { ready: true, missing: [] },
	},
	install: null,
	memory: null,
	profiles: {
		profiles: [
			{ name: 'alpha', current: false, dbExists: true, dbSize: 1024, lastUsed: '2026-01-01T00:00:00Z' },
			{ name: 'beta', current: true, dbExists: true, dbSize: 2048, lastUsed: '2026-02-02T00:00:00Z' },
		],
	},
	config: {
		apiPort: 9077,
		profile: 'beta',
		bankName: '',
		embeddingProvider: 'local',
		embeddingModel: 'BAAI/bge-small-en-v1.5',
		rerankerProvider: 'local',
		rerankerModel: 'cross-encoder/ms-marco-MiniLM-L-6-v2',
		pypiIndex: 'https://pypi.tuna.tsinghua.edu.cn/simple',
		hfEndpoint: 'https://hf-mirror.com',
		hfHome: '',
		uvPath: '',
		embedPath: '',
		pgCtlPath: '',
		pgDataPath: '',
		llm: {
			provider: 'openai',
			baseUrl: 'https://api.example.com/v1',
			apiKey: '',
			apiKeySet: true,
			model: 'test-model',
			reasoningEffort: 'none',
		},
	},
}

/**
 * 等异步状态更新落定。
 * @param rounds - 轮数。
 * @returns Promise。
 */
async function settle(rounds = 10) {
	for (let i = 0; i < rounds; i += 1) {
		await new Promise((resolve) => setImmediate(resolve))
	}
}

const failures = []
/**
 * 断言。
 * @param label - 用例名。
 * @param condition - 期望为真的条件。
 */
function check(label, condition) {
	if (condition) {
		console.log(`  ✓ ${label}`)
		return
	}
	failures.push(label)
	console.log(`  ✗ ${label}`)
}

rootElement = { type: SectionComponent, props: { children: [] } }
renderTree()
await settle()

console.log('仓库列表')
const deleteButtons = buttons().filter((button) => textOf(button) === '删除')
check('每个仓库都有删除按钮', deleteButtons.length === 2)
check('当前仓库的删除按钮是禁用的', deleteButtons.filter((b) => b.props.disabled === true).length === 1)
check('非当前仓库有启用按钮', findButton('启用') !== undefined)

console.log('点删除先弹确认框')
findButton('删除').props.onClick()
await settle()
check('出现了确认标题', textOf(tree).includes('删除这个仓库？'))
check('确认按钮文案是「永久删除」', findButton('永久删除') !== undefined)
check('还没发出任何删除请求', requests.every((r) => !r.url.endsWith('/profile-delete')))

console.log('点取消什么都不发')
findButton('取消').props.onClick()
await settle()
check('弹窗已关闭', !textOf(tree).includes('删除这个仓库？'))
check('依然没有删除请求', requests.every((r) => !r.url.endsWith('/profile-delete')))
check('弹窗关闭后解除了键盘监听', keyListeners.length === 0)

console.log('按 Esc 也能关掉')
findButton('删除').props.onClick()
await settle()
check('Esc 监听已挂上', keyListeners.length === 1)
keyListeners[0]({ key: 'Escape' })
await settle()
check('Esc 关闭了弹窗', !textOf(tree).includes('删除这个仓库？'))
check('Esc 关闭后没有删除请求', requests.every((r) => !r.url.endsWith('/profile-delete')))

console.log('确认后发出请求')
findButton('删除').props.onClick()
await settle()
findButton('永久删除').props.onClick()
await settle()
const sent = requests.find((r) => r.url.endsWith('/profile-delete'))
check('发出了 profile-delete 请求', sent !== undefined)
check('请求带上了仓库名', sent?.body?.name === 'alpha')
check('成功后显示提示', textOf(tree).includes('仓库已删除'))

console.log('宿主拒绝时显示错误而不是假装成功')
hostValue = { ok: false, message: '「alpha」是当前正在使用的仓库，请先切换到别的仓库再删除' }
findButton('删除').props.onClick()
await settle()
findButton('永久删除').props.onClick()
await settle()
check('显示了宿主给的原因', textOf(tree).includes('请先切换到别的仓库'))
check('没有显示成功提示', !textOf(tree).includes('仓库已删除'))

process.exit(failures.length > 0 ? 1 : 0)
