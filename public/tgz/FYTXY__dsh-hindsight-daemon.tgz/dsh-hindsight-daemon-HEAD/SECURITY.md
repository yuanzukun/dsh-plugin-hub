# Security Policy

## Reporting a vulnerability

Open a [private security advisory](https://github.com/FYTXY/dsh-hindsight-daemon/security/advisories/new)
or email the maintainer listed in `package.json`. Please do not open a public issue for
anything that could leak a credential or let a local process take over memory storage.

Expect an acknowledgement within a few days. This is a single-maintainer project, so a
fix may take longer; you will get an honest status rather than silence.

## Security boundaries

This plugin runs with the same privileges as your DSH process and manages local
processes and files, so the interesting surfaces are worth stating explicitly.

**What it protects**

- The settings API is gated on the request's `Host` header: only `127.0.0.1`,
  `localhost`, `[::1]`, `::1` and the hosts DSH declares in
  `webRuntime.trustedHosts` are accepted, everything else gets `403`. That is what stops
  a DNS-rebinding page from reading your configuration through the browser.
- The LLM API key is never sent back to the browser. `config.js` replaces it with an
  empty string plus an `apiKeySet` boolean; the settings page renders dots.
- Config writes are atomic (temp file + rename), so a crash mid-write cannot leave a
  half-parsed JSON that would silently fall back to defaults.

**What it does not protect**

- **The API key is stored in plain text** in `<DSH home>/hindsight-daemon/config.json`,
  and in `~/.hindsight/profiles/<profile>.env`. That is a deliberate decision: the
  Hindsight daemon reads it from the env file, and encrypting it would only move the
  key into a file next to the code that decrypts it. Protect it with filesystem
  permissions and do not commit these paths (`.gitignore` already covers the common
  ones).
- **Memory contents are not encrypted.** The embedded PostgreSQL data directory holds
  whatever Hindsight extracted, in the clear. Disk encryption is your responsibility.
- **Everything stays local.** No memory content, prompt, or transcript leaves the
  machine — the only outbound traffic is to the LLM endpoint *you* configure (used for
  fact extraction) and to the PyPI/HuggingFace mirrors during dependency installation.

**Process control**

The plugin stops processes by PID (looked up by listening port) and by name
(`hindsight-embed.exe` / `pkill -f hindsight-embed`). The name-based path is the blunt
one: it will stop any process matching that pattern, not only the daemon this plugin
started. It only runs during shutdown, and only when `stopOnExit` is enabled.

## Supported versions

The latest released minor version receives fixes. This plugin is pre-1.0, so a fix
may land as a minor bump with a documented behaviour change in
[CHANGELOG.md](CHANGELOG.md); pin an exact version if you need stability.
