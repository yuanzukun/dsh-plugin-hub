#!/usr/bin/env bash
#
# 把 dsh-hindsight-daemon 装进某个 DSH profile（Linux / macOS）。
#
# 做的事只有一件：在 profile 的 cordis.patch.yml 里追加一条 insert，
# 让 DSH 启动时加载本插件。依赖（uv / hindsight-embed / 模型）由插件
# 自己的设置页负责安装，这个脚本不碰它们。
#
# 幂等：重复执行不会重复写入。执行前会自动备份原文件。
#
# 用法：
#   ./scripts/install.sh                       # 装进默认的 web profile
#   ./scripts/install.sh --profile desktop     # 装进指定 profile
#   ./scripts/install.sh --dsh-home /path/.dsh # 自定义 DSH 主目录
#
set -euo pipefail

PROFILE="web"
DSH_HOME="${DSH_HOME:-$HOME/.dsh}"
ENTRY_ID="hindsight-daemon"

usage() {
	cat <<'USAGE'
用法: install.sh [选项]

选项:
  -p, --profile <name>   目标 DSH profile（默认 web）
      --dsh-home <path>  DSH 主目录（默认 $HOME/.dsh）
  -h, --help             显示本帮助

示例:
  ./scripts/install.sh
  ./scripts/install.sh --profile desktop
USAGE
}

while [[ $# -gt 0 ]]; do
	case "$1" in
		-p|--profile)
			PROFILE="${2:-}"
			shift 2
			;;
		--dsh-home)
			DSH_HOME="${2:-}"
			shift 2
			;;
		-h|--help)
			usage
			exit 0
			;;
		*)
			echo "未知参数: $1" >&2
			usage >&2
			exit 1
			;;
	esac
done

if [[ -z "$PROFILE" ]]; then
	echo "错误：profile 名不能为空" >&2
	exit 1
fi

# 插件根目录 = 本脚本所在目录的上一级
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
ENTRY="$PLUGIN_DIR/lib/index.js"

if [[ ! -f "$ENTRY" ]]; then
	echo "错误：找不到插件入口 $ENTRY" >&2
	exit 1
fi

PATCH="$DSH_HOME/profiles/$PROFILE/cordis.patch.yml"

if [[ ! -f "$PATCH" ]]; then
	echo "错误：找不到 profile「$PROFILE」的补丁文件：$PATCH" >&2
	echo "" >&2
	echo "该 profile 还没初始化过。先执行一次让它生成：" >&2
	echo "  dsh --profile $PROFILE --help" >&2
	exit 1
fi

# 幂等：已经装过就直接退出
if grep -qE "^[[:space:]]*-[[:space:]]*id:[[:space:]]*${ENTRY_ID}[[:space:]]*$" "$PATCH"; then
	echo "插件已经装进 profile「$PROFILE」了，无需重复安装。"
	echo "  补丁文件: $PATCH"
	exit 0
fi

BACKUP="$PATCH.bak-$(date +%Y%m%d-%H%M%S)"
cp "$PATCH" "$BACKUP"

# 判断文件是否"实质为空"：去掉注释和空行后只剩 [] 或什么都不剩。
CONTENT="$(grep -vE '^[[:space:]]*(#|$)' "$PATCH" | tr -d '[:space:]' || true)"

if [[ "$CONTENT" == "[]" || -z "$CONTENT" ]]; then
	# 空的补丁层：整体重写，保留原有的头部注释风格
	cat > "$PATCH" <<YAML
# Your patch layer for this dsh profile, applied after every bundle layer:
# a top-level YAML array of loader patch entries (id-targeted config
# overrides, disables, and insert lists).
- insert:
    - id: ${ENTRY_ID}
      name: '${ENTRY}'
YAML
else
	# 已有其它条目：追加到末尾
	cat >> "$PATCH" <<YAML

- insert:
    - id: ${ENTRY_ID}
      name: '${ENTRY}'
YAML
fi

echo "已安装到 profile「$PROFILE」"
echo "  入口:     $ENTRY"
echo "  补丁文件: $PATCH"
echo "  备份:     $BACKUP"
echo ""
echo "重启 DSH 后生效。首次使用请在设置页「Hindsight 记忆」里点「安装依赖与模型」。"
