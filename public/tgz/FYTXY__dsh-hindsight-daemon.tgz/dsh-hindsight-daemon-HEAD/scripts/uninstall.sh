#!/usr/bin/env bash
#
# 从 DSH profile 里移除 dsh-hindsight-daemon（Linux / macOS）。
#
# 只删 cordis.patch.yml 里那一条 insert，不碰其它条目，也不删插件目录
# 和已经生成的记忆数据。想彻底清除请另外删：
#   ~/.dsh/plugins/dsh-hindsight-daemon
#   ~/.dsh/hindsight-daemon            （插件自己的配置）
#   ~/.hindsight 与 ~/.pg0             （记忆本体，谨慎）
#
# 幂等：没装过时只提示，不改文件。
#
# 用法：
#   ./scripts/uninstall.sh
#   ./scripts/uninstall.sh --profile desktop
#
set -euo pipefail

PROFILE="web"
DSH_HOME="${DSH_HOME:-$HOME/.dsh}"
ENTRY_ID="hindsight-daemon"

usage() {
	cat <<'USAGE'
用法: uninstall.sh [选项]

选项:
  -p, --profile <name>   目标 DSH profile（默认 web）
      --dsh-home <path>  DSH 主目录（默认 $HOME/.dsh）
  -h, --help             显示本帮助
USAGE
}

while [[ $# -gt 0 ]]; do
	case "$1" in
		-p|--profile)
			PROFILE="${2:-}"
			shift 2
			;;
		--dsh-home)
			DSH_HOME="${2:-}"
			shift 2
			;;
		-h|--help)
			usage
			exit 0
			;;
		*)
			echo "未知参数: $1" >&2
			usage >&2
			exit 1
			;;
	esac
done

PATCH="$DSH_HOME/profiles/$PROFILE/cordis.patch.yml"

if [[ ! -f "$PATCH" ]]; then
	echo "找不到补丁文件：$PATCH" >&2
	exit 1
fi

# 找到 id 所在行
ID_LINE="$(grep -nE "^[[:space:]]*-[[:space:]]*id:[[:space:]]*${ENTRY_ID}[[:space:]]*$" "$PATCH" | head -1 | cut -d: -f1 || true)"

if [[ -z "$ID_LINE" ]]; then
	echo "profile「$PROFILE」里没有装本插件，无需卸载。"
	exit 0
fi

TOTAL="$(wc -l < "$PATCH")"

# 向前找所属的 `- insert:`（顶格那一行）
INSERT_LINE=""
for ((i = ID_LINE; i >= 1; i--)); do
	LINE="$(sed -n "${i}p" "$PATCH")"
	if [[ "$LINE" =~ ^-\ insert: ]]; then
		INSERT_LINE="$i"
		break
	fi
done

if [[ -z "$INSERT_LINE" ]]; then
	echo "警告：找到了 id 行（第 $ID_LINE 行）但没找到所属的 insert 块，为避免误删已中止。" >&2
	echo "请手动编辑：$PATCH" >&2
	exit 1
fi

# 向后找块结束：下一个顶格的 `- ` 行之前
END_LINE="$TOTAL"
for ((i = INSERT_LINE + 1; i <= TOTAL; i++)); do
	LINE="$(sed -n "${i}p" "$PATCH")"
	if [[ "$LINE" =~ ^-[[:space:]] ]]; then
		END_LINE=$((i - 1))
		break
	fi
done

# 安全闸：这个块里必须只有我们这一条 id，否则说明是共用的 insert，不能整块删
ID_COUNT="$(sed -n "${INSERT_LINE},${END_LINE}p" "$PATCH" | grep -cE '^[[:space:]]*-[[:space:]]*id:' || true)"
if [[ "$ID_COUNT" -ne 1 ]]; then
	echo "警告：第 $INSERT_LINE-$END_LINE 行这个 insert 块里有 $ID_COUNT 个条目，不是本插件独占，为避免误删已中止。" >&2
	echo "请手动编辑：$PATCH" >&2
	exit 1
fi

BACKUP="$PATCH.bak-$(date +%Y%m%d-%H%M%S)"
cp "$PATCH" "$BACKUP"

# 连同块前紧邻的空行一起删，避免留下连续空行
START="$INSERT_LINE"
while [[ "$START" -gt 1 ]]; do
	PREV="$(sed -n "$((START - 1))p" "$PATCH")"
	if [[ -z "${PREV//[[:space:]]/}" ]]; then
		START=$((START - 1))
	else
		break
	fi
done

sed -i "${START},${END_LINE}d" "$PATCH"

# 删空后如果文件只剩注释，补一个空的 [] 让 YAML 仍是合法数组
CONTENT="$(grep -vE '^[[:space:]]*(#|$)' "$PATCH" | tr -d '[:space:]' || true)"
if [[ -z "$CONTENT" ]]; then
	echo '[]' >> "$PATCH"
fi

echo "已从 profile「$PROFILE」卸载"
echo "  补丁文件: $PATCH"
echo "  备份:     $BACKUP"
echo ""
echo "插件目录与记忆数据都还在，如需彻底清除请手动删除（见脚本头部注释）。"
