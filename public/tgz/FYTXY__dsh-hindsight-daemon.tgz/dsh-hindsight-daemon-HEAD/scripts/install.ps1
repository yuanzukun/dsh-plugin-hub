﻿#Requires -Version 5.1
<#
.SYNOPSIS
    把 dsh-hindsight-daemon 安装到本机的 DSH Desktop。

.DESCRIPTION
    做两件事：
      1. 在 DSH profile 的 cordis.patch.yml 里追加一个 insert 块，把插件挂上去；
      2. 调用 scripts/install-deps.mjs 安装 Python 依赖与本地模型（可跳过）。

    脚本是幂等的：重复执行不会写入第二个 insert 块。修改前会自动备份
    cordis.patch.yml。

.PARAMETER Profile
    DSH profile 名，默认 desktop。

.PARAMETER DshHome
    DSH 的 home 目录，默认取 $env:DSH_HOME，再退回 $env:USERPROFILE\.dsh。

.PARAMETER SkipDeps
    只挂插件、不安装依赖（依赖可以之后在设置页点「一键安装」）。

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\install.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\install.ps1 -Profile web -SkipDeps
#>
[CmdletBinding()]
param(
    [string]$Profile = 'desktop',
    [string]$DshHome = '',
    [switch]$SkipDeps
)

$ErrorActionPreference = 'Stop'

function Write-Step {
    param([string]$Message)
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([string]$Message)
    Write-Host "  OK  $Message" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host "  !!  $Message" -ForegroundColor Yellow
}

# —— 1. 定位仓库根目录 ——
$repoRoot = Split-Path -Parent $PSScriptRoot
$manifest = Join-Path $repoRoot 'package.json'
if (-not (Test-Path -LiteralPath $manifest)) {
    throw "找不到 $manifest，脚本似乎不在插件的 scripts 目录里。"
}
$package = Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json
$entry = Join-Path $repoRoot 'lib/index.js'
if (-not (Test-Path -LiteralPath $entry)) {
    throw "找不到 $entry，仓库不完整。"
}
Write-Step "插件目录: $repoRoot（$($package.name) $($package.version)）"

# —— 2. 定位 DSH profile ——
if ([string]::IsNullOrWhiteSpace($DshHome)) {
    if (-not [string]::IsNullOrWhiteSpace($env:DSH_HOME)) {
        $DshHome = $env:DSH_HOME
    } else {
        $DshHome = Join-Path $env:USERPROFILE '.dsh'
    }
}
if (-not (Test-Path -LiteralPath $DshHome)) {
    throw "找不到 DSH home: $DshHome（DSH Desktop 是否安装并运行过？）"
}

$profilesRoot = Join-Path $DshHome 'profiles'
$profileDir = Join-Path $profilesRoot $Profile
if (-not (Test-Path -LiteralPath $profileDir)) {
    $available = @()
    if (Test-Path -LiteralPath $profilesRoot) {
        $available = Get-ChildItem -LiteralPath $profilesRoot -Directory | Select-Object -ExpandProperty Name
    }
    throw "找不到 profile '$Profile'。现有 profile: $($available -join ', ')"
}
Write-Step "DSH profile: $profileDir"

# —— 3. 写入 cordis.patch.yml ——
$patchPath = Join-Path $profileDir 'cordis.patch.yml'
$patchText = ''
if (Test-Path -LiteralPath $patchPath) {
    $patchText = Get-Content -LiteralPath $patchPath -Raw -Encoding UTF8
    if ($null -eq $patchText) { $patchText = '' }
}

$entryId = 'hindsight-daemon'
if ($patchText -match "(?m)^\s*-\s*id:\s*$([regex]::Escape($entryId))\s*$") {
    Write-Warn "cordis.patch.yml 里已经有 id: $entryId，跳过写入（如需换路径请先手动删掉旧块）。"
} else {
    if ($patchText.Length -gt 0) {
        $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
        $backup = "$patchPath.bak-$stamp"
        Copy-Item -LiteralPath $patchPath -Destination $backup -Force
        Write-Ok "已备份到 $backup"
    }

    $entryPath = $entry -replace '\\', '/'
    $block = @(
        '',
        '# Hindsight 本地记忆 daemon：DSH 启动时拉起，DSH 退出时连嵌入式 PostgreSQL 一起停掉。',
        '# 不产生任何常驻进程；移除这个 insert 块（以及插件目录）即可卸载。',
        '- insert:',
        "    - id: $entryId",
        "      name: '$entryPath'",
        ''
    ) -join "`r`n"

    if ($patchText.Length -gt 0 -and -not $patchText.EndsWith("`n")) {
        $patchText += "`r`n"
    }
    $patchText += $block
    [System.IO.File]::WriteAllText($patchPath, $patchText, (New-Object System.Text.UTF8Encoding($false)))
    Write-Ok "已写入 $patchPath"
}

# —— 4. 安装依赖与模型 ——
if ($SkipDeps) {
    Write-Warn "已跳过依赖安装。启动 DSH 后可在设置页「Hindsight 记忆」里点「安装依赖与模型」。"
} else {
    $node = Get-Command node -ErrorAction SilentlyContinue
    if ($null -eq $node) {
        Write-Warn "PATH 里没有 node，无法自动安装依赖。请先装 Node.js 20+，或在 DSH 设置页点「一键安装」。"
    } else {
        Write-Step "安装 Python 依赖与本地模型（约 1.5 GB + 1.2 GB，首次需要十几分钟）"
        $depsScript = Join-Path $repoRoot 'scripts/install-deps.mjs'
        & node $depsScript
        if ($LASTEXITCODE -ne 0) {
            throw "依赖安装失败（退出码 $LASTEXITCODE）。可以修好后再跑一次，或在 DSH 设置页重试。"
        }
        Write-Ok "依赖与模型就绪"
    }
}

Write-Host ''
Write-Host '安装完成。' -ForegroundColor Green
Write-Host '接下来：'
Write-Host '  1. 重启 DSH Desktop（插件在启动时加载）；'
Write-Host '  2. 打开 设置 → Hindsight 记忆，填入你自己的模型服务（Base URL / API Key / 模型名）；'
Write-Host '  3. daemon 会在 DSH 启动时自动拉起，关闭 DSH 时自动停止。'
