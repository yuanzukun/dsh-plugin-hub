﻿#Requires -Version 5.1
<#
.SYNOPSIS
    从 DSH Desktop 卸载 dsh-hindsight-daemon。

.DESCRIPTION
    只做一件事：从 profile 的 cordis.patch.yml 里删掉本插件的 insert 块。
    插件目录、Python 依赖与本地模型都保留，方便之后重新挂上；如果要彻底清理，
    脚本末尾会打印需要手动删除的路径。

.PARAMETER Profile
    DSH profile 名，默认 desktop。

.PARAMETER DshHome
    DSH 的 home 目录，默认取 $env:DSH_HOME，再退回 $env:USERPROFILE\.dsh。

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\scripts\uninstall.ps1
#>
[CmdletBinding()]
param(
    [string]$Profile = 'desktop',
    [string]$DshHome = ''
)

$ErrorActionPreference = 'Stop'

$entryId = 'hindsight-daemon'

if ([string]::IsNullOrWhiteSpace($DshHome)) {
    if (-not [string]::IsNullOrWhiteSpace($env:DSH_HOME)) {
        $DshHome = $env:DSH_HOME
    } else {
        $DshHome = Join-Path $env:USERPROFILE '.dsh'
    }
}

$patchPath = Join-Path (Join-Path (Join-Path $DshHome 'profiles') $Profile) 'cordis.patch.yml'
if (-not (Test-Path -LiteralPath $patchPath)) {
    throw "找不到 $patchPath"
}

$lines = [System.Collections.Generic.List[string]]::new()
foreach ($line in (Get-Content -LiteralPath $patchPath -Encoding UTF8)) { $lines.Add($line) }

# 找 `- id: hindsight-daemon` 所在行
$idPattern = '^\s*-\s*id:\s*' + [regex]::Escape($entryId) + '\s*$'
$idIndex = -1
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match $idPattern) { $idIndex = $i; break }
}

if ($idIndex -lt 0) {
    Write-Host "cordis.patch.yml 里没有 id: $entryId，无需卸载。" -ForegroundColor Yellow
    return
}

# 计算该行缩进（'-' 所在列）
$idIndent = $lines[$idIndex].IndexOf('-')

# 向后吃掉所有缩进更深的续行（如 name:）
$end = $idIndex
for ($i = $idIndex + 1; $i -lt $lines.Count; $i++) {
    $text = $lines[$i]
    if ([string]::IsNullOrWhiteSpace($text)) { continue }
    $indent = $text.Length - $text.TrimStart().Length
    if ($indent -le $idIndent) { break }
    $end = $i
}

# 向前找 `- insert:` 父行
$insertIndex = -1
for ($i = $idIndex - 1; $i -ge 0; $i--) {
    $text = $lines[$i]
    if ([string]::IsNullOrWhiteSpace($text)) { continue }
    $indent = $text.Length - $text.TrimStart().Length
    if ($indent -lt $idIndent -and $text -match '^\s*-\s*insert:\s*$') {
        $insertIndex = $i
    }
    break
}

$start = $idIndex
if ($insertIndex -ge 0) {
    # 父块里除本条目外还有别的 `- id:` 吗？有就只删本条目，没有就整块删掉。
    $insertDash = $lines[$insertIndex].IndexOf('-')
    $hasSibling = $false
    for ($i = $insertIndex + 1; $i -lt $lines.Count; $i++) {
        $text = $lines[$i]
        if ([string]::IsNullOrWhiteSpace($text)) { continue }
        $indent = $text.Length - $text.TrimStart().Length
        if ($indent -le $insertDash) { break }
        if ($text -match '^\s*-\s*id:' -and $i -ne $idIndex) { $hasSibling = $true }
    }
    if (-not $hasSibling) {
        $start = $insertIndex
        # 连带吃掉紧邻其上的注释与空行
        for ($i = $insertIndex - 1; $i -ge 0; $i--) {
            $text = $lines[$i]
            if ([string]::IsNullOrWhiteSpace($text) -or $text -match '^\s*#') { $start = $i } else { break }
        }
    }
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
Copy-Item -LiteralPath $patchPath -Destination "$patchPath.bak-$stamp" -Force
Write-Host "已备份到 $patchPath.bak-$stamp" -ForegroundColor Cyan

$kept = [System.Collections.Generic.List[string]]::new()
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($i -lt $start -or $i -gt $end) { $kept.Add($lines[$i]) }
}

$text = ($kept -join "`r`n")
if (-not $text.EndsWith("`n")) { $text += "`r`n" }
[System.IO.File]::WriteAllText($patchPath, $text, (New-Object System.Text.UTF8Encoding($false)))

Write-Host "已从 $patchPath 移除 id: $entryId" -ForegroundColor Green
Write-Host ''
Write-Host '重启 DSH 后插件即不再加载。以下内容保留，需要时再删：'
Write-Host "  配置目录  $(Join-Path $DshHome 'hindsight-daemon')"
Write-Host "  uv 工具   <UV_TOOL_DIR>\hindsight-embed"
Write-Host '  模型缓存  %HF_HOME%（或 ~\.cache\huggingface）'
Write-Host '  数据库    ~\.pg0\instances\hindsight-embed-<profile>'
