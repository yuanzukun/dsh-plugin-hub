#!/usr/bin/env node
/**
 * 在 DSH 之外执行「依赖 + 模型」安装。
 *
 * 设置页里的「一键安装」走的是同一条代码路径（`lib/core/installer.js` 的
 * `runInstall`），这里只是把它搬到命令行，好处是安装不需要先启动 DSH ——
 * 装完再开 DSH，插件首次加载时环境已经是齐的。
 *
 * 用法：
 *   node scripts/install-deps.mjs
 *   node scripts/install-deps.mjs --pypi https://pypi.org/simple
 */

import { readConfig, toFlat } from '../lib/config.js'
import { runInstall } from '../lib/core/installer.js'

/**
 * 解析命令行参数。
 * @param argv - process.argv.slice(2)。
 * @returns 覆盖到配置上的补丁。
 */
function parseArgs(argv) {
	const patch = {}
	for (let index = 0; index < argv.length; index += 1) {
		const current = argv[index]
		const next = argv[index + 1]
		if (current === '--pypi' && next !== undefined) {
			patch.pypiIndex = next
			index += 1
		} else if (current === '--hf' && next !== undefined) {
			patch.hfEndpoint = next
			index += 1
		} else if (current === '--profile' && next !== undefined) {
			patch.profile = next
			index += 1
		} else if (current === '--port' && next !== undefined) {
			const parsed = Number.parseInt(next, 10)
			if (Number.isFinite(parsed)) patch.apiPort = parsed
			index += 1
		}
	}
	return patch
}

/**
 * 打印一行进度。
 * @param event - `{ stage, message, detail }`。
 */
function printProgress(event) {
	const stage = String(event.stage ?? '').padEnd(9)
	const message = String(event.message ?? '')
	const detail = typeof event.detail === 'string' && event.detail.length > 0 ? `  ${event.detail}` : ''
	process.stdout.write(`[${stage}] ${message}${detail}\n`)
}

async function main() {
	const patch = parseArgs(process.argv.slice(2))
	const config = { ...readConfig(), ...patch }
	const flat = toFlat(config)

	process.stdout.write('=== dsh-hindsight-daemon 依赖安装 ===\n')
	process.stdout.write(`profile : ${flat.profile}\n`)
	process.stdout.write(`端口    : ${flat.port}\n`)
	process.stdout.write(`PyPI    : ${flat.pypiIndex.length > 0 ? flat.pypiIndex : '(官方源)'}\n`)
	process.stdout.write(`HF 镜像 : ${flat.hfEndpoint.length > 0 ? flat.hfEndpoint : '(官方源)'}\n`)
	process.stdout.write('首次安装需要下载约 1.5 GB 依赖与 1.2 GB 模型，请耐心等待。\n\n')

	const result = await runInstall(flat, printProgress)

	if (!result.ok) {
		process.stdout.write(`\n✗ 安装失败：${result.error ?? '未知错误'}\n`)
		process.exitCode = 1
		return
	}
	process.stdout.write('\n✓ 安装完成。启动 DSH 后，daemon 会被自动拉起。\n')
}

await main()
