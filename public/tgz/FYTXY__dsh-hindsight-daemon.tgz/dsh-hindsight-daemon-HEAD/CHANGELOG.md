# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.0] — 2026-10-24

Structural release: the plugin gained a test suite, CI, and conventional repository
documentation. **Runtime behaviour is unchanged** — no difference in when the daemon
starts, when it is stopped, or what the settings page does.

### Added

- `tests/` with 25 tests under `node --test`, covering:
  - config defaults, secret redaction, flat/`toFlat` conversion, atomic write, and
    fallback on hand-edited or corrupted `config.json`;
  - profile-name validation (including path traversal), database path derivation;
  - platform helpers (`exeName`, `venvExe`), path normalisation, fatal-log detection,
    status ring buffer;
  - exit-hook registration, removal and idempotency;
  - profile deletion (files, metadata entry, in-use refusal, invalid names);
  - the settings page's delete flow, driven through a minimal hooks implementation
    instead of a browser;
  - packaging invariants: `files` whitelist, bundle patch ids, PowerShell BOM,
    README relative links.
- `.github/workflows/tests.yml`: Node 22/24 on Ubuntu and Windows, with syntax checks
  and a `npm pack --dry-run` guard.
- `docs/architecture.md`: process topology, the three exit channels, and the measured
  timings behind each design decision.
- `.editorconfig`, `CONTRIBUTING.md`, `SECURITY.md`, `CHANGELOG.md`.
- `README.zh-CN.md` (full Chinese translation); `README.md` is now the English document.

### Changed

- `package.json`: added `test` / `check` / `pack:dry` scripts, moved the documentation
  set into `files`, and refreshed keywords.
- The three `scripts/smoke-*.mjs` scripts became `tests/*.test.mjs`. They keep their
  assertions; only the location and the `node --test` entry point changed.

### Fixed

- `tests/exit-hooks.test.mjs` only sandboxed `HOME`/`USERPROFILE`. When `DSH_HOME` is
  set in the environment (DSH's own host process sets it), the test read the *real*
  configuration, launched a real daemon and killed it — 46 seconds per run, and it
  interfered with a running daemon. The test now pins `DSH_HOME` into its sandbox and
  runs in ~600 ms.

## [0.3.0]

### Added

- Deleting a memory repository (profile) from the settings page, with a confirmation
  step; the in-use repository cannot be deleted until another one is activated.
- Linux support end-to-end: `scripts/install.sh` / `uninstall.sh`, `pg_ctl` and
  port-based process handling, and the three exit channels that Linux actually needs.

### Changed

- Documentation rewritten around cross-platform paths (`~` instead of `C:\Users\...`).

## [0.2.x]

### Added

- Memory repository list with create/switch, backed by per-profile env files.
- Model-service form with a connectivity test that sends one minimal request using the
  current draft, so a wrong key is caught before the first memory write.
- One-click dependency installation in five stages (`check`, `packages`, `profile`,
  `models`, `verify`).

## [0.1.0]

### Added

- Initial release: Cordis entry that starts the Hindsight daemon on DSH launch and
  stops it — together with its embedded PostgreSQL — on exit, with a settings page.
- Windows one-click installer that patches the profile's `cordis.patch.yml` idempotently.

[Unreleased]: https://github.com/FYTXY/dsh-hindsight-daemon/compare/v0.4.0...HEAD
[0.4.0]: https://github.com/FYTXY/dsh-hindsight-daemon/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/FYTXY/dsh-hindsight-daemon/releases/tag/v0.3.0
[0.2.x]: https://github.com/FYTXY/dsh-hindsight-daemon/releases
[0.1.0]: https://github.com/FYTXY/dsh-hindsight-daemon/releases
