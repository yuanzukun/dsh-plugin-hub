import assert from 'node:assert/strict'
import { readFileSync, mkdtempSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'
import test from 'node:test'

// Real plugin markup/styles against Harness ddefc45f's shared dock and StatsPills CSS.
// CHROME_BIN points to a local Chromium; no server, account, or browser profile needed.
test('plugin owns the bottom row below native statistics and context meter at every width', { skip: !process.env.CHROME_BIN }, () => {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-layout-'))
  try {
    const bundle = readFileSync(new URL('../client/client.js', import.meta.url), 'utf8')
    const nativeCss = readFileSync(new URL('./fixtures/harness-stats-pills.css', import.meta.url), 'utf8')
    const html = `<meta charset="utf-8"><style>${nativeCss}
      body{margin:0;font-family:Arial}.dock{display:flex;align-items:center;justify-content:center;gap:12px;max-width:100%;padding-top:4px}
    </style><script>
    let Widget;
    const jsx=(type,props)=>({type,props});
    const react={memo:f=>(Widget=f),useState:f=>[typeof f==='function'?f():f,()=>{}],useRef:()=>({current:null}),useEffect:()=>{},useSyncExternalStore:()=>({status:'ok',sessionId:'a',payload:{ok:true,balances:[{total:12.62}],stats:{percent:94.3}}})};
    window.__ModuleLoader__={load:d=>d.factory(id=>id==='react'?react:id==='react/jsx-runtime'?{jsx,jsxs:jsx}:{})};
    ${bundle}
    function render(node){
      if(node==null)return document.createTextNode('');
      if(Array.isArray(node)){const f=document.createDocumentFragment();node.forEach(n=>f.append(render(n)));return f}
      if(typeof node!=='object')return document.createTextNode(String(node));
      if(!node.type)return render(node.props?.children);
      const e=document.createElement(node.type);for(const [k,v] of Object.entries(node.props||{})){if(k==='className')e.className=v;else if(k==='children')e.append(render(v))}return e;
    }
    </script><body><script>
    const failures=[];
    for(const wrapped of [false,true])for(const width of [900,700,480,320]){
      const dock=document.createElement('div');dock.className='dock';dock.style.width=width+'px';
      dock.innerHTML='<div class="root"><span class="anchor"><button class="pill"><span class="label">4 轮 18 步</span></button></span><span class="anchor"><button class="pill"><span class="label">1.3M tok · 18s</span></button></span></div>';
      const outlet=wrapped?document.createElement('div'):dock;if(wrapped){outlet.dataset.slot='conversation.composer.dock';outlet.style.display='contents';outlet.append(dock.firstChild);dock.append(outlet);}
      outlet.append(render(Widget({sessionId:'a',useProjection:()=>({cost:.269}),t:k=>({balance:'余额',sessionCost:'本次会话',percentUsed:'累计消耗'}[k]||k)})));
      const meter=document.createElement('span');meter.textContent='◉ 9%';meter.style.flex='none';dock.append(meter);document.body.append(dock);
      const widget=dock.querySelector('.dshbs_widget');
      const pluginRoot=dock.querySelector('.dshbs_root');
      for(const native of [dock.querySelector('.root'),meter])if(widget.getBoundingClientRect().top<native.getBoundingClientRect().bottom)failures.push(width+': plugin is not below native controls');
      if(Math.abs(pluginRoot.getBoundingClientRect().width-width)>1)failures.push(width+': plugin does not own a full row');
      for(const label of dock.querySelectorAll('.label'))if(label.scrollWidth>label.clientWidth)failures.push(width+': native statistics truncated');
      if(dock.scrollWidth>width+1)failures.push(width+': dock overflows');
    }
    const out=document.createElement('pre');out.id='result';out.textContent=JSON.stringify(failures);document.body.append(out);
    </script>`
    const file = join(dir, 'layout.html'); writeFileSync(file, html)
    const result = spawnSync(process.env.CHROME_BIN, ['--headless', '--window-size=1200,900', '--no-sandbox', '--disable-gpu', '--dump-dom', '--no-proxy-server', '--user-data-dir='+join(dir,'profile'), 'file://'+file], { encoding:'utf8', timeout:30000, maxBuffer:2e6 })
    assert.equal(result.status, 0, result.stderr)
    const failures = result.stdout.match(/<pre id="result">(.*?)<\/pre>/)?.[1]
    assert.equal(failures, '[]', failures ?? result.stderr)
  } finally { rmSync(dir, { recursive:true, force:true }) }
})
