# Harness composer compatibility — 2026-09-18

Verified upstream tags: npm `latest` / `next` = `0.1.5-rc.2`; npm `alpha` and
GitHub master = `0.1.6-alpha.2` (`ddefc45fbc7f8e46dd73185e68295696d1297887`).

In alpha.2, `InputBar.tsx` puts `conversation.composer.dock` entries and
`ContextMeter` in one horizontal flex row. `StatsPills` has `min-width:0` and
ellipsizes its labels. The plugin's previous `width:100%` claimed the row's
width and unnecessarily squeezed native statistics even at 900px.
The rc.2 version used a separate full-width native statistics row.

The fix makes only the dock containing this plugin wrap, and assigns the plugin
a full-width last row using flex order. Native statistics and the context meter
stay above it. Readings can wrap within the plugin row when space is limited. It keeps the existing slot
and scoped session data API. It does not change pricing or account calculations.

Sources:
- [InputBar](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.1.6-alpha.2/packages/client/ui-conversation/src/client/skeleton/InputBar.tsx)
- [Dock CSS](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.1.6-alpha.2/packages/client/ui-conversation/src/client/skeleton/InputBar.module.css)
- [Native statistics CSS](https://github.com/deepseek-ai/deepseek-harness/blob/dsh-v0.1.6-alpha.2/packages/client/ui-chat/src/client/chat/StatsPills.module.css)

Reproduction and regression:

```sh
CHROME_BIN=/path/to/headless_shell node --test --test-isolation=none test/ui-layout.test.js
node --test --test-isolation=none test/*.test.js
```

The browser test renders the actual plugin component with mocked data/hooks and
the upstream native statistics CSS. Before the fix it reports truncated native
labels at 900px and 700px. After the fix, at 900px, 700px, 480px and 320px, the plugin owns a full-width
row below both native controls, native labels are not truncated, and the dock
does not overflow. This is an isolated Chromium layout test,
not a macOS browser integration test. For v0.3.2, an authenticated Chromium
session also opens the running Harness and checks the real DOM: the plugin
row is below the native controls at 1280px, 900px and 640px viewport widths.

## v0.3.2 correction

The v0.3.1 fixture omitted Harness SlotOutlet's `display:contents` wrapper.
Its selector matched that wrapper rather than the actual flex dock, so the
live dock still did not wrap. v0.3.2 targets the dock through the explicit
`data-slot="conversation.composer.dock"` anchor as well as older direct children.
The browser regression now covers both DOM structures at all four widths.
