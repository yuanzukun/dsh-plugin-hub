# 阅读器视觉与排版规范

## 方向

沿用既有暖白阅读主题，把正文与 AI 伴读做成同一张连续纸面。文字是视觉中心，工具随操作显现。此次是现有界面的打磨与排版修复。

参考 RSS 的右侧伴读、可拖动分割、底部输入与快捷提示词结构。参考 qiaomu-design 的 Notion 设计资料，采用透明 ghost 按钮、约 5% 的轻微悬停染色、1px 低对比度边界；颜色继续使用 Reader 自己的六套阅读主题。

## 结构与数值

| 区域 | 规范 |
| --- | --- |
| 正文版心 | 单页外框最大 860px；双页最大 1280px。页边距在外框，分页裁切在内部无 padding 的独立视口 |
| 页内留白 | 分页上方 64px、下方 48px；横向采用用户设置值与 6vw 中较小者，窄屏可读 |
| 分页 | 一列或两列，双列间距 56px；高度取实际视口。缩放、分割、字号与行高变化重新测量并对齐当前页 |
| 左右标题栏 | 桌面同为 52px；触屏 56px。同为 `--qmr-paper` 背景与 `--qmr-border` 底线 |
| 标题信息 | 书名、章节和进度同一行；窄屏隐藏次要信息。伴读书名与章节同一行，不重复同名书籍与章节 |
| 分界 | 布局中只占 1px；透明拖动热区向两侧各延伸 6px。窄屏换成水平细线和上下热区 |
| 工具 | 透明图标按钮，无常驻外框。鼠标约 36px，触屏 44px；保留名称、tooltip 与细焦点提示 |
| 导航 | 目录在底部进度条左侧；顶部与底部停止操作 2.8 秒隐藏，键盘焦点可保持显示 |
| 翻页边缘 | 仅边缘 28px 的透明区域；取消大面积 hover 色块，避免遮挡选文 |

## 五项视觉细节

1. 选文使用阅读主题的低饱和强调色。
2. 键盘焦点用主题色细线，无双重边框、光晕或尺寸变化。
3. 工具栏淡出，正文版心保持稳定。
4. 分界线与标题栏底线形成连续的细线结构。
5. 页码与进度使用等宽数字，滚动条采用主题色细轨道。

不修改原书的诗句、目录或元数据内容；短诗本身的行宽不会被强行拉长。

## 两轮检查

第一轮修正分页露出下一列、分割间隙、标题栏不同底色和高度。真实组件截图发现鼠标焦点可能让工具栏常驻，窄屏图标和副标题会抢空间，分割移动时动画会短暂错位。

第二轮：仅保留键盘可见焦点对工具栏的显示保护；窄屏隐藏副标题和不常用的全屏入口；重新测量立即对齐，不对缩放播放平移动画；去掉重复书名，次要字号统一到 12px。

## 验证与边界（2026-10-01）

本地预览直接加载项目 ReaderView、CompanionPanel、controller 与核心引擎，使用内置《唐诗三百首》和《Meditations》实际 EPUB 内容。未模拟 AI 回复，预览未接 Harness 原生会话。

- 1280×720：分页翻页没有下一列残字；左右标题栏背景均为 `rgb(248,246,240)`，高度均为 52px，分界占 1px。
- 拖动分割线由 44% 改到 34%；方向键调整和双击回到 44% 均生效。
- 当前页为第 2 页、页数仍为 19 时调整分割比例，正文 transform 根据新列宽更新。
- 1440×900：双列视口 1120px、列数 2，严格显示两栏。
- 390×844：上下分屏，分界高度 1px，上下热区各 6px；页面无横向溢出。
- 连续滚动：列数 auto、transform none，纵向可滚动；无分页计数。
- 夜间主题：正文与两侧标题栏同为 `rgb(24,26,27)`。
- 自动隐藏：两栏 opacity 0、pointer-events none；正文视口位置保持不变。
- 搜索「江南」：首个结果翻到第 3 页，下个结果翻到第 10 页；命中可见且 scrollLeft 始终为 0。分页定位改用页号，不让浏览器横向滚动。

构建与 47 项现有测试通过。桌面安装通过软链接使用本项目产物；桌面自动操作被宿主状态变化中断，尚未完成本轮桌面重载与原生伴读验收。

截图：`docs/qa/reader-page.png`、`docs/qa/reader-split.png`。

# 书库：C「清晰书目」

## 已选方向与设计依据

用户在四方向预览中选择 C，并补充「可以更精致一点」。选择依据保存于 `design-previews/2026-10-01-library/selection.json`。正式界面采用左侧分类、右侧横向书目；不采用封面网格或大型 Hero。

参考资料：

- [Apple Books 分类指南](https://support.apple.com/en-ke/guide/books/ibks33867842/mac)：分类导航与书目分工。
- [Apple Books](https://www.apple.com/apple-books/)：继续阅读入口与封面辨识。
- [Material 列表](https://m2.material.io/develop/ios/components/list/)：左侧主要内容、右侧辅助信息。
- 本地 Notion 与 Linear 设计资料：1px 轻边界、ghost 操作、约 4% 悬停染色、低饱和单一强调色、等宽数字。

## 正式规范

| 区域 | 数值与行为 |
| --- | --- |
| 分类栏 | 桌面 196px，较窄桌面 176px；700px 以下换横向状态导航 |
| 层次 | 使用宿主文字和背景令牌混色：分类底色约 2%、继续阅读 3%、悬停 4%、选中 6%；兼容深色主题 |
| 主区 | 桌面左右 32px 留白，较窄桌面 24px，手机 16px |
| 书目 | 实测行高 77px；封面 36×52px；无封面使用书籍线性图标，无 QM 字母块 |
| 文字 | 主标题 22px；书名 15px / 手机 14px；作者与进度 12px；次要列标题 11px。中文系统字体，不设置中文字间距 |
| 列 | 书名与作者、格式、阅读进度、划线数、更多操作；标题与正文对齐，进度与数量使用等宽数字 |
| 继续阅读 | 紧凑横条，封面 28×40px；书名、进度与继续操作，不重复作者和划线数量 |
| 操作 | 搜索输入 42px / 手机 44px；鼠标图标 40px / 手机 44px；菜单有独立按钮，避免嵌套按钮或行点击吞掉键盘事件 |
| 手机 | 保留封面、书名、作者、进度和更多操作；格式改为选择框，笔记与划线留在更多菜单 |
| 焦点 | 1px 细线，颜色令牌缺失时回退到宿主次要文字；无阴影、双边框或尺寸变化 |

搜索、阅读状态筛选、格式筛选与排序通过既有 UI store 保存；不修改 Harness 的页面 URL，避免影响宿主路由。新增书库文案共用中英字典，供客户端注册与 locale 文件使用。

## 两轮打磨与验收

第一轮实际组件截图检查主列留白、窄屏列宽、书名截断、菜单和异步状态。第二轮压缩继续阅读与行高、对齐列标题、补齐手机 44px 点击区域，并在真实宿主中调整浅色层次。

- 本地实际组件（并非静态效果图）：1440×900 桌面、390×844 窄屏；窄屏书库 scrollWidth 为 390px，无横向溢出。
- 使用六本实际内置 EPUB 和两本仅用于验收的 PDF/TXT 元数据，检查有封面 / 无封面、长书名、中英与深色主题。
- 搜索作者「老子」只显示《道德经》；PDF 筛选只显示测试 PDF；有划线筛选显示一本；书名排序生效；清空筛选恢复八本。
- 空库、加载、无匹配与可重试错误各有独立展示。加载时不会提前显示空库提示。
- 菜单 Esc 关闭菜单并将焦点还给触发按钮，保留书库。阅读笔记入口通过 Enter 直接打开笔记模式；划线入口打开列表模式。
- Harness 安装版已加载本轮产物：真实六本书目可见；搜索「老子」得到一本，清除后恢复六本；菜单展示阅读笔记、划线、文件格式 / 大小和删除；Esc 只关闭菜单。
- 构建成功，47 项现有测试通过。本轮没有执行真实书籍删除，也没有进行导入或 AI 请求；原生 AI 伴读的完整验收仍属阅读器章节所述的待验范围。

截图：`docs/qa/library-harness.png`（实机）、`docs/qa/library-desktop.png`、`docs/qa/library-mobile.png`、`docs/qa/library-dark-mobile.png`（实际组件预览）。


## 纯白与无边框划线（v1.0.2）

新增独立的「纯白」主题：背景 `#ffffff`，正文 `#242629`，分界 `#e4e6e9`。设置面板中放在「纸白」之前；「纸白」继续使用原本的暖色纸面。纯白主题覆盖正文、工具栏与 AI 伴读纸面，通过既有书籍设置持久化。

正文划线取消 normal / is-focused 的 border、outline 与 box-shadow，只保留原来的半透明荧光色。去掉额外 padding，跨行不形成框角。划线文字继承当前阅读主题的正文色，夜间保持可读。点击仍打开划线 / 批注面板，定位行为保留。

实际组件验收：在《道德经》第三章点击跨三行的粉色划线，is-focused 为 true，border 为 0px、outline 为 none、box-shadow 为 none；背景 rgba(248,123,168,.42)。纯白正文背景为 rgb(255,255,255)。截图见 `docs/qa/white-borderless-highlight.png`。


## 2026-11-03 原版找书与提示词适配

Reference: Qiaomu Reader 4.9.4 `book-shelf.js`, `ebook-library-ui.js`, `ai-prompts.js` and scoped discovery/prompt CSS. DSH's existing C library list, white/borderless highlights and native AI conversation remain the product frame.

Discovery is a focused book-finding dialog, not a growing form inside the library. Reuse the original's 60px 2:3 covers, compact cover/text cards, 116px detail cover, restrained segmented navigation, 13px metadata hierarchy and 20px detail spacing. Keep the existing system Chinese font and Harness semantic colors; no new visual theme or decorative assets. Covers come from the original public mirror, with lazy loading and readable failure placeholders.

Flow: Library → Find books → rankings/search/topics → detail → reading mark or external catalogue/Gutenberg → back to the same list position and focused book. Reading lists are one view with want/read counts. Recommendation, errors, loading, no results and no saved lists each have their own message and recovery. Search and public catalogue selection remain local until the user explicitly submits Gutenberg search.

Prompt editing follows the original's single scrollable draft with title/body per item and one footer for Add, Restore, Cancel and Save. Changes apply only after Save; failure keeps the full draft. The native composer is untouched. Dialogs trap focus, close on Escape and restore focus.

All new discovery CSS lives under `.qmr-discovery-dialog` or its backdrop/entry. Prompt styling is limited to `.qmr-prompt-dialog`. Never extend shared `.qmr-feature-panel` selectors. Dark mode uses inherited Harness tokens; narrow views collapse to one cover grid column with wrapping controls and a fixed dialog header/footer. No hover-only required action, duplicate tooltip or italic original title.

Acceptance: actual original/DSH screen comparison, desktop/narrow and light/dark; covers, long titles, detail/comments, lists/recommendations, back scroll/focus, source switching, empty/error/retry, prompt failure/draft, EPUB and speech control regression. Test fixtures are identified separately from public/live data. Record unaligned host-specific behavior and unavailable environments in READER-ADAPTATION.md.
