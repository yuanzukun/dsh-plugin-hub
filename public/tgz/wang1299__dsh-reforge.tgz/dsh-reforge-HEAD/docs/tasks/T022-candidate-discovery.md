# T022 · 候选经验发现与提醒

依赖T020/T021，基线84f5d57；设计见[ADR025](../decisions/025-candidate-discovery.md)。

- 问题：用户需要查找并复制候选ID，面板发现性不足。
- 目标：同session只读查询、下次正常对话数量提醒、owner面板顶部动态入口。
- 非目标：自动验证/批准、跨session共享、持久化未读、OS通知、付费或收益实验。
- 验收：查询只返回当前自动candidate与当前revision；共享关闭/异session/cwd无泄露；严格有界且只读。面板鉴权、动态新增及表单不覆盖。实际包Agent通过新回执拿ID、显式验证与后续复用；负路径保留。
- 检查：先失败回归，类型/静态/相关及完整测试、固定官方兼容、包安装演练、浏览器证据、独立稳定SHA审查和当前头两平台CI。
- 状态：Issue [#53](https://github.com/wang1299/dsh-reforge/issues/53)，设计/失败回归先于实现。当前实现与检查见[验收记录](../development/T022-acceptance.md)，最终当前SHA的CI/独立评审/合并在关联PR记录；没有发布或付费验证。
