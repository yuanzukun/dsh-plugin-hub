# T002 独立评审及修复

- 目标 SHA：40984dda1b483729c4b2fed2ac810203e11e0e8a
- 基线：21a9620f4d31295c530b4e2f321ad493624b2197
- 独立评审者：AI Agent `mvp_independent_review`，只读指定 Git 提交及合成复现；不是正式 GitHub Review。
- 无 P0/P1。3项成立 P2，均按阻塞处理：
  1. verification.ts:25,119 聚合计数允许跳过原失败用例：记录用例ID与状态，要求原失败真通过且前后集合一致；增加skip/删除反例测试。
  2. service.ts:117 旧版本反例停用新版本：反馈绑定应用revision；旧版本反例只保留历史。
  3. store.ts:22,55 首次反馈阻止后续反例：按事件ID幂等追加，每应用取最新已知结果统计，unknown不冒充成功。
- 原设计证据清理P2：评审已确认闭合。
- c534488必要复审确认新库3项修复闭合，但指出旧库唯一约束和无cases报告未迁移；已补ADR-003及50f1de4迁移，独立必要复审通过，迁移回归1项通过，无新阻塞。
- 发布分支codex/t002-core从T001 squash结果重放原任务提交，src/test/package/类型与静态配置对比50f1de4无差异；公开评审记录如实区分原目标SHA与发布头映射。Issue #3，当前CI与合并状态见PR。

- 远端Windows故障修复目标29906d8062d5ec4bc80ff4a2991fc33552604c1c，基线2651e969d442d8f5e5323ee255e47ad90846d52b；native realpath比较目录身份，repoId保持、子目录拒绝。独立必要复审通过；CI run39120887699两平台9项检查通过，PR #9已squash合并。
