# dsh-screenshot

对话框下面加一个「截图」按钮：点一下，DSH 窗口收起，你拖个框，选中的那块图直接落进输入框。

<img src="icon.svg" width="72" alt="icon">

## 干什么用的

平时想让模型看屏幕上的东西，得自己开截图工具、截图、保存、再拖进输入框。这个插件把这段收成一次点击：

1. 点「截图」→ DSH 窗口最小化，屏幕上别的东西露出来
2. 整屏变暗，鼠标变十字，拖一个矩形（框边实时显示 `宽 x 高`）
3. 松手 → 只裁框住那块 → DSH 窗口弹回来 → 图片躺在输入框的附件条里

不想框？**按住 Alt 再点**，直接整屏。想反悔？右键或 `Esc`，什么都不放，也不报错。

## 要求

- **Windows 10 / 11**（抓屏走 PowerShell + GDI+，别的平台还没写）
- DSH 桌面版，`0.2.1` 及以上
- 系统自带的 Windows PowerShell 5.1 就够了，不用装 pwsh

## 安装

在 DSH 的「插件」页里添加本目录（本地目录安装）。或者由 Agent 调 `plugin_manager` 的 `install_bundle`，指向这个目录的绝对路径。

装完**刷新页面**；如果是从旧版更新，把 DSH 完全退出再打开，Host 半才会换成新代码。

## 用法细节

| 操作 | 结果 |
| --- | --- |
| 点「截图」 | 框选一块区域 |
| `Alt` + 点 | 整屏 |
| 拖动 | 框选，实时显示尺寸 |
| 右键 / `Esc` | 取消 |

成品长边超过 1920 会自动缩一档，避免把几 MB 的原图塞给模型。框选出来的图会按原样保留（不缩），除非它本身就超了 1920。

## 实现

三个文件，各管一段：

| 文件 | 职责 |
| --- | --- |
| [`client.js`](client.js) | 输入框下面那个按钮。取到图后调 `conversation.createDrafts()` + `inputActions.addAttachments()`，把 PNG 变成输入框里的待发附件 |
| [`index.js`](index.js) | Host 半。注册 `POST /dsh-screenshot/capture`，过一遍 `ctx.connection.requestRejection()` 的鉴权，再通过 Host 的 `subprocess` 服务串行跑 PowerShell，回 PNG 字节 |
| [`capture.ps1`](capture.ps1) | 真正干活的：沿进程树找到 DSH 的窗口句柄 → 最小化 → 抓虚拟桌面 → 铺一层可选区的遮罩 → 裁切/缩放 → 存 PNG → 不管成败都恢复窗口 |

几个设计取舍：

- **先抓整屏再选**，选完从那张原图上裁。所以成品里不会带上遮罩、边框、尺寸提示，也没有「截图时窗口还没最小化完」的时序问题。
- **选择器只编译一次**。C# 现编译在冷机上要十几秒，所以编译产物缓存到 `%TEMP%\dsh-screenshot\selector-v1.dll`，之后每次调用稳定在 1.5 秒上下。
- **鉴权走 DSH 自己的那套**。路由没有另开鉴权，直接用 `connection.requestRejection()`，所以只有带着本机浏览器会话 cookie 的页面能调，命令行 `curl` 过去是 401。
- 图片不落盘：Host 写到临时目录，客户端取走字节后立刻删。
- 起进程走 Host 的 `subprocess` 服务，不直接引 Node 的进程模块：可执行文件由 provider 解析，stdio 和回收也归 provider，插件手里不留裸的进程能力。

## 已知限制

- 只有 Windows。
- 多显示器且各屏缩放比不同时，坐标可能有偏差（目前按系统 DPI 处理）。
- 框选期间是全屏模态的：想截某个应用里展开的菜单，得先用快捷键把菜单调出来再点截图。
- 没有全局快捷键，入口只有输入框下那个按钮。

## 验证状态

- 框选、裁切、窗口恢复：在本机真实桌面上用合成鼠标事件跑通过，产出的图就是框住的那块。
- 取消路径：脚本退出码 2 → 路由回 409 → 前端静默复位，不弹错误。
- 鉴权：不带浏览器 cookie 直接 POST 返回 401。
- 浏览器里真实点击这一下：没有浏览器自动化手段，靠手动验证。

## English

A DSH plugin that sits under the message box. Click **Shot**, the DSH window minimizes, you drag a rectangle over the screen, and that crop lands in the composer as a draft image. `Alt` + click grabs the whole screen; right-click or `Esc` cancels.

- Windows 10 / 11 only (capture runs through PowerShell + GDI+).
- Needs DSH desktop `0.2.1` or newer; the bundled Windows PowerShell 5.1 is enough.
- Install from the DSH Plugins page by pointing it at this directory.
- The image never touches disk besides one temp file: it is served over a session-gated loopback route and the temp file is removed right after.

## License

MIT

