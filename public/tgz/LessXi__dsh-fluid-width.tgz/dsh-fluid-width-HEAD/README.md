# dsh-fluid-width

让 DeepSeek Harness（DSH）Web GUI 的聊天显示区**自适应屏幕宽度**。

## 问题

DSH Web GUI 的聊天显示区宽度由 conversation 根节点的 CSS 变量
`--dsh-chat-content-width` 决定，出厂值硬编码为 **748px**——聊天列、输入框、
提问卡片全都消费这个变量。宽屏（如 2560×1600）下中间留大片空白，显示区
看起来非常窄。

## 本插件做什么

把该变量覆盖为 **`min(100%, 2000px)`**：显示区随窗口流动，仅在超宽屏
（中心列 > 2000px，约 4K 显示器）保留封顶。

- 聊天列 / 输入框 / 提问卡片自动跟随（它们都用同一个变量）；
- 侧边栏和右侧面板的宽度不受影响，可继续用分隔条拖拽。

两条注入路径互为保险：

1. **静态覆盖**：以当前版本的根 class 加 `!important` 声明，与官方样式的
   加载顺序无关，立即生效；
2. **版本无关重写**：用 `MutationObserver` 监听 `<head>` 里注入的
   `<style>`，凡出现 `--dsh-chat-content-width:<px>` 的字面量定义就原地
   替换。DSH 升级后 class hash 变化时，路径 1 会失效，路径 2 仍能兜底。

## 安装

```sh
dsh plugin --profile web add github:LessXi/dsh-fluid-width
```

- 本插件零依赖、无 `prepare` 构建脚本，Git 安装后无需任何构建步骤；
- 安装完成后**重启 `dsh web`**（bundle 列表是启动时快照），再刷新页面。

验证：打开任意会话，缩小/拉宽浏览器窗口，聊天内容应随窗口伸缩。

## 自定义封顶

编辑 `lib/client.js` 顶部的常量：

```js
const MAX_WIDTH_PX = 2000;
```

- 改成 `100%`（连同上面的拼接）可完全流式，无任何封顶；
- 改小（如 `1200`）可让内容重新收敛。

## 卸载

```sh
dsh plugin --profile web remove dsh-fluid-width
```

然后重启 `dsh web`。

## 兼容性说明

- 目标运行面：DSH Web GUI（`dsh web`，client 半区）。插件没有 host 职责。
- 静态覆盖依赖当前版本 conversation 根节点的 CSS class
  （`.hlCKXq_root`）；若某次 DSH 升级后该 class 变化且官方样式改用
  非 px 字面量定义，两条路径都失效时，把 `ROOT_CLASS` 更新为新的
  class 即可。
- 本仓库按 DSH bundle 契约分发（`dsh.bundle.patch` → `cordis.patch.yml`），
  无需手动编辑 profile 的 `cordis.patch.yml`。

## 开发

```sh
npm run check   # node --check 语法检查 + client 半区 vm smoke test
```

`test/smoke.mjs` 用最小 DOM shim 验证：模块注册、`<style>` 注入、
官方样式到达后的原地重写、dispose 清理。

## License

MIT
