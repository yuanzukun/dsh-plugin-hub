import { readFile } from "node:fs/promises";
import vm from "node:vm";
import assert from "node:assert/strict";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const source = await readFile(path.join(root, "lib", "client.js"), "utf8");

// ---- 最小 DOM shim ----
const headChildren = [];
const observers = [];

class FakeStyle {
  constructor() {
    this.tagName = "STYLE";
    this.nodeType = 1;
    this.id = "";
    this.textContent = "";
  }
  remove() {
    const i = headChildren.indexOf(this);
    if (i >= 0) headChildren.splice(i, 1);
  }
}

function notifyChildList(added) {
  for (const ob of [...observers]) {
    for (const cb of ob.callbacks) cb([{ type: "childList", addedNodes: added }]);
  }
}

const head = {
  appendChild(el) {
    headChildren.push(el);
    notifyChildList([el]);
    return el;
  }
};

class FakeMutationObserver {
  constructor(cb) {
    this.callbacks = [cb];
    this.disconnected = false;
  }
  observe() {
    observers.push(this);
  }
  disconnect() {
    this.disconnected = true;
    const i = observers.indexOf(this);
    if (i >= 0) observers.splice(i, 1);
  }
}

const document = {
  head,
  createElement: () => new FakeStyle(),
  querySelectorAll: (sel) => (sel === "style" ? [...headChildren] : [])
};

// ---- 加载被 __ModuleLoader__ 包装的 client bundle ----
const loaded = [];
const window = { __ModuleLoader__: { load: (def) => loaded.push(def) } };
vm.runInNewContext(source, {
  window,
  document,
  MutationObserver: FakeMutationObserver,
  Object,
  Symbol
});

assert.equal(loaded.length, 1, "client bundle 恰好注册一个模块");
const def = loaded[0];
assert.equal(def.id, "dsh-fluid-width");
const plugin = def.factory(() => {
  throw new Error("unexpected require()");
});
assert.ok(Array.isArray(plugin.inject), "inject 是数组");
assert.equal(plugin.inject.length, 0, "inject 为空");
assert.equal(typeof plugin.apply, "function");

// ---- apply ----
const disposers = [];
const ctx = { effect: (fn) => { disposers.push(fn()); } };
plugin.apply(ctx);
assert.equal(disposers.length, 1, "effect 注册了 disposer");

const mine = headChildren.find((s) => s.id === "dsh-fluid-width-style");
assert.ok(mine, "注入了覆盖 <style>");
assert.match(mine.textContent, /min\(100%,\s*2000px\)\s*!important/);

// ---- 模拟官方 conversation 样式稍后到达 ----
const official = new FakeStyle();
official.textContent =
  ".hlCKXq_root{--dsh-chat-content-width:748px;--dsh-composer-card-max-width:calc(var(--dsh-chat-content-width) + 32px)}";
head.appendChild(official);
assert.doesNotMatch(official.textContent, /748px/, "官方 px 定义被重写");
assert.match(official.textContent, /--dsh-chat-content-width:min\(100%, 2000px\)/);
assert.match(
  official.textContent,
  /calc\(var\(--dsh-chat-content-width\) \+ 32px\)/,
  "派生声明不受影响"
);

// ---- 非 style 节点被忽略 ----
head.appendChild({ nodeType: 1, tagName: "SCRIPT", textContent: "x" });

// ---- dispose 清理 ----
disposers.forEach((d) => d());
assert.ok(!headChildren.includes(mine), "dispose 后覆盖 <style> 被移除");
assert.equal(observers.length, 0, "dispose 后 observer 已断开");
assert.equal(disposers[0].constructor.name, "Function");

console.log("dsh-fluid-width smoke test passed");
