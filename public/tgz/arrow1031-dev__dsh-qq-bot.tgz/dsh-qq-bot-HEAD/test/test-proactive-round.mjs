#!/usr/bin/env node
/**
 * 主动发言回合的端到端验证：不需要 DSH，不需要 QQ，也不需要等定时器。
 *
 *   node test/test-proactive-round.mjs
 *
 * 目的：把「轮到该说话 → 判断 → 触发回合 → 发送」整条链在
 * 真插件代码上跑一遍。此前这条链只有生产实例上肉眼验证过，纯函数测试盖不到
 * index.js 里那段胶水——尤其「判断模型切没切、切回没有」这种接线错误。
 *
 * 发言阶段模型有两处接线（判断阶段与回合），漏掉任何一处
 * 纯函数测试都看不出来，所以按场景各跑一遍：
 *   1. 两段式（配了 speakModel）：发言模型两次回英文拒绝语 → 被拦 → 回退判断正文 → 发出；
 *   2. 单段式（不配 speakModel）：判断正文本身就是英文拒绝语 → 被拦 → 一条都不发；
 *   3. 反向对照：判断阶段给的 message 不再参与发送（正文一律来自回合）。
 *
 * 做法：每个场景各自起假 OneBot、各自 apply、跑完各自清理；假 ctx + 真 lib/index.js，
 * 把插件注册的定时器回调抓出来手动触发，于是整轮检查是确定性的，不用 sleep 五分钟。
 */

import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import process from 'node:process';
import { startMockOneBot } from './mock-onebot.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const PKG_ROOT = path.join(here, '..');
let failures = 0;
const results = [];
function check(name, ok, detail = '') {
  results.push(ok);
  if (!ok) failures += 1;
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + name + (ok || detail === '' ? '' : ' — ' + detail));
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const textOf = (sent) => {
  const msg = (sent && Array.isArray(sent.message)) ? sent.message : [];
  const seg = msg.find((s) => s && s.type === 'text');
  return seg && seg.data && typeof seg.data.text === 'string' ? seg.data.text : '';
};

const linkPath = path.join(PKG_ROOT, 'node_modules');
let createdLink = false;
const PROFILE_MODULES = process.env.DSH_PROFILE_MODULES ?? path.join(process.env.DSH_HOME ?? path.join(os.homedir(), '.dsh'), 'profiles', 'node_modules');
if (!fs.existsSync(linkPath) && fs.existsSync(PROFILE_MODULES)) {
  fs.symlinkSync(PROFILE_MODULES, linkPath, process.platform === 'win32' ? 'junction' : 'dir');
  createdLink = true;
}
try { await import.meta.resolve('@deepseek-ai/schemastery'); }
catch {
  console.log('缺少 @deepseek-ai/schemastery —— 请先在本目录执行 npm install / pnpm install。');
  process.exit(2);
}

const logLines = [];
const realLog = console.log;
console.log = (...args) => { logLines.push(args.map(String).join(' ')); realLog(...args); };

// 假模型的两句台词：判断模型的正常 JSON、以及「整句英文拒绝语」——用来证明正文不再取自 judge。
// 一句 61 字符、一个 CJK 都没有，正好落在「> 12 字且无 CJK」这个判据里。
const JUDGE_TEXT = '那就下午三点老地方见';
const ENGLISH_REJECT = "Sorry, it looks like I can't chat about this topic right now.";

/**
 * 跑一个主动发言场景：起假 OneBot → 假 ctx + 真 lib/index.js → 手动触发那一轮检查 → 断言 → 清理。
 *
 * 每个场景的 mock / ctx / 定时器数组都是新造的，同一个进程里顺序跑多次也不会互相串味
 * （插件状态全在 apply() 的闭包里）；清理（disposers + mock.close）在本函数返回前做完。
 *
 * @param {{ label: string, judgeMessage: string, proactive?: object, verify: Function }} options
 */
async function runScenario(options) {
  const { label, judgeMessage, proactive: overrides, verify, speakReasoningOnly, hangWhenIdle } = options;
  console.log('\n场景：' + label);
  const mock = await startMockOneBot({ quiet: true });
  const disposers = [];
  const agents = new Map();
  const fakeWorkspaces = new Map();
  // 抓 proactive 的定时器：首次检查 = intervalMinutes*60000/2，远大于阈值。
  const proactiveTimers = [];
  // modelSelects：记录 agent.model.select() 的调用，用来验证「两段式切了发言模型、跑完切回去」。
  const stats = { speakCalls: 0, prompts: [], modelSelects: [], cancelCauses: [], hangWhenIdle: false, guardFn: null, handle: null };
  // 模拟插件 fiber 已经卸载：此时 ctx.timeout 会抛 INACTIVE（真 cordis 的 assertActive）。
  let timerBroken = false;
  // 只看本场景这段日志：上一个场景的「OneBot 已连接」「no-cjk」不能算数。
  const logStart = logLines.length;
  const logs = () => logLines.slice(logStart);
  const waitFor = async (fn, timeoutMs, what) => {
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      const v = await fn();
      if (v) return v;
      if (Date.now() > deadline) {
        const tail = logs().slice(-8).map((line) => '  ' + line).join('\n');
        throw new Error('等待超时：' + what + '\n已发送 ' + mock.sent.length + ' 条\n最近日志：\n' + tail);
      }
      await sleep(50);
    }
  };
  const fakeWorkspaceRegistry = {
    async resolveByPath(p) { return fakeWorkspaces.get(p); },
    async create(p, title) { const ws = { id: 'ws-' + (fakeWorkspaces.size + 1), path: p, title }; fakeWorkspaces.set(p, ws); return ws; },
    async list() { return [...fakeWorkspaces.values()]; },
  };
  // 主动发言现在走「触发回合」：followup 推一条触发消息，回合跑完后 extractReply 从
  // 读到的 assistant 文本就是「模型说的话」；这里用一个固定句子模拟发言阶段模型。
  const proactiveReply = '本鱼觉得这事儿能接一句。';
  // 主动发言现在走「触发回合」：followup 推一条触发消息，回合跑完后 extractReply 从
  // deriveMessages 里读 assistant 文本。桩必须真的把这两段都演出来，否则永远取不到回复。
  // tools 服务的桩：guard 收下回调并留在 stats 里，供「超时后是否 fail-closed」那类断言探针。
  const toolsStub = {
    guard(fn) { stats.guardFn = fn; return () => {}; },
    get() { return undefined; },
    register() {},
  };

  const fakeAgent = (sessionId) => {
    const messages = [];
    const agent = {
      sessionId,
      options: { provider: '', model: '' },
      // 真宿主里 agent.ctx 能拿到 tools 服务（访客工具闸靠它安装）。桩缺了它，
      // manager 会把 guardUnavailable 置 true，主动回合就按 fail-closed 拒绝发起——
      // 那是生产环境的正确行为，测试桩得跟上，不能反过来放松红线。
      // guard 回调存起来：D2 的回归点要能直接问「此刻这个回合放行哪些工具」。
      ctx: { get: (name) => (name === 'tools' ? toolsStub : undefined), tools: toolsStub },
      session: { deriveMessages: () => messages.slice() },
      // 两段式的「发言阶段模型」现在是切给 agent 的，桩要能记录 select 调用。
      model: {
        current: () => ({ provider: 'conv-p', model: 'conv-m' }),
        select(selection) { stats.modelSelects.push({ provider: selection.provider, model: selection.model }); },
      },
      async followup(message) {
        messages.push({ id: message.id, role: 'user', content: message.content });
        const reply = String(sessionId).includes('silent') ? '' : proactiveReply;
        if (reply !== '') messages.push({ id: 'a-' + messages.length, role: 'assistant', content: [{ type: 'text', text: reply }], source: { kind: 'model' } });
      },
      // netbag：cancel 必须被记下来（N-04 的回归点就是「超时了但没取消」）。
      cancelCalls: 0,
      // sessionId 里带 hang 的：whenIdle 永远不 resolve，用来触发 180s 超时路径。
      async whenIdle() {
        if (stats.hangWhenIdle === true) return new Promise(function () {});
      },
      cancel(cause) { this.cancelCalls += 1; stats.cancelCauses.push(cause); },
    };
    return agent;
  };

  const ctx = {
    fiber: { marker: 'plugin-fiber' },
    inject(names, callback) {
      if (Array.isArray(names) && names.includes('settings')) callback({ effect(fn) { const d = fn(); if (typeof d === 'function') disposers.push(d); return () => {}; }, settings: { configure() { return () => {}; } } });
      return () => {};
    },
    on() { return () => {}; },
    subprocess: {
      async resolveExecutable() { return process.execPath; },
      spawn(spec) {
      // 真服务内部要读 this（选容器模式），这里照做——桩要是完全不碰 this，
      // 「把方法裸传、丢了 this」这种接线错误就永远测不出来。
      // 曾经为此让线上适配器起不来、每 30 秒重试一次，而当时 148 项测试全绿。
      if (this === undefined || this === null || typeof this.resolveExecutable !== 'function') {
        throw new TypeError("Cannot read properties of undefined (reading 'selectContainmentMode')");
      }

        const child = spawn(spec.argv[0], spec.argv.slice(1), { cwd: spec.cwd, stdio: ['pipe', 'pipe', 'pipe'] });
        const done = new Promise((resolve) => child.on('close', (exitCode, signal) => resolve({ exitCode, signal })));
        return { stdin: child.stdin, stdout: child.stdout, stderr: child.stderr, done, terminate() { try { child.kill('SIGTERM'); } catch { /* ignore */ } }, waitForExit: () => done.then(() => true), _child: child };
      },
    },
    reflect: { get(name) { return name === 'workspaceRegistry' ? fakeWorkspaceRegistry : undefined; } },
    workspaceRegistry: fakeWorkspaceRegistry,
    sessionController: {
      async create(request) { return { sessionId: request.sessionId }; },
      async resolveAgent(sessionId) { if (!agents.has(sessionId)) agents.set(sessionId, fakeAgent(sessionId)); return { agent: agents.get(sessionId) }; },
    },
    timeout(cb, delay) {
      if (Number(delay) >= 30000) {
        if (timerBroken === true) throw new Error('cannot get required service "timer" in inactive context');
        proactiveTimers.push({ cb, delay: Number(delay) });
        return () => {};
      }
      const t = setTimeout(cb, delay);
      return () => clearTimeout(t);
    },
    effect(fn) { const d = fn(); if (typeof d === 'function') disposers.push(d); return () => {}; },
    tools: { register() { return () => {}; } },
    attachments: { async saveImage() { return { attachmentId: 'x', mediaType: 'image/png', bytes: 1, width: 0, height: 0 }; } },
    llm: {
      async resolveModelInfo(provider, model) { return { provider, model, inputModalities: ['text'] }; },
      async *stream(options) {
        const model = String(options.model ?? '');
        const promptText = (() => {
          const msg = Array.isArray(options.messages) && options.messages.length > 0 ? options.messages[0] : null;
          const part = msg !== null && Array.isArray(msg.content) && msg.content.length > 0 ? msg.content[0] : null;
          return part !== null && typeof part.text === 'string' ? part.text : '';
        })();
        stats.prompts.push({ model, text: promptText });
        if (model === 'judge-m') {
          yield { type: 'text-delta', index: 0, text: JSON.stringify({ speak: true, topic: '下午打球', message: judgeMessage }) };
          return;
        }
        stats.speakCalls += 1;
        // 推理型模型：正文全落在 reasoning-delta（实测 deepseek-flash 就是这样）。
        // 走 shared/stream-text.js 的兜底后，思考里的内容应当被当作发言正文发出去。
        if (speakReasoningOnly === true) {
          yield { type: 'reasoning-delta', index: 0, text: '那就下午三点老地方见' };
          return;
        }
        // 发言阶段故意返回整句英文拒绝语：证明它不会被当成正文发出去（guide 只出 JSON）。
        // 顺带模拟真实上游：text-delta 之后还会给一个 block-end（整块文本），
        // 两者只能二选一——如果被相加，同一句拒绝语会变成两遍。
        yield { type: 'text-delta', index: 0, text: ENGLISH_REJECT };
        yield { type: 'block-end', index: 0, block: { type: 'text', text: ENGLISH_REJECT } };
      },
    },
  };

  try {
    const mod = await import(pathToFileURL(path.join(PKG_ROOT, 'lib', 'index.js')).href);
    const validated = mod.Config['~standard'].validate({
      onebot: { wsUrl: mock.wsUrl, httpUrl: mock.httpUrl },
      reply: { ackAfterMs: 0 },
      proactive: {
        enabled: true,
        groups: ['33333'],
        intervalMinutes: 5,
        windowMessages: 20,
        minNewMessages: 1,
        quietHours: [],
        maxPerHour: 5,
        maxPerDay: 20,
        minGapMinutes: 0,
        provider: 'mockp',
        model: 'judge-m',
        dryRun: false,
        verbose: true,
        maxChars: 120,
        ...(overrides === undefined ? {} : overrides),
      },
    });
    check('Config 校验通过', validated.issues === undefined, JSON.stringify(validated.issues));
    if (hangWhenIdle === true) stats.hangWhenIdle = true;
    await mod.apply(ctx, validated.value);
    // 诊断出口走 WeakMap 侧信道（不是 apply 的返回值）。
    // 为什么：cordis 把 apply 的返回值当 effect 校验，返回普通对象会抛
    // `Invalid effect` 让插件装不上 —— 而这里直接调用 apply 不经 fiber.effect，
    // 那个校验跑不到，于是「测试全绿、生产全红」。
    stats.handle = mod.pluginDiagnostics(ctx);
    await waitFor(() => mock.clientCount() === 1, 10000, '适配器连上假 OneBot');
    await waitFor(() => logs().some((l) => l.includes('OneBot 已连接')), 20000, 'OneBot 已连接');
    check('适配器已连接且 OneBot 就绪', mock.clientCount() === 1 && logs().some((l) => l.includes('OneBot 已连接')));
    check('抓到了主动发言定时器', proactiveTimers.length >= 1, String(proactiveTimers.length));
    // 适配器重启（restart）也走同一个 ctx.timeout：混进来就会让下面「手动触发」打到错的东西。
    check('只抓到 1 条主动发言定时器', proactiveTimers.length === 1, String(proactiveTimers.length));

    // 造一段「有三人、最新一条是问题、时间新鲜」的群聊，绕开事件闸的各种跳过条件。
    const nowSec = Math.floor(Date.now() / 1000);
    const chat = [
      [30001, '阿七', '下午有人打球吗', 300],
      [30002, '小满', '我去，不过得三点后', 240],
      [30003, '路人', '我也想去，场地订了吗', 180],
      [30001, '阿七', '还没订，人够就订', 120],
      [30002, '小满', '那我来订，你们几点到', 60],
    ];
    for (const [index, [uid, nick, text, ago]] of chat.entries()) {
      mock.history.push({
        message_id: 900000 + index + 1, time: nowSec - ago, message_type: 'group', group_id: 33333,
        user_id: uid, sender: { user_id: uid, nickname: nick, card: '' },
        message: [{ type: 'text', data: { text } }], raw_message: text,
      });
    }

    // 手动触发那一轮检查（不用真的等三分钟）。
    const best = proactiveTimers.slice().sort((a, b) => b.delay - a.delay)[0];
    const tick = best.cb;
    // 让 tick 结束后的「排下一轮」撞上已卸载的定时器服务（B1 的回归点）。
    if (options.breakTimer === true) timerBroken = true;
    await tick();
    await verify({ mock, stats, logs, waitFor });
  } catch (error) {
    // 抛异常（多半是等待超时）也要记一条失败：只加 failures 会让汇总出现「N/N 项通过」却判失败。
    check('整个场景没有抛异常', false, error && error.message ? error.message : String(error));
    console.log('\n错误：' + (error && error.stack ? error.stack : String(error)));
  } finally {
    for (const d of disposers) { try { d(); } catch { /* ignore */ } }
    await sleep(400);
    await mock.close();
  }
}

// 顺序跑：上一个场景的清理（disposers → 适配器退出 → mock.close）做完，下一个才开新的 mock。
for (const scenario of [
  {
    label: '两段式：发言模型切给 agent 回合，回合产出即发送',
    judgeMessage: JUDGE_TEXT,
    // 两段式要求 provider + model 成对（provider 留空 = 跟随判断阶段，不启用）；兜底开关控制发言阶段的校验。
    proactive: { speakProvider: 'speak-p', speakModel: 'speak-m' },
    async verify({ mock, stats, logs, waitFor }) {
      const sentGroup = await waitFor(() => mock.sent.find((s) => Number(s.group_id) === 33333 || Number(s.target_id) === 33333), 20000, '主动发言发送');
      const text = textOf({ message: sentGroup.message });
      // 发言阶段现在由 agent 回合承担：断言点从「调了几次 llm」改成「模型切没切、切回没有」。
      check('两段式把发言模型切给了 agent', stats.modelSelects.some((x) => x.provider === 'speak-p' && x.model === 'speak-m'), JSON.stringify(stats.modelSelects));
      check('回合结束后切回了原模型', stats.modelSelects.length >= 2 && stats.modelSelects[stats.modelSelects.length - 1].model === 'conv-m', JSON.stringify(stats.modelSelects));
      // 摘要方向：旧→新。排序被删掉时这条会挂（此前只有纯函数测试，端到端漏了）。
      const judgePrompt = stats.prompts.find((item) => item.model === 'judge-m');
      const promptText = judgePrompt === undefined ? '' : judgePrompt.text;
      const oldAt = promptText.indexOf('下午有人打球吗');
      const newAt = promptText.indexOf('那我来订');
      check('判断提示词里的摘要按旧→新排列', oldAt >= 0 && newAt > oldAt, 'old@' + oldAt + ' new@' + newAt);
      check('英文拒绝语没有被发出去', !/^Sorry,/i.test(text), JSON.stringify(text.slice(0, 40)));
      check('正文来自回合产出', text.length > 0, JSON.stringify(text));
    },
  },
  {
    label: '两段式 + 推理型发言模型：旧的两段式兜底已退役，只验回合正常产出',
    judgeMessage: JUDGE_TEXT,
    speakReasoningOnly: true,
    proactive: { speakProvider: 'speak-p', speakModel: 'speak-m' },
    async verify({ mock, stats, logs, waitFor }) {
      const sentGroup = await waitFor(() => mock.sent.find((s) => Number(s.group_id) === 33333 || Number(s.target_id) === 33333), 20000, 'reasoning 兜底后的主动发言');
      const text = textOf({ message: sentGroup.message });
      check('推理型发言模型：模型切换照旧发生', stats.modelSelects.length > 0, JSON.stringify(stats.modelSelects));
      check('推理型发言模型：正文来自回合产出', text.length > 0, JSON.stringify(text));
    },
  },
  {
    label: '单段式：judge 只决定接不接，正文由回合产出（不再校验 judge 的 message）',
    judgeMessage: ENGLISH_REJECT,
    // 不设 speakProvider/speakModel = 单段模式；judge 给的英文 message 不该被当成正文发出去。
    proactive: {},
    async verify({ mock, stats, logs }) {
      // tick 已经把整轮检查 await 完了，再留一点余量给适配器的 HTTP 往返，避免「刚好还没写进去」。
      await sleep(300);
      // 判定阶段不再产出正文（A1），因此 judge 给的 message 不参与校验；
      // 单段模式 = 不切发言模型，正文完全由 agent 回合生成。
      check('单段式：没有切换发言模型', stats.modelSelects.length === 0, JSON.stringify(stats.modelSelects));
      check('单段式：正文来自回合产出（不是 judge 那句）', mock.sent.length > 0 && !/^Sorry,/i.test(textOf({ message: mock.sent[0].message })), 'sent=' + mock.sent.length);
    },
  },
  {
    label: '反向对照：judge 给的英文 message 不再参与发送（正文一律来自回合）',
    judgeMessage: ENGLISH_REJECT,
    // 与上一条同配置、只换 judge 输出：证明「不发送 judge 正文」是回合路径本身决定的，不是某次拦截碰巧。
    proactive: {},
    async verify({ mock, waitFor }) {
      const sentGroup = await waitFor(() => mock.sent.find((s) => Number(s.group_id) === 33333 || Number(s.target_id) === 33333), 20000, '主动发言发送');
      const text = textOf({ message: sentGroup.message });
      check('反向对照：无论 judge 给什么，发出的都是回合正文（且只发一条）', mock.sent.length === 1, 'sent=' + mock.sent.length);
      // A1 之后 judge 只出「接不接 + 话题」，message 字段即使写了也不会被当成正文。
      check('反向对照：发出去的不是 judge 那句英文', !/^Sorry,/i.test(text), JSON.stringify(text.slice(0, 40)));
    },
  },
  {
    label: '两段式关掉兜底：兜底开关已不影响回合路径',
    judgeMessage: JUDGE_TEXT,
    // speakFallback 曾控制「发言阶段全挂时回不回退到 judge 正文」；现在 judge 不再产出正文，
    // 这个开关对发送路径没有影响了——留着它只为兼容旧配置，不该再决定发不发。
    proactive: { speakProvider: 'speak-p', speakModel: 'speak-m' },
    async verify({ mock, stats, logs }) {
      await sleep(300);
      check('关掉兜底：仍然切了发言模型给回合', stats.modelSelects.length > 0, JSON.stringify(stats.modelSelects));
      check('关掉兜底：回合产出照常发出', mock.sent.length > 0, 'sent=' + mock.sent.length);
      check('关掉兜底：没有走已退役的回退分支', !logs().some((line) => line.includes('回退用判断模型给的正文')));
    },
  },
  {
    label: '卸载竞态：tick 回来时定时器服务已不可用（B1 回归点）',
    judgeMessage: JUDGE_TEXT,
    proactive: {},
    // 让 tick 结束后的「排下一轮」抛 INACTIVE：以前这个异常会变成 unhandled rejection，
    // timer 回调丢弃返回值，Node 24 直接 exit 1——插件重挂/升级就能带崩整个宿主。
    breakTimer: true,
    async verify({ logs }) {
      await sleep(200);
      check('排不了下一轮时只记一行日志，不把异常抛进进程', logs().some((line) => line.includes('不再排下一轮')), 'logLines=' + logs().length);
      check('进程还活着（能跑到这一行就说明没有 unhandled rejection）', true);
    },
  },
  {
    label: '超时：whenIdle 不返回时放弃本次发言，并取消残留回合（N-04 回归）',
    judgeMessage: JUDGE_TEXT,
    // idleTimeoutMs 必须放进 proactive（场景 overrides 只合并 proactive 那一层）；
    // 压到 300ms，否则这条用例要真等 180 秒。
    proactive: { idleTimeoutMs: 300 },
    // whenIdle 永不 resolve 的桩，用来触发超时路径。
    hangWhenIdle: true,
    async verify({ mock, stats, logs }) {
      await sleep(400);
      check('超时：判定为超时并放弃本次发言（没有发送）', mock.sent.length === 0, 'sent=' + mock.sent.length);
      check('超时：日志点名超时', logs().some((l) => l.indexOf('内没有结束') >= 0), logs().slice(-3).join(' | '));
      // N-04 的核心：只标记超时不够，必须把还在跑的回合取消掉，
      // 否则它会一直占住 whenIdle()，下一条用户消息会被静默丢弃。
      check('超时：真的取消了残留回合', stats.cancelCauses.length === 1, JSON.stringify(stats.cancelCauses));
      check('超时：取消时带了合法 cause（宿主签名要求闭合联合）',
        stats.cancelCauses[0] !== undefined && typeof stats.cancelCauses[0].kind === 'string', JSON.stringify(stats.cancelCauses));

      // 决策 4-A 的回归点：超时后**两份身份都不能恢复**。
      // 只看 dshAllowed 不够 —— qqgroup 的鉴权读的是 turnSpeaker（tools/index.js:483-492），
      // 而 currentSpeaker 优先读 entry.turnSpeaker（:29-31），qqgroup 又在访客白名单里直接放行。
      // 所以只把 dshAllowed 置 false 时，残留回合仍能拿恢复后的发言人快照驱动群管理动作。
      const entry = ((stats.handle !== null && stats.handle !== undefined && stats.handle.state !== undefined)
        ? stats.handle.state.convos.get('group-33333') : undefined);
      check('超时：拿得到会话条目（诊断出口可用）', entry !== undefined && entry !== null);
      if (entry !== undefined && entry !== null) {
        check('超时：turnSpeaker 仍是访客快照（没被恢复成原发言人）',
          entry.turnSpeaker !== null && entry.turnSpeaker !== undefined && entry.turnSpeaker.owner === false,
          JSON.stringify(entry.turnSpeaker));
        check('超时：dshAllowed 仍为 false（fail-closed）', entry.dshAllowed === false, String(entry.dshAllowed));
      }
      // D2 的回归点：超时后 finally 已跑完，但被 cancel 的残留回合仍在 agent 里跑。
      // 若这时把 dshAllowed 恢复成回合开始前的值（拥有者 → true），残留回合就能以拥有者身份用 DSH 工具。
      // 探针直接调 guard 回调读判定结果，比看日志可靠。
      const verdict = (stats.guardFn === null) ? null : stats.guardFn({ name: 'subagent' });
      check('超时后残留回合不能以拥有者身份用高危工具（fail-closed）',
        verdict === null || String(verdict).length > 0, 'verdict=' + String(verdict));
    },
  },
]) {
  await runScenario(scenario);
}

if (createdLink) { try { if (process.platform === 'win32') fs.rmdirSync(linkPath); else fs.unlinkSync(linkPath); } catch { /* ignore */ } }

// ─────── 契约：apply 的返回值必须能被 cordis 当 effect 收下 ───────
// cordis 的 fiber.effect 会把插件 apply 的返回值当 effect 校验：
//   函数 = dispose、null/undefined = 放行、thenable / iterator / asyncIterator = 收下，
//   **普通对象一律 throw new TypeError("Invalid effect")**。
// 单测直接调用 apply 不经 fiber.effect，所以这条校验只有真装才跑到 ——
// 曾经的 `return { state }` 让插件在生产装不上（读不到设置页模板），而全套测试 49/49 全绿。
// 判据用**源码契约**：apply 体内不得出现 `return {…}`（那是唯一会踩雷的写法）。
{
  const pluginSrc = fs.readFileSync(path.join(PKG_ROOT, 'lib', 'gateway', 'plugin.js'), 'utf8');
  // 只匹配「apply 末尾」那个位置：缩进 2 空格的 return {…}; 之后紧跟顶格的 `}`（apply 函数收尾）。
  // 注意别写成 `\n  };` —— apply 的收尾大括号是**顶格**的，写成缩进会永远不匹配（恒不触发）。
  const retPlain = /\n  return \{[^;]*\};\n\}/.test(pluginSrc);
  check('apply 不返回普通对象（否则 cordis 抛 Invalid effect，插件装不上）',
    retPlain === false, retPlain === true ? 'apply 末尾出现了 return {…}' : '');
  const mod = await import(pathToFileURL(path.join(PKG_ROOT, 'lib', 'index.js')).href);
  check('诊断出口通过 pluginDiagnostics(ctx) 侧信道取，不靠 apply 返回值',
    typeof mod.pluginDiagnostics === 'function' && pluginSrc.indexOf('DIAGNOSTICS.set(ctx') >= 0,
    typeof mod.pluginDiagnostics === 'function' ? '' : 'pluginDiagnostics 未导出');
}
const passed = results.filter(Boolean).length;
console.log('\n' + passed + '/' + results.length + ' 项通过');
if (failures > 0) { console.log('主动发言回合自测失败'); process.exit(1); }

console.log('主动发言回合自测通过');
process.exit(0);
