/**
 * Shared wire vocabulary between the Host and browser halves: the loopback
 * RPC channel, its endpoints, and the plain-JSON request/result types.
 * @module dsh-sight/config
 */

/** Dedicated, loopback-only RPC channel registered by the Host half. */
export const SIGHT_RPC_CHANNEL = '/sight'

/** Endpoints accepted by {@link SIGHT_RPC_CHANNEL}. */
export const SIGHT_RPC = {
  status: 'status',
  applyReasoning: 'applyReasoning',
  clearReasoning: 'clearReasoning',
  probeImage: 'probeImage',
  imageSupport: 'imageSupport',
  figmaMcpStatus: 'figmaMcpStatus',
  figmaMcpApply: 'figmaMcpApply',
  figmaMcpRemove: 'figmaMcpRemove',
  repoDirList: 'repoDirList',
  figwrightPluginUpdate: 'figwrightPluginUpdate',
  bridgePluginUpdate: 'bridgePluginUpdate',
} as const

/** One reasoning-effort dictionary entry rendered as a chip on the settings page. */
export interface SightReasoningDictionaryEntry {
  readonly family: string
  readonly label: string
  readonly efforts: readonly { readonly level: string; readonly wire: string }[]
}

/** One provider/model row on the settings page. */
export interface SightModelEntry {
  readonly id: string
  readonly name: string
  /**
   * Reasoning-effort levels this model actually exposes, and where they came
   * from: `adapter` = resolved from the installed adapter/catalog (e.g. the
   * official DeepSeek channel always carries off/high/max); `declared` = from a
   * `reasoningEfforts` map written in the pi-ai settings. `null` when the model
   * exposes no reasoning levels at all.
   */
  readonly reasoning: { readonly source: 'adapter' | 'declared'; readonly levels: readonly string[] } | null
  /**
   * Whether this model accepts image input, as the adapter resolves it. This is
   * the same `inputModalities` the prompt admission checks, so `false` means
   * pasting an image into this model is refused before the request is sent.
   * `null` when the adapter states no modalities at all.
   */
  readonly image: boolean | null
}

/** One configured pi-ai provider group on the settings page. */
export interface SightProviderEntry {
  readonly provider: string
  readonly name: string
  readonly models: readonly SightModelEntry[]
  readonly error: string | null
  /**
   * Whether {@link SIGHT_RPC.probeImage} applies to this group. The official
   * DeepSeek channel declares modalities in its own catalog
   * (`inputModalities`), which the probe does not write, so it is not probeable.
   */
  readonly probeable: boolean
}

/** Result of {@link SIGHT_RPC.status}. */
export interface SightStatusResult {
  readonly namespace: string
  readonly reasoningDictionary: readonly SightReasoningDictionaryEntry[]
  readonly providers: readonly SightProviderEntry[]
}

/** One model whose reasoning-effort map was written by {@link SIGHT_RPC.applyReasoning}. */
export interface SightReasoningChange {
  readonly provider: string
  readonly model: string
  readonly family: string
  readonly efforts: readonly { readonly level: string; readonly wire: string }[]
}

/**
 * One model the pass deliberately left alone. Reported so a run that writes
 * nothing explains itself instead of looking like a silent success.
 */
export interface SightReasoningSkip {
  readonly provider: string
  readonly model: string
  /**
   * `adapter` = the adapter already describes levels for it (an installed
   * catalog entry or the channel's own metadata), so the dictionary would only
   * narrow it; `declared` = the settings already carry a `reasoningEfforts` map.
   */
  readonly reason: 'adapter' | 'declared'
}

/** One channel whose write was refused; the other channels still applied. */
export interface SightReasoningFailure {
  readonly provider: string
  readonly error: string
}

/** Result of {@link SIGHT_RPC.applyReasoning}. */
export interface SightApplyReasoningResult {
  /** Models whose `reasoningEfforts` this pass wrote. */
  readonly applied: number
  /** Channels this pass wrote to. */
  readonly providers: number
  readonly changes: readonly SightReasoningChange[]
  /** Models left untouched, with why. */
  readonly skipped: readonly SightReasoningSkip[]
  /** Channels whose write the settings validator refused, with the diagnostic. */
  readonly failed: readonly SightReasoningFailure[]
}

/**
 * Request payload for {@link SIGHT_RPC.clearReasoning}: drop one model's
 * written declaration so the adapter's own resolution — an installed catalog's
 * `thinkingLevelMap` — describes it again.
 */
export interface SightReasoningClearRequest {
  readonly provider: string
  readonly model: string
}

/** Result of {@link SIGHT_RPC.clearReasoning}. */
export interface SightReasoningClearResult {
  readonly ok: boolean
  /** Diagnostic when the write was refused, or the model had no declaration. */
  readonly error: string | null
}

/**
 * What an endpoint image-capability probe concluded. `inconclusive` is a real
 * outcome, not a failure to report one: a single rejected request cannot be
 * attributed to the image unless a text-only control request over the same
 * route already succeeded, so everything unattributable lands here rather than
 * being guessed at as `rejected`.
 */
export type SightImageProbeVerdict = 'supported' | 'rejected' | 'inconclusive'

/** Request payload for {@link SIGHT_RPC.probeImage}: test one pi-ai route's endpoint. */
export interface SightImageProbeRequest {
  readonly provider: string
  readonly model: string
}

/** Result of {@link SIGHT_RPC.probeImage}. */
export interface SightImageProbeResult {
  readonly verdict: SightImageProbeVerdict
  /** The evidence behind the verdict, including the provider's own words. */
  readonly detail: string
  /** Whether `input` includes `image` *after* this probe. */
  readonly declared: boolean
}

/** Request payload for {@link SIGHT_RPC.imageSupport}: read one route's admitted modalities. */
export interface SightImageSupportRequest {
  readonly provider: string
  readonly model: string
}

/**
 * Result of {@link SIGHT_RPC.imageSupport}: the same `inputModalities` the
 * prompt admission reads, so `true` means an image will be accepted. `null` when
 * the adapter states no modalities at all (which admission treats as refusal).
 */
export interface SightImageSupportResult {
  readonly image: boolean | null
}

/**
 * Status of the Figma MCP bridge on the settings page. The bridge runs the
 * `figma-ui-mcp` server over localhost — no token, no proxy, no Figma REST API.
 */
export interface SightFigmaMcpStatusResult {
  /** Design-to-code (local plugin bridge, read-only) status. */
  readonly read: SightFigmaModeStatus
  /** AI-driven design (plugin bridge) status. */
  readonly write: SightFigmaModeStatus
  /** The `cordis.patch.yml` absolute path (for the "restart to apply" hint). */
  readonly patchPath: string
  /** Profile name the patch belongs to (e.g. `desktop`). */
  readonly profile: string
  /** Any error reading the patch file (e.g. parse failure). */
  readonly error: string | null
}

/** Request payload for {@link SIGHT_RPC.figmaMcpApply}. */
export interface SightFigmaMcpApplyRequest {
  /** Which capability to configure: 'read' (plugin-based design-to-code) or 'write' (plugin-bridge AI design). */
  readonly mode: 'read' | 'write'
  /** Read mode engine selection; defaults to 'figma-ui-mcp' when omitted. */
  readonly backend?: SightReadBackend
  /** Read mode grounding directory for the figwright engine (absolute local path or empty). */
  readonly repoDir?: string
  /** Legacy fields accepted for wire compatibility but ignored in read mode. */
  readonly token?: string
  readonly proxy?: string
}

/** Request payload for {@link SIGHT_RPC.figmaMcpRemove}. */
export interface SightFigmaMcpRemoveRequest {
  /** Which capability to remove. */
  readonly mode: 'read' | 'write'
}

/** Read-only design-to-code backend engine behind the read mode facade. */
export type SightReadBackend = 'figma-ui-mcp' | 'figwright'

/** Status of one Figma MCP capability. */
export interface SightFigmaModeStatus {
  /** Whether the capability's row exists in `cordis.patch.yml`. */
  readonly configured: boolean
  /** Legacy migration signal: whether an old REST row still carries a token. */
  readonly hasToken: boolean
  /** Absolute path of the shared Figma plugin manifest, when available. */
  readonly manifestPath: string | null
  /** Active read backend engine ('figma-ui-mcp' when no state file exists yet). */
  readonly backend: SightReadBackend
  /** Local repo directory the figwright engine may scan (read-only, never uploaded). */
  readonly repoDir: string | null
  /** Locally extracted Figwright plugin (release zip, kept at the latest copy only). */
  readonly figwrightPlugin: SightFigwrightPluginInfo
  /** Locally patched Figma UI MCP Bridge copy (per-file session routing). */
  readonly bridgePlugin: SightBridgePluginInfo
  /** Generated figma-ui-mcp entry whose http-proxy keeps `sessionId` intact. */
  readonly bridgeServer: SightBridgeServerInfo
}

/** Result of {@link SIGHT_RPC.figmaMcpApply} / {@link SIGHT_RPC.figmaMcpRemove}. */
export interface SightFigmaMcpWriteResult {
  readonly ok: boolean
  readonly patchPath: string
  readonly error: string | null
}

/** Request payload for {@link SIGHT_RPC.repoDirList} (omit `path` to start at the home directory). */
export interface SightRepoDirListRequest {
  readonly path?: string
}

/** One host-side directory listing for the repoDir picker (absolute paths). */
export interface SightDirListing {
  /** Directory that was listed. */
  readonly path: string
  /** Parent directory, or null when already at the filesystem root. */
  readonly parent: string | null
  /** Subdirectories as absolute paths (dot-directories omitted, sorted). */
  readonly dirs: readonly string[]
  readonly error: string | null
}

/** Locally extracted Figwright plugin (release zip, kept at the latest copy only). */
export interface SightFigwrightPluginInfo {
  /** Release tag of the installed copy, e.g. "v0.5.0"; null when not installed. */
  readonly installedTag: string | null
  /** Absolute path of the extracted manifest.json; null when not installed. */
  readonly manifestPath: string | null
}

/** Result of {@link SIGHT_RPC.figwrightPluginUpdate}. */
export interface SightFigwrightPluginUpdateResult {
  readonly ok: boolean
  /** True when the already-installed copy already matches the latest GitHub release. */
  readonly upToDate: boolean
  readonly tag: string | null
  readonly manifestPath: string | null
  readonly error: string | null
}

/**
 * Locally managed Figma UI MCP Bridge plugin copy: the upstream plugin plus the
 * per-file session patch that gives every open Figma file its own bridge
 * session (without it, all files share one queue and a write can land in the
 * wrong file).
 */
export interface SightBridgePluginInfo {
  /** True when the managed copy carries the current patch revision. */
  readonly patched: boolean
  /** `figma-ui-mcp` package version the copy was built from; null when unknown. */
  readonly upstreamVersion: string | null
  /** Absolute path of the copy's `manifest.json`; null when no copy exists. */
  readonly manifestPath: string | null
  /** Why the copy could not be (re)built — e.g. a moved upstream anchor. Null when healthy. */
  readonly error: string | null
}

/**
 * Generated entry for the upstream figma-ui-mcp server. Its http-proxy forwards
 * `sessionId`, which the package's own proxy drops — without it a pinned file is
 * ignored whenever another process already owns the bridge.
 */
export interface SightBridgeServerInfo {
  /** True when the generated entry carries the current patch revision. */
  readonly patched: boolean
  /** Absolute path of the generated entry; null when it could not be written. */
  readonly entryPath: string | null
  /** Why generation failed (upstream layout change); null when healthy. */
  readonly error: string | null
}

/** Result of {@link SIGHT_RPC.bridgePluginUpdate}. */
export interface SightBridgePluginUpdateResult extends SightBridgePluginInfo {
  readonly ok: boolean
  /** State of the generated figma-ui-mcp entry (http-proxy sessionId patch). */
  readonly bridgeServer: SightBridgeServerInfo
}
