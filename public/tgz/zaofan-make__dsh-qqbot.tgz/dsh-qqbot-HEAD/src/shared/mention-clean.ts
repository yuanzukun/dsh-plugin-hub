/**
 * 入站 @bot 长 id 清洗(2026-09-11 主人要求省 token):
 * QQ 群消息里 @bot 时, content 会带 `<@botOpenid>`(32 位 hex 的 bot openid),
 * 原样喂 LLM 每条都耗一截 token(当前消息 + 历史折叠都带)。
 * 策略:
 *  ① 从 mentions 数组(is_you === true)拿 bot 自身 id → 精确替换成短标记 `@bot`;
 *  ② 无 mentions 元数据且 wasMentioned 时, 若 content 里恰好只有 1 个 @ 标记
 *     (群聊 @bot 消息通常只 @ 自己) → 兜底替换成 `@bot`;
 *  ③ 多个 @ 标记且无法区分 → 不动(避免误伤 @ 其他群友, 那些有语义)。
 * 只清入站, 出站 AI 回复里的 <@对方openid>(用于 @ 人)原样保留。
 */

export interface MentionLike {
  id?: string;
  is_you?: boolean;
  is_bot?: boolean;
}

export function replaceBotMention(
  content: string | undefined | null,
  mentions?: MentionLike[] | null,
  wasMentioned?: boolean,
): string {
  const text = String(content ?? '');
  if (!text) return text;

  // ① mentions 精确匹配(is_you → bot 自身 openid)
  const botIds: string[] = [];
  if (Array.isArray(mentions)) {
    for (const m of mentions) {
      if (m?.is_you && m.id) botIds.push(m.id);
    }
  }
  if (botIds.length > 0) {
    let out = text;
    for (const bid of botIds) {
      try {
        out = out.replace(new RegExp(`<@!?${bid}>`, 'g'), '@bot');
      } catch { /* 非法 id 跳过 */ }
    }
    return out;
  }

  // ② 无 mentions 元数据 + wasMentioned + 恰好 1 个 @ 标记 → 兜底替换
  if (wasMentioned) {
    const all = [...text.matchAll(/<@!?([A-Za-z0-9]+)>/g)];
    if (all.length === 1) return text.replace(/<@!?[A-Za-z0-9]+>/g, '@bot');
  }

  return text;
}

/**
 * 这条消息 @ 的是**别人**（不是她）吗？
 *
 * 2026-09-15 主人修正过一次语义："**不是**没人@她的时候降低评分, 是**有人@别人**的时候降低评分"。
 *   · 没被 @ ≠ 不该回话 —— 那恰恰是她该主动挑话插的常态，扣分会把她变成"等点名才说话"；
 *   · 真正该扣的是"这句 @ 的是别人"：那轮对话的方向是那个人，她基本不该插嘴。
 *
 * 为什么用 QQ 的 mentions 元数据而不是正文里的 `@某某` 字样：
 *   正文里 @ 别人的标记形式不固定，而 mentions 是平台给的权威列表。
 *   ⚠️ 两个平台细节：① 她被 @ 时（GROUP_AT_MESSAGE_CREATE）QQ 的 mentions **不含 bot 自身**，
 *   所以要先看 wasMentioned；② 没被 @ 时（GROUP_MESSAGE_CREATE）mentions = 这条 @ 的全部人。
 */
export function mentionsOthers(mentions: MentionLike[] | null | undefined, wasMentioned: boolean): boolean {
  if (wasMentioned) return false;                          // @ 的就是她 → 走"必回"那条路，不扣
  if (!Array.isArray(mentions) || mentions.length === 0) return false;
  return mentions.some((m) => m && m.is_you !== true);
}
