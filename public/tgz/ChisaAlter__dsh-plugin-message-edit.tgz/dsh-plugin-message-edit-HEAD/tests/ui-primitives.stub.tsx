import type { ReactNode } from 'react'

export function IconEditOutline16() {
  return <span aria-hidden="true">edit</span>
}

export function Tooltip({ children }: { children: ReactNode }) {
  return <>{children}</>
}
