// @vitest-environment jsdom
import { describe, expect, it, vi } from 'vitest'
import type { ClientContext, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type { MessageEditInjected } from '../src/client/slots.ts'
import { apply, inject } from '../src/client/index.ts'
import { apply as nodeApply } from '../src/index.ts'

import type {} from '../src/client/host-contract.ts'

const sid = (value: string): SessionId => value as SessionId

function bench() {
  const calls: { method: string; args: unknown[] }[] = []
  const drafts: Array<{ sessionId: string; text: string }> = []
  const notices: Array<{ sessionId: string; message: string }> = []
  const entries: Array<{
    options: Record<string, unknown>
    inject: ((sessionId: SessionId) => MessageEditInjected) | undefined
  }> = []
  const disposers: Array<() => void> = []

  const sessions = {
    fork: vi.fn(async (opts: { sessionId: SessionId; beforeSeq?: number }) => {
      calls.push({ method: 'fork', args: [opts] })
      return sid('child-1')
    }),
    open: vi.fn((id: SessionId) => { calls.push({ method: 'open', args: [id] }) }),
    scope: vi.fn((id: SessionId) => ({ sessionId: id })),
  }
  const locale = {
    register: vi.fn(() => vi.fn()),
  }
  const conversation = {
    input: {
      for: vi.fn((scope: { sessionId: SessionId }) => ({
        setDraft: (text: string) => { drafts.push({ sessionId: scope.sessionId, text }) },
        notify: (level: 'info' | 'error', message: string) => {
          notices.push({ sessionId: scope.sessionId, message: `${level}:${message}` })
        },
      })),
    },
  }
  const slots = {
    require: vi.fn(),
    inject: vi.fn((_name: string, register: () => () => void) => {
      const dispose = register()
      disposers.push(dispose)
      return dispose
    }),
    register: vi.fn((options: Record<string, unknown>) => {
      const entry = {
        options,
        inject: options.inject as ((sessionId: SessionId) => MessageEditInjected) | undefined,
      }
      entries.push(entry)
      return () => {
        const index = entries.indexOf(entry)
        if (index >= 0) entries.splice(index, 1)
      }
    }),
  }
  const ctx = {
    sessions,
    locale,
    conversation,
    slots,
    effect: vi.fn((install: () => (() => void) | void) => {
      const dispose = install()
      if (dispose !== undefined) disposers.push(dispose)
      return dispose
    }),
  } as unknown as ClientContext

  apply(ctx)
  return {
    calls,
    drafts,
    notices,
    sessions,
    locale,
    slots,
    entry: () => entries[0],
    dispose: () => {
      for (const dispose of [...disposers].reverse()) dispose()
    },
    reload: () => apply(ctx),
  }
}

describe('message-edit browser plugin', () => {
  it('declares the services required by its browser half', () => {
    expect(inject).toEqual(['slots', 'sessions', 'conversation', 'locale'])
  })

  it('requires the user-action slot before registering browser behavior', () => {
    const b = bench()
    expect(b.slots.require).toHaveBeenCalledWith('conversation.chat.user-actions')
    expect(b.slots.require.mock.invocationCallOrder[0]).toBeLessThan(
      b.slots.inject.mock.invocationCallOrder[0]!,
    )
  })

  it('registers the edit entry with the documented id, order, and locale', () => {
    const b = bench()
    expect(b.entry()?.options).toMatchObject({
      name: 'conversation.chat.user-actions',
      id: 'edit',
      order: 10,
      locale: 'messageEdit',
    })
    expect(b.entry()?.inject).toBeTypeOf('function')
  })

  it('forks with beforeSeq, opens the child, and prefills its draft', async () => {
    const b = bench()
    await b.entry()!.inject!(sid('s1')).edit(7, 'revised prompt')
    expect(b.calls).toEqual([
      { method: 'fork', args: [{ sessionId: 's1', beforeSeq: 7, increaseTitle: true }] },
      { method: 'open', args: ['child-1'] },
    ])
    expect(b.drafts).toEqual([{ sessionId: 'child-1', text: 'revised prompt' }])
  })

  it('rejects loudly when the child scope cannot be resolved', async () => {
    const b = bench()
    b.sessions.scope.mockReturnValue(undefined as never)
    await expect(b.entry()!.inject!(sid('s1')).edit(7, 'text')).rejects.toThrow(/child scope unavailable/)
    expect(b.drafts).toHaveLength(0)
  })

  it('notifies through the source Session input facade', () => {
    const b = bench()
    b.entry()!.inject!(sid('s1')).notify('boom')
    expect(b.notices).toEqual([{ sessionId: 's1', message: 'error:boom' }])
  })

  it('withdraws the registration through its disposer', () => {
    const b = bench()
    b.dispose()
    expect(b.entry()).toBeUndefined()
  })

  it('re-registers cleanly after disposal', () => {
    const b = bench()
    b.dispose()
    b.reload()
    expect(b.entry()?.options).toMatchObject({ id: 'edit' })
  })

  it('registers both locale dictionaries', () => {
    const b = bench()
    expect(b.locale.register).toHaveBeenCalledWith('messageEdit', expect.objectContaining({ zh: expect.any(Object), en: expect.any(Object) }))
  })

  it('disables itself without registering anything on a legacy slot runtime', () => {
    const error = vi.spyOn(console, 'error').mockImplementation(() => undefined)
    const entries: unknown[] = []
    const ctx = {
      slots: {
        inject: vi.fn(() => entries.push('injected')),
      },
      effect: vi.fn(),
    } as unknown as ClientContext

    expect(() => apply(ctx)).not.toThrow()
    expect(entries).toEqual([])
    expect(ctx.effect).not.toHaveBeenCalled()
    expect(error).toHaveBeenCalledWith(expect.stringContaining('plugin disabled'))
  })

  it('fails before side effects when the declared slot is unavailable', () => {
    const b = bench()
    b.dispose()
    b.slots.require.mockImplementation(() => { throw new Error('slot unavailable') })
    expect(() => b.reload()).toThrow('slot unavailable')
    expect(b.entry()).toBeUndefined()
  })

  it('the node half stays loadable on legacy hosts', () => {
    expect(() => { nodeApply() }).not.toThrow()
  })
})
