import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { MessageEditAction } from './MessageEditAction.tsx';
export type { MessageEditActionProps, MessageEditInjected } from './slots.ts';
export type { MessageEditKey } from './locales.ts';
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
