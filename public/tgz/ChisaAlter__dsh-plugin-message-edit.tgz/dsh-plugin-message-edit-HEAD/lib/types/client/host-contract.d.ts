/** Host capabilities required by this plugin but not present in older dsh type releases. */
import type { ConversationSnapshot, SessionId } from '@deepseek-ai/dsh-client-runtime/client';
/** Content passed by the user-message action slot. */
export type UserActionContentBlock = ConversationSnapshot['nodes'][number] extends infer Node ? Node extends {
    kind: 'user';
    content: infer Content extends readonly unknown[];
} ? Content[number] : never : never;
/** Owner currency supplied by a compatible ui-conversation host. */
export interface UserActionOwnerProps {
    seq: number;
    content: readonly UserActionContentBlock[];
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        'conversation.chat.user-actions': {
            kind: 'list';
            scope: 'session';
            owner: UserActionOwnerProps;
        };
    }
}
/** Runtime slot API added with the named host-feature contract. */
export interface CompatibleSlots {
    require(key: 'conversation.chat.user-actions'): void;
}
/** Narrow capability used instead of widening the installed runtime package globally. */
export interface ForkBeforeSessions {
    fork(options: {
        sessionId: SessionId;
        beforeSeq: number;
        increaseTitle?: boolean;
    }): Promise<SessionId>;
    open(sessionId: SessionId): void;
}
