/** `messageEdit` namespace dictionaries. */
export declare const zh: {
    'action.edit': string;
    'action.running': string;
    'action.unsupported': string;
    'action.pending': string;
    'error.generic': string;
};
export type MessageEditKey = keyof typeof zh;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        messageEdit: MessageEditKey;
    }
}
export declare const en: {
    'action.edit': string;
    'action.running': string;
    'action.unsupported': string;
    'action.pending': string;
    'error.generic': string;
};
