import type { MessageEditActionProps } from './slots.ts';
export declare function MessageEditAction({ seq, content, edit, notify, useSession, t }: MessageEditActionProps): import("react").JSX.Element | null;
