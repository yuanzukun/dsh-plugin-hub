# dsh-plugin-message-edit

[English](README.md) | 中文

DeepSeek Harness Web 插件，为最新一条用户消息增加“编辑并重新发送”操作。插件会在该消息所在轮次之前创建子会话，打开子会话，并将原文恢复到输入框。源会话保持不变，子会话不包含旧消息及其旧回答。

> [!IMPORTANT]
> 本插件要求宿主提供下列具名能力。兼容的新宿主会在激活前拒绝缺失能力的插件；尚不识别兼容性声明的旧宿主会在浏览器端安全禁用插件，因此不会产生错误的完整历史分支。当前公开的 `0.1.0-rc.6` 宿主不提供此功能。

## 宿主能力要求

宿主必须同时提供：

- `conversation.chat.user-actions`
- `session.fork.beforeSeq`
- `session.fork.blank`

插件 manifest 精确声明这些能力 ID。兼容宿主在安装和浏览器组合阶段对缺失能力采用失败关闭；浏览器入口注册前还会检查插槽 API。

## 功能行为

- 仅最新一条已提交的用户消息显示铅笔按钮。
- 点击铅笔不会立即发送。
- 子会话在目标消息所在轮次之前分支。
- 原文会恢复到子会话输入框，等待用户修改。
- 会话仍在生成或消息包含非文本块时，操作不可用并显示原因。
- 分支请求期间锁定按钮，避免重复点击。
- 分支失败时保留源会话选择，并在输入框显示本地化错误提示。

## 安装

当 DSH 构建提供全部所需宿主能力时，可在**设置 > 插件**中安装。手动安装等价于：

```sh
dsh plugin --profile web add github:ChisaAlter/dsh-plugin-message-edit#<commit-sha>
```

仓库会提交 `lib/`，并且不定义安装生命周期脚本，因此 GitHub 安装不需要 `allowBuilds` 例外授权。

## 开发验证

需要 Node.js 22.19 或更高版本，以及 pnpm 11.7.0。

```sh
pnpm install --frozen-lockfile
pnpm verify
pnpm pack:check
```

`pnpm verify` 会执行严格 TypeScript 检查、21 个行为测试、干净的生产构建和发布产物校验。

`v0.1.0` 候选版本已通过 GitHub commit `0100468b17ffe838cbcb2facd250192476a28171` 安装到隔离的兼容 Web profile。启动图只包含外部插件；编辑第一条用户消息会创建空子会话并恢复原文草稿；源会话保持不变；卸载后操作按钮和启动图条目均消失。

## 发布步骤

1. 在干净检出中执行 `pnpm verify` 和 `pnpm pack:check`。
2. 提交重新生成的 `lib/`、`pnpm-lock.yaml` 和源码改动。
3. 确认 Node 22 和 Node 24 的 CI 均通过。
4. 在提供全部声明能力的宿主上按 commit SHA 测试安装和卸载。
5. 创建与 `package.json` 版本一致的 tag 和 Release。

桌面市场按 commit SHA 安装，不要求 Release 附件。

阻断检查项见 [RELEASING.md](RELEASING.md)。

## 限制

- 仅支持纯文本消息；图片及其他非文本消息不可编辑。
- 当前回答结束后才能编辑。
- 仅 Chat 视图提供此操作。
- 插件依赖宿主核心变更，无法通过浏览器代码为旧宿主补齐。

## 许可证

MIT
