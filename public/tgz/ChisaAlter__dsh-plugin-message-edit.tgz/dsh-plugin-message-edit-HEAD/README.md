# dsh-plugin-message-edit

English | [中文](README.zh.md)

A DeepSeek Harness web plugin that adds **Edit and resend** to the latest user message. It creates a child session immediately before that message, opens the child, and restores the original text to the composer. The source session remains unchanged, and the old message and old assistant response are not included in the child.

> [!IMPORTANT]
> This plugin requires the named host capabilities below. Compatible DSH hosts reject missing capabilities before activation. Legacy hosts that do not implement the compatibility manifest safely leave the browser plugin disabled, so they cannot create an incorrect full-history fork. The current public `0.1.0-rc.6` host does not provide this feature.

## Required host capabilities

The host must provide all of the following:

- `conversation.chat.user-actions`
- `session.fork.beforeSeq`
- `session.fork.blank`

The manifest declares these exact feature IDs. Installation and browser composition fail closed on a compatible host when any requirement is missing; the browser half also checks the slot API before registering.

## Behavior

- Only the newest committed user message shows the pencil action.
- Clicking the pencil does not send immediately.
- A child session is forked before the selected message's turn.
- The original text is restored to the child composer for editing.
- Running sessions and messages containing non-text blocks show an unavailable action with a reason.
- A pending fork locks the action against duplicate clicks.
- A failed fork leaves the source selected and reports a localized composer notice.

## Installation

Install it from **Settings > Plugins** when your DSH build exposes all required host capabilities. Manual installation is equivalent to:

```sh
dsh plugin --profile web add github:ChisaAlter/dsh-plugin-message-edit#<commit-sha>
```

The repository commits `lib/` and defines no lifecycle build scripts, so GitHub installation does not require an `allowBuilds` exception.

## Development

Requires Node.js 22.19 or later and pnpm 11.7.0.

```sh
pnpm install --frozen-lockfile
pnpm verify
pnpm pack:check
```

`pnpm verify` runs strict TypeScript checking, 21 behavior tests, a clean production build, and release-artifact validation.

The `v0.1.0` release candidate was installed from GitHub commit `0100468b17ffe838cbcb2facd250192476a28171` into an isolated compatible Web profile. The boot graph contained only the external plugin, editing the first user turn created an empty child with the original text as a draft, the source session stayed unchanged, and uninstall removed both the action and the boot entry.

## Publishing

1. Run `pnpm verify` and `pnpm pack:check` from a clean checkout.
2. Commit the regenerated `lib/`, `pnpm-lock.yaml`, and source changes.
3. Confirm CI passes on Node 22 and Node 24.
4. Test install and uninstall by commit SHA on a host that exposes every declared capability.
5. Tag and release the same version as `package.json`.

The desktop marketplace installs by commit SHA and does not require a release asset.

See [RELEASING.md](RELEASING.md) for the blocking checklist.

## Limitations

- Text-only messages can be edited. Image and other non-text messages are unavailable.
- Editing waits for the current response to finish.
- The action is available in Chat view only.
- The plugin requires host changes and cannot polyfill them from browser code.

## License

MIT
