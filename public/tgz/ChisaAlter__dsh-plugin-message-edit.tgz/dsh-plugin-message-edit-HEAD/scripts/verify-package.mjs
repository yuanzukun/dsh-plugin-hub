import { access, readFile, readdir } from 'node:fs/promises'
import { constants } from 'node:fs'

const root = new URL('../', import.meta.url)
const pkg = JSON.parse(await readFile(new URL('package.json', root), 'utf8'))
const patch = await readFile(new URL('cordis.patch.yml', root), 'utf8')
const client = await readFile(new URL('lib/client.js', root), 'utf8')

const required = [
  'lib/index.js',
  'lib/client.js',
  'lib/types/index.d.ts',
  'lib/types/client/index.d.ts',
  'cordis.patch.yml',
]
await Promise.all(required.map(path => access(new URL(path, root), constants.R_OK)))

if (pkg.dsh?.bundle?.patch !== './cordis.patch.yml') {
  throw new Error('package.json must expose dsh.bundle.patch')
}
if (pkg.dsh?.client?.platform !== 'web') {
  throw new Error('package.json must declare a web client')
}
if (!patch.includes(`name: ${pkg.name}`)) {
  throw new Error('cordis.patch.yml must mount the package by its exact name')
}
if (!client.includes('window.__ModuleLoader__.load') || !client.includes(`id: "${pkg.name}"`)) {
  throw new Error('lib/client.js is not a dsh closure-factory bundle')
}
const requiredFeatures = pkg.dsh?.compatibility?.features
if (!Array.isArray(requiredFeatures) || requiredFeatures.length === 0
  || requiredFeatures.some(feature => typeof feature !== 'string')) {
  throw new Error('package.json must declare non-empty dsh.compatibility.features')
}
if (!client.includes('slots.require')
  || !client.includes('conversation.chat.user-actions')) {
  throw new Error('Browser entry must fail closed when the host lacks the required slot API')
}
if (Object.values({ ...pkg.dependencies, ...pkg.peerDependencies, ...pkg.devDependencies })
  .some(value => String(value).startsWith('workspace:'))) {
  throw new Error('standalone package contains a workspace dependency')
}
if (pkg.scripts?.prepare !== undefined || pkg.scripts?.preinstall !== undefined || pkg.scripts?.postinstall !== undefined) {
  throw new Error('GitHub marketplace package must install without lifecycle scripts')
}

const sourceFiles = await readdir(new URL('src', root), { recursive: true })
if (sourceFiles.some(path => path.includes('..'))) {
  throw new Error('invalid source path')
}

console.log(`verified ${pkg.name}@${pkg.version}: ${required.length} release artifacts, no install scripts`)
