# Release checklist

## Hard compatibility gate

The plugin declares and requires:

- [x] `conversation.chat.user-actions` in `@deepseek-ai/dsh-client-ui-conversation`
- [x] `session.fork.beforeSeq` in the client and host fork contract
- [x] `session.fork.blank` reconciliation before the first turn
- [x] install-time and browser boot-graph rejection for missing named features
- [x] a browser integration test proving the child excludes the edited turn

Hosts that understand `dsh.compatibility.features` reject the plugin before activation when a feature is absent. Older hosts safely disable the browser half when the required slot API is unavailable.

## Repository gate

- [x] `package.json` is at the repository root.
- [x] The package name and `cordis.patch.yml` row both use `dsh-plugin-message-edit`.
- [x] `lib/` is committed and matches source.
- [x] No `prepare`, `preinstall`, or `postinstall` script exists.
- [x] `pnpm install --frozen-lockfile` succeeds from a clean checkout.
- [x] `pnpm verify` passes with 21 tests.
- [x] `pnpm pack:check` contains only expected runtime files and documentation.
- [x] Installation was tested from commit `0100468b17ffe838cbcb2facd250192476a28171`.
- [x] Uninstall removes the action and does not affect conversation rendering.

## GitHub gate

- [x] Repository is public at `ChisaAlter/dsh-plugin-message-edit`.
- [x] Default branch contains the root `package.json` and committed `lib/`.
- [x] CI passes on Node 22 and Node 24.
- [ ] Add the `dsh-plugin`, `deepseek-harness`, `conversation`, and `productivity` topics.
- [ ] Tag `v0.1.0` and create a GitHub Release matching `package.json`.
