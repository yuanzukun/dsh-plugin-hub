import type { ClientContext, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import { MessageEditAction } from './MessageEditAction.tsx'
import type { CompatibleSlots, ForkBeforeSessions } from './host-contract.ts'
import type { MessageEditInjected } from './slots.ts'
import { en, zh } from './locales.ts'

export { MessageEditAction } from './MessageEditAction.tsx'
export type { MessageEditActionProps, MessageEditInjected } from './slots.ts'
export type { MessageEditKey } from './locales.ts'

const NS = 'messageEdit'

export const inject = ['slots', 'sessions', 'conversation', 'locale']

export function apply(ctx: ClientContext): void {
  const slots = ctx.slots as unknown as Partial<CompatibleSlots>
  if (typeof slots.require !== 'function') {
    console.error(
      'dsh-plugin-message-edit requires a newer dsh host with the conversation.chat.user-actions feature; plugin disabled',
    )
    return
  }
  slots.require('conversation.chat.user-actions')

  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'message-edit: dictionaries')

  ctx.slots.inject('conversation.chat.user-actions', () => ctx.slots.register({
    name: 'conversation.chat.user-actions',
    id: 'edit',
    order: 10,
    locale: NS,
    inject: (sessionId): MessageEditInjected => ({
      edit: async (seq, text) => {
        const sessions = ctx.sessions as unknown as ForkBeforeSessions
        const childId = await sessions.fork({ sessionId: sessionId as SessionId, beforeSeq: seq, increaseTitle: true })
        sessions.open(childId)
        const scope = ctx.sessions.scope(childId)
        if (scope === undefined) throw new Error(`message edit child scope unavailable: ${childId}`)
        ctx.conversation.input.for(scope).setDraft(text)
      },
      notify: (message) => {
        const scope = ctx.sessions.scope(sessionId)
        if (scope !== undefined) ctx.conversation.input.for(scope).notify('error', message)
      },
    }),
  }, MessageEditAction))
}
