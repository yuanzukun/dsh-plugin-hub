import { useCallback, useEffect, useId, useRef, useState } from 'react'
import { IconEditOutline16, Tooltip } from '@deepseek-ai/dsh-client-ui-primitives'
import type { MessageEditActionProps } from './slots.ts'
import css from './MessageEditAction.module.css'

export function MessageEditAction({ seq, content, edit, notify, useSession, t }: MessageEditActionProps) {
  const latest = useSession(snapshot => snapshot.nodes.findLast(node => node.kind === 'user')?.seq === seq)
  const running = useSession(snapshot => snapshot.running)
  const [pending, setPending] = useState(false)
  const alive = useRef(true)
  const reasonId = useId()

  useEffect(() => () => { alive.current = false }, [])

  const textOnly = content.every(block => block.type === 'text')
  const text = textOnly
    ? content.map(block => block.type === 'text' ? block.text : '').join('')
    : ''
  const unavailable = running || !textOnly || pending
  const label = pending
    ? t('action.pending')
    : running
      ? t('action.running')
      : !textOnly
        ? t('action.unsupported')
        : t('action.edit')

  const onEdit = useCallback(() => {
    if (unavailable) return
    setPending(true)
    void edit(seq, text).catch(() => {
      notify(t('error.generic'))
    }).finally(() => {
      if (alive.current) setPending(false)
    })
  }, [edit, notify, seq, t, text, unavailable])

  if (!latest) return null
  return (
    <>
      <Tooltip label={label} side="bottom">
        <button
          type="button"
          className={css.action}
          aria-label={t('action.edit')}
          aria-disabled={unavailable || undefined}
          aria-describedby={unavailable ? reasonId : undefined}
          data-unavailable={unavailable || undefined}
          onClick={unavailable ? undefined : onEdit}
        >
          <IconEditOutline16 />
        </button>
      </Tooltip>
      {unavailable && <span id={reasonId} className={css.visuallyHidden}>{label}</span>}
    </>
  )
}
