import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type {} from './host-contract.ts'
import type {} from './locales.ts'

export interface MessageEditInjected {
  edit: (seq: number, text: string) => Promise<void>
  notify: (message: string) => void
}

export type MessageEditActionProps =
  PropsRuntime<'conversation.chat.user-actions'>
  & InjectFace<MessageEditInjected>
  & PropsLocale<'messageEdit'>
