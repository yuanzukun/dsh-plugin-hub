/** Host half for the dual-face dsh plugin. */

export const name = 'message-edit'

/** Compatibility is enforced from the package manifest before this half activates. */
export function apply(): void {}
