# dsh-thinking-effort

为 [DSH（DeepSeek Harness）](https://github.com/deepseek-ai/deepseek-harness) 的 `llm-pi-ai` 第三方模型补充可配置的思考强度档位，并设置子 agent 的默认思考强度。

[![npm version](https://img.shields.io/npm/v/@hytime/dsh-thinking-effort)](https://www.npmjs.com/package/@hytime/dsh-thinking-effort)
[![npm downloads](https://img.shields.io/npm/dm/@hytime/dsh-thinking-effort)](https://www.npmjs.com/package/@hytime/dsh-thinking-effort)
[![GitHub license](https://img.shields.io/github/license/hytime/dsh-thinking-effort)](https://github.com/hytime/dsh-thinking-effort/blob/main/LICENSE)

- [English README](./README.md)
- [日本語 README](./README.ja.md)
- [한국어 README](./README.ko.md)
- [安装指南](./docs/INSTALL.zh.md)
- [English installation guide](./docs/INSTALL.md)
- [日本語インストールガイド](./docs/INSTALL.ja.md)
- [한국어 설치 안내](./docs/INSTALL.ko.md)
- [版本更新日志](./docs/CHANGELOG.md)
- [日本語 changelog](./docs/CHANGELOG.ja.md)
- [한국어 changelog](./docs/CHANGELOG.ko.md)

> **兼容边界：** DSH Runtime compatibility 只负责 Settings 传输：新版 DSH 使用 `remote.settings`，旧版 DSH 使用 `connection.api.settings`。插件按运行时实际能力进行探测；旧版没有 Remote provider 时不会因此要求可选的 Remote 服务。
>
> Gateway Protocol compatibility 是独立的一层。DSH schema 提供时，插件支持 18 个常用标量 `llm-pi-ai.compat` 字段，按角色与推理、格式与输出、流式与工具、存储与缓存 4 组组织。boolean 字段可设为「自动」「支持」或「不支持」，enum 字段可设为「自动」或具体取值，number 字段可填整数或保持「自动」。DSH `0.1.0-rc.7` 不提供网关兼容设置；`0.1.0-rc.8` 至 `<0.1.2-alpha.1` 支持其他字段，但没有 `supportsFinishReason` 和 `supportsThinkingTokenBudget`；`0.1.2-alpha.1` 至 `<0.1.3-alpha.2` 提供其中 15 个，`0.1.3-alpha.2` 及更高版本在 schema 支持时提供全部 18 个字段。安装并启用可选的 `dsh-llm-openai-completions` transport 后，它可以接管符合条件的自定义 OpenAI 兼容思考模型供应商。「自动」会取消当前层覆盖，并恢复继承链中的下一层取值。
>
> DSH `0.1.2-alpha.1` 及更高版本通过 `LocaleRuntime` 支持语言包注册外部 locale ID。本插件会动态注册 `ja` 和 `ko`，无需维护 DSH fork。只支持固定内置 locale ID 的旧版 DSH 仍只能使用 `zh` 和 `en`。
>
> 发布包的运行入口是 `lib/index.js`（Host）和 `lib/client.js`（Client）。修改 TypeScript 或 locale 源文件后，运行 `pnpm run build`，再启动 DSH 或打包插件。当前 DSH 没有公开的 semver metadata 契约，因此运行时能力探测是权威来源。只有显式 metadata 或测试输入提供时才使用可选版本；未知合法版本仍按实际能力运行。插件同时支持新版 `remote.settings` 和旧版 `connection.api.settings`。
>
> Host 在宿主提供 Settings `installSection` 时用它注册插件自有的 `dsh-thinking-effort` namespace，否则回退到旧版 `register` 路径。在 `0.1.7` 及以后的 entry-config 模型下这两条路径都不存在，设置分区改由导出的 `Config` 提供。插件不在运行时依赖 `@deepseek-ai/dsh-settings`，因此在配置为 `autoInstallPeers: false` 的 DSH profile 中也能干净安装，不会引入第二份 Cordis 运行时。

## DSH 版本兼容

| DSH 范围 | 网关兼容设置 |
| --- | --- |
| `0.1.0-rc.7` | 不支持 |
| `0.1.0-rc.8` 至 `<0.1.2-alpha.1` | schema 暴露时可用，但没有 `supportsFinishReason` 和 `supportsThinkingTokenBudget` |
| `0.1.2-alpha.1` 至 `<0.1.3-alpha.2` | schema 暴露时支持 15 个字段；`thinkingTokenBudgetField`、`vllmPriority` 与 `supportsMaxOutputTokens` 尚未提供 |
| `0.1.3-alpha.2` 至 `<0.2.2-0` | schema 暴露时支持全部 18 个字段。该区间横跨 `0.1.7` 的设置重写与 `0.2.0`／`0.2.1` 线，均已验证保持相同的可编辑字段集合。达到或超过该上限的版本不做映射：插件照常工作，改为跟随运行时宿主实际报告的能力 |

从 DSH `0.1.0-rc.8` 起，后续支持范围均以运行时 schema 暴露为准。上表表示各 DSH 版本最多可用的字段集合；当前网关协议还可能进一步缩小集合。

实际可配置字段需要同时满足三项条件：DSH 版本支持、运行时 schema 暴露，以及当前路由的 `api` 协议支持。不支持的字段不会显示，也不会写入 Settings。18 个字段中，`openai-completions` 支持除 `supportsMaxOutputTokens` 之外的全部字段；`openai-responses`、`azure-openai-responses` 和 `openai-codex-responses` 只支持 `supportsDeveloperRole`、`supportsStrictMode`、`supportsLongCacheRetention` 和 `supportsMaxOutputTokens`。如果 `api` 缺失或无法识别，最终仍以运行时 schema 和 DSH 校验为准。

DSH `0.1.7` 起改为从 Loader 条目自身的 `Config` schema 派生设置表单（entry-config 模型）；没有导出该 schema 的插件不会出现设置表单。本插件已导出该 schema，因此在 `0.1.7` 及以后，它的设置分区使用 Loader 条目 ID `thinking-effort`；`0.1.0-rc.7` 至 `0.1.6` 仍使用注册的 namespace `dsh-thinking-effort`，客户端会自动解析宿主实际发布的那个 ID。`subagentEffort` 现在存放在本插件自己的分区，且在 `0.1.7` 及以后旧的 `llm-pi-ai` 位置不再是回退读取来源：该分区的 schema 只声明了 `providers`，宿主会拒绝写入其他路径，并从它上报的用户层中丢掉未声明的键。所以升级前存在那里的子 agent 默认值会显示为未设置，需要在插件的设置卡片里重新选择一次。本插件在 `0.1.7` 之前导出的快照仍把该值放在 `llm-pi-ai` 里；导入时插件会把该值迁移到自己的分区——这也正是同一批次里的 providers 能被接受的原因（只要有一个写入路径不是 volatile，宿主就会拒绝整个批次）。`0.1.7` 及以后设置保存在当前 profile 的 `cordis.patch.yml`，而不再是 `~/.dsh/settings.yaml`（`0.1.7` 不再使用该文件）。

## 为什么需要它？

DSH 的 `llm-pi-ai` 适配器允许你手工声明第三方模型，但这些模型通常没有 `reasoningEfforts` 配置。因此，Composer 的模型选择器不会显示「推理等级」，你也无法把网关实际支持的值（例如 `ultra`）映射到 DSH 的标准档位。

这个插件解决的是配置层问题：

- 为你自己 profile 声明的、缺少档位的模型补上默认选项，安装后即可在 Composer 中看到「推理等级」；只由组合 base 或 schema 默认值提供的模型不会被补全，跳过的数量会写入宿主日志；
- 在设置页按模型自定义档位，并把 `high` 映射为网关需要的任意字符串，例如 `ultra`；
- 为子 agent 设置统一的默认思考强度，同时保留显式指定值的优先级；
- 子 agent 的自定义线上值会按实际模型的 `reasoningEfforts` 映射回标准档位，找不到映射时不会注入非法档位；
- 不修改已经存在的用户自定义档位，避免覆盖现有配置。

## 适合谁？

如果你满足下面任一情况，这个插件通常值得安装：

- 通过 `llm-pi-ai` 手工接入了 OpenAI 兼容或其他第三方模型；
- 模型接口支持思考强度，但 DSH 的模型选择器没有显示对应选项；
- 不同网关使用不同的线上值，需要把 DSH 的 `high`、`max` 等档位映射为 `ultra`、`reasoning` 等字符串；
- 希望控制子 agent 的成本与响应质量，而不影响主 agent 的显式配置。

如果你只使用 DSH 内置模型，且 Composer 已经提供正确的推理等级，这个插件不是必需品。

## 标识说明

这几个名称职责不同，请不要混用：

| 名称 | 用途 |
| --- | --- |
| `@hytime/dsh-thinking-effort` | npm 包名、浏览器 bundle 请求路径、模块加载器注册 ID 和宿主/客户端运行时 ID，安装、升级和卸载时使用 |
| `thinking-effort` | Cordis 组合条目 ID 和设置页 Slot ID |

## 功能概览

| 功能 | 作用 |
| --- | --- |
| 默认档位补齐 | 为用户层中缺少配置的模型添加 `off`、`high`、`max`，不覆盖已有自定义值；只由组合 base 或 schema 默认值提供的模型不补全，并在宿主日志中报出数量 |
| 模型级编辑 | 在「设置 → 模型能力与档位」中逐模型勾选档位并填写线上值；catalog/modelOverrides 和 `models[]` 模型都可编辑 compat |
| 网关兼容配置 | 按 provider 全局或单个模型配置 18 个常用标量字段，按角色与推理、格式与输出、流式与工具、存储与缓存分组并默认收起 |
| OpenCode 会话 Header | 按精确模型启用动态 `x-opencode-session`，默认生成与 DSH 会话绑定的确定性 `ses_` 值（提供 template / expression / script 等模式以应对上游格式变化），不保存固定 Header 值 |
| OpenCode user-agent 覆盖 | 按 provider/model（含自定义路由）改写 `user-agent` 以模仿上游客户端，可为不同路由配置不同值；默认关闭 |
| 网关值映射 | 例如 DSH 选择 `high` 时，实际向网关发送 `ultra` |
| 配置备份与方案 | 把当前配置导出成 JSON 文件用于跨机器迁移；在本机保存多份命名方案并可在其中切换；导入前可选择「合并」或「替换」并预览影响范围 |
| 子 agent 默认值 | 为未显式指定档位的子 agent 请求自动填入默认思考强度 |
| 快捷预设 | 一键应用官方 DeepSeek 风格或通用档位组合 |
| Composer 分档滑块 | 运行时提供 `modelDirectories` 服务时，注册 Composer 的可选 `seat`，显示当前 `provider/model` 的宿主已解析推理档位 |
| 多语言设置 | 已包含中文、English、日本語和한국어字典；日语/韩语切换使用 DSH 的语言包支持 |

## 安装、升级与卸载

DSH 插件必须通过官方 `dsh plugin` 命令安装。普通 `pnpm install` 只会把包放入当前 Node.js 项目，不能替代 DSH profile 的依赖和 bundle 注册；也不要手工编辑 profile 的 `package.json`。

### 1. 确认 profile

```bash
echo "DSH_HOME=${DSH_HOME:-$HOME/.dsh}"
ls "${DSH_HOME:-$HOME/.dsh}/profiles"
dsh --version
```

将正在运行的 profile 名称替换下面命令中的 `<profile>`，例如 `web`。

### 2. 安装最新版本

```bash
dsh plugin --profile <profile> add @hytime/dsh-thinking-effort
```

安装指定版本：

```bash
dsh plugin --profile <profile> add @hytime/dsh-thinking-effort@0.3.10
```

官方 CLI 会同时更新 profile 依赖、锁文件和 `dsh.profile.bundles`，无需手工追加 YAML。

### 3. 升级

```bash
dsh plugin --profile <profile> update @hytime/dsh-thinking-effort
```

### 4. 卸载

```bash
dsh plugin --profile <profile> remove @hytime/dsh-thinking-effort
rm -f "${DSH_HOME:-$HOME/.dsh}/thinking-effort-loaded.json"
```

宿主侧改动需要重启 DSH；浏览器侧刷新 Web 页面。

完整的迁移、验证和排查步骤请查看 [INSTALL.md](./docs/INSTALL.md)。

## 从旧包迁移

旧版本可能使用以下依赖：

```text
dsh-thinking-effort
github:hytime/dsh-thinking-effort
```

如果旧依赖仍然存在，使用官方命令迁移：

```bash
dsh plugin --profile <profile> remove dsh-thinking-effort
dsh plugin --profile <profile> add @hytime/dsh-thinking-effort@0.3.10
```

如果旧依赖已经被其他工具移除，但 profile 的 bundle 列表仍残留旧名称，先从旧 profile 的 `pnpm-lock.yaml` 找到旧 GitHub commit，再使用官方命令恢复并移除：

```bash
dsh plugin --profile <profile> add github:hytime/dsh-thinking-effort#<old-commit>
dsh plugin --profile <profile> remove dsh-thinking-effort
dsh plugin --profile <profile> add @hytime/dsh-thinking-effort@0.3.10
```

不要把 `dsh-thinking-effort` 添加到新的 `dsh.profile.bundles` 中。

## 快速使用

1. 打开 DSH「设置 → 模型能力与档位」。
2. 使用页面顶部的「页面语言」选择中文、English、日本語或한국어。DSH 默认优先使用已保存的语言，其次使用浏览器语言，最后回退 English；选择会持久化到 DSH。
3. 在「子 agent 默认档位」卡片中选择没有显式值时使用的默认档位，然后点击「应用」。
4. 使用「一键设置」将官方 DeepSeek 风格或通用预设应用到全部模型，或展开供应商和模型进行详细配置。
5. 使用搜索框按模型名称或 ID 筛选。模型行会显示文字/图像输入能力、已声明的上下文长度，以及打开单模型设置的按钮。
6. 勾选需要的标准档位，并填写发送给网关的线上值。例如：

   | DSH 档位 | 网关线上值 |
   | --- | --- |
   | `off` | 留空，表示不发送 |
   | `high` | `ultra` |
   | `max` | `max` |

7. 在模型编辑器中，只有目标模型确实需要 `x-opencode-session` 时才启用「OpenCode 会话 Header」。它默认关闭，会从当前 DSH 会话生成确定性的 `ses_` 值，不会在同一路由的其他模型或不同 provider 之间继承；拨动开关即立即保存，没有单独的保存按钮。上游格式变化时参考[生成器章节](#opencode-会话-header-生成器)。
8. 回到 Composer，选择对应模型后即可使用推理档位滑块。

### Composer 推理档位滑块

当 DSH Web 运行时提供 `modelDirectories` 服务时，客户端会为可选 `conversation.input.model` `seat` 注册一个有意压过官方模型选择器的实现——这个槽是单占位槽，优先级越低越胜出——不会修改 Composer 本身。滑块读取当前精确 `provider/model` 在宿主侧解析后的 `reasoning.efforts` 数组，因此只显示该模型当前生效的档位。选择档位提交的是普通会话模型选择，不会写入插件的 Settings 文档。

模型声明了 `defaultEffort` 时，滑块会显示对应档位。模型未声明 `defaultEffort` 时，面板额外提供「跟随模型默认」；提交时不会设置推理档位覆盖值。控件使用宿主 `--dsw-*` 语义 `token`，不维护自己的主题偏好，会跟随当前浅色或深色主题。

运行时未提供 `modelDirectories` 服务时，不会注册这个 `seat`；设置页和旧版 Settings 传输回退仍可使用。插件不修改 DSH Composer、`ui-conversation` 或 `ui-model-selection` 包。

设置页右下角会显示当前安装版本，例如 `v0.1.14`。

### 网关兼容配置

provider 的 `compat` 区域是该 provider 下全部模型的全局默认值。设置页将 18 个字段按 4 组组织并默认收起。请使用 DSH 官方 YAML 配置结构：

```yaml
providers:
  qwen-gateway:
    compat:
      supportsDeveloperRole: false
      maxTokensField: max_tokens
    models:
      - id: qwen-plus
      - id: qwen-thinking
        compat:
          maxTokensField: max_completion_tokens
```

逐字段独立按以下顺序取值：model → provider → base/catalog → protocol。URL/hostname 不会作为 compat 来源。模型值只覆盖当前字段。「自动」（`Auto`）会删除当前层字段，恢复 provider 继承，并让继承链中的下一层生效。provider 默认值会应用到该路由的所有模型，模型级修改只影响当前模型。对同一路由（provider）而言，非空的 `models[]` 和非空的 `modelOverrides` 互斥；官方 schema 会拒绝该无效配置，插件遇到异常数据时 fail closed。

设置页的 provider 全局区域用于修改该 provider 下全部模型的默认值。catalog/modelOverrides 模型和 `models[]` 模型都能展开后编辑单模型 compat：前者只对目标字段使用 `modelOverrides.<model>.compat` 下的字段级 `set`/`unset`，后者通过一个完整的 `providers.<route>.models` 数组 set 写回，同时保留其他模型和字段。模型级修改不会影响其他模型。

这些 compat 值属于控制面配置。它们不实现或替代网关 transport；网络请求仍由外部 transport 负责。

### OpenCode 会话 Header 生成器

模型编辑器提供独立的「OpenCode 会话 Header」开关。它默认关闭，保存在插件自有的设置分区中，不写入 `llm-pi-ai.compat`。只有确实需要 `x-opencode-session` 的精确 `provider/model` 才应启用；同一路由中的其他模型（包括 GPT 模型）不会继承该设置。拨动开关即立即保存，没有单独的保存按钮；重新打开模型时显示的是已持久化的值。

启用后、未配置 `format` 时，Host 会发送符合 `ses_` 规范形态、**由当前 DSH 会话确定性派生**的值：`ses_` + 12 位十六进制（48 位毫秒时间戳，会话内首次使用时铸造一次）+ 14 位 Base62（对归一化的 DSH 会话 ID 取 80 位 SHA-256 摘要）。同一 DSH 会话总是发送同一个值：该值按会话粘性保留，有界缓存淘汰只丢弃缓存值、绝不丢弃首次铸造的铸币，因此被淘汰的会话再次访问时值仍不变；只有 DSH 重启且处于 `firstUse` 模式时才会重新铸造 hex 时间戳（`time: hash` 则完全无状态）。14 位后缀因为是派生而非存储，在 DSH 重启后依然稳定。不同会话（包括每次子 agent 运行）派生不同值。

生成器参数可在设置页的**会话值生成器**卡片中调整，也可在设置文档中手写：`0.1.7` 及以后是当前 profile 的 `cordis.patch.yml` 中的 `opencodeSession.format` 分区（由 Loader 条目 ID `thinking-effort` 定位）；`0.1.0-rc.7` 至 `0.1.6` 是 `dsh-thinking-effort.opencodeSession.format`，例如 `~/.dsh/settings.yaml`。两种方式等价。共四档，可应对上游格式变化而无需重建插件：

- `ses-derive`（默认）——上面的规范生成器。`time: firstUse` 按会话铸造一次 hex 段；`time: hash` 改为从会话摘要派生，使整个值在任何机器上完全一致。
- `passthrough`——旧行为：发送原始 DSH 会话 ID。
- `template`——带 `{hex12}`、`{tail62}`、`{sessionId}`、`{rawSessionId}`、`{sha256}`、`{now}`、`{provider}`、`{model}` 占位符的字符串。
- `expression`——使用同一上下文的受限加法表达式，另提供 `sha256`、`slice`、`lower`、`upper` 辅助函数，例如 `'ses_' + hex12 + tail62`。
- `script`——导出 `format(context)` 的 JS 文件的绝对路径，文件变更时热加载；加载或求值失败时回退到 `ses-derive`。

可选的 `validate` 正则配合 `onInvalid: warn | drop | send` 校验产物是否符合上游最新要求（默认 `warn`）。适配器或调用方已经提供的 `x-opencode-session` 会被保留、绝不覆盖。该设置不会选择或修改 `openai-completions`、`openai-responses` 或 `anthropic-messages` 协议。完整配置参考见 [INSTALL.zh.md](./docs/INSTALL.zh.md)。

Sub2API、CPA 和其他中转服务必须保留并继续把 `x-opencode-session` 转发给 OpenCode 上游。`llm-pi-ai.providers.<route>.headers.x-opencode-session` 这类静态 route Header 不能替代本功能：它会让所有会话共用一个值，无法提供按会话路由和提示词缓存亲和性。修改 Host 后需要重启 DSH；修改 Settings 或 Client 后需要刷新 Web 页面。

### OpenCode user-agent 覆盖

部分上游还会校验 `user-agent` 头。`llm-pi-ai` 适配器会在每个 provider 请求上强制盖上自己的归因 `user-agent`（`deepseek-harness/…`）并删除 provider 配置的同名头，因此无法通过 DSH 本身修改。本插件在请求离开发送前的最后一层改写它——按 provider/model 生效、默认关闭。下面的 YAML 展示 `0.1.7` 之前版本读取的 namespace 形态：

```yaml
dsh-thinking-effort:
  opencodeSession:
    userAgent:
      value: "opencode/1.18.31 ai-sdk/provider-utils/4.0.23 runtime/bun/1.3.14"
      providers:
        opencode-go:
          enabled: true              # 整条路由
        sundrawnewapi-private:
          value: "opencode/1.18.31"  # 可选的路由级值
          models:
            mimo-v2.5-free: true     # 精确模型
```

- `value` 是总开关：为空或缺失时全局不生效。
- 命中判定：路由的 `enabled` 为 true（全部模型）或精确模型被开启；自定义路由直接用其 provider 名作为 key。
- 路由自己的 `value` 优先于总 `value`。
- 未命中的请求保持 DSH 的归因 `user-agent` 不变。

它与上面的会话 Header 作用于同一请求层，可以叠加使用，两者同时开启即可完整模仿上游客户端。完整参考见 [INSTALL.zh.md](./docs/INSTALL.zh.md)；修改 Host 后需要重启 DSH。

### 配置备份与方案

「配置备份与方案」卡片位于语言选择器和「子 agent 默认档位」卡片下方，可以导出当前配置、在本机保存命名方案，并导入先前导出的文件。

1. 点击「导出当前配置」下载 `dsh-config-<时间戳>.json`。文件按原样包含 `llm-pi-ai` 用户层与本插件自有设置分区的配置（`0.1.0-rc.7` 至 `0.1.6` 的键为 `dsh-thinking-effort`，`0.1.7` 及以后为 Loader 条目 ID `thinking-effort`）：凭据值不会被导出（provider 只记录保存密钥的环境变量名 `apiKeyEnv`），但这些分区里的值都会原样写入，放在 provider `headers` 里的明文 token 就是其中之一。请妥善保管。
2. 在「方案库」中输入名称后点击「保存当前配置」，即可把当前配置存为命名方案；「导出」写成文件，「删除」移除方案，最多保存 20 份。「应用」切回方案时走的是与导入相同的预览，默认的「合并」会保留方案里没有的 provider，要完全还原需在预览中改选「替换」。
3. 点击「导入配置」中的「选择文件…」后，「导入预览」会先列出新增 / 覆盖 / 删除的条数，确认之前不会写入任何内容。
4. 导入默认使用「合并」（保留文件里没有的配置）；「替换」必须显式选择，它会删除文件里没有的 provider。点击「确认导入」会先把当前配置存为「导入前的自动备份」，再写入变更；还原这份备份同样走这个预览。

导出与导入复用插件现有的 Settings 通道，因此新版 Remote Settings 与旧版 `connection.api.settings` 都可以使用。结果显示某个 namespace 需要重启时，重启 DSH 后生效。

导入快照时默认只迁移能力配置；provider 的 `baseURL`、`apiKeyEnv`、`headers` 与 `opencodeSession.format.script` 属于本机部署接线，需在预览中显式勾选「同时导入端点与凭据」才会生效。

### 旧数据自动迁移

DSH 0.1.7 会把 `settings.yaml` 重命名并只导入一次，而更早版本的插件在 0.1.7 上加载失败，因此你此前设置的思考档位或模型开关可能只留在 `settings.yaml.imported` 里。插件会在启动时扫描该文档、尚未重命名的 `settings.yaml` 以及活的 `llm-pi-ai` 用户层；当发现属于本插件、而你的设置分区尚未声明的值时，会在设置页上方弹出询问：「迁移」把它们写入本插件的设置分区，「稍后」在本次页面加载内不再追问，「不再询问」则记录下这一次的具体内容，仅当旧数据之后发生变化才会再次提示。在你点击「迁移」之前不会写入任何旧数据值，且迁移只补齐你尚未设置的值，绝不覆盖。写入前，插件会把当时的设置存进「配置备份与方案」的回滚槽（`autoBackup`，来源标记为 `migration`），并与迁移值在同一批写入中落盘。想按需检查旧数据时，使用「配置备份与方案」卡片中的「重新扫描旧数据」。

### 设置页界面

页面顶部是语言选择器；其下方的「子 agent 默认档位」卡片控制没有显式档位的请求。「一键设置」负责批量应用预设。供应商和模型列表支持展开/收起；每个模型行显示输入能力、上下文长度，并在设置区域提供网关兼容控件。`models[]` 保存使用完整数组 set，而不是数组索引 path op。上下文长度输入还支持用 `k`（大小写不限）表示 1024 倍，例如 `64k` 即 `65536`。页面按与 `dsh-web-mobile` 相同的断点（1023px / 767px / 480px）在窄屏重排：成对字段降为单列、标签堆叠在控件上方、固定控件宽度被释放，因此手机上无需横向滚动即可操作。

![中文模型能力与档位设置页](https://raw.githubusercontent.com/hytime/dsh-thinking-effort/main/docs/assets/screenshots/plugin-zh-settings-expanded.png)

完整的中英日韩截图集见 [`docs/SCREENSHOTS.md`](./docs/SCREENSHOTS.md)。


## 工作方式

- **宿主侧：** 插件读取 `llm-pi-ai` 设置，在启动和设置变更时扫描 `models` 与 `modelOverrides`，只为缺少 `reasoningEfforts` 的模型补充默认档位。补齐只写入用户层，因此覆盖的是你自己 profile 声明的模型：由组合 base 或 schema 默认值提供的模型在该层没有可写入的条目，插件不会为其补全，并在宿主日志中说明跳过了多少个。插件同时读取模型级 OpenCode 会话设置，只在匹配的 `llm/stream` 请求中注入按 `opencodeSession.format` 生成（默认 `ses-derive`）的 `x-opencode-session`，并为 `opencodeSession.userAgent` 命中的模型改写 `user-agent`（否则会被 `llm-pi-ai` 适配器的归因头强制覆盖）。
- **客户端：** 通过 DSH Settings Remote（`ctx.remote.settings`）注册设置页；运行时提供 `modelDirectories` 服务时，为可选 Composer `seat` 注册有意压过官方模型选择器的实现（该槽为单占位槽，优先级越低越胜出），并显示宿主已解析的推理档位滑块。模型编辑器把 OpenCode 会话 Header 设置保存在插件自有 namespace，与 `llm-pi-ai.compat` 分开。四种文案分别维护在 `src/locales/zh.json`、`src/locales/en.json`、`src/locales/ja.json` 和 `src/locales/ko.json`，发布前生成到客户端 bundle。
- **子 agent：** `0.1.7` 及以后默认值存储在本插件自有设置分区的 `subagentEffort`（`0.1.0-rc.7` 至 `0.1.6` 为 `llm-pi-ai` 用户层）。宿主优先读取插件自有分区，再回退 `llm-pi-ai`；只有 `0.1.7` 之前的版本会真正把值放在后者（entry-config 的 `llm-pi-ai` 分区只声明 `providers`，其用户层不会承载这个键）。`agent/request` waterfall 只对未显式指定档位的子 agent 请求进行补全。
- **版本信息：** 设置页右下角显示当前安装版本，例如 `v0.1.14`；DSH 插件列表从已安装包的 `package.json.version` 读取同一版本。

## 安装验证

```bash
grep -n "@hytime/dsh-thinking-effort" \
  "${DSH_HOME:-$HOME/.dsh}/profiles/<profile>/package.json"
dsh --profile <profile> --dump-default-config
```

组合树应包含：

```yaml
- id: thinking-effort
  name: '@hytime/dsh-thinking-effort'
```

且不应再包含：

```yaml
name: dsh-thinking-effort
```

宿主加载标记位于：

```bash
cat "${DSH_HOME:-$HOME/.dsh}/thinking-effort-loaded.json"
```

## 重要限制

- DSH 的 `llm-pi-ai` 适配器固定提供 7 个标准档位：`off`、`minimal`、`low`、`medium`、`high`、`xhigh`、`max`。插件不能增加第 8 个显示名称，但可以为每个档位填写任意线上值。
- 非 `off` 档位必须填写线上值；`off` 留空表示不发送该参数。
- 子 agent 使用的模型必须支持所选档位，否则网关可能返回 `UNSUPPORTED_REASONING_EFFORT`。
- `off` 和未设置都可能表现为不发送 `reasoning` 参数，是否真正关闭思考取决于第三方网关的协议语义。
- Composer 滑块只在 Web 运行时提供可选 `modelDirectories` 服务时注册。该服务不可用时，不会注册 `seat`，插件也不会修改 Composer。
- 宿主逻辑修改需要重启 DSH；Settings、locale 和 Client bundle 修改需要刷新 Web 页面。
- 「配置备份与方案」的方案库和导入前的自动备份都保存在插件自有的设置分区中，不会随导出文件迁移。要把命名方案带到另一台机器，需要逐个「导出」再在目标机器上导入。

## CI 与发布维护

- Pull Request 和推送到 `main` 会在 Node `22.19.0` 与 `24.x` 上运行质量矩阵。
- workflow 使用 `pnpm install --frozen-lockfile`；依赖变更时，维护者必须提交 `pnpm-lock.yaml`。
- 普通 CI workflow 不会发布 npm；发布只由 `publish.yml` 接收匹配的 `v<version>` tag 后执行。
- 创建发布 tag 前，维护者先更新 `package.json` 版本和各语言 `CHANGELOG`，提交这些变更，再创建匹配的 `v<version>` tag。tag 指向的提交必须位于 `main` 历史中。
- npm 包必须配置 GitHub Trusted Publisher：仓库为 `hytime/dsh-thinking-effort`，workflow 为 `publish.yml`。发布使用 GitHub OIDC 生成 provenance，不需要 `NPM_TOKEN`。
- 发布前 workflow 会按 rc7 → rc2 → alpha2 → namespace → entry 顺序构建并测试五个官方 DSH 能力代表：`dsh-v0.1.0-rc.7`（`0.1.0-rc.7`）、`dsh-v0.1.1-rc.2`（`0.1.1-rc.2`）、`dsh-v0.1.3-alpha.2`（`0.1.3-alpha.2`）、`dsh-v0.1.6-alpha.1`（`0.1.6-alpha.1`）和 `dsh-v0.1.7-alpha.1`（`0.1.7-alpha.1`）；通过官方 `dsh plugin` 命令安装并执行真实兼容检查，`0.1.6-alpha.1`（namespace 模型）和 `0.1.7-alpha.1`（entry-config 模型）两个代表版本都会运行真实浏览器 DOM 探针。
- workflow 不会自动修改版本或任何 `CHANGELOG`；如果 npm 中已经存在相同版本，发布也会被阻止。

## 排查

- **官方组合配置失败：** 执行 `dsh --profile <profile> --dump-default-config`，检查是否仍有旧的 `name: dsh-thinking-effort`。
- **设置页没有出现：** 重启 DSH 后刷新 Web 页面，确认 profile 的 bundle 清单包含 `@hytime/dsh-thinking-effort`。
- **宿主没有补齐：** 检查 `$DSH_HOME/thinking-effort-loaded.json` 是否存在；日志前缀为 `[@hytime/dsh-thinking-effort]`。
- **写入档位失败：** 检查非 `off` 档位是否填写了线上值，并确认目标模型配置仍然存在。
- **子 agent 报 `UNSUPPORTED_REASONING_EFFORT`：** 改用该模型支持的档位，或恢复为「提供方默认」。

## 许可证

[MIT](./LICENSE)
