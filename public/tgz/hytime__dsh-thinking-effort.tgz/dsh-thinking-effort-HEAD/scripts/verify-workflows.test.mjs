import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import test from 'node:test';
import { parse } from 'yaml';

const repositoryRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const workflowPath = path.join(repositoryRoot, '.github', 'workflows', 'ci.yml');
const publishWorkflowPath = path.join(repositoryRoot, '.github', 'workflows', 'publish.yml');
const publishFixtureRoot = path.join(repositoryRoot, 'scripts', 'fixtures');
const publishCleanupFixturePath = path.join(publishFixtureRoot, 'publish-invalid-cleanup.yml');
const publishNpmTokenFixturePath = path.join(publishFixtureRoot, 'publish-invalid-npm-token.yml');
const requiredCommands = [
  'pnpm install --frozen-lockfile',
  'pnpm run build',
  'pnpm run typecheck',
  'pnpm run typecheck:test',
  'pnpm test',
  'pnpm run test:release',
  'node --check lib/index.js',
  'node --check lib/client.js',
  'pnpm pack --dry-run',
  'pnpm audit --audit-level=high',
  'git diff --check',
];

async function readWorkflow() {
  return parse(await readFile(workflowPath, 'utf8'));
}

function scalarValues(value) {
  if (Array.isArray(value)) return value.flatMap(scalarValues);
  if (value && typeof value === 'object') return Object.values(value).flatMap(scalarValues);
  return typeof value === 'string' ? [value] : [];
}

function assertNoNpmTokenEnv(value, location = 'workflow') {
  if (Array.isArray(value)) {
    value.forEach((item, index) => assertNoNpmTokenEnv(item, `${location}[${index}]`));
    return;
  }
  if (!value || typeof value !== 'object') return;

  if (
    value.env &&
    typeof value.env === 'object' &&
    !Array.isArray(value.env) &&
    Object.hasOwn(value.env, 'NPM_TOKEN')
  ) {
    assert.fail(`publish workflow must not define NPM_TOKEN in ${location}.env`);
  }

  for (const [key, child] of Object.entries(value)) {
    assertNoNpmTokenEnv(child, `${location}.${key}`);
  }
}

function assertNoNodeAuthTokenEnv(value, location = 'workflow') {
  if (Array.isArray(value)) {
    value.forEach((item, index) => assertNoNodeAuthTokenEnv(item, `${location}[${index}]`));
    return;
  }
  if (!value || typeof value !== 'object') return;

  if (
    value.env &&
    typeof value.env === 'object' &&
    !Array.isArray(value.env) &&
    Object.hasOwn(value.env, 'NODE_AUTH_TOKEN')
  ) {
    assert.fail(`publish workflow must not define NODE_AUTH_TOKEN in ${location}.env`);
  }

  for (const [key, child] of Object.entries(value)) {
    assertNoNodeAuthTokenEnv(child, `${location}.${key}`);
  }
}

function assertNoNpmConfigUserconfig(value, location = 'workflow') {
  if (Array.isArray(value)) {
    value.forEach((item, index) => assertNoNpmConfigUserconfig(item, `${location}[${index}]`));
    return;
  }
  if (!value || typeof value !== 'object') return;

  if (Object.hasOwn(value, 'NPM_CONFIG_USERCONFIG')) {
    assert.fail(`publish workflow must not define NPM_CONFIG_USERCONFIG in ${location}`);
  }

  for (const [key, child] of Object.entries(value)) {
    assertNoNpmConfigUserconfig(child, `${location}.${key}`);
  }
}

function assertNoPublishAuthTokens(workflow) {
  assertNoNpmTokenEnv(workflow);
  assertNoNodeAuthTokenEnv(workflow);
  assertNoNpmConfigUserconfig(workflow);

  const scalarValuesInWorkflow = scalarValues(workflow);
  assert.equal(
    scalarValuesInWorkflow.some((value) => /\bNPM_TOKEN\b/.test(value)),
    false,
    'publish workflow must not reference NPM_TOKEN',
  );
  assert.equal(
    scalarValuesInWorkflow.some((value) => /\bNODE_AUTH_TOKEN\b/.test(value)),
    false,
    'publish workflow must not reference NODE_AUTH_TOKEN',
  );
}

const expectedCompatibilityCleanup =
  'rm -rf "${RUN_ROOT:-$RUNNER_TEMP/dsh-thinking-effort-compat-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}}"';

function assertCompatibilityCleanupStructure(compatibility) {
  assert.ok(Array.isArray(compatibility?.steps), 'compatibility job must define steps');
  const cleanup = compatibility.steps.find(
    (step) => step.name === 'Cleanup temporary compatibility resources',
  );
  assert.ok(cleanup, 'compatibility job must define the temporary resources cleanup step');
  assert.equal(cleanup.if, '${{ always() }}', 'compatibility cleanup must run with always()');
  assert.equal(
    cleanup.run?.trim(),
    expectedCompatibilityCleanup,
    'compatibility cleanup must use a syntactically valid RUN_ROOT fallback expression',
  );
}

function assertWorkflowStructure(workflow) {
  assert.ok(workflow && typeof workflow === 'object', 'CI workflow must parse to an object');
  assert.ok(workflow.on && typeof workflow.on === 'object', 'workflow must define triggers');
  assert.ok(Object.hasOwn(workflow.on, 'pull_request'), 'workflow must declare pull_request trigger');
  assert.ok(Object.hasOwn(workflow.on, 'push'), 'workflow must declare push trigger');
  assert.ok(
    Object.hasOwn(workflow.on, 'workflow_dispatch'),
    'workflow must declare workflow_dispatch trigger',
  );
  assert.deepEqual(
    workflow.on.push.branches,
    ['main', 'dev'],
    'workflow must push from main and the dev integration branch',
  );

  const quality = workflow.jobs?.quality;
  assert.ok(quality && typeof quality === 'object', 'CI workflow must define jobs.quality');
  assert.deepEqual(
    quality.strategy?.matrix?.['node-version'],
    ['22.19.0', '24.x'],
    'quality job must use the supported Node matrix',
  );
  assert.ok(Array.isArray(quality.steps), 'quality job must define steps');

  const setupNode = quality.steps.find((step) => step.uses === 'actions/setup-node@v4');
  assert.ok(
    quality.steps.some((step) => step.uses === 'actions/checkout@v4'),
    'quality job must use actions/checkout@v4',
  );
  assert.ok(setupNode, 'quality job must use actions/setup-node@v4');
  // GitHub's runner images ship no pnpm, so every `pnpm ...` step below would
  // be command-not-found without this action. It must precede setup-node,
  // whose `cache: pnpm` also resolves the pnpm store path.
  const setupPnpmIndex = quality.steps.findIndex((step) => step.uses === 'pnpm/action-setup@v6');
  assert.notEqual(setupPnpmIndex, -1, 'quality job must install pnpm with pnpm/action-setup@v6');
  assert.ok(
    setupPnpmIndex < quality.steps.indexOf(setupNode),
    'pnpm must be installed before setup-node runs',
  );
  assert.equal(
    setupNode.with?.['node-version'],
    '${{ matrix.node-version }}',
    'setup-node must use the matrix Node version',
  );
  assert.equal(setupNode.with?.cache, 'pnpm', 'setup-node must use pnpm cache');

  const runCommands = quality.steps.filter((step) => Object.hasOwn(step, 'run')).map((step) => step.run);
  assert.deepEqual(
    runCommands,
    requiredCommands,
    'quality job must run the required commands in order',
  );

  assert.equal(workflow.permissions?.contents, 'read', 'workflow contents permission must be read');
  assert.equal(
    quality.permissions?.contents ?? workflow.permissions?.contents,
    'read',
    'quality contents permission must be read',
  );
  assert.notEqual(
    workflow.permissions?.['id-token'],
    'write',
    'workflow must not grant id-token write',
  );
  assert.notEqual(
    quality.permissions?.['id-token'],
    'write',
    'quality must not grant id-token write',
  );

  assert.equal(
    workflow.concurrency?.group,
    'ci-${{ github.event.pull_request.number || github.ref }}',
    'workflow must group pull requests by number',
  );
  assert.equal(
    workflow.concurrency?.['cancel-in-progress'],
    "${{ github.event_name == 'pull_request' }}",
    'workflow must cancel only pull request runs',
  );
  assert.equal(
    scalarValues(workflow).some((value) => /\bnpm\s+publish\b/.test(value)),
    false,
    'workflow must not publish npm',
  );
}

/**
 * Assert the advisory pull-request policy job: it must only run on pull
 * requests, must stay advisory, and must actually invoke the policy engine.
 * @param {object} workflow Parsed CI workflow.
 */
function assertPrPolicyJob(workflow) {
  const job = workflow.jobs?.['pr-policy'];
  assert.ok(job && typeof job === 'object', 'CI workflow must define jobs.pr-policy');
  assert.equal(
    job.if,
    "${{ github.event_name == 'pull_request' }}",
    'pr-policy must run only for pull requests',
  );
  assert.equal(
    job['continue-on-error'],
    true,
    'pr-policy must stay advisory until branch protection requires it',
  );
  assert.equal(job.permissions?.contents, 'read', 'pr-policy contents permission must be read');
  assert.notEqual(
    job.permissions?.['id-token'],
    'write',
    'pr-policy must not grant id-token write',
  );
  assert.ok(Array.isArray(job.steps), 'pr-policy job must define steps');
  assert.ok(
    job.steps.some((step) => step.uses === 'actions/checkout@v4'),
    'pr-policy job must use actions/checkout@v4',
  );

  const runCommands = job.steps.filter((step) => Object.hasOwn(step, 'run')).map((step) => step.run);
  assert.ok(
    runCommands.some((command) => command.includes('node scripts/pr-policy.mjs')),
    'pr-policy job must invoke scripts/pr-policy.mjs',
  );
  assert.equal(
    runCommands.some((command) => /--strict\b/.test(command)),
    false,
    'pr-policy must not run in strict mode while it is advisory',
  );
  assert.equal(
    runCommands.some((command) => /\bexit\s+1\b/.test(command)),
    false,
    'pr-policy must not fail the check while it is advisory',
  );
}

test('CI workflow declares the required triggers and Node matrix', async () => {
  const workflow = await readWorkflow();

  assert.deepEqual(Object.keys(workflow.on).sort(), ['pull_request', 'push', 'workflow_dispatch']);
  assert.deepEqual(workflow.on.push.branches, ['main', 'dev']);
  assert.deepEqual(workflow.jobs.quality.strategy.matrix['node-version'], ['22.19.0', '24.x']);
});

test('CI workflow runs every required quality command in order', async () => {
  const workflow = await readWorkflow();
  const runCommands = workflow.jobs.quality.steps
    .filter((step) => Object.hasOwn(step, 'run'))
    .map((step) => step.run);

  assert.deepEqual(runCommands, requiredCommands);
});

test('CI workflow configures setup-node, permissions, and PR concurrency structurally', async () => {
  const workflow = await readWorkflow();
  const quality = workflow.jobs.quality;
  const setupNode = quality.steps.find((step) => step.uses === 'actions/setup-node@v4');

  assert.equal(setupNode.with['node-version'], '${{ matrix.node-version }}');
  assert.equal(setupNode.with.cache, 'pnpm');
  assert.equal(workflow.permissions.contents, 'read');
  assert.equal(quality.permissions?.contents ?? workflow.permissions.contents, 'read');
  assert.notEqual(workflow.permissions['id-token'], 'write');
  assert.notEqual(quality.permissions?.['id-token'], 'write');
  assert.equal(workflow.concurrency.group, 'ci-${{ github.event.pull_request.number || github.ref }}');
  assert.equal(
    workflow.concurrency['cancel-in-progress'],
    "${{ github.event_name == 'pull_request' }}",
  );
  assert.equal(scalarValues(workflow).some((value) => /\bnpm\s+publish\b/.test(value)), false);
});

test('CI workflow has the complete expected structure', async () => {
  assertWorkflowStructure(await readWorkflow());
});

test('CI workflow keeps the pull request policy advisory and wired to the engine', async () => {
  assertPrPolicyJob(await readWorkflow());
});

const malformedWorkflowCases = [
  {
    name: 'pull_request trigger',
    mutate: (workflow) => delete workflow.on.pull_request,
    message: 'workflow must declare pull_request trigger',
  },
  {
    name: 'push branch trigger',
    mutate: (workflow) => {
      workflow.on.push.branches = ['develop'];
    },
    message: 'workflow must push from main and the dev integration branch',
  },
  {
    name: 'push trigger',
    mutate: (workflow) => delete workflow.on.push,
    message: 'workflow must declare push trigger',
  },
  {
    name: 'workflow_dispatch trigger',
    mutate: (workflow) => delete workflow.on.workflow_dispatch,
    message: 'workflow must declare workflow_dispatch trigger',
  },
  {
    name: 'quality job',
    mutate: (workflow) => delete workflow.jobs.quality,
    message: 'CI workflow must define jobs.quality',
  },
  {
    name: 'quality steps',
    mutate: (workflow) => delete workflow.jobs.quality.steps,
    message: 'quality job must define steps',
  },
  {
    name: 'checkout action',
    mutate: (workflow) => {
      workflow.jobs.quality.steps = workflow.jobs.quality.steps.filter(
        (step) => step.uses !== 'actions/checkout@v4',
      );
    },
    message: 'quality job must use actions/checkout@v4',
  },
  {
    name: 'setup-node action',
    mutate: (workflow) => {
      workflow.jobs.quality.steps = workflow.jobs.quality.steps.filter(
        (step) => step.uses !== 'actions/setup-node@v4',
      );
    },
    message: 'quality job must use actions/setup-node@v4',
  },
  {
    name: 'job contents permission',
    mutate: (workflow) => {
      workflow.jobs.quality.permissions = { contents: 'write' };
    },
    message: 'quality contents permission must be read',
  },
  {
    name: 'job id-token permission',
    mutate: (workflow) => {
      workflow.jobs.quality.permissions = { 'id-token': 'write' };
    },
    message: 'quality must not grant id-token write',
  },
  {
    name: 'Node matrix',
    mutate: (workflow) => {
      workflow.jobs.quality.strategy.matrix['node-version'] = ['22.19.0'];
    },
    message: 'quality job must use the supported Node matrix',
  },
  {
    name: 'setup-node version',
    mutate: (workflow) => {
      workflow.jobs.quality.steps.find((step) => step.uses === 'actions/setup-node@v4').with[
        'node-version'
      ] = '22.19.0';
    },
    message: 'setup-node must use the matrix Node version',
  },
  {
    name: 'setup-node cache',
    mutate: (workflow) => {
      workflow.jobs.quality.steps.find((step) => step.uses === 'actions/setup-node@v4').with.cache = 'yarn';
    },
    message: 'setup-node must use pnpm cache',
  },
  {
    name: 'quality run steps',
    mutate: (workflow) => {
      workflow.jobs.quality.steps.find((step) => Object.hasOwn(step, 'run')).run = 'echo npm ci';
    },
    message: 'quality job must run the required commands in order',
  },
  {
    name: 'contents permission',
    mutate: (workflow) => {
      workflow.permissions.contents = 'write';
    },
    message: 'workflow contents permission must be read',
  },
  {
    name: 'id-token permission',
    mutate: (workflow) => {
      workflow.permissions['id-token'] = 'write';
    },
    message: 'workflow must not grant id-token write',
  },
  {
    name: 'concurrency group',
    mutate: (workflow) => {
      workflow.concurrency.group = 'ci-${{ github.ref }}';
    },
    message: 'workflow must group pull requests by number',
  },
  {
    name: 'concurrency cancellation',
    mutate: (workflow) => {
      workflow.concurrency['cancel-in-progress'] = false;
    },
    message: 'workflow must cancel only pull request runs',
  },
  {
    name: 'publish command',
    mutate: (workflow) => {
      workflow.jobs.quality.steps.find((step) => step.uses === 'actions/checkout@v4').name =
        'checkout (npm publish marker)';
    },
    message: 'workflow must not publish npm',
  },
  {
    name: 'pr-policy job',
    mutate: (workflow) => delete workflow.jobs['pr-policy'],
    message: 'CI workflow must define jobs\\.pr-policy',
  },
  {
    name: 'pr-policy trigger',
    mutate: (workflow) => {
      workflow.jobs['pr-policy'].if = "${{ github.event_name == 'push' }}";
    },
    message: 'pr-policy must run only for pull requests',
  },
  {
    name: 'pr-policy advisory posture',
    mutate: (workflow) => {
      workflow.jobs['pr-policy']['continue-on-error'] = false;
    },
    message: 'pr-policy must stay advisory',
  },
  {
    name: 'pr-policy strict mode',
    mutate: (workflow) => {
      const steps = workflow.jobs['pr-policy'].steps;
      const target = steps.find((step) => step.run?.includes('scripts/pr-policy.mjs'));
      target.run = `${target.run} --strict`;
    },
    message: 'pr-policy must not run in strict mode',
  },
];

test('each malformed workflow fixture fails at its broken structural constraint', async () => {
  const validWorkflow = await readWorkflow();

  for (const { name, mutate, message } of malformedWorkflowCases) {
    const fixture = structuredClone(validWorkflow);
    mutate(fixture);
    assert.throws(
      () => {
        assertWorkflowStructure(fixture);
        assertPrPolicyJob(fixture);
      },
      new RegExp(message),
      name,
    );
  }
});

async function readPublishWorkflow() {
  return parse(await readFile(publishWorkflowPath, 'utf8'));
}

const publishAuthCleanupCommand = `set -Eeuo pipefail
token="$(pnpm config get //registry.npmjs.org/:_authToken 2>/dev/null || true)"
if [[ -n "$token" && "$token" != "undefined" ]]; then
  echo "a static npm token is configured; trusted publishing must be the only auth source" >&2
  exit 1
fi
`;
const publishPnpmVersionCommand = `set -Eeuo pipefail
pnpm_version="$(pnpm --version)"
printf 'pnpm %s\\n' "$pnpm_version"
node -e 'const [major] = process.argv[1].split(".").map(Number); if (major < 11) throw new Error("pnpm >= 11 is required for OIDC publishing")' "$pnpm_version"
`;

const publishQualityCommands = [
  'pnpm install --frozen-lockfile',
  'pnpm run build',
  'node scripts/verify-release.mjs "$GITHUB_REF_NAME"',
  `set -Eeuo pipefail
PACKAGE_VERSION="$(node -p "require('./package.json').version")"
query_output="$RUNNER_TEMP/dsh-thinking-effort-npm-view.txt"
set +e
pnpm view @hytime/dsh-thinking-effort@\${PACKAGE_VERSION} version --json > "$query_output" 2>&1
query_status=$?
set -e
if [ "$query_status" -eq 0 ]; then
  echo "npm version \${PACKAGE_VERSION} already exists" >&2
  exit 1
fi
if ! grep -Eiq 'ERR_PNPM_PACKAGE_NOT_FOUND|E404|HTTP[[:space:]]+404' "$query_output"; then
  cat "$query_output" >&2
  exit "$query_status"
fi
`,
  'pnpm run typecheck',
  'pnpm run typecheck:test',
  'pnpm run test:release',
  'pnpm test',
  'node --check lib/index.js',
  'node --check lib/client.js',
  'pnpm pack --dry-run',
  'pnpm audit --audit-level=high',
  'git diff --check',
];

function publishRunCommands(job) {
  return job.steps.filter((step) => Object.hasOwn(step, 'run')).map((step) => step.run);
}

function assertPublishWorkflowStructure(workflow) {
  assert.ok(workflow && typeof workflow === 'object', 'publish workflow must parse to an object');
  assert.deepEqual(Object.keys(workflow.on ?? {}), ['push'], 'publish workflow must only define push trigger');
  assert.deepEqual(workflow.on.push?.tags, ['v*.*.*'], 'publish workflow must trigger v*.*.* tags');
  assert.equal(workflow.permissions?.contents, 'read', 'publish workflow contents permission must be read');

  const quality = workflow.jobs?.quality;
  const compatibility = workflow.jobs?.compatibility;
  const publish = workflow.jobs?.publish;
  assert.ok(quality && typeof quality === 'object', 'publish workflow must define jobs.quality');
  assert.ok(compatibility && typeof compatibility === 'object', 'publish workflow must define jobs.compatibility');
  assert.ok(publish && typeof publish === 'object', 'publish workflow must define jobs.publish');
  assert.deepEqual(publishRunCommands(quality), publishQualityCommands, 'publish quality commands must run in order');
  assert.equal(
    quality.steps.find((step) => step.uses === 'actions/checkout@v4')?.with?.['fetch-depth'],
    0,
    'quality job must check out full history',
  );
  assert.equal(
    quality.steps.find((step) => step.uses === 'actions/setup-node@v4')?.with?.['node-version'],
    '22.19.0',
    'quality job must use Node 22.19.0',
  );
  const duplicateCheck = publishRunCommands(quality).find((command) =>
    command.includes('pnpm view @hytime/dsh-thinking-effort@${PACKAGE_VERSION} version --json'),
  );
  assert.ok(duplicateCheck, 'quality job must check whether the package version already exists');
  assert.match(duplicateCheck, /PACKAGE_VERSION="\$\(node -p/);
  assert.match(duplicateCheck, /grep -Eiq 'ERR_PNPM_PACKAGE_NOT_FOUND\|E404\|HTTP\[\[:space:\]\]\+404'/);
  assert.doesNotMatch(duplicateCheck, /not found/i);
  const publishTagGuard = publish.steps.find((step) => step.name === 'Verify tag points to main');
  assert.equal(
    publishTagGuard?.run,
    `set -Eeuo pipefail
git fetch --no-tags origin main
git merge-base --is-ancestor "$GITHUB_SHA" origin/main
`,
    'publish job must verify that the tag points to main',
  );
  const publishAuthCleanup = publish.steps.find((step) => step.name === 'Verify OIDC-only npm authentication');
  assert.equal(
    publishAuthCleanup?.run,
    publishAuthCleanupCommand,
    'publish job must assert that no static npm token can shadow trusted publishing',
  );
  const publishPnpmVersion = publish.steps.find((step) => step.name === 'Verify pnpm version for Trusted Publishing');
  assert.equal(
    publishPnpmVersion?.run,
    publishPnpmVersionCommand,
    'publish job must assert the pnpm Trusted Publishing minimum version',
  );
  const publishInstall = publish.steps.find((step) => step.name === 'Install dependencies');
  assert.equal(publishInstall?.run, 'pnpm install --frozen-lockfile');
  const publishBuild = publish.steps.find((step) => step.name === 'Build');
  assert.equal(publishBuild?.run, 'pnpm run build');
  const publishPackage = publish.steps.find((step) => step.name === 'Publish package with provenance');
  assert.equal(
    publishPackage?.run,
    'pnpm publish --provenance --access public --skip-manifest-obfuscation --no-git-checks',
  );
  assert.match(
    publishPackage.run,
    /--skip-manifest-obfuscation/,
    'publish must keep packageManager in the published manifest, which the DSH CLI requires',
  );
  assert.deepEqual(
    publishRunCommands(publish),
    [publishTagGuard?.run, publishAuthCleanup?.run, publishPnpmVersion?.run, publishInstall?.run, publishBuild?.run, publishPackage?.run],
    'publish job must verify, isolate auth, check pnpm, install, build, and publish in order',
  );
  assert.equal(
    publish.steps.find((step) => step.uses === 'actions/setup-node@v4')?.with?.['node-version'],
    '24.x',
    'publish job must use Node 24.x',
  );
  assert.equal(
    publish.steps.find((step) => step.uses === 'actions/setup-node@v4')?.with?.['registry-url'],
    undefined,
    'publish must not let setup-node write a placeholder _authToken that could shadow OIDC',
  );
  assertNoPublishAuthTokens(workflow);
  assert.equal(publishRunCommands(publish).some((command) => /\bnpm view /.test(command)), false);
  assert.ok(
    publishRunCommands(publish).includes('pnpm install --frozen-lockfile'),
    'publish job must run pnpm install --frozen-lockfile',
  );
  assert.ok(
    publishRunCommands(publish).includes('pnpm run build'),
    'publish job must run pnpm run build',
  );
  assert.ok(Array.isArray(compatibility.steps), 'compatibility job must define steps');
  assertCompatibilityCleanupStructure(compatibility);
  assert.deepEqual(compatibility.needs, 'quality', 'compatibility must need quality');
  assert.deepEqual(publish.needs, ['quality', 'compatibility'], 'publish must need quality and compatibility');
  assert.equal(publish.permissions?.contents, 'read', 'publish contents permission must be read');
  assert.equal(publish.permissions?.['id-token'], 'write', 'publish must have OIDC id-token write permission');
  assert.equal(publish.concurrency?.group, 'npm-publish-${{ github.ref_name }}');
  assert.equal(publish.concurrency?.['cancel-in-progress'], false);

  const compatibilityBuild = compatibility.steps.find(
    (step) => step.name === 'Build five official DSH capability representatives and run integration tests',
  );
  assert.ok(compatibilityBuild, 'compatibility job must define its build and integration step');
  assert.equal(typeof compatibilityBuild.run, 'string', 'compatibility build step must have a run script');
  for (const required of [
    'dsh-v0.1.0-rc.7',
    'dsh-v0.1.1-rc.2',
    'dsh-v0.1.3-alpha.2',
    'dsh-v0.1.6-alpha.1',
    'dsh-v0.1.7-alpha.1',
    'DSH_CLI_ROOTS="$RC7_ROOT,$RC2_ROOT,$ALPHA_ROOT,$NAMESPACE_ROOT,$ENTRY_ROOT"',
    'pnpm --version',
    'pnpm install --frozen-lockfile',
    'pnpm rebuild --pending fs-ext',
    'pnpm run build',
    "require('path').basename(JSON.parse(require('fs').readFileSync(process.argv[1], 'utf8')).filename)",
    'CHROME_PATH',
    'dsh plugin',
    'DSH_LOADER_INTEGRATION=1',
    'DSH_REQUIRE_THINKING_EFFORT_DOM=1',
    'pnpm test tests/loader-composition.test.ts',
    '--skip-manifest-obfuscation',
    'trap',
    'DSH_TEST_PID=$!',
    'kill "$DSH_TEST_PID"',
    'wait "$DSH_TEST_PID"',
    'rm -rf "$RUN_ROOT"',
  ]) {
    assert.ok(compatibilityBuild.run.includes(required), `compatibility build step must include ${required}`);
  }
  assert.match(compatibilityBuild.run, /RC7_ROOT=.*dsh-v0\.1\.0-rc\.7/);
  assert.match(compatibilityBuild.run, /RC2_ROOT=.*dsh-v0\.1\.1-rc\.2/);
  assert.match(compatibilityBuild.run, /ALPHA_ROOT=.*dsh-v0\.1\.3-alpha\.2/);
  assert.match(compatibilityBuild.run, /NAMESPACE_ROOT=.*dsh-v0\.1\.6-alpha\.1/);
  assert.match(compatibilityBuild.run, /ENTRY_ROOT=.*dsh-v0\.1\.7-alpha\.1/);
  assert.equal((compatibilityBuild.run.match(/git clone --depth 1 --branch/g) ?? []).length, 5);
  assert.doesNotMatch(compatibilityBuild.run, /dsh-v0\.1\.2-alpha\.[12]/);
  assert.doesNotMatch(compatibilityBuild.run, /corepack enable/);
  assert.doesNotMatch(compatibilityBuild.run, /\bnpm (?:ci|install|run|test|pack|audit|publish|view|config)\b/);
  assert.match(compatibilityBuild.run, /pnpm --version/);
  // The compatibility job's `run` script never names the action, so the guard
  // belongs on the job's steps, not on the script text.
  assert.ok(
    compatibility.steps.some((step) => step.uses === 'pnpm/action-setup@v6'),
    'compatibility job must install pnpm with pnpm/action-setup@v6',
  );

  assert.match(publishTagGuard.run, /git fetch --no-tags origin main/);
  assert.match(publishTagGuard.run, /git merge-base --is-ancestor "\$GITHUB_SHA" origin\/main/);
  assert.doesNotMatch(publishRunCommands(publish).join('\n'), /npm view @hytime\/dsh-thinking-effort@\$\{PACKAGE_VERSION\} version --json/);
  assert.equal(
    publishPackage.run,
    'pnpm publish --provenance --access public --skip-manifest-obfuscation --no-git-checks',
  );

}

test('publish workflow does not use runner context in job-level env', async () => {
  const workflow = await readPublishWorkflow();
  const compatibilityEnv = workflow.jobs.compatibility?.env ?? {};

  for (const value of Object.values(compatibilityEnv)) {
    assert.doesNotMatch(String(value), /\$\{\{\s*runner\./);
  }
});

test('publish workflow declares tag guards, dependencies, OIDC, and compatibility matrix', async () => {
  assertPublishWorkflowStructure(await readPublishWorkflow());
});

test('publish workflow rejects a malformed compatibility cleanup fixture', async () => {
  const fixture = parse(await readFile(publishCleanupFixturePath, 'utf8'));

  assert.throws(
    () => assertCompatibilityCleanupStructure(fixture.jobs.compatibility),
    /compatibility cleanup must use a syntactically valid RUN_ROOT fallback expression/,
  );
});

test('publish workflow rejects NPM_TOKEN keys in nested env fixtures', async () => {
  const fixture = parse(await readFile(publishNpmTokenFixturePath, 'utf8'));

  assert.throws(
    () => assertNoNpmTokenEnv(fixture),
    /NPM_TOKEN.*workflow\.jobs\.publish\.steps\[0\]\.with\.options\.env/,
  );
});
