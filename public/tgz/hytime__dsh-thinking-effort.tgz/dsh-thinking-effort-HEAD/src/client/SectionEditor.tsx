import React from 'react'
import { GATEWAY_COMPAT_FIELD_KEYS, type GatewayCompatFieldKey } from '../compat/gateway/fields.js'
import { editableProviderCompatFields } from '../compat/gateway/validation.js'
import { isOpenCodeSessionSectionId } from '../compat/opencode-session.js'
import packageJson from '@hytime/dsh-thinking-effort/package.json' with { type: 'json' }
import { DEFAULT_LEVELS, INPUT_MODALITIES, LEVEL_LABEL_KEYS, NS, OPENCODE_SESSION_NS, PRESETS, ALL_LEVELS, CONTEXT_1M } from './constants.js'
import { inventoryFrom, modelCompatKey, modelGatewayCompatViewsFrom, providerGatewayCompatViewsFrom } from './model-inventory.js'
import { emptyTakeoverRuntimeResolution } from './takeover-runtime.js'
import { openCodeSessionOp, openCodeSessionStateFor, isOpenCodeSessionNamespace } from './model-header-ops.js'
import { opsForModelArrayCompat, opsForModelCompat, opsForProviderCompat, setOps } from './model-ops.js'
import { isPluginEntrySection, pluginSection, subagentEffortTarget } from './subagent-section.js'
import { buildInput, buildLevels, contextDraftFrom, draftFrom, inputDraftFrom, modelSaveBlockedReason, validateContextWindow, validateLevels } from './validation.js'
import { revisionOf } from './types.js'
import { isSettingsConflict } from '../shared/conflict.js'
import type { ClientLocale, ClientResult, ConfigFormFace, ContextDraft, DraftCell, InputDraft, InventoryItem, GatewayCompatEditability, ModelCompatDirtyFields, ModelGatewayCompatUpdate, ModelGatewayCompatView, ModelUpdate, OpenCodeSessionState, ProviderGatewayCompatUpdate, ProviderGatewayCompatView, ReasoningDraft, SettingsApi, SettingsNamespace, SettingsOp, Translation } from './types.js'
import type { Palette } from './theme.js'
import type { TakeoverRuntimeStore } from './takeover-runtime.js'
import { iosPalette } from './theme.js'
import { ActionButton, Icon } from './components/Controls.js'
import css from './settings.module.css'
import { ModelRow } from './components/ModelRow.js'
import { SubagentSettings } from './components/SubagentSettings.js'
import { ConfigBackupCard } from './components/ConfigBackupCard.js'
import { OpenCodeFormatCard } from './components/OpenCodeFormatCard.js'
import { renderGatewayCompatControls } from './components/GatewayCompatControls.js'

const PLUGIN_VERSION = packageJson.version

// How long the success badge floats in the panel's top-right before it fades
// on its own. Every field edit clears the notice (they set notice: null), so a
// later save re-shows it and restarts this countdown.
const NOTICE_DISMISS_MS = 3000

type DirtyFields = { levels?: boolean; context?: boolean; input?: boolean }

interface RunOpsRequest {
  readonly ns: string
  readonly revision: number
  readonly ops: readonly SettingsOp[]
  /**
   * Rebuild the ops against a freshly read section, for the conflict retry.
   *
   * Supplying this is a claim that the write is safe to replay once another
   * writer has moved the section, and what makes that true differs by op shape:
   *
   * - A LEAF op — `['providers', route, 'compat', field]`, an `opencodeSession`
   *   model flag, `subagentEffort` — sets exactly one path, so it lands on
   *   whatever the document now holds. `() => ops` is correct.
   * - A CONTAINER op carries a whole `models` array or `modelOverrides` dict
   *   rebuilt from THIS panel's inventory. Replaying it unchanged would write
   *   that stale container over the document and drop a concurrent edit to a
   *   sibling model, or a model another writer added. These callers MUST
   *   rebuild from `fresh`.
   *
   * Omitting it makes a conflict report instead of retry, which is the safe
   * default: an unproven replay is worse than a visible refusal.
   */
  readonly rebuildOps?: (fresh: SettingsNamespace) => readonly SettingsOp[]
  readonly successMessage: string
  readonly onSuccess?: () => void
  readonly openCodeSessionSavedKey?: string
  /**
   * The write targets the plugin's own entry section, so its response refreshes
   * the subagent view instead of the `llm-pi-ai` inventory.
   */
  readonly entrySectionWrite?: boolean
}
interface SubagentState { effort: string | null; revision: number }
interface EditorState {
  loading: boolean
  namespace: SettingsNamespace | null
  openCodeSessionViews: Record<string, boolean>
  openCodeSessionDrafts: Record<string, boolean>
  openCodeSessionDirty: Record<string, boolean>
  openCodeSessionFound: boolean
  openCodeSessionAvailable: boolean
  inventory: InventoryItem[]
  providerViews: Record<string, ProviderGatewayCompatView>
  providerDrafts: Record<string, ProviderGatewayCompatView>
  providerDirty: Record<string, boolean>
  providerCompatDirty: Record<string, Partial<Record<GatewayCompatFieldKey, boolean>>>
  providerCompatExpanded: Record<string, boolean>
  modelCompatViews: Record<string, ModelGatewayCompatView>
  modelCompatDrafts: Record<string, ModelGatewayCompatView>
  modelCompatDirty: Record<string, ModelCompatDirtyFields>
  modelCompatExpanded: Record<string, boolean>
  revision: number
  /**
   * A count of the reads of the shared `dsh-thinking-effort` namespace, handed
   * to the generator card so it re-reads whenever this editor does. It is not
   * the namespace revision: the import path can land on one revision twice (the
   * snapshot writer commits `set`s, and the card's own write bumps it again), so
   * a value the card compares for equality has to change on every read, not
   * only when the revision does.
   */
  openCodeSessionReads: number
  expanded: Record<string, boolean>
  expandedProviders: Record<string, boolean>
  drafts: Record<string, ReasoningDraft>
  contextDrafts: Record<string, ContextDraft>
  inputDrafts: Record<string, InputDraft>
  dirty: Record<string, DirtyFields>
  busy: boolean
  error: string | null
  notice: string | null
  query: string
  nsFound: boolean
  /**
   * The plugin's own section under whatever settings model the host publishes:
   * the Loader entry section on 0.1.7 and later, the registered
   * `dsh-thinking-effort` namespace before that. Both the OpenCode session
   * fields and `subagentEffort` live in it, so the editor holds exactly ONE
   * descriptor for it — a second copy would be refreshed by only the writes
   * that named it, and because 0.1.7 revisions are per section, the copy left
   * behind would fence its next write with a stale `expectedRevision` and be
   * refused as a conflict.
   */
  pluginSection: SettingsNamespace | null
  subagent: SubagentState | null
  subagentDraft: string
  subagentCustom: string
  quickSettingsOpen: boolean
}

export interface SectionEditorProps {
  readonly settings: SettingsApi
  readonly locale: ClientLocale
  readonly t: Translation
  readonly palette?: Palette
  readonly takeoverRuntime?: TakeoverRuntimeStore
}

const initialState: EditorState = {
  loading: true, namespace: null, openCodeSessionReads: 0, openCodeSessionViews: {}, openCodeSessionDrafts: {}, openCodeSessionDirty: {}, openCodeSessionFound: false, openCodeSessionAvailable: false, inventory: [], providerViews: {}, providerDrafts: {}, providerDirty: {}, providerCompatDirty: {}, providerCompatExpanded: {}, modelCompatViews: {}, modelCompatDrafts: {}, modelCompatDirty: {}, modelCompatExpanded: {}, revision: 0, expanded: {}, expandedProviders: {}, drafts: {}, contextDrafts: {}, inputDrafts: {}, dirty: {}, busy: false, error: null, notice: null, query: '', nsFound: true, pluginSection: null, subagent: null, subagentDraft: 'default', subagentCustom: '', quickSettingsOpen: false,
}

export type { OpenCodeSessionState } from './types.js'

export function createOpenCodeSessionState(
  namespace: SettingsNamespace | undefined,
  inventory: readonly InventoryItem[],
  previous?: OpenCodeSessionState,
): OpenCodeSessionState {
  return openCodeSessionStateFor(namespace, inventory, previous)
}

export function applyOpenCodeSessionMutation(
  state: OpenCodeSessionState,
  response: ClientResult<SettingsNamespace>,
  inventory: readonly InventoryItem[],
  savedKey?: string,
): OpenCodeSessionState {
  if (!response.ok || !isOpenCodeSessionNamespace(response.value)) return state
  const previous: OpenCodeSessionState = {
    ...state,
    dirty: { ...state.dirty },
  }
  if (savedKey !== undefined) delete previous.dirty[savedKey]
  return openCodeSessionStateFor(response.value, inventory, previous)
}

export async function saveOpenCodeSession(
  settings: Pick<SettingsApi, 'mutate'>,
  namespace: SettingsNamespace,
  item: InventoryItem,
  enabled: boolean,
): Promise<ClientResult<SettingsNamespace>> {
  const operation = openCodeSessionOp(item.route, item.model, enabled)
  if (operation === undefined) {
    return { ok: false, error: { message: 'OpenCode session settings require a provider and model' } }
  }
  // The section the namespace came from, which is the entry id under 0.1.7
  // rather than the legacy registered namespace.
  return settings.mutate(namespace.ns, [operation], namespace.revision)
}

function keyOf(item: InventoryItem): string { return modelCompatKey(item.route, item.model) }

/**
 * Re-point model updates at the same models in a freshly read inventory.
 *
 * The model-level ops carry a whole `models` array (or `modelOverrides` dict)
 * rebuilt from this panel's inventory. Replaying that container unchanged after
 * a conflict would write the stale copy over the document and silently drop
 * whatever another writer did meanwhile — an edit to a sibling model, or a
 * model the Host's own default-levels fill had just added. Rebuilding from the
 * fresh inventory is what makes the retry additive instead of destructive.
 *
 * An update whose model is gone is dropped rather than resurrected: there is
 * nothing left to write to, and re-adding it would undo the deletion.
 */
function rebaseItem(fresh: readonly InventoryItem[], item: InventoryItem): InventoryItem | undefined {
  return fresh.find((candidate) => candidate.route === item.route
    && candidate.model === item.model
    && candidate.inOverrides === item.inOverrides)
}

/** Re-point model updates at the same models in a freshly read inventory. */
function rebaseUpdates(fresh: readonly InventoryItem[], updates: readonly ModelUpdate[]): ModelUpdate[] {
  return updates.flatMap((update) => {
    const item = rebaseItem(fresh, update.item)
    return item === undefined ? [] : [{ ...update, item }]
  })
}
function availableCompatFieldCount(view: ProviderGatewayCompatView | ModelGatewayCompatView): number {
  const values = view as unknown as Record<string, unknown>
  return GATEWAY_COMPAT_FIELD_KEYS.filter((key) => key !== 'supportsDeveloperRole' && key !== 'maxTokensField' && values[`${key}Available`] === true).length
}
function removeDirtyFields<T extends object>(dirty: Record<string, T>, key: string, fields: readonly (keyof T)[]): Record<string, T> {
  const next = { ...dirty }
  const entry = { ...(next[key] ?? {}) }
  fields.forEach((field) => { delete entry[field] })
  if (Object.keys(entry).length === 0) delete next[key]
  else next[key] = entry
  return next
}

function clearOpenCodeSessionState(current: EditorState, _key: string): EditorState {
  // The OpenCode Header toggle saves immediately, so its draft always equals
  // the persisted namespace value. Collapsing the editor must not clear it;
  // reopening renders the saved value.
  return current
}

function clearModelEditorState(current: EditorState, key: string): EditorState {
  const next = clearOpenCodeSessionState(current, key)
  const expanded = { ...next.expanded }; delete expanded[key]
  const drafts = { ...next.drafts }; delete drafts[key]
  const contextDrafts = { ...next.contextDrafts }; delete contextDrafts[key]
  const inputDrafts = { ...next.inputDrafts }; delete inputDrafts[key]
  const dirty = { ...next.dirty }; delete dirty[key]
  return { ...next, expanded, drafts, contextDrafts, inputDrafts, dirty }
}

function subagentView(namespace: SettingsNamespace | null): { subagent: SubagentState | null; draft: string; custom: string; revision: number } {
  if (!namespace) return { subagent: null, draft: 'default', custom: '', revision: 0 }
  const revision = revisionOf(namespace)
  const user = namespace.user ?? {}
  const effort = typeof user.subagentEffort === 'string' && user.subagentEffort.length > 0 ? user.subagentEffort : null
  const draft = effort === null ? 'default' : ALL_LEVELS.includes(effort as typeof ALL_LEVELS[number]) ? effort : 'custom'
  return { subagent: { effort, revision }, draft, custom: draft === 'custom' ? effort ?? '' : '', revision }
}

const noRuntimeSubscribe = (): (() => void) => () => undefined
const noRuntimeSnapshot = (): typeof emptyTakeoverRuntimeResolution => emptyTakeoverRuntimeResolution

/**
 * The section whose `user` layer holds `subagentEffort`: the plugin's own entry
 * section when the host publishes one (0.1.7 and later), else the `llm-pi-ai`
 * section the releases before it wrote the value into. `null` while the model
 * registry itself is missing, which is the state the editor already reports as
 * "unconfigured": the setting is only meaningful beside the models it applies
 * to, and `nsFound` hides the rest of the page in exactly that case.
 */
function subagentSection(
  pluginSection: SettingsNamespace | null,
  llmSection: SettingsNamespace | null,
): SettingsNamespace | null {
  return isPluginEntrySection(pluginSection) && llmSection !== null ? pluginSection : llmSection
}

/** The OpenCode session state the editor holds, in the shape its merge helpers take. */
function openCodeStateOf(current: EditorState): OpenCodeSessionState {
  return {
    namespace: isOpenCodeSessionNamespace(current.pluginSection) ? current.pluginSection : null,
    views: current.openCodeSessionViews,
    drafts: current.openCodeSessionDrafts,
    dirty: current.openCodeSessionDirty,
    found: current.openCodeSessionFound,
    available: current.openCodeSessionAvailable,
  }
}

export function SectionEditor({ settings, locale, t, palette = iosPalette(), takeoverRuntime }: SectionEditorProps): React.ReactElement {
  const [state, setState] = React.useState<EditorState>(initialState)
  const takeoverResolution = React.useSyncExternalStore(
    takeoverRuntime?.subscribe ?? noRuntimeSubscribe,
    takeoverRuntime?.getSnapshot ?? noRuntimeSnapshot,
    takeoverRuntime?.getSnapshot ?? noRuntimeSnapshot,
  )

  const applyNamespaceView = (current: EditorState, nextNamespace: SettingsNamespace, notice: string | null, pluginSection: SettingsNamespace | null): EditorState => {
    const view = subagentView(subagentSection(pluginSection, nextNamespace))
    const nextInventory = inventoryFrom(nextNamespace)
    const providerViews = providerGatewayCompatViewsFrom(nextNamespace, settings.compatibilityProfile, takeoverResolution)
    const modelCompatViews = modelGatewayCompatViewsFrom(nextNamespace, nextInventory, settings.compatibilityProfile, takeoverResolution)
    const modelCompatDrafts = { ...current.modelCompatDrafts }
    for (const item of nextInventory) {
      const key = keyOf(item)
      const draft = modelCompatDrafts[key]
      const dirty = current.modelCompatDirty[key]
      const view = modelCompatViews[key]
      if (view === undefined) continue
      if (!dirty) modelCompatDrafts[key] = view
      else if (draft) {
        const preserved = { ...view }
        for (const field of GATEWAY_COMPAT_FIELD_KEYS) {
          if (dirty[field] === true) Object.assign(preserved, { [field]: draft[field] })
        }
        modelCompatDrafts[key] = preserved
      }
    }
    const providerDrafts = { ...current.providerDrafts }
    for (const [provider, providerView] of Object.entries(providerViews)) {
      if (current.providerDirty[provider] !== true) providerDrafts[provider] = providerView
    }
    return { ...current, loading: false, namespace: nextNamespace, busy: false, nsFound: true, pluginSection, inventory: nextInventory, providerViews, providerDrafts, modelCompatViews, modelCompatDrafts, revision: revisionOf(nextNamespace), subagent: view.subagent, subagentDraft: view.draft, subagentCustom: view.custom, notice }
  }

  /**
   * Refresh every view of the plugin's one section from a single descriptor.
   *
   * `subagentEffort` and the OpenCode session fields live in the same section
   * under the 0.1.7 entry-config model, so one write to either returns the
   * descriptor that supersedes what the editor holds for both — and the
   * revision in it is the `expectedRevision` the NEXT write to that section has
   * to send. Revisions are per section there, so a view left on the pre-write
   * copy made the second of any two such writes fail as a conflict. Every write
   * whose response targets this section lands here; `savedKey` names the
   * OpenCode toggle just persisted, whose draft is no longer dirty.
   */
  const applyPluginSectionView = (current: EditorState, section: SettingsNamespace | null, notice: string | null, savedKey?: string): EditorState => {
    const previous = openCodeStateOf(current)
    const refreshed = section === null
      ? createOpenCodeSessionState(undefined, current.inventory, previous)
      : applyOpenCodeSessionMutation(previous, { ok: true, value: section }, current.inventory, savedKey)
    const view = subagentView(subagentSection(section, current.namespace))
    return {
      ...current,
      busy: false,
      pluginSection: section,
      openCodeSessionReads: current.openCodeSessionReads + 1,
      openCodeSessionViews: refreshed.views,
      openCodeSessionDrafts: refreshed.drafts,
      openCodeSessionDirty: refreshed.dirty,
      openCodeSessionFound: refreshed.found,
      openCodeSessionAvailable: refreshed.available,
      subagent: view.subagent,
      subagentDraft: view.draft,
      subagentCustom: view.custom,
      notice,
    }
  }

  /**
   * Re-read every section this editor renders through one `describe`.
   *
   * `notice` is the success message to surface once the re-read lands. The
   * default `null` is what the mount-time and card-triggered calls want (they
   * are reads, not saves); the `configForms` write branch passes its
   * `successMessage` because that transport carries no response body to project
   * and would otherwise lose the "saved" notice the legacy path shows.
   */
  const load = (notice: string | null = null): void => {
    // Only the first read — before any inventory is on screen — swaps the page
    // for the loading placeholder. A save refreshes through here too, and
    // collapsing a populated list to one line shrinks the document height, which
    // is what yanked the panel back to the top (losing the user's scroll and the
    // row they had just edited) on every save. Keeping the current list mounted
    // while the re-read is in flight preserves that position.
    setState((current) => ({ ...current, loading: current.inventory.length === 0, error: null }))
    settings.describe().then((response) => {
      if (!response.ok) {
        setState((current) => ({ ...current, loading: false, busy: false, error: response.error.message }))
        return
      }
      const found = response.value.namespaces.find((entry) => entry.ns === NS)
      // One description answers both questions: which section this plugin's
      // settings live in, and the id that section carries under whichever model
      // the host exposes. The legacy `dsh-thinking-effort` namespace no longer
      // exists under 0.1.7, where every plugin setting lives in the entry
      // section, so the resolved section supersedes the id-specific lookup.
      const plugin = pluginSection(response.value.namespaces) ?? null
      if (!found) {
        setState((current) => {
          const next = { ...current, loading: false, busy: false, nsFound: false, namespace: null, inventory: [], providerViews: {}, providerDrafts: {}, providerDirty: {}, providerCompatDirty: {}, providerCompatExpanded: {}, modelCompatViews: {}, modelCompatDrafts: {}, modelCompatDirty: {}, modelCompatExpanded: {}, subagent: null }
          return applyPluginSectionView(next, plugin, notice)
        })
        return
      }
      setState((current) => applyPluginSectionView(applyNamespaceView(current, found, notice, plugin), plugin, notice))
    }).catch((error: unknown) => {
      const message = error instanceof Error ? error.message : String(error)
      setState((current) => ({ ...current, loading: false, busy: false, error: t('readSettingsFailed', { message }) }))
    })
  }

  React.useEffect(() => { load() }, [])

  React.useEffect(() => {
    setState((current) => {
      if (current.namespace === null) return current
      const providerViews = providerGatewayCompatViewsFrom(current.namespace, settings.compatibilityProfile, takeoverResolution)
      const providerDrafts = { ...current.providerDrafts }
      for (const [provider, view] of Object.entries(providerViews)) {
        if (current.providerDirty[provider] !== true) providerDrafts[provider] = view
      }
      const modelCompatViews = modelGatewayCompatViewsFrom(current.namespace, current.inventory, settings.compatibilityProfile, takeoverResolution)
      const modelCompatDrafts = { ...current.modelCompatDrafts }
      for (const item of current.inventory) {
        const key = keyOf(item)
        const draft = modelCompatDrafts[key]
        const dirty = current.modelCompatDirty[key]
        const view = modelCompatViews[key]
        if (view === undefined) continue
        if (!dirty) modelCompatDrafts[key] = view
        else if (draft) {
          const preserved = { ...view }
          for (const field of GATEWAY_COMPAT_FIELD_KEYS) {
            if (dirty[field] === true) Object.assign(preserved, { [field]: draft[field] })
          }
          modelCompatDrafts[key] = preserved
        }
      }
      return { ...current, providerViews, providerDrafts, modelCompatViews, modelCompatDrafts }
    })
  }, [takeoverResolution])

  React.useEffect(() => {
    if (state.notice === null) return undefined
    const timer = setTimeout(() => {
      setState((current) => (current.notice === null ? current : { ...current, notice: null }))
    }, NOTICE_DISMISS_MS)
    return () => clearTimeout(timer)
  }, [state.notice])

  /**
   * Re-read one section as the document now stands, so a write refused as stale
   * can be retried against it.
   *
   * `undefined` means the section could not be re-read; the caller then reports
   * the original conflict rather than writing without a revision, because a
   * write that cannot establish the current state has no business bypassing the
   * check that exists to protect it.
   */
  const latestSection = (target: string): Promise<SettingsNamespace | undefined> =>
    settings.describe().then((response) => {
      if (!response.ok) return undefined
      return response.value.namespaces.find((entry) => entry.ns === target)
    }).catch(() => undefined)

  /**
   * The official write queue for one section, when this host publishes one.
   *
   * Only a WRITE-CAPABLE form is served. An absent revision would make the
   * host read the write as unconditional, and a memory-mode form (off-loopback)
   * answers every mutation with `false` — in both cases the hand-rolled
   * transport below is the better answer, so those forms are ignored rather
   * than allowed to swallow a save.
   *
   * Resolved per write, not once at mount: the service can activate after this
   * plugin's `apply` (client entries are created concurrently), and `index.ts`
   * hands over a live view that re-reads it on every lookup.
   */
  const formForWrite = (target: string): ConfigFormFace | undefined => {
    const form = settings.formFor?.(target)
    if (form === undefined) return undefined
    const snapshot = form.getSnapshot()
    // `undefined` revision would make the host read the write as unconditional,
    // and a memory-mode form (off-loopback) answers every mutate with `false`.
    return snapshot.writable === true && typeof snapshot.revision === 'number' ? form : undefined
  }

  const runOps = ({ ns, revision, ops, rebuildOps, successMessage, onSuccess, openCodeSessionSavedKey, entrySectionWrite }: RunOpsRequest): void => {
    // The OpenCode-specific copy belongs to the header toggle, whose section id
    // happens to equal the entry id under the 0.1.7 model. A failed subagent
    // save targets that same section (`entrySectionWrite`), so the discriminator
    // is the write kind, not the id: keying on the id alone would report a
    // subagent failure as an OpenCode session failure.
    const writeError = (message: string): string => isOpenCodeSessionSectionId(ns) && entrySectionWrite !== true
      ? t('opencodeSessionSaveFailed', { message })
      : t('writeError', { message })
    setState((current) => ({ ...current, busy: true, error: null, notice: null }))

    const succeed = (value: SettingsNamespace): void => {
      if (!value || typeof value !== 'object') {
        setState((current) => ({ ...current, busy: false, error: t('saveMissingNamespace') }))
        return
      }
      const savedKey = openCodeSessionSavedKey
      if (ns !== NS && entrySectionWrite !== true && (savedKey === undefined || !isOpenCodeSessionNamespace(value))) {
        setState((current) => ({ ...current, busy: false, error: t('saveMissingNamespace') }))
        return
      }
      onSuccess?.()
      setState((current) => {
        if (ns === NS) return applyNamespaceView(current, value, successMessage, current.pluginSection)
        // Every other accepted write targets the plugin's own section, so its
        // response refreshes the OpenCode view and the subagent view together.
        if (entrySectionWrite === true) return applyPluginSectionView(current, value, successMessage)
        return applyPluginSectionView(current, value, successMessage, savedKey)
      })
    }

    // A refusal and a thrown transport error are kept apart because the two
    // transports report differently: the modern Remote answers `ok: false`
    // while the legacy bridge rejects, and only the refusal carries a message
    // the caller is expected to render verbatim.
    type Outcome = { readonly ok: true; readonly value: SettingsNamespace }
      | { readonly ok: false; readonly message: string; readonly conflict: boolean; readonly threw: boolean }
    const writeOnce = async (writeOps: readonly SettingsOp[], expectedRevision: number): Promise<Outcome> => {
      try {
        const response = await settings.mutate(ns, writeOps, expectedRevision)
        return response.ok
          ? { ok: true, value: response.value }
          : { ok: false, message: response.error.message, conflict: isSettingsConflict(response.error), threw: false }
      } catch (error: unknown) {
        return {
          ok: false,
          message: error instanceof Error ? error.message : String(error),
          conflict: isSettingsConflict(error),
          threw: true,
        }
      }
    }

    const run = async (): Promise<void> => {
      const form = formForWrite(ns)
      if (form !== undefined) {
        // The form owns a serialized write queue, a revision fence and a
        // post-refusal re-read, so the panel no longer fences the FIRST attempt
        // itself against its mount-time revision. That fence does not cover the
        // rebuild-and-retry below, which still runs. The first attempt omits
        // `expectedRevision` on purpose: the form fences against the revision
        // IT tracks, not the panel's mount-time copy, which is exactly the
        // stale value the fence exists to supersede.
        // Its `mutate` answers with a bare boolean and carries no descriptor, so
        // success refreshes through `load()` — the same
        // `applyNamespaceView`/`applyPluginSectionView` projection the legacy
        // path reaches through `succeed` — rather than projecting an empty
        // value, which would blank the provider and model views.
        if (await form.mutate(ops)) { onSuccess?.(); load(successMessage); return }
        // A refusal is retried ONCE, and only for a caller that supplied
        // `rebuildOps`: replaying a stale container array would succeed while
        // discarding the concurrent change that caused the refusal. The rebuild
        // still needs a FULL descriptor (`value.providers` for the inventory,
        // `schema` for the editable compat fields), neither of which the form
        // snapshot carries, so the re-read goes through `describe()`.
        if (rebuildOps !== undefined) {
          const fresh = await latestSection(ns)
          if (fresh !== undefined) {
            const rebuilt = rebuildOps(fresh)
            if (rebuilt.length > 0 && await form.mutate(rebuilt, revisionOf(fresh))) {
              onSuccess?.(); load(successMessage); return
            }
          }
        }
        // `mutate` returns only a boolean, so there is no host message to
        // render; the honest report is the generic write failure.
        setState((current) => ({ ...current, busy: false, error: writeError(t('writeFailed')) }))
        return
      }
      let outcome = await writeOnce(ops, revision)
      // The panel holds the revision it read at mount, so any write to the same
      // section meanwhile — another window, the Host's own default-levels fill,
      // a model switch — fences every later save forever. Re-read the section
      // and retry ONCE against it.
      //
      // The retry only runs for a caller that supplied `rebuildOps`, and for a
      // container-shaped write that callback rebuilds the array from the FRESH
      // inventory: replaying the panel's stale array would succeed while
      // silently discarding the very concurrent change that caused the
      // conflict. A second conflict is reported rather than retried again, so a
      // persistently losing writer cannot spin, and a rebuild that yields no
      // ops (every target model is gone) reports the original conflict instead
      // of claiming success.
      if (!outcome.ok && outcome.conflict && rebuildOps !== undefined) {
        const fresh = await latestSection(ns)
        if (fresh !== undefined) {
          const freshRevision = revisionOf(fresh)
          if (freshRevision !== revision) {
            const rebuilt = rebuildOps(fresh)
            if (rebuilt.length > 0) outcome = await writeOnce(rebuilt, freshRevision)
          }
        }
      }
      if (outcome.ok) { succeed(outcome.value); return }
      const message = outcome.message
      setState((current) => ({
        ...current,
        busy: false,
        error: outcome.threw && message.length === 0 ? t('writeFailed') : writeError(message),
      }))
    }
    // `succeed` renders the accepted response and is not expected to throw, but
    // it used to run inside the transport's `.catch`, so a throw there surfaced
    // as a reported write failure. Keeping that net means an unexpected error
    // leaves the button usable and visible instead of only reaching the console.
    run().catch((error: unknown) => {
      const message = error instanceof Error ? error.message : String(error)
      setState((current) => ({ ...current, busy: false, error: message.length > 0 ? writeError(message) : t('writeFailed') }))
    })
  }

  const applyModel = (item: InventoryItem): void => {
    const key = keyOf(item)
    const levels = buildLevels(state.drafts[key] ?? {})
    const contextDraft = state.contextDrafts[key] ?? contextDraftFrom(item)
    const inputDraft = state.inputDrafts[key] ?? inputDraftFrom(item)
    // One shared predicate decides both this refusal and the Save button's
    // disabled state, so the two can never disagree about what is savable.
    const blocked = modelSaveBlockedReason(levels, contextDraft, inputDraft, t)
    if (blocked !== null) { setState((current) => ({ ...current, error: blocked })); return }
    const context = contextDraft.touched ? validateContextWindow(contextDraft, t) : { value: undefined }
    const input = inputDraft.touched ? buildInput(inputDraft, t) : { value: undefined }
    const update: ModelUpdate = { item, levels, contextWindow: context.value, contextWindowTouched: contextDraft.touched, input: input.value, inputTouched: inputDraft.touched }
    runOps({
      ns: NS,
      revision: state.revision,
      ops: setOps(state.inventory, [update]),
      // Whole-array write: rebuild from the fresh inventory so a concurrent
      // sibling edit or added model survives the retry.
      rebuildOps: (fresh) => {
        const inventory = inventoryFrom(fresh)
        return setOps(inventory, rebaseUpdates(inventory, [update]))
      },
      successMessage: t('modelSettingsSaved'),
      onSuccess: () => {
        // Normalize the context field to the integer that was actually stored:
        // a `32k` entry would otherwise keep echoing the typed form, which no
        // longer matches the row's canonical value. `1M` mode renders from the
        // toggle, so its draft is left alone.
        setState((current) => {
          const base = current.contextDrafts[key] ?? contextDraftFrom(item)
          const draft = contextDraft.touched && context.value !== undefined && contextDraft.oneMillion !== true
            ? { ...base, value: String(context.value), previousValue: String(context.value) }
            : current.contextDrafts[key]
          return {
            ...current,
            dirty: removeDirtyFields(current.dirty, key, ['levels', 'context', 'input']),
            contextDrafts: draft === undefined ? current.contextDrafts : { ...current.contextDrafts, [key]: draft },
          }
        })
      },
    })
  }

  const applyModelCompat = (item: InventoryItem): void => {
    const key = keyOf(item)
    const draft = state.modelCompatDrafts[key]
    const current = state.modelCompatViews[key]
    const dirty = state.modelCompatDirty[key]
    if (!draft || !current || !dirty) return
    const update: Partial<ModelGatewayCompatUpdate> = {}
    for (const field of GATEWAY_COMPAT_FIELD_KEYS) {
      if (dirty[field] === true && draft[field] !== current[field]) Object.assign(update, { [field]: draft[field] })
    }
    const editability = editableProviderCompatFields(settings.compatibilityProfile, state.namespace?.schema)
    const ops = item.inOverrides
      ? opsForModelCompat(item, update, editability)
      : opsForModelArrayCompat(state.inventory, item, update, editability)
    // An override writes leaf compat paths; a `models[]` entry rewrites the
    // whole array, so only that branch has to be rebuilt from fresh data.
    const rebuildOps = (fresh: SettingsNamespace): readonly SettingsOp[] => {
      if (!item.inOverrides) {
        const inventory = inventoryFrom(fresh)
        const rebased = rebaseItem(inventory, item)
        return rebased === undefined ? [] : opsForModelArrayCompat(inventory, rebased, update, editableProviderCompatFields(settings.compatibilityProfile, fresh.schema))
      }
      return opsForModelCompat(item, update, editableProviderCompatFields(settings.compatibilityProfile, fresh.schema))
    }
    if (ops.length === 0) {
      setState((currentState) => ({ ...currentState, modelCompatDirty: removeDirtyFields(currentState.modelCompatDirty, key, GATEWAY_COMPAT_FIELD_KEYS) }))
      return
    }
    runOps({
      ns: NS,
      revision: state.revision,
      ops,
      rebuildOps,
      successMessage: t('modelGatewayCompatSaved'),
      onSuccess: () => {
        setState((currentState) => ({ ...currentState, modelCompatDirty: removeDirtyFields(currentState.modelCompatDirty, key, GATEWAY_COMPAT_FIELD_KEYS) }))
      },
    })
  }

  const patchModelCompat = (item: InventoryItem, next: Partial<ModelGatewayCompatUpdate>): void => {
    const key = keyOf(item)
    setState((current) => {
      const draft = current.modelCompatDrafts[key] ?? current.modelCompatViews[key]
      if (!draft) return current
      const modelCompatDrafts = { ...current.modelCompatDrafts, [key]: { ...draft, ...next } }
      const nextDirty: ModelCompatDirtyFields = { ...current.modelCompatDirty[key] }
      for (const field of GATEWAY_COMPAT_FIELD_KEYS) {
        if (Object.prototype.hasOwnProperty.call(next, field)) Object.assign(nextDirty, { [field]: true })
      }
      const modelCompatDirty = { ...current.modelCompatDirty, [key]: nextDirty }
      return { ...current, notice: null, modelCompatDrafts, modelCompatDirty }
    })
  }

  const patchOpenCodeSession = (item: InventoryItem, enabled: boolean): void => {
    const key = keyOf(item)
    const namespace = state.pluginSection
    // The section the switch writes is the plugin's own; it is only addressable
    // when it carries a readable OpenCode session view, which is also what the
    // switch's availability is rendered from.
    if (namespace === null || !isOpenCodeSessionNamespace(namespace)) return
    const operation = openCodeSessionOp(item.route, item.model, enabled)
    if (operation === undefined) return
    // The switch saves immediately: the draft reflects the newly toggled value
    // right away, and the mutation persists it to the plugin namespace.
    setState((current) => ({
      ...current,
      notice: null,
      openCodeSessionDrafts: { ...current.openCodeSessionDrafts, [key]: enabled },
    }))
    runOps({
      ns: namespace.ns,
      revision: namespace.revision,
      ops: [operation],
      // Leaf write: the path addresses one model's flag, so replaying it lands
      // on whatever the document now holds.
      rebuildOps: () => [operation],
      successMessage: t('opencodeSessionSaved'),
      openCodeSessionSavedKey: key,
    })
  }

  const closeModelEditor = (item: InventoryItem): void => {
    const key = keyOf(item)
    setState((current) => clearModelEditorState(current, key))
  }

  const restoreReasoningDefaults = (item: InventoryItem): void => {
    const key = keyOf(item)
    runOps({
      ns: NS,
      revision: state.revision,
      ops: setOps(state.inventory, [{ item, levels: DEFAULT_LEVELS }]),
      rebuildOps: (fresh) => {
        const inventory = inventoryFrom(fresh)
        return setOps(inventory, rebaseUpdates(inventory, [{ item, levels: DEFAULT_LEVELS }]))
      },
      successMessage: t('restoreReasoning'),
      onSuccess: () => {
        setState((current) => ({ ...current, drafts: current.drafts[key] ? { ...current.drafts, [key]: draftFrom(DEFAULT_LEVELS) } : current.drafts, dirty: removeDirtyFields(current.dirty, key, ['levels']) }))
      },
    })
  }

  const restoreProviderDefaults = (item: InventoryItem): void => {
    runOps({
      ns: NS,
      revision: state.revision,
      ops: setOps(state.inventory, [{ item, contextWindow: undefined, contextWindowTouched: true, input: undefined, inputTouched: true }]),
      rebuildOps: (fresh) => {
        const inventory = inventoryFrom(fresh)
        const updates: ModelUpdate[] = [{ item, contextWindow: undefined, contextWindowTouched: true, input: undefined, inputTouched: true }]
        return setOps(inventory, rebaseUpdates(inventory, updates))
      },
      successMessage: t('restoreCapability'),
      onSuccess: () => closeModelEditor(item),
    })
  }

  const applyPreset = (levels: typeof PRESETS[number]['levels']): void => {
    runOps({
      ns: NS,
      revision: state.revision,
      ops: setOps(state.inventory, state.inventory.map((item): ModelUpdate => ({ item, levels }))),
      // Rebuilt from the fresh inventory, so a model another writer added keeps
      // its own settings instead of being dropped with the stale array.
      rebuildOps: (fresh) => {
        const inventory = inventoryFrom(fresh)
        const updates = inventory.map((item): ModelUpdate => ({ item, levels }))
        return setOps(inventory, updates)
      },
      successMessage: t('settingsUpdated'),
      onSuccess: () => {
        setState((current) => {
          let dirty = current.dirty
          const drafts = { ...current.drafts }
          current.inventory.forEach((item) => { const key = keyOf(item); if (drafts[key]) drafts[key] = draftFrom(levels); dirty = removeDirtyFields(dirty, key, ['levels']) })
          return { ...current, drafts, dirty }
        })
      },
    })
  }

  const applySubagentEffort = (): void => {
    const value = state.subagentDraft === 'default' ? undefined : state.subagentDraft === 'custom' ? state.subagentCustom.trim() : state.subagentDraft
    if (state.subagentDraft !== 'default' && !value) { setState((current) => ({ ...current, notice: null, error: t('customEffortRequired') })); return }
    const ops: SettingsOp[] = state.subagentDraft === 'default' ? [{ op: 'unset', path: ['subagentEffort'] }] : [{ op: 'set', path: ['subagentEffort'], value }]
    const target = subagentEffortTarget(isPluginEntrySection(state.pluginSection) ? state.pluginSection : null, state.revision)
    runOps({
      ns: target.ns,
      revision: target.revision,
      ops,
      rebuildOps: () => ops,
      successMessage: t('subagentSaved'),
      entrySectionWrite: target.ownSection,
    })
  }

  const applyProviderCompat = (route: string): void => {
    const draft = state.providerDrafts[route]
    const current = state.providerViews[route]
    const dirtyFields = state.providerCompatDirty[route]
    if (!draft || !current) return
    const update: Partial<ProviderGatewayCompatUpdate> = {}
    for (const field of GATEWAY_COMPAT_FIELD_KEYS) {
      if (dirtyFields?.[field] === true && draft[field] !== current[field]) Object.assign(update, { [field]: draft[field] })
    }
    const ops = opsForProviderCompat(route, update, editableProviderCompatFields(settings.compatibilityProfile, state.namespace?.schema) as Partial<Pick<GatewayCompatEditability, GatewayCompatFieldKey>>)
    const clearProviderDirty = (currentState: EditorState): EditorState => {
      const providerDirty = { ...currentState.providerDirty }
      delete providerDirty[route]
      const providerCompatDirty = { ...currentState.providerCompatDirty }
      delete providerCompatDirty[route]
      return { ...currentState, providerDirty, providerCompatDirty }
    }
    if (ops.length === 0) {
      setState((currentState) => clearProviderDirty(currentState))
      return
    }
    runOps({
      ns: NS,
      revision: state.revision,
      ops,
      rebuildOps: () => ops,
      successMessage: t('gatewayCompatSaved'),
      onSuccess: () => {
        setState((currentState) => clearProviderDirty(currentState))
      },
    })
  }

  const patchProviderCompat = (route: string, next: ProviderGatewayCompatView): void => {
    setState((current) => {
      const draft = current.providerDrafts[route] ?? current.providerViews[route]
      if (!draft) return { ...current, notice: null, providerDrafts: { ...current.providerDrafts, [route]: next }, providerDirty: { ...current.providerDirty, [route]: true } }
      const keysChanged = GATEWAY_COMPAT_FIELD_KEYS.filter((key) => next[key] !== draft[key])
      const nextDirtyFields: Partial<Record<GatewayCompatFieldKey, boolean>> = { ...current.providerCompatDirty[route] }
      for (const field of keysChanged) Object.assign(nextDirtyFields, { [field]: true })
      return {
        ...current,
        notice: null,
        providerDrafts: { ...current.providerDrafts, [route]: next },
        providerCompatDirty: { ...current.providerCompatDirty, [route]: nextDirtyFields },
        providerDirty: { ...current.providerDirty, [route]: true },
      }
    })
  }

  const toggleProviderCompatExpanded = (route: string): void => setState((current) => ({ ...current, providerCompatExpanded: { ...current.providerCompatExpanded, [route]: current.providerCompatExpanded[route] !== true } }))
  const toggleModelCompatExpanded = (key: string): void => setState((current) => ({ ...current, modelCompatExpanded: { ...current.modelCompatExpanded, [key]: current.modelCompatExpanded[key] !== true } }))
  const toggleProvider = (route: string): void => setState((current) => ({ ...current, expandedProviders: { ...current.expandedProviders, [route]: current.expandedProviders[route] !== true } }))
  const toggleExpand = (item: InventoryItem): void => {
    const key = keyOf(item)
    setState((current) => {
      if (current.expanded[key]) {
        const expanded = { ...current.expanded }; delete expanded[key]
        return { ...clearOpenCodeSessionState(current, key), expanded }
      }
      return { ...current, expanded: { ...current.expanded, [key]: true }, drafts: current.drafts[key] ? current.drafts : { ...current.drafts, [key]: draftFrom(item.levels) }, contextDrafts: current.contextDrafts[key] ? current.contextDrafts : { ...current.contextDrafts, [key]: contextDraftFrom(item) }, inputDrafts: current.inputDrafts[key] ? current.inputDrafts : { ...current.inputDrafts, [key]: inputDraftFrom(item) } }
    })
  }
  const patchDraft = (item: InventoryItem, level: typeof ALL_LEVELS[number], patch: Partial<DraftCell>): void => {
    const key = keyOf(item)
    setState((current) => {
      const cell = { ...(current.drafts[key]?.[level] ?? { on: false, wire: '' }), ...patch }
      if (level !== 'off' && patch.on === true && cell.wire.trim() === '') cell.wire = level
      return { ...current, notice: null, dirty: { ...current.dirty, [key]: { ...current.dirty[key], levels: true } }, drafts: { ...current.drafts, [key]: { ...current.drafts[key], [level]: cell } } }
    })
  }
  const patchContextValue = (item: InventoryItem, value: string): void => {
    const key = keyOf(item)
    setState((current) => { const draft = current.contextDrafts[key] ?? contextDraftFrom(item); return { ...current, notice: null, dirty: { ...current.dirty, [key]: { ...current.dirty[key], context: true } }, contextDrafts: { ...current.contextDrafts, [key]: { ...draft, value, previousValue: value, oneMillion: false, touched: true } } } })
  }
  const setOneMillion = (item: InventoryItem, enabled: boolean): void => {
    const key = keyOf(item)
    setState((current) => { const draft = current.contextDrafts[key] ?? contextDraftFrom(item); const previous = enabled ? (draft.oneMillion ? draft.previousValue : draft.value) : draft.previousValue; return { ...current, notice: null, dirty: { ...current.dirty, [key]: { ...current.dirty[key], context: true } }, contextDrafts: { ...current.contextDrafts, [key]: { ...draft, oneMillion: enabled, previousValue: previous || '', value: enabled ? String(CONTEXT_1M) : previous || '', touched: true } } } })
  }
  const patchInputCapability = (item: InventoryItem, modality: 'text' | 'image', enabled: boolean): void => {
    const key = keyOf(item)
    setState((current) => { const draft = current.inputDrafts[key] ?? inputDraftFrom(item); const other = modality === 'text' ? 'image' : 'text'; if (!enabled && !draft[other]) return { ...current, notice: null, error: t('inputCapabilityMinimum') }; return { ...current, error: null, notice: null, dirty: { ...current.dirty, [key]: { ...current.dirty[key], input: true } }, inputDrafts: { ...current.inputDrafts, [key]: { ...draft, [modality]: enabled, touched: true } } } })
  }

  const query = state.query.trim().toLowerCase()
  const visible = query === '' ? state.inventory : state.inventory.filter((item) => item.model.toLowerCase().includes(query) || item.name.toLowerCase().includes(query))
  const routes = [...new Set(visible.map((item) => item.route))]
  const expandedCount = visible.filter((item) => state.expanded[keyOf(item)] && (query !== '' || state.expandedProviders[item.route])).length
  const snapshot = locale.getSnapshot?.() ?? {}
  const available = new Set(snapshot.locales?.map((entry) => entry.id).filter((id): id is string => typeof id === 'string') ?? ['zh', 'en', 'ja', 'ko'])
  const languageOptions: Array<[string, string]> = [['zh', 'languageChinese'], ['en', 'languageEnglish'], ['ja', 'languageJapanese'], ['ko', 'languageKorean']]

  return <div className={css.settingsRoot} style={{ color: palette.text, fontFamily: '-apple-system, BlinkMacSystemFont, SF Pro Text, Segoe UI, sans-serif' }}>
    {state.notice ? <div style={{ position: 'sticky', top: '8px', zIndex: 20, height: 0, pointerEvents: 'none' }}><div role="status" aria-live="polite" style={{ position: 'absolute', right: '8px', top: 0, pointerEvents: 'auto', display: 'inline-flex', alignItems: 'center', gap: '5px', maxWidth: 'calc(100% - 16px)', padding: '6px 10px', border: `1px solid ${palette.accentBorder}`, borderRadius: '8px', color: palette.accent, backgroundColor: palette.accentSoft, boxShadow: palette.shadow, fontSize: '12px', lineHeight: '16px', fontWeight: 650 }}><Icon name="check" size={13} />{state.notice}</div></div> : null}
    <label className={css.controlRowEnd} style={{ fontSize: '12px', marginBottom: '4px' }}>{t('languageLabel')}<select value={snapshot.active} onChange={(event) => locale.setLocale?.(event.currentTarget.value)} style={{ height: '26px', padding: '0 7px', border: `1px solid ${palette.border}`, borderRadius: '7px', backgroundColor: palette.field, color: palette.text, fontSize: '12px' }}>{languageOptions.map(([id, key]) => available.has(id) ? <option key={id} value={id}>{t(key)}</option> : null)}</select></label>
    <h3 style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', columnGap: '8px', rowGap: '4px', fontSize: '18px', lineHeight: '24px', fontWeight: 700, letterSpacing: 0, margin: '0 0 7px' }}><Icon name="sliders" size={19} /><span>{t('pageTitle')}</span></h3>
    {state.error ? <div role="alert" aria-live="assertive" style={{ fontSize: '12px', lineHeight: '18px', color: palette.danger, backgroundColor: palette.dangerBg, border: `1px solid ${palette.dangerBorder}`, borderRadius: '8px', padding: '6px 8px', margin: '0 0 8px' }}>{state.error}</div> : null}
    <SubagentSettings effort={state.subagent?.effort ?? null} namespaceFound={state.subagent !== null} draft={state.subagentDraft} custom={state.subagentCustom} busy={state.busy} palette={palette} t={t} onDraftChange={(value) => setState((current) => ({ ...current, notice: null, subagentDraft: value }))} onCustomChange={(value) => setState((current) => ({ ...current, notice: null, subagentCustom: value }))} onSave={applySubagentEffort} />
    <ConfigBackupCard settings={settings} palette={palette} t={t} onApplied={load} />
    <OpenCodeFormatCard settings={settings} palette={palette} t={t} revision={state.openCodeSessionReads} namespace={state.pluginSection?.ns ?? OPENCODE_SESSION_NS} onApplied={load} />
    {state.nsFound === false ? <p style={{ fontSize: '12px', opacity: 0.75 }}>{t('noNamespace')}</p> : <div>
      <div className={css.controlRow} style={{ marginBottom: state.quickSettingsOpen ? '4px' : '6px' }}><ActionButton text={t('quickSettings')} onClick={() => setState((current) => ({ ...current, quickSettingsOpen: !current.quickSettingsOpen }))} disabled={state.busy} palette={palette} icon={state.quickSettingsOpen ? 'chevronUp' : 'sliders'} />{state.quickSettingsOpen ? <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', flexBasis: '100%', padding: '4px', border: `1px solid ${palette.border}`, borderRadius: '8px', backgroundColor: palette.field }}>{PRESETS.map((preset) => <ActionButton key={preset.key} text={t(preset.labelKey)} onClick={() => { setState((current) => ({ ...current, quickSettingsOpen: false })); applyPreset(preset.levels) }} disabled={state.busy} palette={palette} icon={preset.key === 'official' ? 'sparkles' : 'sliders'} />)}</div> : null}</div>
      <div style={{ position: 'relative', marginBottom: '7px' }}><span style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: palette.secondary, pointerEvents: 'none' }}><Icon name="search" size={15} /></span><input type="text" value={state.query} placeholder={t('searchPlaceholder')} onChange={(event) => { const value = event.currentTarget.value; setState((current) => ({ ...current, query: value })) }} style={{ boxSizing: 'border-box', width: '100%', height: '30px', padding: '0 10px 0 30px', border: `1px solid ${palette.border}`, borderRadius: '8px', fontSize: '13px', backgroundColor: palette.field, color: palette.text, outline: 'none', boxShadow: palette.shadow }} /></div>
      {state.loading ? <div style={{ fontSize: '12px', opacity: 0.7 }}>{t('loading')}</div> : visible.length === 0 ? <div style={{ fontSize: '12px', opacity: 0.7 }}>{state.inventory.length === 0 ? t('noModels') : t('noMatches')}</div> :
         routes.map((route) => { const providerModels = visible.filter((item) => item.route === route); const providerOpen = query !== '' || state.expandedProviders[route] === true; return <div key={route} style={{ marginBottom: '6px' }}><div className={css.entityHeader} style={{ minHeight: '32px', padding: '4px 6px', marginBottom: '4px', border: `1px solid ${palette.border}`, borderRadius: '8px', backgroundColor: palette.raised }}><span style={{ display: 'flex', alignItems: 'center', gap: '7px', minWidth: 0 }}><span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '22px', height: '22px', minWidth: '22px', border: `1px solid ${palette.border}`, borderRadius: '7px', color: palette.secondary, backgroundColor: palette.group }}><Icon name="layers" size={14} /></span><span style={{ display: 'grid', gap: '1px', minWidth: 0 }}><span style={{ color: palette.text, fontSize: '12px', fontWeight: 700, overflowWrap: 'anywhere' }}>{route}</span><span style={{ color: palette.accent, fontSize: '10px', lineHeight: '11px', fontWeight: 700 }}>{t('vendor')}</span></span></span><span style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', color: palette.secondary, whiteSpace: 'nowrap' }}><span>{t('modelCount', { count: providerModels.length })}</span>{query !== '' ? <span>{t('searchResults')}</span> : <ActionButton text="" onClick={() => toggleProvider(route)} palette={palette} tone="ghost" icon={providerOpen ? 'chevronUp' : 'chevronDown'} label={providerOpen ? t('collapseProvider') : t('expandProvider')} />}</span></div>{providerOpen && state.providerDrafts[route] ? <>
          {renderGatewayCompatControls({ view: state.providerDrafts[route], onChange: (next) => patchProviderCompat(route, next), disabled: state.busy, expanded: state.providerCompatExpanded[route] === true, onToggleExpanded: () => toggleProviderCompatExpanded(route), availableCount: availableCompatFieldCount(state.providerDrafts[route]) }, { palette, t })}{state.providerDirty[route] ? <ActionButton text={t('saveGatewayCompat')} onClick={() => applyProviderCompat(route)} disabled={state.busy} tone="primary" palette={palette} icon="check" /> : null}</> : null}{providerOpen ? providerModels.map((item) => { const key = keyOf(item); const dirty = state.dirty[key] ?? {}; const compatAvailable = state.modelCompatViews[key] !== undefined; const openCodeSessionEditable = state.openCodeSessionAvailable && item.modelSourceConflict !== true; return <ModelRow key={`${key}-${item.inOverrides ? 'override' : item.index}`} item={item} open={state.expanded[key] === true} draft={state.drafts[key]} contextDraft={state.contextDrafts[key] ?? contextDraftFrom(item)} inputDraft={state.inputDrafts[key] ?? inputDraftFrom(item)} dirty={dirty.levels === true || dirty.context === true || dirty.input === true} busy={state.busy} palette={palette} t={t} onToggle={() => toggleExpand(item)} onLevelChange={(level, patch) => patchDraft(item, level, patch)} onContextChange={(value) => patchContextValue(item, value)} onOneMillionChange={(enabled) => setOneMillion(item, enabled)} onInputChange={(modality, enabled) => patchInputCapability(item, modality, enabled)} onSave={() => applyModel(item)} blockedReason={modelSaveBlockedReason(buildLevels(state.drafts[key] ?? {}), state.contextDrafts[key] ?? contextDraftFrom(item), state.inputDrafts[key] ?? inputDraftFrom(item), t)} onRestoreReasoning={() => restoreReasoningDefaults(item)} onRestoreCapability={() => restoreProviderDefaults(item)}
                         compatView={compatAvailable ? state.modelCompatDrafts[key] : undefined}
                          compatExpanded={state.modelCompatExpanded[key] === true}
                          onToggleCompatExpanded={compatAvailable ? () => toggleModelCompatExpanded(key) : undefined}
                          compatDirty={state.modelCompatDirty[key]} onCompatChange={compatAvailable ? (next) => patchModelCompat(item, next) : undefined} onSaveCompat={compatAvailable ? () => applyModelCompat(item) : undefined} openCodeSession={state.openCodeSessionDrafts[key]} openCodeSessionAvailable={openCodeSessionEditable} onOpenCodeSessionChange={(enabled) => patchOpenCodeSession(item, enabled)} /> }) : null}</div> })}
      {expandedCount > 0 ? <div style={{ fontSize: '12px', color: palette.secondary, margin: '4px 2px 0' }}>{t('expandedSettings', { count: expandedCount })}</div> : null}
    </div>}
    <span aria-label={t('versionLabel')} style={{ position: 'absolute', right: '12px', bottom: '8px', fontSize: '10px', lineHeight: '14px', opacity: 0.45, pointerEvents: 'none', userSelect: 'none' }}>v{PLUGIN_VERSION}</span>
  </div>
}
