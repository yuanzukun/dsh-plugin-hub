import { ALL_LEVELS, CONTEXT_1M, CONTEXT_MAX, CONTEXT_MIN, INPUT_MODALITIES, LEVEL_LABEL_KEYS } from './constants.js'
import type { ContextDraft, InputDraft, InputModality, InventoryItem, ReasoningDraft, ReasoningEfforts, Translation } from './types.js'

export function draftFrom(levels: ReasoningEfforts | null | undefined): ReasoningDraft {
  const draft: ReasoningDraft = {}
  for (const level of ALL_LEVELS) {
    const value = levels?.[level]
    const wire = value === undefined ? '' : value === null ? '' : String(value)
    draft[level] = { on: wire !== '' || (level === 'off' && levels?.off === null), wire }
  }
  return draft
}

export function buildLevels(draft: ReasoningDraft): ReasoningEfforts {
  const output: ReasoningEfforts = {}
  for (const level of ALL_LEVELS) {
    const cell = draft[level]
    if (!cell?.on) continue
    output[level] = level === 'off' ? (cell.wire.trim() === '' ? null : cell.wire.trim()) : cell.wire.trim()
  }
  return output
}

export function contextDraftFrom(item: Pick<InventoryItem, 'contextWindow'>): ContextDraft {
  const contextWindow = Number.isInteger(item.contextWindow) ? item.contextWindow : undefined
  const value = contextWindow === undefined ? '' : String(contextWindow)
  return {
    value,
    oneMillion: contextWindow === CONTEXT_1M,
    previousValue: contextWindow === CONTEXT_1M ? '' : value,
    touched: false,
  }
}

export function inputDraftFrom(item: Pick<InventoryItem, 'input'>): InputDraft {
  const declared = Array.isArray(item.input) ? item.input : []
  const effective: readonly InputModality[] = declared.length > 0 ? declared : ['text']
  return { text: effective.includes('text'), image: effective.includes('image'), touched: false }
}

export function buildInput(draft: Pick<InputDraft, 'text' | 'image'> | undefined, translate: Translation): { value?: readonly ('text' | 'image')[]; error?: string } {
  if (!draft) return { value: undefined }
  const value = INPUT_MODALITIES.filter((modality) => draft[modality] === true)
  return value.length === 0 ? { error: translate('inputCapabilityMinimum') } : { value }
}

export function validateContextWindow(
  draft: Pick<ContextDraft, 'value' | 'oneMillion'> | undefined,
  translate: Translation,
): { value?: number; error?: string } {
  if (!draft) return { value: undefined }
  if (draft.oneMillion) return { value: CONTEXT_1M }
  const raw = typeof draft.value === 'string' ? draft.value.trim().toLowerCase() : ''
  if (raw === '') return { value: undefined }
  // `k` follows the binary convention the industry uses for token budgets, so
  // `64k` is 65536 rather than 64000. The stored value stays a plain integer.
  const kSuffix = /^(\d+)\s*k$/.exec(raw)
  if (kSuffix === null && !/^\d+$/.test(raw)) return { error: translate('contextInteger') }
  const value = kSuffix === null ? Number(raw) : Number(kSuffix[1]) * 1024
  if (!Number.isSafeInteger(value) || value < CONTEXT_MIN || value > CONTEXT_MAX) return { error: translate('contextRange') }
  return { value }
}

export function validateLevels(levels: ReasoningEfforts, translate: Translation): string | null {
  let hasThinking = false
  for (const [level, wire] of Object.entries(levels)) {
    if (level === 'off') continue
    hasThinking = true
    if (typeof wire !== 'string' || wire.length === 0) {
      return translate('levelNeedsValue', { level: translate(LEVEL_LABEL_KEYS[level as keyof typeof LEVEL_LABEL_KEYS] ?? level) })
    }
  }
  return hasThinking ? null : translate('atLeastThinking')
}

/**
 * Why one model's editor cannot be saved, or `null` when it can.
 *
 * The write path and the Save button's affordance must agree on this: the
 * button is disabled on exactly the condition the write would refuse, so the
 * refusal is visible where the user is looking instead of only in the
 * page-top banner. Both read this one function rather than restating the
 * order of the checks, which is also the order the errors are reported in.
 *
 * Only a TOUCHED context or input draft is validated, matching the write path:
 * an untouched field means "leave the stored value alone", so its placeholder
 * value is not a refusal.
 */
export function modelSaveBlockedReason(
  levels: ReasoningEfforts,
  contextDraft: ContextDraft | undefined,
  inputDraft: InputDraft | undefined,
  translate: Translation,
): string | null {
  const levelError = validateLevels(levels, translate)
  if (levelError !== null) return levelError
  if (contextDraft?.touched === true) {
    const context = validateContextWindow(contextDraft, translate)
    if (context.error !== undefined) return context.error
  }
  if (inputDraft?.touched === true) {
    const input = buildInput(inputDraft, translate)
    if (input.error !== undefined) return input.error
  }
  return null
}

export { ALL_LEVELS, CONTEXT_1M, CONTEXT_MAX, CONTEXT_MIN }
