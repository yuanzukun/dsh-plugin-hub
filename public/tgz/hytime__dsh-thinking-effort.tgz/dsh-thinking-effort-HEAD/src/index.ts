import { mark } from './host/marker.js'
import { installSettingsWatcher } from './host/settings.js'
import { installOpenCodeSession } from './host/opencode-session.js'
import { installLegacyMigration } from './host/legacy-watcher.js'
import { handleAgentRequest } from './host/subagent.js'
import type { HostContext } from './host/types.js'

export const name = '@hytime/dsh-thinking-effort'
export const inject = ['settings', 'timer', 'llm'] as const

/**
 * The Loader entry's config schema. DSH 0.1.7 derives the settings form from
 * it, so it must stay exported from the package entry.
 */
export { Config } from './host/plugin-settings.js'

export function apply(ctx: HostContext): void {
  mark('apply')
  installSettingsWatcher(ctx)
  installOpenCodeSession(ctx)
  installLegacyMigration(ctx)
  ctx.on('agent/request', (...args: unknown[]) => {
    const payload = args[0]
    const next = args[1] as () => Promise<unknown>
    return handleAgentRequest(ctx, payload, next)
  }, { global: true })
}
