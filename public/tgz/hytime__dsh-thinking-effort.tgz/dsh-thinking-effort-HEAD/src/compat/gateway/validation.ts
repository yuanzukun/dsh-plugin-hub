import { GATEWAY_COMPAT_FIELDS, GATEWAY_COMPAT_FIELD_KEYS, fieldsForApi } from './fields.js'
import type { GatewayCompatFieldKey } from './fields.js'
import type { DshVersionCapabilities } from '../version-map.js'
import type { GatewayCompatEditability, GatewayCompatValidationResult } from './types.js'
import { isUnknownRecord } from '../../shared/guards.js'

type RuntimeProfile = 'modern' | 'legacy' | 'unknown'
type EditabilityCapabilities = DshVersionCapabilities | RuntimeProfile

function record(value: unknown): Record<string, unknown> | undefined {
  return isUnknownRecord(value) ? value : undefined
}

function hasProperty(value: unknown, key: string): boolean {
  const object = record(value)
  return object !== undefined && Object.prototype.hasOwnProperty.call(object, key)
}

function dereference(value: unknown, refs: Record<string, unknown> | undefined): unknown {
  let current = value
  const seen = new Set<string>()
  while (typeof current === 'number' && refs !== undefined) {
    const key = String(current)
    if (seen.has(key) || !Object.prototype.hasOwnProperty.call(refs, key)) return undefined
    seen.add(key)
    current = refs[key]
  }
  return current
}

/**
 * The schema node one field path addresses.
 *
 * `schema` is whatever a `settings/describe` row publishes — under the
 * `entry-config` model that is `Schema.prototype.toJSON()`, a `{ uid, refs }`
 * envelope whose root sits at `refs[String(uid)]` and whose children are
 * numeric references into the same table. An envelope carries no top-level
 * `dict`, so `schema.dict` reads nothing there: reading a form's fields means
 * resolving the root through here first. Paths name `dict`/`properties` keys,
 * with `*` for the `additionalProperties`/inner node of a dict or array. A
 * plain (non-envelope) schema is walked in place, which is what the
 * hand-written fixtures use.
 */
export function schemaNodeAtPath(schema: unknown, path: readonly string[]): Record<string, unknown> | undefined {
  const envelope = record(schema)
  const refs = record(envelope?.refs)
  let node: unknown = refs !== undefined && envelope?.uid !== undefined
    ? refs[String(envelope.uid)]
    : schema

  for (const key of path) {
    const object = record(dereference(node, refs))
    if (object === undefined) return undefined
    const properties = record(object.dict) ?? record(object.properties)
    const child = key === '*'
      ? object.additionalProperties ?? properties?.['*']
      : properties?.[key]
    const next = child ?? (object.type === 'dict' || object.type === 'array' ? object.inner : undefined)
    node = dereference(next, refs)
  }

  return record(dereference(node, refs))
}

function schemaProperties(value: unknown): Record<string, unknown> | undefined {
  const object = record(value)
  if (!object) return undefined
  const properties = record(object.properties) ?? record(object.dict)
  if (properties) return properties
  const schema = record(object.schema)
  if (schema) return schemaProperties(schema)
  const inner = record(object.inner)
  if (inner) return schemaProperties(inner)
  const objectSchema = record(object.object)
  if (objectSchema) return schemaProperties(objectSchema)
  const additionalProperties = record(object.additionalProperties)
  if (additionalProperties) return schemaProperties(additionalProperties)
  const items = record(object.items)
  if (items) return schemaProperties(items)
  return undefined
}

function compatProperties(schema: unknown): Record<string, unknown> | undefined {
  const pathNode = schemaNodeAtPath(schema, ['providers', '*', 'compat'])
  const pathProperties = schemaProperties(pathNode)
  if (pathProperties && GATEWAY_COMPAT_FIELD_KEYS.some((field) => hasProperty(pathProperties, field))) return pathProperties

  const direct = schemaProperties(schema)
  if (direct && GATEWAY_COMPAT_FIELD_KEYS.some((field) => hasProperty(direct, field))) return direct

  const providers = direct?.providers
  const providerProperties = schemaProperties(providers)
  const compat = providerProperties?.compat
  const nested = schemaProperties(compat)
  if (nested) return nested

  const descriptor = record(schema)
  if (!descriptor) return undefined
  for (const key of ['schema', 'value', 'descriptor']) {
    const nestedResult = compatProperties(descriptor[key])
    if (nestedResult) return nestedResult
  }
  return undefined
}

function schemaAllowsField(schema: unknown, field: GatewayCompatFieldKey): boolean {
  const properties = compatProperties(schema)
  return properties !== undefined && hasProperty(properties, field)
}

function runtimeAllowsField(
  capabilities: EditabilityCapabilities | undefined,
  field: GatewayCompatFieldKey,
): boolean {
  if (capabilities === 'modern' || capabilities === 'legacy') return true
  if (capabilities === 'unknown' || capabilities === undefined || capabilities === null || typeof capabilities !== 'object') return false
  return Array.isArray(capabilities.gatewayCompatFields) && capabilities.gatewayCompatFields.includes(field)
}

/**
 * Compute which gateway compat fields are editable for a provider route.
 *
 * A field must pass (a) the runtime version capabilities, (b) the descriptor
 * schema offering it, and — when `api` is provided — (c) the route protocol's
 * offer (`fieldsForApi`). When `api` is absent the protocol gate is skipped, so
 * routes without a declared protocol keep full-field compatibility. The
 * resulting availability map only marks fields the filtered set offers, so the
 * UI never presents (and never attempts to write) a field DSH's
 * `assertOfferedCompatFields` would reject for that protocol.
 */
export function editableProviderCompatFields(
  capabilities: EditabilityCapabilities | undefined,
  descriptorSchema: unknown,
  api?: unknown,
): GatewayCompatEditability {
  const protocolFields = api === undefined ? undefined : fieldsForApi(api)
  const editableFieldsResult = GATEWAY_COMPAT_FIELD_KEYS.filter((field) => (
    runtimeAllowsField(capabilities, field)
    && schemaAllowsField(descriptorSchema, field)
    && (protocolFields === undefined || protocolFields.includes(field))
  ))
  const availability = Object.fromEntries(
    editableFieldsResult.map((field) => [field, true]),
  ) as Partial<Record<GatewayCompatFieldKey, boolean>>
  return { ...availability, editableFields: editableFieldsResult }
}

export function validateProviderCompat(
  capabilities: EditabilityCapabilities | undefined,
  descriptorSchema: unknown,
  api?: unknown,
): GatewayCompatValidationResult {
  const fields = editableProviderCompatFields(capabilities, descriptorSchema, api)
  return {
    ...fields,
    available: fields.supportsDeveloperRole === true && fields.maxTokensField === true,
  }
}
