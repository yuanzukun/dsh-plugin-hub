import { describe, expect, it, vi } from 'vitest'

import { apply, inject, name } from '../src/client/index.js'
import { LOCALE_NS } from '../src/client/constants.js'
import { PLUGIN_ENTRY_ID } from '../src/shared/constants.js'
import { observeTakeoverSettings, resolveTakeoverDescription } from '../src/client/takeover-runtime.js'
import { providerGatewayCompatViewFrom } from '../src/client/model-inventory.js'
import { resolveTakeoverGatewayCompat, resolveTakeoverProviders, takeoverGatewayCompatInputs } from '../src/compat/gateway/resolve.js'
import type { ClientContext, SettingsNamespace } from '../src/client/types.js'

function createHarness(mode: 'modern' | 'legacy') {
  const listeners: Array<(name: string) => void> = []
  const registrations: Array<{ descriptor: Record<string, unknown>; render: unknown }> = []
  const disposed: string[] = []
  const addLanguage = vi.fn((entry: { id: string }) => () => disposed.push(entry.id))
  const register = vi.fn(() => () => disposed.push('dictionary'))
  const locale = {
    register,
    addLanguage,
    bind: () => (key: string) => key,
    getSnapshot: () => ({ active: 'zh', locales: [{ id: 'zh' }] }),
  }
  const effectDisposers: Array<() => void> = []
  const slots = {
    inject: vi.fn((_name: string, callback: () => (() => void) | undefined) => {
      const disposer = callback()
      if (typeof disposer === 'function') effectDisposers.push(disposer)
      return disposer ?? (() => undefined)
    }),
    register: vi.fn((descriptor: Record<string, unknown>, render: unknown) => {
      registrations.push({ descriptor, render })
      return () => disposed.push('slot')
    }),
  }
  // Official ui-model-selection face, mirrored minimally: per-session
  // directory exposing store/load/select (see task-0-preflight).
  const directory = {
    store: {
      getSnapshot: () => ({ status: 'idle' }),
      subscribe: () => () => undefined,
    },
    load: vi.fn(),
    select: vi.fn(),
  }
  const modelDirectories = {
    directoryFor: vi.fn(() => directory),
  }
  const remoteSettings = {
    describe: vi.fn().mockResolvedValue({ ok: true, value: { namespaces: [] } }),
    mutate: vi.fn().mockResolvedValue({ ok: true, value: { namespaces: [] } }),
  }
  const legacySettings = {
    describe: vi.fn().mockResolvedValue({ result: { ok: true, value: { namespaces: [] } } }),
    mutate: vi.fn().mockResolvedValue({ result: { ok: true, value: { namespaces: [] } } }),
  }
  const connection = mode === 'legacy' ? { api: { settings: legacySettings } } : {}
  // Modern DSH exposes the `remote.session` Remote namespace (modelCatalog etc.);
  // legacy transports do not. The seat probes this shape to decide whether to
  // declare `remote.session` in its inject list.
  const sessionRemote = mode === 'modern' ? { modelCatalog: vi.fn().mockResolvedValue({ ok: true }) } : undefined
  const remote = {}
  const sessions = {}
  // `ctx.configForms` is optional and belongs to a DIFFERENT client entry, so it
  // may only exist after this plugin's `apply`. Mutable on purpose: a test can
  // present it late, exactly as the host does.
  let configForms: unknown
  const context = {
    get: vi.fn((key: string) => key === 'remote.settings'
      ? mode === 'modern' ? remoteSettings : undefined
      : key === 'modelDirectories'
        ? modelDirectories
        : key === 'remote.session'
          ? sessionRemote
          : key === 'remote'
            ? remote
            : key === 'sessions'
              ? sessions
              : key === 'configForms'
                ? configForms
                : ({ slots, connection, locale }[key as 'slots' | 'connection' | 'locale'])),
    plugin: vi.fn((plugin: { inject?: readonly string[]; apply: (scope: ClientContext) => void }) => {
      const allPresent = (plugin.inject ?? []).every((name) => context.get(name) !== undefined)
      if (!allPresent) return () => undefined
      plugin.apply({ ...context, slots, modelDirectories } as unknown as ClientContext)
      return () => undefined
    }),
    inject: vi.fn(() => () => undefined),
    on: vi.fn((event: string, callback: (name: string) => void) => {
      expect(event).toBe('internal/service')
      listeners.push(callback)
      return () => undefined
    }),
    effect: vi.fn((callback: () => void | (() => void)) => {
      const disposer = callback() as (() => void) | undefined
      if (disposer !== undefined) effectDisposers.push(disposer)
      return disposer
    }),
  }

  return {
    context, slots, locale, listeners, registrations, disposed, addLanguage, register,
    remoteSettings, legacySettings, sessionRemote, modelDirectories, directory,
    // Present (or replace) the optional `configForms` service, mimicking a
    // late-activating sibling client entry. The event a real host emits for that
    // activation is this plugin's `internal/service` notification.
    provideConfigForms: (service: unknown) => { configForms = service },
    // Cordis tears effects down in reverse registration order.
    disposeAllEffects: () => { for (const disposer of effectDisposers.reverse()) disposer() },
  }
}


describe('client registration through the guarded context', () => {
  it('mounts after the remote.settings service is announced without context.inject', () => {
    const registrations: Array<{ descriptor: Record<string, unknown>; render: unknown }> = []
    const listeners: Array<(name: string) => void> = []
    let remoteSettings: unknown
    const slots = {
      inject: vi.fn((_name: string, callback: () => void) => callback()),
      register: vi.fn((descriptor: Record<string, unknown>, render: unknown) => {
        registrations.push({ descriptor, render })
        return () => undefined
      }),
    }
    const locale = {
      register: vi.fn(() => () => undefined),
      bind: () => (key: string) => key,
      getSnapshot: () => ({ locales: [{ id: 'zh' }] }),
    }
    const services: Record<string, unknown> = {
      slots,
      connection: {},
      locale,
      // The composer seat needs the optional directory service; without it
      // only the settings mount's two slots register (asserted below).
      modelDirectories: undefined,
    }
    const context = {
      get: vi.fn((key: string) => key === 'remote.settings' ? remoteSettings : services[key]),
      plugin: vi.fn((plugin: { inject?: readonly string[]; apply: (scope: ClientContext) => void }) => {
        for (const name of plugin.inject ?? []) {
          if (context.get(name) === undefined) return () => undefined
        }
        plugin.apply(context)
        return () => undefined
      }),
      inject: vi.fn(() => () => undefined),
      on: vi.fn((event: string, callback: (name: string) => void) => {
        expect(event).toBe('internal/service')
        listeners.push(callback)
        return () => undefined
      }),
      effect: vi.fn((callback: () => void | (() => void)) => callback()),
    }

    apply(context as Parameters<typeof apply>[0])
    expect(registrations).toHaveLength(0)

    remoteSettings = {
      describe: vi.fn(),
      mutate: vi.fn(),
    }
    for (const listener of listeners) listener('remote.settings')

    expect(registrations).toHaveLength(2)
    expect(registrations[0]?.descriptor).toMatchObject({
      name: 'settings.section',
      id: 'thinking-effort',
    })
    expect(registrations[1]?.descriptor).toMatchObject({
      name: 'shell.overlay',
      id: 'thinking-effort-legacy-migration',
    })
  })
})

describe('client registration', () => {
  it('resolves takeover capabilities from the mounted settings descriptor', async () => {
    const harness = createHarness('legacy')
    harness.legacySettings.describe.mockResolvedValue({
      result: {
        ok: true,
        value: {
          namespaces: [{
            ns: 'llm-pi-ai',
            revision: 1,
            value: {
              providers: {
                local: {
                  api: 'openai-completions',
                  baseURL: 'http://gateway.test/v1',
                  models: [{ id: 'model', reasoningEfforts: { high: 'high' }, compat: { thinkingFormat: 'qwen', supportsReasoningEffort: true } }],
                },
              },
            },
            schema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: {} } } } } } },
          }],
        },
      },
    })

    apply(harness.context)
    const render = harness.registrations[0]?.render
    const element = (render as () => { props?: { settings?: { describe: () => Promise<unknown> } } })()
    await element.props?.settings?.describe()

    expect(harness.legacySettings.describe).toHaveBeenCalled()
  })

  it('re-resolves after the observed settings API describes or mutates', async () => {
    const harness = createHarness('modern')
    apply(harness.context)
    const render = harness.registrations[0]?.render
    const element = (render as () => { props?: { settings?: { describe: () => Promise<unknown>; mutate: (ns: string, ops: readonly unknown[], revision: number) => Promise<unknown> } } })()
    const observed = element.props?.settings
    expect(observed).toBeDefined()

    await observed!.describe()
    await observed!.mutate('llm-pi-ai', [], 1)
    await Promise.resolve()

    expect(harness.remoteSettings.describe.mock.calls.length).toBeGreaterThanOrEqual(2)
  })

  it('passes the resolved takeover snapshot to the settings consumer', async () => {
    const harness = createHarness('modern')
    harness.remoteSettings.describe.mockResolvedValue({
      ok: true,
      value: {
        namespaces: [{
          ns: 'llm-pi-ai',
          revision: 1,
          value: {
            providers: {
              local: {
                api: 'openai-completions',
                baseURL: 'http://gateway.test/v1',
                models: [{ id: 'model', reasoningEfforts: { high: 'high' }, compat: { thinkingFormat: 'qwen', supportsReasoningEffort: true } }],
              },
            },
          },
          schema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } },
        }],
      },
    })

    apply(harness.context)
    const render = harness.registrations[0]?.render
    const element = (render as () => { props?: Record<string, unknown> })()
    const observed = element.props?.settings as { describe: () => Promise<unknown> }
    await observed.describe()

    const runtime = element.props?.takeoverRuntime as { getSnapshot: () => { providers: readonly string[]; compat: readonly unknown[] } }
    expect(runtime.getSnapshot()).toMatchObject({
      providers: ['local'],
      compat: expect.arrayContaining([expect.objectContaining({ provider: 'local', model: 'model' })]),
    })
  })

  it('clears the runtime snapshot when the mount effect is disposed', () => {
    const harness = createHarness('modern')
    apply(harness.context)
    const render = harness.registrations[0]?.render
    const element = (render as () => { props?: Record<string, unknown> })()
    const runtime = element.props?.takeoverRuntime as { getSnapshot: () => { providers: readonly string[]; compat: readonly unknown[] }; update: (resolution: { providers: readonly string[]; compat: readonly unknown[] }) => void }
    runtime.update({ providers: ['local'], compat: [] })

    harness.disposeAllEffects()

    expect(runtime.getSnapshot()).toEqual({ providers: [], compat: [] })
  })

  it.each([
    ['rc7 remains unsupported', 'legacy' as const, { properties: { providers: { additionalProperties: { properties: { compat: { properties: {} } } } } } }, [], false],
    ['rc2 accepts the optional takeover', 'legacy' as const, { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } }, ['local'], true],
    ['alpha2 accepts the optional takeover', 'modern' as const, { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } }, ['local'], true],
  ])('%s publishes the expected runtime capability result', (_label, profile, schema, expectedProviders, includeTakeover) => {
    const piAiNamespace = {
      ns: 'llm-pi-ai',
      revision: 1,
      value: {
        providers: {
          local: {
            api: 'openai-completions',
            baseURL: 'http://gateway.test/v1',
            models: [{ id: 'model', reasoningEfforts: { high: 'high' }, compat: { thinkingFormat: 'qwen', supportsReasoningEffort: true } }],
          },
        },
      },
      schema,
    }
    const response = {
      ok: true as const,
      value: {
        namespaces: [
          piAiNamespace,
          ...(includeTakeover ? [{ ns: 'llm-openai-completions', revision: 1, value: { enabled: true, providers: ['local'] } }] : []),
        ],
      },
    }

    expect(resolveTakeoverDescription({ compatibilityProfile: profile }, response).providers).toEqual(expectedProviders)
  })

  it('ignores late descriptions after the observer is disposed', async () => {
    let resolveDescription!: (value: { ok: true; value: { namespaces: [] } }) => void
    const settings = {
      externalLanguages: false,
      compatibilityProfile: 'modern' as const,
      describe: vi.fn(() => new Promise<{ ok: true; value: { namespaces: [] } }>((resolve) => { resolveDescription = resolve })),
      mutate: vi.fn(),
    }
    const onResolution = vi.fn()
    const observed = observeTakeoverSettings(settings, onResolution)
    const pending = observed.describe()
    observed.dispose()
    resolveDescription({ ok: true, value: { namespaces: [] } })
    await pending

    expect(onResolution).not.toHaveBeenCalled()
  })

  it('publishes only the newest overlapping description', async () => {
    const resolvers: Array<(value: { ok: true; value: { namespaces: [] } }) => void> = []
    const settings = {
      externalLanguages: false,
      compatibilityProfile: 'modern' as const,
      describe: vi.fn(() => new Promise<{ ok: true; value: { namespaces: [] } }>((resolve) => { resolvers.push(resolve) })),
      mutate: vi.fn(),
    }
    const onResolution = vi.fn()
    const observed = observeTakeoverSettings(settings, onResolution)
    const first = observed.describe()
    const second = observed.describe()
    resolvers[1]!({ ok: true, value: { namespaces: [] } })
    await second
    resolvers[0]!({ ok: true, value: { namespaces: [] } })
    await first

    expect(onResolution).toHaveBeenCalledTimes(1)
  })

  it('does not describe again after a failed mutation', async () => {
    const settings = {
      externalLanguages: false,
      compatibilityProfile: 'modern' as const,
      describe: vi.fn(),
      mutate: vi.fn().mockResolvedValue({ ok: false as const, error: { message: 'conflict' } }),
    }
    const observed = observeTakeoverSettings(settings, vi.fn())

    await observed.mutate('llm-pi-ai', [], 1)

    expect(settings.describe).not.toHaveBeenCalled()
  })

  it('keeps model-level takeover compat separate instead of projecting the first model', () => {
    const result = resolveTakeoverDescription({ compatibilityProfile: 'modern' }, {
      ok: true,
      value: {
        namespaces: [{
          ns: 'llm-pi-ai',
          revision: 1,
          value: {
            providers: {
              local: {
                api: 'openai-completions',
                baseURL: 'http://gateway.test/v1',
                models: [
                  { id: 'first', reasoningEfforts: { high: 'high' }, compat: { maxTokensField: 'max_tokens' } },
                  { id: 'second', reasoningEfforts: { high: 'high' }, compat: { maxTokensField: 'max_completion_tokens' } },
                ],
              },
            },
          },
          schema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } },
        }],
      },
    })

    expect(result.compat).toEqual(expect.arrayContaining([
      expect.objectContaining({ provider: 'local' }),
      expect.objectContaining({ provider: 'local', model: 'first', maxTokensField: { value: 'max_tokens', source: 'model' } }),
      expect.objectContaining({ provider: 'local', model: 'second', maxTokensField: { value: 'max_completion_tokens', source: 'model' } }),
    ]))
    const view = providerGatewayCompatViewFrom({
      value: { providers: { local: { models: [{ id: 'first' }, { id: 'second' }] } } },
      schema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } },
    }, 'local', 'modern', result)
    expect(view.maxTokensField).toBe('auto')
  })

  it('does not publish takeover compatibility when both model sources are present', () => {
    const result = resolveTakeoverDescription({ compatibilityProfile: 'modern' }, {
      ok: true,
      value: {
        namespaces: [{
          ns: 'llm-pi-ai',
          revision: 1,
          value: {
            providers: {
              local: {
                api: 'openai-completions',
                baseURL: 'http://gateway.test/v1',
                models: [{ id: 'model', reasoningEfforts: { high: 'high' }, compat: { maxTokensField: 'max_tokens' } }],
                modelOverrides: { model: { reasoningEfforts: { high: 'high' }, compat: { maxTokensField: 'max_completion_tokens' } } },
              },
            },
          },
          schema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } },
        }],
      },
    })

    expect(result).toEqual({ providers: [], compat: [] })
  })

  it('does not publish takeover compatibility when model sources are split across descriptor layers', () => {
    const result = resolveTakeoverDescription({ compatibilityProfile: 'modern' }, {
      ok: true,
      value: {
        namespaces: [{
          ns: 'llm-pi-ai',
          revision: 1,
          value: {
            providers: {
              local: {
                api: 'openai-completions',
                baseURL: 'http://gateway.test/v1',
                models: [{ id: 'model', reasoningEfforts: { high: 'high' } }],
              },
            },
          },
          user: {
            providers: {
              local: {
                modelOverrides: { model: { reasoningEfforts: { high: 'override-high' } } },
              },
            },
          },
          schema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } },
        }],
      },
    })

    expect(result).toEqual({ providers: [], compat: [] })
  })

  it('enumerates model overrides when models is an empty array', () => {
    const result = resolveTakeoverDescription({ compatibilityProfile: 'modern' }, {
      ok: true,
      value: {
        namespaces: [{
          ns: 'llm-pi-ai',
          revision: 1,
          value: {
            providers: {
              local: {
                api: 'openai-completions',
                baseURL: 'http://gateway.test/v1',
                models: [],
                modelOverrides: {
                  'override-model': {
                    reasoningEfforts: { high: 'high' },
                    compat: { maxTokensField: 'max_completion_tokens' },
                  },
                },
              },
            },
          },
          schema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } },
        }],
      },
    })

    expect(result.providers).toEqual(['local'])
    expect(result.compat).toEqual(expect.arrayContaining([
      expect.objectContaining({ provider: 'local', model: 'override-model', maxTokensField: { value: 'max_completion_tokens', source: 'model' } }),
    ]))
  })

  it('keeps takeover model resolution own-property based and fail closed for malformed entries', () => {
    const inherited = Object.create({ inherited: { compat: { supportsDeveloperRole: true } } }) as Record<string, unknown>
    Object.defineProperty(inherited, '__proto__', {
      configurable: true,
      enumerable: true,
      value: { compat: { maxTokensField: 'max_tokens' } },
      writable: true,
    })
    inherited.malformed = null
    const section = {
      providers: {
        local: {
          compat: { supportsDeveloperRole: false },
          modelOverrides: inherited,
        },
      },
    }

    expect(takeoverGatewayCompatInputs(section, 'local', 'inherited')).toEqual({
      providerCompat: { supportsDeveloperRole: false },
    })
    expect(takeoverGatewayCompatInputs(section, 'local', '__proto__')).toEqual({
      providerCompat: { supportsDeveloperRole: false },
      modelCompat: { maxTokensField: 'max_tokens' },
    })
    expect(takeoverGatewayCompatInputs(section, 'local', 'malformed')).toEqual({
      providerCompat: { supportsDeveloperRole: false },
    })
  })
  it('always schedules a post-mutation describe when an older describe overlaps it', async () => {
    type MutationResult = { ok: true; value: { ns: string; revision: number; value: Record<string, unknown> } }
    type DescriptionResult = { ok: true; value: { namespaces: SettingsNamespace[] } }
    const schema = { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } }
    const description = (provider: string): DescriptionResult => ({
      ok: true,
      value: {
        namespaces: [{
          ns: 'llm-pi-ai',
          revision: provider === 'old' ? 3 : 4,
          value: { providers: { [provider]: { api: 'openai-completions', baseURL: 'http://gateway.test/v1', compat: { supportsDeveloperRole: provider === 'old' }, models: [{ id: 'model', reasoningEfforts: { high: 'high' }, compat: { maxTokensField: provider === 'old' ? 'max_tokens' : 'max_completion_tokens' } }] } } },
          schema,
        }],
      },
    })
    let resolveMutation!: (value: MutationResult) => void
    const descriptions: Array<(value: DescriptionResult) => void> = []
    const settings = {
      externalLanguages: false,
      compatibilityProfile: 'modern' as const,
      describe: vi.fn(() => new Promise<DescriptionResult>((resolve) => { descriptions.push(resolve) })),
      mutate: vi.fn(() => new Promise<MutationResult>((resolve) => { resolveMutation = resolve })),
    }
    const resolutions: Array<{ providers: readonly string[]; compat: readonly unknown[] }> = []
    const observed = observeTakeoverSettings(settings, (resolution) => resolutions.push(resolution))

    const mutation = observed.mutate('llm-pi-ai', [], 1)
    const overlappingDescribe = observed.describe()
    resolveMutation({ ok: true, value: { ns: 'llm-pi-ai', revision: 2, value: {} } })
    await mutation

    expect(settings.describe).toHaveBeenCalledTimes(2)
    descriptions[0]!(description('old'))
    descriptions[1]!(description('new'))
    await overlappingDescribe
    await Promise.resolve()
    expect(resolutions).toHaveLength(1)
    expect(resolutions[0]).toMatchObject({
      providers: ['new'],
      compat: expect.arrayContaining([
        expect.objectContaining({
          provider: 'new',
          supportsDeveloperRole: { value: false, source: 'provider' },
        }),
        expect.objectContaining({
          provider: 'new',
          model: 'model',
          maxTokensField: { value: 'max_completion_tokens', source: 'model' },
        }),
      ]),
    })
    expect(resolutions[0]?.compat).not.toEqual(expect.arrayContaining([expect.objectContaining({ provider: 'old' })]))
  })

  it('invalidates the previous runtime snapshot when post-mutation describe rejects', async () => {
    let describeCount = 0
    const settings = {
      externalLanguages: false,
      compatibilityProfile: 'modern' as const,
      describe: vi.fn(async () => {
        describeCount += 1
        if (describeCount === 1) {
          return {
            ok: true as const,
            value: {
              namespaces: [{
                ns: 'llm-pi-ai',
                revision: 1,
                value: { providers: { local: { api: 'openai-completions', baseURL: 'http://gateway.test/v1', models: [{ id: 'model', reasoningEfforts: { high: 'high' } }] } } },
                schema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } },
              }],
            },
          }
        }
        throw new Error('describe unavailable')
      }),
      mutate: vi.fn(async () => ({ ok: true as const, value: { ns: 'llm-pi-ai', revision: 2, value: {} } })),
    }
    const resolutions: Array<{ providers: readonly string[]; compat: readonly unknown[] }> = []
    const observed = observeTakeoverSettings(settings, (resolution) => resolutions.push(resolution))

    await observed.describe()
    await observed.mutate('llm-pi-ai', [], 1)
    await Promise.resolve()
    await Promise.resolve()

    expect(resolutions.at(-1)).toEqual({ providers: [], compat: [] })
    observed.dispose()
  })

  it('republishes a valid resolution after a rejected post-mutation describe', async () => {
    let describeCount = 0
    const valid = {
      ok: true as const,
      value: {
        namespaces: [{
          ns: 'llm-pi-ai',
          revision: 1,
          value: { providers: { local: { api: 'openai-completions', baseURL: 'http://gateway.test/v1', models: [{ id: 'model', reasoningEfforts: { high: 'high' } }] } } },
          schema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } },
        }],
      },
    }
    const settings = {
      externalLanguages: false,
      compatibilityProfile: 'modern' as const,
      describe: vi.fn(async () => {
        describeCount += 1
        if (describeCount === 2) throw new Error('describe unavailable')
        return valid
      }),
      mutate: vi.fn(async () => ({ ok: true as const, value: { ns: 'llm-pi-ai', revision: 2, value: {} } })),
    }
    const resolutions: Array<{ providers: readonly string[]; compat: readonly unknown[] }> = []
    const observed = observeTakeoverSettings(settings, (resolution) => resolutions.push(resolution))

    await observed.describe()
    await observed.mutate('llm-pi-ai', [], 1)
    await Promise.resolve()
    await Promise.resolve()
    expect(resolutions.at(-1)).toEqual({ providers: [], compat: [] })

    await observed.describe()

    expect(resolutions.at(-1)).toMatchObject({
      providers: ['local'],
      compat: expect.arrayContaining([expect.objectContaining({ provider: 'local', model: 'model' })]),
    })
    observed.dispose()
  })

  it('uses runtime profile and descriptor schema to fail closed for takeover capability', () => {
    const piAi = {
      providers: {
        local: {
          api: 'openai-completions',
          baseURL: 'http://gateway.test/v1',
          models: [{ id: 'model', reasoningEfforts: { high: 'high' }, compat: { thinkingFormat: 'qwen', supportsReasoningEffort: true } }],
        },
      },
    }
    const oldSchema = { properties: { providers: { additionalProperties: { properties: { compat: { properties: {} } } } } } }
    const fullSchema = { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } }

    expect(resolveTakeoverProviders({ runtimeProfile: 'legacy', descriptorSchema: oldSchema, piAi })).toEqual([])
    expect(resolveTakeoverProviders({ runtimeProfile: 'legacy', descriptorSchema: fullSchema, piAi })).toEqual(['local'])
    expect(resolveTakeoverGatewayCompat({ runtimeProfile: 'legacy', descriptorSchema: fullSchema, piAi, provider: 'local', model: 'model' })).toMatchObject({
      thinkingFormat: { value: 'qwen', source: 'model' },
      supportsReasoningEffort: { value: true, source: 'model' },
    })
    expect(resolveTakeoverProviders({ runtimeProfile: 'unknown', descriptorSchema: fullSchema, piAi })).toEqual([])
  })

  it('falls back to the detected runtime profile for versions newer than the mapped windows', () => {
    const piAi = {
      providers: {
        local: {
          api: 'openai-completions',
          baseURL: 'http://gateway.test/v1',
          models: [{ id: 'model', reasoningEfforts: { high: 'high' }, compat: { thinkingFormat: 'qwen', supportsReasoningEffort: true } }],
        },
      },
    }
    const fullSchema = { properties: { providers: { additionalProperties: { properties: { compat: { properties: { supportsDeveloperRole: {}, maxTokensField: {} } } } } } } }

    // A mapped version keeps owning its transport, even when the profile could take over.
    expect(resolveTakeoverProviders({ version: '0.1.0-rc.7', runtimeProfile: 'modern', descriptorSchema: fullSchema, piAi })).toEqual([])
    // The 0.2.0 line is mapped to the same window, so it takes the mapped path too.
    expect(resolveTakeoverProviders({ version: '0.2.0-rc.2', runtimeProfile: 'modern', descriptorSchema: fullSchema, piAi })).toEqual(['local'])
    // An unmapped newer version falls back to what the host actually reports.
    expect(resolveTakeoverProviders({ version: '0.3.0', runtimeProfile: 'modern', descriptorSchema: fullSchema, piAi })).toEqual(['local'])
    // The fallback still fails closed without a capable profile or schema.
    expect(resolveTakeoverProviders({ version: '0.3.0', runtimeProfile: 'unknown', descriptorSchema: fullSchema, piAi })).toEqual([])
    expect(resolveTakeoverProviders({ version: '0.3.0', runtimeProfile: 'modern', descriptorSchema: { properties: { providers: { additionalProperties: { properties: { compat: { properties: {} } } } } } }, piAi })).toEqual([])
    // Invalid version metadata never falls back.
    expect(resolveTakeoverProviders({ version: 42, runtimeProfile: 'modern', descriptorSchema: fullSchema, piAi })).toEqual([])
  })

  it('exports the scoped identity and exact hard injection list', () => {
    expect(name).toBe('@hytime/dsh-thinking-effort')
    expect(inject).toEqual(['slots', 'connection', 'locale'])
  })

  it('reads remote.settings and registers the expected settings slot', () => {
    const harness = createHarness('modern')
    apply(harness.context)

    expect(harness.context.get).toHaveBeenCalledWith('remote.settings')
    expect(harness.context.on).toHaveBeenCalledWith('internal/service', expect.any(Function))
    expect(harness.slots.inject).toHaveBeenCalledWith('settings.section', expect.any(Function))
    expect(harness.slots.inject).toHaveBeenCalledWith('shell.overlay', expect.any(Function))
    expect(harness.slots.inject).toHaveBeenCalledWith('conversation.input.model', expect.any(Function))
    expect(harness.registrations).toHaveLength(3)
    expect(harness.registrations[0]?.descriptor).toMatchObject({
      name: 'settings.section',
      id: 'thinking-effort',
      order: 12,
      locale: LOCALE_NS,
    })
    expect(harness.registrations[1]?.descriptor).toMatchObject({
      name: 'shell.overlay',
      id: 'thinking-effort-legacy-migration',
      order: 40,
    })
    expect(harness.registrations[2]?.descriptor).toMatchObject({
      name: 'conversation.input.model',
      priority: -10,
      locale: LOCALE_NS,
    })
  })

  it('registers the composer seat with an injected directory face', () => {
    const harness = createHarness('modern')
    apply(harness.context)

    const descriptor = harness.registrations[2]?.descriptor
    expect(descriptor).toMatchObject({
      name: 'conversation.input.model',
      priority: -10,
      locale: LOCALE_NS,
    })
    expect(harness.slots.inject).toHaveBeenCalledWith('conversation.input.model', expect.any(Function))
  })

  it('shadows the shipped model seat on purpose, so the priority must stay below 0', () => {
    const harness = createHarness('modern')
    apply(harness.context)

    // `conversation.input.model` is a SINGLE slot, and its winner is the FIRST
    // entry in ASCENDING priority order, so a negative priority SHADOWS the
    // shipped ModelSelect (priority 0). Renaming this to a positive value would
    // silently hand the seat back to the official component and hide the slider.
    const descriptor = harness.registrations[2]?.descriptor
    expect(descriptor?.priority).toBeLessThan(0)
  })

  it('registers a render factory for the provider compatibility settings surface', () => {
    const harness = createHarness('modern')
    apply(harness.context)

    const render = harness.registrations[0]?.render
    expect(render).toEqual(expect.any(Function))
    const element = (render as () => { props?: Record<string, unknown> })()
    expect(element.props).toEqual(expect.objectContaining({ settings: expect.any(Object), locale: expect.any(Object), t: expect.any(Function) }))
  })

  it('delivers a late configForms service to the already-mounted editor', () => {
    const harness = createHarness('modern')
    // `ctx.configForms` (DSH 0.1.7+) belongs to `@deepseek-ai/dsh-client-ui-settings`,
    // whose client entry is created CONCURRENTLY with this one, so it can activate
    // after `apply` has already registered the slot. Mount therefore sees no
    // service, and the bridge keeps a LIVE view that re-reads the context.
    apply(harness.context)

    const render = harness.registrations[0]?.render
    const element = (render as () => { props?: { settings?: { formFor?: (entryId: string) => unknown } } })()
    const settings = element.props?.settings
    expect(settings).toBeDefined()
    const registrationsBefore = harness.registrations.length
    expect(registrationsBefore).toBe(3)
    // No service yet: the live view resolves to nothing instead of `formFor`
    // being absent, which is what lets the lookup below start working.
    expect(settings?.formFor?.(PLUGIN_ENTRY_ID)).toBeUndefined()

    const form = { getSnapshot: () => ({ status: 'ready', revision: 3, writable: true }) }
    harness.provideConfigForms({ get: (entryId: string) => (entryId === PLUGIN_ENTRY_ID ? form : undefined) })
    for (const listener of harness.listeners) listener('configForms')

    // The SAME bridge object must now answer with the form: `configFormsView`
    // re-reads `context.get('configForms')` per lookup, and the `mounted` latch
    // must not have frozen the registered slot onto a pre-service bridge. Both
    // halves fail together when the 4th argument at the mount call is dropped.
    expect(settings?.formFor?.(PLUGIN_ENTRY_ID)).toBe(form)
    // The late activation re-ran `mountFromRemote`, but the latch still holds:
    // no duplicate settings.section / shell.overlay registration.
    expect(harness.registrations).toHaveLength(registrationsBefore)
  })

  it('keeps legacy fallback active and does not replace the first successful mount', async () => {
    const harness = createHarness('legacy')
    apply(harness.context)

    expect(harness.context.on).toHaveBeenCalledWith('internal/service', expect.any(Function))
    expect(harness.registrations).toHaveLength(3)
    const render = harness.registrations[0]?.render
    const element = (render as () => { props?: { settings?: { describe: () => Promise<unknown> } } })()
    await element.props?.settings?.describe()
    expect(harness.legacySettings.describe).toHaveBeenCalled()
  })

  it('disposes dictionaries and externally registered languages', () => {
    const harness = createHarness('modern')
    apply(harness.context)

    expect(harness.register).toHaveBeenCalledWith(LOCALE_NS, expect.objectContaining({ zh: expect.any(Object), en: expect.any(Object), ja: expect.any(Object), ko: expect.any(Object) }))
    expect(harness.addLanguage).toHaveBeenCalledTimes(2)
    // One direct effect (language-pack dictionaries); the three slot
    // registrations go through slots.inject, whose teardown is the returned
    // disposer (Cordis fiber effect). All are torn down via disposeAllEffects.
    expect(harness.context.effect).toHaveBeenCalledTimes(1)
    harness.disposeAllEffects()
    expect(harness.disposed).toEqual(['slot', 'slot', 'slot', 'ko', 'ja', 'dictionary'])
  })

  it('injects the per-session directory store and verbs into the composer seat', () => {
    const harness = createHarness('modern')
    apply(harness.context)

    expect(harness.context.get).toHaveBeenCalledWith('modelDirectories')
    const descriptor = harness.registrations[2]?.descriptor as { inject?: (sessionId: string) => unknown }
    expect(descriptor?.inject).toEqual(expect.any(Function))

    const face = descriptor?.inject?.('session-1') as { directory: { getSnapshot: () => { status: string } }; load: () => void; select: unknown }
    expect(face).toEqual(expect.objectContaining({ load: expect.any(Function), select: expect.any(Function) }))
    expect(face.directory.getSnapshot()).toEqual({ status: 'idle' })
    expect(harness.modelDirectories.directoryFor).toHaveBeenCalledWith('session-1')
    // The injected `directory` is the store itself — what useSyncExternalStore
    // consumes — while load/select close over the owning controller.
    expect(harness.directory.store).toBe(face.directory)
  })

  it('skips the composer seat when the modelDirectories service is absent', () => {
    const registrations: Array<{ descriptor: Record<string, unknown> }> = []
    const listeners: Array<(name: string) => void> = []
    const calls: string[] = []
    // `remoteSettings` starts unresolved so the settings mount path can be
    // announced AFTER apply. `registerComposerSeat` runs at the top of apply and
    // declares modelDirectories via inject; because that service is absent the
    // inject callback never fires, so only the settings mount's slots register.
    let remoteSettings: unknown
    const slots = {
      inject: vi.fn((_name: string, callback: () => void) => callback()),
      register: vi.fn((descriptor: Record<string, unknown>) => {
        registrations.push({ descriptor })
        return () => undefined
      }),
    }
    const locale = {
      register: vi.fn(() => () => undefined),
      bind: () => (key: string) => key,
      getSnapshot: () => ({ locales: [{ id: 'zh' }] }),
    }
    const context = {
      get: vi.fn((key: string) => {
        calls.push(key)
        return key === 'remote.settings' ? remoteSettings : key === 'modelDirectories' ? undefined : ({ slots, connection: {}, locale } as Record<string, unknown>)[key]
      }),
      plugin: vi.fn((plugin: { inject?: readonly string[]; apply: (scope: ClientContext) => void }) => {
        for (const name of plugin.inject ?? []) {
          if (context.get(name) === undefined) return () => undefined
        }
        plugin.apply(context)
        return () => undefined
      }),
      inject: vi.fn(() => () => undefined),
      on: vi.fn((event: string, callback: (name: string) => void) => {
        listeners.push(callback)
        return () => undefined
      }),
      effect: vi.fn((callback: () => void | (() => void)) => callback()),
    }

    apply(context as Parameters<typeof apply>[0])
    // The seat declares modelDirectories through inject, so it is probed at
    // apply time; because the injected service is absent, the seat is skipped.
    expect(calls).toContain('modelDirectories')
    expect(registrations).toHaveLength(0)

    // Announce a working settings service: mount now runs and the settings
    // mount's slots register; the seat stays absent (modelDirectories missing).
    remoteSettings = { describe: vi.fn(), mutate: vi.fn() }
    for (const listener of listeners) listener('remote.settings')

    expect(registrations).toHaveLength(2)
    expect(registrations[0]?.descriptor?.name).toBe('settings.section')
    expect(registrations[1]?.descriptor?.name).toBe('shell.overlay')
    expect(slots.inject).not.toHaveBeenCalledWith('conversation.input.model', expect.any(Function))
  })
})
