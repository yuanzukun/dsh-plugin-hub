// @vitest-environment jsdom
import { act, createElement } from 'react'
import { createRoot } from 'react-dom/client'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createSnapshotStore } from '@deepseek-ai/dsh-client-store'
import { Slider } from '../src/client/thinking-slider/slider.js'
import type { ModelDirectoryState, SliderProps } from '../src/client/thinking-slider/slider.js'

const dictionary: Record<string, string> = {
  seatModelLoading: '加载模型…',
  seatNoModel: '未选择模型',
  seatNoEfforts: '当前模型未提供推理档位',
  seatError: '模型目录加载失败：{message}',
  seatFollowDefault: '跟随模型默认',
  seatSliderLabel: '推理档位',
  seatReasoningLabel: '推理等级',
  seatModelLabel: '模型',
  seatErrorAction: '模型操作失败：{message}',
  providerAccount: 'DeepSeek 账号',
}

const t = (key: string, params?: Record<string, unknown>): string => {
  const value = dictionary[key] ?? `{{${key}}}`
  return value.replace(/\{(\w+)\}/g, (_match: string, name: string) => String(params?.[name] ?? `{${name}}`))
}

function setRangeValue(input: HTMLInputElement, value: string): void {
  Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set?.call(input, value)
  input.dispatchEvent(new Event('input', { bubbles: true }))
}

function setSelectValue(input: HTMLSelectElement, value: string): void {
  Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value')?.set?.call(input, value)
  input.dispatchEvent(new Event('change', { bubbles: true }))
}

;(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true

const reasoning = {
  efforts: [
    { id: 'off', name: 'Off' },
    { id: 'high', name: 'High' },
    { id: 'max', name: 'Max', description: 'Largest budget' },
  ],
  defaultEffort: 'high',
}

function state(overrides: Partial<ModelDirectoryState> = {}): ModelDirectoryState {
  return {
    current: { provider: 'deepseek-official', model: 'deepseek-v4-flash' },
    routable: true,
    groups: [{
      id: 'deepseek-official',
      name: 'DeepSeek',
      models: [{
        id: 'deepseek-v4-flash',
        name: 'DeepSeek-V4-Flash',
        description: 'Fast catalog description',
        reasoning,
      }],
    }],
    failures: [],
    status: 'ready',
    error: null,
    ...overrides,
  }
}

function renderSeat(props: SliderProps) {
  const container = document.createElement('div')
  document.body.append(container)
  const root = createRoot(container)
  act(() => {
    root.render(createElement(Slider, props))
  })
  return { container, root }
}

function openPanel(container: HTMLDivElement): void {
  const trigger = container.querySelector('[data-seat-trigger]') as HTMLButtonElement
  expect(trigger).not.toBeNull()
  act(() => { trigger.click() })
  expect(container.querySelector('[data-seat-panel]')).not.toBeNull()
}

function dispose(root: ReturnType<typeof createRoot>, container: HTMLDivElement): void {
  act(() => root.unmount())
  container.remove()
}

/** jsdom reports a zero rect and a fixed viewport, so geometry is stubbed per test. */
function setViewportWidth(width: number): void {
  Object.defineProperty(window, 'innerWidth', { configurable: true, writable: true, value: width })
}

function stubRootRect(container: HTMLDivElement, left: number, width: number): void {
  const root = container.querySelector('[data-seat-root]') as HTMLElement
  expect(root).not.toBeNull()
  root.getBoundingClientRect = () => ({
    x: left, y: 0, left, top: 0, right: left + width, bottom: 28,
    width, height: 28, toJSON: () => ({}),
  }) as DOMRect
}

function panelLeft(container: HTMLDivElement): string {
  const panel = container.querySelector('[data-seat-panel]') as HTMLDivElement
  expect(panel).not.toBeNull()
  return panel.style.left
}

afterEach(() => {
  document.body.innerHTML = ''
})

describe('thinking slider composer seat', () => {
  it('starts as a compact chip and opens reasoning controls above the model selector', () => {
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, t })

    expect(container.querySelector('[data-seat-panel]')).toBeNull()
    expect(container.querySelector('[data-seat-trigger]')?.textContent).toContain('DeepSeek-V4-Flash')
    expect(container.querySelector('[data-seat-trigger]')?.textContent).toContain('High')

    openPanel(container)
    const reasoningHeader = container.querySelector('[data-seat-reasoning]')
    const range = container.querySelector('[data-seat-input]')
    const modelSelect = container.querySelector('[data-seat-model-select]')
    expect(reasoningHeader).not.toBeNull()
    expect(range).not.toBeNull()
    expect(modelSelect).not.toBeNull()
    const reasoningEl = reasoningHeader as Node
    const rangeEl = range as Node
    const modelSelectEl = modelSelect as Node
    expect(reasoningEl.compareDocumentPosition(rangeEl) & Node.DOCUMENT_POSITION_FOLLOWING).not.toBe(0)
    expect(rangeEl.compareDocumentPosition(modelSelectEl) & Node.DOCUMENT_POSITION_FOLLOWING).not.toBe(0)

    dispose(root, container)
  })

  it('renders only the efforts the current model is configured with after opening', () => {
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, t })

    openPanel(container)
    expect(container.textContent).toContain('DeepSeek-V4-Flash')
    expect(container.textContent).toContain('Off')
    expect(container.textContent).toContain('High')
    expect(container.textContent).toContain('Max')
    expect(container.textContent).not.toContain('minimal')
    expect(container.textContent).not.toContain('low')

    dispose(root, container)
  })

  it('shows the empty efforts state when the current model provides none', () => {
    const directory = createSnapshotStore(state({
      groups: [{
        id: 'deepseek-official',
        name: 'DeepSeek',
        models: [{ id: 'deepseek-v4-flash', name: 'DeepSeek-V4-Flash' }],
      }],
    }))
    const { container, root } = renderSeat({ directory, t })

    openPanel(container)
    expect(container.textContent).toContain('当前模型未提供推理档位')
    expect(container.textContent).not.toContain('Off')

    dispose(root, container)
  })

  it('handles a null current selection and the loading status', () => {
    const directory = createSnapshotStore(state({ current: null, status: 'loading' }))
    const { container, root } = renderSeat({ directory, t })

    expect(container.textContent).toContain('加载模型…')
    openPanel(container)
    expect(container.textContent).toContain('当前模型未提供推理档位')

    dispose(root, container)
  })

  it('surfaces the directory error under the error status', () => {
    const directory = createSnapshotStore(state({
      current: null,
      groups: [],
      status: 'error',
      error: 'catalog unreachable',
    }))
    const { container, root } = renderSeat({ directory, t })

    openPanel(container)
    expect(container.textContent).toContain('模型目录加载失败：catalog unreachable')

    dispose(root, container)
  })

  it('submits a range change as a session selection with the matching reasoning effort', () => {
    const select = vi.fn().mockResolvedValue(true)
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, select, t })

    openPanel(container)
    const input = container.querySelector('[data-seat-input]') as HTMLInputElement
    act(() => { setRangeValue(input, '2') })

    expect(select).toHaveBeenCalledWith({ provider: 'deepseek-official', model: 'deepseek-v4-flash', reasoningEffort: 'max' })
    dispose(root, container)
  })

  it('announces the current effective effort level through aria-valuetext', () => {
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, t })

    openPanel(container)
    expect((container.querySelector('[data-seat-input]') as HTMLInputElement).getAttribute('aria-valuetext')).toBe('High')

    dispose(root, container)
  })

  it('submits a selected model with that model default effort', () => {
    const select = vi.fn().mockResolvedValue(true)
    const directory = createSnapshotStore(state({
      groups: [{
        id: 'deepseek-official',
        name: 'DeepSeek',
        models: [
          { id: 'deepseek-v4-flash', name: 'DeepSeek-V4-Flash', reasoning },
          {
            id: 'deepseek-v4-reasoner',
            name: 'DeepSeek-V4-Reasoner',
            reasoning: { efforts: reasoning.efforts, defaultEffort: 'max' },
          },
        ],
      }],
    }))
    const { container, root } = renderSeat({ directory, select, t })

    openPanel(container)
    const input = container.querySelector('[data-seat-model-select]') as HTMLSelectElement
    const target = [...input.options].find(option => option.textContent === 'DeepSeek-V4-Reasoner')
    expect(target).toBeDefined()
    act(() => { setSelectValue(input, target?.value ?? '') })

    expect(select).toHaveBeenCalledWith({
      provider: 'deepseek-official',
      model: 'deepseek-v4-reasoner',
      reasoningEffort: 'max',
    })
    dispose(root, container)
  })

  it('retains an explicit current effort when selecting the same model', () => {
    const select = vi.fn().mockResolvedValue(true)
    const directory = createSnapshotStore(state({
      current: { provider: 'deepseek-official', model: 'deepseek-v4-flash', reasoningEffort: 'off' },
    }))
    const { container, root } = renderSeat({ directory, select, t })

    openPanel(container)
    const input = container.querySelector('[data-seat-model-select]') as HTMLSelectElement
    act(() => { setSelectValue(input, input.value) })

    expect(select).toHaveBeenCalledWith({
      provider: 'deepseek-official',
      model: 'deepseek-v4-flash',
      reasoningEffort: 'off',
    })
    dispose(root, container)
  })

  it('represents a model-default selection without marking the first effort active', () => {
    const select = vi.fn().mockResolvedValue(true)
    const directory = createSnapshotStore(state({
      groups: [{
        id: 'deepseek-official',
        name: 'DeepSeek',
        models: [{
          id: 'deepseek-v4-flash',
          name: 'DeepSeek-V4-Flash',
          reasoning: { efforts: reasoning.efforts },
        }],
      }],
    }))
    const { container, root } = renderSeat({ directory, select, t })

    expect(container.querySelector('[data-seat-trigger]')?.textContent).toContain('跟随模型默认')
    openPanel(container)
    const range = container.querySelector('[data-seat-input]') as HTMLInputElement
    expect(container.querySelector('[data-seat-reasoning]')?.textContent).toContain('跟随模型默认')
    expect(range.getAttribute('aria-valuetext')).toBe('跟随模型默认')
    expect(range.getAttribute('data-seat-unset')).toBe('true')
    expect(container.querySelector('[data-seat-active]')).toBeNull()
    const followDefault = container.querySelector('[data-seat-default]') as HTMLButtonElement
    expect(followDefault.getAttribute('aria-pressed')).toBe('true')

    act(() => { followDefault.click() })
    expect(select).toHaveBeenCalledWith({ provider: 'deepseek-official', model: 'deepseek-v4-flash' })
    expect(select.mock.calls[0]?.[0]).not.toHaveProperty('reasoningEffort')
    dispose(root, container)
  })

  it('hides follow-model-default when the model declares a default effort', () => {
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, t })

    openPanel(container)
    expect(container.querySelector('[data-seat-default]')).toBeNull()
    dispose(root, container)
  })

  it('closes the panel on outside mousedown and returns focus to the compact chip on Escape', async () => {
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, t })

    openPanel(container)
    const outside = document.createElement('button')
    document.body.append(outside)
    act(() => { outside.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })) })
    expect(container.querySelector('[data-seat-panel]')).toBeNull()
    outside.remove()

    openPanel(container)
    const panel = container.querySelector('[data-seat-panel]') as HTMLDivElement
    act(() => { panel.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })) })
    expect(container.querySelector('[data-seat-panel]')).toBeNull()
    await Promise.resolve()
    expect(document.activeElement).toBe(container.querySelector('[data-seat-trigger]'))

    dispose(root, container)
  })

  it('swallows a rejected selection promise after a range change', async () => {
    const select = vi.fn().mockRejectedValue(new Error('selection rejected'))
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, select, t })

    openPanel(container)
    act(() => { setRangeValue(container.querySelector('[data-seat-input]') as HTMLInputElement, '2') })
    await Promise.resolve()
    expect(select).toHaveBeenCalledTimes(1)
    dispose(root, container)
  })

  it('surfaces a failed selection through the directory error action copy', () => {
    const select = vi.fn().mockResolvedValue(false)
    const directory = createSnapshotStore(state({ status: 'selecting' }))
    const { container, root } = renderSeat({ directory, select, t })

    openPanel(container)
    act(() => { setRangeValue(container.querySelector('[data-seat-input]') as HTMLInputElement, '2') })
    act(() => { directory.set(state({ status: 'error', error: 'selection rejected' })) })
    expect(container.textContent).toContain('模型操作失败：selection rejected')

    dispose(root, container)
  })
})

describe('provider group labels', () => {
  /** Open the reasoning panel and expand the model menu. */
  function openModelMenu(container: HTMLDivElement): void {
    openPanel(container)
    const row = container.querySelector('[data-seat-model-row] button') as HTMLButtonElement
    expect(row).not.toBeNull()
    act(() => { row.click() })
    expect(container.querySelector('[data-seat-model-menu]')).not.toBeNull()
  }

  const accountState = () => state({
    current: { provider: 'deepseek-account', model: 'deepseek-v4-flash' },
    groups: [{
      id: 'deepseek-account',
      name: 'DeepSeek Account',
      models: [{ id: 'deepseek-v4-flash', name: 'DeepSeek-V4-Flash', reasoning }],
    }],
  })

  it('localizes the signed-in account route in the menu and the native select', () => {
    const { container, root } = renderSeat({ directory: createSnapshotStore(accountState()), select: vi.fn().mockResolvedValue(true), t })

    openModelMenu(container)
    // The registered displayName is English; the heading must not be.
    const toggle = container.querySelector('[data-seat-model-menu] button') as HTMLButtonElement
    expect(toggle.textContent).toContain('DeepSeek 账号')
    expect(toggle.textContent).not.toContain('DeepSeek Account')

    const optgroup = container.querySelector('[data-seat-model-select] optgroup') as HTMLOptGroupElement
    expect(optgroup.label).toBe('DeepSeek 账号')

    dispose(root, container)
  })

  it('keeps every other provider group at its registered name', () => {
    const { container, root } = renderSeat({
      directory: createSnapshotStore(state({
        groups: [{ id: 'my-gateway', name: 'My Gateway', models: [{ id: 'm', name: 'M', reasoning }] }],
      })),
      select: vi.fn().mockResolvedValue(true),
      t,
    })

    openModelMenu(container)
    const toggle = container.querySelector('[data-seat-model-menu] button') as HTMLButtonElement
    expect(toggle.textContent).toContain('My Gateway')
    expect((container.querySelector('[data-seat-model-select] optgroup') as HTMLOptGroupElement).label).toBe('My Gateway')

    dispose(root, container)
  })
})

describe('scale and model row affordances', () => {
  it('places every tick label on the same fraction as its pip', () => {
    const { container, root } = renderSeat({ directory: createSnapshotStore(state()), t })

    openPanel(container)
    const ticks = [...container.querySelectorAll('[data-seat-scale] > span')]
    const pips = [...container.querySelectorAll('[data-seat-range] span span')]
    expect(ticks).toHaveLength(reasoning.efforts.length)
    expect(pips).toHaveLength(reasoning.efforts.length)
    // The labels used to be divided evenly, which put the first and last half
    // a step inside the end pips. Both rows now read the same fractions.
    expect(ticks.map(tick => (tick as HTMLElement).style.left))
      .toEqual(pips.map(pip => (pip as HTMLElement).style.left))
    expect((ticks[0] as HTMLElement).style.left).toBe('0%')
    expect((ticks[ticks.length - 1] as HTMLElement).style.left).toBe('100%')

    dispose(root, container)
  })

  it('turns the model row chevron over while the model menu is open', () => {
    const { container, root } = renderSeat({
      directory: createSnapshotStore(state()),
      select: vi.fn().mockResolvedValue(true),
      t,
    })

    openPanel(container)
    const chevron = container.querySelector('[data-seat-model-chevron]') as HTMLElement
    const collapsed = chevron.className
    const row = container.querySelector('[data-seat-model-row] button') as HTMLButtonElement

    act(() => { row.click() })
    expect(container.querySelector('[data-seat-model-menu]')).not.toBeNull()
    expect(chevron.className).not.toBe(collapsed)
    // The open state is an extra class on top of the collapsed one, not a swap.
    expect(collapsed.split(' ').filter(name => chevron.className.split(' ').includes(name))).toEqual(collapsed.split(' '))

    act(() => { row.click() })
    expect(container.querySelector('[data-seat-model-menu]')).toBeNull()
    expect(chevron.className).toBe(collapsed)

    dispose(root, container)
  })
})

describe('continuous range dragging', () => {
  /**
   * The official ModelDirectory sets `status = 'selecting'` synchronously at
   * the top of its async `select()`, before the first await. A seat that reads
   * that status as "busy" therefore disables the native range on the very first
   * input event, and the browser stops reporting the rest of the drag — one
   * step per press. The service itself is built for this: every `select()`
   * takes a generation and only the newest response is applied.
   */
  it('stays draggable while a selection is still in flight', () => {
    const select = vi.fn(() => new Promise<boolean>(() => {}))
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, select, t })

    openPanel(container)
    const range = container.querySelector('[data-seat-input]') as HTMLInputElement
    act(() => { setRangeValue(range, '2') })

    // What the host-side store does the instant select() is entered.
    act(() => { directory.set(state({ status: 'selecting', pending: { provider: 'deepseek-official', model: 'deepseek-v4-flash', reasoningEffort: 'max' } })) })

    expect(range.disabled).toBe(false)
    // The second step of the same drag has to reach the host as well.
    act(() => { setRangeValue(range, '0') })
    expect(select).toHaveBeenCalledTimes(2)
    expect(select).toHaveBeenLastCalledWith({ provider: 'deepseek-official', model: 'deepseek-v4-flash', reasoningEffort: 'off' })

    dispose(root, container)
  })

  it('reads the position from the pending selection until the host confirms it', () => {
    const select = vi.fn(() => new Promise<boolean>(() => {}))
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, select, t })

    openPanel(container)
    const range = container.querySelector('[data-seat-input]') as HTMLInputElement
    act(() => { setRangeValue(range, '2') })
    act(() => { directory.set(state({ status: 'selecting', pending: { provider: 'deepseek-official', model: 'deepseek-v4-flash', reasoningEffort: 'max' } })) })

    // `current` has not moved yet; without the pending value the controlled
    // range would snap back to the host's old answer mid-drag.
    expect((directory.getSnapshot().current as { reasoningEffort?: string }).reasoningEffort).toBeUndefined()
    expect(range.value).toBe('2')
    expect(container.querySelector('[data-seat-active]')?.textContent).toBe('Max')
    expect(range.getAttribute('aria-valuetext')).toBe('Max')

    // Once the host confirms, the confirmed value stands on its own.
    act(() => { directory.set(state({ current: { provider: 'deepseek-official', model: 'deepseek-v4-flash', reasoningEffort: 'max' } })) })
    expect(range.value).toBe('2')

    dispose(root, container)
  })

  it('falls back to the host value when a directory exposes no pending selection', () => {
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, select: vi.fn().mockResolvedValue(true), t })

    openPanel(container)
    const range = container.querySelector('[data-seat-input]') as HTMLInputElement
    expect(range.value).toBe('1')
    act(() => { setRangeValue(range, '2') })

    // Older directory builds carry no `pending`; the seat must still read the
    // confirmed value rather than a local guess.
    expect(directory.getSnapshot().pending).toBeUndefined()

    dispose(root, container)
  })

  it('clamps the panel into a narrow viewport instead of following the off-screen anchor', () => {
    setViewportWidth(390)
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, t })
    // The chip sits flush against the left edge, so the 336px right-anchored
    // panel would start at -38px and most of it would be unreachable.
    stubRootRect(container, 16, 282)

    openPanel(container)
    expect(panelLeft(container)).toBe('0px')

    dispose(root, container)
  })

  it('keeps the original right-aligned anchor whenever the panel fits', () => {
    setViewportWidth(1440)
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, t })
    stubRootRect(container, 600, 150)

    openPanel(container)
    // Anchored to the trigger's right edge: 414px viewport-left, 186px back
    // from a trigger whose left edge is at 600px.
    expect(panelLeft(container)).toBe('-186px')

    dispose(root, container)
  })

  it('recomputes the clamp when the window is resized while the panel is open', () => {
    setViewportWidth(1440)
    const directory = createSnapshotStore(state())
    const { container, root } = renderSeat({ directory, t })
    stubRootRect(container, 600, 150)

    openPanel(container)
    expect(panelLeft(container)).toBe('-186px')

    // A real resize shrinks the viewport AND reflows the chip with it, so the
    // stub moves too; the panel must re-clamp against the new geometry.
    setViewportWidth(390)
    stubRootRect(container, 16, 282)
    act(() => { window.dispatchEvent(new Event('resize')) })
    expect(panelLeft(container)).toBe('0px')

    dispose(root, container)
  })
})
