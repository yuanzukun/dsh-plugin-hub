/**
 * test/private-voice.test.js — 私聊语音转文字（协议端 `get_ptt_text` = QQ 自带识别）。
 *
 * 覆盖：
 *  - 纯函数：record 段收进 records、正文保留 `[语音]` 占位（对外契约不变）；
 *  - 私聊：转成功 → 正文里的 `[语音]` 换成 `[语音·文字]…`；
 *  - 私聊：转不出来 → 保持 `[语音]` 自然降级（不替模型编话术）；
 *  - 群聊不转（哪怕被 @ 唤醒）：只做私聊；
 *  - 控制台「私聊语音转文字」关掉 → 一个接口都不打；
 *  - 适配器：`get_ptt_text` 成功/失败两种返回。
 */
import test from 'node:test'
import assert from 'node:assert/strict'

import { extractText, normalizeEvent } from '../kernel/format.js'
import { OneBotAdapter } from '../kernel/onebot-adapter.js'
import { bootKernel, emitRaw, waitFor, ADMIN_QQ, GROUP_ID } from './helpers.mjs'
import { createFakeOneBot } from './fake-onebot.mjs'

const recordSeg = (file = 'abc.amr', duration = 3) => ({
  type: 'record',
  data: { file, url: `https://multimedia.example.invalid/${file}`, duration },
})

function privateVoiceEvent({ messageId = 7001, userId = ADMIN_QQ, file = 'abc.amr' } = {}) {
  return {
    post_type: 'message',
    message_type: 'private',
    user_id: userId,
    message_id: messageId,
    sender: { user_id: userId, nickname: '主人' },
    message: [recordSeg(file)],
  }
}

/** 群聊里 @ 本机 + 语音（应该被唤醒，但不该转文字）。 */
function groupVoiceAtEvent({ messageId = 5001 } = {}) {
  return {
    post_type: 'message',
    message_type: 'group',
    group_id: GROUP_ID,
    user_id: ADMIN_QQ,
    message_id: messageId,
    sender: { user_id: ADMIN_QQ, nickname: '主人', card: '群主' },
    message: [
      { type: 'at', data: { qq: '999999' } },
      recordSeg('group.amr', 2),
    ],
  }
}

async function fixture(t, config = {}) {
  const h = await bootKernel({
    config: {
      pacing: { merge: { enabled: false }, reply: { enabled: false } },
      pluginConfig: { 'gate-wake': { callAck: false }, stickers: { enabled: false }, 'group-memory': { accumulateEnabled: false } },
      ...config,
    },
  })
  t.after(() => h.dispose())
  return h
}

// ── 纯函数 ────────────────────────────────────────────────
test('extractText：语音段收进 records，正文仍是 [语音]（对外契约不变）', () => {
  const r = extractText([{ type: 'text', data: { text: '你听' } }, recordSeg('v.amr', 5)], 999999)
  assert.equal(r.text, '你听[语音]')
  assert.deepEqual(r.records, [{ url: 'https://multimedia.example.invalid/v.amr', file: 'v.amr', duration: 5 }])
})

test('extractText：没有语音时 records 是空数组（别让下游判 undefined）', () => {
  assert.deepEqual(extractText([{ type: 'text', data: { text: '你好' } }], 1).records, [])
})

test('normalizeEvent：私聊语音事件带 records 与消息 ID', () => {
  const ev = normalizeEvent(privateVoiceEvent(), 999999, ADMIN_QQ)
  assert.equal(ev.chatKey, 'private:' + ADMIN_QQ)
  assert.equal(ev.messageId, 7001)
  assert.equal(ev.records.length, 1)
  assert.equal(ev.records[0].file, 'abc.amr')
  assert.equal(ev.text, '[语音]')
})

// ── 私聊：转成功 ──────────────────────────────────────────
test('私聊语音：转成了就把 [语音] 换成 [语音·文字]…（消息 ID 带上）', async (t) => {
  const h = await fixture(t)
  const calls = []
  h.kernel.onebot.pttText = async (messageId, timeoutMs) => {
    calls.push({ messageId, timeoutMs })
    return '今天有点累，不想吃饭'
  }
  await emitRaw(h.kernel, privateVoiceEvent({ messageId: 7001 }))
  await waitFor(() => h.ctx._prompts[0], { label: '私聊语音进模型' })
  const prompt = h.ctx._prompts[0].content.map((c) => c.text || '').join('\n')
  assert.match(prompt, /\[语音·文字\]今天有点累，不想吃饭/)
  assert.deepEqual(calls.map((c) => c.messageId), [7001], '只转本条语音')
})

test('私聊语音：转不出来 → 保持 [语音] 自然降级，不补话术', async (t) => {
  const h = await fixture(t)
  h.kernel.onebot.pttText = async () => null
  await emitRaw(h.kernel, privateVoiceEvent({ messageId: 7002 }))
  await waitFor(() => h.ctx._prompts[0], { label: '进模型' })
  const prompt = h.ctx._prompts[0].content.map((c) => c.text || '').join('\n')
  assert.match(prompt, /\[语音\]/)
  assert.doesNotMatch(prompt, /\[语音·文字\]/)
})

// ── 范围：只做私聊 ────────────────────────────────────────
test('群聊语音（哪怕 @ 唤醒了）不转文字', async (t) => {
  const h = await fixture(t)
  let called = 0
  h.kernel.onebot.pttText = async () => { called += 1; return '不该出现' }
  await emitRaw(h.kernel, groupVoiceAtEvent())
  await waitFor(() => h.ctx._prompts[0], { label: '群语音唤醒进模型' })
  const prompt = h.ctx._prompts[0].content.map((c) => c.text || '').join('\n')
  assert.match(prompt, /\[语音\]/)
  assert.doesNotMatch(prompt, /\[语音·文字\]/)
  assert.equal(called, 0, '群聊不该打转写接口')
})

test('控制台关掉「私聊语音转文字」→ 一个接口都不打', async (t) => {
  const h = await fixture(t, { outbound: { voiceToText: false } })
  let called = 0
  h.kernel.onebot.pttText = async () => { called += 1; return '不该出现' }
  await emitRaw(h.kernel, privateVoiceEvent({ messageId: 7003 }))
  await waitFor(() => h.ctx._prompts[0], { label: '进模型' })
  const prompt = h.ctx._prompts[0].content.map((c) => c.text || '').join('\n')
  assert.match(prompt, /\[语音\]/)
  assert.equal(called, 0)
})

// ── 适配器 ────────────────────────────────────────────────
test('pttText：get_ptt_text 成功返回文字；失败返回 null', async (t) => {
  const fake = createFakeOneBot()
  await fake.start()
  t.after(() => fake.close())
  const adapter = new OneBotAdapter({
    httpUrl: fake.url.httpUrl,
    selfId: fake.selfId,
    log: { debug() {}, info() {}, warn() {}, error() {} },
  })
  fake.setPttReply({ text: '你好呀' })
  assert.equal(await adapter.pttText(7001), '你好呀')
  fake.setPttReply({ ok: false })
  assert.equal(await adapter.pttText(7001), null)
  assert.deepEqual(
    fake.calls.filter((c) => c.action === 'get_ptt_text').map((c) => c.params.message_id),
    [7001, 7001],
  )
})
