/**
 * admin/schema.js — 控制面的**描述表**（核心开关 + 各子插件 configSchema 汇总）。
 *
 * 设计（沿用现网 admin-api 最值钱的那部分：描述表驱动）：
 *   · 加一个核心开关 = 下面 CORE_CONTROLS 加一行；
 *   · 加一个子插件开关 = 只改插件自己的 configSchema —— 这里、控制台 UI 都不用动；
 *   · 控制台只能改**白名单里的键**：`readValue/writeValue` 按 key 找到注册项，找不到就抛错。
 *
 * 控制台页面归属规则（2026-10-20 起）：
 *   · 目标：**一个子插件 = 一个页面**（生图凭据也归 imagegen，虽然仍存 `credentials.gptImage.*`）；
 *   · `OTHER_GROUPS`：权限/门禁/文件/发图/头像 五组统一并到「其他」页（低频配置集中放）；
 *   · `PERSONA_GROUPS`：跟随「人设」显示在「总览」页的分组（当前为空：句池/唤醒 已各自成页）。
 *
 * 键与配置路径的映射（v2 配置结构见 kernel/config-store.js）：
 *   · 核心项：`key` 就是 raw 配置里的点路径（`pacing.reply.hourlyMax`、`onebot.wsUrl`…）；
 *   · 子插件项：`key = <pluginId>.<field>`，落到 `raw.pluginConfig[<pluginId>][<field>]`。
 *
 * 单位口径（**两套，别混**）：
 *   · 核心项：raw 存“底层单位”（毫秒 / 0~1 分数），面板显示“人话单位”（分钟 / 秒 / %）；
 *     `scale` = 面板值 × scale = 存储值，换算只在 readValue/writeValue 的边界做一次。
 *   · 子插件项：raw 里**本来就存面板单位**（秒 / % —— 各插件 configSchema 的 default 就是面板值），
 *     所以这里**不做 scale 换算**；`scale` 只是“× scale = 插件内部基准单位”的说明字段，前端不读。
 *
 * 秘密字段（onebot token）读出来给占位符，写回占位符 = 不改。
 */

/** 秘密值的占位符：读 schema 时回显它而不是真值；把它原样写回来 = 不修改。 */
export const SECRET_MASK = '••••••••'

import { validateReplyInterval } from '../kernel/config-store.js'

const isPlainObject = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v)

/** 点路径读取（`a.b.c` 或数组）。 */
export function getPath(obj, dotted) {
  const parts = Array.isArray(dotted) ? dotted : String(dotted).split('.')
  return parts.reduce((o, k) => (o == null ? undefined : o[k]), obj)
}

/** 点路径写入（中间层不存在就建对象）。 */
export function setPath(obj, dotted, value) {
  const parts = Array.isArray(dotted) ? dotted.slice() : String(dotted).split('.')
  const last = parts.pop()
  const target = parts.reduce((o, k) => (o[k] == null ? (o[k] = {}) : o[k]), obj)
  target[last] = value
  return obj
}

/** 数字保留 3 位小数（面板值显示用；避免 0.1*3 这类浮点尾巴）。 */
const round3 = (n) => Math.round(n * 1000) / 1000
const round6 = (n) => Math.round(n * 1e6) / 1e6

/**
 * 子插件里**不在控制台聚合里渲染**的字段（插件配置保留，由专属页面/编辑页管理）。
 * 拆条 / 表情概率现在归各自插件所有（`pluginConfig['persona-voice']` / `.stickers`），
 * 显示在插件自己的页面里，不再隐藏。
 */
const HIDDEN_PLUGIN_FIELDS = {
  'message-monitor': new Set(['rules']), // 规则由专属编辑页管理，不渲染通用输入框
}

// ============================================================
// 注册表 ①：核心开关（映射 raw 配置顶层键）
// ============================================================

/**
 * @typedef {object} ControlDef
 * @property {string} key       面板/白名单键 = raw 配置点路径
 * @property {string} group     控制台页签（首次出现顺序 = 标签页顺序）
 * @property {'bool'|'int'|'float'|'str'|'text'|'enum'|'group'|'qq-list'|'info'} type
 * @property {string} label
 * @property {string} [unit]    面板单位（分钟/秒/%/字/毫秒/次）
 * @property {number} [scale]   面板值 × scale = 存储值（只在读写边界换算）
 * @property {number} [min]     面板值下限
 * @property {number} [max]     面板值上限
 * @property {number} [step]
 * @property {Array|object[]} [options]
 * @property {string} [hint]
 * @property {unknown} [default] 配置缺键时的默认值（存储单位）
 * @property {boolean} [secret] 秘密字段：面板只回显占位符
 * @property {string} [text]  `type:'info'` 的说明正文（原样给前端，不参与读写）
 * @property {string[]} [suggestions] str 控件的输入建议（前端渲染成 datalist）
 */
export const CORE_CONTROLS = [
  // ── 群聊页顶部：主人 QQ（全局唯一身份）──────────────────────
  {
    key: 'adminQq', group: '群聊', type: 'int', label: '主人 QQ',
    min: 1, max: 99999999999, step: 1, default: 0,
    hint: '必填：只有这个 QQ 的私聊豁免出口脱敏，群里的“主人指令”也按它判。改完热生效（下一条消息起）。',
  },

  // ── OneBot 连接（对接任意 OneBot v11 协议端）──────
  {
    key: 'info.onebot', group: 'OneBot 连接', type: 'info',
    text: '分三步接上 OneBot 协议端（任意 OneBot v11 实现；配置键是 onebot.*，与具体实现无关）：\n'
      + '① 先在本机装好并启动协议端并登录 QQ（各实现方式不同：有的自己拉起 QQ，有的注入已在运行的 QQ 进程，详见 docs/安装与卸载.md §二）；\n'
      + '② 在协议端配置里打开「WebSocket 服务端」（常见默认 ws://127.0.0.1:3001）和「HTTP 服务端」（常见默认 http://127.0.0.1:3000）；有 token 就一并填到下面（部分实现强制要 token，两个都要填）；\n'
      + '③ 填好地址/token 后先让输入框失焦（离开输入框就会保存），再点「运维」页的「🔌 测试 OneBot 连接」：出现 ✅ 就说明通了（测的是已保存的配置）。\n'
      + '⚠️ 两个地址都在同一台机器时用 127.0.0.1 即可；跨机器要把 127.0.0.1 换成协议端那台机器的 IP，并确认防火墙放行端口。',
  },
  {
    key: 'onebot.wsUrl', group: 'OneBot 连接', type: 'str', label: 'OneBot v11 正向 WS 地址',
    default: 'ws://127.0.0.1:3001',
    hint: '协议端的 WebSocket 服务地址（入站消息从这里来）。改了会重新连接。',
  },
  {
    key: 'onebot.wsToken', group: 'OneBot 连接', type: 'str', label: 'WS Token', secret: true, default: '',
    hint: '可留空。填了就是 OneBot 的 access_token（走 Authorization: Bearer）。',
  },
  {
    key: 'onebot.httpUrl', group: 'OneBot 连接', type: 'str', label: 'OneBot HTTP API 地址',
    default: 'http://127.0.0.1:3000',
    hint: '发消息 / 查群列表 / 取头像走这个 HTTP API。',
  },
  {
    key: 'onebot.httpToken', group: 'OneBot 连接', type: 'str', label: 'HTTP Token', secret: true, default: '',
    hint: '多数实现可留空；强制鉴权的实现（如 SnowLuma）必填，与协议端的 HTTP token 一致。',
  },

  // ── 出站（回复长度 / 长文卡片 / 引用）───────────────────────
  {
    key: 'outbound.replyMaxLength', group: '消息设置', type: 'int', label: '单条字数上限',
    min: 100, max: 100000, step: 100, default: 3000,
    hint: '网关硬上限：超过直接报错，让模型精简重发；兜底路径会在换行处切段逐条发。',
  },
  {
    key: 'outbound.longForwardThreshold', group: '消息设置', type: 'int', label: '长文卡片阈值', unit: '字',
    min: 0, max: 100000, step: 100, default: 400,
    hint: '正文超过这个字数就打成一张合并转发卡片（不刷屏）；0 = 用单条字数上限（等于关掉卡片）。',
  },
  {
    key: 'outbound.longForwardChunkSize', group: '消息设置', type: 'int', label: '长文卡片分片大小', unit: '字',
    min: 100, max: 5000, step: 100, default: 800,
    hint: '合并转发卡片里每个节点最多这么多字。',
  },
  {
    key: 'outbound.quoteAfterMsgs', group: '消息设置', type: 'int', label: '引用门槛（唤醒后插了几条才挂引用）',
    min: 0, max: 50, step: 1, default: 3,
    hint: '本群在“唤醒那条”之后又插了 N 条才允许挂引用；0 = 一律不自动挂。',
  },
  {
    key: 'outbound.groupContextCount', group: '群聊', type: 'int', label: '入站条数上限',
    min: 0, max: 50, step: 1, default: 10,
    hint: '**每轮最多带几条“还没给它看过的”群消息**（不是固定带这么多）。\n'
      + '怎么算：只取上一次回复之后群里新来的消息，最多 N 条（按时间旧→新，只取 30 分钟内的，本条消息本身不算）；'
      + '新消息超过 N 条时**只给最后 N 条，更早的直接丢弃、之后也不会补** —— 所以这是个封顶值。\n'
      + '调大 = 它更能接上前文（尤其是它沉默一阵、群里刷了几十条之后），代价是每轮多几十个 token（每条约 20 token，走的是未缓存输入）。\n'
      + '0 = 完全不带上文；一般 10~20 够用；要一次性看很多条用 `/history N`，别靠这里顶。',
  },

  {
    key: 'outbound.groupContextImages', group: '群聊', type: 'bool', label: '上文图片入站',
    default: false,
    hint: '开：群聊「入站条数」窗口里的**真实图片**会随上文一起送进模型（表情包不算），'
      + '数量与「入站条数上限」同步封顶（最多 N 张），长边缩到 768px 再送（实测约 180~380 token/张，均值约 270）。\n'
      + '典型场景：群友先发图、再叫它，它不会再答"图没送到"。\n'
      + '只在上下文窗口里出现过图时才产生费用；窗口里没图 = 零开销。默认关。',
  },

  {
    key: 'outbound.voiceToText', group: '消息设置', type: 'bool', label: '私聊语音转文字',
    default: true,
    hint: '开：私聊收到语音条时，用协议端（SnowLuma `get_ptt_text`，就是 QQ 客户端自带的那套识别）转成文字再送模型 —— 零成本、不落盘、不用本地模型。\n'
      + '最多等 8 秒；转不出来（超时/失败）就保持 `[语音]` 占位，由模型自己问一句，不硬编话术。\n'
      + '只对私聊生效：群聊语音不转（多数跟它无关，每条都转会把协议端打慢）。关 = 私聊语音也只听得到 `[语音]`。',
  },

  // ── 合批等待（私聊合批 / 群聊唤醒各自成轮）──────────────────
  {
    key: 'pacing.merge.enabled', group: '消息设置', type: 'bool', label: '合批等待（等对方说完再答）', default: true,
    hint: '开：被叫后先等下面这个时间再入站。私聊连发的几条并成一轮（每来一条重新计时）；'
      + '群聊里唤醒消息各自成轮，等待期内别人的聊天/补发的正文并进当前这轮。关：被叫立即入站。',
  },
  {
    key: 'pacing.merge.waitMs', group: '消息设置', type: 'int', label: '合并等待时间', unit: '秒', scale: 1000,
    min: 0, max: 120, step: 1, default: 5000,
    hint: '被叫后等几秒再进模型（0–120 秒）。私聊：安静这么久才答，期间的新消息并进来；'
      + '群聊：唤醒消息等这么久，期间非唤醒消息并入当前轮。机器人正在回答时新唤醒直接排队、不等待。',
  },

  {
    key: 'pacing.merge.loadImages', group: '消息设置', type: 'bool', label: '识别合批内图片', default: true,
    hint: '开启：按本轮各消息及各自图片的顺序加载图片，包含群里并入本轮的非唤醒消息；关闭：只加载首条消息的图片，后续图片保留占位。增加图片会增加视觉输入成本；单图失败不影响其余图片，引用图仍按各事件原有处理。不改变唤醒、等待或排队规则。',
  },

  // ── 主动接话：没人叫也偶尔接一句（高级项默认折叠）─────────────
  // 群聊、私聊共用小时级随机窗；连续对话保留独立限制。
  {
    key: 'pacing.reply.enabled', group: '主动接话', type: 'bool', label: '允许主动接话（没人叫也偶尔接一句）', default: false,
    hint: '群聊和私聊共用总开关，关掉后只在被叫时回话。群聊还要在「群聊」页勾「允许主动接话」；私聊只对下面明确填写的 QQ 生效，名单默认空。',
  },
  {
    key: 'pacing.reply.quietHours.enabled', group: '主动接话', section: '免打扰', type: 'bool', label: '启用主动接话免打扰', default: true,
    hint: '免打扰时段暂停群聊主动接话、群聊续聊和私聊主动找话；被叫后的正常回复不受影响。默认按上海时间 23:00–08:00 免打扰。',
  },
  {
    key: 'pacing.reply.quietHours.start', group: '主动接话', section: '免打扰', type: 'str', label: '免打扰开始（HH:mm）', default: '23:00',
    hint: '24 小时制 HH:mm，例如 23:00；按下面的 IANA 时区计算，支持跨午夜。开始与结束相同表示全天免打扰。',
  },
  {
    key: 'pacing.reply.quietHours.end', group: '主动接话', section: '免打扰', type: 'str', label: '免打扰结束（HH:mm）', default: '08:00',
    hint: '24 小时制 HH:mm，例如 08:00；到结束时间后才恢复考虑主动接话，不保证立即发送。开始与结束相同表示全天免打扰。',
  },
  {
    key: 'pacing.reply.quietHours.timeZone', group: '主动接话', section: '免打扰', type: 'str', label: '免打扰时区（IANA）', default: 'Asia/Shanghai',
    hint: '填写 IANA 时区名称，例如 Asia/Shanghai、Asia/Tokyo 或 America/New_York；不依赖服务器或浏览器本地时区。',
  },
  {
    key: 'pacing.reply.privateChats', group: '主动接话', type: 'qq-list', label: '允许主动找话的私聊 QQ',
    default: [],
    hint: '输入一个 QQ 后点＋或按回车添加，点标签×移除；名单为空就不主动发私聊，不会自动加入主人或所有好友。加删后保存，已有名单保持不变。',
  },
  {
    key: 'pacing.reply.interval.minMs', group: '主动接话', type: 'float', label: '正常间隔最短', unit: '小时',
    scale: 3600000, min: 0.5, max: 720, step: 0.5, default: 3600000,
    hint: '群聊、私聊共用随机窗：默认在 1–4 小时之间抽下一次机会。最短不能大于最长；要提高最短，请先提高最长。改参数重新抽一次，刷新页面不抽。',
  },
  {
    key: 'pacing.reply.interval.maxMs', group: '主动接话', type: 'float', label: '正常间隔最长', unit: '小时',
    scale: 3600000, min: 0.5, max: 720, step: 0.5, default: 14400000,
    hint: '群聊、私聊使用同一个正常随机窗，默认最长 4 小时。最长不能小于最短；机会到期仍由语境与门禁决定是否发送。',
  },
  {
    key: 'pacing.reply.interval.unansweredMinMs', group: '主动接话', type: 'float', label: '未回复间隔最短', unit: '小时',
    scale: 3600000, min: 0.5, max: 720, step: 0.5, default: 14400000,
    hint: '主动发出后没有真人回复，改用未回复随机窗，默认 4–10 小时；最短不能大于最长，要提高最短请先提高最长。',
  },
  {
    key: 'pacing.reply.interval.unansweredMaxMs', group: '主动接话', type: 'float', label: '未回复间隔最长', unit: '小时',
    scale: 3600000, min: 0.5, max: 720, step: 0.5, default: 36000000,
    hint: '未回复时随机等待的上界，默认 10 小时；持续未回复继续退避至下面的上限，真人回话后恢复正常窗。',
  },
  {
    key: 'pacing.reply.interval.maxBackoffMs', group: '主动接话', type: 'float', label: '持续未回复退避上限', unit: '小时',
    scale: 3600000, min: 0.5, max: 720, step: 0.5, default: 86400000,
    hint: '群聊、私聊持续未回复时逐步拉长等待，最多 24 小时（默认）；不是永久停聊，也不是固定签到。',
  },
  {
    key: 'pacing.reply.silenceEnabled', group: '主动接话', type: 'bool', label: '群聊、私聊冷场时也主动找话', default: true,
    hint: '群聊、私聊共用冷场开关和随机间隔。开 = 到机会时即使没人说话也可主动找话；'
      + '关 = 私聊主动找话暂停，群聊不再定时找话，但群里出现新消息、且语境合适时仍可能接一句。',
  },
  {
    key: 'pacing.reply.sensitivity', group: '主动接话', type: 'int', label: '语境敏感度（越高越挑时机）', unit: '%',
    scale: 0.01, min: 0, max: 100, step: 5, default: 0.45,
    hint: '先给群消息按语境打分（问句、正在热聊、它很久没说话…分高；@别人、纯表情分低），分够高才接。',
  },
  // ── 连续对话（2026-10-27）：被真人叫过并回过话之后，隔一会儿把这期间的新消息塞回模型再判一次 ──
  // 控制台：8 项全部暴露，但不平铺在页面上——`section:'连续对话'` 让前端收进「主动接话」页里
  // 一个独立的折叠块（和「高级」按钮同一种交互），默认收起，免得把常用项挤下去。
  {
    key: 'pacing.reply.continuation.enabled', group: '主动接话', section: '连续对话', type: 'bool', label: '连续对话（回完话后再看要不要补一句）', default: false,
    hint: '开 = 被真人叫过、它回过话之后，等「回完话后等多久检查」这么久，把这期间群里新说的话再看一遍：'
      + '想补就补一句，不想补就什么都不发。\n'
      + '防自转：只有真人唤醒才会开这条链，一次唤醒只检查一次，且必须有人类新消息才会检查。'
      + '总开关（允许主动接话）关掉时它也不工作。',
  },
  {
    key: 'pacing.reply.continuation.delayMs', group: '主动接话', section: '连续对话', type: 'int', label: '回完话后等多久检查', unit: '秒',
    scale: 1000, min: 30, max: 300, step: 10, default: 120000,
    hint: '从它**发出回复**那一刻开始计时。到点时如果没人再叫它 → 看这期间有没有新的人类消息，再决定要不要补一句。',
  },
  {
    key: 'pacing.reply.continuation.bonus', group: '主动接话', section: '连续对话', type: 'float', label: '情境加分', min: 0, max: 3, step: 0.1, default: 1.5,
    hint: '和「主动接话」共用同一套语境权重与门槛，这里只是给"刚聊过"这个情境加的分（直接加到分数上）。\n'
      + '0 = 完全按原权重（续聊几乎永远过不了门槛）；调高 = 更容易补这一句。默认 1.5。',
  },
  {
    key: 'pacing.reply.continuation.hourlyMax', group: '主动接话', section: '连续对话', type: 'int', label: '每群每小时最多补几次', unit: '次',
    min: 1, max: 20, step: 1, default: 5,
    hint: '防话痨：每个群每小时最多起几次续聊检查。和下面的「两次续聊最小间隔」一起，两个都满足才会触发。',
  },
  {
    key: 'pacing.reply.continuation.minGapMs', group: '主动接话', section: '连续对话', type: 'int', label: '两次续聊最小间隔', unit: '分钟',
    scale: 60000, min: 1, max: 60, step: 1, default: 300000,
    hint: '两次续聊检查之间至少隔这么久，防止"刚补完又补"。默认 5 分钟。',
  },
  {
    key: 'pacing.reply.continuation.maxPerChain', group: '主动接话', section: '连续对话', type: 'int', label: '一次唤醒最多检查几次', unit: '次',
    min: 1, max: 3, step: 1, default: 1,
    hint: '**防自转的核心**：一次真人唤醒最多只走 1 次续聊检查（默认 1）。'
      + '调成 2~3 会让它在一段对话里多回看几次，也更容易显得"黏人"，建议先保持 1。',
  },
  {
    key: 'pacing.reply.continuation.requireNewMessage', group: '主动接话', section: '连续对话', type: 'bool', label: '必须有人类新消息才检查', default: true,
    hint: '开（推荐）：它回完之后，群里必须有人再说话，才会做续聊检查；没人说话就彻底不触发。\n'
      + '关：没人接话也会隔一会儿自己回看一次，按当前语境打分（没有新消息时不会引用旧消息）——容易变成"自问自答"，不建议关。',
  },
  {
    key: 'pacing.reply.continuation.quoteLastHuman', group: '主动接话', section: '连续对话', type: 'bool', label: '续聊时引用最后一条人类消息', default: false,
    hint: '开 = 补的那一句会挂在"最后一条人类消息"下面（引用），视觉上更像在接话；关 = 普通发言。\n'
      + '注意：主动接话/续聊默认不 @ 任何人，这里只控制引用（挂哪条消息）。',
  },
  {
    key: 'pacing.reply.maxChars', group: '主动接话', type: 'int', label: '主动接话最多多少字', unit: '字',
    min: 20, max: 500, step: 10, default: 140,
    hint: '提示里要求它主动接话别太长；超了照发但会记日志。',
  },
  {
    key: 'pacing.reply.groups', group: '主动接话', type: 'group', label: '允许主动接话的群',
    default: [],
    hint: '群号列表（空 = 没有群允许主动接话）。推荐在「群聊」页每张群卡片勾「允许主动接话」；这里和群卡片改的是同一份配置。',
  },

  // ── 主动接话·高级（控制台折叠在「高级」按钮里，一般不用动）─────
  {
    key: 'pacing.reply.topicWindowMs', group: '主动接话', advanced: true, type: 'int', label: '机会窗口（到点后再等多久时机）', unit: '分钟',
    scale: 60000, min: 1, max: 30, step: 1, default: 600000,
    hint: '到了机会点后在窗口里等一条“值得接”的消息；一直等不到就放弃这次机会（不硬凑）。',
  },
  {
    key: 'pacing.reply.topicMinMsgs', group: '主动接话', advanced: true, type: 'int', label: '窗口内至少几条消息才按话题接',
    min: 1, max: 20, step: 1, default: 3,
    hint: '窗口里消息太少就不按“话题”挑时机（防硬接）；冷场找话不受这条限制。',
  },
  // 9 项语境权重：只影响主动接话的“挑时机”，一般只调语境敏感度就够
  { key: 'pacing.reply.weights.intercept', group: '主动接话', advanced: true, type: 'float', label: '语境分：基础分（截距）', min: -5, max: 5, step: 0.05, default: -1.2005, hint: '所有加分项都从这一分开始；数越负整体越安静。' },
  { key: 'pacing.reply.weights.mentionBot', group: '主动接话', advanced: true, type: 'float', label: '语境分：提到它名字', min: -5, max: 5, step: 0.05, default: 1.5852, hint: '消息里出现它的名字/别名时加分（真 @ 或叫到走唤醒那条路，不看这些分）。' },
  { key: 'pacing.reply.weights.atOther', group: '主动接话', advanced: true, type: 'float', label: '语境分：@ 了别人', min: -5, max: 5, step: 0.05, default: -1.1157, hint: '群友在点名别人 = 不是冲它来的，减分。' },
  { key: 'pacing.reply.weights.hasQuestion', group: '主动接话', advanced: true, type: 'float', label: '语境分：在提问（问号）', min: -5, max: 5, step: 0.05, default: 0.4807, hint: '消息带问号 = 这话在等人回应，加分。' },
  { key: 'pacing.reply.weights.placeholderOnly', group: '主动接话', advanced: true, type: 'float', label: '语境分：只有表情/图', min: -5, max: 5, step: 0.05, default: -1.0281, hint: '只有表情包/图片、没有文字可接，减分。' },
  { key: 'pacing.reply.weights.selfRatio', group: '主动接话', advanced: true, type: 'float', label: '语境分：它自己的话占比', min: -5, max: 5, step: 0.05, default: 2.6525, hint: '近 5 分钟群里的话有多少是它说的；权重最大的一项。' },
  { key: 'pacing.reply.weights.recentCount', group: '主动接话', advanced: true, type: 'float', label: '语境分：群里刷屏程度', min: -5, max: 5, step: 0.05, default: -0.0367, hint: '近 5 分钟的消息条数；越刷屏越观望。' },
  { key: 'pacing.reply.weights.logSecondsSinceBot', group: '主动接话', advanced: true, type: 'float', label: '语境分：它多久没说话', min: -5, max: 5, step: 0.05, default: 0.0571, hint: '距它上次发言的秒数取对数；越久没说话越有信心。' },
  { key: 'pacing.reply.weights.pendingCount', group: '主动接话', advanced: true, type: 'float', label: '语境分：一次来几条', min: -5, max: 5, step: 0.05, default: 0.1012, hint: '它正在回一轮时又来消息 = 群里正热，小幅加分。' },

  // ── 其他（2026-10-20）：原来隐藏的 权限/门禁/文件/发图/头像 五组统一并到这一页 ──
  {
    key: 'info.other', group: '其他', type: 'info',
    text: '这里是低频 / 高级配置，按来源分组说明（每一项都有详细悬停解释）：\n'
      + '· 门禁：屏蔽群 / 群内黑名单 / 群内白名单 / 全局允许用户 —— 「群聊」页每张群卡片也有同样的开关，改哪边都一样。\n'
      + '· 文件 / 发图：入站文件落盘目录、可发图片目录白名单。\n'
      + '· 头像：QQ 头像缓存目录与过期时长。\n'
      + '平时不用动；改错了热生效，且有配置备份可回滚。',
  },
]

// ============================================================
// 注册表 ②：内置动作按钮（危险维护动作先预演，再带凭据确认）
// ============================================================

/** @typedef {{id:string,group:string,label:string,hint?:string,confirm?:{title?:string,okLabel?:string},hidden?:boolean}} ActionDef */
export const ACTIONS = [
  {
    id: 'selfcheck', group: '运维', label: '跑离线自检',
    hint: '检查实例配置、工具、人设与目录权限；不调用网络或模型，不写报告、不创建探针文件。',
  },
  {
    id: 'clear-qq-sessions', group: '危险操作', label: '🧹 一键清空 QQ 对话',
    hint: '清空全部 QQ 线映射并归档这些会话（含游离会话）。点击后弹窗二次确认才执行；归档只影响侧栏显示、不删文件。',
    confirm: { title: '⚠️ 确认清空全部 QQ 对话？', okLabel: '确认清空' },
  },
  {
    id: 'cleanup-tmp', group: '运维', label: '🧽 清理临时文件',
    hint: '只清理插件自有临时目录中的过期临时文件；先预演，确认携带本次预演凭据后才删除。',
    confirm: { title: '⚠️ 确认清理临时文件？', okLabel: '确认清理' },
  },
  {
    id: 'dedup-baks', group: '运维', label: '🧹 配置备份去重',
    hint: '仅去除实例配置的重复备份（按内容比较，保留不同版本）；先预演，确认携带本次预演凭据后才删除。',
    confirm: { title: '⚠️ 确认删掉重复配置备份？', okLabel: '确认去重' },
  },

  // 新手向导 / 连接自检（契约 §3.1）
  {
    id: 'onebot-check', group: '运维', label: '🔌 测试 OneBot 连接',
    hint: '向协议端发一次 get_login_info：通了一次就能收到消息；失败会给出原因（未启动 / 地址错 / token 错）。',
  },
  {
    id: 'onebot-reconnect', group: '运维', label: '↻ 重新连接 OneBot',
    hint: '重连协议端的 WebSocket（改完地址/token 但没自动重连时用）。',
  },
  {
    id: 'ensure-workspace', group: '运维', label: '📁 检查 / 创建 QQ 工作区',
    hint: '按实例配置的 dsh.qqWorkspacePath / dsh.workspaceTitle 在 DSH 侧栏注册工作区（已存在则复用，不重复创建）。控制台没有这两个字段，需要改就改 config.json（改完重启 dsh-web）。',
  },
  {
    id: 'check-host-deps', group: '运维', label: '🧪 检查运行环境',
    hint: '逐项检查「安装即用」需要的依赖：DSH 会话 / 工具 / 工作区 / preset 服务、内置 qq-chat、工作区自举、数据目录可写；'
      + '缺什么给出修复建议（可直接把结果交给 DSH，让它安装依赖）。',
  },
  {
    id: 'imagegen-check', group: '运维', label: '🖼 检查生图配置',
    hint: '校验协议 / 地址 / 模型 / API Key；必填都过了会再试一次 GET {base}/models（不通不算失败，只给提示）。',
  },
  {
    id: 'diagnose', group: '运维', label: '🩺 一键诊断 / 导出运维报告',
    hint: '检查配置、DSH preset、工具注册、OneBot 连接、人设、目录可写、生图配置，生成脱敏报告并告诉你保存位置；可直接交给 DSH 本体修复。',
  },

  // 隐藏动作（由控制台特定页面调用，不出现在按钮列表里）
  { id: 'reply-preset', hidden: true, group: '隐藏', label: '主动接话档位', hint: '内部动作：{id:"reply-preset", preset:"quiet|semi|active"}' },
  { id: 'reset-session', hidden: true, group: '隐藏', label: '重置单条会话', hint: '内部动作：{id:"reset-session", chat:"group:<群号>"}' },
  { id: 'welcome-images', hidden: true, group: '隐藏', label: '入群欢迎图片池', hint: '内部动作：列图片池目录' },
  { id: 'welcome-test', hidden: true, group: '隐藏', label: '模拟入群欢迎', hint: '内部动作：{id:"welcome-test", group_id, confirm?}' },
]

/** 控制台「运维」页要渲染的动作按钮（过滤隐藏项；confirm 透传给前端二次确认）。 */
export function visibleActions() {
  return ACTIONS.filter((a) => !a.hidden).map((a) => ({
    id: a.id, group: a.group, label: a.label, hint: a.hint || '', confirm: a.confirm || null,
  }))
}

// ============================================================
// 配置路径 → 白名单键（endpoints 的 group / memory 端点共用）
// ============================================================

/** 群管控写哪几段配置（v2 结构）。唤醒词落点 = `pluginConfig['gate-wake'].keywords`（文本行）。 */
export const GROUP_PATHS = {
  ignore: ['pluginConfig', 'gate-wake', 'ignoreGroups'],
  allowlist: ['pluginConfig', 'gate-wake', 'groupUserAllowlist'],
  blocklist: ['pluginConfig', 'gate-wake', 'groupUserBlocklist'],
  keywords: ['pluginConfig', 'gate-wake', 'keywords'],
  spont: ['pacing', 'reply', 'groups'],
  welcome: ['pluginConfig', 'group-welcome', 'groups'],
}

// ============================================================
// 子插件展开
// ============================================================

const defOf = (item) => (item && item.plugin) || item

/**
 * 全部**已发现**的子插件定义（含被配置停用的）。
 * 内核优先给 `kernel.pluginDefs`；退回 `kernel.pluginsAll`；最后退回 `kernel.plugins`（只有已加载的）。
 * @returns {{id:string, def:object, cfg:object|null, loaded:boolean}[]}
 */
export function pluginDefs(kernel = {}) {
  const out = []
  const seen = new Set()
  const add = (item, loaded) => {
    const def = defOf(item)
    const id = String((item && item.id) || (def && def.id) || '')
    if (!id || seen.has(id)) return
    seen.add(id)
    out.push({ id, def: def && typeof def === 'object' ? def : {}, cfg: (item && item.cfg) || null, loaded })
  }
  if (Array.isArray(kernel?.pluginDefs)) for (const p of kernel.pluginDefs) add(p, false)
  if (Array.isArray(kernel?.pluginsAll)) for (const p of kernel.pluginsAll) add(p, false)
  if (Array.isArray(kernel?.plugins)) for (const p of kernel.plugins) add(p, true)
  // 插件定义（kernel.pluginDefs）里没有 cfg；把内核已加载条目的**已解析 cfg**（含默认值/绝对路径）补上，
  // 这样控制台某字段在 raw 没写时能回落到真正的运行时值，而不是 schema 里的相对默认值。
  const loadedCfg = new Map(
    (Array.isArray(kernel?.plugins) ? kernel.plugins : []).map((p) => [String(p?.id || p?.plugin?.id || ''), p?.cfg || null]),
  )
  for (const rec of out) if (!rec.cfg) rec.cfg = loadedCfg.get(rec.id) || null
  const order = (p) => Number(p.def?.order) || 100
  return out.sort((a, b) => order(a) - order(b) || a.id.localeCompare(b.id))
}

/** 核心项 → 注册项（内部形态；`configPath` 为 raw 配置点路径数组）。 */
function coreEntries() {
  return CORE_CONTROLS.map((c) => ({
    kind: 'core',
    key: c.key,
    // info 是纯说明块：不映射任何配置路径，读写都被挡（见 readValue/writeValue）
    configPath: c.type === 'info' ? null : String(c.key).split('.'),
    plugin: 'core',
    field: '',
    group: c.group,
    type: c.type,
    label: c.label,
    unit: c.unit || '',
    scale: Number(c.scale) > 0 ? Number(c.scale) : 1,
    min: c.min,
    max: c.max,
    step: c.step,
    options: Array.isArray(c.options) ? c.options : null,
    hint: c.hint || '',
    text: c.text,
    suggestions: Array.isArray(c.suggestions) ? c.suggestions : null,
    default: c.default,
    secret: c.secret === true,
    // 进阶项：控制台折叠显示（如「主动接话」页的「高级」按钮）
    advanced: c.advanced === true,
    // 具名折叠块：同一标签页里再分小组（如「连续对话」），前端按 section 渲染成独立折叠块
    section: c.section || '',
  }))
}

/** 子插件 configSchema → 注册项：key = `<插件id>.<字段>`，落到 `pluginConfig.<id>.<field>`。 */
function pluginEntries(kernel) {
  const out = []
  for (const { id, def, cfg } of pluginDefs(kernel)) {
    const schema = def?.configSchema
    if (!isPlainObject(schema)) continue
    const title = String(def.title || id)
    const hidden = HIDDEN_PLUGIN_FIELDS[id] || null
    for (const [field, fdef] of Object.entries(schema)) {
      if (!isPlainObject(fdef)) continue
      if (hidden && hidden.has(field)) continue // 由专属页面管理，不渲染通用输入框
      // 插件字段可以映射到别的配置路径（例：生图凭据仍存 credentials.gptImage.*，
      // 但面板归属算 imagegen —— 这样「生图」页 = 一个子插件，旧配置零迁移）
      const configPath = fdef.type === 'info'
        ? null
        : (Array.isArray(fdef.configPath) ? fdef.configPath : ['pluginConfig', id, field])
      out.push({
        kind: 'plugin',
        key: String(fdef.key || `${id}.${field}`),
        configPath,
        plugin: id,
        field,
        title,
        cfg,
        group: fdef.group || title, // 不写 group 的字段按插件标题归组
        type: String(fdef.type || 'str'),
        label: fdef.label || field,
        unit: fdef.unit || '',
        scale: Number(fdef.scale) > 0 ? Number(fdef.scale) : 1,
        min: fdef.min,
        max: fdef.max,
        step: fdef.step,
        options: Array.isArray(fdef.options) ? fdef.options : null,
        hint: fdef.hint || '',
        text: fdef.text,
        suggestions: Array.isArray(fdef.suggestions) ? fdef.suggestions : null,
        default: fdef.default,
        secret: fdef.secret === true,
        advanced: fdef.advanced === true,
      })
    }
  }
  return out
}

/** 注册表全量（核心 + 子插件）。 */
export function allControls(kernel) {
  return [...coreEntries(), ...pluginEntries(kernel)]
}

/** 按 key 找注册项；找不到返回 null（写值时调用方负责抛“不在白名单”）。 */
export function findControl(kernel, key) {
  const k = String(key || '')
  return allControls(kernel).find((e) => e.key === k) || null
}

/** raw 配置里该注册项的**存储值**（子插件项缺键时退回内核已加载的插件 cfg，再退回 schema 默认值）。 */
function storedValue(entry, rawConfig = {}, kernel = {}) {
  if (entry.type === 'info') return undefined
  const raw = rawConfig || {}
  if (entry.kind === 'core') return getPath(raw, entry.configPath)
  const inFile = getPath(raw, entry.configPath)
  if (inFile !== undefined) return inFile
  const fromCfg = entry.cfg && entry.field ? entry.cfg[entry.field] : undefined
  if (fromCfg !== undefined) return fromCfg
  return kernel?.runtime ? getPath(kernel.runtime, entry.configPath) : undefined
}

/** 存储值 → 面板值（核心项按 scale 除；子插件项原样；秘密字段回显占位符）。 */
function panelValue(entry, rawConfig, kernel) {
  if (entry.type === 'info') return undefined
  const stored = storedValue(entry, rawConfig, kernel)
  let value = stored === undefined ? entry.default : stored
  if (entry.secret && value) return SECRET_MASK
  if (entry.kind === 'core' && entry.scale !== 1 && typeof value === 'number' && Number.isFinite(value)) {
    return round3(value / entry.scale)
  }
  return value
}

/** 按注册项的类型/范围归一**面板值**（不做 scale 换算 —— 换算在 writeValue 里一次性做）。 */
export function coercePanel(entry, raw) {
  const key = entry.key
  if (entry.type === 'info') throw new Error(`${key} 是说明块，不能写值`)
  if (entry.type === 'bool') {
    if (typeof raw !== 'boolean') throw new Error(`${key} 需要布尔值（true/false）`)
    return raw
  }
  if (entry.type === 'int') {
    const n = Number(raw)
    if (!Number.isFinite(n) || !Number.isInteger(n)) throw new Error(`${key} 需要整数`)
    if (entry.min != null && n < entry.min) throw new Error(`${key} 不能小于 ${entry.min}${entry.unit || ''}`)
    if (entry.max != null && n > entry.max) throw new Error(`${key} 不能大于 ${entry.max}${entry.unit || ''}`)
    return n
  }
  if (entry.type === 'float') {
    const n = Number(raw)
    if (!Number.isFinite(n)) throw new Error(`${key} 需要数字`)
    if (entry.min != null && n < entry.min) throw new Error(`${key} 不能小于 ${entry.min}`)
    if (entry.max != null && n > entry.max) throw new Error(`${key} 不能大于 ${entry.max}`)
    return n
  }
  if (entry.type === 'str' || entry.type === 'text') {
    const s = raw == null ? '' : String(raw)
    if (/[\u0000]/.test(s)) throw new Error(`${key} 不能包含空字符`)
    // 这里只校验写值格式；时段是否生效由 pacing 的 quietHoursStatus 统一判断。
    if (/^pacing\.reply\.quietHours\.(start|end)$/.test(key) && !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(s)) {
      throw new Error(`${key} 需要 HH:mm 格式（00:00–23:59）`)
    }
    if (key === 'pacing.reply.quietHours.timeZone') {
      try {
        if (!s || /^[+-]/.test(s)) throw new Error('not an IANA zone')
        new Intl.DateTimeFormat('en', { timeZone: s }).format(0)
      } catch {
        throw new Error(`${key} 需要有效的 IANA 时区，例如 Asia/Shanghai`)
      }
    }
    return s
  }
  if (entry.type === 'enum') {
    const v = raw == null ? '' : String(raw)
    const hit = (entry.options || []).some((o) => String(o && o.value !== undefined ? o.value : o) === v)
    if (!hit) throw new Error(`${key} 不在可选项里：${v}`)
    return v
  }
  if (entry.type === 'qq-list') {
    // 私聊名单使用数字 QQ 数组；不沿用 group 的字符串数组或通配符语义。
    if (!Array.isArray(raw) && typeof raw !== 'string') throw new Error(`${key} 需要 QQ 数组或逗号/空白分隔文本`)
    const arr = Array.isArray(raw) ? raw : raw.trim().split(/[,，\s]+/).filter(Boolean)
    const out = []
    for (const x of arr) {
      const s = typeof x === 'number' || typeof x === 'string' ? String(x).trim() : ''
      const n = Number(s)
      if (!/^\d{1,12}$/.test(s) || !Number.isSafeInteger(n) || n <= 0) throw new Error(`${key} 只能填写 1–12 位正整数 QQ 号`)
      if (!out.includes(n)) out.push(n)
    }
    return out
  }
  if (entry.type === 'group') {
    // 群号列表这类：接受数组或逗号/空白分隔字符串 → 统一成字符串数组（去空、去重）
    const arr = Array.isArray(raw) ? raw : String(raw ?? '').split(/[,，\s]+/)
    const out = []
    for (const x of arr) {
      const s = String(x).trim()
      if (s && !out.includes(s)) out.push(s)
    }
    return out
  }
  throw new Error(`${key} 的控件类型未知：${entry.type}`)
}

/** 面板值 → 存储值（核心项按 scale 乘，子插件项原样 —— 见文件头单位口径）。 */
function storedOf(entry, panel) {
  if (entry.kind !== 'core' || entry.scale === 1 || typeof panel !== 'number') return panel
  const stored = round6(panel * entry.scale)
  return entry.type === 'int' && entry.scale >= 1 ? Math.round(stored) : stored
}

/**
 * 读一个白名单键的**面板值**（供 schema/status 与测试用）。
 * @param {object} kernel
 * @param {string} key
 * @param {object} [rawConfig]
 */
export function readValue(kernel, key, rawConfig = {}) {
  const entry = findControl(kernel, key)
  if (!entry) throw new Error(`不在控制台白名单里：${key}`)
  if (entry.type === 'info') return undefined // 说明块：Read 不产出
  return panelValue(entry, rawConfig, kernel)
}

/**
 * 写一个白名单键：校验/归一 → 返回该落在 raw 配置的哪个路径、存什么值。
 * **不落盘**（落盘由 admin/store.js 负责，方便先校验后备份）。
 * @returns {{key:string, value:unknown, stored:unknown, configPath:string[], unchanged?:boolean}}
 */
export function writeValue(kernel, key, value, rawConfig = {}) {
  const entry = findControl(kernel, key)
  if (!entry) throw new Error(`不在控制台白名单里：${key}`)
  if (entry.type === 'info') throw new Error(`${key} 是说明块，不能写值`)
  if (entry.secret) {
    const s = value == null ? '' : String(value)
    if (s === SECRET_MASK) {
      return { key, value: SECRET_MASK, stored: SECRET_MASK, configPath: entry.configPath, unchanged: true }
    }
    // 秘密字段允许直接写成空串（清空）或新值
  }
  const panel = coercePanel(entry, value)
  const stored = storedOf(entry, panel)
  if (key.startsWith('pacing.reply.interval.')) {
    const interval = { ...(getPath(rawConfig, 'pacing.reply.interval') || {}), [entry.configPath.at(-1)]: stored }
    const errors = validateReplyInterval(interval)
    if (errors.length) throw new Error(errors.join('；') + '；提高最短请先提高最长，降低最长请先降低最短')
  }
  if (isPlainObject(rawConfig)) setPath(rawConfig, entry.configPath, stored)
  return { key, value: panel, stored, configPath: entry.configPath }
}

// ============================================================
// 汇总：controls / groups / modules / actions
// ============================================================

/**
 * 原来的「隐藏组」：权限/门禁/文件/发图/头像 五组不再各占一页，而是统一并到「其他」页
 * （配置路径与插件读取逻辑完全不变，只是换了个面板入口 + 补详细悬停解释）。
 */
const OTHER_GROUPS = new Set(['权限', '门禁', '文件', '发图', '头像'])
const OTHER_LABEL = '其他'

/** 跟随「人设」显示在同一页（「总览」的人设区块下方）的分组。当前为空：句池 / 唤醒 已各自成页（子插件 1:1）。 */
const PERSONA_GROUPS = []

/** 控制面板值（含默认值回填；schema 端点直接返回它）。 */
function controlView(entry, rawConfig, kernel) {
  if (entry.type === 'info') {
    // 说明块：只带 text（前端渲染整行说明），没有 value/min/max/options
    return {
      key: entry.key,
      group: entry.group,
      type: 'info',
      label: entry.label || '',
      text: String(entry.text || ''),
      hint: entry.hint || '',
    }
  }
  const view = {
    key: entry.key,
    group: entry.group,
    type: entry.type,
    label: entry.label,
    unit: entry.unit,
    scale: entry.scale,
    min: entry.min,
    max: entry.max,
    step: entry.step,
    options: entry.options,
    value: panelValue(entry, rawConfig, kernel),
    hint: entry.hint,
    default: entry.default,
  }
  if (entry.kind === 'plugin') {
    view.plugin = entry.plugin
    view.field = entry.field
    // 字段映射到别的配置路径（key 不以 <插件id>. 开头）→ 标 mapped，前端/测试都别按老约定猜
    if (!String(entry.key).startsWith(`${entry.plugin}.`)) view.mapped = true
  }
  if (entry.secret) view.secret = true
  // 进阶项：控制台默认折叠在「高级」按钮里（比如主动接话的语境权重）
  if (entry.advanced) view.advanced = true
  // 具名折叠块：前端据此在同一个标签页里额外渲染一个独立折叠区（如「连续对话」）
  if (entry.section) view.section = entry.section
  // str 控件的输入建议（前端渲染 <datalist>）
  if (Array.isArray(entry.suggestions) && entry.suggestions.length) view.suggestions = entry.suggestions
  return view
}

/**
 * 子插件清单（控制台「子插件」页与「总览 → 可选模块」）。
 * `on` = 配置层面的启用态；`loaded` = 内核当前是否真的加载成功。
 */
export function collectModules(kernel, rawConfig = {}) {
  const raw = isPlainObject(rawConfig) ? rawConfig : {}
  const errs = kernel?.pluginErrors instanceof Map ? kernel.pluginErrors : null
  const loadedIds = new Set(
    (Array.isArray(kernel?.plugins) ? kernel.plugins : []).map((p) => String(p?.id || p?.plugin?.id || '')).filter(Boolean),
  )
  const list = []
  const seen = new Set()
  for (const { id, def } of pluginDefs(kernel)) {
    seen.add(id)
    const cfg = raw.pluginConfig && isPlainObject(raw.pluginConfig[id]) ? raw.pluginConfig[id] : {}
    const hardOff = Boolean(raw.plugins && raw.plugins[id] === false)
    const hasEnabled = isPlainObject(def.configSchema) && Boolean(def.configSchema.enabled)
    // on：raw 里没写过这个插件的配置时，用内核 pluginDefs 的 enabled（已考虑停用/插件级关闭）
    const cfgOn = cfg.enabled !== false && !hardOff
    const on = isPlainObject(raw.pluginConfig) && isPlainObject(raw.pluginConfig[id]) ? cfgOn : (def.enabled !== false && !hardOff)
    const order = Number(def.order) || 100
    const err = errs?.get?.(id)
    const defError = typeof def.error === 'string' && def.error ? def.error : null
    const loaded = loadedIds.has(id)
    list.push({
      id,
      title: def.title || id,
      label: `${def.title || id}（${id}）`,
      order,
      key: hasEnabled ? `${id}.enabled` : null,
      on,
      alwaysOn: !hasEnabled,
      loaded,
      lastError: err ? String(err?.message || err) : defError,
      desc: String(def.description || def.desc || ''),
      hint: `管线顺序 order=${order}｜${loaded ? '已加载' : '未加载'}`
        + (hardOff ? '｜插件级关闭（plugins.<id> = false）' : ''),
    })
  }
  if (errs) {
    for (const [id, e] of errs) {
      if (seen.has(id)) continue
      seen.add(id)
      list.push({
        id, title: id, label: id, order: 100, key: null, on: false, alwaysOn: false,
        loaded: false, lastError: String(e?.message || e), desc: '',
        hint: '插件加载失败（详见内核日志）',
      })
    }
  }
  for (const [id, v] of Object.entries(raw.plugins || {})) {
    if (v !== false || seen.has(id)) continue
    list.push({
      id, title: id, label: id, order: 100, key: null, on: false, alwaysOn: false,
      loaded: false, lastError: null, desc: '', hint: '在配置里被插件级关闭（plugins.<id> = false）',
    })
  }
  return list.sort((a, b) => a.order - b.order || a.id.localeCompare(b.id))
}

/**
 * 汇总成控制台能直接渲染的 schema（形状对齐现网 /admin/schema 响应）。
 * @param {object} kernel
 * @param {object} [rawConfig] 实例配置 raw（v2；缺省用 kernel.raw）
 * @returns {{controls:object[], groups:{name:string,plugins:string[]}[], modules:object[], actions:object[]}}
 */
export function collectSchema(kernel, rawConfig) {
  const raw = isPlainObject(rawConfig) ? rawConfig : (isPlainObject(kernel?.raw) ? kernel.raw : {})
  // 权限/门禁/文件/发图/头像 → 统一并到「其他」页（配置路径不变，只是换分组）
  const entries = allControls(kernel).map((e) => (OTHER_GROUPS.has(e.group) ? { ...e, group: OTHER_LABEL } : e))
  // 「表情包」页顶部一行实时概况（数量/标签数随时变 → 插件现算后给，不塞进静态 schema 文字）。
  // 插件没加载 / 没提供统计时静默跳过，控制台照常可用。
  const stickerStats = (() => {
    const fn = kernel?.shared?.stickerStats
    if (typeof fn !== 'function') return null
    try { return fn() } catch { return null }
  })()
  if (stickerStats?.ok) {
    const at = entries.findIndex((e) => e.group === '表情包')
    if (at >= 0) {
      entries.splice(at, 0, {
        key: 'info.stickers', group: '表情包', type: 'info', kind: 'plugin', plugin: 'stickers',
        text: `当前表情库：${stickerStats.count} 张（其中 ${stickerStats.tagged} 张打过标签，共 ${stickerStats.tags} 个标签）｜上限 ${stickerStats.max} 张`
          + (stickerStats.dead > 0 ? `\n⚠️ 另有 ${stickerStats.dead} 条索引指向已被删除的图片（挑到会跳过；打开「收表情」后会自动清理）` : '')
          + `\n收表情（会写索引）：${stickerStats.collect ? '开 —— 会收新图并写 index.json' : '关 —— 库只读，只能挑现有图发'}`,
      })
    }
  }
  const controls = entries.map((e) => controlView(e, raw, kernel))
  const groups = new Map() // group 名 -> Set<来源>（core / 插件 id），保持首次出现顺序
  for (const e of entries) {
    // PERSONA_GROUPS 当前为空（句池/唤醒 已各自成页）；机制保留：以后要折叠进总览的小组写这里
    if (PERSONA_GROUPS.includes(e.group)) continue
    if (!groups.has(e.group)) groups.set(e.group, new Set())
    groups.get(e.group).add(e.kind === 'core' ? 'core' : e.plugin)
  }
  return {
    controls,
    groups: [...groups].map(([name, plugins]) => ({ name, plugins: [...plugins] })),
    modules: collectModules(kernel, raw),
    actions: visibleActions(),
    // 跟随「人设」一起显示在「总览」页的组（不再单独成页）
    personaGroups: [...PERSONA_GROUPS],
  }
}
