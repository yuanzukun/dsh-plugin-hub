#!/usr/bin/env node
/** ArmorBreak native CLI (P2 slice): doctor/capabilities/analyze/task/mcp. */
import { requestTrustedHostApproval } from './approvalPrompt.js'
import { isMainModule } from '../../lib/core/isMainModule.js'
import { createEngine } from '../engine-node/index.js'
import { makeApprovalId } from '../../lib/control/approvalAuthority.js'
import { createMcpServer } from '../mcp-server/index.js'
import { copyFileSync, existsSync, readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { resolve, join } from 'node:path'
import { homedir } from 'node:os'
import { spawn } from 'node:child_process'
import { applyJsonInstall, planJsonInstall, uninstallJsonServer } from '../installer/index.js'
import { applyTomlInstall, planTomlInstall, uninstallTomlServer } from '../installer/toml.js'
import { applyYamlInstall, planYamlInstall, uninstallYamlServer } from '../installer/yaml.js'
import { inspectDshHostProfile } from '../../lib/integrations/dshHostInspector.js'
import { diagnoseDshAnchors } from '../../lib/integrations/dshAnchorDiagnostic.js'
import { inspectDshRuntimeLayout } from '../../lib/integrations/dshRuntimeLayout.js'

function parse(argv) {
  const positional = []
  const options = {}
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i]
    if (token === '--json') options.json = true
    else if (token.startsWith('--')) {
      const key = token.slice(2)
      const value = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : true
      options[key] = value
    } else positional.push(token)
  }
  return { command: positional.shift() ?? 'help', positional, options }
}

function print(value, json) {
  process.stdout.write(`${json ? JSON.stringify(value, null, 2) : String(value)}\n`)
}

function config(env = process.env) {
  const stateRoot = env.ARMORBREAK_STATE_ROOT
  const workspaceId = env.ARMORBREAK_WORKSPACE
  const principalId = env.ARMORBREAK_PRINCIPAL_ID ?? 'cli-local-user'
  if (!stateRoot || !workspaceId) throw new Error('ARMORBREAK_STATE_ROOT and ARMORBREAK_WORKSPACE are required')
  const principal = { id: principalId, kind: 'local-user', workspaces: [workspaceId] }
  return { stateRoot, workspaceId, principal, principals: [principal] }
}

export async function runCli(argv = process.argv.slice(2), dependencies = {}) {
  const { command, positional, options } = parse(argv)
  if (command === 'start') {
    if (positional.length || Object.keys(options).some(k => !['workspace','state-root','port','no-open','json'].includes(k))) throw new Error('start accepts --workspace, --state-root, --port, --no-open and --json')
    const env = dependencies.env ?? process.env
    const workspaceId = resolve(String(options.workspace ?? env.ARMORBREAK_WORKSPACE ?? process.cwd()))
    const stateRoot = resolve(String(options['state-root'] ?? env.ARMORBREAK_STATE_ROOT ?? env.ARMORBREAK_HOME ?? join(homedir(), '.armorbreak')))
    const port = options.port === undefined ? 0 : Number(options.port)
    if (!Number.isInteger(port) || port < 0 || port > 65535 || options.port === true) throw new Error('port must be an integer from 0 to 65535')
    const { createWorkbenchServer } = await import('../../workbench/server.mjs')
    const server = await createWorkbenchServer({ port, native: {workspaceId,stateRoot} })
    print(options.json ? {url:server.url,workspace:workspaceId,mode:'LOCAL_READ_ONLY',authentication:'NONE'} : `ArmorBreak 工作台：${server.url}\n当前项目：${workspaceId}\n仅本地只读检查；按 Ctrl+C 停止。`, options.json)
    if (!options['no-open']) {
      const [binary,args] = process.platform === 'win32' ? ['rundll32.exe',['url.dll,FileProtocolHandler',server.url]] : process.platform === 'darwin' ? ['open',[server.url]] : ['xdg-open',[server.url]]
      const browser = spawn(binary,args,{stdio:'ignore',windowsHide:true,detached:true})
      browser.once('error',()=>process.stderr.write('未能自动打开浏览器，请打开上方工作台地址。\n'));browser.unref()
    }
    return server
  }
  if (command === 'help' || options.help) {
    print('armorbreak start [--workspace <project-directory>] [--no-open]|doctor|host inspect --home <absolute-path> --profile <name>|host diagnose --target <file> --spec <file>|host layout --resources <absolute-resources-directory>|config preview|config convert|config stage --bundle <file>|config status --lab <absolute-path>|config apply|config revert (trusted host only; fresh synthetic labs)|capabilities|analyze|task|workflow|approval|install approve|agent|report|mcp [--json]', false)
    return
  }
  if (command === 'host' && positional[0] === 'inspect') {
    const report = await inspectDshHostProfile({ home: options.home, profile: options.profile })
    print(JSON.stringify(report, null, 2), false)
    return
  }
  if (command === 'host' && positional[0] === 'layout') {
    const report = await inspectDshRuntimeLayout({ resources: options.resources })
    print(JSON.stringify(report, null, 2), false)
    return
  }
  if (command === 'host' && positional[0] === 'diagnose') {
    const report = await diagnoseDshAnchors({ targetFile: options.target, specFile: options.spec })
    print(JSON.stringify(report, null, 2), false)
    return
  }
  const cfg = config(dependencies.env ?? process.env)
  const engine = await createEngine(cfg)
  try {
    const ctx = { principal: cfg.principal, workspaceId: cfg.workspaceId, requestId: `cli-${Date.now()}`, traceId: `trace-${Date.now()}` }
    if (command === 'host' && positional[0] === 'health') {
      return print(await engine.analyze(ctx, { capability: 'host.health', target: options.resources,
        options: options['expected-version'] === undefined ? {} : { expectedVersion: options['expected-version'] } }), options.json)
    }
    if (command === 'doctor') return print(await engine.health(ctx), options.json)
    if (command === 'host' && positional[0] === 'diagnostics') return print(await engine.analyze(ctx, { capability: 'host.diagnostics', target: options.root }), options.json)
    if (command === 'plugin' && positional[0] === 'verify') return print(await engine.analyze(ctx, { capability: 'plugin.verify', target: options.root, options: options.closure ? { closure: true } : {} }), options.json)
    if (command === 'maintenance' && positional[0] === 'plan') return print(await engine.analyze(ctx, { capability: 'maintenance.plan', target: options.root }), options.json)
    if (command === 'maintenance' && positional[0] === 'backup-usage') return print(await engine.analyze(ctx, { capability: 'maintenance.backup_usage', target: options.root }), options.json)
    if (command === 'maintenance' && positional[0] === 'verify-snapshot') return print(await engine.analyze(ctx, { capability: 'maintenance.backup_usage', target: options.root, options: { verifySnapshot: options.snapshot } }), options.json)
    if (command === 'config' && positional[0] === 'preview') return print(await engine.analyze(ctx, { capability: 'configuration.preview', target: options.bundle }), options.json)
    if (command === 'config' && positional[0] === 'convert') return print(await engine.analyze(ctx, { capability: 'configuration.convert', target: options.bundle }), options.json)
    if (command === 'config' && ['stage','apply','revert','status'].includes(positional[0])) {
      const { configurationLabCommand } = await import('./configurationLab.js')
      return print(await configurationLabCommand({ runtime: engine.runtime, workspace: cfg.workspaceId, operator: cfg.principal.id, operation: positional[0], options, dependencies }), options.json)
    }
    if (command === 'assessment' && positional[0] === 'review') return print(await engine.analyze(ctx, { capability: 'assessment.review', target: options.bundle }), options.json)
    if (command === 'assessment' && positional[0] === 'assets') return print(await engine.analyze(ctx, { capability: 'assessment.assets', target: options.bundle }), options.json)
    if (command === 'capabilities') return print(await engine.capabilities(ctx), options.json)
    if (command === 'agent' && positional[0] === 'doctor') {
      const configPath = String(options.config ?? '')
      if (!configPath) throw new Error('agent doctor requires --config <path>')
      if (!existsSync(configPath)) throw new Error('config path does not exist')
      let document
      try { document = JSON.parse(readFileSync(configPath, 'utf8')) } catch { throw new Error('agent doctor config is not valid JSON') }
      const servers = document.mcpServers ?? document.mcp?.servers ?? {}
      const entry = servers.armorbreak ?? null
      const problems = []
      if (!entry) problems.push('armorbreak MCP entry is missing')
      else {
        if (typeof entry.command !== 'string' && typeof entry.url !== 'string') problems.push('entry needs command or url')
        const env = entry.env ?? {}
        for (const key of ['ARMORBREAK_STATE_ROOT', 'ARMORBREAK_WORKSPACE', 'ARMORBREAK_PRINCIPAL_ID']) if (!(key in env)) problems.push(`entry env is missing ${key}`)
      }
      print({ status: problems.length === 0 ? 'OK' : 'FAIL', configPath, transport: entry?.url ? 'http' : 'stdio', serverNames: Object.keys(servers), problems }, options.json)
      if (problems.length > 0) process.exitCode = 1
      return
    }
    if (command === 'agent' && positional[0] === 'install') {
      const target = String(options.target ?? '')
      const configPath = String(options.config ?? '')
      const scope = String(options.scope ?? 'project')
      if (!['claude', 'codex', 'hermes', 'generic'].includes(target)) throw new Error('agent install target must be claude, codex, hermes or generic')
      if (!configPath) throw new Error('agent install requires --config <path>; no host path is guessed')
      if (!['user', 'project'].includes(scope)) throw new Error('agent install --scope must be user or project')
      const uninstall = Boolean(options.uninstall || options.disable)
      const serverEnv = {
        ARMORBREAK_STATE_ROOT: String(options['state-root'] ?? '${ARMORBREAK_STATE_ROOT}'),
        ARMORBREAK_WORKSPACE: String(options.workspace ?? '${ARMORBREAK_WORKSPACE}'),
        ARMORBREAK_PRINCIPAL_ID: String(options.principal ?? 'armorbreak-host'),
      }
      if (options['audit-log']) serverEnv.ARMORBREAK_MCP_AUDIT_LOG = String(options['audit-log'])
      const server = {
        command: 'node',
        args: [fileURLToPath(new URL('../mcp-server/index.js', import.meta.url))],
        env: serverEnv,
      }
      if (uninstall) {
        if (!existsSync(configPath)) throw new Error('config path does not exist')
        const backup = configPath + '.armorbreak.bak'
        copyFileSync(configPath, backup)
        let result
        if (target === 'codex') result = await uninstallTomlServer({ configPath })
        else if (target === 'hermes') result = await uninstallYamlServer({ configPath })
        else result = await uninstallJsonServer({ configPath })
        return print({ status: Boolean(options.disable) ? 'DISABLED' : 'UNINSTALLED', target, scope, configPath, backup, ...result }, options.json)
      }
      let plan
      if (target === 'codex') plan = await planTomlInstall({ configPath, server, force: Boolean(options.force) })
      else if (target === 'hermes') plan = await planYamlInstall({ configPath, server, force: Boolean(options.force) })
      else plan = await planJsonInstall({ configPath, server, force: Boolean(options.force) })
      if (!options.apply) return print({ status: 'DRY_RUN', target, scope, configPath, changed: plan.changed, before: plan.before, after: plan.after, warning: 'No file written. Pass --apply after reviewing the diff.' }, options.json)
      let applied
      if (target === 'codex') applied = await applyTomlInstall(plan)
      else if (target === 'hermes') applied = await applyYamlInstall(plan)
      else applied = await applyJsonInstall(plan)
      return print({ status: 'INSTALLED', target, scope, configPath, ...applied }, options.json)
    }
    if (command === 'approval' && positional[0] === 'issue') {
      const riskLevel = String(options.risk ?? '')
      const taskId = String(options['task-id'] ?? '')
      const target = String(options.target ?? '')
      if (!['L1', 'L2'].includes(riskLevel)) throw new Error('approval risk must be L1 or L2; L3 is always denied')
      if (!taskId || !target) throw new Error('approval issue requires --task-id and --target')
      if (options.confirm !== undefined) throw new Error('approval cannot be confirmed by a predictable command-line flag')
      if (options.operator !== undefined) throw new Error('--operator is a caller-controlled label and cannot establish approval identity')
      await requestTrustedHostApproval(dependencies.approvalProvider, {
        agent: dependencies.agent,
        toolName: 'armorbreak',
        callId: dependencies.callId,
        sessionId: dependencies.sessionId,
        reason: '[ArmorBreak ' + riskLevel + '] approve task ' + taskId + ' for target ' + target,
        signal: dependencies.signal,
      })
      const issued = engine.approvalAuthority.issue({
        id: makeApprovalId(), riskLevel, taskId, target, operator: 'platform-approval',
        sessionId: dependencies.sessionId, ttlMs: 5 * 60 * 1000,
      })
      return print({ status: 'ISSUED', ...issued }, options.json)
    }
    if (command === 'install' && positional[0] === 'approve') {
      const planId = String(options['plan-id'] ?? positional[1] ?? '')
      if (!planId) throw new Error('install approve requires --plan-id')
      const plan = await engine.runtime.installer.get(planId)
      if (plan.status !== 'VERIFIED') throw new Error('installation plan must be VERIFIED; got ' + plan.status)
      if (options.operator !== undefined) throw new Error('--operator is a caller-controlled label and cannot establish approval identity')
      await requestTrustedHostApproval(dependencies.approvalProvider, {
        agent: dependencies.agent,
        toolName: 'armorbreak',
        callId: dependencies.callId,
        sessionId: dependencies.sessionId,
        reason: '[ArmorBreak L2] approve installation plan ' + plan.planId + ' hash ' + plan.planHash + ' artifact SHA-256 ' + plan.artifact.sha256 + ' path ' + plan.artifact.path,
        signal: dependencies.signal,
      })
      const approvalId = 'install:' + plan.planId
      const approvalToken = engine.runtime.approvalAuthority.issue({
        id: approvalId, riskLevel: 'L2', taskId: plan.planId, target: plan.planHash,
        operator: 'platform-approval', sessionId: dependencies.sessionId, ttlMs: 5 * 60 * 1000,
      }).token
      const approved = await engine.runtime.installer.approve(plan, { approvalToken, operator: 'platform-approval' })
      return print({ status: approved.status, planId: approved.planId, planHash: approved.planHash, approvedBy: approved.approvedBy, approvedAt: approved.approvedAt }, options.json)
    }
    if (command === 'analyze') {
      if (!options.target || !options.capability) throw new Error('analyze requires --target and --capability')
      return print(await engine.analyze(ctx, { capability: String(options.capability), target: String(options.target), options: {} }), options.json)
    }
    if (command === 'report') {
      if (!positional[0]) throw new Error('report <task-id> is required')
      return print(await engine.getReport(ctx, positional[0]), options.json)
    }
    if (command === 'task') {
      if (positional[0] === 'list') return print(await engine.listTasks(ctx), options.json)
      if (positional[0] === 'cancel' && positional[1]) return print(await engine.cancelTask(ctx, positional[1]), options.json)
      if (positional[0] !== 'status' || !positional[1]) throw new Error('task status <task-id>, task list, or task cancel <task-id> is required')
      return print(await engine.getTask(ctx, positional[1]), options.json)
    }
    if (command === 'workflow') {
      if (positional[0] === 'list') return print(await engine.listWorkflows(ctx), options.json)
      if (positional[0] === 'start') {
        if(Object.keys(options).some(k=>!['workflow','target','json'].includes(k)))throw new Error('workflow start accepts only --workflow, --target and --json')
        return print(await engine.startWorkflow(ctx,{workflow:options.workflow,target:options.target}),options.json)
      }
      if (positional[0] === 'cancel' && positional[1]) return print(await engine.cancelTask(ctx, positional[1]), options.json)
      throw new Error('workflow list, workflow start --workflow ID --target ABS, or workflow cancel <task-id> is required')
    }
    if (command === 'mcp' && positional[0] === 'serve') {
      const { server } = await createMcpServer(cfg)
      await server.serve()
      return
    }
    throw new Error(`unknown command: ${command}`)
  } finally {
    await engine.close()
  }
}

if (isMainModule(import.meta.url)) runCli().then(server => {
  if (server?.close) for (const signal of ['SIGINT','SIGTERM']) process.once(signal,()=>{server.close().then(()=>process.exit(0)).catch(()=>process.exit(1))})
}).catch((cause) => {
  process.stderr.write(`${String(cause?.message ?? cause)}\n`)
  process.exitCode = 1
})

