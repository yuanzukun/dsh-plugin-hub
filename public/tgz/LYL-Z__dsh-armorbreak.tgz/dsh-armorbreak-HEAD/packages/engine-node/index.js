/**
 * @armorbreak/engine-node (P1 slice)
 *
 * The Engine is the only host-facing entry that resolves a trusted principal and
 * workspace before touching task state. A model-provided principal/operator is
 * never trusted: principals come from constructor configuration controlled by the
 * embedding host. Request ids are idempotent and replaying a different payload is
 * rejected rather than silently creating a second task.
 */
import { createHash } from 'node:crypto'
import { constants } from 'node:fs'
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from 'node:path'
import { open, realpath, stat } from 'node:fs/promises'
import { getRuntime } from '../../lib/core/runtime.js'
import { ApprovalAuthority } from '../../lib/control/approvalAuthority.js'
import { listWorkflows, getWorkflow } from '../../lib/core/workflows.js'
import { validateInvocation } from '../protocol/index.js'
import { createEvidenceEnvelope, createEventEnvelope, CORE_VERSION } from '../core/index.js'
import { isFilesystemPathWithin, sameFilesystemPath } from '../../lib/core/pathBoundary.js'

const MAX_TITLE = 300
const MAX_OBJECTIVE = 5000
const MAX_TARGET = 4096
const MAX_IDEMPOTENCY = 10_000
const MAX_REPORT_BYTES = 256 * 1024

function samePath(a, b) {
  return sameFilesystemPath(a, b)
}

function sessionOf(ctx) {
  const value = ctx?.principal?.sessionId ?? ctx?.connectionId ?? null
  if (value === null || value === undefined || value === '') return null
  if (typeof value !== 'string' || value.length > 200) throw new EngineError('INVALID_REQUEST', 'session id is invalid')
  return value
}

function taskOwnedBy(task, principal, sessionId) {
  return task?.principalId === principal.id && (task.sessionId ?? null) === sessionId
}

function pathWithin(root, target) {
  return isFilesystemPathWithin(root, target)
}

function denyReport(message) {
  throw new EngineError('POLICY_DENIED', message)
}

function assertCanonicalReportPaths(tasksRoot, taskDirectory, reportsRoot, candidate, canonicalPaths) {
  const [canonicalTasksRoot, canonicalTaskDirectory, canonicalRoot, canonicalFile] = canonicalPaths
  const expectedTaskDirectory = join(canonicalTasksRoot, basename(taskDirectory))
  const expectedReportsRoot = join(expectedTaskDirectory, 'reports')
  const expectedReportFile = join(expectedReportsRoot, relative(reportsRoot, candidate))
  const violations = []
  // Permit a trusted workspace/state-root ancestor to be canonicalized by Windows
  // (for example, a runner TEMP junction), while rejecting a redirected task leaf
  // or any link/escape below the task directory.
  if (!samePath(expectedTaskDirectory, canonicalTaskDirectory)) violations.push('task-directory-realpath-changed')
  if (!samePath(expectedReportsRoot, canonicalRoot)) violations.push('reports-root-realpath-changed')
  if (!samePath(expectedReportFile, canonicalFile)) violations.push('report-file-realpath-changed')
  if (!pathWithin(canonicalTasksRoot, canonicalTaskDirectory)) violations.push('task-directory-outside-tasks-root')
  if (!pathWithin(canonicalTaskDirectory, canonicalRoot)) violations.push('reports-root-outside-task-directory')
  if (!pathWithin(canonicalRoot, canonicalFile)) violations.push('report-file-outside-reports-root')
  if (samePath(canonicalRoot, canonicalTaskDirectory)) violations.push('reports-root-equals-task-directory')
  if (samePath(canonicalFile, canonicalRoot)) violations.push('report-file-equals-reports-root')
  if (violations.length) denyReport(`report path validation failed (${violations.join(',')})`)
  return { canonicalRoot, canonicalFile }
}

async function canonicalReportPaths(tasksRoot, taskDirectory, reportsRoot, candidate) {
  const values = await Promise.all([realpath(tasksRoot), realpath(taskDirectory), realpath(reportsRoot), realpath(candidate)])
  return assertCanonicalReportPaths(tasksRoot, taskDirectory, reportsRoot, candidate, values)
}

async function readBoundedReport(handle) {
  const buffer = Buffer.alloc(MAX_REPORT_BYTES + 1)
  let offset = 0
  while (offset < buffer.length) {
    const { bytesRead } = await handle.read(buffer, offset, buffer.length - offset, offset)
    if (bytesRead === 0) break
    offset += bytesRead
  }
  if (offset > MAX_REPORT_BYTES) denyReport('report exceeds 256 KiB')
  return buffer.subarray(0, offset)
}

export async function readTaskReport(store, report) {
  const taskDirectory = resolve(store.taskDir(report.taskId))
  const reportsRoot = join(taskDirectory, 'reports')
  const candidate = resolve(String(report.path ?? ''))
  if (!pathWithin(reportsRoot, candidate) || samePath(candidate, reportsRoot)) {
    denyReport('report path is outside the task report directory')
  }
  if (typeof report.sha256 !== 'string' || !/^[a-f\d]{64}$/i.test(report.sha256)) {
    throw new EngineError('EVIDENCE_MISMATCH', 'report metadata must contain a valid SHA-256 digest')
  }

  // Resolve the trusted path before opening, then resolve it again afterwards.
  // On Windows O_NOFOLLOW is unavailable; canonical path equality and the
  // opened-file identity checks below reject junction swaps before any bytes
  // are read. On POSIX, O_NOFOLLOW rejects a final-component symlink and
  // O_NONBLOCK prevents a substituted FIFO from hanging the report reader.
  const tasksRoot = resolve(store.tasksDir ?? dirname(taskDirectory))
  const initialPaths = await canonicalReportPaths(tasksRoot, taskDirectory, reportsRoot, candidate)
  if (process.platform !== 'win32' &&
      (typeof constants.O_NOFOLLOW !== 'number' || typeof constants.O_NONBLOCK !== 'number')) {
    denyReport('the platform cannot guarantee a bounded no-follow report open')
  }
  const flags = constants.O_RDONLY | (process.platform === 'win32' ? 0 : constants.O_NOFOLLOW | constants.O_NONBLOCK)
  const handle = await open(candidate, flags)
  try {
    const opened = await handle.stat({ bigint: true })
    if (!opened.isFile() || opened.nlink !== 1n || opened.dev === 0n || opened.ino === 0n || opened.size > BigInt(MAX_REPORT_BYTES)) {
      denyReport('report file type, identity, link count, or size is not allowed')
    }

    const currentPaths = await canonicalReportPaths(tasksRoot, taskDirectory, reportsRoot, candidate)
    if (!samePath(initialPaths.canonicalRoot, currentPaths.canonicalRoot) ||
        !samePath(initialPaths.canonicalFile, currentPaths.canonicalFile)) {
      denyReport('report path changed while it was being opened')
    }
    const current = await stat(currentPaths.canonicalFile, { bigint: true })
    if (!current.isFile() || current.nlink !== 1n || current.dev !== opened.dev || current.ino !== opened.ino) {
      denyReport('report file identity changed while it was being opened')
    }

    const bytes = await readBoundedReport(handle)
    const actualDigest = createHash('sha256').update(bytes).digest('hex')
    if (actualDigest !== report.sha256.toLowerCase()) {
      throw new EngineError('EVIDENCE_MISMATCH', 'report hash does not match task metadata')
    }
    return bytes.toString('utf8')
  } finally {
    await handle.close()
  }
}

function hash(value) {
  return createHash('sha256').update(JSON.stringify(value)).digest('hex')
}

export class EngineError extends Error {
  constructor(code, message) {
    super(message)
    this.name = 'EngineError'
    this.code = code
  }
}

export class TrustedEngine {
  /**
   * @param {{stateRoot: string, principals: Array<{id:string, kind:'local-user'|'service'|'verified-host', workspaces:string[]}>}} options
   */
  constructor(options) {
    if (!options?.stateRoot) throw new Error('stateRoot is required')
    if (!Array.isArray(options.principals) || options.principals.length === 0) throw new Error('at least one trusted principal is required')
    this.stateRoot = options.stateRoot
    this.principals = new Map()
    for (const principal of options.principals) {
      if (!principal?.id || !['local-user', 'service', 'verified-host'].includes(principal.kind)) throw new Error('invalid trusted principal')
      if (!Array.isArray(principal.workspaces) || principal.workspaces.length === 0) throw new Error(`principal ${principal.id} needs workspaces`)
      this.principals.set(principal.id, { ...principal, workspaces: new Set(principal.workspaces) })
    }
    this.idempotency = new Map()
    this.approvalAuthority = options.approvalAuthority ?? new ApprovalAuthority({ stateRoot: this.stateRoot })
    this.requestTimeoutMs = Number(options.requestTimeoutMs ?? 30_000)
    this.runtime = getRuntime({ stateRoot: this.stateRoot })
  }

  async init() {
    await this.runtime.init()
    return this
  }

  async close() {
    await this.runtime.close?.()
  }

  bounded(ctx, operation) {
    const signal = ctx?.cancellation ?? ctx?.signal
    if (signal?.aborted) return Promise.reject(new EngineError('CANCELLED', 'request was cancelled before execution'))
    let timeoutMs = this.requestTimeoutMs
    if (ctx?.deadline !== undefined) {
      const deadline = Date.parse(String(ctx.deadline))
      if (!Number.isFinite(deadline)) return Promise.reject(new EngineError('INVALID_REQUEST', 'deadline must be an ISO timestamp'))
      timeoutMs = Math.min(timeoutMs, deadline - Date.now())
      if (timeoutMs <= 0) return Promise.reject(new EngineError('TIMEOUT', 'request deadline has passed'))
    }
    let timer
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new EngineError('TIMEOUT', `request exceeded ${timeoutMs}ms`)), timeoutMs)
      timer.unref?.()
    })
    let abortHandler
    const aborted = new Promise((_, reject) => {
      if (!signal) return
      abortHandler = () => reject(new EngineError('CANCELLED', 'request aborted'))
      signal.addEventListener('abort', abortHandler, { once: true })
    })
    const running = typeof operation === 'function' ? operation() : operation
    return Promise.race([running, timeout, aborted]).finally(() => {
      clearTimeout(timer)
      if (signal && abortHandler) signal.removeEventListener('abort', abortHandler)
    })
  }

  authenticate(ctx) {
    if (ctx?.cancellation?.aborted || ctx?.signal?.aborted) throw new EngineError('CANCELLED', 'request was cancelled')
    const validation = validateInvocation(ctx)
    if (!validation.ok) throw new EngineError('INVALID_REQUEST', validation.issues.join('; '))
    const configured = this.principals.get(ctx.principal.id)
    if (!configured || configured.kind !== ctx.principal.kind) throw new EngineError('POLICY_DENIED', 'unknown principal or kind mismatch')
    const requestedWorkspace = resolve(String(ctx.workspaceId))
    const allowed = [...configured.workspaces].some((entry) => entry === '*' || samePath(entry, requestedWorkspace))
    if (!allowed) throw new EngineError('POLICY_DENIED', 'principal is not allowed to access this workspace')
    sessionOf(ctx)
    return configured
  }

  checkIdempotency(principal, ctx, payload) {
    const key = `${principal.id}:${sessionOf(ctx) ?? ''}:${ctx.workspaceId}:${ctx.requestId}`
    const digest = hash(payload)
    const existing = this.idempotency.get(key)
    if (existing) {
      if (existing.digest !== digest) throw new EngineError('INVALID_REQUEST', 'requestId reused with a different payload')
      return existing.promise
    }
    if (this.idempotency.size >= MAX_IDEMPOTENCY) throw new EngineError('ENGINE_UNAVAILABLE', 'idempotency cache is full')
    return null
  }

  /**
   * Create a task. It intentionally accepts only a trusted principal as operator;
   * an `operator` supplied in the payload must equal that principal or be absent.
   */
  async createTask(ctx, input = {}) {
    const principal = this.authenticate(ctx)
    if (input.operator !== undefined && input.operator !== principal.id) throw new EngineError('POLICY_DENIED', 'model-supplied operator cannot override the trusted principal')
    const title = String(input.title ?? '').trim()
    const objective = String(input.objective ?? '').trim()
    if (!title || title.length > MAX_TITLE) throw new EngineError('INVALID_REQUEST', `title must be 1..${MAX_TITLE} chars`)
    if (objective.length > MAX_OBJECTIVE) throw new EngineError('INVALID_REQUEST', `objective exceeds ${MAX_OBJECTIVE} chars`)
    if (input.targetPath !== undefined && String(input.targetPath).length > MAX_TARGET) throw new EngineError('INVALID_REQUEST', 'targetPath is too long')
    const payload = { title, objective, workflowId: input.workflowId ?? null, targetPath: input.targetPath ?? null, targetKind: input.targetKind ?? 'none', steps: input.steps ?? [] }
    const replay = this.checkIdempotency(principal, ctx, payload)
    if (replay) return replay
    const promise = this.runtime.workspace(ctx.workspaceId).taskStore.create({
      ...payload,
      operator: principal.id,
      principalId: principal.id,
      sessionId: sessionOf(ctx),
    })
    this.idempotency.set(`${principal.id}:${sessionOf(ctx) ?? ''}:${ctx.workspaceId}:${ctx.requestId}`, { digest: hash(payload), promise })
    return promise
  }

  /** Verify and consume a human/platform approval; model text is never an approval. */
  async verifyApproval(ctx, { riskLevel, taskId, target, approvalToken } = {}) {
    const principal = this.authenticate(ctx)
    if (!['L1', 'L2'].includes(riskLevel)) throw new EngineError('INVALID_REQUEST', 'approval is only valid for L1/L2')
    if (!approvalToken) throw new EngineError('APPROVAL_REQUIRED', 'an approval token is required')
    if (!taskId || !target) throw new EngineError('INVALID_REQUEST', 'taskId and target are required')
    const result = this.approvalAuthority.consume(String(approvalToken), { taskId: String(taskId), target: String(target), riskLevel, operator: principal.id, sessionId: sessionOf(ctx) })
    if (!result.valid) throw new EngineError(result.code ?? 'POLICY_DENIED', result.reason ?? 'approval rejected')
    return { approvalId: result.payload.id, riskLevel, operator: principal.id, expiresAt: result.payload.expiresAt, taskId: String(taskId) }
  }

  /** Persist a sanitized event/evidence envelope into the existing evidence chain. */
  async recordEnvelope(ctx, taskId, { origin = 'sdk', targetHash, payload = {}, event } = {}) {
    return this.bounded(ctx, async () => {
      const principal = this.authenticate(ctx)
      const store = this.runtime.workspace(ctx.workspaceId).taskStore
      const task = await store.get(String(taskId))
      if (!taskOwnedBy(task, principal, sessionOf(ctx)) || !samePath(task.workspace, ctx.workspaceId)) throw new EngineError('POLICY_DENIED', 'task is outside the authorized principal, session, or workspace')
      const envelope = event
        ? createEventEnvelope({ ctx, taskId: task.id, origin, targetHash, event, payload })
        : createEvidenceEnvelope({ ctx, taskId: task.id, origin, targetHash, payload })
      const record = await store.evidenceStore(task.id).addEvidence({ title: event ? `event:${event}`.slice(0, 200) : 'evidence-envelope', kind: 'event-envelope', excerpt: JSON.stringify(envelope), meta: { traceId: ctx.traceId, principalId: ctx.principal.id, origin, targetHash, payloadSha256: envelope.payloadSha256 }, targetSha256: targetHash })
      return { envelope, evidenceId: record.id }
    })
  }

  async getTask(ctx, taskId) {
    const principal = this.authenticate(ctx)
    let task
    try { task = await this.runtime.workspace(ctx.workspaceId).taskStore.get(String(taskId)) } catch { throw new EngineError('POLICY_DENIED', 'task is outside the authorized workspace') }
    if (!taskOwnedBy(task, principal, sessionOf(ctx)) || !samePath(task.workspace, ctx.workspaceId)) throw new EngineError('POLICY_DENIED', 'task is outside the authorized principal, session, or workspace')
    return task
  }

  async listTasks(ctx) {
    const principal = this.authenticate(ctx)
    const tasks = await this.runtime.workspace(ctx.workspaceId).taskStore.list(1000)
    return tasks.filter((task) => taskOwnedBy(task, principal, sessionOf(ctx))).slice(0, 20)
  }

  async cancelTask(ctx, taskId, reason = 'cancelled by trusted principal') {
    const principal = this.authenticate(ctx)
    const store = this.runtime.workspace(ctx.workspaceId).taskStore
    let task
    try { task = await store.get(String(taskId)) } catch { throw new EngineError('POLICY_DENIED', 'task is outside the authorized workspace') }
    if (!taskOwnedBy(task, principal, sessionOf(ctx)) || !samePath(task.workspace, ctx.workspaceId)) throw new EngineError('POLICY_DENIED', 'task is outside the authorized principal, session, or workspace')
    await store.cancel(task, reason.slice(0, 300))
    return { taskId: task.id, state: 'CANCELLED', principalId: principal.id, traceId: ctx.traceId }
  }

  async getEvidence(ctx, taskId) {
    return this.bounded(ctx, async () => {
      const principal = this.authenticate(ctx)
      const store = this.runtime.workspace(ctx.workspaceId).taskStore
      let task
      try { task = await store.get(String(taskId)) } catch { throw new EngineError('POLICY_DENIED', 'task is outside the authorized workspace') }
      if (!taskOwnedBy(task, principal, sessionOf(ctx)) || !samePath(task.workspace, ctx.workspaceId)) throw new EngineError('POLICY_DENIED', 'task is outside the authorized principal, session, or workspace')
      const records = await store.evidenceStore(task.id).readEvidence(200)
      return { taskId: task.id, evidence: records.map((record) => ({ id: record.id, title: record.title, kind: record.kind, excerpt: record.excerpt, hash: record.hash, targetSha256: record.targetSha256 })) }
    })
  }

  async getReport(ctx, taskId) {
    return this.bounded(ctx, async () => {
      const principal = this.authenticate(ctx)
      const store = this.runtime.workspace(ctx.workspaceId).taskStore
      let task
      try { task = await store.get(String(taskId)) } catch { throw new EngineError('POLICY_DENIED', 'task is outside the authorized workspace') }
      if (!taskOwnedBy(task, principal, sessionOf(ctx)) || !samePath(task.workspace, ctx.workspaceId)) throw new EngineError('POLICY_DENIED', 'task is outside the authorized principal, session, or workspace')
      if (!task.report?.path) throw new EngineError('INVALID_REQUEST', 'task has no report')
      const content = await readTaskReport({ taskDir: (id) => store.taskDir(id), tasksDir: store.tasksDir }, { ...task.report, taskId: task.id })
      return { taskId: task.id, path: task.report.path, sha256: task.report.sha256, markdown: content }
    })
  }

  async listWorkflows(ctx) {
    this.authenticate(ctx)
    return listWorkflows()
  }

  /** Run a registered, entirely L0 workflow through the existing Core DAG runner. */
  async startWorkflow(ctx, input = {}) {
    return this.bounded(ctx, async()=>{
      this.authenticate(ctx)
      if(!input||Array.isArray(input)||Object.keys(input).some(k=>!['workflow','target'].includes(k))||typeof input.workflow!=='string'||input.workflow.length>120)throw new EngineError('INVALID_REQUEST','registered workflow and target are required')
      const workflow=getWorkflow(input.workflow)
      if(workflow.steps.some(step=>this.runtime.registry.get(step.capabilityId)?.riskLevel!=='L0'))throw new EngineError('APPROVAL_REQUIRED','this entry supports registered L0 workflows only')
      const targetPath=workflow.targetKind==='none'?null:typeof input.target==='string'&&input.target.trim()&&input.target.length<=MAX_TARGET?resolve(input.target):null
      if(workflow.targetKind!=='none'&&!targetPath)throw new EngineError('INVALID_REQUEST','workflow requires a file or directory target')
      if(targetPath&&!pathWithin(ctx.workspaceId,targetPath))throw new EngineError('TARGET_OUT_OF_SCOPE','target is outside the authorized workspace')
      const task=await this.createTask(ctx,{title:workflow.title,objective:workflow.description,workflowId:workflow.id,targetPath,targetKind:workflow.targetKind,steps:structuredClone(workflow.steps)})
      const completed=await this.runtime.runner.runWorkflow(task,{requestApproval:async()=>false,signal:ctx.cancellation??ctx.signal,generateReport:true})
      const evidence=await this.getEvidence(ctx,task.id)
      return {taskId:task.id,workflowId:workflow.id,state:completed.state,stats:completed.stats,report:completed.report??null,
        evidenceIds:evidence.evidence.map(e=>e.id),reportPath:completed.report?.path??null,
        data:{workflowId:workflow.id,findings:completed.stats.findings,evidence:completed.stats.evidence,
          steps:completed.steps.map(s=>({id:s.id,title:s.title,capability:s.capabilityId,status:s.status,summary:s.summary??null}))}}
    })
  }

  async capabilities(ctx) {
    this.authenticate(ctx)
    return this.runtime.registry.list()
  }

  /** Execute one L0 capability through the existing Core runner. L1/L2 never self-approve. */
  async analyze(ctx, { capability, target, options = {} } = {}) {
    return this.bounded(ctx, async () => {
      const principal = this.authenticate(ctx)
      const capabilityId = String(capability ?? '')
      const selected = this.runtime.registry.get(capabilityId)
      if (!selected) throw new EngineError('UNKNOWN_CAPABILITY', `unknown capability: ${capabilityId}`)
      if (selected.riskLevel !== 'L0') throw new EngineError('APPROVAL_REQUIRED', `${selected.riskLevel} requires a trusted approval; MCP cannot self-approve`)
      if (!target) throw new EngineError('INVALID_REQUEST', 'target is required for an L0 file analysis')
      const workspaceRoot = resolve(ctx.workspaceId)
      const targetPath = resolve(String(target))
      if (targetPath !== workspaceRoot && !targetPath.startsWith(workspaceRoot + sep)) throw new EngineError('TARGET_OUT_OF_SCOPE', 'target is outside the authorized workspace')
      const store = this.runtime.workspace(ctx.workspaceId).taskStore
      const task = await store.create({
        title: `MCP ${selected.title}`,
        objective: `Run ${capabilityId} on ${targetPath}`,
        workflowId: null,
        targetPath,
        targetKind: selected.targetKind ?? 'file',
        operator: principal.id,
        principalId: principal.id,
        sessionId: sessionOf(ctx),
        steps: [{ id: 'analyze', title: selected.title, capabilityId, options: options && typeof options === 'object' ? options : {} }],
      })
      let result
      try { result = await this.runtime.runner.runCapability({
        task, capabilityId, targetPath, options: options && typeof options === 'object' ? options : {},
        stepId: task.steps.find((step) => step.status === 'PENDING')?.id ?? null,
        requestApproval: async () => false,
        signal: ctx.cancellation ?? ctx.signal,
      }) } catch (error) {
        // A rejected analysis must not leave an EXECUTING task that reappears as
        // INTERRUPTED on restart. Settle the real step before preserving the error.
        if (error?.code === 'CANCELLED') await store.cancel(task, 'analysis cancelled')
        else {
          const step = task.steps.find(s => s.id === 'analyze')
          if (step && !['DONE','FAILED'].includes(step.status)) await store.updateStep(task, step.id, {status:'FAILED',error:'analysis rejected; see Core audit',finishedAt:new Date().toISOString()})
          if (['EXECUTING','COLLECTING_EVIDENCE','VERIFYING'].includes(task.state)) await this.runtime.runner.finalizeTask(task,{generateReport:true})
          else if (!['FAILED','REJECTED','CANCELLED','TIMED_OUT'].includes(task.state)) await store.transition(task,'FAILED','analysis rejected before execution completed')
        }
        throw error
      }
      let finalized = task
      if (!task.steps.some((step) => step.status === 'PENDING' || step.status === 'RUNNING')) finalized = await this.runtime.runner.finalizeTask(task, { generateReport: true })
      return {
        taskId: task.id, state: finalized.state, capability: capabilityId, riskLevel: selected.riskLevel,
        target: result.target ?? targetPath, targetSha256: result.targetSha256 ?? null,
        evidenceIds: result.evidenceIds ?? [], reportPath: finalized.report?.path ?? null,
        data: result.data,
      }
    })
  }

  async health(ctx) {
    this.authenticate(ctx)
    return this.runtime.stateSummary(ctx.workspaceId)
  }
}

export async function createEngine(options) {
  const engine = await new TrustedEngine(options).init()
  const methods = ['createTask', 'getTask', 'listTasks', 'cancelTask', 'getEvidence', 'getReport', 'recordEnvelope', 'analyze', 'capabilities', 'health', 'listWorkflows', 'startWorkflow', 'verifyApproval']
  for (const name of methods) {
    const original = engine[name].bind(engine)
    engine[name] = (ctx, ...args) => engine.bounded(ctx, () => original(ctx, ...args))
  }
  return engine
}

export { CORE_VERSION }

