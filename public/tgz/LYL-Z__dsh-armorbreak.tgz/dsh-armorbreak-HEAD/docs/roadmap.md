# Roadmap / 路线图

- **Available in development.** A shared Core, CLI, MCP and local Workbench
  with evidence and reports, configuration preview and copied backup checks.
- **In progress.** Profile, plugin and maintenance lifecycle, backup recovery
  with byte-level acceptance, advanced Workbench workflows, and real DSH
  Desktop/Web integration.
- **Stable gates.** File-specific rights review, supported platform and
  installation acceptance, production identity and trusted approvals,
  reproducible assets, attestations and independent download verification.

近期重点为隔离恢复、真实宿主和 Workbench 体验。正式版以逐项验收为准。
进度沿用三仓来源与能力台账，已发布内容以 [CHANGELOG](../CHANGELOG.md) 为准。

下文保留早期研发记录。当前范围遵循 [授权使用政策](../ETHICAL_USE.md)。

## R1（下一个版本，最高价值）

1. **模型驱动 E2E 测试**：给 CLI/headless 增加可注入的 LLM mock（本地 OpenAI 兼容 SSE 服务），
   自动验证「选择破甲模式 → 模型调用工具 → 证据/报告」全链路。
2. **外部工具适配器 v1**：Ghidra（`analyzeHeadless` 导出 JSON）、JADX（`--output-format json`）、
   Semgrep（`--json`）、TShark（`-T json`）、Trivy/Syft（`--format json`）的参数数组调用 + 输出解析器 +
   依赖检查 + 结果归一化；全部经 runner 的 scope/approval 与审计。
3. **UI 工作台**：在现有 Slot 体系内增加"任务工作台/工具中心/证据中心"页面（或右栏 Tab），
   通过 Host 只读路由 + 新增只读 API 获取数据；报告预览与导出按钮。
4. **会话级工作区映射**：把当前 session 的 cwd 暴露给状态卡（通过 useSession/Remote），使状态卡显示当前会话任务。

## R2

5. **容器/虚拟机隔离提供者抽象**：Docker（已实现基础）、Podman、WSL2、Hyper-V/VMware 适配；
   L1 的能力门改为查询 provider 注册表；容器网络策略（DNS 黑洞、egress 白名单）与超时强杀。
6. **L2 主动测试能力**：授权后的 HTTP 探测扩展（多请求模板、速率限制、并发上限、结果对比），
   并接入 Nmap/Nuclei 等工具（严格参数数组 + 模板白名单 + 目标校验）。
7. **证据中心增强**：证据去重/聚类、发现聚合视图、跨任务检索、SARIF/JSON 导出（已支持）与
   报告重生成（不伪造历史）。
8. **解析深度**：.NET 元数据、Go/Rust 符号、APK v4 签名、DEX 方法级引用、PCAP 分片重组、TLS 证书链解析、
   YARA 规则文件加载（用户提供）。
9. **SBOM/依赖数据库**：接入 OSV/NVD 离线数据（用户自行提供）后才输出 CVE 结论；在此之前保持"盘点 + 启发式"。

## R3

10. **报告产品化**：模板化（执行摘要/技术报告/复测报告）、多语言、风险矩阵、修复优先级、复测对比。
11. **团队与审计**：多角色审批记录（operator 身份）、导出审计链为可验证证据包、跨会话任务检索。
12. **性能**：大文件流式解析、并行独立能力（runner 并发上限 + 证据顺序保证）、结果缓存。
13. **跨平台**：macOS/Linux 真机验证；Windows 符号链接/junction 安全语义补全；路径规范化库替换自研实现。

## 明确的非目标

- 不提供未经授权的攻击能力、凭据窃取、隐蔽持久化、恶意代码投递、破坏性入侵；
- 不把 L3 任何形式下放为可自动执行；
- 不伪造工具输出、测试结果或漏洞发现；缺失能力必须明示。
