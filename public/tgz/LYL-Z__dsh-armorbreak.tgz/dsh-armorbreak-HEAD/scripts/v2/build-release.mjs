#!/usr/bin/env node
/**
 * Deterministic candidate artifact builder:
 * sorted ustar entries, zero mtime/uid/gid, gzip, SHA-256, CycloneDX SBOM.
 * A test Ed25519 signature is generated to verify the mechanism; it is never
 * labelled a production signature.
 */
import { createHash, generateKeyPairSync } from 'node:crypto'
import { execFileSync, spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { basename, join, relative, resolve } from 'node:path'
import { gzipSync } from 'node:zlib'
import { fileURLToPath } from 'node:url'
import { signArtifact, verifyArtifactSignature } from './artifact-signature.mjs'

const root = resolve(fileURLToPath(new URL('../..', import.meta.url)))
const args = process.argv.slice(2)
const value = (name, fallback) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : fallback }
const outDir = resolve(value('--out', join(root, 'dist')))
const evidencePath = resolve(value('--evidence', join(root, 'docs/v2/acceptance/release-build.json')))
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
const commit = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim()

const EXCLUDE = new Set(['.git', 'node_modules', 'dist', '.armorbreak', '.github'])
const EXCLUDE_PATHS = new Set(['docs/v2/release/readiness.json', 'docs/v2/release/sbom.spdx.json'])
function files(current = root, prefix = '') {
  const out = []
  for (const entry of readdirSync(current, { withFileTypes: true })) {
    if (EXCLUDE.has(entry.name)) continue
    const full = join(current, entry.name)
    const rel = prefix ? `${prefix}/${entry.name}` : entry.name
    if (EXCLUDE_PATHS.has(rel) || rel.startsWith('docs/v2/acceptance/')) continue
    if (entry.isDirectory()) out.push(...files(full, rel))
    else if (entry.isFile()) out.push(rel)
  }
  return out
}

function octal(value, length) { return `${value.toString(8).padStart(length - 1, '0')}\0` }
function splitName(name) {
  const bytes = Buffer.byteLength(name)
  if (bytes <= 100) return { name, prefix: '' }
  for (let i = name.lastIndexOf('/'); i > 0; i -= 1) {
    const prefix = name.slice(0, i)
    const rest = name.slice(i + 1)
    if (Buffer.byteLength(prefix) <= 155 && Buffer.byteLength(rest) <= 100) return { name: rest, prefix }
  }
  throw new Error(`path too long for ustar: ${name}`)
}
function header(name, size, type = '0') {
  const split = splitName(name)
  const block = Buffer.alloc(512, 0)
  block.write(split.name, 0, 100, 'utf8')
  block.write(octal(0o644, 8), 100, 8, 'ascii')
  block.write(octal(0, 8), 108, 8, 'ascii')
  block.write(octal(0, 8), 116, 8, 'ascii')
  block.write(octal(size, 12), 124, 12, 'ascii')
  block.write(octal(0, 12), 136, 12, 'ascii')
  block.write('        ', 148, 8, 'ascii')
  block.write(type, 156, 1, 'ascii')
  block.write('ustar\0', 257, 6, 'ascii')
  block.write('00', 263, 2, 'ascii')
  block.write('root', 265, 32, 'ascii')
  block.write('root', 297, 32, 'ascii')
  if (split.prefix) block.write(split.prefix, 345, 155, 'utf8')
  let sum = 0
  for (const byte of block) sum += byte
  block.write(`${sum.toString(8).padStart(6, '0')}\0 `, 148, 8, 'ascii')
  return block
}
function tar(paths) {
  const chunks = []
  for (const rel of paths.sort()) {
    const full = join(root, rel)
    const body = readFileSync(full)
    chunks.push(header(rel, body.length), body)
    const pad = (512 - (body.length % 512)) % 512
    if (pad) chunks.push(Buffer.alloc(pad))
  }
  chunks.push(Buffer.alloc(1024))
  return Buffer.concat(chunks)
}

function buildOnce(name) {
  const paths = files().filter((path) => !path.startsWith('docs/v2/acceptance/') && !path.endsWith('release-build.json'))
  const archive = gzipSync(tar(paths), { level: 9 })
  const target = join(outDir, name)
  writeFileSync(target, archive)
  return { target, sha256: createHash('sha256').update(archive).digest('hex'), bytes: archive.length, paths }
}

mkdirSync(outDir, { recursive: true })
const name = `armorbreak-portable-${pkg.version}.tar.gz`
const first = buildOnce(name)
const second = buildOnce(`${name}.reproduce`)
const reproducible = first.sha256 === second.sha256
if (!reproducible) console.error(`reproducibility mismatch: ${first.sha256} != ${second.sha256}`)
const sbomPath = join(outDir, `${name}.sbom.cdx.json`)
const sbom = {
  bomFormat: 'CycloneDX', specVersion: '1.5', version: 1,
  metadata: { component: { type: 'application', name: pkg.name, version: pkg.version, hashes: [{ alg: 'SHA-256', content: first.sha256 }] } },
  components: ['protocol', 'core', 'engine-node', 'mcp-server', 'cli', 'installer', 'provider-router', 'adapter-dsh', 'skill-router', 'sdk-ts', 'core-daemon', 'migration'].map((name) => ({ type: 'library', name: `@armorbreak/${name}`, version: pkg.version })),
}
writeFileSync(sbomPath, `${JSON.stringify(sbom, null, 2)}\n`)
const { privateKey, publicKey } = generateKeyPairSync('ed25519')
const signature = await signArtifact(first.target, privateKey.export({ type: 'pkcs8', format: 'pem' }))
const signatureValid = await verifyArtifactSignature(first.target, signature.signature, publicKey.export({ type: 'spki', format: 'pem' }))
const cleanDir = mkdtempSync(join(tmpdir(), 'abm-cleanroom-'))
let cleanRoom
try {
  execFileSync('tar', ['-xzf', first.target, '-C', cleanDir], { stdio: 'pipe' })
  const cli = spawnSync(process.execPath, ['packages/cli/index.js', 'capabilities', '--json'], {
    cwd: cleanDir,
    env: { ...process.env, ARMORBREAK_STATE_ROOT: join(cleanDir, '.state'), ARMORBREAK_WORKSPACE: cleanDir },
    encoding: 'utf8', timeout: 120_000,
  })
  const capabilities = cli.status === 0 ? JSON.parse(cli.stdout).length : 0
  cleanRoom = { extracted: true, cliCapabilities: capabilities, result: capabilities === 46 ? 'PASS' : 'FAIL', stderr: String(cli.stderr ?? '').slice(0, 1000) }
} catch (error) {
  cleanRoom = { extracted: false, cliCapabilities: 0, result: 'FAIL', error: String(error.message) }
} finally {
  rmSync(cleanDir, { recursive: true, force: true })
}
const manifest = {
  schemaVersion: 'armorbreak.release-build/v1', generatedAt: new Date().toISOString(), commit, package: pkg.name, version: pkg.version,
  artifact: basename(first.target), bytes: first.bytes, sha256: first.sha256, reproducible,
  sbom: basename(sbomPath), sbomSha256: createHash('sha256').update(readFileSync(sbomPath)).digest('hex'),
  files: first.paths.length, cleanRoom, signature: { algorithm: 'ed25519', testKey: true, valid: signatureValid, signature: signature.signature, publicKey: publicKey.export({ type: 'spki', format: 'pem' }) },
  productionSigned: false,
  limitations: ['Test Ed25519 key verifies the signing mechanism; it is not a production identity.', 'Docker/npm publish not performed by this builder.'],
}
writeFileSync(join(outDir, `${name}.manifest.json`), `${JSON.stringify(manifest, null, 2)}\n`)
mkdirSync(resolve(evidencePath, '..'), { recursive: true })
writeFileSync(evidencePath, `${JSON.stringify(manifest, null, 2)}\n`)
if (!process.argv.includes('--no-portable-evidence')) writeFileSync(join(root, 'docs/v2/acceptance/portable-artifact.json'), `${JSON.stringify({
  schemaVersion: 'armorbreak.portable-artifact/v1', generatedAt: manifest.generatedAt, sourceCommit: commit, version: pkg.version,
  artifact: basename(first.target), bytes: first.bytes, sha256: first.sha256, sbom: basename(sbomPath),
  cleanRoom, signed: false,
  limitations: ['Test Ed25519 signature only; no production identity.', 'Docker/npm publish not performed.'],
}, null, 2)}\n`)
console.log(JSON.stringify({ artifact: first.target, sha256: first.sha256, reproducible, signatureValid, sbom: sbomPath, manifest: join(outDir, `${name}.manifest.json`), evidence: evidencePath }, null, 2))
if (!reproducible || !signatureValid) process.exitCode = 1
