# 客户端控件支持状态与基础滚动

上级：[Studio](../README.md#专题树)。范围是当前源码中的编辑、Lua运行时和Web/DSH/PNG试玩；“可用”不代表真机已验证。11类控件均可创建、配置公共变换、保存JSON，并按已知子集交换GIA。编辑器可创建、Lua字段可写和试玩有效是不同层次。

## 支持矩阵

| 控件 | 当前可用 | 主要缺口 |
|---|---|---|
| 容器节点 | 层级、锚点、位置/缩放/XYZ 旋转投影、显隐/激活、脚本挂载、子控件查询、动态实例与 sibling 排序；`showCursor` 参与光标回调门控。新建容器默认打开常驻光标（模拟器策略；官方字段表默认关）。GIA/JSON 导入和显式 `false` 保持原值 | 导航隔离、按键/点击穿透屏蔽字段可保存/读写，但没有完整对应行为；手柄导航不完整 |
| 文本框 | 文本、字号/颜色/背景/描边、横纵对齐、整行容纳裁切、Lua 更新；字号自适应、最小字号及统一换行；Unity 基础富文本 `b/i/size/color`，编辑预览/PNG/Pixi 共用排版 | 富文本仅支持下述子集；字体度量、整行容纳、混合字号与自适应细节为模拟器策略 |
| 图片 | 100001–100006 六类代理图元、白名单图片素材、颜色/透明度、独立宽高拉伸、XYZ 旋转投影与背面镜像、水平/垂直进度填充；矩形遮罩裁切后代，像素羽化从矩形边缘向内 | 径向填充、遮罩反转、纹理轮廓取形未实现；未知素材显示缺失框。羽化曲线、百分比模式和范围字段是下方模拟器策略 |
| 预设按钮 | 默认、悬停、按下、不可用四态，可共用直接子控件；射线/交互开关；光标事件与按键监听 | 深色按钮本体为模拟器占位，不导出为原生皮肤；完整手柄导航与焦点外观未实现 |
| 光标检测区域 | 射线命中、进入/离开、按下/抬起/点击、拖拽生命周期、坐标/位移；祖先 `showCursor` 门控 | 单活动指针策略，未完整模拟多点触控；与真机的复杂穿透规则不完全一致 |
| 文本视窗 | 文本显示、基础富文本、字号自适应、统一分行、纵向滚轮/拖动/触摸、滚动条轨道点击和滑块拖动、边界限制、内容变更后重算、PNG/Pixi 输出 | 无惯性/回弹、无手柄滚动；交互/滚动条开关 GIA 映射未核实 |
| 网格视窗 | `RefreshItems` 模板项实例化与复用；横纵向排列、AutoWrap/Fixed；滚轮/拖拽/触摸/滚动条；裁切与命中；`scrollProgress`（含 Tween）、`ScrollToItemAt`、数量/尺寸/间隔/边距/内容长度查询 | 完整实例化，未做虚拟列表；单次最多 2000 项；惯性/回弹/手柄滚动未实现；部分 GIA 配置未映射；布局、索引等采取下述模拟器策略 |
| 模板引用控件 | 公共变换、旧文本形式引用索引保存与读回；非 UTF-8 引用配置按原始字节导入/保存/导出 | 非空原生引用的目标编码尚未确认，不会自动展开目标模板；不透明配置保留时禁止改写目标索引。显式 `game.InstantiateClientUIControl` 是另一条已支持能力 |
| 按键提示 | 公共变换、键鼠/手柄按键字段 | 试玩未绘制按键图标，也不随输入设备自动切换提示 |
| 界面动效 | 素材选择、浏览器 C/T 合成、独立实例、动效/音效/全局层级字段；`PlayAnimation` 重播、`StopAnimation` 清除；按需缓存、失败隔离 | Host PNG 省略视频帧并给出 assetWarnings；非空 GIA 配置待核实；时序/声音/原生尺寸采用[预览策略](ui-vfx-playback.md) |
| 全屏动效 | 素材选择、浏览器全屏 cover 播放、固定控件下层、动效索引/音效字段；共用缓存与故障隔离 | 同上；无专属 Play/Stop Lua API，cover 与自动开始是预览策略 |

公共能力也有保真边界：显示布局是平面投影仿真，混合轴、父子均带倾转的通用三维层级仍采用下述策略；手柄配置存取不代表导航事件/最近邻寻路已实现。字段可写但效果未实现的情况，应以上表和对应渲染实现为准。

## 预设按钮四态与占位外观（2026-11-02）

- 四态依次是默认／悬停／按下／不可用，Authoring 字段为 `defaultChildId/hoverChildId/pressedChildId/unavailableChildId`，GIA `ButtonPresetConfig` 对应 `501/502/503/504`。不可用优先于按下、悬停，空闲回默认；点击不会留下独立的“选中态”。Lua 的 `interactable` 变化在下一次输出或命中前刷新状态。
- 每态绑定一个直接子控件，四态可以共用节点。先选出当前状态的目标，再对去重后的节点更新显隐；未被任何状态引用的装饰子控件不受四态管理。没有绑定的状态不借用其他槽。
- 本体保留模拟器占位，编辑器、PNG、Pixi 统一使用 `#202020` 深灰黑底，保留按下压暗；辅助边框、编辑标签和底色不写入 GIA，也不作为真机默认皮肤的证明。实际样式由状态子控件提供，整体色差未由此关闭。
- 本次不做旧 JSON 自动迁移：`selectedChildId` 不再读取／写入／接受 patch，默认态需重新绑定；已有 `unavailableChildId` 保持不可用语义，但导出改写正确的504槽。旧 GIA 按实际 wire 槽位读取，不能再沿用旧模拟器的错误标签。

证据：用户在本次会话提供的模拟器／设备编辑器对照截图（原件待补，客户端版本和平台未知）显示旧首槽引用进入设备“默认”、旧末槽进入“不可用”；中间悬停、按下不变。完整工作区的官方预设按钮说明本地快照（2026-10-24，页面 `mhdbkf04v6y8` §三.1）同样列默认／悬停／按下／不可用。旧同节点填满四槽的样本不足以证明首尾语义，相关知识定义已更正。截图是 `observed / device`（限配置显示），字段映射综合判断为 `inferred`；修复包运行切换及原生重导出仍 `device_status=pending`。

自包含回归：`test/gia-observed-fields.test.mjs` 独立手写 wire 验证导入及服务端／客户端／整合导出四个不同节点，避免仅用同一codec往返自证；`test/layout.test.mjs` 覆盖默认返回、禁用优先、各共用组合、空槽、Lua切换及销毁登记清理；`test/pixi-cache.test.mjs` 验证占位色的实际Pixi图形及编辑／试玩PNG像素。Windows / Node22 / Pixi8.20 专项和全仓 `pnpm test`（含Edge浏览器回归）通过；未配置Electron及Windows符号链接用例跳过。测试结果仅为 `observed / simulator`。

## 基础富文本（2026-10-20）

文本框和文本视窗的 `text` 现在自动解析以下 Unity legacy UI 富文本子集，无需新增开关：

| 语法 | 效果 |
|---|---|
| `<b>粗体</b>`、`<i>斜体</i>` | 可互相嵌套，也可重复嵌套同种标签；闭合后恢复外层样式 |
| `<size=12>小字</size>` | 正整数、绝对 UI 像素字号；支持带引号的参数 |
| `<color=red>红字</color>` | Unity 文档列出的 22 个颜色名（含别名）；`green=#008000`、`lime=#00ff00` |
| `<color=#FF0000>红字</color>` | 六位 RGB，不透明 |
| `<color=#FF000080>半透明红字</color>` | 八位 **RGBA**，最后两位是 Alpha；与控件内部 ARGB 数值顺序不同 |

例如：`普通 <color=red><b>红色粗体</b></color> <i>斜体</i> <size=12>小字</size>`。标签名和颜色名大小写不敏感，参数可用单/双引号包裹，等号周围不接受空格。未知标签、无效参数、未闭合及交叉闭合的未配对标签保留为字面文字；合法的内层配对仍可生效。不是 HTML 解释器，不解析实体、不创建 DOM 标签。`u`、`s`、`br`、`material`、`quad`、TMP 扩展及相对/百分比字号不在支持范围；换行使用实际换行符。

### 排版、渲染与保留策略

- `play/rich-text.js` 解析配对标签和样式栈，`play/text-layout.js` 按样式测量并输出分行/分段。有效标签不占宽度；关闭标签后恢复控件默认或外层颜色/字号。运行时、JSON 和 GIA 始终保留原始 `text`，不把解析后的文字写回存档。
- 混合字号逐行取最大字号 ×1.2 为行高，共用字母基线；文本框额外容纳余量按全文最大显示字号 ×0.25+4 计算。自适应只调整未指定 `<size>` 的基础字号，显式字号保持绝对值；到最小字号仍溢出时，文本框仅绘制能完整容纳的前缀行（见下方整行可见性），文本视窗滚动。逐字符换行、样式段之间的字偶距、混合字号基线和拟合均是模拟器策略。
- `play/rich-text-paint.js` 为编辑器 Canvas、PNG 和 Pixi 共用绘制代码，保留对齐、描边、视窗裁切、滚动及本地字体。富文本视窗按实际变高行块计算滚动长度，只栅格化可见视窗。
- Pixi 富文本每个控件持有一张自有 Canvas 纹理，同尺寸文字/样式更新原位重绘并上传；普通/富文本切换、尺寸变化与销毁释放自有纹理。单边上限4096像素，超大控件等比降低栅格分辨率，不按全文高度分配纹理。普通文本继续使用既有 Pixi Text 更新/缓存路径。

### 来源与验证

- 语法来源：2026-10-20 在线读取 [Unity 2018.4 Manual / Rich Text](https://docs.unity3d.com/2018.4/Documentation/Manual/StyledText.html)，`evidence_source=documented`、运行端 `official_document`，来源明确为 **Unity** 文档。千星本地 Lua API 仅声明文本控件的 `text/fontSize/fontColor` 等字段，没有富文本语法契约；不能据原神使用 Unity 推定其全部文本组件行为。
- 最小复现：`<color=red>红字</color> <i>斜体</i> <size=12>小字</size>`，旧实现显示完整标签并将标签计入换行；现显示样式化正文。千星实机具体兼容范围、混合字号/自适应、异常标签处理及精确字形仍 `device_status=pending`。
- 回归：`test/rich-text.test.mjs` 覆盖独立文档颜色值、嵌套恢复、异常标签、标签不占宽度、字号拟合边界、九种对齐/基线/描边、PNG 颜色与 Alpha、树形/扁平一致、实际 Lua 增量、变高行滚动、JSON/GIA 字符串保留、Pixi 纹理复用和释放。`web/test/rich-text-browser.test.mjs` 覆盖真实编辑器 Canvas、WebGL 颜色/Alpha、扁平回退、200次更新实际上传和资源释放；已有字体与普通文字缓存浏览器用例继续验证回归。
- 验证环境：Windows / Node22.23.2 / Pixi8.20 / Edge headless + SwiftShader，上述回归及系统字体为空的回退通过；`observed / simulator`。

源码更新后须构建并重启旧 Web/MCP/DSH 宿主、刷新页面，才能加载新渲染器。本节只描述模拟器能力，验证结果为 `observed / simulator`。

## 模板引用 GIA 导入（2026-10-18）

反馈称带模板引用控件的 GIA 导入异常，尚未收到该文件或原始报错。已有原生 `client_list.json` / `server_container.json` 只覆盖空引用槽；官方教程第三方抓取副本（2026-09-25）说明引用控件应预览被引用模板，但未说明 GIA wire 编码。不能从空槽推断非空目标 GUID 的布局。

本轮在 Windows / Node.js 22.23.2 / protobufjs 8.7.2，用独立合成 wire 确认以下实现缺陷（`evidence_source=observed`，运行端 `simulator`；反馈原包根因仍为 `unknown`）：

1. 旧 `Details.templateRefSlot` / `Data.empty76` 声明为 string，非 UTF-8 wt2 负载会在 protobuf 解码阶段报 `The encoded data was not valid for encoding utf-8`。现按 bytes 解码；非文本内层配置与非空外层槽以 Base64 放入 `giaRaw`，经 JSON 重载和 GIA 重导出保持原字节。已有空槽及模拟器旧纯文本引用继续兼容。
2. `Root.accessories` 中脚本等依赖曾被全当成客户端控件，报“GIA 控件 … 缺少多平台变换”。现仅把已识别 UI 单元送入布局，脚本映射从主图与附件提取，其他未支持依赖显示丢失范围警告。
3. 客户端独立模板的脚本挂载曾硬编码为服务端资产，并在新控件树写入前校验而被清空；现按实际资产类型、在新树就绪后恢复挂载。

保留策略不等于完整支持：原生非空绑定仍未解码，运行时不自动展开目标模板；不透明引用中可能嵌有资产索引，当前不会猜测重写。普通名称/布局编辑允许，改写此类目标索引明确拒绝以免静默丢配置。该修复不保证所有未知资产往返，也没有验证原生编辑器重新导入，`device_status=pending`。

自包含回归 `studio/test/gia-reference.test.mjs` 覆盖二进制内外槽、空/旧文本槽、JSON与GIA字节保留、编辑拒绝原子性、非UI依赖、脚本附件挂载及坏UI仍报错。合成数据不作为非空原生字段结构的证据。收到问题原包后再核对实际失败路径与目标模板引用格式。

本地两份原生空引用模板可导入；反馈者原包和真机回导未验证。

### pixel-link 整合包静态排查（2026-10-29）

用户报告 `pixel-link.save.json` 导出的整合包无法被真机沙箱正常识别，原失败 GIA、报错及客户端版本未提供（`provided_unverified / device / failed`）。输入身份及本地审计见完整工作区 `probes/pixel-link-gia-20261029/audit.json`。未改导出器或原 JSON；在独立 Web 编辑会话复现，不切换现有预览。

`observed / simulator / not_required`：当前源码与 Web `0.5.1-local.20261026.t022835` 均把服务端「模板引用控件」GUID `1073741879` 的 `giaRaw.templateRefSlot="1073741845"` 按 UTF-8 写入 `Data[66/89].Details.template_ref_slot(77)`，原字节 `31303733373431383435`（10 字节）。该文本不是已知原生绑定格式；若按嵌套 protobuf 读取，前9字节成为 field6/fixed64，最后字节 `0x35` 声明 field6/fixed32 却没有余下4字节，独立严格扫描和 protobufjs Reader 均报越界。**这证明它不是完整的嵌套 protobuf 消息，不证明原生槽必定采用该消息类型**；非空原生样本仍缺，真机拒绝根因保持 `inferred / device / pending`。

现有 `bytes` 声明只保证字节保留。`validateServerGiaCompatibility` / `validateGiaCompatibility` 没有检查这个槽的内部，因此当前兼容性校验通过不能证明原生引用有效；普通文本往返测试也不构成真机证据。独立 `knowledge/ui/gia.proto` 审计23个单元、1619条消息、4267个字段未发现外层 wire/oneof/UTF-8/非有限浮点异常；信封、GUID自身引用、父子关系、四平台及客户端资产编号亦未发现异常。

已从运行中 Web 的16722字节基线制作16712字节对照包：只清空该字段、重算其祖先及信封长度，其余字节保持；GUID和Info编号不重排。对照不再绑定目标模板，**只用于测试能否识别，不是游戏修复**，真机待验。输入还只有一条空源码映射 `workspace/pixel-link/ui_main.lua`，当前工作区无该文件；这是独立的运行内容缺失，空脚本映射本身并非已证实非法。输入已有索引待核对账本仍保留，不猜测更新缺失源码。

后续用户明确“文本是索引核对那步改的，改回去再把源码补充完之后重新导出还是无法识别”（`provided_unverified / device / failed`）。因此不能把十进制引用或缺源码当作已确认根因，不要求重复该失败修正。随后找到同时间的原始 `Downloads/整合包.gia`，16722字节，SHA256 `4c937ad63ee2ded72b8d1c17624a715e3c552631f13e3e777ffbd14dfbc575ea`，仍含旧文本和空源码；恢复后的新失败包不在当前提供的文件中。已知通过的WOO整合包哈希匹配，亦含混合Root.graph、空Info.related及目录式Lua路径，故不将这些特征一概判非法。

用户请求直接修改JSON后，另存 `pixel-link.import-candidate.save.json` 及配套GIA：仅将未知引用控件换成保留身份/几何的普通容器，并嵌入明确标注的最小启动/点击检查脚本，用已文档化API实例化原目标。原GUID及Info.index不变，不捏造原生绑定格式或缺失玩法源码。PC/手机坐标点击、MCP Worker、当前Web导入再导出及独立schema检查通过（`observed / simulator`）；真机`pending`，该候选**不是三关玩法恢复或已确认修复**。输出身份及限制见上述audit的candidate段。

## 字号自适应（2026-10-14）

修复前 `adaptiveFontSize` / `minimumFontSize` 可编辑、保存及由 Lua 读写，客户端 GIA 的 `TextConfig(75).adaptive(502)` 编解码也正确，但 scene/paint 未投影这两个字段，PNG/Pixi 始终按配置字号绘制。两行文字、40px 字号、最小 10px、160×40 文本框可复现裁切；此前“自适应未实现”的状态由本节替代。

- `play/text-layout.js` 在本地尺寸中测量并缓存分行；编辑布局、试玩 PNG/扁平 paint/Pixi 共用最终字号和显式行列表。开关、最小字号、文本、尺寸变化均重算并进入增量更新；缩放/XYZ 投影在排版之后应用。Lua `fontSize` 和保存配置保持请求值，不被实际显示字号覆盖。编辑预览将同一结果按画布缩放显示。
- **模拟器策略**：字符边界换行，左右各 2 UI 单位留白，行高为字号的 1.2 倍；文本框按下节另计块占位，自适应在 `[min(最小字号, 配置字号), 配置字号]` 中选能容纳全部行的最大正整数字号；到下限仍溢出时，文本框仅绘制能完整容纳的前缀行、文本视窗继续滚动。固定字号不缩小，原有 8px 显示下限移除。文本视窗先尝试适配，无空间时为滚动条保留宽度。字体使用宿主配置或本机回退字体，官方精确换行/小数字号拟合及抗锯齿未还原；2026-10-20 新增的基础富文本与混合字号规则见上节。
- API 依据为完整知识工作区本地 `Lua客户端UI脚本API.md` 的 `adaptiveFontSize:boolean` 与 `minimumFontSize:integer`（documented / official_document，本轮未在线核验）；上述拟合算法是模拟器策略，`device_status=pending`，不能由字段名或 PNG 推断真机精确算法。
- GIA 必须按消息类型区分：本项目客户端 `TextConfig(75)` 的自适应为 `502`、描边关闭为 `506`；图片编辑器素材组使用的旧 `TextBox(19)` 才是 `506` 自适应。旧消息的 `503=1` 仍含义未知，不映射为 visible，也不替换新版 `TextConfig.field503=12`。旧素材组 GIA 的完整语义导入不在本次渲染修复范围。
- 自包含回归：`test/text-autosize.test.mjs` 以两行 ×1.2 行高加文本框块占位给出最大字号 13 的独立期望（文本视窗仍为16），覆盖实际 Lua 更新、开关/下限、尺寸、滚动、宽度、中文、换行、投影隔离、PNG 和真实 Pixi 对象；`test/gia-observed-fields.test.mjs` 固定新版原生观察字节，防止套用旧字段号。浏览器字号增量验证合并到 `web/test/local-font.test.mjs`，共用真实字体加载、编辑文字 span 和 WebGL 渲染链路，避免维护第二套临时服务器与打包器。测试属于 observed / simulator，不增加真机渲染证据。

### #19 选取字号占位模型（2026-10-18）

用户要求选取 [PR #19](https://github.com/1475505/miliastra-beyond-simulator/pull/19) 中的字号像素占位与自适应部分。来源为作者 `a85dbd1` 的测量报告：字号16/高26放不下一行、16/28可放一行、16/46放不下两行、16/47可放两行、20/56放不下两行、20/57可放两行。报告称 PC UI 缩放1.2，具体客户端版本及原始工程/截图未在本轮取得；`evidence_source=provided_unverified`、运行端 `device`、`device_status=pending`。本文将其作为用户采纳的模拟器拟合模型，不宣布为官方跨字体契约。

- 文本框排版需求：`requiredHeight = 行数 × 字号 × 1.2 + 字号 × 0.25 + 4`。空文本不占高度；`contentHeight` 仍仅是行块高度，`blockInset` 是容纳判定余量，不猜测它如何分配为上下 padding。
- 文本视窗不加该余量，维持自身滚动和可见行策略。未采用 PR 的全局10px字号下限、文本框/视窗共用隐藏门槛、滚动边缘整行跳隐；也不将其两套渲染端裁行逻辑复制进来。
- 宽度用 #20 加载的实际字体 `measureText` 测量，自动换行也参与每个候选字号的高度检查。自适应以二分搜索挑能完整容纳的最大整数字号，低于配置最小字号仍放不下时停在最小字号。Lua/JSON 中请求字号不变。
- 例如160×40、两行、配置40、最小10：字号13需要38.45 UI像素，字号14需要41.1，故选择13。宽度/字号的单位为缩放前画布本地像素；实际屏幕像素随后受画布缩放和父级变换影响，字形着色像素范围还取决于字体，不能把 fontSize 当作每个字的固定宽高。
- 精简验证沿用现有 `text-autosize`、`local-font` 和浏览器字体用例，只加一组独立边界表，避免维护 PR 中重复常量/公式断言及另一套浏览器排版链路。

### 文本框整行可见性（#22 C，2026-10-20）

[#22 C](https://github.com/1475505/miliastra-beyond-simulator/issues/22) 再次报告“模拟器有字、真机无字”。维护者要求摘取相关 PR 的适用测试修复；对应的缺字/裁行报告实际位于 [#19 原始提交 `a85dbd1`](https://github.com/1475505/miliastra-beyond-simulator/blob/a85dbd1747a4eed159056c04c049ab30b5cbf269/studio/test/textbox-min-height.test.mjs)，#15 的8项测试主要针对字号收缩和下限。此前只将占位用于自适应选字号，固定字号或达到最小字号后仍按矩形裁切字形，因此同一高度可能显示真机报告中不绘制的文字。

- **采纳规则**：完成字体测量、换行与自适应后，文本框保留从首行开始能完整容纳的最长前缀。等字号时为 `min(实际行数, max(0, floor((框高 - (0.25×最终字号 + 4)) / (1.2×最终字号))))`；边界容许浮点误差。一行也放不下时文字和描边都不绘制，底色仍绘制。先裁行再对齐保留的行块，不把后三行反向显示出来。
- **共享结果**：`play/text-layout.js` 输出 `visibleLineCount`、`visibleContentHeight`；原有 `lines/richLines/contentHeight/requiredHeight/fits` 保留全文排版信息。DOM 编辑预览、编辑/试玩 PNG、扁平 paint、Pixi 共用这两个字段。字号、文本、框大小变化重算，Lua `text/fontSize`、控件显隐、JSON/GIA 均不被裁行结果覆盖。外部缩放/旋转在本地容纳判定之后应用。
- **富文本策略**：累计已测量的变高行块，沿用全文最大显示字号的块占位；显式 `<size>` 不随基础字号缩小。该扩展没有原始真机卡片依据，属于 `inferred / simulator`，`device_status=pending`。
- **范围**：只摘取文本框完整行的容纳行为。没有引入全局10px字号下限或“字号<16就隐藏”；文本视窗保留完整内容、连续滚动与边缘裁切。上一节“只用于字号拟合”的范围由本节扩展，文本视窗策略不变。
- **证据边界**：作者报告的 PC/UI缩放1.2 条件、字号10/16/20/24/40/60边界表仍为 `provided_unverified / device`、`device_status=pending`，具体客户端版本、字体和原始卡片待补。本轮最小模拟器观察：字号16/框高26，旧版 `fits=false` 仍有字形，修复后只有底色；高28恢复一行、高47显示两行。不能据此关闭 #22 原工程的所有缺字原因。
- **长期回归**：合并进已有 `test/text-autosize.test.mjs`，保留独立边界、PNG底色/描边及保留行块对齐、编辑预览文本、Lua大小/字号增量；`web/test/local-font.test.mjs` 保留自适应切换时GPU旧字形清除和恢复。完整测量扫描、三种对齐×富文本的重复组合、浏览器逐高度行带扫描已验收后删除，不长期维护第二套测试夹具。
- **本地验证**：Windows / Node22.23.2 / Pixi8.20 / Edge headless + SwiftShader；独立边界先在旧实现失败，修复后文本和浏览器字体/裁行回归通过。`observed / simulator`，不增加真机通过结论。

## X/Y 旋转投影（2026-10-12）

右侧「变换」可编辑旋转 X/Y/Z，MCP/Controller `set` 支持 `rotationX`、`rotationY`、`rotationZ`，沿用四平台同步开关。JSON 保留三轴；GIA `RectTransform.field508` 的 float field 1/2/3 对应 X/Y/Z，导入导出均保留，零分量继续省略、零向量保留空 message。Lua 方法、字段与 Tween 更新共同进入同一变换链。

单轴依据是 ROTXY-20261011-v2 的 PC 真机截图和 126 条采样（完整知识工作区 `knowledge/fact.md` / `probes/image-rotation-xy-20261011/device-20261011.md`）：矩形图片 X 沿高度压缩/翻面，Y 沿宽度压缩/翻面；90° 侧立无面、120/180° 背面可见，子角标继承，GIA/方法/字段一致。实际客户端版本未提供；不将生成包的 7.1.0 当客户端版本。

- `ui/layout.js` 在轴心处计算正交投影矩阵，极小值归零保证 90° 真正退化。负行列分量保留，不能用正宽高替代镜像。
- DOM 编辑器、编辑 PNG、试玩 PNG/扁平 paint、Pixi WebGL 共用完整矩阵；图片先按本地大小切片/绘制再应用投影。显示更新继续走原场景增量机制。点击选择使用同一逆矩阵，侧立时不命中，可从树选择后修改角度。
- **组合策略**：沿用 Runtime 欧拉角读回的 Z-X-Y 约定，局部按 `Ry * Rx * Rz` 投影，然后在二维层级中组合。它保证 `(120,0,0)` 与真机等价读回 `(60,180,180)` 显示相同；混合轴顺序、父子同时倾转时的深度耦合、非图片控件、命中/裁切没有本次真机依据。当前不保留 Z 深度、透视或深度排序；父子均旋转时不是完整三维场景。
- 长期回归：`test/rotation-xy.test.mjs`（配置/同步/JSON、轴心、PNG、角标、等价角、增量、选择、Pixi 矩阵），`test/gia-observed-fields.test.mjs`（独立 wire 字节）。一次性浏览器验收覆盖真实 WebGL 0/30/60/90/120/180→0 增量和 DOM 镜像，验收后脚本已清理。

构建 `pnpm build` 后，重启旧 Web/MCP/DSH 宿主并刷新页面才能加载新实现。上述实现与回归属于 `observed / simulator`；只将真机已覆盖的单轴图片行为标为 `device_status=passed`。

2026-10-12 Windows / Node22.23.2 / Edge headless + SwiftShader验收三轴DOM/WebGL显示；外部ROTXY2 GIA独立复核的126次采样与真机转录一致，原包与源码哈希不变。外部复核不作为仓库测试依赖。

## 命中转发：祖先矩形只在视口处裁切（2026-11-04）

4ASCEND 主菜单的「退出」按钮真机可点、模拟器点不中：按钮热区挂在一个左上角 `0×0` 的容器（`退出层`）下，热区完整画在父矩形之外。旧实现在递归子节点之前先用控件自己的布局矩形做门槛（`local` 不在 `box` 内就返回），父容器是点，子节点根本没被测试；画面不裁切，所以按钮看得见却点不到。

现策略：布局宿主（容器、按钮、网格、文本视窗、模板引用）即使指针在自己矩形外，也继续把指针交给子节点；控件**自己**是否被接受仍要求指针落在自己矩形内。滚动视口（网格、文本视窗）是蒙版语义，继续按自身矩形裁切内容——`test/scroll.test.mjs` 的「视窗外不可点」依赖这一点。

- 依据：UGUI 的 `GraphicRaycaster` 对每个 `raycastTarget` 图元单独测自身矩形，祖先矩形不参与后代判定；只有 `RectMask2D`/`Mask` 之类的蒙版才裁后代。真机侧目前只有“该按钮能点”这一条用户观察，无坐标与对照用例，`device_status=pending`。
- 未覆盖：遮罩是否改变点击命中（MASK v1 未测）、旋转父级下的命中、`disableCursorEventPassthrough` 与几何裁切的关系。这些保持旧行为，不随本条一起改。
- 回归：`test/layout.test.mjs` 的「零尺寸锚点容器把指针转交给溢出子节点」用与 4ASCEND 相同的 `0×0` 容器 + `52×39` 热区形状断言坐标点击可触发，并断言远离热区仍为空；`scroll.test.mjs` 继续保证视口裁切。真实存档复现：手机 1280×720 下点击 `(39, 690)`，改前不弹窗、改后打开退出弹窗。
- 生效条件：改的是 `studio/play/session.js`，Host/试玩 Worker 跑的是安装后的 `dsh-plugin/dist`，需重新构建并重启 DSH 宿主后才在工具里生效。

## 基础矩形遮罩（2026-10-11）

MASK v1 的 PC 真机回传确认：`enableMask` 裁切图片的后代，不裁切兄弟；`imageColor` alpha=0 不取消遮罩。像素羽化从对应两边向内衰减，羽化宽度 0 仍是硬边。真机两组软边并非逐像素相同：不透明遮罩组有较亮条带，具体合成过程未确认，详见完整工作区 `knowledge/fact.md` 的 MASK v1 条目。

当前模拟器策略：矩形取形、线性羽化；按遮罩身份先合成整组（包括图片自身），再应用一次覆盖率，嵌套逐层相乘；遮罩宽高非正数为**空覆盖**，与关闭遮罩区分。百分比模式暂按边长换算宽度，范围字段不参与；这不是官方百分比公式。反转与按纹理透明轮廓取形未实现，点击命中仍用原布局矩形。

- PNG 与 Pixi 的树形及扁平回退使用相同分组边界，重叠子图不会叠加同一个遮罩的覆盖率；独立兄弟遮罩即使几何相同也分别合成。
- PNG 仅分配与画布相交的遮罩包围盒图层，按组读回合成，逆矩阵在组外计算；不再对每个小图元遍历整屏。1600×900、100 个 10×10 图元的一次本机截图从约 29.5 秒降至约 0.08 秒（非跨设备性能承诺）。
- Pixi 外层保留视窗裁切，内层执行图片遮罩；两者独立更新和释放。羽化宽度更新复用纹理，软遮罩纹理单边上限 2048，超大尺寸按纹理缩放显示。
- 回归入口：`test/image-mask.test.mjs` 使用手算像素期望，覆盖重叠/嵌套/兄弟/零尺寸/旋转/高 DPI、Lua 增量、视窗组合与资源回收；`web/test/image-mask-browser.test.mjs` 用同一小型合成夹具核对真实 WebGL 与 PNG，含扁平回退和增量更新。浏览器用例通过 `QXQY_BROWSER` 启用。

上述渲染一致性与性能检查为 `observed / simulator`，`device_status=not_required`；不升级为真机精确羽化曲线或合成顺序已还原。

验证环境：Windows / Node22.23.2 / Pixi8.20 / Canvas0.1.100 / Edge headless + SwiftShader；上述遮罩回归通过。

### 编辑画布遮罩与羽化（2026-10-20）

此前编辑页只能配置遮罩参数，DOM画布及编辑器PNG仍平铺所有控件。现 `ui/inspector.js` 为编辑盒附加祖先遮罩链与层级可见性，复用试玩的 `imageMaskSpec/groupMaskedPaint`；透明图片的遮罩、子孙裁切、嵌套、零尺寸和投影随布局一起更新。

- `editor-ui/mask-preview.js` 将同一遮罩下的DOM内容分组合成，再应用一次alpha遮罩；羽化使用已有 `paintMaskCanvas` 线性覆盖率，局部栅格单边上限2048。遮罩图像通过完整仿射矩阵映射到画布，控件仍沿用已有DOM文字/图片预览；改羽化宽度、开关或变换后直接更新。硬边使用矩形，百分比仍沿用试玩近似换算。
- 编辑器PNG复用试玩的裁剪包围盒分组合成。DOM选框/控制点与PNG选框最后单独绘制，不参与羽化，不因选中控件而把其图像提升层序。隐藏祖先或左树关闭画布可见性时，其后代不显示；遮罩范围外仍可通过控件树选取，编辑点击继续按布局矩形判断。
- 支持边界沿用上节：仅矩形取形，精确羽化曲线、范围字段、反转和图片透明轮廓未新增实现。编辑预览仍不执行Lua，不证明真机像素一致。
- 自包含关键回归扩充原有 `test/image-mask.test.mjs`、`web/test/image-mask-browser.test.mjs`，共用 `fixtures/image-mask.mjs`。PNG保留独立像素、祖先链、零宽/旋转和选框回归；浏览器用一个嵌套夹具核验实际分组合成、实时检视器提交、编辑选框及树可见性。重复的浏览器硬边/关闭/零宽/旋转逐项验收及整份存档切换已验证后清理。来源为 `observed / simulator`，`device_status=not_required`（编辑预览接通）；沿用的真机保真边界不升级。
- 验证：Windows / Node22.23.2 / Edge headless + SwiftShader的DOM/PNG和真实属性输入回归通过，重启宿主并刷新页面后生效。

## 基础滚动（2026-10-02）

### 使用

- **文本视窗**：在检视器填写超过视窗高度的文本，开启“允许滚动交互”，进入试玩后直接滚轮或拖动。隐藏滚动条仍可滚动。文本变短、字号或尺寸变化会重新测量并限制偏移。
- **网格视窗**：配置“列表项模板索引”、尺寸/间距/排列，在运行脚本中调用 `RefreshItems(itemCount, callback)`。编辑器“预览数量”不自动生成运行条目。只有 `RefreshItems` 管理的模板项随列表移动和裁切；静态子控件保持原位。
- **工具/回放**：沿用 `pointer`，新增 `type: "wheel"`，传 `x/y/deltaX/deltaY`。例如 `{"type":"wheel","x":600,"y":450,"deltaY":48}`。正 `deltaY` 往后滚动；横向列表优先使用 `deltaX`，没有横向量时使用 `deltaY`。`type: "cancel"` 结束当前指针事务，不产生点击。
- 编辑视图保持静态布局；滚动在试玩生效。运行偏移保存在各玩家的运行时控件上，停止/重开复位，不写回 Authoring JSON。

### 明确采用的模拟器策略

这些细节由本次“先基本可用”的需求授权，不宣称为官方行为：

1. 单活动鼠标/触点，无惯性、弹性或手柄滚动；`interactable=false` 禁止原生滚动；网格还检查 `raycastTarget`。滚动命中遵循当前显示树，遮挡在上的可交互控件不会把滚轮传给无亲缘关系的下层视窗。嵌套视窗取命中链中最近的可滚动祖先，不做到边缘后继续传递。
2. 滚动条为简单 8px 轨道、最短 18px 滑块；点击轨道把滑块中心定位到指针，拖动按轨道有效行程换算。浏览器像素/行/页滚轮单位转为画布单位，行按 16 CSS px、页按一视口。内容拖动按控件本地变换换算。
3. 文本在宿主端用本机字体测量、按字符换行，行高 `fontSize × 1.2`；溢出时从顶部开始滚动，内容不溢出时遵循垂直对齐。PNG/Pixi 使用同一份分行和偏移；Pixi 只绘制可见行附近的文字，避免长文本生成超大纹理。字体栅格仍可能不同。
4. 网格项索引 **0 起始**，非本列表项返回 `-1`；`scrollProgress` 限制在 `[0,1]`，0 为顶部/左侧，1 为底部/右侧。`ScrollToItemAt` 的 Top/Center/Bottom 在横向对应左/中/右。
5. 纵向按行填充，横向按列填充；AutoWrap 根据交叉轴空间计算项数；Fixed 使用 `layoutConstraintFixedCount`，最小 1。`padding1X/Y` 暂解释为左/上，`padding2X/Y` 为右/下；cell 最小 1，间距/边距最小 0。这一边距映射尚无真机证据。
6. `RefreshItems` 同步为全部项调用 `(control,index)` 回调，同模板项按索引复用，减少数量时销毁尾项，更换模板后重建；新项激活，模板脚本沿用已有实例化生命周期。没有可见区虚拟化，最多 2000 项；递归刷新同一网格、无效数量/模板明确报错。同步回调完成后释放自身引用。
7. 滚动过程中不额外触发列表项 Click；拖动由内建滚动消费，不同时派发列表项 Drag。滑块盖在列表项之上，输入和显示使用同一视窗裁切。

### API 依据与证据

- API 来源：完整知识工作区 `knowledge/guide/Lua客户端UI脚本API.md`，SHA256 `4A43F93F2B322BE8336FF33D9CB07B3BC3A8D4C8A931A45D18F90E4E64941BAB`，本地快照，未本轮在线核验。`ClientUITextWindowControl` 的 `interactable/showScrollBar`、网格字段及七个方法、`ScrollDirection/ScrollLayoutConstraint/ScrollAlignType` 为 documented / official_document；范围、索引起点、间距向量方向等未明之处见上方策略。
- 支持清单来自源码核对：Runtime `scene.js/runtime.js`、`studio/play/compile.js/session.js/pixi-renderer.js`、`studio/host-png.js`、`studio/ui/inspector.js`、`studio/gia/codec.js`；属于 observed / simulator，`device_status=not_required`（本次只验模拟器可用性）。官方还原程度未作验证。
- 修复前最小复现：160×80 文本视窗、字号 20、40 行文字、交互与滚动条均开启，按下→拖动 35→松开，命中/拖拽状态成立但 paint 与 PNG 完全不变；网格七方法直接抛 `not implemented`。当前相同输入改变内容偏移与画面。
- 自动回归：`studio/test/scroll.test.mjs` 使用手写几何期望（10 行 ×24 行高 −80=160 溢出、拖动 35=偏移 35；两列网格 5×30−80=70），覆盖边界、遮挡/缩放、显隐/禁用、取消、文本重排、Lua 回调/复用/定位/Tween/释放、PNG 与树形/扁平 Pixi 裁切、滚轮录制回放。`browser-session.test.mjs` 检查滚轮单位换算、多指过滤和取消；`gia-loss-warnings.test.mjs` 检查新增字段 JSON 往返和 GIA 损失提示。
- 浏览器证据：`web/test/scroll-browser.test.mjs`，Windows / Node 22.23.2 / Edge headless / SwiftShader / Pixi 8.20.0；真实浏览器鼠标滚轮、鼠标拖拽、滚动条点击、模拟触摸输入均到达 Worker 并移动两类视窗；GPU 截图检查网格内部固定色像素和视窗外裁切。单独设置 `QXQY_BROWSER` 后 2/2 通过；全仓默认测试会跳过需浏览器环境变量的用例。
- GIA：此次开放的视窗交互/滚动条、列表模板、方向/排列字段只保证 JSON/Lua。未核实 wire 映射不猜写；导出有对应改动时返回明确提示。已有已知尺寸/间距与文本字段继续沿用原编解码。

### 实现入口

| 路径 | 职责 |
|---|---|
| `client/lua-runtime/src/grid.js`、`scene.js`、`runtime.js` | 网格 API、条目生命周期、布局/进度与 Lua 参数桥接 |
| `studio/play/scroll.js`、`scroll-geometry.js` | 文本测量、滚动条和裁切几何 |
| `studio/play/session.js` | 输入仲裁、运行偏移、scene/paint、命中 |
| `studio/play/browser-session.js` | 滚轮/指针/取消与 CSS→画布坐标 |
| `studio/play/pixi-renderer.js`、`studio/host-png.js` | 内容偏移、滚动条和视窗裁切 |
| `studio/host/worker.js`、`studio/autotest/` | 输入透传、录制与确定性回放 |

源码更新后运行 `pnpm build`，并重启加载旧代码的 Web/MCP/Harness 宿主；已有浏览器页需刷新、重新开始试玩。只构建不会替运行中的进程重新加载模块。
