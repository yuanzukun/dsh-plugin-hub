# beyond-simulator-web

单用户自托管 Web 编辑器和磁盘存档预览，无需 Harness。复用共享 Studio、Lua Runtime、固定步长试玩 Worker、Pixi 渲染器及 `editor-ui` 编辑界面。

新手入门、日常操作与常见问题集中在[完整使用指南](../docs/user-guide.md)。本页维护 Web 接入和部署细节。

<a id="052-更新"></a>
公开发布说明见 [GitHub Releases](https://github.com/1475505/miliastra-beyond-simulator/releases)，本页维护当前使用与部署。更新或修改字体后，重启 Web 服务并刷新页面。

## 安装与启动

推荐 Node.js 22+。源码开发在仓库根执行：

```sh
pnpm install --frozen-lockfile
pnpm dev:web --workspace /absolute/path/to/workspace
```

从 npm 安装：

```sh
npm install -g beyond-simulator-web
beyond-simulator-web --workspace /absolute/path/to/workspace --open
```

默认地址 `http://127.0.0.1:4173`，入口：

| 地址 | 用途 |
|---|---|
| `/` | 只读预览工作区存档，监听磁盘变化，适合配合 MCP |
| `/editor` | UI、Lua、服务端逻辑编辑，导入导出、显式保存及独立试玩 |
| `/health` | 无敏感内容的存活检查，无需登录 |

参数：`--workspace <dir>`（默认 `QXQY_WORKSPACE` 或当前目录）、`--file <工作区相对路径>`、`--host <host>`（默认 `127.0.0.1`）、`--port <port>`（默认 `4173`）、`--open`。工作区必须已经存在。

构建后的入口是 `web/dist/server.js`，静态文件与 Worker 随包携带。安装者无需源码、pnpm 或 esbuild。

更新时再次执行 `npm install -g beyond-simulator-web`，再重启服务并刷新页面。

## 编辑与保存

浏览器拒绝试玩新标签页时自动回退到全屏内嵌试玩。仅 `/editor/play` 允许同源嵌入，其他页面禁止被 frame 嵌入。关闭与焦点处理见 [共用编辑器](../editor-ui/README.md#试玩窗口与内嵌兜底)。

`/editor` 与 Harness 共用编辑界面，包括控件树、属性、五档设备画布、Lua 脚本、服务端变量/信号、导入导出和试玩。点击“保存存档”，输入工作区内相对路径，将三类资产写为完整存档 JSON。试玩或普通编辑不会自动写盘。

会话 ID 保存在浏览器标签页的 `sessionStorage`；刷新会保留进程内编辑与 Worker 状态。不同 ID 的会话相互独立；浏览器“复制标签页”可能复制 sessionStorage，从而共享会话。

宿主默认保留 8 个热会话，超出后将最近最少使用的闲置工程压缩保留在内存，再次请求时恢复。未保存内容、revision、选中项、文件哈希与待确认的同步计划一起保留；教学副本也参与回收。进行中的请求与试玩 Worker 不被挤掉，可暂时超出热会话预算。连续 15 分钟无请求的 Worker 会被停止（每分钟检查），工程仍保留；试玩页轮询会续期。宿主参数 `maxSessions`、`sessionIdleMs` 分别调整热会话预算和闲置超时。

服务重启会丢失未保存编辑。保存按钮先提交脚本与逻辑草稿，再按[共享保存契约](../studio/README.md#存档保存与导入)检查版本与磁盘冲突；冲突时重新加载或另存。成功导入解除旧文件关联，下次保存需填写新路径；普通保存与脚本同步保存可混用。

<a id="快速入门"></a>
## 快速上手

编辑器右下角常驻「快速上手」，普通工程也可打开。`/editor?quickStart=1` 提供「下载示例，开始实操」和「用当前存档继续」。以 AI 已完成游戏为起点，带用户把同一个游戏交付到千星沙箱，不先逐页介绍功能：

1. **先试玩这个游戏**：下载打开后第一步直接高亮右上角「试玩」，以“假设 AI 已做好这个游戏”引导体验，再返回编辑准备导出。AI 外置沙箱定位、对话创作、页面说明与日志排错放在可展开补充中。
2. **导出并导入千星沙箱**：导出 GIA 整合包；在游戏「系统菜单 → 资产导入导出工具 → 导入与转存」点击右下角「加载外部资产」，在弹窗中先「打开目录」放入文件，再点击弹窗内「加载外部资产」。选中资产、转存并确认目标页签后，在「界面控件组管理 → 界面布局」选布局，点击左下角「添加界面控件」，从「自定义模板」选择导入的客户端控件容器。
3. **校准客户端控件索引**：重点核对 Lua 用到的客户端控件模板及其子控件，尤其是实例化模板索引。游戏中从「界面控件组库 → 客户端控件模板」找到对应模板，在右侧顶部名称下方复制「索引」，不要用布局或客户端控件容器索引替代模板索引。回到模拟器时自动切到「UI控件-客户端」，用户选中同一个模板或子控件，填入索引并点击「修改」，随后处理 [Lua 引用同步](../studio/docs/control-guid-sync.md)。示例先核对 `RectTemplate`、`CircleTemplate`、`TriangleTemplate`；不要求逐个重编号服务端界面。切换和刷新恢复不代选其他控件或代填索引。
4. **绑定真机路径**：再切到千星沙箱，打开「窗口 → 客户端脚本资源管理器」，在「客户端脚本映射 → 对应页签」按名称和文件路径找到本游戏的脚本，双击打开目录，向上找到并复制 `default_import_file` 完整路径；回模拟器逐项填写目录与存档位置，点击「保存设置」。独立远程示例的两个相对目录字段留空，直接用内联源码及原脚本映射路径，不要求本地存在源码目录。
5. **更新脚本并实机试玩**：点击「保存存档并查看更新」，核对差异、勾选脚本、确认复制，再回千星沙箱保存并重新试玩。后续已有脚本的修改沿用同步流程，无需重新导入 GIA。

结语为「有模拟器问题都可以直接问你的 AI」。完整同步流程及新增脚本、UI 结构变更的处理见 [脚本同步](../studio/docs/script-sync.md)。

模拟器内的提示卡就近浮在目标旁，避让操作区域，不占编辑区高度；遮罩透传点击和滚动，保存与试玩弹窗打开时暂时隐藏提示。高亮随滚动和窗口尺寸变化更新，目标移出视野时可点「定位到这里」。游戏侧步骤在编辑导航下方居中显示较宽的卡片，轻微压暗背景、标明「现在切换到千星沙箱操作」，不再放在右下角或高亮无关控件。关键操作直接显示编号清单，按钮和页签名加粗；卡片底部明确说明完成后点击哪个引导按钮继续，以及该按钮不会执行游戏/编辑器操作。长清单在可视区域内滚动。

按钮按当前任务显示「试玩过了，去导出」「已复制路径，回模拟器」等完成确认。顶部下拉框在五个阶段之间跳转，并显示阶段内进度；右下角的入口仍可恢复收起的引导。切换步骤会先提交代码和逻辑草稿，导览不会代填目录或复制文件。游戏操作入口依据 `output/publish` 工作流、用户提供的界面布局/索引/脚本资源管理器截图，以及[官方资产导入导出说明](https://act.mihoyo.com/ys/ugc/tutorial/detail/mhxbd59urbfu)；入口说明不等于当前示例已获真机验证。

欢迎页默认从 `https://ppt.070077.xyz/beyond-ai/flappy-fish.save.json` 下载示例，仅支持远程 HTTP(S) 来源。可在启动前用 `QXQY_QUICK_START_URL` 覆盖地址（`createWebServer` 对应参数为 `quickStartUrl`）；显式空字符串禁用示例，当前存档仍可实操。

示例标题由 JSON 顶层 `meta.name` 决定；需要改名时修改 JSON 并上传更新，下载代码不覆盖名称。发布时上传一个完整的 `flappy-fish.save.json`，包含服务端 UI、客户端模板和三个脚本的内联源码。URL 直接返回 JSON 字节，由宿主请求，浏览器使用同源 API。例如：

```powershell
$env:QXQY_QUICK_START_URL = 'https://ppt.070077.xyz/beyond-ai/flappy-fish.save.json'
node web/server.js --workspace E:/qxqy-lua --port 4173
```

宿主校验完整存档格式后创建独立教学会话，保留 JSON 中的名称并清空 `scriptSync`。未保存的原工程留在原会话，可通过「返回原工程」切回。选了「用当前存档继续」不会下载示例，之后可从引导卡片的「打开示例存档」重新打开欢迎页。重复打开复用同一教学副本并保留其修改，不重新下载远端更新。下载失败可重试；20 秒超时、最大 6 MiB。教程保存建议路径位于 `tutorials/`，仍需显式点击保存。

步骤与收起状态按导览版本 `simulator-guide-v7` 和会话保存在浏览器本地，与示例版本独立；旧版章节进度不套用到新版步骤。刷新恢复进度及对应面板，已打开教学副本时不再弹出欢迎页；新窗口与内嵌试玩提供通用调试提示。完成导览仅表示浏览完成，千星沙箱的导入与操作由用户执行。

实现：共享 `studio/host/quick-start-source.js`、Web `lib/editor-sessions.js`、共用 `editor-ui/quick-start.js` 与 `dsh-plugin/lib/play.html`。Web/DSH 共用下载校验和实操引导，各自保留独立教学副本；[DSH 会话切换](../dsh-plugin/README.md#快速上手)仍使用真实对话身份。示例未内置于安装包；示例路径只用作填写提示，不限制操作当前工程，步骤推进不依赖玩法日志。宿主重启后的未保存工程恢复沿用上方[编辑与保存](#编辑与保存)边界，已保存教学存档可作为普通工程打开。

回归：`web/test/editor.test.mjs`、`web/test/quick-start.test.mjs`，覆盖热会话预算下的未保存工程/同步计划恢复、并发与活跃 Worker 保护、闲置释放、教学下载重试和副本复用。浏览器用合成工程走试玩、导出、索引/Lua同步、目录设置和临时目录显式复制，并检查多窗口尺寸、目标避让、透传及刷新恢复。观察范围为 Windows / Node22 / Edge（`observed / simulator / not_required`），不涵盖游戏内 GIA 导入。

## 与 MCP 配合

编辑器「Lua 脚本 → 实机脚本同步」可将当前存档脚本显式复制到宿主本机的千星沙箱目录：配置随存档保存，先保存并预览差异，再确认复制。也可授权 AI 通过 MCP 或 Harness 的同步接口完成更新。详见 [目录配置、同步接口及端到端验证](../studio/docs/script-sync.md)。

MCP 显式调用 `qxqy_project_save` 保存工作区 JSON 后，`/` 每 700ms 检查当前文件。还没有打开存档时，每 5 秒重新发现存档并自动打开最新的 `qxqy-simulator-save`；已经打开时，只在该文件变化后停止旧试玩、重新加载，并通过 SSE 刷新浏览器。不会自动改看另一个路径。顶部刷新按钮可立即扫描。该预览不写文件。`/editor` 不自动用磁盘内容覆盖正在编辑的草稿，需要手动“从工作区拉取存档”。

MCP 提供 `qxqy_preview_status()` 和 `qxqy_preview_open({ path: "game.save.json" })`：前者查询 Web 实际版本、工作区、当前存档和加载错误，后者直接让预览服务读取指定存档，无需重新保存。MCP 默认连接 `http://127.0.0.1:4173`，其他端口使用 MCP 的 `--web-url` 或 `QXQY_WEB_URL`；Web 启用口令时，在 MCP 环境中配置相同的 `QXQY_WEB_PASSWORD`。两边必须使用同一工作区，桥接会在读取和打开时校验。工具回执确认服务端已加载，浏览器通过 SSE 或定期状态同步刷新。

页面“预览连接”显示 Web 版本、工作区、加载错误与扫描警告。发现列表只读取 JSON 的前 4 KiB，不再排除超过 8 MiB 的合法存档；在扫描预算内按修改时间取最新 50 项。自动扫描跳过隐藏条目及依赖/生成目录，最多 8 层、10,000 条目和 1,000 目录；达到限制或读取失败会显示汇总警告。明确指定的 `--file` / 预览工具路径不受列表筛选限制，但仍受工作区边界保护。损坏 JSON 会显示加载错误并继续重试；初始文件缺失不会导致整个 Web 服务无法启动。

源码更新后需运行 `pnpm build` 并重启 Web/MCP；`pnpm start:web` 直接运行已有 `web/dist`，不会自动构建。npm 安装用户更新包后也需重启进程。

大工作区可用 `QXQY_SCAN_DIR_LIMIT`、`QXQY_SCAN_ENTRY_LIMIT`、`QXQY_SCAN_DEPTH_LIMIT` 调整自动发现预算；只接受正安全整数，其他值使用上述默认值。每次扫描开始时读取一次，诊断回执返回实际限制。环境变量不会放宽显式文件路径的工作区边界。

<a id="2026-09-26-预览同步修复记录"></a>
### 预览验证与错误恢复

回归入口为 `web/test/preview-state.test.mjs`、`studio/test/workspace.test.mjs`、`studio/test/controller-archive.test.mjs` 与实际启动两个进程的 `mcp/test/web-integration.test.mjs`，覆盖新文件发现、保存路径、大文件、列表预算与显式预览桥接。证据为 `observed / simulator / not_required`。

错误恢复约束：存档损坏时显示加载错误并停止旧试玩，恢复文件后回到编辑预览；旧试玩状态不得屏蔽错误事件，加载失败后即使时间戳未变也要重试。

## 试玩与素材

试玩使用可选 30 / 60 FPS 的固定步长 Worker、增量场景和 Pixi/WebGL；预览工具栏或独立试玩底栏可直接切换，默认 30，浏览器记住选择。刷新预览页会接回已有 Worker，保留暂停、帧率和当前玩家。截图仍由 Host 根据统一场景输出 PNG。完整时钟与工具契约见 [30 / 60 FPS](../mcp/README.md#30--60-fps)。

试玩工具栏「键位响应」默认开启，按官方文档转发键盘及鼠标左右键的 Down/Up；关闭后光标点击和滚动仍可用，失焦会释放已按键。映射、文档/回传差异及范围见 [浏览器键位响应](../studio/docs/browser-input.md)。

白名单静态图片按需从素材源加载，通过同源 `/qxqy-assets/` 路由显示，浏览器复用 HTTP 缓存，Host 与 MCP 共用磁盘缓存。可用 `QXQY_IMAGE_CACHE_DIR` 指定目录；图片属性面板提供「重新下载此素材」。详见 [素材缓存与预览边界](../studio/docs/image-assets.md)。

Lua `game.PlayAudio2D(id)` 触发白名单 MP3 按需缓存与播放，同源路由为 `/qxqy-audio/`，缓存目录可用 `QXQY_AUDIO_CACHE_DIR` 指定。首次自动播放被浏览器阻止时点击「开启声音」；支持停止、试玩暂停/继续和静音。参见 [音频说明](../studio/docs/audio-assets.md)。

界面动效和全屏动效通过 `/qxqy-vfx/ct-v1/` 按需缓存 C/T WebM、图标和声音。`/editor` 支持静音动态预览，两个试玩入口都支持 Lua 驱动的动效播放；`/` 编辑模式仍为静态 PNG。资源失败不停止编辑/试玩。参见 [动效播放、缓存与截图边界](../studio/docs/ui-vfx-playback.md)。

## 部署与访问控制

绑定非回环地址前，设置 `QXQY_WEB_PASSWORD`，登录用户名固定为 `simulator`。设置口令后，即使回环访问也要求认证。业务静态文件、API、SSE 与截图均受保护；写请求只接受 JSON 并校验浏览器 Origin。路径只能落在配置工作区内。

```powershell
$env:QXQY_WEB_PASSWORD = '替换为自己的长口令'
beyond-simulator-web --workspace E:/my-project --host 0.0.0.0
```

HTTP Basic 不提供传输加密；对外部署需使用 HTTPS 反向代理。代理转发应保留外部 Host，与浏览器 Origin 一致；当前路径以站点根 `/` 部署，不支持 URL 子路径前缀。

仓库根的 `Dockerfile` 用 Node 22 构建并安装 Web tarball，运行阶段使用非 root 用户；`compose.yaml` 默认只暴露本机端口，存档放在持久卷 `/data`：

```sh
cp .env.example .env
# 填写 QXQY_WEB_PASSWORD
docker compose up --build -d
```

这是单个可信操作者的实例，不提供多租户权限、资源配额或恶意代码沙箱。不要把工作区设为含无关敏感文件的大目录。静态站点托管和多用户服务需要另行实现。
