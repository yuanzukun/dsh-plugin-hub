/**
 * Route logic as pure functions: query/body in, status+body out. The HTTP
 * shell (index.ts) owns req/res mechanics; everything testable lives here.
 */

import { basename, dirname, join, resolve } from 'node:path'
import { mkdir, readdir, rm, stat } from 'node:fs/promises'
import { runPostCreateCopy, type CopyFilesSeams } from './copy-files.js'
import { credentialHostIssue, credentialSecretIssue, credentialUsernameIssue, createLocalCredentialStore, maskSecret, normalizeCredentialHost, removeCredential, sortCredentials, upsertCredential, type CredentialStore, type GitCredential } from './credentials.js'
import type { CredentialService } from './credential-service.js'
import { importLocalCredentials as runLocalImport, type LocalImportReport } from './local-import.js'
import { appendWorktreeExclude, fsExcludeSeams, GitError, addRemote, addWorktree, addWorktreeCutout, collectAiDiff, commitFiles, commitIndex, createBranch, createTag, cutoutBranchName, deleteBranch, fetchAll, fsDirExists, inspectWorktree, isAbsoluteDir, isStageablePath, listRemotes, listTagNames, logHistory, probeRepo, probeWorkspaceGit, pushTag, removeRemote, removeWorktree, renameBranch, resolveBranch, resolvePushRemote, resolvePushTarget, pushBranch, setRemoteUrl, stagePaths, switchBranch, updateBranch, workingChanges, type ChannelProvider, type DirExists, type ExcludeSeams, type Exec, type NetworkOptions } from './git.js'
import { classifyGitFailure, withHint } from './network.js'
import { channelReport } from './network-probe.js'
import { ACCEL_DEFAULT_URL, accelerateUrlError, isAbsoluteConfigPath, normalizeAccelerateUrl, remoteNameIssue, remoteUrlIssue, sanitizeBranchDir, type RemoteNameIssue, type RemoteUrlIssue } from './normalize.js'
import { deviceFlowClientId, isDeviceFlowHost, pollDeviceFlow, startDeviceFlow, type DeviceFlowPoll } from './oauth.js'
import { resolveRootDir } from './settings.js'
import { COMMIT_MESSAGE_LIMIT } from './wire.js'
import type {
  AiCommitMessageBody, NetworkChannelId, NetworkProbeBody, NetworkProbeResult, AiCommitMessageResult, ChangesBody, ChangesResult, CommitBody, CommitFilesBody, CommitFilesResult, CommitResult, CreateBranchBody, CreateBranchResult, CreateTagBody, CreateTagResult, CreateWorktreeBody, CreateWorktreeResult, CredentialDeleteBody, CredentialEntryView, CredentialOAuthPollBody, CredentialOAuthPollResult, CredentialOAuthStartBody, CredentialOAuthStartResult, CredentialImportResult, CredentialSaveBody, CredentialsResult, DeleteBranchBody, DeleteBranchResult, EnsureDirectoryBody, EnsureDirectoryResult, FetchBody, FetchResult, GroupWorkspacesResult, InspectWorktreeBody, InspectWorktreeResult, LogBody, LogResult, PathExistsResult, PurgeDirectoryBody, PurgeDirectoryResult, PushTagBody, PushTagResult, RemoteAction, RemoveWorktreeBody, RemoveWorktreeResult, RemotesBody, RemotesResult, RemoteMutationBody, RenameBranchBody, RenameBranchResult, RepoStatus, RouteError, StageBody, StageResult, SwitchBody, SwitchResult, UpdateBody, UpdateResult, PushBody, PushResult, WorktreesAllResult,
} from './wire.js'

/** Everything the handlers need from the host half. */
export interface RouteDeps {
  exec: Exec
  /** Fallback channels for a network command, in priority order: the
   * explicit proxy first, then the IP-optimized channel (absent = direct only; tests leave
   * it out so no real lookup, race, or proxy argv ever runs). */
  networkChannels?: (exec: Exec, cwd: string, authArgs: readonly string[]) => readonly ChannelProvider[]
  /** The settings-resolved rootDir (absent/blank = the default location). */
  sectionRootDir: () => string | undefined
  /** Explicit proxy URL for the proxy channel; absent/blank = none. */
  sectionNetworkProxy?: () => string | undefined
  /** The proxy Windows itself has enabled (read-only WinINET probe); absent = not looked up. */
  sectionSystemProxy?: () => Promise<string | undefined>
  /** Whether a worktree creation syncs the remotes first (absent = off). */
  sectionFetchBeforeCreate: () => boolean | undefined
  /** Post-create configuration files to copy when .worktreeinclude is absent. */
  sectionPostCreateCopyFiles?: () => string[] | undefined
  /** Whether the cn-accelerate mirror rewrite is on (absent = off). */
  sectionCnAccelerate?: () => boolean | undefined
  /** The cn-accelerate mirror prefix (absent = the shipped default). */
  sectionCnAccelerateUrl?: () => string | undefined
  /** User home directory seam. */
  home: () => string
  /** `$DSH_HOME` environment value seam. */
  envHome: () => string | undefined
  /** Worktree-registration existence seam (tests substitute). */
  dirExists?: DirExists
  /** Local-ignore write seams (tests substitute). */
  excludeSeams?: ExcludeSeams
  /** Post-create file copy seams (tests substitute). */
  copyFilesSeams?: CopyFilesSeams
  /** HTTP seam for the browser sign-in routes (absent = global fetch). */
  fetchImpl?: typeof fetch
  /** Directory probe seam over fs.stat (true = exists AND is a directory);
   * tests substitute. */
  statDirectory?: (path: string) => Promise<boolean>
  /** Recursive mkdir seam (fs.mkdir recursive); tests substitute. */
  mkdirRecursive?: (path: string) => Promise<void>
  /** One-level directory listing seam (fs.readdir with dirents); tests
   * substitute. */
  listDir?: (path: string) => Promise<string[]>
  /** Recursive force rm seam (fs.rm with retries); tests substitute. */
  rmRecursive?: (path: string) => Promise<void>
  /** Global per-host credential store. Absent = the fs-backed store at the
   * resolved dsh home; tests substitute an in-memory one. */
  credentialsStore?: CredentialStore
  /** The single credential entry point (decision 0034): when wired, it owns
   * the store and both injection channels, and the seams below are ignored. */
  credentialsService?: CredentialService
  /** Re-derive the shell credential bridge after the store changed (absent =
   * a host that does not provide the bridge; tests omit it). */
  refreshShellBridge?: () => Promise<void>
  /** Machine-credential import seam (decision 0038): probes the helpers the
   * user's own gitconfig points git at, for the hosts it names. Tests
   * substitute; absent = the real `git credential fill` probe. */
  importLocalCredentials?: (store: CredentialStore, hosts?: readonly string[]) => Promise<LocalImportReport>
}

/** Real fs-backed one-level directory listing (names only). Plain FILES are
 * filtered out — the storage root can carry strays (a legacy settings.json
 * was seen in the wild), and the scan lists worktree SLOTS, not entries. */
export async function fsListDir(path: string): Promise<string[]> {
  try {
    const dirents = await readdir(path, { withFileTypes: true })
    return dirents.filter(entry => entry.isDirectory()).map(entry => entry.name)
  } catch {
    // A missing storage root is the "no worktrees yet" answer, not an error.
    return []
  }
}

/** Real fs-backed directory probe: exists and is a directory. */
export async function fsStatDirectory(path: string): Promise<boolean> {
  try {
    return (await stat(path)).isDirectory()
  } catch {
    return false
  }
}

/** Real fs-backed recursive mkdir. */
export async function fsMkdirRecursive(path: string): Promise<void> {
  await mkdir(path, { recursive: true })
}

/** One route outcome: HTTP status plus the JSON body. */
export interface RouteOutcome {
  status: number
  body: RepoStatus | CreateWorktreeResult | SwitchResult | CreateBranchResult | FetchResult | UpdateResult | GroupWorkspacesResult | InspectWorktreeResult | RemoveWorktreeResult | PathExistsResult | EnsureDirectoryResult | WorktreesAllResult | PurgeDirectoryResult | ChangesResult | StageResult | CommitResult | LogResult | CommitFilesResult | CreateTagResult | PushTagResult | AiCommitMessageResult | CredentialsResult | CredentialOAuthStartResult | CredentialOAuthPollResult | CredentialImportResult | RemotesResult | NetworkProbeResult | RouteError
}

/** Uniform failure envelope. */
function fail(status: number, error: string): RouteOutcome {
  return { status, body: { error } }
}

/**
 * The rewrite prefix for one request's network READ commands: the cn-accelerate
 * mirror prefix when the switch is on and the URL setting is usable (the
 * shipped default fills an absent URL), else undefined — no injection and the
 * direct connection runs unchanged. PUSH never consults this helper.
 */
function accelPrefix(deps: RouteDeps): string | undefined {
  if (deps.sectionCnAccelerate?.() !== true) return undefined
  const url = deps.sectionCnAccelerateUrl?.() ?? ACCEL_DEFAULT_URL
  return accelerateUrlError(url) === undefined ? normalizeAccelerateUrl(url) : undefined
}

/** The fallback chain for one command: the host's providers, or none at all. */
function networkOptions(deps: RouteDeps, cwd: string, authArgs: readonly string[]): NetworkOptions {
  const channels = deps.networkChannels?.(deps.exec, cwd, authArgs) ?? []
  return channels.length === 0 ? {} : { fallbackChannels: channels }
}

/** The global credential store: the service's shared instance (decision 0037),
 * else the wired store, else the local `~/.git-credentials`-backed store. */
function credentialStore(deps: RouteDeps): CredentialStore {
  return deps.credentialsService?.store ?? deps.credentialsStore ?? createLocalCredentialStore(deps.home(), deps.envHome())
}

/**
 * Credential argv for one network command. Empty by design since 0037: the
 * token reaches git through the URL-scoped `helper = store` include that
 * `~/.gitconfig` carries, so there is nothing to inject. The seam stays so
 * every call site keeps one place to change if a command ever needs an
 * explicit override again.
 */
async function authArgsFor(_deps: RouteDeps): Promise<readonly string[]> {
  return []
}

/**
 * Re-derive the shell credential bridge after a credential changed, so a
 * message sent in the same session can `git push` with the token the user just
 * saved. A bridge failure must never fail the save itself: the store write has
 * already landed, and the worst case is a stale environment until the next
 * save (an added host is not reachable, a deleted one may still be).
 */
async function refreshBridge(deps: RouteDeps): Promise<void> {
  const refresh = deps.credentialsService?.refreshShellEnv ?? deps.refreshShellBridge
  if (refresh === undefined) return
  try {
    await refresh()
  } catch {
    // Deliberately swallowed; see the contract above.
  }
}

/** Upper bound on distinct paths one /group request may probe. */
const GROUP_PATHS_LIMIT = 256

/** Probes per in-flight batch — polite on Windows, where each git call is a
 * process spawn. The probe itself is a single `rev-parse` per directory, so
 * the batch can ride wider than the old three-spawn shape without stacking
 * an unreasonable number of concurrent git processes. */
const GROUP_BATCH_SIZE = 16

/** Upper bound on children one /worktrees-all scan probes. The storage root
 * is this plugin's own slot directory, so a healthy one stays far below;
 * the cap exists so a root pointed at something enormous (a misconfigured
 * rootDir, a home directory) cannot turn one dialog open into thousands of
 * git spawns. Past it the scan answers its first slice plus `truncated`. */
const SCAN_CHILDREN_LIMIT = 512

/**
 * POST /group — git belonging facts for a batch of workspace directories.
 * Deduplicates, validates, probes in bounded batches, and answers 200 with
 * per-path facts (null for non-repositories); a repository-wide git failure
 * is a per-path null, never a 500 — the sidebar must degrade to flat, not
 * error out.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ paths }`.
 */
export async function handleGroupWorktrees(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return fail(400, 'request body must be a JSON object')
  const paths = (body as Record<string, unknown>).paths
  if (!Array.isArray(paths)) return fail(400, 'body key "paths" must be an array of absolute directories')
  const unknownKeys = Object.keys(body as Record<string, unknown>).filter(key => key !== 'paths')
  if (unknownKeys.length > 0) return fail(400, `unknown body key "${unknownKeys[0]}"`)
  const distinct: string[] = []
  for (const candidate of paths) {
    if (typeof candidate !== 'string' || !isAbsoluteDir(candidate)) return fail(400, 'body key "paths" must be an array of absolute directories')
    if (!distinct.includes(candidate)) distinct.push(candidate)
  }
  if (distinct.length > GROUP_PATHS_LIMIT) return fail(400, `body key "paths" accepts at most ${String(GROUP_PATHS_LIMIT)} distinct directories`)

  const facts: Record<string, GroupWorkspacesResult['facts'][string]> = {}
  for (let start = 0; start < distinct.length; start += GROUP_BATCH_SIZE) {
    const batch = distinct.slice(start, start + GROUP_BATCH_SIZE)
    const probed = await Promise.all(batch.map(async (path) => {
      // A probe never throws here by contract (gitMaybe folds non-zero exits),
      // but a defensive catch keeps ONE bad path from sinking the batch.
      try {
        return [path, await probeWorkspaceGit(deps.exec, path) ?? null] as const
      } catch {
        return [path, null] as const
      }
    }))
    for (const [path, value] of probed) facts[path] = value
  }
  return { status: 200, body: { facts } }
}

/** The project-internal layout directory name every repository uses. */
const PROJECT_LAYOUT_DIR = join('.dsh', 'gitworktree')

/**
 * Whether `canonical` sits DIRECTLY inside a `<repo>/.dsh/gitworktree`
 * layout root whose repository actually exists on disk. The layout names its
 * own owner (two levels up must hold a `.git`), so no workspace list is
 * needed to gate the plugin's territory — a plain fs probe decides.
 */
function insideProjectLayout(canonical: string, dirExists: DirExists): boolean {
  const layout = dirname(canonical)
  if (basename(layout) !== 'gitworktree') return false
  const dsh = dirname(layout)
  if (basename(dsh) !== '.dsh') return false
  return dirExists(join(dirname(dsh), '.git'))
}

/**
 * POST /worktrees-all — git facts for every DIRECT child directory of the two
 * storage locations the plugin has ever used, merged:
 *
 * - legacy: the resolved central storage root (today a read-only historical
 *   location — existing worktrees stay put, `rootDir` still resolves it);
 * - project: `<repo>/.dsh/gitworktree` under every DISTINCT repository root
 *   derived from the caller's registered workspace paths (the current
 *   layout — its path prefix is what the workspace tree nests under).
 *
 * The management dialog's data source (and, through it, the lazy prune's):
 * one scan answers for all repositories at once, orphan directories included
 * (a child that probes as no git repository comes back with null facts
 * rather than being dropped — the dialog shows it as unrecognized). Missing
 * locations answer their half as an empty list; per-child probe failures
 * degrade to null facts, never a 500 — the dialog must render, not error
 * out. Each location that holds more than {@link SCAN_CHILDREN_LIMIT}
 * children answers its first slice, and any truncation marks the whole
 * response `truncated`, so a misconfigured location cannot turn one dialog
 * open into thousands of git spawns.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ workspaces? }`.
 */
export async function handleWorktreesAll(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return fail(400, 'request body must be a JSON object')
  const workspacesRaw = (body as Record<string, unknown>).workspaces ?? []
  if (!Array.isArray(workspacesRaw)) return fail(400, 'body key "workspaces" must be an array of absolute directories')
  const unknownKeys = Object.keys(body as Record<string, unknown>).filter(key => key !== 'workspaces')
  if (unknownKeys.length > 0) return fail(400, `unknown body key "${unknownKeys[0]}"`)
  const workspaces: string[] = []
  for (const candidate of workspacesRaw) {
    if (typeof candidate !== 'string' || !isAbsoluteDir(candidate)) return fail(400, 'body key "workspaces" must be an array of absolute directories')
    if (!workspaces.includes(candidate)) workspaces.push(candidate)
  }
  if (workspaces.length > GROUP_PATHS_LIMIT) return fail(400, `body key "workspaces" accepts at most ${String(GROUP_PATHS_LIMIT)} distinct directories`)

  const listDir = deps.listDir ?? fsListDir
  const facts: WorktreesAllResult['worktrees'] = []
  let truncated = false
  const scanLocation = async (root: string, source: 'legacy' | 'project'): Promise<void> => {
    const listed = await listDir(root)
    if (listed.length > SCAN_CHILDREN_LIMIT) {
      truncated = true
      listed.length = SCAN_CHILDREN_LIMIT
    }
    for (let start = 0; start < listed.length; start += GROUP_BATCH_SIZE) {
      const batch = listed.slice(start, start + GROUP_BATCH_SIZE)
      const probed = await Promise.all(batch.map(async (child) => {
        const path = join(root, child)
        try {
          const gitFacts = await probeWorkspaceGit(deps.exec, path)
          return gitFacts === undefined
            ? { path, repoName: null, branch: null, source }
            : { path, repoName: gitFacts.repoName, branch: gitFacts.branch, source }
        } catch {
          return { path, repoName: null, branch: null, source }
        }
      }))
      facts.push(...probed)
    }
  }

  const legacyRoot = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  await scanLocation(legacyRoot, 'legacy')
  const statDirectory = deps.statDirectory ?? fsStatDirectory
  const legacyRootExists = await statDirectory(legacyRoot)

  // Project half: one belonging probe per DISTINCT workspace path (bounded
  // batches, same as /group), then one scan per DISTINCT repository root.
  const repoRoots = new Set<string>()
  for (let start = 0; start < workspaces.length; start += GROUP_BATCH_SIZE) {
    const batch = workspaces.slice(start, start + GROUP_BATCH_SIZE)
    const probed = await Promise.all(batch.map(async (path) => {
      try {
        return await probeWorkspaceGit(deps.exec, path)
      } catch {
        return undefined
      }
    }))
    for (const workspaceFacts of probed) {
      if (workspaceFacts !== undefined) repoRoots.add(workspaceFacts.repoRoot)
    }
  }
  for (const repoRoot of repoRoots) {
    await scanLocation(join(repoRoot, PROJECT_LAYOUT_DIR), 'project')
  }

  return { status: 200, body: { worktrees: facts, legacyRoot, legacyRootExists, ...truncated ? { truncated } : {} } }
}

/** Real fs-backed recursive force rm (Windows file-lock retries included). */
export async function fsRmRecursive(path: string): Promise<void> {
  await rm(path, { recursive: true, force: true, maxRetries: 8, retryDelay: 100 })
}

/** Create the layout root through the deps seam (tests substitute a no-op). */
function mkdirSlot(deps: RouteDeps, layoutRoot: string): Promise<void> {
  const mkdirRecursive = deps.mkdirRecursive ?? fsMkdirRecursive
  return mkdirRecursive(layoutRoot)
}

/**
 * POST /purge — delete a NON-git directory sitting DIRECTLY inside one of the
 * plugin's two storage layouts: the legacy central root or a repository's
 * `.dsh/gitworktree`. The orphaned leftover a half-failed `worktree remove`
 * can leave behind (git registration and the .git file already gone,
 * contents stranded on disk). Triple-gated: one level below a storage
 * location (resolved forms, same slot boundary as /ensure-directory), a real
 * directory, and NOT a git repository — anything git still recognizes must
 * go through /remove, where the removal carries the session-archive and
 * unregistration half. Deletion is a plain recursive force rm.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path }`.
 */
export async function handlePurgeDirectory(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<PurgeDirectoryBody>(body, ['path'])
  if (isOutcome(parsed)) return parsed
  const { path } = parsed
  if (!isAbsoluteDir(path)) return fail(400, '"path" must be an absolute directory')
  const configured = deps.sectionRootDir()?.trim()
  if (configured !== undefined && configured !== '' && !isAbsoluteConfigPath(configured)) {
    return fail(400, `configured rootDir "${String(deps.sectionRootDir())}" is not an absolute path`)
  }
  const rootDir = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  const canonical = resolve(path)
  if (dirname(canonical) !== resolve(rootDir) && !insideProjectLayout(canonical, deps.dirExists ?? fsDirExists)) {
    return fail(400, `"${canonical}" is outside the plugin's worktree storage locations`)
  }
  const statDirectory = deps.statDirectory ?? fsStatDirectory
  if (!(await statDirectory(canonical))) {
    return fail(400, `"${canonical}" is not a directory`)
  }
  const gitFacts = await probeWorkspaceGit(deps.exec, canonical)
  if (gitFacts !== undefined) {
    return fail(400, `"${canonical}" is a git repository; remove it as a worktree instead`)
  }
  const rmRecursive = deps.rmRecursive ?? fsRmRecursive
  try {
    await rmRecursive(canonical)
    return { status: 200, body: { path: canonical, removed: true } }
  } catch (error) {
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/** GitError to outcome: usage-shaped failures are 400, the rest 500. */
function gitFailure(error: GitError): RouteOutcome {
  // Every git failure the routes surface passes through one classifier so
  // the toast explains WHAT broke (host, credentials, divergence) instead of
  // repeating git's raw text alone.
  const failure = classifyGitFailure(error.stderr, { timedOut: error.timedOut })
  const usage = error.stderr.includes('usage:')
    || error.stderr.includes('fatal: invalid')
    // A user-typed branch name git refuses (`'bad..name' is not a valid
    // branch name`) is caller misuse, not a host fault — the client
    // pre-flights the same rules, this is the backstop.
    || error.stderr.includes('not a valid branch name')
    // A name or storage folder that already exists is caller misuse too
    // (a stale worktree folder survives its branch's deletion): the client
    // pre-flights branch duplicates, this is the backstop.
    || error.stderr.includes('already exists')
    // Diverged/branchless states an update cannot fast-forward through are
    // the user's repo state, not host faults: no upstream to merge, a
    // detached HEAD, or local commits `--ff-only` must not paper over.
    || error.stderr.includes('Not possible to fast-forward')
    || error.stderr.includes('no tracking information')
    || error.stderr.includes("unknown revision")
    // A display name that resolves to no branch at all (a stale row the
    // menu no longer shows) is caller-side state, not a host fault. The
    // failure is the SYNTHETIC GitError from git.ts (`branch "x" not
    // found`), so match its `branch "` shape — git's own "not found"
    // texts (a remote that vanished mid-fetch: `Repository '...' not
    // found`) carry no quoted branch and stay 500 host faults.
    || error.stderr.includes('branch "')
    // Deletion refusals from `git branch -d` are the user's repo state the
    // same way: unmerged commits (the safe delete's whole point) and a
    // branch checked out in some worktree.
    || error.stderr.includes('is not fully merged')
    || error.stderr.includes('Cannot delete branch')
    // Removal refusals from git.ts are caller-side state the same way: the
    // main worktree (git refuses it too, but the route answers a clean 400
    // before ever spawning git) and a path the repository never registered
    // (a stale sidebar row racing a terminal-side removal).
    || error.stderr.includes('cannot remove the main worktree')
    || error.stderr.includes('is not a registered worktree')
  return fail(usage ? 400 : 500, withHint(error.message, failure))
}

/**
 * GET /status 鈥?repository facts for one directory.
 * @param deps - host dependencies.
 * @param path - absolute directory the workspace reports.
 */
export async function handleStatus(deps: RouteDeps, path: string | undefined): Promise<RouteOutcome> {
  if (path === undefined || !isAbsoluteDir(path)) return fail(400, 'query parameter "path" must be an absolute directory')
  const facts = await probeRepo(deps.exec, path, deps.dirExists)
  const rootDir = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  if (facts === undefined) return { status: 200, body: { repo: false } }
  return {
    status: 200,
    body: {
      repo: true,
      repoName: facts.repoName,
      repoRoot: facts.repoRoot,
      main: facts.main,
      currentBranch: facts.currentBranch,
      branches: facts.branches,
      remoteBranches: facts.remoteBranches,
      worktrees: facts.worktrees,
      rootDir,
    },
  }
}

/** Validate a JSON body object with exactly the expected keys. */
function readBody<T>(
  body: unknown,
  keys: readonly (keyof T & string)[],
  booleanKeys: readonly (keyof T & string)[] = [],
  optionalKeys: readonly (keyof T & string)[] = [],
  numberKeys: readonly (keyof T & string)[] = [],
): T | RouteOutcome {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return fail(400, 'request body must be a JSON object')
  const record = body as Record<string, unknown>
  for (const key of Object.keys(record)) {
    if (!keys.includes(key as keyof T & string) && !booleanKeys.includes(key as keyof T & string) && !optionalKeys.includes(key as keyof T & string) && !numberKeys.includes(key as keyof T & string)) {
      return fail(400, `unknown body key "${key}"`)
    }
  }
  for (const key of keys) {
    if (typeof record[key] !== 'string') return fail(400, `body key "${key}" must be a string`)
  }
  for (const key of booleanKeys) {
    // Optional flag: absent stays absent (`cutout?: boolean`), present must type-check.
    if (record[key] !== undefined && typeof record[key] !== 'boolean') {
      return fail(400, `body key "${key}" must be a boolean`)
    }
  }
  for (const key of optionalKeys) {
    // Optional string: absent stays absent (`name?: string`), present must type-check.
    if (record[key] !== undefined && typeof record[key] !== 'string') {
      return fail(400, `body key "${key}" must be a string`)
    }
  }
  for (const key of numberKeys) {
    // Optional number: absent stays absent (`limit?: number`), present must type-check.
    if (record[key] !== undefined && typeof record[key] !== 'number') {
      return fail(400, `body key "${key}" must be a number`)
    }
  }
  return record as T
}

/** Discriminator: a RouteOutcome carries the `status`/`body` pair no request body has. */
function isOutcome(value: unknown): value is RouteOutcome {
  return typeof value === 'object' && value !== null && 'status' in value && 'body' in value
}

/**
 * POST /worktree — create or reuse the worktree for a branch, then report the
 * directory so the client can register it as a workspace. The worktree lands
 * at `<repo>/.dsh/gitworktree/<branch>` (path prefix = repository, so the
 * native workspace tree nests it under its repository automatically); an
 * existing registration for the branch ANYWHERE is reused first (the
 * repository-wide worktree list is location-independent — legacy-central
 * worktrees keep being returned, never duplicated). With `cutout: true` the
 * branch is the CURRENT checkout (occupied by the main worktree, so git
 * refuses to add it): a new branch is cut out of it (`<branch>-wt`, first
 * free `-wt<N>` suffix) and isolated in the fresh worktree instead.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleCreateWorktree(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CreateWorktreeBody>(body, ['repoPath', 'branch'], ['cutout'], ['name'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, branch, cutout, name } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (branch.trim() === '') return fail(400, '"branch" must be non-empty')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    // Local-ignore first, creation second: the rule is harmless when the
    // creation later fails (the directory simply does not exist), while the
    // reverse order leaves a created worktree visible as untracked on the
    // next `git status` when the write fails. A write failure never blocks
    // the creation — the worktree cannot be rolled back — it rides the
    // successful response as `excludeWarning` for the client to toast.
    const excludeWarning = await appendWorktreeExclude(deps.excludeSeams ?? fsExcludeSeams, facts.repoRoot)
    const layoutRoot = join(facts.repoRoot, PROJECT_LAYOUT_DIR)
    // Optional pre-create remote sync — but only when the branch actually
    // consumes remote data: a LOCAL branch's worktree (or an existing twin)
    // never reads the fetched refs, so the resolve runs first and the fetch
    // fires just for the remote-only shape (the twin `worktree add -b`
    // consumes it, the cutout's arbitrary base too). Deliberately NOT a
    // gate: a network hiccup must not block the creation — the failure
    // rides the successful response as `fetchWarning` for the client to
    // toast.
    let fetchWarning: string | undefined
    if (deps.sectionFetchBeforeCreate() === true) {
      const resolved = await resolveBranch(deps.exec, facts.repoRoot, branch)
      if (resolved?.remote !== undefined) {
        try {
          {
        const authArgs = await authArgsFor(deps)
        await fetchAll(deps.exec, facts.repoRoot, accelPrefix(deps), authArgs, networkOptions(deps, facts.repoRoot, authArgs))
      }
        } catch (error) {
          fetchWarning = error instanceof GitError ? error.stderr.trim() : error instanceof Error ? error.message : String(error)
        }
      }
    }
    const warnings = { ...fetchWarning === undefined ? {} : { fetchWarning }, ...excludeWarning === undefined ? {} : { excludeWarning } }
    if (cutout === true) {
      // An explicit name skips the `-wt` suffix walk and is used verbatim —
      // both for the branch and the storage folder. A leading dash would
      // ride `worktree add -b` as a flag; any other git-invalid name
      // surfaces through the error envelope (the client pre-flights).
      const custom = name?.trim()
      if (custom !== undefined && custom !== '') {
        if (custom.startsWith('-')) return fail(400, '"name" must not start with "-"')
        const target = join(layoutRoot, sanitizeBranchDir(custom))
        await mkdirSlot(deps, layoutRoot)
        await addWorktreeCutout(deps.exec, facts.repoRoot, branch, custom, target)
        const copyWarning = await runPostCreateCopy(deps, facts.repoRoot, target)
        const copyWarnObj = copyWarning !== undefined ? { copyWarning } : {}
        return { status: 200, body: { path: target, created: true, ...warnings, ...copyWarnObj } }
      }
      // The new branch name must be known before the folder name can be
      // computed: the folder carries the NEW branch's directory name. The
      // name must be free in BOTH namespaces — the branch table and the
      // storage folder: a leftover folder of a since-deleted branch would
      // otherwise fail `worktree add` with a bare "already exists", so the
      // suffix walk probes the folder too.
      const dirExists = deps.dirExists ?? fsDirExists
      const newBranch = await cutoutBranchName(deps.exec, facts.repoRoot, branch, (candidate) =>
        dirExists(join(layoutRoot, sanitizeBranchDir(candidate))),
      )
      const target = join(layoutRoot, sanitizeBranchDir(newBranch))
      await mkdirSlot(deps, layoutRoot)
      await addWorktreeCutout(deps.exec, facts.repoRoot, branch, newBranch, target)
      const copyWarning = await runPostCreateCopy(deps, facts.repoRoot, target)
      const copyWarnObj = copyWarning !== undefined ? { copyWarning } : {}
      return { status: 200, body: { path: target, created: true, ...warnings, ...copyWarnObj } }
    }
    // The folder name carries the branch: `<repo>/.dsh/gitworktree/<branch>`.
    const target = join(layoutRoot, sanitizeBranchDir(branch))
    await mkdirSlot(deps, layoutRoot)
    const result = await addWorktree(deps.exec, facts.repoRoot, branch, target, deps.dirExists)
    let copyWarning: string | undefined
    if (result.created) {
      copyWarning = await runPostCreateCopy(deps, facts.repoRoot, result.path)
    }
    const copyWarnObj = copyWarning !== undefined ? { copyWarning } : {}
    return { status: 200, body: { ...result, ...warnings, ...copyWarnObj } }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /switch — in-place branch switch of the QUERIED directory's own
 * checkout. A main-checkout session switches the main checkout; a linked
 * worktree session switches ITS worktree. (It used to always run in the
 * main checkout: a worktree session's checkout appeared to succeed while its
 * own branch never moved. git itself refuses a branch another worktree
 * holds — an honest error beats moving a checkout nobody was looking at.)
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleSwitch(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<SwitchBody>(body, ['repoPath', 'branch'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, branch } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (branch.trim() === '') return fail(400, '"branch" must be non-empty')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    const switched = await switchBranch(deps.exec, facts.toplevel, branch)
    const result: SwitchResult = { branch: switched }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /branch — create a NEW branch. Without `from`, from the queried
 * directory's current checkout (whatever its HEAD points at, detached
 * included), checked out in place. With `from` (a local branch or a remote
 * tracking ref): checked out here too when `checkout` is set
 * (`git switch -c <name> <from>`), created with no checkout touched
 * otherwise (`git branch`) — a create aimed at another branch must not
 * silently move the session's HEAD unless the caller asked for exactly
 * that. Git validates both names; the client pre-flights the same rules
 * and only sends names it already accepts.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleCreateBranch(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CreateBranchBody>(body, ['repoPath', 'name'], ['checkout'], ['from'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, name, from, checkout } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (name.trim() === '') return fail(400, '"name" must be non-empty')
  // A leading dash would ride `git switch -c` as a flag — reject before the
  // exec, not as an "unknown switch" GitError.
  if (name.startsWith('-')) return fail(400, '"name" must not start with "-"')
  // The same flag-ride guard for the start point, which lands on
  // `git branch <name> <from>` verbatim (a remote ref like `origin/x` is
  // the caller's legitimate shape — passed through untouched).
  if (from !== undefined) {
    if (from.trim() === '') return fail(400, '"from" must be non-empty when present')
    if (from.startsWith('-')) return fail(400, '"from" must not start with "-"')
  }
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    // The session's OWN worktree: the no-`from` shape cuts from — and checks
    // out in — the queried directory's HEAD, and `from` + `checkout` checks
    // out HERE. `repoRoot` would move the main checkout instead of the
    // worktree the session sits in (identical directory when it IS the main
    // checkout).
    const created = await createBranch(deps.exec, facts.toplevel, name, from, checkout === true)
    const result: CreateBranchResult = { branch: created }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /branch-rename — rename a LOCAL branch (`git branch -m`). Runs at the
 * repository root: branch refs are repository-wide and worktree HEADs
 * pointing at the old name follow the ref. Git validates the new name and
 * refuses a target that already exists; both map to 400 through
 * {@link gitFailure}.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleRenameBranch(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<RenameBranchBody>(body, ['repoPath', 'name', 'newName'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, name, newName } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (name.trim() === '') return fail(400, '"name" must be non-empty')
  if (newName.trim() === '') return fail(400, '"newName" must be non-empty')
  // Same flag-ride guard as the create route: the new name lands on
  // `git branch -m <name> <newName>` verbatim.
  if (newName.startsWith('-')) return fail(400, '"newName" must not start with "-"')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    const renamed = await renameBranch(deps.exec, facts.repoRoot, name, newName)
    const result: RenameBranchResult = { branch: renamed }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /branch-delete — delete a LOCAL branch with the SAFE form
 * (`git branch -d`): git refuses unmerged commits and branches checked out
 * in any worktree, both mapping to 400 through {@link gitFailure}. No
 * force variant — a menu click must never discard commits.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleDeleteBranch(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<DeleteBranchBody>(body, ['repoPath', 'name'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, name } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (name.trim() === '') return fail(400, '"name" must be non-empty')
  // Same flag-ride guard as its sibling routes: the name lands on
  // `git branch -d <name>` verbatim.
  if (name.startsWith('-')) return fail(400, '"name" must not start with "-"')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    const deleted = await deleteBranch(deps.exec, facts.repoRoot, name)
    const result: DeleteBranchResult = { branch: deleted }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /fetch 鈥?sync remote-tracking refs for the repository: fetch every
 * remote and prune tracking branches the remotes no longer carry. Pure
 * metadata — the working tree and the current checkout are untouched; the
 * client refetches /status afterwards for the fresh branch list.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleFetch(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<FetchBody>(body, ['repoPath'])
  if (isOutcome(parsed)) return parsed
  const { repoPath } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    {
      const authArgs = await authArgsFor(deps)
      await fetchAll(deps.exec, facts.repoRoot, accelPrefix(deps), authArgs, networkOptions(deps, facts.repoRoot, authArgs))
    }
    const result: FetchResult = { remote: 'all' }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /update 鈥?update the CURRENT checkout: fetch every remote, then
 * fast-forward the branch checked out by the queried directory to its
 * upstream. Divergence, a missing upstream, and conflicting working-tree
 * changes all surface as 400 envelopes carrying git's own explanation.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handleUpdate(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<UpdateBody>(body, ['repoPath'])
  if (isOutcome(parsed)) return parsed
  const { repoPath } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    // The session's OWN worktree, not the main checkout: in a linked-worktree
    // session "update current branch" means the branch that worktree holds.
    // `repoRoot` would fast-forward the main checkout behind the user's back
    // (both are the same directory when the session IS the main checkout).
    const outcome = await updateBranch(deps.exec, facts.toplevel, accelPrefix(deps), await authArgsFor(deps))
    const result: UpdateResult = { branch: outcome.branch, updated: outcome.updated }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /push 鈥?push the branch checked out by the queried directory to its
 * upstream. A missing upstream and a diverged remote surface as 400
 * envelopes carrying git's own explanation; `--force` is never passed.
 * @param deps - host dependencies.
 * @param body - parsed request body.
 */
export async function handlePush(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<PushBody>(body, ['repoPath'])
  if (isOutcome(parsed)) return parsed
  const { repoPath } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    // The session's OWN worktree, not the main checkout: in a linked-worktree
    // session "push current branch" means the branch that worktree holds.
    const authArgs = await authArgsFor(deps)
    const outcome = await pushBranch(deps.exec, facts.toplevel, authArgs, networkOptions(deps, facts.toplevel, authArgs))
    const result: PushResult = { branch: outcome.branch, pushed: outcome.pushed, ...(outcome.note === undefined ? {} : { note: outcome.note }) }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /inspect — pre-delete facts for one worktree directory: the
 * uncommitted-file count (those die with the folder) and the checked-out
 * branch's ahead count (kept — the branch ref survives the removal).
 * Deliberately repo-wide neutral: any directory inside a repository answers,
 * so the dialog data stays meaningful even for odd shapes.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path }`.
 */
export async function handleInspectWorktree(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<InspectWorktreeBody>(body, ['path'])
  if (isOutcome(parsed)) return parsed
  const { path } = parsed
  if (!isAbsoluteDir(path)) return fail(400, '"path" must be an absolute directory')
  try {
    const facts = await probeRepo(deps.exec, path, deps.dirExists)
    if (facts === undefined) return fail(400, `"${path}" is not inside a git repository`)
    const inspected = await inspectWorktree(deps.exec, path)
    const result: InspectWorktreeResult = { dirty: inspected.dirty, ...inspected.ahead === undefined ? {} : { ahead: inspected.ahead } }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /remove — delete one linked worktree: git's registration plus the
 * folder in one stroke (`worktree remove`, `--force` past uncommitted
 * changes the dialog already showed). DSH-side cleanup (archiving the
 * workspace's sessions, dropping the workspace registration) is the
 * browser's follow-up, by design: git first, so a refused removal leaves
 * the workspace world untouched.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path, force? }`.
 */
export async function handleRemoveWorktree(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<RemoveWorktreeBody>(body, ['path'], ['force'])
  if (isOutcome(parsed)) return parsed
  const { path, force } = parsed
  if (!isAbsoluteDir(path)) return fail(400, '"path" must be an absolute directory')
  try {
    const facts = await probeRepo(deps.exec, path, deps.dirExists)
    if (facts === undefined) return fail(400, `"${path}" is not inside a git repository`)
    const result = await removeWorktree(deps.exec, facts.repoRoot, path, force === true, deps.dirExists)
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /exists — batch directory-existence probe over plain fs (no git): true
 * per path that exists AND is a directory. The browser gates the
 * register-as-workspace action on this, so a missing folder (deleted, moved,
 * or a corrupted session-header cwd) is answered by THIS route — the DSH
 * workspace API never sees an unregistrable path.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ paths }`.
 */
export async function handlePathExists(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return fail(400, 'request body must be a JSON object')
  const paths = (body as Record<string, unknown>).paths
  if (!Array.isArray(paths)) return fail(400, 'body key "paths" must be an array of absolute directories')
  const unknownKeys = Object.keys(body as Record<string, unknown>).filter(key => key !== 'paths')
  if (unknownKeys.length > 0) return fail(400, `unknown body key "${unknownKeys[0]}"`)
  const distinct: string[] = []
  for (const candidate of paths) {
    if (typeof candidate !== 'string' || !isAbsoluteDir(candidate)) return fail(400, 'body key "paths" must be an array of absolute directories')
    if (!distinct.includes(candidate)) distinct.push(candidate)
  }
  if (distinct.length > GROUP_PATHS_LIMIT) return fail(400, `body key "paths" accepts at most ${String(GROUP_PATHS_LIMIT)} distinct directories`)
  const statDirectory = deps.statDirectory ?? fsStatDirectory
  const exists: PathExistsResult['exists'] = {}
  await Promise.all(distinct.map(async (path) => {
    // One bad path must not sink the batch: a probe that throws reads as
    // "not a directory" — exactly the gating answer the client needs.
    exists[path] = await statDirectory(path).catch(() => false)
  }))
  // Rebuildability is a STORAGE-SLOT fact, not a general one: only a missing
  // path sitting DIRECTLY inside one of the plugin's storage locations (the
  // legacy root, or a repository's `.dsh/gitworktree`) is a slot this plugin
  // planned, so recreating the empty directory is safe self-healing (its
  // sessions reattach by realpath once the folder is back). Paths outside
  // both are the user's own territory — never rebuilt here.
  const rootDir = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  const dirExists = deps.dirExists ?? fsDirExists
  const rebuildable: PathExistsResult['rebuildable'] = {}
  for (const path of distinct) {
    if (exists[path]) continue
    rebuildable[path] = dirname(resolve(path)) === resolve(rootDir) || insideProjectLayout(resolve(path), dirExists)
  }
  return { status: 200, body: { exists, ...Object.values(rebuildable).some(Boolean) ? { rebuildable } : {} } }
}

/**
 * POST /ensure-directory — recreate a MISSING worktree storage slot
 * (`mkdir -p`). Strictly gated to paths sitting DIRECTLY inside one of the
 * plugin's two storage layouts (the legacy central root, or a repository's
 * `.dsh/gitworktree`): those slots were planned and created by this plugin,
 * so rebuilding the empty folder is self-healing (historical sessions
 * reattach automatically once realpath matches again — DSH keeps the
 * workspace accounting and filters membership by the session header's cwd).
 * Anything else is outside this plugin's territory and is refused, so a
 * corrupted session-header cwd can never be materialized as stray folders.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ path }`.
 */
export async function handleEnsureDirectory(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<EnsureDirectoryBody>(body, ['path'])
  if (isOutcome(parsed)) return parsed
  const { path } = parsed
  if (!isAbsoluteDir(path)) return fail(400, '"path" must be an absolute directory')
  const configured = deps.sectionRootDir()?.trim()
  if (configured !== undefined && configured !== '' && !isAbsoluteConfigPath(configured)) {
    return fail(400, `configured rootDir "${String(deps.sectionRootDir())}" is not an absolute path`)
  }
  const rootDir = resolveRootDir(deps.sectionRootDir(), deps.home(), deps.envHome())
  const canonical = resolve(path)
  // Exactly one level below a storage location, compared on resolved forms
  // so `..` and spelling drift cannot escape the slot boundary.
  if (dirname(canonical) !== resolve(rootDir) && !insideProjectLayout(canonical, deps.dirExists ?? fsDirExists)) {
    return fail(400, `"${canonical}" is outside the plugin's worktree storage locations`)
  }
  const mkdirRecursive = deps.mkdirRecursive ?? fsMkdirRecursive
  try {
    const statDirectory = deps.statDirectory ?? fsStatDirectory
    if (await statDirectory(canonical)) return { status: 200, body: { created: true } }
    await mkdirRecursive(canonical)
    return { status: 200, body: { created: true } }
  } catch (error) {
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/* ------------------------------------------------------------------ *
 * Git panel routes: working tree, staging, commit, history, AI message.
 * All of them act on the QUERIED checkout (repoPath = any directory inside
 * it), so a linked-worktree session reads and mutates its own worktree.
 * ------------------------------------------------------------------ */

/** Upper bound on paths one /stage request accepts. */
const STAGE_PATHS_LIMIT = 500

/** Upper bound on the rows one /changes answer lists; a busier working tree
 * is flagged `truncated` instead of flooding the panel. */
export const CHANGES_ROWS_LIMIT = 500

/** Common validation: `{ repoPath }`-shaped bodies and their checkout directory. */
function readRepoPath(parsed: { repoPath: string } | RouteOutcome): string | RouteOutcome {
  if (isOutcome(parsed)) return parsed
  if (!isAbsoluteDir(parsed.repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  return parsed.repoPath
}

/** Map a git failure on the queried checkout to the uniform 400 envelope. */
function checkoutFailure(error: unknown): RouteOutcome {
  const message = error instanceof Error ? error.message : String(error)
  return fail(400, message)
}

/**
 * POST /changes — the queried checkout's working-tree rows (staged,
 * unstaged, untracked), straight from `git status --porcelain=v1 -z`,
 * capped at {@link CHANGES_ROWS_LIMIT} rows (`truncated` flags the cut).
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath }`.
 */
export async function handleChanges(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<ChangesBody>(body, ['repoPath'])
  if (isOutcome(parsed)) return parsed
  const repoPath = readRepoPath(parsed)
  if (typeof repoPath !== 'string') return repoPath
  try {
    const { changes } = await workingChanges(deps.exec, repoPath)
    if (changes.length > CHANGES_ROWS_LIMIT) {
      return { status: 200, body: { changes: changes.slice(0, CHANGES_ROWS_LIMIT), truncated: true } }
    }
    return { status: 200, body: { changes } }
  } catch (error) {
    return checkoutFailure(error)
  }
}

/**
 * POST /stage — stage (`git add`) or unstage (`git reset -q HEAD --`) the
 * given relative paths of the queried checkout. Paths must be relative,
 * `..`-free, and bounded ({@link STAGE_PATHS_LIMIT}); they are passed to git
 * as execFile arguments, never through a shell.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath, paths, stage }`.
 */
export async function handleStage(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return fail(400, 'request body must be a JSON object')
  const record = body as Record<string, unknown>
  for (const key of Object.keys(record)) {
    if (key !== 'repoPath' && key !== 'paths' && key !== 'stage') return fail(400, `unknown body key "${key}"`)
  }
  const repoPathRaw = record.repoPath
  if (typeof repoPathRaw !== 'string' || !isAbsoluteDir(repoPathRaw)) return fail(400, '"repoPath" must be an absolute directory')
  if (record.stage !== true && record.stage !== false) return fail(400, 'body key "stage" must be a boolean')
  const paths = record.paths
  if (!Array.isArray(paths) || !paths.every(item => typeof item === 'string')) {
    return fail(400, 'body key "paths" must be an array of relative paths')
  }
  if (paths.length === 0) return fail(400, 'body key "paths" must not be empty')
  if (paths.length > STAGE_PATHS_LIMIT) return fail(400, `body key "paths" accepts at most ${String(STAGE_PATHS_LIMIT)} paths`)
  const bad = paths.find(path => !isStageablePath(path))
  if (bad !== undefined) return fail(400, `"${bad}" is not a stageable relative path`)
  try {
    await stagePaths(deps.exec, repoPathRaw, paths, record.stage)
    return { status: 200, body: { staged: true } }
  } catch (error) {
    return checkoutFailure(error)
  }
}

/** Upper bound for one commit message (characters): the shared wire constant,
 * so the client's input cap and this rejection can never drift apart. */

/**
 * POST /commit — commit the queried checkout's index (`git commit -m`).
 * Hooks run as usual; an empty index is git's own refusal, surfaced verbatim.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath, message }`.
 */
export async function handleCommit(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CommitBody>(body, ['repoPath', 'message'])
  if (isOutcome(parsed)) return parsed
  const repoPath = readRepoPath(parsed)
  if (typeof repoPath !== 'string') return repoPath
  const message = parsed.message
  if (message.trim() === '') return fail(400, '"message" must not be blank')
  if (message.length > COMMIT_MESSAGE_LIMIT) return fail(400, `"message" accepts at most ${String(COMMIT_MESSAGE_LIMIT)} characters`)
  try {
    const result = await commitIndex(deps.exec, repoPath, message)
    return { status: 200, body: result }
  } catch (error) {
    return checkoutFailure(error)
  }
}

/** Default and maximum page size of POST /log. */
export const LOG_LIMIT_DEFAULT = 50
export const LOG_LIMIT_MAX = 200

/** Bound for the author filter and the tag annotation (characters). */
const LOG_AUTHOR_LIMIT = 200
const TAG_MESSAGE_LIMIT = 5000
/** Bound for one tag NAME (characters), shared by create and push. */
const TAG_NAME_LIMIT = 300

/**
 * POST /log — one page of the queried checkout's history. The optional `ref`
 * is verified server-side (`rev-parse --verify`), an unborn checkout answers
 * an empty page, and everything else surfaces git's own stderr.
 *
 * `all` walks every ref instead of HEAD (the history card's default view: one
 * graph holding all branches, tags, and their merge edges). `author` and the
 * `since`/`until` window are pushed down to git rather than filtered in the
 * browser — the card paginates, so a client-side filter would only narrow the
 * page it already has and silently hide matches on later pages.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath, limit?, skip?, ref?, all?, author?, since?, until? }`.
 */
export async function handleLog(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<LogBody>(body, ['repoPath'], ['all'], ['ref', 'author'], ['limit', 'skip', 'since', 'until'])
  if (isOutcome(parsed)) return parsed
  const repoPath = readRepoPath(parsed)
  if (typeof repoPath !== 'string') return repoPath
  const limit = parsed.limit ?? LOG_LIMIT_DEFAULT
  const skip = parsed.skip ?? 0
  if (!Number.isInteger(limit) || limit < 1 || limit > LOG_LIMIT_MAX) {
    return fail(400, `"limit" must be an integer between 1 and ${String(LOG_LIMIT_MAX)}`)
  }
  if (!Number.isInteger(skip) || skip < 0) return fail(400, '"skip" must be an integer >= 0')
  const ref = parsed.ref
  if (ref !== undefined && (ref.trim() === '' || ref.length > 300 || ref.startsWith('-'))) {
    return fail(400, '"ref" must be a non-empty revision name')
  }
  const author = parsed.author
  if (author !== undefined && (author.trim() === '' || author.length > LOG_AUTHOR_LIMIT)) {
    return fail(400, `"author" must be a non-empty string of at most ${String(LOG_AUTHOR_LIMIT)} characters`)
  }
  const since = parsed.since
  const until = parsed.until
  for (const [key, value] of [['since', since], ['until', until]] as const) {
    if (value !== undefined && (!Number.isFinite(value) || value <= 0)) {
      return fail(400, `"${key}" must be a positive epoch-millisecond timestamp`)
    }
  }
  if (since !== undefined && until !== undefined && until < since) {
    return fail(400, '"until" must not be earlier than "since"')
  }
  try {
    const commits = await logHistory(deps.exec, repoPath, limit, skip, ref, {
      all: parsed.all === true,
      ...(author === undefined ? {} : { author }),
      ...(since === undefined ? {} : { since }),
      ...(until === undefined ? {} : { until }),
    })
    return { status: 200, body: { commits } }
  } catch (error) {
    return checkoutFailure(error)
  }
}

/**
 * POST /tag — create a tag at an existing commit of the queried repository.
 * The target is restricted to a commit hash (the only shape the history card
 * sends), so an arbitrary string can never reach `git tag` as a flag; git
 * validates the tag name itself and a duplicate surfaces as 400.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath, name, target?, message? }`.
 */
export async function handleCreateTag(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CreateTagBody>(body, ['repoPath', 'name'], [], ['target', 'message'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, name, target, message } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (name.trim() === '') return fail(400, '"name" must be non-empty')
  // A leading dash would ride `git tag` as a flag — reject before the exec.
  if (name.startsWith('-')) return fail(400, '"name" must not start with "-"')
  if (name.length > TAG_NAME_LIMIT) return fail(400, `"name" must be at most ${String(TAG_NAME_LIMIT)} characters`)
  // The target lands on `git tag <name> <target>` verbatim: restrict it to the
  // object id shape the history card sends rather than trusting a free string.
  if (target !== undefined && !/^[0-9a-fA-F]{4,64}$/.test(target)) {
    return fail(400, '"target" must be a git object id')
  }
  if (message !== undefined && message.length > TAG_MESSAGE_LIMIT) {
    return fail(400, `"message" must be at most ${String(TAG_MESSAGE_LIMIT)} characters`)
  }
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    // Tag refs are repository-wide metadata and touch no checkout, so the
    // command runs at the repository root — the same scope as a branch rename.
    const result = await createTag(deps.exec, facts.repoRoot, name, target, message)
    const body: CreateTagResult = result
    return { status: 200, body }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /tag-push — publish ONE existing local tag to a remote. Separate from
 * `POST /push` on purpose: a branch push sends the branch alone, so a tag on
 * an already-pushed commit needs its own verb.
 *
 * The name must match a LOCAL tag this repository actually has (checked
 * against `for-each-ref refs/tags`), so no free string ever reaches git as a
 * flag or a refspec; the remote is resolved server-side and an ambiguous
 * choice is 400. A remote that already carries the same tag object answers
 * `pushed: false` (nothing was sent); a diverged remote tag is git's own
 * refusal, mapped to 400 by {@link gitFailure} — never forced.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath, name }`.
 */
export async function handlePushTag(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<PushTagBody>(body, ['repoPath', 'name'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, name } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (name.trim() === '') return fail(400, '"name" must be non-empty')
  // A leading dash would ride `git push` as a flag — reject before the exec.
  if (name.startsWith('-')) return fail(400, '"name" must not start with "-"')
  if (name.length > TAG_NAME_LIMIT) return fail(400, `"name" must be at most ${String(TAG_NAME_LIMIT)} characters`)
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    // The push runs at the queried directory's own toplevel, so the remote is
    // the one ITS checked-out branch tracks (a linked worktree publishes the
    // remote its own branch knows); tags themselves are repository-wide.
    const tags = await listTagNames(deps.exec, facts.toplevel)
    if (!tags.includes(name)) return fail(400, `"${name}" is not a local tag`)
    const choice = await resolvePushRemote(deps.exec, facts.toplevel)
    if (!choice.ok) return fail(400, choice.message)
    const authArgs = await authArgsFor(deps)
    const result = await pushTag(deps.exec, facts.toplevel, name, choice.remote, authArgs, networkOptions(deps, facts.toplevel, authArgs))
    const body: PushTagResult = { ...result, ...(result.note === undefined ? {} : { note: result.note }) }
    return { status: 200, body }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /commit-files — the files one commit of the queried checkout changed.
 * The hash is verified server-side; unknown revisions answer 400.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath, hash }`.
 */
export async function handleCommitFiles(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CommitFilesBody>(body, ['repoPath', 'hash'])
  if (isOutcome(parsed)) return parsed
  const repoPath = readRepoPath(parsed)
  if (typeof repoPath !== 'string') return repoPath
  const hash = parsed.hash
  if (!/^[0-9a-fA-F]{4,64}$/.test(hash)) return fail(400, '"hash" must be a git object id')
  try {
    const files = await commitFiles(deps.exec, repoPath, hash)
    return { status: 200, body: { hash, files } }
  } catch (error) {
    return checkoutFailure(error)
  }
}

/** Narrow face of the host llm runtime the AI route needs. The service is
 * registered by the dsh-llm host plugin; the panel mounts this route only
 * where that injection resolves. Message content is the model-facing BLOCK
 * list (a plain string is rejected), and visible text arrives only as
 * `text-delta` chunks (reasoning deltas carry text too and must not fold). */
export interface LlmStreamRuntime {
  stream(options: {
    provider: string
    model: string
    reasoningEffort?: string
    messages: ReadonlyArray<{ role: 'user'; content: ReadonlyArray<{ type: 'text'; text: string }> }>
    system?: string
    temperature?: number
    maxTokens?: number
  }): AsyncIterable<{ type: string; text?: string }>
}

/** Bound for the AI-generated message (characters). */
const AI_MESSAGE_LIMIT = 2000

/**
 * POST /ai-commit-message — generate a commit message from the checkout's
 * diff with ONE one-shot llm call. The model route (provider/model/effort)
 * arrives from the requesting session's own selection, so the generation uses
 * the model the user is already talking to; the diff is truncated and the
 * reply folded to plain text.
 * @param deps - host dependencies.
 * @param llm - the resolved llm runtime (the route is mounted only with one).
 * @param body - parsed request body: `{ repoPath, provider, model, effort?, hint? }`.
 */
export async function handleAiCommitMessage(deps: RouteDeps, llm: LlmStreamRuntime, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<AiCommitMessageBody>(body, ['repoPath', 'provider', 'model'], [], ['effort', 'hint'])
  if (isOutcome(parsed)) return parsed
  const repoPath = readRepoPath(parsed)
  if (typeof repoPath !== 'string') return repoPath
  if (parsed.provider.trim() === '' || parsed.model.trim() === '') {
    return fail(400, '"provider" and "model" must be non-empty')
  }
  if (parsed.hint !== undefined && parsed.hint.length > 2000) return fail(400, '"hint" accepts at most 2000 characters')
  try {
    const { diff, recentSubjects, staged } = await collectAiDiff(deps.exec, repoPath)
    if (diff.trim() === '') return fail(400, 'no changes to describe (the working tree and index are clean)')
    const style = recentSubjects.length > 0
      ? `Recent commit subjects of this repository (follow their language and style):\n${recentSubjects.map(subject => `- ${subject}`).join('\n')}`
      : ''
    const userText = [
      `Generate a git commit message for the ${staged ? 'staged' : 'working-tree'} changes below.`,
      style,
      parsed.hint === undefined ? undefined : `User hint (rewrite or style request): ${parsed.hint}`,
      'Diff:',
      diff,
    ].filter(part => part !== undefined).join('\n\n')
    let text = ''
    for await (const chunk of llm.stream({
      provider: parsed.provider,
      model: parsed.model,
      ...(parsed.effort === undefined || parsed.effort === '' ? {} : { reasoningEffort: parsed.effort }),
      messages: [{ role: 'user', content: [{ type: 'text', text: userText }] }],
      system: 'You write git commit messages. Reply with the message ONLY: one conventional-commit subject line (matching the repository language), optionally followed by a blank line and a short body of bullet points. No explanations, no markdown fences.',
      temperature: 0.2,
      maxTokens: 500,
    })) {
      if (chunk.type === 'text-delta') text += chunk.text ?? ''
    }
    text = text.replace(/^```[a-z]*\n?|```\n?$/g, '').trim()
    if (text === '') return fail(502, 'the model returned an empty message')
    if (text.length > AI_MESSAGE_LIMIT) text = text.slice(0, AI_MESSAGE_LIMIT)
    return { status: 200, body: { message: text } }
  } catch (error) {
    return checkoutFailure(error)
  }
}

/** Masked browser view: the stored secret never crosses the wire again. */
function credentialView(entry: GitCredential): CredentialEntryView {
  return {
    host: entry.host,
    username: entry.username,
    method: entry.method,
    updatedAt: entry.updatedAt,
    secretMask: maskSecret(entry.secret),
  }
}

/** Credential-store failures are host-side state (an unreadable/corrupt file,
 * a failed write), so they answer 500 with the file's own explanation. */
function storeFailure(error: unknown): RouteOutcome {
  return fail(500, error instanceof Error ? error.message : String(error))
}

/**
 * POST /credentials — every stored credential as a MASKED row. One row per
 * host: the store is global (not per repository), so the panel edits one
 * address for github.com, gitlab.com, a self-hosted gitea alike.
 * @param deps - host dependencies.
 * @param body - parsed request body: absent or `{}`.
 */
export async function handleCredentials(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<Record<string, never>>(body ?? {}, [])
  if (isOutcome(parsed)) return parsed
  try {
    const entries = await credentialStore(deps).load()
    const result: CredentialsResult = { credentials: sortCredentials(entries).map(credentialView) }
    return { status: 200, body: result }
  } catch (error) {
    return storeFailure(error)
  }
}

/**
 * POST /credentials-save — create or update the credential of ONE host. A
 * blank `secret` on an existing host keeps the stored secret (the browser
 * only ever had the mask), while a new host requires one.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ host, username, method, secret? }`.
 */
export async function handleCredentialsSave(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CredentialSaveBody>(body, ['host', 'username', 'method'], [], ['secret'])
  if (isOutcome(parsed)) return parsed
  const host = normalizeCredentialHost(parsed.host)
  if (host === undefined) {
    return fail(400, credentialHostIssue(parsed.host) === 'empty'
      ? '"host" must be non-empty'
      : '"host" must be a remote host such as github.com')
  }
  if (parsed.method !== 'token' && parsed.method !== 'password') {
    return fail(400, '"method" must be "token" or "password"')
  }
  const username = parsed.username.trim()
  const usernameIssue = credentialUsernameIssue(username, parsed.method)
  if (usernameIssue !== undefined) {
    return fail(400, usernameIssue === 'empty'
      ? '"username" is required for "password" credentials'
      : '"username" must not contain control characters')
  }
  try {
    const store = credentialStore(deps)
    const entries = await store.load()
    const existing = entries.find(entry => entry.host === host)
    const typed = parsed.secret === undefined ? '' : parsed.secret.trim()
    let secret: string
    if (typed !== '') secret = typed
    else if (existing !== undefined) secret = existing.secret
    else return fail(400, '"secret" is required for a new host')
    const secretIssue = credentialSecretIssue(secret)
    if (secretIssue !== undefined) {
      return fail(400, secretIssue === 'empty'
        ? '"secret" must be non-empty'
        : '"secret" must not contain control characters')
    }
    const next = upsertCredential(entries, {
      host,
      username,
      secret,
      method: parsed.method,
      updatedAt: Date.now(),
    })
    await store.save(next)
    await refreshBridge(deps)
    const result: CredentialsResult = { credentials: sortCredentials(next).map(credentialView) }
    return { status: 200, body: result }
  } catch (error) {
    return storeFailure(error)
  }
}

/**
 * POST /credentials-delete — forget ONE host's credential. The other hosts
 * keep theirs: deletion is per host, never a store reset.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ host }`.
 */
export async function handleCredentialsDelete(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CredentialDeleteBody>(body, ['host'])
  if (isOutcome(parsed)) return parsed
  const host = normalizeCredentialHost(parsed.host)
  if (host === undefined) return fail(400, '"host" must be a remote host such as github.com')
  try {
    const store = credentialStore(deps)
    const entries = await store.load()
    const next = removeCredential(entries, host)
    if (next.length === entries.length) return fail(400, `no credential is stored for "${host}"`)
    await store.save(next)
    await refreshBridge(deps)
    const result: CredentialsResult = { credentials: sortCredentials(next).map(credentialView) }
    return { status: 200, body: result }
  } catch (error) {
    return storeFailure(error)
  }
}

/**
 * POST /credentials-import — copy what the machine's own credential helpers
 * already answer for into the managed store, so a machine signed in through
 * gh/GCM/Keychain stops needing a second sign-in here (decision 0038).
 *
 * The candidates are the URL-scoped hosts of the user's gitconfig; a host the
 * panel already manages is skipped (the panel wins), and a host whose helper
 * answers nothing is reported per host instead of failing the whole request.
 * @param deps - host dependencies.
 * @param body - parsed request body: absent, `{}` or `{ hosts?: string[] }`.
 */
export async function handleCredentialsImport(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const record: unknown = body ?? {}
  if (typeof record !== 'object' || record === null || Array.isArray(record)) {
    return fail(400, 'request body must be a JSON object')
  }
  const fields = record as Record<string, unknown>
  for (const key of Object.keys(fields)) {
    if (key !== 'hosts') return fail(400, `unknown body key "${key}"`)
  }
  const rawHosts = fields.hosts
  let hosts: string[] | undefined
  if (rawHosts !== undefined) {
    if (!Array.isArray(rawHosts) || rawHosts.some(value => typeof value !== 'string')) {
      return fail(400, '"hosts" must be an array of remote hosts')
    }
    hosts = (rawHosts as string[]).map(value => value.trim()).filter(value => value !== '')
    if (hosts.length === 0) return fail(400, '"hosts" must not be empty')
  }
  try {
    const store = credentialStore(deps)
    const importNow = deps.importLocalCredentials ?? ((target: CredentialStore, wanted?: readonly string[]) => runLocalImport(target, {}, wanted))
    const report = await importNow(store, hosts)
    if (report.imported.length > 0) await refreshBridge(deps)
    const entries = await store.load()
    const result: CredentialImportResult = {
      credentials: sortCredentials(entries).map(credentialView),
      imported: report.imported,
      skipped: report.skipped,
      failed: report.failed,
    }
    return { status: 200, body: result }
  } catch (error) {
    return storeFailure(error)
  }
}

/** The HTTP seam: the wired fake in tests, global fetch in production. */
function fetchFor(deps: RouteDeps): typeof fetch {
  return deps.fetchImpl ?? globalThis.fetch
}

/**
 * POST /credentials-oauth-start — start a browser sign-in for ONE host
 * (GitHub device flow). The answer carries a one-time user code and the
 * polling credential; the dialog opens the verification page and polls
 * /credentials-oauth-poll until the user approves.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ host }`.
 */
export async function handleCredentialsOAuthStart(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CredentialOAuthStartBody>(body, ['host'])
  if (isOutcome(parsed)) return parsed
  const host = normalizeCredentialHost(parsed.host)
  if (host === undefined) {
    return fail(400, credentialHostIssue(parsed.host) === 'empty'
      ? '"host" must be non-empty'
      : '"host" must be a remote host such as github.com')
  }
  if (!isDeviceFlowHost(host)) return fail(400, `browser sign-in is not available for "${host}"`)
  try {
    const grant = await startDeviceFlow(fetchFor(deps), host, deviceFlowClientId())
    const result: CredentialOAuthStartResult = {
      userCode: grant.userCode,
      verificationUri: grant.verificationUri,
      ...(grant.verificationUriComplete === undefined ? {} : { verificationUriComplete: grant.verificationUriComplete }),
      deviceCode: grant.deviceCode,
      intervalSeconds: grant.intervalSeconds,
      expiresInSeconds: grant.expiresInSeconds,
    }
    return { status: 200, body: result }
  } catch (error) {
    return fail(502, `could not start the browser sign-in: ${error instanceof Error ? error.message : String(error)}`)
  }
}

/**
 * POST /credentials-oauth-poll — one poll of a started browser sign-in.
 * A pending grant answers `{ status: 'pending' }` so the dialog keeps
 * waiting; an approved grant is stored as a `token` credential for the host
 * (the token itself never crosses the wire again) and the fresh masked list
 * comes back.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ host, deviceCode }`.
 */
export async function handleCredentialsOAuthPoll(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<CredentialOAuthPollBody>(body, ['host', 'deviceCode'])
  if (isOutcome(parsed)) return parsed
  const host = normalizeCredentialHost(parsed.host)
  if (host === undefined) return fail(400, '"host" must be a remote host such as github.com')
  if (!isDeviceFlowHost(host)) return fail(400, `browser sign-in is not available for "${host}"`)
  const deviceCode = parsed.deviceCode.trim()
  if (deviceCode === '') return fail(400, '"deviceCode" must be non-empty')
  let poll: DeviceFlowPoll
  try {
    poll = await pollDeviceFlow(fetchFor(deps), host, deviceFlowClientId(), deviceCode)
  } catch (error) {
    return fail(502, `could not poll the browser sign-in: ${error instanceof Error ? error.message : String(error)}`)
  }
  if (poll.status === 'pending') {
    const waiting: CredentialOAuthPollResult = { status: 'pending' }
    return { status: 200, body: waiting }
  }
  if (poll.status === 'slow_down') {
    const backoff: CredentialOAuthPollResult = { status: 'slow_down' }
    return { status: 200, body: backoff }
  }
  if (poll.status === 'network') {
    // Not a failure: the grant is untouched, so the dialog retries instead of
    // throwing away a sign-in the user may already have approved. The client
    // decides when repeated failures become an error.
    const retry: CredentialOAuthPollResult = { status: 'network', message: poll.message }
    return { status: 200, body: retry }
  }
  if (poll.status !== 'token') return fail(400, poll.message)
  const secretIssue = credentialSecretIssue(poll.token)
  if (secretIssue !== undefined) return fail(502, 'the sign-in returned an unusable token')
  try {
    const store = credentialStore(deps)
    const entries = await store.load()
    const next = upsertCredential(entries, {
      host,
      username: '',
      secret: poll.token,
      method: 'token',
      updatedAt: Date.now(),
    })
    await store.save(next)
    await refreshBridge(deps)
    const done: CredentialOAuthPollResult = { status: 'done', credentials: sortCredentials(next).map(credentialView) }
    return { status: 200, body: done }
  } catch (error) {
    return storeFailure(error)
  }
}

/** Human message for a rejected remote NAME. */
function remoteNameMessage(issue: RemoteNameIssue): string {
  if (issue === 'empty') return '"name" must be non-empty'
  if (issue === 'leadingDash') return '"name" must not start with "-"'
  return '"name" may only contain letters, digits, ".", "_" and "-"'
}

/** Human message for a rejected remote URL. */
function remoteUrlMessage(issue: RemoteUrlIssue): string {
  if (issue === 'empty') return '"url" must be non-empty'
  if (issue === 'whitespace') return '"url" must not contain whitespace'
  return '"url" must be an address git accepts (https://..., git@host:path or an absolute path)'
}

/** Actions one /remote call may take. */
const REMOTE_ACTIONS: readonly RemoteAction[] = ['add', 'set-url', 'remove']

/**
 * POST /remotes — the repository's configured remotes with their fetch and
 * push URLs. Remotes belong to the repository, not to a worktree, so any
 * directory inside it answers the full list.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath }`.
 */
export async function handleRemotes(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<RemotesBody>(body, ['repoPath'])
  if (isOutcome(parsed)) return parsed
  const { repoPath } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    const remotes = await listRemotes(deps.exec, facts.repoRoot)
    const result: RemotesResult = { remotes }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * POST /remote — add, re-point or remove ONE remote, then answer the fresh
 * list. Existence is checked against `git remote -v` first, so a duplicate
 * `add` and a missing `set-url`/`remove` answer a clean 400 instead of git's
 * stderr; the URL is pre-flighted by {@link remoteUrlIssue}.
 * @param deps - host dependencies.
 * @param body - parsed request body: `{ repoPath, action, name, url? }`.
 */
export async function handleRemote(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<RemoteMutationBody>(body, ['repoPath', 'action', 'name'], [], ['url'])
  if (isOutcome(parsed)) return parsed
  const { repoPath, action, name } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  if (!REMOTE_ACTIONS.includes(action)) return fail(400, '"action" must be "add", "set-url" or "remove"')
  const nameIssue = remoteNameIssue(name)
  if (nameIssue !== null) return fail(400, remoteNameMessage(nameIssue))
  const url = parsed.url === undefined ? '' : parsed.url.trim()
  if (action !== 'remove') {
    const urlIssue = remoteUrlIssue(url)
    if (urlIssue !== undefined) return fail(400, remoteUrlMessage(urlIssue))
  }
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, `"${repoPath}" is not inside a git repository`)
    const before = await listRemotes(deps.exec, facts.repoRoot)
    const exists = before.some(remote => remote.name === name)
    if (action === 'add') {
      if (exists) return fail(400, `remote "${name}" already exists`)
      await addRemote(deps.exec, facts.repoRoot, name, url)
    } else if (!exists) {
      return fail(400, `remote "${name}" does not exist`)
    } else if (action === 'set-url') {
      await setRemoteUrl(deps.exec, facts.repoRoot, name, url)
    } else {
      await removeRemote(deps.exec, facts.repoRoot, name)
    }
    const remotes = await listRemotes(deps.exec, facts.repoRoot)
    const result: RemotesResult = { remotes }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    return fail(500, error instanceof Error ? error.message : String(error))
  }
}

/**
 * Report which network channel can read the repository's endpoint right now.
 *
 * Diagnostics only: nothing here writes to git or to the config. Each
 * channel gets its own budget (PROBE_TIMEOUT_MS), so a dead proxy costs one
 * timeout and the answer still names the channels that work. The system
 * proxy is reported when the plugin has none of its own — git ignores
 * WinINET, so a value here is a suggestion the user must opt into (0043).
 * @param deps - route dependencies (exec, channel providers, config readers).
 * @param body - `{ repoPath }`.
 * @returns one report per channel, in the order the write path would try them.
 */
export async function handleNetworkProbe(deps: RouteDeps, body: unknown): Promise<RouteOutcome> {
  const parsed = readBody<NetworkProbeBody>(body, ['repoPath'])
  if (isOutcome(parsed)) return parsed
  const { repoPath } = parsed
  if (!isAbsoluteDir(repoPath)) return fail(400, '"repoPath" must be an absolute directory')
  try {
    const facts = await probeRepo(deps.exec, repoPath, deps.dirExists)
    if (facts === undefined) return fail(400, JSON.stringify(repoPath) + " is not inside a git repository")
    const authArgs = await authArgsFor(deps)
    const url = await probeEndpoint(deps.exec, facts.repoRoot, authArgs)
    if (url === undefined) return fail(400, '"repoPath" has no remote to probe')
    const channels = [await channelReport(deps.exec, facts.repoRoot, 'direct', url, [], authArgs)]
    for (const provider of deps.networkChannels?.(deps.exec, facts.repoRoot, authArgs) ?? []) {
      const argv = await provider(url)
      if (argv === undefined || argv.length === 0) continue
      const channel: NetworkChannelId = argv.some(item => item.startsWith('http.proxy=')) ? 'proxy' : 'ip'
      if (channels.some(report => report.channel === channel)) continue
      channels.push(await channelReport(deps.exec, facts.repoRoot, channel, url, argv, authArgs))
    }
    const systemProxy = await deps.sectionSystemProxy?.()
    const result: NetworkProbeResult = {
      url,
      channels,
      ...(systemProxy === undefined || systemProxy === '' ? {} : { systemProxy }),
    }
    return { status: 200, body: result }
  } catch (error) {
    if (error instanceof GitError) return gitFailure(error)
    throw error
  }
}

/**
 * The endpoint a probe should read: the upstream's push URL when the branch
 * tracks one, otherwise the push URL of `origin` (or the first remote).
 * @param exec - executor seam.
 * @param cwd - any directory inside the repository.
 * @param authArgs - credential argv for the host.
 * @returns the URL, or undefined when the repository has no remote at all.
 */
async function probeEndpoint(exec: Exec, cwd: string, authArgs: readonly string[]): Promise<string | undefined> {
  const target = await resolvePushTarget(exec, cwd, authArgs)
  if (target?.url !== undefined && target.url !== '') return target.url
  const remotes = await listRemotes(exec, cwd)
  const chosen = remotes.find(remote => remote.name === 'origin') ?? remotes[0]
  if (chosen === undefined) return undefined
  const url = chosen.pushUrl !== '' ? chosen.pushUrl : chosen.fetchUrl
  return url === '' ? undefined : url
}
