/**
 * Shared wire contract between the host half (HTTP routes under
 * `/plugin/git-worktree`) and the browser half (chip + plugin settings card).
 * Zero runtime dependencies: constants and types only, imported by both
 * builds.
 */

/** Absolute pathname prefix every route of this plugin lives under. */
export const ROUTE_PREFIX = '/plugin/git-worktree'

/** GET ROUTE_PREFIX/status?path=<absolute dir> */
export const ROUTE_STATUS = `${ROUTE_PREFIX}/status`

/** POST ROUTE_PREFIX/worktree — create-or-reuse a worktree for a branch. */
export const ROUTE_WORKTREE = `${ROUTE_PREFIX}/worktree`

/** POST ROUTE_PREFIX/switch — in-place branch switch of the main checkout. */
export const ROUTE_SWITCH = `${ROUTE_PREFIX}/switch`

/** POST ROUTE_PREFIX/branch — create a NEW branch (at the current checkout
 * or an explicit start point, with or without checking it out). */
export const ROUTE_BRANCH = `${ROUTE_PREFIX}/branch`

/** POST ROUTE_PREFIX/branch-rename — rename a LOCAL branch (refs are
 * repository-wide; worktree HEADs pointing at it follow). */
export const ROUTE_BRANCH_RENAME = `${ROUTE_PREFIX}/branch-rename`

/** POST ROUTE_PREFIX/branch-delete — delete a LOCAL branch (`-d`, merged
 * only; git refuses the rest). */
export const ROUTE_BRANCH_DELETE = `${ROUTE_PREFIX}/branch-delete`

/** POST ROUTE_PREFIX/fetch — sync remote-tracking refs (fetch every remote + prune). */
export const ROUTE_FETCH = `${ROUTE_PREFIX}/fetch`

/** POST ROUTE_PREFIX/update — fast-forward the current branch to its upstream. */
export const ROUTE_UPDATE = `${ROUTE_PREFIX}/update`

/** POST ROUTE_PREFIX/push — push the current branch to its upstream. */
export const ROUTE_PUSH = `${ROUTE_PREFIX}/push`

/** POST ROUTE_PREFIX/group — git belonging facts for a batch of workspace paths. */
export const ROUTE_GROUP = `${ROUTE_PREFIX}/group`

/** POST ROUTE_PREFIX/inspect — pre-delete facts for one worktree directory. */
export const ROUTE_INSPECT = `${ROUTE_PREFIX}/inspect`

/** POST ROUTE_PREFIX/remove — delete one linked worktree (git registration + folder). */
export const ROUTE_REMOVE = `${ROUTE_PREFIX}/remove`

/** POST ROUTE_PREFIX/exists — batch directory-existence probe (fs, no git). */
export const ROUTE_EXISTS = `${ROUTE_PREFIX}/exists`

/** POST ROUTE_PREFIX/ensure-directory — mkdir -p a missing worktree storage slot. */
export const ROUTE_ENSURE_DIRECTORY = `${ROUTE_PREFIX}/ensure-directory`

/** POST ROUTE_PREFIX/worktrees-all — scan the storage root: git facts for
 * every direct child directory (the plugin-planned worktree slots). */
export const ROUTE_WORKTREES_ALL = `${ROUTE_PREFIX}/worktrees-all`

/** POST ROUTE_PREFIX/purge — delete a NON-git directory sitting DIRECTLY in
 * the storage root (an orphaned leftover whose .git is already gone). */
export const ROUTE_PURGE = `${ROUTE_PREFIX}/purge`

/** POST ROUTE_PREFIX/changes — working-tree changes (staged/unstaged rows). */
export const ROUTE_CHANGES = `${ROUTE_PREFIX}/changes`

/** POST ROUTE_PREFIX/stage — batch stage (git add) or unstage paths. */
export const ROUTE_STAGE = `${ROUTE_PREFIX}/stage`

/** POST ROUTE_PREFIX/commit — commit the index with a message. */
export const ROUTE_COMMIT = `${ROUTE_PREFIX}/commit`

/** POST ROUTE_PREFIX/log — paginated commit history of the checkout. */
export const ROUTE_LOG = `${ROUTE_PREFIX}/log`

/** POST ROUTE_PREFIX/commit-files — the files one commit changed. */
export const ROUTE_COMMIT_FILES = `${ROUTE_PREFIX}/commit-files`

/** POST ROUTE_PREFIX/tag — create a tag at an existing commit. */
export const ROUTE_TAG = `${ROUTE_PREFIX}/tag`

/** POST ROUTE_PREFIX/tag-push — push ONE existing local tag to its remote. */
export const ROUTE_TAG_PUSH = `${ROUTE_PREFIX}/tag-push`

/** POST ROUTE_PREFIX/network-probe — read the endpoint through every configured channel (diagnostics; no state change). */
export const ROUTE_NETWORK_PROBE = `${ROUTE_PREFIX}/network-probe`

/** POST ROUTE_PREFIX/credentials — the global per-host credentials, secrets
 * masked (the stored secret never leaves the host). */
export const ROUTE_CREDENTIALS = `${ROUTE_PREFIX}/credentials`

/** POST ROUTE_PREFIX/credentials-save — create or update one host credential. */
export const ROUTE_CREDENTIALS_SAVE = `${ROUTE_PREFIX}/credentials-save`

/** POST ROUTE_PREFIX/credentials-delete — forget one host credential. */
export const ROUTE_CREDENTIALS_DELETE = `${ROUTE_PREFIX}/credentials-delete`

/** POST ROUTE_PREFIX/credentials-oauth-start — begin a browser sign-in for
 * one host (GitHub device flow); answers the one-time user code. */
export const ROUTE_CREDENTIALS_OAUTH_START = `${ROUTE_PREFIX}/credentials-oauth-start`

/** POST ROUTE_PREFIX/credentials-oauth-poll — poll a started browser sign-in;
 * stores the token and answers the fresh masked list once the user approves. */
export const ROUTE_CREDENTIALS_OAUTH_POLL = `${ROUTE_PREFIX}/credentials-oauth-poll`

/** POST ROUTE_PREFIX/credentials-import — copy the credentials the machine's
 * own helpers already answer for into the managed store (decision 0038). */
export const ROUTE_CREDENTIALS_IMPORT = `${ROUTE_PREFIX}/credentials-import`

/** POST ROUTE_PREFIX/remotes — the repository's configured remotes. */
export const ROUTE_REMOTES = `${ROUTE_PREFIX}/remotes`

/** POST ROUTE_PREFIX/remote — add, re-point or remove ONE remote. */
export const ROUTE_REMOTE = `${ROUTE_PREFIX}/remote`

/** POST ROUTE_PREFIX/ai-commit-message — one-shot LLM commit message from
 * the staged diff (mounted only where the host provides the llm service). */
export const ROUTE_AI_COMMIT_MESSAGE = `${ROUTE_PREFIX}/ai-commit-message`

/** Upper bound for one commit message (characters). The host rejects longer
 * bodies and the client caps its input at the same value, so the two ends
 * can never disagree. */
export const COMMIT_MESSAGE_LIMIT = 2000

/** One selectable branch row. */
export interface BranchEntry {
  /** Display name: a bare local name (`main`) or `<remote>/<name>`. */
  name: string
  kind: 'local' | 'remote'
  /** Commits the local branch is AHEAD of its upstream (local rows with an
   * upstream only; absent = no upstream or in sync). */
  ahead?: number
  /** Commits the local branch is BEHIND its upstream (same conditions). */
  behind?: number
}

/** One existing worktree of the repository. */
export interface WorktreeEntry {
  /** Absolute path of the worktree directory. */
  path: string
  /** Checked-out local branch name; absent for a detached or bare worktree. */
  branch: string | undefined
  /** True for the main worktree (the one holding `.git`). */
  main: boolean
}

/** Response of GET status — `repo: false` for a directory outside any git repository. */
export type RepoStatus =
  | { repo: false }
  | {
      repo: true
      /** Main repository directory basename — the root folder of `<rootDir>/<repoName>/`. */
      repoName: string
      /** Absolute path of the main worktree directory. */
      repoRoot: string
      /** True when the queried directory IS the main worktree (its own
       * toplevel holds the shared `.git`). The client's "session sits in a
       * linked worktree" trigger — `repoRoot` cannot answer it, since it
       * names the main checkout from every worktree by construction. */
      main: boolean
      /** Branch checked out by the directory the client asked about. */
      currentBranch: string
      /** Local branches plus every remote's remote-only branches (those
       * without a same-named local twin; `<remote>/HEAD` dropped). */
      branches: BranchEntry[]
      /** The FULL remote view: every remote branch, local twins included
       * (the git panel's remote tree; `<remote>/HEAD` and bare leftover
       * refs dropped). Absent from hosts serving an older build of this
       * route — the client falls back to filtering `branches`. */
      remoteBranches?: BranchEntry[]
      /** Every worktree of the repository, main first (git order). */
      worktrees: WorktreeEntry[]
      /** Resolved worktree storage root (absolute) — what the settings say today. */
      rootDir: string
    }

/** POST worktree request body. */
export interface CreateWorktreeBody {
  /** Any directory inside the repository (workspace cwd). */
  repoPath: string
  /** Chosen branch display name: local (`feat-x`) or remote (`origin/feat-x`). */
  branch: string
  /** True: cut a NEW branch out of `branch` (the current checkout's
   * branch — occupied by the main worktree) and isolate it in a fresh
   * worktree. The storage folder is named after the new branch. */
  cutout?: boolean
  /** Cutout only: explicit name for the NEW branch. Default (absent):
   * derived `<branch>-wt`, suffixing past taken names. */
  name?: string
}

/** POST worktree response body. */
export interface CreateWorktreeResult {
  /** The worktree directory (created or reused). */
  path: string
  /** False when an existing worktree for the branch was reused. */
  created: boolean
  /** Present only when the pre-create remote sync (`fetchBeforeCreate`) was
   * enabled AND failed: the creation went ahead anyway (a local worktree
   * never consumes the fetch), this carries git's stderr summary for the
   * client to toast. */
  fetchWarning?: string
  /** Present only when the idempotent write of `/.dsh/gitworktree/` into
   * `<repo>/.git/info/exclude` failed: the worktree was created anyway (it
   * cannot be rolled back), so the SOURCE REPOSITORY now shows an untracked
   * `.dsh/` directory — the client must toast this or the user's next
   * `git status` reads as a mystery. */
  excludeWarning?: string
  /** Present only when copying declared configuration files into the new
   * worktree failed for one or more files: the worktree was created anyway,
   * this carries a summary of the failed copies for the client to toast. */
  copyWarning?: string
}

/** POST switch request body. */
export interface SwitchBody {
  /** Any directory inside the main worktree. */
  repoPath: string
  /** Target branch display name (local, or remote whose local twin is created by dwim). */
  branch: string
}

/** POST switch response body. */
export interface SwitchResult {
  /** The branch actually checked out after the switch. */
  branch: string
}

/** POST branch request body. */
export interface CreateBranchBody {
  /** Any directory inside the repository (workspace cwd). Without `from` the
   * new branch is cut from whatever this directory's HEAD points at and
   * checked out HERE. */
  repoPath: string
  /** User-typed name of the branch to create (a local name, verbatim). */
  name: string
  /** Optional start point (a local branch or a remote-tracking ref like
   * `origin/feat-x`). Absent keeps the original in-place semantics: create
   * AND check out here. */
  from?: string
  /** With `from`, ALSO check the new branch out in the queried directory
   * (`git switch -c <name> <from>`) instead of leaving every checkout
   * untouched (`git branch <name> <from>`). Ignored without `from` —
   * the no-`from` shape always checks out. */
  checkout?: boolean
}

/** POST branch response body. */
export interface CreateBranchResult {
  /** The branch created; checked out in the queried directory unless
   * created at a start point with `checkout` left false. */
  branch: string
}

/** POST branch-rename request body. */
export interface RenameBranchBody {
  /** Any directory inside the repository (branch refs are repository-wide). */
  repoPath: string
  /** The branch to rename (a LOCAL name; remote branches are not ours). */
  name: string
  /** User-typed new name (a local name, verbatim). */
  newName: string
}

/** POST branch-rename response body. */
export interface RenameBranchResult {
  /** The branch's new name. */
  branch: string
}

/** POST branch-delete request body. */
export interface DeleteBranchBody {
  /** Any directory inside the repository (branch refs are repository-wide). */
  repoPath: string
  /** The branch to delete (a LOCAL name; remote branches are not ours). */
  name: string
}

/** POST branch-delete response body. */
export interface DeleteBranchResult {
  /** The branch that was deleted. */
  branch: string
}

/** POST fetch request body. */
export interface FetchBody {
  /** Any directory inside the repository (workspace cwd). */
  repoPath: string
}

/** POST fetch response body — the fetch mutates refs server-side; the
 * client refetches /status for the fresh branch list. */
export interface FetchResult {
  /** What the fetch covered: "all" remotes (this plugin always fetches all). */
  remote: string
}

/** POST update request body. */
export interface UpdateBody {
  /** Any directory inside the repository (workspace cwd) — the branch
   * checked out by THIS directory is the one updated. */
  repoPath: string
}

/** POST update response body — fetch every remote, then fast-forward the
 * checked-out branch to its upstream. */
export interface UpdateResult {
  /** The branch that was updated (empty for a detached checkout, which
   * cannot be updated and always errors before this response). */
  branch: string
  /** False when the upstream already contained the branch (nothing moved). */
  updated: boolean
}

/** POST push request body. */
export interface PushBody {
  /** Any directory inside the repository (workspace cwd) — the branch
   * checked out by THIS directory is the one pushed. */
  repoPath: string
}

/** POST push response body — push the checked-out branch to its upstream. */
export interface PushResult {
  /** The branch that was pushed (empty for a detached checkout, which
   * cannot be pushed and always errors before this response). */
  branch: string
  /** False when the upstream already contained the branch (nothing moved). */
  pushed: boolean
  /** Set when the push timed out but the remote ref already matched HEAD:
   * the push landed and only the confirmation was lost. */
  note?: 'timed-out-but-landed'
}

/** Error envelope every non-2xx response carries. */
export interface RouteError {
  error: string
}

/** Git belonging facts of one workspace directory; null = not a git repository. */
export interface WorkspaceGitFacts {
  /** Grouping key: the repository's main worktree directory (canonical). */
  repoRoot: string
  /** Group title: the main repository directory basename. */
  repoName: string
  /** Branch checked out by this directory; null = detached or unborn HEAD. */
  branch: string | null
  /** True when this directory IS the main worktree (holds the shared .git). */
  main: boolean
}

/** POST group request body. */
export interface GroupWorkspacesBody {
  /** Absolute workspace directories to probe (deduped server-side). */
  paths: string[]
}

/** POST group response body — one entry per DISTINCT requested path. */
export interface GroupWorkspacesResult {
  /** Git facts per path; null marks a path outside any git repository. */
  facts: Record<string, WorkspaceGitFacts | null>
}

/** POST inspect request body. */
export interface InspectWorktreeBody {
  /** The worktree directory to inspect (absolute). */
  path: string
}

/** POST inspect response body — the facts the remove-confirm dialog shows. */
export interface InspectWorktreeResult {
  /** Uncommitted changes in the directory (staged + unstaged + untracked
   * file rows of `git status --porcelain`). */
  dirty: number
  /** Commits the checked-out branch is ahead of its upstream; absent = no
   * upstream. Purely informational: the branch ref survives the removal, so
   * these commits are NOT lost. */
  ahead?: number
}

/** POST remove request body. */
export interface RemoveWorktreeBody {
  /** The linked worktree directory to delete (absolute). */
  path: string
  /** True: force past uncommitted changes (the confirm dialog already
   * showed the dirty count). */
  force?: boolean
}

/** POST remove response body. */
export interface RemoveWorktreeResult {
  /** The removed worktree directory. */
  path: string
  /** True when only a stale registration was pruned (the directory was
   * already gone); false when `git worktree remove` deleted a live folder. */
  pruned: boolean
}

/** POST exists request body. */
export interface PathExistsBody {
  /** Absolute directories to probe (deduped server-side). */
  paths: string[]
}

/** POST exists response body — one entry per DISTINCT requested path; true =
 * the path exists AND is a directory. The client gates the register action on
 * this, so a missing folder never reaches the DSH workspace API. */
export interface PathExistsResult {
  exists: Record<string, boolean>
  /** Per MISSING path: true when it sits DIRECTLY inside the plugin's
   * worktree storage root — a slot this plugin planned, so rebuilding the
   * empty directory is safe (historical sessions reattach automatically once
   * realpath matches again). Absent paths and directories outside the root
   * never appear here. */
  rebuildable?: Record<string, boolean>
}

/** POST ensure-directory request body. */
export interface EnsureDirectoryBody {
  /** The missing directory to create (absolute; must sit directly inside the
   * legacy storage root or a repository's `.dsh/gitworktree`). */
  path: string
}

/** POST ensure-directory response body. */
export interface EnsureDirectoryResult {
  /** Always true on 200 — the directory now exists (created, or already
   * present as a directory). */
  created: boolean
}

/** POST worktrees-all request body (all-optional for shape compatibility). */
export interface WorktreesAllBody {
  /** Absolute directories of the REGISTERED workspaces, from which the host
   * derives the repository-root set to scan `<repo>/.dsh/gitworktree` under
   * (each probed once, deduplicated). Absent/empty scans only the legacy
   * storage root. */
  workspaces?: string[]
}

/** One direct child directory of a worktree storage location. */
export interface WorktreeScanEntry {
  /** Absolute directory path. */
  path: string
  /** Main repository directory basename; null = the directory is not inside
   * a git repository (an orphan or foreign folder — shown as unrecognized,
   * never deleted, never counted against the prune cap). */
  repoName: string | null
  /** Branch checked out by the directory; null = unrecognized, detached, or
   * unborn HEAD. */
  branch: string | null
  /** Where the directory lives: `project` = inside `<repo>/.dsh/gitworktree`
   * (the current layout, auto-nested under its repository by the workspace
   * tree), `legacy` = inside the historical central storage root. */
  source: 'legacy' | 'project'
}

/** POST worktrees-all response body — one entry per DIRECT child of each
 * scanned storage location; a missing location answers its half as an empty
 * list. */
export interface WorktreesAllResult {
  worktrees: WorktreeScanEntry[]
  /** The resolved LEGACY storage root (historical central location): kept
   * read-only in the settings card so existing users can still find where
   * their old worktrees live. */
  legacyRoot: string
  /** False when the legacy root does not exist on disk — "未使用" rather
   * than hiding the field. */
  legacyRootExists: boolean
  /** Present and true when either scanned location held more children than
   * the scan probes: the list is the first slice, and the client says so
   * rather than presenting a truncated scan as the whole picture. */
  truncated?: boolean
}

/** POST purge request body. */
export interface PurgeDirectoryBody {
  /** The leftover directory to delete (absolute; must sit directly inside
   * the legacy storage root or a repository's `.dsh/gitworktree`, AND have
   * no git identity). */
  path: string
}

/** POST purge response body. */
export interface PurgeDirectoryResult {
  /** Always true on 200 — the directory (contents included) is gone. */
  path: string
  removed: boolean
}

/** Status letter of one working-tree or commit file change. `U` never comes
 * from a commit's file list — it marks an UNMERGED working-tree path. */
export type ChangeStatus = 'A' | 'M' | 'D' | 'R' | 'C' | 'T' | 'U'

/** One working-tree change row of POST changes. */
export interface WorktreeChange {
  /** New path, relative to the repository root. */
  path: string
  /** Original path for a rename/copy. */
  oldPath?: string
  /** Index (staged) status; absent when the index matches HEAD. */
  staged?: ChangeStatus
  /** Worktree (unstaged) status; absent when the worktree matches the index. */
  unstaged?: ChangeStatus
  /** True for an untracked path (neither staged nor tracked). */
  untracked?: boolean
}

/** POST changes request body. */
export interface ChangesBody {
  /** Any directory inside the repository (the queried checkout). */
  repoPath: string
}

/** POST changes response body. */
export interface ChangesResult {
  /** One row per changed path, in git status order; capped server-side. */
  changes: WorktreeChange[]
  /** True when the working tree had more rows than the server cap and only
   * the first ones are listed here. */
  truncated?: boolean
}

/** POST stage request body. */
export interface StageBody {
  /** Any directory inside the repository (the queried checkout). */
  repoPath: string
  /** Relative paths to (un)stage; they must come from POST changes output. */
  paths: string[]
  /** True stages (git add); false unstages (git reset / git rm --cached). */
  stage: boolean
}

/** POST stage response body. */
export interface StageResult {
  /** Always true on 200 — the index now reflects the request. */
  staged: boolean
}

/** POST commit request body. */
export interface CommitBody {
  /** Any directory inside the repository (the queried checkout). */
  repoPath: string
  /** The commit message, verbatim (git -m). */
  message: string
}

/** POST commit response body. */
export interface CommitResult {
  /** The created commit's full hash. */
  hash: string
  /** The commit subject (first line of the message, trimmed). */
  subject: string
}

/** One commit row of POST log. */
export interface CommitEntry {
  /** Full hash. */
  hash: string
  /** Abbreviated hash (%h). */
  short: string
  authorName: string
  authorEmail: string
  /** Author date, epoch milliseconds. */
  date: number
  /** Parent hashes; more than one marks a merge commit. */
  parents: string[]
  /** The commit subject (%s). */
  subject: string
  /** The commit body (%b); empty when none. */
  body: string
  /** Decorations (%D), raw segments: `HEAD -> main`, `tag: v1.0.2`, `origin/main`. */
  refs: string[]
}

/** POST log request body. */
export interface LogBody {
  /** Any directory inside the repository (the queried checkout). */
  repoPath: string
  /** Page size; default 50, capped at 200. */
  limit?: number
  /** Offset into the filtered history; default 0. */
  skip?: number
  /** Optional starting ref (a branch name, `HEAD`, …); validated server-side. */
  ref?: string
  /** Walk every ref (branches + tags) instead of the checkout's HEAD — the
   * history card's default view, which is what makes branches/merges visible.
   * Ignored when `ref` is given. */
  all?: boolean
  /** Committer-author substring/regex (`--author`); absent = every author. */
  author?: string
  /** Lower bound on the commit date, epoch milliseconds (`--since`). */
  since?: number
  /** Upper bound on the commit date, epoch milliseconds (`--until`). */
  until?: number
}

/** POST log response body. */
export interface LogResult {
  commits: CommitEntry[]
}

/** POST tag request body. */
export interface CreateTagBody {
  /** Any directory inside the repository (tag refs are repository-wide). */
  repoPath: string
  /** User-typed tag name, verbatim (git validates it). */
  name: string
  /** The commit to tag (a full or abbreviated hash, validated server-side);
   * absent tags the repository's current HEAD. */
  target?: string
  /** Optional annotation message; non-empty creates an ANNOTATED tag. */
  message?: string
}

/** POST tag response body. */
export interface CreateTagResult {
  /** The tag created. */
  tag: string
  /** The commit hash the tag points at. */
  hash: string
}

/** POST tag-push request body. */
export interface PushTagBody {
  /** Any directory inside the repository (tag refs are repository-wide). */
  repoPath: string
  /** An EXISTING local tag name, verified server-side before any push. */
  name: string
}

/** POST tag-push response body. */
export interface PushTagResult {
  /** The tag that was the subject of the push. */
  tag: string
  /** The remote the tag was pushed to (resolved server-side). */
  remote: string
  /** False when the remote already carried this exact tag object — nothing
   * was sent. True once the push command actually ran. */
  pushed: boolean
  /** Set when the push timed out but the remote tag already named the local
   * object: the tag landed and only the confirmation was lost. */
  note?: 'timed-out-but-landed'
}

/** One file row of POST commit-files. */
export interface CommitFileEntry {
  /** New path, relative to the repository root. */
  path: string
  /** Original path for a rename/copy. */
  oldPath?: string
  status: ChangeStatus
  /** Added lines; absent for a binary file or when parsing fell short. */
  insertions?: number
  /** Deleted lines; same conditions. */
  deletions?: number
  /** True when git numstat reported `-` (binary content). */
  binary?: boolean
}

/** POST commit-files request body. */
export interface CommitFilesBody {
  /** Any directory inside the repository (the queried checkout). */
  repoPath: string
  /** The commit hash (validated server-side). */
  hash: string
}

/** POST commit-files response body. */
export interface CommitFilesResult {
  hash: string
  files: CommitFileEntry[]
}

/** POST ai-commit-message request body. */
export interface AiCommitMessageBody {
  /** Any directory inside the repository (the queried checkout). */
  repoPath: string
  /** The model route to call, as selected by the requesting session. */
  provider: string
  model: string
  /** Adapter-owned reasoning effort for the exact model; absent = default. */
  effort?: string
  /** Optional user hint (an existing draft to rewrite, or style directions). */
  hint?: string
}

/** POST ai-commit-message response body. */
export interface AiCommitMessageResult {
  /** The generated commit message (subject, optionally followed by a body). */
  message: string
}

/** Hosts whose browser sign-in the credential dialog offers. Mirrors the
 * host-side device-flow support (`src/oauth.ts`); a shared constant keeps the
 * browser list from drifting away from what the host can actually do. */
export const BROWSER_SIGN_IN_HOSTS: readonly string[] = ['github.com']

/** How a stored credential's secret is meant to be used. */
export type CredentialMethod = 'token' | 'password'

/** One credential row as the browser sees it: the secret is masked. */
export interface CredentialEntryView {
  /** Normalized remote host the credential belongs to. */
  host: string
  username: string
  method: CredentialMethod
  /** Epoch millis of the last save. */
  updatedAt: number
  /** Masked tail (`****abcd`) — never the secret itself. */
  secretMask: string
}

/** POST credentials response body. */
export interface CredentialsResult {
  credentials: CredentialEntryView[]
}

/** POST credentials-save request body. */
export interface CredentialSaveBody {
  /** Remote host, bare or pasted as a full remote URL (normalized host-side). */
  host: string
  username: string
  method: CredentialMethod
  /** Token or password. Omitted/blank on an EXISTING host keeps the stored
   * secret; a new host requires it. */
  secret?: string
}

/** POST credentials-save response body: the updated masked list. */
export type CredentialSaveResult = CredentialsResult

/** POST credentials-delete request body. */
export interface CredentialDeleteBody {
  host: string
}

/** POST credentials-delete response body: the updated masked list. */
export type CredentialDeleteResult = CredentialsResult

/** POST credentials-import request body — absent hosts means "whatever the
 * machine's gitconfig points git at". */
export interface CredentialImportBody {
  /** Explicit hosts to probe; omitted, the gitconfig's URL-scoped hosts are
   * the candidates. */
  hosts?: string[]
}

/** One host the import copied into the store (secret never included). */
export interface CredentialImportEntry {
  host: string
  /** `oauth2` for a token credential, the helper's user name otherwise. */
  username: string
  method: CredentialMethod
}

/** One host whose machine helper had nothing to give; the store is untouched. */
export interface CredentialImportFailure {
  host: string
  error: string
}

/** POST credentials-import response body: the fresh masked list plus what the
 * import did per host. */
export interface CredentialImportResult extends CredentialsResult {
  imported: CredentialImportEntry[]
  skipped: string[]
  failed: CredentialImportFailure[]
}

/** POST credentials-oauth-start request body. */
export interface CredentialOAuthStartBody {
  /** Remote host whose browser sign-in to start (must support device flow). */
  host: string
}

/** POST credentials-oauth-start response body: what the dialog shows/opens. */
export interface CredentialOAuthStartResult {
  /** The short code to type on the verification page. */
  userCode: string
  /** Verification page without the code. */
  verificationUri: string
  /** Verification page with the code pre-filled, when the host returns one. */
  verificationUriComplete?: string
  /** Polling credential for {@link CredentialOAuthPollBody}. */
  deviceCode: string
  /** Minimum seconds between polls. */
  intervalSeconds: number
  /** Seconds until the grant expires. */
  expiresInSeconds: number
}

/** POST credentials-oauth-poll request body. */
export interface CredentialOAuthPollBody {
  /** The host whose sign-in is being polled. */
  host: string
  /** The grant's `deviceCode` from the start call. */
  deviceCode: string
}

/** POST credentials-oauth-poll response body: still waiting, or the fresh list
 * once the token was stored (the token itself never crosses the wire). */
export type CredentialOAuthPollResult =
  | { status: 'pending' }
  /** GitHub asked the client to back off; the dialog doubles its interval. */
  | { status: 'slow_down' }
  /** The endpoint was unreachable for this poll; the grant is still valid, so
   * the dialog keeps polling and only gives up after repeated failures. */
  | { status: 'network'; message: string }
  | { status: 'done'; credentials: CredentialEntryView[] }

/** One configured remote. */
export interface RemoteEntry {
  name: string
  /** URL `git fetch` uses. */
  fetchUrl: string
  /** URL `git push` uses (equals fetchUrl unless a push URL is set apart). */
  pushUrl: string
}

/** POST remotes response body. */
export interface RemotesResult {
  remotes: RemoteEntry[]
}

/** POST remotes request body. */
export interface RemotesBody {
  /** Any directory inside the repository (remotes are repository-wide). */
  repoPath: string
}

/** The mutation one /remote call performs. */
export type RemoteAction = 'add' | 'set-url' | 'remove'

/** POST remote request body. */
export interface RemoteMutationBody {
  /** Any directory inside the repository (remotes are repository-wide). */
  repoPath: string
  action: RemoteAction
  /** The remote name (validated host-side). */
  name: string
  /** The new URL; required for `add` and `set-url`, absent for `remove`. */
  url?: string
}

/** POST remote response body: the repository's remotes after the change. */
export type RemoteMutationResult = RemotesResult


/** The network channels a probe can report, in the order they are tried. */
export type NetworkChannelId = 'direct' | 'proxy' | 'ip'

/** One channel's verdict from ROUTE_NETWORK_PROBE. */
export interface NetworkChannelReport {
  /** Which channel was attempted. */
  channel: NetworkChannelId
  /** Whether an ls-remote answered within the probe budget. */
  ok: boolean
  /** Wall-clock milliseconds the attempt took. */
  elapsedMs: number
  /** Why it failed, trimmed for display; absent when ok. */
  detail?: string
}

/** POST network-probe request body. */
export interface NetworkProbeBody {
  /** Any directory inside the repository. */
  repoPath: string
}

/** POST network-probe response body: one verdict per configured channel. */
export interface NetworkProbeResult {
  /** The endpoint that was probed (the push URL when the branch has one). */
  url: string
  /** One entry per configured channel. */
  channels: NetworkChannelReport[]
  /** The WinINET proxy when one is enabled but not configured in the plugin. */
  systemProxy?: string
}
