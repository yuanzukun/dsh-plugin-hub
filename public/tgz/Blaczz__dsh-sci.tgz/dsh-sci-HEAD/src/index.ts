/**
 * Host half of dsh-sci: registers three zero-dependency scientific tools.
 * All logic lives in the pure ./units.ts / ./constants.ts / ./ode.ts modules.
 */
import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { convert, lookupUnit, unitNames } from './units.ts'
import { constantSummaries, lookupConstant, PHYSICAL_CONSTANTS } from './constants.ts'
import { getModel, ODE_MODELS, resolveParams, rk4 } from './ode.ts'

export { convert, lookupUnit, unitNames, UNITS } from './units.ts'
export type { UnitDef } from './units.ts'
export { constantSummaries, lookupConstant, PHYSICAL_CONSTANTS } from './constants.ts'
export type { ConstantDef } from './constants.ts'
export { getModel, ODE_MODELS, resolveParams, rk4 } from './ode.ts'
export type { OdeModel, VectorField } from './ode.ts'

export const name = 'dsh-sci'
export const inject = ['tools']

/** Evenly downsample a trajectory to at most `samples` points (inclusive ends). */
function downsample(t: number[], y: number[][], samples: number): { t: number[]; y: number[][] } {
  const total = t.length
  const count = Math.min(total, Math.max(2, Math.floor(samples)))
  const step = (total - 1) / (count - 1)
  const outT: number[] = []
  const outY: number[][] = []
  for (let i = 0; i < count; i += 1) {
    const index = Math.round(i * step)
    outT.push(t[index]!)
    outY.push(y[index]!)
  }
  return { t: outT, y: outY }
}

export function apply(ctx: Context): void {
  ctx.tools.register(defineTool({
    name: 'units_convert',
    description: 'Convert a physical quantity between units of the same dimension (length, mass, time, temperature, energy, pressure, frequency, force, angle, volume, area, electric, …). Returns the converted value.',
    parameters: {
      value: { type: 'number', required: true, description: 'Numeric value to convert.' },
      from: { type: 'string', required: true, description: 'Source unit symbol or name (e.g. "eV", "km", "celsius", "nanometer").' },
      to: { type: 'string', required: true, description: 'Target unit symbol or name.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          value: { type: 'number', required: true },
          from: { type: 'string', required: true },
          to: { type: 'string', required: true },
        },
      },
      render: (args, out) => [{ type: 'text', text: `${args.value} ${args.from} = ${out.value} ${out.to}` }],
    },
    async execute(args) {
      const value = convert(args.value, args.from, args.to)
      return { value, from: args.from, to: args.to }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'physical_constants',
    description: 'Look up a CODATA physical constant by id, symbol or name (e.g. "speed_of_light", "h", "Boltzmann constant"). Omit the query to list every available constant.',
    parameters: {
      query: { type: 'string', description: 'Constant id, symbol or name. Omit to list all.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          constants: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                id: { type: 'string', required: true },
                symbol: { type: 'string', required: true },
                name: { type: 'string', required: true },
                value: { type: 'number', required: true },
                unit: { type: 'string', required: true },
                description: { type: 'string', required: true },
                exact: { type: 'boolean' },
              },
            },
          },
        },
      },
      render: (_args, out) => [{
        type: 'text',
        text: out.constants.map(c => `${c.symbol} (${c.name}) = ${c.value} ${c.unit}${c.exact ? ' [exact]' : ''}`).join('\n'),
      }],
    },
    async execute(args) {
      if (args.query === undefined) {
        return { constants: [...PHYSICAL_CONSTANTS] }
      }
      const constant = lookupConstant(args.query)
      if (constant === undefined) {
        throw new Error(`unknown constant ${JSON.stringify(args.query)}; try ${constantSummaries().slice(0, 3).join('; ')} …`)
      }
      return { constants: [constant] }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'ode_solve',
    description: `Numerically solve a common dynamical-system ODE with a 4th-order Runge–Kutta integrator. Models: ${ODE_MODELS.map(m => `${m.id} (${m.description})`).join('; ')}.`,
    parameters: {
      model: { type: 'string', required: true, enum: ODE_MODELS.map(m => m.id), description: 'Dynamical-system model id.' },
      params: { type: 'object', additionalProperties: true, description: 'Model parameters to override defaults (e.g. {"r": 0.2, "K": 500}).' },
      y0: { type: 'array', items: { type: 'number' }, description: 'Initial conditions; defaults to the model baseline.' },
      tEnd: { type: 'number', required: true, description: 'Integration end time (start is always 0).' },
      steps: { type: 'number', description: 'RK4 steps; default 1000.' },
      samples: { type: 'number', description: 'Max output samples; default 101.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          model: { type: 'string', required: true },
          labels: { type: 'array', items: { type: 'string' }, required: true },
          params: { type: 'object', additionalProperties: true, required: true },
          t: { type: 'array', items: { type: 'number' }, required: true },
          y: { type: 'array', items: { type: 'array', items: { type: 'number' } }, required: true },
          yFinal: { type: 'array', items: { type: 'number' }, required: true },
        },
      },
      render: (args, out) => [{
        type: 'text',
        text: `${out.model} at t=${args.tEnd}: final state [${out.labels.map((label, i) => `${label}=${out.yFinal[i]}`).join(', ')}] (${out.t.length} samples).`,
      }],
    },
    async execute(args) {
      const model = getModel(args.model)
      if (model === undefined) {
        throw new Error(`unknown model ${JSON.stringify(args.model)}; expected one of ${ODE_MODELS.map(m => m.id).join(', ')}`)
      }
      const params = resolveParams(model, (args.params ?? {}) as Record<string, number>)
      const y0 = args.y0 ?? model.y0
      if (y0.length !== model.dim) {
        throw new Error(`model ${model.id} expects ${model.dim} initial values, got ${y0.length}`)
      }
      const steps = Math.min(10000, Math.max(10, Math.floor(args.steps ?? 1000)))
      const full = rk4(model.make(params), y0, 0, args.tEnd, steps)
      const sampled = downsample(full.t, full.y, Math.floor(args.samples ?? 101))
      return {
        model: model.id,
        labels: model.labels,
        params,
        t: sampled.t,
        y: sampled.y,
        yFinal: full.y[full.y.length - 1]!,
      }
    },
  }))

  // Keep the unit table referenced so a tree-shake cannot drop the data.
  void unitNames
}
