/**
 * Physical-unit conversion, zero-dependency. Each unit belongs to a dimension
 * and carries a multiplicative factor (plus an optional affine offset for
 * temperature). Conversion routes through the dimension's base unit.
 */

export interface UnitDef {
  /** Canonical name. */
  name: string
  /** Lookup aliases (lowercase). */
  aliases: string[]
  /** Dimension key ('length', 'energy', …); conversion requires a match. */
  dimension: string
  /** Multiply-to-base factor. */
  factor: number
  /** Affine offset in base units (temperature only). */
  offset?: number
}

export const UNITS: readonly UnitDef[] = [
  // Length (base: meter)
  { name: 'meter', aliases: ['m', 'meter', 'metre', 'meters', 'metres'], dimension: 'length', factor: 1 },
  { name: 'kilometer', aliases: ['km', 'kilometer', 'kilometre'], dimension: 'length', factor: 1e3 },
  { name: 'centimeter', aliases: ['cm', 'centimeter', 'centimetre'], dimension: 'length', factor: 1e-2 },
  { name: 'millimeter', aliases: ['mm', 'millimeter', 'millimetre'], dimension: 'length', factor: 1e-3 },
  { name: 'micrometer', aliases: ['um', 'µm', 'micron', 'micrometer', 'micrometre'], dimension: 'length', factor: 1e-6 },
  { name: 'nanometer', aliases: ['nm', 'nanometer', 'nanometre'], dimension: 'length', factor: 1e-9 },
  { name: 'angstrom', aliases: ['angstrom', 'å', 'a'], dimension: 'length', factor: 1e-10 },
  { name: 'inch', aliases: ['in', 'inch', 'inches'], dimension: 'length', factor: 0.0254 },
  { name: 'foot', aliases: ['ft', 'foot', 'feet'], dimension: 'length', factor: 0.3048 },
  { name: 'yard', aliases: ['yd', 'yard', 'yards'], dimension: 'length', factor: 0.9144 },
  { name: 'mile', aliases: ['mi', 'mile', 'miles'], dimension: 'length', factor: 1609.344 },
  { name: 'astronomical-unit', aliases: ['au', 'astronomical unit', 'astronomical-unit'], dimension: 'length', factor: 1.495978707e11 },
  { name: 'light-year', aliases: ['ly', 'lightyear', 'light-year', 'light year'], dimension: 'length', factor: 9.4607304725808e15 },
  { name: 'parsec', aliases: ['pc', 'parsec'], dimension: 'length', factor: 3.08567758149137e16 },

  // Mass (base: kilogram)
  { name: 'kilogram', aliases: ['kg', 'kilogram', 'kilograms'], dimension: 'mass', factor: 1 },
  { name: 'gram', aliases: ['g', 'gram', 'grams'], dimension: 'mass', factor: 1e-3 },
  { name: 'milligram', aliases: ['mg', 'milligram'], dimension: 'mass', factor: 1e-6 },
  { name: 'microgram', aliases: ['ug', 'µg', 'microgram'], dimension: 'mass', factor: 1e-9 },
  { name: 'tonne', aliases: ['t', 'tonne', 'metric ton'], dimension: 'mass', factor: 1e3 },
  { name: 'pound', aliases: ['lb', 'lbs', 'pound', 'pounds'], dimension: 'mass', factor: 0.45359237 },
  { name: 'ounce', aliases: ['oz', 'ounce', 'ounces'], dimension: 'mass', factor: 0.028349523125 },
  { name: 'dalton', aliases: ['da', 'u', 'amu', 'dalton', 'atomic mass unit'], dimension: 'mass', factor: 1.66053906660e-27 },

  // Time (base: second)
  { name: 'second', aliases: ['s', 'sec', 'second', 'seconds'], dimension: 'time', factor: 1 },
  { name: 'millisecond', aliases: ['ms', 'millisecond'], dimension: 'time', factor: 1e-3 },
  { name: 'microsecond', aliases: ['us', 'µs', 'microsecond'], dimension: 'time', factor: 1e-6 },
  { name: 'nanosecond', aliases: ['ns', 'nanosecond'], dimension: 'time', factor: 1e-9 },
  { name: 'minute', aliases: ['min', 'minute', 'minutes'], dimension: 'time', factor: 60 },
  { name: 'hour', aliases: ['h', 'hr', 'hour', 'hours'], dimension: 'time', factor: 3600 },
  { name: 'day', aliases: ['d', 'day', 'days'], dimension: 'time', factor: 86400 },
  { name: 'year', aliases: ['yr', 'year', 'years', 'julian year'], dimension: 'time', factor: 31557600 },

  // Frequency (base: hertz)
  { name: 'hertz', aliases: ['hz', 'hertz'], dimension: 'frequency', factor: 1 },
  { name: 'kilohertz', aliases: ['khz', 'kilohertz'], dimension: 'frequency', factor: 1e3 },
  { name: 'megahertz', aliases: ['mhz', 'megahertz'], dimension: 'frequency', factor: 1e6 },
  { name: 'gigahertz', aliases: ['ghz', 'gigahertz'], dimension: 'frequency', factor: 1e9 },
  { name: 'terahertz', aliases: ['thz', 'terahertz'], dimension: 'frequency', factor: 1e12 },

  // Temperature (base: kelvin; affine)
  { name: 'kelvin', aliases: ['k', 'kelvin'], dimension: 'temperature', factor: 1, offset: 0 },
  { name: 'celsius', aliases: ['c', '°c', 'celsius', 'centigrade'], dimension: 'temperature', factor: 1, offset: 273.15 },
  { name: 'fahrenheit', aliases: ['f', '°f', 'fahrenheit'], dimension: 'temperature', factor: 5 / 9, offset: 255.37222222222223 },

  // Energy (base: joule)
  { name: 'joule', aliases: ['j', 'joule', 'joules'], dimension: 'energy', factor: 1 },
  { name: 'kilojoule', aliases: ['kj', 'kilojoule'], dimension: 'energy', factor: 1e3 },
  { name: 'electronvolt', aliases: ['ev', 'electronvolt', 'electron-volt'], dimension: 'energy', factor: 1.602176634e-19 },
  { name: 'kiloelectronvolt', aliases: ['kev', 'kiloelectronvolt'], dimension: 'energy', factor: 1.602176634e-16 },
  { name: 'megaelectronvolt', aliases: ['mev', 'megaelectronvolt'], dimension: 'energy', factor: 1.602176634e-13 },
  { name: 'gigaelectronvolt', aliases: ['gev', 'gigaelectronvolt'], dimension: 'energy', factor: 1.602176634e-10 },
  { name: 'calorie', aliases: ['cal', 'calorie', 'calories'], dimension: 'energy', factor: 4.184 },
  { name: 'kilocalorie', aliases: ['kcal', 'kilocalorie'], dimension: 'energy', factor: 4184 },
  { name: 'watt-hour', aliases: ['wh', 'watt-hour', 'watthour'], dimension: 'energy', factor: 3600 },
  { name: 'kilowatt-hour', aliases: ['kwh', 'kilowatt-hour'], dimension: 'energy', factor: 3.6e6 },
  { name: 'erg', aliases: ['erg', 'ergs'], dimension: 'energy', factor: 1e-7 },
  { name: 'hartree', aliases: ['ha', 'eh', 'hartree'], dimension: 'energy', factor: 4.3597447222071e-18 },
  { name: 'british-thermal-unit', aliases: ['btu', 'british thermal unit'], dimension: 'energy', factor: 1055.05585262 },

  // Power (base: watt)
  { name: 'watt', aliases: ['w', 'watt', 'watts'], dimension: 'power', factor: 1 },
  { name: 'kilowatt', aliases: ['kw', 'kilowatt'], dimension: 'power', factor: 1e3 },
  { name: 'megawatt', aliases: ['mw', 'megawatt'], dimension: 'power', factor: 1e6 },
  { name: 'horsepower', aliases: ['hp', 'horsepower'], dimension: 'power', factor: 745.6998715822702 },

  // Pressure (base: pascal)
  { name: 'pascal', aliases: ['pa', 'pascal', 'pascals'], dimension: 'pressure', factor: 1 },
  { name: 'kilopascal', aliases: ['kpa', 'kilopascal'], dimension: 'pressure', factor: 1e3 },
  { name: 'megapascal', aliases: ['mpa', 'megapascal'], dimension: 'pressure', factor: 1e6 },
  { name: 'bar', aliases: ['bar', 'bars'], dimension: 'pressure', factor: 1e5 },
  { name: 'atmosphere', aliases: ['atm', 'atmosphere', 'standard atmosphere'], dimension: 'pressure', factor: 101325 },
  { name: 'torr', aliases: ['torr'], dimension: 'pressure', factor: 101325 / 760 },
  { name: 'millimeter-of-mercury', aliases: ['mmhg', 'millimeter of mercury'], dimension: 'pressure', factor: 133.322387415 },
  { name: 'psi', aliases: ['psi', 'pound per square inch'], dimension: 'pressure', factor: 6894.757293168 },

  // Force (base: newton)
  { name: 'newton', aliases: ['n', 'newton', 'newtons'], dimension: 'force', factor: 1 },
  { name: 'dyne', aliases: ['dyn', 'dyne', 'dynes'], dimension: 'force', factor: 1e-5 },
  { name: 'kilogram-force', aliases: ['kgf', 'kilogram-force', 'kilopond'], dimension: 'force', factor: 9.80665 },
  { name: 'pound-force', aliases: ['lbf', 'pound-force'], dimension: 'force', factor: 4.4482216152605 },

  // Angle (base: radian)
  { name: 'radian', aliases: ['rad', 'radian', 'radians'], dimension: 'angle', factor: 1 },
  { name: 'degree', aliases: ['deg', '°', 'degree', 'degrees'], dimension: 'angle', factor: Math.PI / 180 },
  { name: 'arcminute', aliases: ['arcmin', 'arcminute'], dimension: 'angle', factor: Math.PI / 180 / 60 },
  { name: 'arcsecond', aliases: ['arcsec', 'arcsecond'], dimension: 'angle', factor: Math.PI / 180 / 3600 },

  // Volume (base: cubic meter)
  { name: 'cubic-meter', aliases: ['m3', 'cubic meter', 'cubic-meter', 'metre cubed'], dimension: 'volume', factor: 1 },
  { name: 'liter', aliases: ['l', 'liter', 'litre', 'liters', 'litres'], dimension: 'volume', factor: 1e-3 },
  { name: 'milliliter', aliases: ['ml', 'milliliter', 'millilitre'], dimension: 'volume', factor: 1e-6 },
  { name: 'cubic-centimeter', aliases: ['cm3', 'cc', 'cubic centimeter'], dimension: 'volume', factor: 1e-6 },
  { name: 'gallon', aliases: ['gal', 'gallon', 'us gallon'], dimension: 'volume', factor: 0.003785411784 },

  // Area (base: square meter)
  { name: 'square-meter', aliases: ['m2', 'square meter', 'square-meter'], dimension: 'area', factor: 1 },
  { name: 'square-centimeter', aliases: ['cm2', 'square centimeter'], dimension: 'area', factor: 1e-4 },
  { name: 'square-kilometer', aliases: ['km2', 'square kilometer'], dimension: 'area', factor: 1e6 },
  { name: 'hectare', aliases: ['ha', 'hectare'], dimension: 'area', factor: 1e4 },
  { name: 'acre', aliases: ['acre', 'acres'], dimension: 'area', factor: 4046.8564224 },

  // Electric (base: ampere / coulomb / volt / ohm)
  { name: 'ampere', aliases: ['a', 'amp', 'ampere', 'amperes'], dimension: 'current', factor: 1 },
  { name: 'milliampere', aliases: ['ma', 'milliampere'], dimension: 'current', factor: 1e-3 },
  { name: 'coulomb', aliases: ['c', 'coulomb', 'coulombs'], dimension: 'charge', factor: 1 },
  { name: 'ampere-hour', aliases: ['ah', 'ampere-hour'], dimension: 'charge', factor: 3600 },
  { name: 'volt', aliases: ['v', 'volt', 'volts'], dimension: 'potential', factor: 1 },
  { name: 'millivolt', aliases: ['mv', 'millivolt'], dimension: 'potential', factor: 1e-3 },
  { name: 'kilovolt', aliases: ['kv', 'kilovolt'], dimension: 'potential', factor: 1e3 },
  { name: 'ohm', aliases: ['ohm', 'Ω', 'ohms'], dimension: 'resistance', factor: 1 },
  { name: 'kiloohm', aliases: ['kohm', 'kΩ', 'kiloohm'], dimension: 'resistance', factor: 1e3 },
  { name: 'megaohm', aliases: ['mohm', 'mΩ', 'megaohm'], dimension: 'resistance', factor: 1e6 },
]

const byAlias = new Map<string, UnitDef>()
for (const unit of UNITS) {
  byAlias.set(unit.name.toLowerCase(), unit)
  for (const alias of unit.aliases) byAlias.set(alias.toLowerCase(), unit)
}

/** Resolve a unit by canonical name or alias (case-insensitive). */
export function lookupUnit(symbol: string): UnitDef | undefined {
  return byAlias.get(symbol.trim().toLowerCase())
}

/** List every unit (name + aliases) as human-readable strings. */
export function unitNames(): string[] {
  return UNITS.map(unit => `${unit.name} (${unit.aliases.join(', ')})`)
}

/**
 * Convert a value between two units of the same dimension. Throws on unknown
 * units or incompatible dimensions.
 */
export function convert(value: number, from: string, to: string): number {
  const fromUnit = lookupUnit(from)
  const toUnit = lookupUnit(to)
  if (fromUnit === undefined) throw new Error(`unknown unit ${JSON.stringify(from)}`)
  if (toUnit === undefined) throw new Error(`unknown unit ${JSON.stringify(to)}`)
  if (fromUnit.dimension !== toUnit.dimension) {
    throw new Error(`incompatible dimensions: ${JSON.stringify(from)} is ${fromUnit.dimension}, ${JSON.stringify(to)} is ${toUnit.dimension}`)
  }
  const base = value * fromUnit.factor + (fromUnit.offset ?? 0)
  return (base - (toUnit.offset ?? 0)) / toUnit.factor
}
