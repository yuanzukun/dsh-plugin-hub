/**
 * CODATA 2018 physical constants (SI), zero-dependency. `exact` marks the
 * constants fixed by the 2019 SI redefinition.
 */

export interface ConstantDef {
  id: string
  symbol: string
  name: string
  value: number
  unit: string
  description: string
  exact?: boolean
}

export const PHYSICAL_CONSTANTS: readonly ConstantDef[] = [
  { id: 'speed_of_light', symbol: 'c', name: 'speed of light', value: 299792458, unit: 'm/s', description: 'Speed of light in vacuum', exact: true },
  { id: 'planck_constant', symbol: 'h', name: 'Planck constant', value: 6.62607015e-34, unit: 'J·s', description: 'Planck constant', exact: true },
  { id: 'reduced_planck_constant', symbol: 'ħ', name: 'reduced Planck constant', value: 1.054571817e-34, unit: 'J·s', description: 'h / 2π', exact: true },
  { id: 'elementary_charge', symbol: 'e', name: 'elementary charge', value: 1.602176634e-19, unit: 'C', description: 'Elementary charge', exact: true },
  { id: 'boltzmann_constant', symbol: 'k', name: 'Boltzmann constant', value: 1.380649e-23, unit: 'J/K', description: 'Boltzmann constant', exact: true },
  { id: 'avogadro_constant', symbol: 'NA', name: 'Avogadro constant', value: 6.02214076e23, unit: '1/mol', description: 'Avogadro constant', exact: true },
  { id: 'gravitational_constant', symbol: 'G', name: 'gravitational constant', value: 6.67430e-11, unit: 'm^3/(kg·s^2)', description: 'Newtonian constant of gravitation' },
  { id: 'vacuum_permittivity', symbol: 'ε₀', name: 'vacuum permittivity', value: 8.8541878128e-12, unit: 'F/m', description: 'Vacuum electric permittivity' },
  { id: 'vacuum_permeability', symbol: 'μ₀', name: 'vacuum permeability', value: 1.25663706212e-6, unit: 'N/A^2', description: 'Vacuum magnetic permeability' },
  { id: 'electron_mass', symbol: 'm_e', name: 'electron mass', value: 9.1093837015e-31, unit: 'kg', description: 'Electron rest mass' },
  { id: 'proton_mass', symbol: 'm_p', name: 'proton mass', value: 1.67262192369e-27, unit: 'kg', description: 'Proton rest mass' },
  { id: 'neutron_mass', symbol: 'm_n', name: 'neutron mass', value: 1.67492749804e-27, unit: 'kg', description: 'Neutron rest mass' },
  { id: 'gas_constant', symbol: 'R', name: 'molar gas constant', value: 8.314462618, unit: 'J/(mol·K)', description: 'Molar gas constant' },
  { id: 'stefan_boltzmann_constant', symbol: 'σ', name: 'Stefan–Boltzmann constant', value: 5.670374419e-8, unit: 'W/(m^2·K^4)', description: 'Stefan–Boltzmann constant' },
  { id: 'fine_structure_constant', symbol: 'α', name: 'fine-structure constant', value: 7.2973525693e-3, unit: '', description: 'Dimensionless fine-structure constant' },
  { id: 'faraday_constant', symbol: 'F', name: 'Faraday constant', value: 96485.33212, unit: 'C/mol', description: 'Charge per mole of electrons' },
  { id: 'rydberg_constant', symbol: 'R∞', name: 'Rydberg constant', value: 10973731.568160, unit: '1/m', description: 'Rydberg constant' },
  { id: 'bohr_radius', symbol: 'a₀', name: 'Bohr radius', value: 5.29177210903e-11, unit: 'm', description: 'Bohr radius' },
  { id: 'standard_atmosphere', symbol: 'atm', name: 'standard atmosphere', value: 101325, unit: 'Pa', description: 'Standard atmospheric pressure', exact: true },
  { id: 'standard_gravity', symbol: 'g₀', name: 'standard gravity', value: 9.80665, unit: 'm/s^2', description: 'Standard acceleration of gravity', exact: true },
]

const byKey = new Map<string, ConstantDef>()
for (const constant of PHYSICAL_CONSTANTS) {
  byKey.set(constant.id.toLowerCase(), constant)
  byKey.set(constant.symbol.toLowerCase(), constant)
  byKey.set(constant.name.toLowerCase(), constant)
}

/** Resolve a constant by id, symbol, or name (case-insensitive). */
export function lookupConstant(query: string): ConstantDef | undefined {
  const key = query.trim().toLowerCase()
  if (byKey.has(key)) return byKey.get(key)
  // Substring fallback over names for friendlier lookups.
  return PHYSICAL_CONSTANTS.find(constant =>
    constant.name.toLowerCase().includes(key) || constant.symbol.toLowerCase().includes(key))
}

/** Human-readable list of all constants. */
export function constantSummaries(): string[] {
  return PHYSICAL_CONSTANTS.map(constant =>
    `${constant.symbol} — ${constant.name}: ${constant.value} ${constant.unit}${constant.exact ? ' (exact)' : ''}`)
}
