/**
 * Zero-dependency numerical simulation: a fourth-order Runge–Kutta integrator
 * plus a curated library of common dynamical-system models (safe vector
 * fields — no arbitrary code execution). This is the "simulation engine".
 */

export type VectorField = (t: number, y: number[]) => number[]

/** Integrate a vector field with the classic RK4 method over [t0, t1]. */
export function rk4(f: VectorField, y0: number[], t0: number, t1: number, steps: number): { t: number[]; y: number[][] } {
  const n = Math.max(1, Math.floor(steps))
  const h = (t1 - t0) / n
  const dim = y0.length
  const t: number[] = new Array(n + 1)
  const y: number[][] = new Array(n + 1)
  t[0] = t0
  y[0] = [...y0]

  for (let i = 0; i < n; i += 1) {
    const ti = t[i]!
    const yi = y[i]!
    const k1 = f(ti, yi)
    const k2 = f(ti + h / 2, addScale(yi, k1, h / 2))
    const k3 = f(ti + h / 2, addScale(yi, k2, h / 2))
    const k4 = f(ti + h, addScale(yi, k3, h))
    const next = new Array(dim)
    for (let j = 0; j < dim; j += 1) {
      next[j] = yi[j]! + (h / 6) * (k1[j]! + 2 * k2[j]! + 2 * k3[j]! + k4[j]!)
    }
    t[i + 1] = ti + h
    y[i + 1] = next
  }
  return { t, y }
}

function addScale(base: number[], delta: number[], scale: number): number[] {
  return base.map((value, i) => value + scale * delta[i]!)
}

/* ------------------------------------------------------------------ */
/* Model library                                                      */
/* ------------------------------------------------------------------ */

export interface OdeModel {
  id: string
  name: string
  dim: number
  description: string
  params: Record<string, number>
  y0: number[]
  labels: string[]
  /** Build the vector field from (possibly overridden) parameters. */
  make: (params: Record<string, number>) => VectorField
}

export const ODE_MODELS: readonly OdeModel[] = [
  {
    id: 'exponential', name: 'Exponential growth / decay', dim: 1,
    description: 'dy/dt = r·y (r > 0 grows, r < 0 decays)',
    params: { r: 0.5 }, y0: [1], labels: ['y'],
    make: p => (_t, y) => [p.r! * y[0]!],
  },
  {
    id: 'logistic', name: 'Logistic growth', dim: 1,
    description: 'dy/dt = r·y·(1 − y/K), the S-curve carrying-capacity model',
    params: { r: 0.5, K: 100 }, y0: [1], labels: ['y'],
    make: p => (_t, y) => [p.r! * y[0]! * (1 - y[0]! / p.K!)],
  },
  {
    id: 'harmonic', name: 'Harmonic oscillator', dim: 2,
    description: 'y″ = −ω²·y (undamped spring / simple pendulum small-angle)',
    params: { omega: 1 }, y0: [1, 0], labels: ['y', 'v'],
    make: p => (_t, y) => [y[1]!, -p.omega! * p.omega! * y[0]!],
  },
  {
    id: 'damped', name: 'Damped harmonic oscillator', dim: 2,
    description: 'y″ = −2ζω·y′ − ω²·y',
    params: { omega: 1, zeta: 0.1 }, y0: [1, 0], labels: ['y', 'v'],
    make: p => (_t, y) => [y[1]!, -2 * p.zeta! * p.omega! * y[1]! - p.omega! * p.omega! * y[0]!],
  },
  {
    id: 'pendulum', name: 'Nonlinear pendulum', dim: 2,
    description: 'θ″ = −(g/L)·sin θ',
    params: { g: 9.80665, L: 1 }, y0: [0.1, 0], labels: ['θ', 'ω'],
    make: p => (_t, y) => [y[1]!, -(p.g! / p.L!) * Math.sin(y[0]!)],
  },
  {
    id: 'lotka-volterra', name: 'Lotka–Volterra (predator–prey)', dim: 2,
    description: 'dx/dt = αx − βxy; dy/dt = δxy − γy',
    params: { alpha: 1.0, beta: 0.1, gamma: 1.0, delta: 0.02 }, y0: [10, 5], labels: ['prey', 'predator'],
    make: p => (_t, y) => [
      p.alpha! * y[0]! - p.beta! * y[0]! * y[1]!,
      p.delta! * y[0]! * y[1]! - p.gamma! * y[1]!,
    ],
  },
  {
    id: 'sir', name: 'SIR epidemic', dim: 3,
    description: 'dS/dt = −βSI/N; dI/dt = βSI/N − γI; dR/dt = γI (N = S+I+R)',
    params: { beta: 0.3, gamma: 0.1 }, y0: [999, 1, 0], labels: ['S', 'I', 'R'],
    make: p => (_t, y) => {
      const s = y[0]!
      const i = y[1]!
      const n = s + i + y[2]!
      return [-p.beta! * s * i / n, p.beta! * s * i / n - p.gamma! * i, p.gamma! * i]
    },
  },
  {
    id: 'lorenz', name: 'Lorenz attractor', dim: 3,
    description: "dx/dt = σ(y−x); dy/dt = x(ρ−z)−y; dz/dt = xy − βz",
    params: { sigma: 10, rho: 28, beta: 8 / 3 }, y0: [1, 1, 1], labels: ['x', 'y', 'z'],
    make: p => (_t, y) => [
      p.sigma! * (y[1]! - y[0]!),
      y[0]! * (p.rho! - y[2]!) - y[1]!,
      y[0]! * y[1]! - p.beta! * y[2]!,
    ],
  },
  {
    id: 'van-der-pol', name: 'Van der Pol oscillator', dim: 2,
    description: "x″ = μ(1−x²)x′ − x (relaxation oscillator)",
    params: { mu: 1 }, y0: [1, 0], labels: ['x', 'v'],
    make: p => (_t, y) => [y[1]!, p.mu! * (1 - y[0]! * y[0]!) * y[1]! - y[0]!],
  },
]

export function getModel(id: string): OdeModel | undefined {
  return ODE_MODELS.find(model => model.id === id)
}

/** Merge caller params over a model's defaults, validating keys. */
export function resolveParams(model: OdeModel, overrides: Record<string, number> = {}): Record<string, number> {
  const params: Record<string, number> = { ...model.params }
  for (const [key, value] of Object.entries(overrides)) {
    if (!(key in model.params)) throw new Error(`unknown parameter ${JSON.stringify(key)} for model ${model.id}; expected one of ${Object.keys(model.params).join(', ')}`)
    if (!Number.isFinite(value)) throw new Error(`parameter ${key} must be a finite number`)
    params[key] = value
  }
  return params
}
