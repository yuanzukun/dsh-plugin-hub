/**
 * Physical-unit conversion, zero-dependency. Each unit belongs to a dimension
 * and carries a multiplicative factor (plus an optional affine offset for
 * temperature). Conversion routes through the dimension's base unit.
 */
export interface UnitDef {
    /** Canonical name. */
    name: string;
    /** Lookup aliases (lowercase). */
    aliases: string[];
    /** Dimension key ('length', 'energy', …); conversion requires a match. */
    dimension: string;
    /** Multiply-to-base factor. */
    factor: number;
    /** Affine offset in base units (temperature only). */
    offset?: number;
}
export declare const UNITS: readonly UnitDef[];
/** Resolve a unit by canonical name or alias (case-insensitive). */
export declare function lookupUnit(symbol: string): UnitDef | undefined;
/** List every unit (name + aliases) as human-readable strings. */
export declare function unitNames(): string[];
/**
 * Convert a value between two units of the same dimension. Throws on unknown
 * units or incompatible dimensions.
 */
export declare function convert(value: number, from: string, to: string): number;
