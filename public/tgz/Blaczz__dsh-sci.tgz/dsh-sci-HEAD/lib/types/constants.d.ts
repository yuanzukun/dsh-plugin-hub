/**
 * CODATA 2018 physical constants (SI), zero-dependency. `exact` marks the
 * constants fixed by the 2019 SI redefinition.
 */
export interface ConstantDef {
    id: string;
    symbol: string;
    name: string;
    value: number;
    unit: string;
    description: string;
    exact?: boolean;
}
export declare const PHYSICAL_CONSTANTS: readonly ConstantDef[];
/** Resolve a constant by id, symbol, or name (case-insensitive). */
export declare function lookupConstant(query: string): ConstantDef | undefined;
/** Human-readable list of all constants. */
export declare function constantSummaries(): string[];
