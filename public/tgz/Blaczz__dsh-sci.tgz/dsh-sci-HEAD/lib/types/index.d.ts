/**
 * Host half of dsh-sci: registers three zero-dependency scientific tools.
 * All logic lives in the pure ./units.ts / ./constants.ts / ./ode.ts modules.
 */
import type { Context } from '@deepseek-ai/cordis';
export { convert, lookupUnit, unitNames, UNITS } from './units.ts';
export type { UnitDef } from './units.ts';
export { constantSummaries, lookupConstant, PHYSICAL_CONSTANTS } from './constants.ts';
export type { ConstantDef } from './constants.ts';
export { getModel, ODE_MODELS, resolveParams, rk4 } from './ode.ts';
export type { OdeModel, VectorField } from './ode.ts';
export declare const name = "dsh-sci";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
