/**
 * Zero-dependency numerical simulation: a fourth-order Runge–Kutta integrator
 * plus a curated library of common dynamical-system models (safe vector
 * fields — no arbitrary code execution). This is the "simulation engine".
 */
export type VectorField = (t: number, y: number[]) => number[];
/** Integrate a vector field with the classic RK4 method over [t0, t1]. */
export declare function rk4(f: VectorField, y0: number[], t0: number, t1: number, steps: number): {
    t: number[];
    y: number[][];
};
export interface OdeModel {
    id: string;
    name: string;
    dim: number;
    description: string;
    params: Record<string, number>;
    y0: number[];
    labels: string[];
    /** Build the vector field from (possibly overridden) parameters. */
    make: (params: Record<string, number>) => VectorField;
}
export declare const ODE_MODELS: readonly OdeModel[];
export declare function getModel(id: string): OdeModel | undefined;
/** Merge caller params over a model's defaults, validating keys. */
export declare function resolveParams(model: OdeModel, overrides?: Record<string, number>): Record<string, number>;
