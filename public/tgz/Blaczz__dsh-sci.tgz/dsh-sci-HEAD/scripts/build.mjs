import { spawnSync } from 'node:child_process'

const root = process.cwd()
const result = spawnSync('node', ['node_modules/typescript/bin/tsc', '-p', 'tsconfig.json'], {
  cwd: root,
  stdio: 'inherit',
})
if (result.status !== 0) process.exit(result.status ?? 1)
