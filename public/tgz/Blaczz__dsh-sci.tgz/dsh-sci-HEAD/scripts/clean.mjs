import { rmSync } from 'node:fs'
import { resolve } from 'node:path'

for (const path of ['lib', '.build']) {
  rmSync(resolve(process.cwd(), path), { recursive: true, force: true })
}
