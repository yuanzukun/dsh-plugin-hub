/** ODE integrator and model-library tests. */
import { describe, expect, it } from 'vitest'
import { getModel, ODE_MODELS, resolveParams, rk4 } from '../src/ode.ts'

describe('rk4', () => {
  it('integrates exponential decay to e^-t', () => {
    const f = (_t: number, y: number[]) => [-y[0]!]
    const { t, y } = rk4(f, [1], 0, 1, 200)
    expect(t).toHaveLength(201)
    expect(y[200]![0]).toBeCloseTo(Math.exp(-1), 6)
  })

  it('integrates the harmonic oscillator to cos(t)/-sin(t) over one period', () => {
    const f = (_t: number, y: number[]) => [y[1]!, -y[0]!]
    const { y } = rk4(f, [1, 0], 0, 2 * Math.PI, 4000)
    const last = y[y.length - 1]!
    expect(last[0]).toBeCloseTo(1, 3)   // cos(2π) ≈ 1
    expect(last[1]).toBeCloseTo(0, 2)   // -sin(2π) ≈ 0
  })

  it('produces the requested number of samples', () => {
    const f = (_t: number, y: number[]) => [-y[0]!]
    const { t, y } = rk4(f, [1], 0, 10, 100)
    expect(t.length).toBe(101)
    expect(y.length).toBe(101)
  })
})

describe('model library', () => {
  it('every model produces a vector field of the declared dimension', () => {
    for (const model of ODE_MODELS) {
      const field = model.make({ ...model.params })
      const result = field(0, model.y0)
      expect(result).toHaveLength(model.dim)
    }
  })

  it('resolves each model by id', () => {
    for (const model of ODE_MODELS) {
      expect(getModel(model.id)?.id).toBe(model.id)
    }
    expect(getModel('nonexistent')).toBeUndefined()
  })

  it('sir model conserves total population approximately', () => {
    const sir = getModel('sir')!
    const { y } = rk4(sir.make({ ...sir.params }), sir.y0, 0, 50, 1000)
    const last = y[y.length - 1]!
    expect(last[0]! + last[1]! + last[2]!).toBeCloseTo(1000, 3)
  })
})

describe('resolveParams', () => {
  it('merges overrides and rejects unknown keys', () => {
    const model = getModel('logistic')!
    expect(resolveParams(model, { r: 2 })['r']).toBe(2)
    expect(resolveParams(model, { r: 2 })['K']).toBe(100)
    expect(() => resolveParams(model, { nope: 1 })).toThrow(/unknown parameter/)
    expect(() => resolveParams(model, { r: Number.NaN })).toThrow(/finite/)
  })
})
