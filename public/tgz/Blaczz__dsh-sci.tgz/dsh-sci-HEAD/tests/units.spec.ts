/** Unit-conversion tests. */
import { describe, expect, it } from 'vitest'
import { convert, lookupUnit, unitNames } from '../src/units.ts'

describe('lookupUnit', () => {
  it('resolves by canonical name and aliases, case-insensitively', () => {
    expect(lookupUnit('m')?.name).toBe('meter')
    expect(lookupUnit('METERS')?.name).toBe('meter')
    expect(lookupUnit('µm')?.name).toBe('micrometer')
    expect(lookupUnit('um')?.name).toBe('micrometer')
    expect(lookupUnit('°c')?.name).toBe('celsius')
    expect(lookupUnit('kg')?.dimension).toBe('mass')
  })

  it('returns undefined for unknown units', () => {
    expect(lookupUnit('parsec-per-second')).toBeUndefined()
  })
})

describe('convert', () => {
  it('converts within a dimension', () => {
    expect(convert(1, 'km', 'm')).toBeCloseTo(1000, 10)
    expect(convert(1000, 'm', 'km')).toBeCloseTo(1, 10)
    expect(convert(1, 'eV', 'J')).toBeCloseTo(1.602176634e-19, 24)
    expect(convert(1, 'kWh', 'J')).toBeCloseTo(3.6e6, 10)
    expect(convert(1, 'hour', 's')).toBeCloseTo(3600, 10)
  })

  it('converts affine temperatures', () => {
    expect(convert(0, 'celsius', 'kelvin')).toBeCloseTo(273.15, 10)
    expect(convert(32, 'fahrenheit', 'celsius')).toBeCloseTo(0, 10)
    expect(convert(100, 'celsius', 'fahrenheit')).toBeCloseTo(212, 10)
    expect(convert(0, 'kelvin', 'celsius')).toBeCloseTo(-273.15, 10)
  })

  it('throws on incompatible dimensions', () => {
    expect(() => convert(1, 'm', 'kg')).toThrow(/incompatible dimensions/)
  })

  it('throws on unknown units', () => {
    expect(() => convert(1, 'm', 'light-fortnight')).toThrow(/unknown unit/)
  })
})

describe('unitNames', () => {
  it('lists a reasonable number of units', () => {
    expect(unitNames().length).toBeGreaterThan(50)
  })
})
