/** Physical-constant tests. */
import { describe, expect, it } from 'vitest'
import { constantSummaries, lookupConstant, PHYSICAL_CONSTANTS } from '../src/constants.ts'

describe('lookupConstant', () => {
  it('resolves by id, symbol and name', () => {
    expect(lookupConstant('speed_of_light')?.symbol).toBe('c')
    expect(lookupConstant('c')?.value).toBe(299792458)
    expect(lookupConstant('Boltzmann constant')?.symbol).toBe('k')
  })

  it('falls back to substring match on the name', () => {
    expect(lookupConstant('planck')?.symbol).toBe('h')
    expect(lookupConstant('avogadro')?.symbol).toBe('NA')
  })
})

describe('values', () => {
  it('holds the exact SI-definition constants', () => {
    expect(lookupConstant('c')!.value).toBe(299792458)
    expect(lookupConstant('h')!.value).toBeCloseTo(6.62607015e-34, 40)
    expect(lookupConstant('e')!.value).toBeCloseTo(1.602176634e-19, 28)
    expect(lookupConstant('k')!.value).toBeCloseTo(1.380649e-23, 29)
  })

  it('has a reduced Planck constant equal to h / 2π', () => {
    const h = lookupConstant('h')!.value
    expect(lookupConstant('ħ')!.value).toBeCloseTo(h / (2 * Math.PI), 34)
  })

  it('lists every constant with a value and unit', () => {
    for (const constant of PHYSICAL_CONSTANTS) {
      expect(Number.isFinite(constant.value)).toBe(true)
      expect(typeof constant.symbol).toBe('string')
    }
    expect(constantSummaries().length).toBe(PHYSICAL_CONSTANTS.length)
  })
})
