# dsh-sci 🔬

> DeepSeek Harness 零依赖科学计算工具包：物理单位换算、CODATA 物理常数、Runge–Kutta 常微分方程/动力学仿真。零核心改动。

[English](./README.md) | 简体中文

一个 **DeepSeek Harness（DSH）** 的纯工具插件，注册三个科研日常会用到的模型工具，全部**零依赖纯函数**实现——不联网、不装外部软件、可单测：

| 工具 | 用途 | 示例 |
|---|---|---|
| `units_convert` | 物理量单位换算（长度/质量/时间/温度/能量/压强/频率/力/角度/体积/面积/电学，70+ 单位） | `1 eV → J`、`0 ℃ → K`、`1 kWh → J` |
| `physical_constants` | 查 CODATA 物理常数（c、h、e、k、G、N_A …） | `physical_constants("h")` |
| `ode_solve` | 四阶 Runge–Kutta 数值求解常见动力学系统（**仿真引擎**） | 指数/Logistic/谐振子/阻尼/单摆/捕食者/传染病/洛伦兹/Van der Pol |

## ✨ 特性

- **零依赖**：单位换算、物理常数、RK4 积分器全部手写纯函数，无 `node_modules` 运行时依赖、无网络。
- **安全仿真**：`ode_solve` 用**模型库**（9 个精选动力学系统）+ 参数化，而非任意代码执行——模型可安全调用。
- **精度可验**：RK4 精度与解析解（`e^-t`、`cos t`）在单测中对标。
- **零核心改动**：纯 `ctx.tools.register`，无客户端 bundle。

## 📦 安装

前置：DSH（`dsh web` 可运行）、Node ≥ 22.19、pnpm。

```bash
# GitHub 安装（预构建 lib/ 已提交）
dsh plugin --profile web add "github:Blaczz/dsh-sci#main"

# 本地目录安装
cd dsh-sci && npm install --legacy-peer-deps && npm run build
dsh plugin --profile web add ./dsh-sci
```

安装后**重启 `dsh web`**。然后直接问 agent："把 5 电子伏特换算成焦耳"、"查一下普朗克常数"、"仿真一个阻尼谐振子，ω=2, ζ=0.1，跑到 t=20"。

## 🔬 使用示例

```
用户：帮我仿真 Lotka-Volterra 捕食者模型，alpha=1, beta=0.1, gamma=1, delta=0.02，到 t=50
agent → ode_solve(model="lotka-volterra", params={...}, tEnd=50)
       → 返回时间序列 + 末态 [prey, predator]

用户：1 个电子伏特是多少焦耳？
agent → units_convert(value=1, from="eV", to="J") → 1.602176634e-19

用户：列出所有物理常数
agent → physical_constants() → c, h, e, k, G, N_A, ... 全部
```

## 🛠️ 本地开发

```bash
npm install --legacy-peer-deps
$env:DSH_NODE_MODULES = "$env:USERPROFILE\.dsh\profiles\node_modules"
npm run setup:dsh-workspace
npm run verify                          # ★ 一键门禁：clean + typecheck + test + build
npm test                                # vitest（24 项：单位/常数/ODE 精度 + manifest）
```

## 目录结构

```
dsh-sci/
├── package.json            # dsh.bundle.patch（纯工具插件）
├── cordis.patch.yml        # bundle 补丁层
├── scripts/                # build（仅 tsc）/ clean / setup-dsh-workspace / verify
├── src/
│   ├── units.ts            # ★ 单位换算（70+ 单位，维度 + factor + offset）
│   ├── constants.ts        # ★ CODATA 2018 物理常数
│   ├── ode.ts              # ★ RK4 积分器 + 9 个动力学模型库
│   └── index.ts            # 宿主半：注册 3 个工具
└── tests/                  # units / constants / ode / manifest
```

## 🧩 生态定位

- **填补空白**：DSH 生态此前 `physics`/`ode`/`numerical`/`fft` 主题**零命中**；`units` 的命中全是"unit test/unit economics"假阳性，**无物理单位换算**。已有 `dsh-science` 系列是可复现 Python/R 工作台（非数值工具），`dsh-robotic-harness` 是 MuJoCo 机器人仿真（重依赖）。
- **技术路线**：参考 `omdsh-dev/dsh-tool-*` 的零依赖纯工具范式与 `dsh-tool-calculator` 的递归下降解析思路，纯函数可测。
- **零核心改动**：纯 `ctx.tools.register`，无外部软件、无网络。

## ⚖️ License

MIT © 2026 Blaczz。独立社区插件，与 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 无关。
