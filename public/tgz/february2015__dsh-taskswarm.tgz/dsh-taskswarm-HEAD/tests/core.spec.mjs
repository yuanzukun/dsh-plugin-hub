import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync, mkdirSync, rmSync, existsSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { sanitizeNameComponent, resolveRepoSlug } from '../lib/core/naming.js'
import { parsePrompt, ensureStatusFile, ensureStatusStructure, advanceStep, markTaskRunning, markTaskDone, setTaskStatus, appendExecutionLog, parseStatusFile, explainParseFailure, checkPacketQuality } from '../lib/core/task.js'
import { scanTasks, scanTaskFailures, buildWaves } from '../lib/core/discover.js'
import { writeMailboxMessage, readInbox, ackMessage, sessionInboxDir, SUPERVISOR_SESSION } from '../lib/core/mailbox.js'
import { runGit } from '../lib/core/git.js'
import { ensureOrchWorktree, createLaneWorktree, worktreePaths } from '../lib/core/worktree.js'
import { compactBatchStatus } from '../lib/orchestrator/supervisor.js'

function tmp() {
  return mkdtempSync(join(tmpdir(), 'taskswarm-core-'))
}

function writeTask(dir, id, name, deps, steps) {
  mkdirSync(dir, { recursive: true })
  const stepLines = steps
    .map((s, i) => `### Step ${i}: ${s.title}\n\n${s.items.map((it) => `- [ ] ${it}`).join('\n')}\n`)
    .join('\n')
  const prompt = [
    `# Task: ${id} — ${name}`,
    '',
    '**Size:** S',
    '',
    '## Dependencies',
    ...(deps.length ? deps.map((d) => `- ${d}`) : ['- **None**']),
    '',
    '## Mission',
    `Do ${name}.`,
    '',
    '## File Scope',
    `- ${id}.txt`,
    '',
    '## Steps',
    '',
    stepLines,
    '',
    '## Completion Criteria',
    '',
    `- [ ] ${id}.txt exists`,
    '',
    '---',
  ].join('\n')
  writeFileSync(join(dir, 'PROMPT.md'), prompt, 'utf-8')
  // No STATUS.md on purpose: ensureStatusFile scaffolds it from the packet.
}

test('naming sanitizes components', () => {
  assert.equal(sanitizeNameComponent('Hello World!'), 'hello-world')
  assert.equal(sanitizeNameComponent('  A--B  '), 'a-b')
  assert.equal(resolveRepoSlug('/tmp/My-Repo_Name'), 'my-repo-name')
})

test('parsePrompt extracts id, deps, steps, criteria', () => {
  const root = tmp()
  const dir = join(root, 'TASKSWARM-001-foo')
  writeTask(dir, 'TASKSWARM-001', 'Foo', ['A-001'], [
    { title: 'Preflight', items: ['read prompt', 'read status'] },
    { title: 'Work', items: ['create file'] },
  ])
  const task = parsePrompt(join(dir, 'PROMPT.md'), dir, 'tasks')
  assert.ok(task)
  assert.equal(task.id, 'TASKSWARM-001')
  assert.equal(task.name, 'Foo')
  assert.deepEqual(task.deps, ['A-001'])
  assert.equal(task.steps.length, 2)
  assert.equal(task.steps[1].items[0].text, 'create file')
  assert.equal(task.steps[1].items[0].checked, false)
  assert.ok(task.completionCriteria.includes('TASKSWARM-001.txt exists'))
  rmSync(root, { recursive: true, force: true })
})

test('advanceStep ticks checkboxes and markTaskDone sets status', () => {
  const root = tmp()
  const dir = join(root, 'TASKSWARM-002-bar')
  writeTask(dir, 'TASKSWARM-002', 'Bar', [], [
    { title: 'Preflight', items: ['a', 'b'] },
  ])
  const task = parsePrompt(join(dir, 'PROMPT.md'), dir, 'tasks')
  ensureStatusFile(task)
  const first = advanceStep(task, 0)
  assert.equal(first.item, 'a')
  const statusAfter = parseStatusFile(dir)
  assert.equal(statusAfter.status, 'running')
  markTaskDone(dir)
  assert.equal(parseStatusFile(dir).status, 'done')
  assert.ok(existsSync(join(dir, '.DONE')))
  rmSync(root, { recursive: true, force: true })
})

test('markTaskRunning sets Current Step and step status consistently (B4)', () => {
  const root = tmp()
  const dir = join(root, 'TASKSWARM-003-baz')
  writeTask(dir, 'TASKSWARM-003', 'Baz', [], [
    { title: 'Preflight', items: ['a', 'b'] },
    { title: 'Work', items: ['c'] },
  ])
  const task = parsePrompt(join(dir, 'PROMPT.md'), dir, 'tasks')
  ensureStatusFile(task)
  // Before: Current Step is the scaffolded initial "Not Started".
  assert.equal(parseStatusFile(dir).currentStep, 'Not Started')
  // After markTaskRunning: Current Step = first step title, status running.
  const title = markTaskRunning(dir, task)
  assert.equal(title, 'Preflight')
  const info = parseStatusFile(dir)
  assert.equal(info.status, 'running')
  assert.equal(info.currentStep, 'Preflight')
  const content = readFileSync(join(dir, 'STATUS.md'), 'utf-8')
  assert.match(content, /### Step 0: Preflight\n\*\*Status:\*\* 🟢 In Progress/, 'step 0 marked in progress')
  assert.match(content, /^\*\*Current Step:\*\* Preflight$/m, 'Current Step updated')
  rmSync(root, { recursive: true, force: true })
})

test('parseStatusFile reports checked/total checkbox counts (KI-008)', () => {
  const root = tmp()
  const dir = join(root, 'TASKSWARM-004-qux')
  writeTask(dir, 'TASKSWARM-004', 'Qux', [], [
    { title: 'Work', items: ['a', 'b', 'c'] },
  ])
  const task = parsePrompt(join(dir, 'PROMPT.md'), dir, 'tasks')
  ensureStatusFile(task)
  // Initially: 0/3.
  let info = parseStatusFile(dir)
  assert.equal(info.checked, 0)
  assert.equal(info.total, 3)
  // Advance once: 1/3.
  advanceStep(task, 0)
  info = parseStatusFile(dir)
  assert.equal(info.checked, 1)
  assert.equal(info.total, 3)
  rmSync(root, { recursive: true, force: true })
})

test('ensureStatusStructure rebuilds missing Step sections from PROMPT', () => {
  const root = tmp()
  const dir = join(root, 'TASKSWARM-005-quux')
  writeTask(dir, 'TASKSWARM-005', 'Quux', [], [
    { title: 'Work', items: ['a', 'b', 'c'] },
  ])
  const task = parsePrompt(join(dir, 'PROMPT.md'), dir, 'tasks')
  // 模拟任务包创建方只写了 Status 头 + Execution Log、缺 Step 段（手工/其它 AI 创建）。
  const logLine = '| 2026-08-16 | Created | pending |'
  writeFileSync(join(dir, 'STATUS.md'), [
    `# TASKSWARM-005: Quux — Status`,
    '**Status:** 🟢 In Progress',
    '**Current Step:** Not Started',
    '',
    '---',
    '',
    '## Execution Log',
    '',
    '| Timestamp | Action | Outcome |',
    '|---|---|---|',
    logLine,
  ].join('\n') + '\n', 'utf-8')

  // 补建前：无 Step 段。
  assert.equal(/### Step \d+: /.test(readFileSync(join(dir, 'STATUS.md'), 'utf-8')), false)

  // ensureStatusStructure 直接补建：Step 段从 PROMPT 注入，Execution Log 行保留。
  assert.equal(ensureStatusStructure(task), true)
  let content = readFileSync(join(dir, 'STATUS.md'), 'utf-8')
  assert.match(content, /### Step 0: Work/, 'Step 0 section rebuilt')
  assert.equal((content.match(/- \[ \]/g) || []).length, 3, '3 unchecked checkboxes from PROMPT')
  assert.ok(content.includes(logLine), 'existing Execution Log row preserved (inject, not rewrite)')
  assert.equal(ensureStatusStructure(task), false, 'idempotent: no rebuild when Step sections exist')

  // 已有 Step 段时 advance 直接勾选。
  const first = advanceStep(task, 0)
  assert.equal(first.item, 'a')
  assert.equal(parseStatusFile(dir).checked, 1)
  rmSync(root, { recursive: true, force: true })
})

test('advanceStep auto-rebuilds a missing Step section before ticking (defense-in-depth)', () => {
  const root = tmp()
  const dir = join(root, 'TASKSWARM-006-quuz')
  writeTask(dir, 'TASKSWARM-006', 'Quuz', [], [
    { title: 'Work', items: ['a', 'b', 'c'] },
  ])
  const task = parsePrompt(join(dir, 'PROMPT.md'), dir, 'tasks')
  // 只写 Status 头，连 Execution Log 都没有——最残缺的情况。
  writeFileSync(join(dir, 'STATUS.md'), [
    `# TASKSWARM-006: Quuz — Status`,
    '**Status:** 🟢 In Progress',
    '**Current Step:** Not Started',
    '',
    '---',
  ].join('\n') + '\n', 'utf-8')

  // advance 自带防御：缺 Step 段时先补建再勾选（不再静默失败）。
  const first = advanceStep(task, 0)
  assert.equal(first.item, 'a', 'advance auto-rebuilds missing Step section and ticks')
  assert.equal(parseStatusFile(dir).checked, 1)
  assert.equal(parseStatusFile(dir).total, 3)
  rmSync(root, { recursive: true, force: true })
})

test('all STATUS.md write entry points rebuild missing Step sections (write-path guard)', () => {
  const root = tmp()
  const dir = join(root, 'TASKSWARM-007-quve')
  writeTask(dir, 'TASKSWARM-007', 'Quve', [], [
    { title: 'Work', items: ['a', 'b'] },
  ])
  const task = parsePrompt(join(dir, 'PROMPT.md'), dir, 'tasks')
  const writeBare = () => writeFileSync(join(dir, 'STATUS.md'), [
    `# TASKSWARM-007: Quve — Status`,
    '**Status:** 🔵 Ready for Execution',
    '**Current Step:** Not Started',
    '',
    '---',
  ].join('\n') + '\n', 'utf-8')

  // 1) setTaskStatus（任务状态更新）→ 补建。
  writeBare()
  setTaskStatus(dir, 'running')
  assert.equal(parseStatusFile(dir).total, 2, 'setTaskStatus ensures structure')

  // 2) markTaskDone（任务成功/完成）→ 补建。
  writeBare()
  markTaskDone(dir)
  assert.equal(parseStatusFile(dir).total, 2, 'markTaskDone ensures structure')
  assert.equal(parseStatusFile(dir).status, 'done')

  // 3) markTaskRunning（lane 启动/状态变更）→ 补建。
  writeBare()
  markTaskRunning(dir, task)
  assert.equal(parseStatusFile(dir).total, 2, 'markTaskRunning ensures structure')

  // 4) appendExecutionLog（任务日志追加）→ 补建。
  writeBare()
  appendExecutionLog(dir, 'Lane started', 'lane 1')
  assert.equal(parseStatusFile(dir).total, 2, 'appendExecutionLog ensures structure')

  // 5) advanceStep（任务推进）→ 补建（前一测试已覆盖，这里只确认成功勾选）。
  writeBare()
  const r = advanceStep(task, 0)
  assert.equal(r.item, 'a')

  rmSync(root, { recursive: true, force: true })
})

test('discover + buildWaves layers independent tasks first', () => {
  const root = tmp()
  const tasksRoot = join(root, 'tasks')
  writeTask(join(tasksRoot, 'A-001-x'), 'A-001', 'X', [], [{ title: 'S', items: ['a'] }])
  writeTask(join(tasksRoot, 'B-002-y'), 'B-002', 'Y', [], [{ title: 'S', items: ['a'] }])
  writeTask(join(tasksRoot, 'C-003-z'), 'C-003', 'Z', ['A-001'], [{ title: 'S', items: ['a'] }])
  const discovered = scanTasks(tasksRoot)
  assert.equal(discovered.length, 3)
  const waves = buildWaves(discovered.map((d) => d.task))
  assert.deepEqual(waves.waves.map((w) => w.map((t) => t.id).sort()), [['A-001', 'B-002'], ['C-003']])
  rmSync(root, { recursive: true, force: true })
})

test('mailbox write/read/ack round-trips', () => {
  const root = tmp()
  const inbox = sessionInboxDir(root, 'batch-1', SUPERVISOR_SESSION)
  const m1 = writeMailboxMessage(inbox, 'lane-1', SUPERVISOR_SESSION, 'notify', { text: 'hi' })
  const m2 = writeMailboxMessage(inbox, 'lane-2', SUPERVISOR_SESSION, 'escalate', { text: 'help' })
  const all = readInbox(inbox)
  assert.equal(all.length, 2)
  assert.deepEqual(new Set(all.map((m) => m.id)), new Set([m1.id, m2.id]))
  assert.ok(all.some((m) => m.type === 'escalate'))
  const files = readdirSync(inbox).filter((n) => !n.startsWith('.'))
  assert.equal(files.length, 2)
  for (const file of files) {
    assert.ok(ackMessage(inbox, file))
  }
  assert.equal(readInbox(inbox).length, 0)
  rmSync(root, { recursive: true, force: true })
})

test('human-readable legacy packets are reported as parse failures, not silently dropped', () => {
  const root = tmp()
  // The exact failure mode from dsh-localvoice: folder T1 + "# T1 插件骨架" heading.
  const dir = join(root, 'T1')
  mkdirSync(dir, { recursive: true })
  writeFileSync(join(dir, 'PROMPT.md'), ['# T1 插件骨架', '', '## 目标', '搭建插件骨架', '', '## 验收标准（DoD）', '- [ ] ok'].join('\n'), 'utf-8')
  // parsePrompt itself returns null…
  assert.equal(parsePrompt(join(dir, 'PROMPT.md'), dir, 'tasks'), null)
  // …explainParseFailure gives the actionable cause…
  const reason = explainParseFailure(join(dir, 'PROMPT.md'), dir)
  assert.match(reason, /# Task:/)
  // …and scanTaskFailures surfaces the folder (where scanTasks silently skips it).
  assert.equal(scanTasks(root).length, 0)
  const fails = scanTaskFailures(root)
  assert.equal(fails.length, 1)
  assert.equal(fails[0].folder, 'T1')
  rmSync(root, { recursive: true, force: true })
})

test('invalid heading ID (T1 without hyphen) explains the [A-Z]+-\\d+ rule', () => {
  const root = tmp()
  const dir = join(root, 'TASK1')
  mkdirSync(dir, { recursive: true })
  writeFileSync(join(dir, 'PROMPT.md'), ['# Task: TASK1 — 无连字符', '', '## Mission', 'do it'].join('\n'), 'utf-8')
  assert.equal(parsePrompt(join(dir, 'PROMPT.md'), dir, 'tasks'), null)
  assert.match(explainParseFailure(join(dir, 'PROMPT.md'), dir), /\[A-Z\]\+-\\d\+/)
  rmSync(root, { recursive: true, force: true })
})

test('checkPacketQuality flags missing steps / criteria / file scope', () => {
  const root = tmp()
  const ok = join(root, 'OK-001-x')
  writeTask(ok, 'OK-001', 'X', [], [{ title: 'A', items: ['a'] }])
  const okTasks = scanTasks(root, true)
  assert.equal(okTasks.length, 1)
  assert.deepEqual(checkPacketQuality(okTasks[0].task), [])

  const bad = join(root, 'BAD-002-y')
  mkdirSync(bad, { recursive: true })
  writeFileSync(join(bad, 'PROMPT.md'), ['# Task: BAD-002 — Y', '', '**Size:** S', '', '## Mission', 'do it', '', '## Completion Criteria', '- [ ] done'].join('\n'), 'utf-8')
  const packet = parsePrompt(join(bad, 'PROMPT.md'), bad, 'bad')
  assert.ok(packet)
  const warnings = checkPacketQuality(packet)
  assert.ok(warnings.some((w) => w.includes('Step')))
  assert.ok(warnings.some((w) => w.includes('File Scope')))
  rmSync(root, { recursive: true, force: true })
})

test('lane worktrees are based on taskswarm/orch HEAD, not the working branch', () => {
  const root = tmp()
  runGit(['init', '-q'], root)
  runGit(['config', 'user.email', 'test@example.com'], root)
  runGit(['config', 'user.name', 'test'], root)
  writeFileSync(join(root, 'master.txt'), 'master only\n')
  runGit(['add', '-A'], root)
  runGit(['commit', '-m', 'master base'], root)

  const paths = worktreePaths(root, join(root, '.taskswarm'))
  assert.equal(ensureOrchWorktree(root, paths).ok, true)
  // Simulate a merged lane: commit T-1's output onto orch only (not on master).
  writeFileSync(join(paths.orchWorktree, 't1-output.txt'), 'merged by T-1\n')
  runGit(['add', '-A'], paths.orchWorktree)
  runGit(['commit', '-m', 'T-1 merged'], paths.orchWorktree)

  const lane = createLaneWorktree(root, paths, 'T-2')
  assert.ok(lane, 'lane worktree should be created')
  // The lane must inherit the orch-only file (baseline = orch HEAD).
  assert.equal(existsSync(join(lane.dir, 't1-output.txt')), true, 'lane must contain orch-merged output')
  assert.equal(existsSync(join(lane.dir, 'master.txt')), true)
  const head = runGit(['log', '--oneline', '-1'], lane.dir)
  assert.match(head.stdout, /T-1 merged/)

  runGit(['worktree', 'remove', '--force', lane.dir], root)
  runGit(['worktree', 'remove', '--force', paths.orchWorktree], root)
  rmSync(root, { recursive: true, force: true })
})

test('retried lanes attach the old branch, keep checkpoints, and merge newer orch work', () => {
  const root = tmp()
  runGit(['init', '-q'], root)
  runGit(['config', 'user.email', 'test@example.com'], root)
  runGit(['config', 'user.name', 'test'], root)
  writeFileSync(join(root, 'base.txt'), 'base\n')
  runGit(['add', '-A'], root)
  runGit(['commit', '-m', 'base'], root)

  const paths = worktreePaths(root, join(root, '.taskswarm'))
  assert.equal(ensureOrchWorktree(root, paths).ok, true)

  // First run: lane based on orch v1, worker checkpoints some work.
  const lane1 = createLaneWorktree(root, paths, 'T-3')
  assert.ok(lane1)
  writeFileSync(join(lane1.dir, 'checkpoint.txt'), 'old checkpoint\n')
  runGit(['add', '-A'], lane1.dir)
  runGit(['commit', '-m', 'checkpoint 1'], lane1.dir)
  runGit(['worktree', 'remove', '--force', lane1.dir], root) // engine cleans the worktree, branch kept

  // orch advances (another task merged).
  writeFileSync(join(paths.orchWorktree, 't2-output.txt'), 'merged by T-2\n')
  runGit(['add', '-A'], paths.orchWorktree)
  runGit(['commit', '-m', 'T-2 merged'], paths.orchWorktree)

  // Retry: recreate the lane → attaches existing branch + merges newer orch.
  const lane2 = createLaneWorktree(root, paths, 'T-3')
  assert.ok(lane2)
  assert.equal(existsSync(join(lane2.dir, 'checkpoint.txt')), true, 'old checkpoint preserved')
  assert.equal(existsSync(join(lane2.dir, 't2-output.txt')), true, 'newer orch work merged in')

  runGit(['worktree', 'remove', '--force', lane2.dir], root)
  runGit(['worktree', 'remove', '--force', paths.orchWorktree], root)
  rmSync(root, { recursive: true, force: true })
})

test('checkPacketQuality flags silent dependency/File-Scope problems (feedback A/C)', () => {
  const root = tmp()
  const t1 = join(root, 'T-001-a')
  mkdirSync(t1, { recursive: true })
  // Dependencies 节存在但只有非 ID 行（旧式 `- **Task:** 无`）→ 应警告（P1/P9 静默坑）。
  writeFileSync(join(t1, 'PROMPT.md'), [
    '# Task: T-001 — A',
    '## Dependencies',
    '- **Task:** 无',
    '## File Scope',
    '- src/a.rs',
    '## Steps',
    '### Step 0: Work',
    '- [ ] do',
    '## Completion Criteria',
    '- [ ] done',
    '---',
  ].join('\n'), 'utf-8')
  const p1 = parsePrompt(join(t1, 'PROMPT.md'), t1, '')
  assert.ok(p1)
  const w1 = checkPacketQuality(p1)
  assert.ok(w1.some((w) => w.includes('Dependencies') && w.includes('ID')), 'non-ID dependency lines flagged')

  // File Scope 含注释行（`- > xxx`）→ 应警告（P3 fail-fast 诉求）。
  const t2 = join(root, 'T-002-b')
  mkdirSync(t2, { recursive: true })
  writeFileSync(join(t2, 'PROMPT.md'), [
    '# Task: T-002 — B',
    '## Dependencies',
    '- **None**',
    '## File Scope',
    '- > 这是注释',
    '- src/b.rs',
    '## Steps',
    '### Step 0: Work',
    '- [ ] do',
    '## Completion Criteria',
    '- [ ] done',
    '---',
  ].join('\n'), 'utf-8')
  const p2 = parsePrompt(join(t2, 'PROMPT.md'), t2, '')
  assert.ok(p2)
  const w2 = checkPacketQuality(p2)
  assert.ok(w2.some((w) => w.includes('File Scope')), 'File-Scope comment line flagged')

  // 合法：`- **None**` 无依赖不警告。
  const t3 = join(root, 'T-003-c')
  mkdirSync(t3, { recursive: true })
  writeFileSync(join(t3, 'PROMPT.md'), [
    '# Task: T-003 — C',
    '## Dependencies',
    '- **None**',
    '## File Scope',
    '- src/c.rs',
    '## Steps',
    '### Step 0: Work',
    '- [ ] do',
    '## Completion Criteria',
    '- [ ] done',
    '---',
  ].join('\n'), 'utf-8')
  const p3 = parsePrompt(join(t3, 'PROMPT.md'), t3, '')
  assert.ok(p3)
  const w3 = checkPacketQuality(p3)
  assert.ok(!w3.some((w) => w.includes('Dependencies')), 'explicit None is not flagged')
  assert.ok(!w3.some((w) => w.includes('File Scope')), 'clean File Scope is not flagged')

  rmSync(root, { recursive: true, force: true })
})

function statusState(lanes, phase, wavePlan) {
  return {
    id: 'B1',
    phase,
    tasksRoot: '/nonexistent-tasks',
    wavePlan,
    lanes: lanes.map(([taskId, p], i) => ({ taskId, phase: p, lane: i + 1 })),
  }
}

test('compactBatchStatus: paused before wave 2 shows wave-1 failure, not a clean wave', () => {
  // JM-406 场景：波次 1 有 failed lane，批次暂停于波次 2 前。"暂停于波次 2/3 前"
  // 绝不能读成"波次 1 全部完成"——头部必须把波次 1 的失败明确标出来。
  // lane 列表只列当前波（W2 的 B）——失败由头部 abnormalNote 承担（display-current-wave）。
  const state = statusState([['A', 'failed'], ['B', 'pending'], ['C', 'pending']], 'paused', [['A'], ['B'], ['C']])
  const zh = compactBatchStatus(state, 'zh-CN')
  assert.match(zh, /暂停于波次 2\/3 前/)
  assert.match(zh, /波次 1 有失败任务/)
  assert.match(zh, /已完成 0\/3/)
  // 只列当前波 lane（B），不列 W1 的失败 lane A。
  assert.match(zh, /lane 2 \[等待中\] B/)
  assert.doesNotMatch(zh, /lane 1/)
  const en = compactBatchStatus(state, 'en')
  assert.match(en, /paused before wave 2\/3/)
  assert.match(en, /wave 1 has 1 failed/)
})

test('compactBatchStatus: clean pause (wave merged) does not claim failure', () => {
  const state = statusState([['A', 'merged'], ['B', 'pending'], ['C', 'pending']], 'paused', [['A'], ['B'], ['C']])
  const zh = compactBatchStatus(state, 'zh-CN')
  assert.match(zh, /暂停于波次 2\/3 前/)
  assert.doesNotMatch(zh, /有失败任务/)
  assert.match(zh, /已完成 1\/3/)
  // 只列当前波 lane（B），不列 W1 的已合并 lane A。
  assert.match(zh, /lane 2 \[等待中\] B/)
  assert.doesNotMatch(zh, /lane 1/)
})

test('compactBatchStatus: conflict lane in paused wave is surfaced too', () => {
  const state = statusState([['A', 'conflict'], ['B', 'pending'], ['C', 'pending']], 'paused', [['A'], ['B'], ['C']])
  const zh = compactBatchStatus(state, 'zh-CN')
  assert.match(zh, /波次 1 有冲突待处置/)
})

test('compactBatchStatus: last wave failed -> paused after all waves, no bogus N+1', () => {
  const state = statusState([['A', 'merged'], ['B', 'merged'], ['C', 'failed']], 'paused', [['A'], ['B'], ['C']])
  const zh = compactBatchStatus(state, 'zh-CN')
  assert.match(zh, /暂停于全部波次执行完后/)
  assert.match(zh, /波次 3 有失败任务/)
  assert.doesNotMatch(zh, /4\/3/)
})

test('compactBatchStatus: running state keeps wave index, no pause annotation', () => {
  const state = statusState([['A', 'merged'], ['B', 'running'], ['C', 'pending']], 'running', [['A'], ['B'], ['C']])
  const zh = compactBatchStatus(state, 'zh-CN')
  assert.match(zh, /· 波次 2\/3/)
  assert.doesNotMatch(zh, /暂停于/)
  assert.match(zh, /lane 2 \[运行中\] B/)
})
