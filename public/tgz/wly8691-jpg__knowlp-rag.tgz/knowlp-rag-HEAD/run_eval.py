#!/usr/bin/env python
"""
KnowLP-RAG retrieval evaluation script v2.1

- Hybrid mode by default (--hybrid)
- Computes Precision@5, Recall@5, MRR
- Groups by query type to expose weak spots

2026-08-02 FIX: Pass log_feedback=False to prevent eval from polluting
the feedback log with fake "consumed" signals.
"""
import json, sys
from pathlib import Path
from collections import defaultdict
from datetime import datetime

from config import GRAPH_DIR
# Pit-1 discipline: never sys.path.insert(0, GRAPH_DIR) — GRAPH_DIR is a pure data directory;
# inserting it would make eval import stale code copies. eval uses repo-root code only.


def load_queries():
    # Real ground truth is not in the repo (contains personal note titles). Clone users can copy the example:
    #   cp eval_queries.example.json eval_queries.json  (build your own graph, then self-evaluate)
    path = GRAPH_DIR / 'eval_queries.json'
    if not path.exists():
        print("⚠️  eval_queries.json missing — copy eval_queries.example.json and rerun")
        sys.exit(1)
    return json.loads(path.read_text(encoding='utf-8'))


def run_search(query: str, hybrid: bool = False, top_k: int = 5):
    """FIXED: Disable feedback logging during eval."""
    from knowlp_search import load_graph, retrieval_router, retrieval_router_hybrid
    graph, meta, meta_by_name, meta_by_path = load_graph()

    if hybrid:
        result = retrieval_router_hybrid(query, graph, meta, meta_by_name, meta_by_path,
                                         top_k=top_k, log_feedback=False)
    else:
        result = retrieval_router(query, graph, meta, meta_by_name, meta_by_path,
                                  top_k=top_k, log_feedback=False)

    names = [r['name'] for r in result.get('merged', [])]
    return names, result


def evaluate(query_item: dict, hybrid: bool = False, k: int = 5) -> dict:
    query = query_item['query']
    relevant = set(query_item['relevant'])

    returned, full = run_search(query, hybrid=hybrid, top_k=k)
    returned_k = returned[:k]

    tp_k = len(set(returned_k) & relevant)
    precision_k = tp_k / min(k, max(1, len(returned_k))) if returned_k else 0.0
    recall_k = tp_k / max(1, len(relevant))

    f1 = 2 * precision_k * recall_k / max(0.001, precision_k + recall_k)

    mrr = 0.0
    first_hit_rank = None
    for i, name in enumerate(returned_k):
        if name in relevant:
            first_hit_rank = i + 1
            mrr = 1.0 / first_hit_rank
            break

    return {
        'id': query_item['id'],
        'query': query,
        'type': query_item.get('type', ''),
        'notes': query_item.get('notes', ''),
        'returned': returned_k,
        'relevant': list(relevant),
        'tp': tp_k,
        'precision@k': round(precision_k, 3),
        'recall@k': round(recall_k, 3),
        'f1': round(f1, 3),
        'mrr': round(mrr, 3),
        'first_hit_rank': first_hit_rank,
        'total_returned': len(returned),
        'total_relevant': len(relevant),
    }


def print_type_summary(results: list[dict]):
    by_type = defaultdict(list)
    for r in results:
        by_type[r['type']].append(r)

    print(f"\n{'─' * 60}")
    print(f"📊 Performance by query type:")
    print(f"{'type':<20s} {'n':>4s} {'P@5':>6s} {'R@5':>6s} {'MRR':>6s} {'F1':>6s} {'zero-recall':>6s}")
    print(f"{'─' * 60}")

    type_order = sorted(by_type.items(),
                        key=lambda x: sum(r['f1'] for r in x[1]) / len(x[1]))

    for ttype, items in type_order:
        n = len(items)
        avg_p = sum(r['precision@k'] for r in items) / n
        avg_r = sum(r['recall@k'] for r in items) / n
        avg_m = sum(r['mrr'] for r in items) / n
        avg_f = sum(r['f1'] for r in items) / n
        zeros = sum(1 for r in items if r['recall@k'] == 0)
        bar = "█" * int(avg_f * 20) if avg_f > 0 else "▁"
        print(f"{ttype:<20s} {n:>4d} {avg_p:>6.3f} {avg_r:>6.3f} {avg_m:>6.3f} {avg_f:>6.3f} {zeros:>4d}/{n}  {bar}")

    worst = type_order[0] if type_order else ("?", [])
    print(f"\n⚠️ weakest type: '{worst[0]}' (F1={sum(r['f1'] for r in worst[1])/len(worst[1]):.3f})")
    if worst[1]:
        for r in worst[1]:
            print(f"   [{r['id']}] {r['query'][:50]} — {r['notes']}")


def main():
    args = sys.argv[1:]
    # --v3 delegates to the graded, ranking-aware benchmark (benchmarks/eval_v3.py)
    if '--v3' in args:
        args = [a for a in args if a != '--v3']
        sys.argv = [sys.argv[0]] + args
        benchmarks_dir = Path(__file__).resolve().parent / 'benchmarks'
        sys.path.insert(0, str(benchmarks_dir))
        import eval_v3
        eval_v3.main()
        return
    hybrid = '--graph-only' not in args
    compare = '--compare' in args
    k = 5

    queries = load_queries()
    mode = "Hybrid" if hybrid else "Graph-only"

    print(f"\n📊 KnowLP-RAG evaluation — {mode} mode (P@5 / R@5 / MRR)")
    print(f"   queries: {len(queries)}")
    print(f"   time:   {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"   (feedback logging DISABLED during eval)")

    if compare:
        print(f"\n{'═' * 50}")
        results_g = [evaluate(q, hybrid=False, k=k) for q in queries]
        results_h = [evaluate(q, hybrid=True, k=k) for q in queries]

        for label, res in [("Graph-only", results_g), ("Hybrid", results_h)]:
            avg_p = sum(r['precision@k'] for r in res) / len(res)
            avg_r = sum(r['recall@k'] for r in res) / len(res)
            avg_m = sum(r['mrr'] for r in res) / len(res)
            avg_f = sum(r['f1'] for r in res) / len(res)
            zeros = sum(1 for r in res if r['recall@k'] == 0)
            print(f"\n  {label}: P@5={avg_p:.3f} R@5={avg_r:.3f} MRR={avg_m:.3f} F1={avg_f:.3f} zero-recall={zeros}/{len(res)}")

        results = results_h
    else:
        results = [evaluate(q, hybrid=hybrid, k=k) for q in queries]

    print(f"\n{'─' * 80}")
    for r in results:
        status = "✅" if r['f1'] >= 0.5 else ("⚠️" if r['f1'] > 0 else "❌")
        mrr_str = f"MRR={r['mrr']:.2f}" if r['mrr'] > 0 else "MRR=0  "
        hit_str = f"rank#{r['first_hit_rank']}" if r['first_hit_rank'] else "miss"
        print(f"  {status} [{r['id']:2d}] {mrr_str} | {r['query'][:45]:45s} | {hit_str} | "
              f"P@5={r['precision@k']:.2f} R@5={r['recall@k']:.2f} "
            f"(hits {r['tp']}/{r['total_relevant']})")

    avg_p = sum(r['precision@k'] for r in results) / len(results)
    avg_r = sum(r['recall@k'] for r in results) / len(results)
    avg_m = sum(r['mrr'] for r in results) / len(results)
    avg_f = sum(r['f1'] for r in results) / len(results)
    zeros = sum(1 for r in results if r['recall@k'] == 0)
    hits = sum(1 for r in results if r['mrr'] > 0)

    print(f"\n{'═' * 50}")
    print(f"📊 Summary ({mode}, P@5 / R@5 / MRR):")
    print(f"   Precision@5:  {avg_p:.3f}")
    print(f"   Recall@5:     {avg_r:.3f}")
    print(f"   MRR:          {avg_m:.3f}")
    print(f"   F1:           {avg_f:.3f}")
    print(f"   MRR>0:        {hits}/{len(results)} ({100*hits/len(results):.0f}%)")
    print(f"   zero recall:       {zeros}/{len(results)}")

    print_type_summary(results)

    out = GRAPH_DIR / f"eval_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps({
        'mode': mode, 'k': k, 'timestamp': datetime.now().isoformat(),
        'avg_precision': round(avg_p, 3), 'avg_recall': round(avg_r, 3),
        'avg_mrr': round(avg_m, 3), 'avg_f1': round(avg_f, 3),
        'mrr_hit_count': hits, 'zero_recall_count': zeros,
        'results': results,
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"\n📁 {out}")


if __name__ == '__main__':
    main()
