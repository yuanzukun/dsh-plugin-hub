#!/usr/bin/env python
"""
KnowLP-RAG: EDU-GraphRAG — Obsidian vault knowledge-graph construction
Based on the GraphRAG-Induced Dual Knowledge Structure Graphs (KnowLP) paper

Phase 1: metadata extraction + explicit links → initial dual graph
Phase 2: LLM deep relation extraction → enriched prerequisite + similarity graphs

2026-08-02 FIXES:
  - Fix: name_index keys on name only, preventing path pollution from creating dead edges
  - Fix: rebuild preserves _last_feedback_applied and _feedback_stats
"""
import json, re, os, sys, time, urllib.request
from pathlib import Path
from datetime import datetime
from collections import defaultdict

from config import VAULT, GRAPH_DIR, DEEP_DIRS, EXCLUDE_DIRS, EXCLUDE_FILES

# ====================== Helpers ======================

STOP_WORDS = {
    '\u7684','\u4e86','\u5728','\u662f','\u6211','\u6709','\u548c','\u5c31','\u4e0d','\u4eba','\u90fd','\u4e00','\u4e00\u4e2a',
    '\u4e0a','\u4e5f','\u5f88','\u5230','\u8bf4','\u8981','\u53bb','\u4f60','\u4f1a','\u7740','\u6ca1\u6709','\u770b','\u597d',
    '\u81ea\u5df1','\u8fd9','\u4ed6','\u5979','\u5b83','\u4eec','\u90a3','\u4e9b','\u6240','\u4e3a','\u6240\u4ee5','\u56e0\u4e3a',
    '\u4f46\u662f','\u5982\u679c','\u867d\u7136','\u53ef\u4ee5','\u8fd9\u4e2a','\u90a3\u4e2a','\u4ec0\u4e48','\u600e\u4e48','\u54ea','\u5417',
    '\u554a','\u5462','\u5427','\u54e6','\u55ef','\u54c8','\u563f\u563f','the','a','an','is','are',
    'was','were','be','been','being','have','has','had','having','do',
    'does','did','doing','will','would','shall','should','may','might',
    'must','can','could','to','of','in','for','on','with','at','by',
    'from','as','into','through','during','before','after','above',
    'below','between','under','again','further','then','once','here',
    'there','when','where','why','how','all','both','each','few','more',
    'most','other','some','such','no','nor','not','only','own','same',
    'so','than','too','very','just','about','up','out','over','now',
    'and','that','but','or','which','who','whom','this','it','its',
}

def _tokenize(text: str) -> set[str]:
    """Tokenize summary text into meaningful word set."""
    words = re.findall(r'[\u4e00-\u9fff]{2,}|[a-zA-Z]{3,}', text.lower())
    return {w for w in words if w not in STOP_WORDS}

def _jaccard(a: set, b: set) -> float:
    """Jaccard similarity between two sets."""
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)

def _summary_overlap(m1: dict, m2: dict) -> int:
    """Count shared meaningful words in summaries."""
    s1 = _tokenize(m1.get('summary', '')[:500])
    s2 = _tokenize(m2.get('summary', '')[:500])
    return len(s1 & s2)

# ====================== Phase 1: Metadata Extraction ======================

def extract_metadata(filepath: Path) -> dict:
    """Extract frontmatter, headings, wikilinks, tags from a markdown file."""
    try:
        text = filepath.read_text(encoding='utf-8')
    except:
        return None

    meta = {
        'path': str(filepath.relative_to(VAULT)),
        'name': filepath.stem,
        'size': len(text),
        'mtime': filepath.stat().st_mtime,  # decision-3: write the real timestamp at build time, replacing post-hoc file mtime
        'headings': [],
        'tags': [],
        'wikilinks': [],   # [[...]] links
        'frontmatter': {},
        'summary': '',      # first 300 chars after frontmatter
    }

    # Extract frontmatter
    fm_match = re.match(r'^---\s*\n(.*?)\n---\s*\n', text, re.DOTALL)
    if fm_match:
        fm_text = fm_match.group(1)
        for line in fm_text.split('\n'):
            if ':' in line:
                k, _, v = line.partition(':')
                v = v.strip().strip('"').strip("'")
                k = k.strip()
                if k == 'tags':
                    meta['tags'] = [t.strip() for t in v.strip('[]').split(',') if t.strip()]
                else:
                    meta['frontmatter'][k] = v
        body = text[fm_match.end():]
    else:
        body = text

    # Extract headings
    for m in re.finditer(r'^#{1,4}\s+(.+)$', body, re.MULTILINE):
        meta['headings'].append(m.group(1).strip())

    # Extract wikilinks [[...]]
    meta['wikilinks'] = re.findall(r'\[\[([^\]|#]+)(?:[#|][^\]]+)?\]\]', body)

    # Extract inline tags #tag
    meta['tags'] += re.findall(r'(?<!\w)#([a-zA-Z\u4e00-\u9fff][\w\u4e00-\u9fff/-]*)', body)
    meta['tags'] = list(set(meta['tags']))

    # Summary (first meaningful paragraph after headings)
    paras = [p.strip() for p in re.split(r'\n\s*\n', body) if p.strip() and not p.strip().startswith('#')]
    if paras:
        meta['summary'] = paras[0][:500]

    # Phase 1.5: paragraph-level chunking for body-text recall
    meta['chunks'] = chunk_body(body, meta['headings'], name=filepath.stem)

    return meta


def chunk_body(body: str, headings: list[str], name: str = "",
               min_chars: int = 200, max_chars: int = 2000) -> list[dict]:
    """Split note body into chunks by ## headings, then by size."""
    chunks = []
    sections = re.split(r'(?=^## )', body, flags=re.MULTILINE)
    chunk_idx = 0

    for section in sections:
        if not section.strip():
            continue
        h_match = re.match(r'^##\s+(.+)', section)
        section_head = h_match.group(1).strip() if h_match else ''
        text = re.sub(r'^#{1,4}\s+.*$', '', section, flags=re.MULTILINE)
        text = re.sub(r'```[\s\S]*?```', '', text)
        text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)
        text = re.sub(r'[*_~`>|#]', '', text)
        text = re.sub(r'\|.*?\|', '', text)
        text = re.sub(r'\n{2,}', '\n', text).strip()

        if len(text) < min_chars:
            continue
        if len(text) > max_chars:
            for i in range(0, len(text), max_chars):
                sub = text[i:i + max_chars].strip()
                if len(sub) >= min_chars:
                    chunks.append({
                        'id': f"{name}#{chunk_idx}",
                        'text': sub,
                        'headings': [section_head] if section_head else [],
                        'note_name': name,
                    })
                    chunk_idx += 1
        else:
            chunks.append({
                'id': f"{name}#{chunk_idx}",
                'text': text,
                'headings': [section_head] if section_head else [],
                'note_name': name,
            })
            chunk_idx += 1
    return chunks


def _edge_tag(src_meta: dict, dst_meta: dict) -> str:
    """Edge tag (decay phase 1): either endpoint's tags containing #decree/#ephemeral sets the tier.

    decree wins — the "anti-senility" anchor: better to under-decay than mis-decay.
    No tag = default tier (30-day half-life).
    """
    tags = set(src_meta.get('tags', [])) | set(dst_meta.get('tags', []))
    if 'decree' in tags:
        return 'decree'
    if 'ephemeral' in tags:
        return 'ephemeral'
    return 'default'


def build_initial_graph(all_meta: list[dict]) -> dict:
    """Build initial dual graph from explicit links and tags."""
    # FIXED: Index by name ONLY — prevent path strings from becoming graph nodes
    name_index = {}
    name_set = set()
    for m in all_meta:
        if m:
            name_index[m['name']] = m
            name_set.add(m['name'])

    prerequisite = defaultdict(list)
    similarity = defaultdict(list)

    for m in all_meta:
        if not m:
            continue
        src = m['name']
        src_dir = str(Path(m['path']).parent)

        # Rule 1: Wikilinks → prerequisite edges
        for link in m['wikilinks']:
            if link in name_index:
                prerequisite[src].append(link)
            else:
                # FIXED: Partial match only against valid NAMES, not paths
                for n in name_set:
                    if link.lower() in n.lower() or n.lower() in link.lower():
                        if n not in prerequisite[src]:
                            prerequisite[src].append(n)

        # Rule 2: Same directory → similarity
        for m2 in all_meta:
            if not m2 or m2['name'] == src:
                continue
            m2_dir = str(Path(m2['path']).parent)
            if m2_dir == src_dir:
                tag_jac = _jaccard(set(m['tags']), set(m2['tags']))
                summary_ov = _summary_overlap(m, m2)
                if summary_ov >= 3 or tag_jac >= 0.35:
                    if m2['name'] not in similarity[src]:
                        similarity[src].append(m2['name'])

        # Rule 3: Shared tags → similarity
        for m2 in all_meta:
            if not m2 or m2['name'] == src:
                continue
            tag_jac = _jaccard(set(m['tags']), set(m2['tags']))
            summary_ov = _summary_overlap(m, m2)
            if tag_jac >= 0.4 or (tag_jac >= 0.25 and summary_ov >= 5):
                if m2['name'] not in similarity[src]:
                    similarity[src].append(m2['name'])

        # Rule 4: Sequential naming (contiguous dates) → prerequisite
        if '-2026-' in src or '-2025-' in src:
            for m2 in all_meta:
                if not m2 or m2['name'] == src:
                    continue
                prefix1 = re.sub(r'\d{4}-\d{2}-\d{2}', '', src)
                prefix2 = re.sub(r'\d{4}-\d{2}-\d{2}', '', m2['name'])
                if prefix1 == prefix2:
                    dates1 = re.findall(r'(\d{4}-\d{2}-\d{2})', src)
                    dates2 = re.findall(r'(\d{4}-\d{2}-\d{2})', m2['name'])
                    if dates1 and dates2 and dates1[0] < dates2[0]:
                        if m2['name'] not in prerequisite[src]:
                            prerequisite[src].append(m2['name'])

    # Deduplicate
    for k in list(prerequisite.keys()):
        prerequisite[k] = list(set(prerequisite[k]))[:10]

    for k in list(similarity.keys()):
        scored = []
        for n in set(similarity[k]):
            m2 = name_index.get(n, {})
            jac = _jaccard(set(name_index.get(k, {}).get('tags', [])),
                          set(m2.get('tags', [])))
            ov = _summary_overlap(name_index.get(k, {}), m2)
            scored.append((n, jac * 10 + ov * 0.5))
        scored.sort(key=lambda x: -x[1])
        similarity[k] = [s[0] for s in scored[:5]]

    # Build edge weights
    weights = {}
    for k, vlist in prerequisite.items():
        for v in vlist:
            weights[f"{k}||{v}"] = {"type": "prerequisite", "weight": 1.0, "use_count": 0,
                                    "tag": _edge_tag(name_index.get(k, {}), name_index.get(v, {}))}
    for k, vlist in similarity.items():
        for v in vlist:
            key = f"{k}||{v}"
            jac = _jaccard(set(name_index.get(k, {}).get('tags', [])),
                          set(name_index.get(v, {}).get('tags', [])))
            ov = _summary_overlap(name_index.get(k, {}), name_index.get(v, {}))
            score = min(jac * 0.7 + min(ov / 20, 0.3), 1.0)
            weights[key] = {"type": "similarity", "weight": max(score, 0.35), "use_count": 0,
                            "tag": _edge_tag(name_index.get(k, {}), name_index.get(v, {}))}

    return {
        'prerequisite': dict(prerequisite),
        'similarity': dict(similarity),
        'weights': weights,
    }


# ====================== Phase 2: LLM Deep Relationship Extraction ======================

DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE = "https://api.deepseek.com/v1"

def call_llm(system_prompt: str, user_prompt: str, model: str = "deepseek-chat") -> str:
    """Call DeepSeek API with prompts and return response text."""
    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.1,
        "max_tokens": 4096,
        "response_format": {"type": "json_object"},
    }).encode('utf-8')

    req = urllib.request.Request(
        f"{DEEPSEEK_BASE}/chat/completions",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        },
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read())
    return result["choices"][0]["message"]["content"]


def run_llm_extraction(meta_list: list[dict], graph: dict) -> dict:
    """Use DeepSeek to extract deeper prerequisite and similarity relationships."""
    strategic = [m for m in meta_list if m and (
        str(Path(m['path']).parts[0]) in DEEP_DIRS or m['size'] > 2000
    )][:30]

    doc_index = {}
    for i, m in enumerate(strategic):
        did = f"doc_{i}"
        doc_index[did] = {
            'id': did, 'name': m['name'], 'path': m['path'],
            'tags': m['tags'][:5], 'headings': ' | '.join(m['headings'][:5]),
            'summary': m['summary'][:200],
        }

    doc_descriptions = []
    for did, d in doc_index.items():
        desc = f"[{did}] {d['name']} | tags: {', '.join(d['tags'])} | {d['headings'][:80]} | {d['summary'][:120]}"
        doc_descriptions.append(desc)

    system_prompt = (
        "You are a knowledge graph architect. Your task is to identify TWO types of relationships "
        "between documents:\n"
        "1. PREREQUISITE: Understanding document A requires first reading document B "
        "(B is foundational knowledge for A).\n"
        "2. SIMILARITY: Documents A and B cover highly related topics that could substitute or complement each other.\n\n"
        "Rules:\n"
        "- Only output relationships where you are reasonably confident.\n"
        "- For prerequisite: if A references concepts from B, A has prerequisite B.\n"
        "- For similarity: if A and B share the same domain, tools, or methodology.\n"
        "- Do NOT create relationships between clearly unrelated documents.\n"
        "- Output STRICT JSON with keys 'prerequisite' and 'similarity', each being an array of [doc_id_a, doc_id_b] pairs."
    )

    user_prompt = (
        "Analyze these documents and identify prerequisite and similarity relationships:\n\n"
        + "\n".join(doc_descriptions)
    )

    print(f"   Sending {len(doc_descriptions)} docs to DeepSeek for deep extraction...")

    try:
        response = call_llm(system_prompt, user_prompt)
        llm_result = json.loads(response)

        id_to_name = {d['id']: d['name'] for d in doc_index.values()}
        new_prereq = []
        new_sim = []

        for pair in llm_result.get("prerequisite", []):
            a, b = pair[0], pair[1]
            if a in id_to_name and b in id_to_name:
                new_prereq.append(f"{id_to_name[a]} -> {id_to_name[b]}")

        for pair in llm_result.get("similarity", []):
            a, b = pair[0], pair[1]
            if a in id_to_name and b in id_to_name:
                new_sim.append(f"{id_to_name[a]} ~~ {id_to_name[b]}")

        return {
            'method': 'deepseek-chat',
            'analyzed_docs': len(doc_index),
            'new_prerequisites': new_prereq,
            'new_similarities': new_sim,
            'prerequisite_pairs': llm_result.get("prerequisite", []),
            'similarity_pairs': llm_result.get("similarity", []),
        }
    except Exception as e:
        return {'method': 'deepseek-chat', 'error': str(e)[:200], 'analyzed_docs': len(doc_index)}


# ====================== Dry-run report (nail-1 spec check) ======================

def _print_dry_run_report(graph, all_meta, n_md_total, excluded, failed):
    """Four-tier counts + schema diff against existing GRAPH_DIR data. Writes nothing."""
    n_pre = sum(len(v) for v in graph['prerequisite'].values())
    n_sim = sum(len(v) for v in graph['similarity'].values())
    w = graph.get('weights', {})
    endpoints = set(graph['prerequisite']) | set(graph['similarity'])
    for m in ('prerequisite', 'similarity'):
        for v in graph[m].values():
            endpoints.update(v)
    names = set()
    for m in all_meta:
        names.add(m['name'])
        names.add(m['path'])
        names.add(m['path'].replace('\\', '/').split('/')[-1])
    dang = sorted(e for e in endpoints if e not in names)

    print("\n===== DRY RUN — nothing written =====")
    print(f"[spec] vault .md {n_md_total} → index entries {len(all_meta)} → graph endpoints {len(endpoints)}")
    print(f"[graph]   prereq {n_pre} / sim {n_sim} / weights keys {len(w)} / dangling endpoints {len(dang)}")
    for e in dang[:10]:
        print(f"   [dangling] {e}")
    empty = [m['path'] for m in all_meta if m['size'] < 50]
    print(f"[empty notes size<50] {len(empty)}")
    for p in empty[:8]:
        print(f"   [empty] {p}")

    gp = GRAPH_DIR / 'dual_graph.json'
    if gp.exists():
        old = json.loads(gp.read_text(encoding='utf-8'))
        o_pre = sum(len(v) for v in old.get('prerequisite', {}).values())
        o_sim = sum(len(v) for v in old.get('similarity', {}).values())
        ow = old.get('weights', {})
        print(f"[diff graph] old prereq {o_pre} / sim {o_sim} / weights {len(ow)} → new prereq {n_pre} / sim {n_sim} / weights {len(w)}")
        dropped = set(ow) - set(w)
        print(f"[diff weights] old-only (rebuild carries no old weights): {len(dropped)}; sample: {sorted(dropped)[:5]}")
        mp = GRAPH_DIR / 'meta_index.json'
        if mp.exists():
            old_meta = json.loads(mp.read_text(encoding='utf-8'))
            old_paths = {e['path'].replace('\\', '/') for e in old_meta}
            new_paths = {m['path'].replace('\\', '/') for m in all_meta}
            gone, added = old_paths - new_paths, new_paths - old_paths
            print(f"[diff index] old {len(old_meta)} entries → new {len(all_meta)}; gone {len(gone)} / added {len(added)}")
            for p in sorted(gone)[:8]:
                print(f"   [-] {p}")
            for p in sorted(added)[:8]:
                print(f"   [+] {p}")
            old_fields = set(old_meta[0]) if old_meta else set()
            # aligned with persisted entry fields (in-memory all_meta carries frontmatter etc., never persisted)
            entry_fields = {'name', 'path', 'mtime', 'tags', 'headings', 'summary', 'size', 'wikilinks', 'chunks'}
            new_fields = entry_fields
            print(f"[diff schema] meta fields added {sorted(new_fields - old_fields)} / removed {sorted(old_fields - new_fields)}")
    else:
        print("[diff] no existing graph data in GRAPH_DIR, diff skipped")


# ====================== Save-stage state preservation ======================

def _has_learning_traces(entry: dict) -> bool:
    """Learned vs purely-computed weight entry (decay closed-loop batch P1).

    Learning traces: source (llm-derived weight), use_count>0 (consumption),
    decayed_at (the decay system actually modified the weight), rel (LLM-vetted
    relation). A bare {type, weight, use_count:0, tag} entry is fully
    re-derivable from the vault, so refreshing it loses nothing.

    last_updated deliberately does NOT count: apply_feedback.apply_decay's
    first-run branch blanket-stamps it on never-touched entries ("initialize to
    now"), so on the deployment 1035/1110 entries carry it while at most a few
    dozen were ever feedback-touched. Treating it as a trace would freeze every
    weight again — the exact problem this rule exists to fix.
    """
    if entry.get("source"):
        return True
    if (entry.get("use_count") or 0) > 0:
        return True
    return bool(entry.get("decayed_at") or entry.get("rel"))


def merge_preserved_state(graph: dict, old: dict, now_ts: float | None = None) -> dict:
    """Merge the previous graph's state into the freshly built graph, per edge.

    Decay-clock fix (2026-10-02): the save stage used to replace the fresh
    weights dict with the old one wholesale, so edges rebuilt from the current
    vault never entered the weights table (their queries fell back to the 0.5
    default in activation_engine) and entries missing last_touch never
    self-healed. Per-edge merge:
      - new edges: enter the table with their computed weight, last_touch=now;
      - surviving edges with learning traces (source / use_count>0 /
        decayed_at / rel): the old entry is kept verbatim —
        learned weight and markers are preserved (P1 rule);
      - purely computed surviving edges: weight and structural fields refresh
        from the rebuild (vault content changed → similarity should follow),
        last_touch preserved (P1 rule);
      - any entry still missing last_touch: backfilled to now (epoch seconds,
        the same clock apply_feedback.py writes on hit write-back);
      - orphan cleanup (P2): weights entries the new adjacency no longer
        references AND without learning traces are dropped — the weights table
        must not grow monotonically. Learned orphans stay: the edge may
        reappear (scan window / renamed note), and learned state must not be
        lost to a transient adjacency change.
    Feedback idempotency markers (_last_feedback_applied / _feedback_stats)
    pass through unchanged.
    """
    if now_ts is None:
        now_ts = time.time()
    old_weights = old.get("weights")
    if isinstance(old_weights, dict):
        merged = dict(old_weights)
        fresh_weights = graph.get("weights", {})
        for key, fresh in fresh_weights.items():
            prev = merged.get(key)
            if prev is None:
                if isinstance(fresh, dict):
                    fresh.setdefault("last_touch", now_ts)  # new edge: clock starts now
                merged[key] = fresh
            elif isinstance(prev, dict) and not _has_learning_traces(prev):
                # purely computed: refresh from the rebuild, keep the clock
                if isinstance(fresh, dict):
                    refreshed = dict(fresh)
                    refreshed["last_touch"] = prev.get("last_touch") or now_ts
                    merged[key] = refreshed
        for val in merged.values():
            if isinstance(val, dict) and not val.get("last_touch"):
                val["last_touch"] = now_ts
        adj_keys = set()
        for m in ("prerequisite", "similarity"):
            for src, dsts in (graph.get(m) or {}).items():
                for d in dsts:
                    adj_keys.add(f"{src}||{d}")
        for key in [k for k in merged if k not in adj_keys]:
            val = merged[key]
            if isinstance(val, dict) and not _has_learning_traces(val):
                del merged[key]  # P2: no-trace orphan — nothing learned is lost
        graph["weights"] = merged
    for field in ("weights_meta", "_last_feedback_applied", "_feedback_stats"):
        if field in old:
            graph[field] = old[field]
    return graph


def load_old_graph(graph_path: Path) -> dict | None:
    """Read the previous dual_graph.json for state preservation; None on failure.

    Failures are warned, never silent: a silently skipped merge used to strand
    the decay clock and learned weights without any trace.
    """
    try:
        return json.loads(graph_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        print(f"[WARN] Could not read existing {graph_path} ({e}); "
              "old weights and feedback markers will NOT be preserved", file=sys.stderr)
        return None


# ====================== Main ======================

def main():
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

    # work-order infra 2: build lock + index lifecycle meta
    from index_lifecycle import acquire_build_lock, release_build_lock, write_index_meta
    from config import VAULT as _VAULT, GRAPH_DIR as _GD
    _lock = acquire_build_lock(_GD)
    if _lock is None:
        print("[BLOCKED] another build is running (.build.lock with a live PID). "
              "If you are sure it is dead, delete the lock file and retry.")
        sys.exit(2)

    import argparse as _ap
    ap = _ap.ArgumentParser()
    ap.add_argument('--llm', action='store_true', help='Run LLM deep relationship extraction')
    ap.add_argument('--llm-only', action='store_true', help='Only run LLM phase, merge into existing graph')
    ap.add_argument('--dry-run', action='store_true', dest='dry_run',
                    help='Count + schema diff only, write nothing')
    args, _ = ap.parse_known_args()

    print(f"[Scan] Obsidian Vault: {VAULT}")

    # Phase 1: Extract metadata
    # Spec (nail 1): skip dot-dirs + EXCLUDE_DIRS (any path segment) + EXCLUDE_FILES (vault-relative posix paths)
    print("\n[Phase 1] Extracting metadata...")
    all_meta, failed, excluded = [], [], []
    n_md_total = 0
    for f in sorted(VAULT.rglob('*.md')):
        n_md_total += 1
        rel = f.relative_to(VAULT)
        parts = rel.parts
        if any(p.startswith('.') for p in parts):
            continue
        if any(p in EXCLUDE_DIRS for p in parts) or rel.as_posix() in EXCLUDE_FILES:
            excluded.append(rel.as_posix())
            continue
        meta = extract_metadata(f)
        if meta:
            all_meta.append(meta)
        else:
            failed.append(rel.as_posix())

    print(f"   Total .md files: {n_md_total}  excluded: {len(excluded)}  extracted: {len(all_meta)}  failed: {len(failed)}")
    for p in excluded[:15]:
        print(f"   [excluded] {p}")
    for p in failed[:10]:
        print(f"   [FAILED] {p}")

    # Build initial graph
    print("\n[Build] Building initial dual graph...")
    graph = build_initial_graph(all_meta)

    n_pre = sum(len(v) for v in graph['prerequisite'].values())
    n_sim = sum(len(v) for v in graph['similarity'].values())
    print(f"   Prerequisite edges: {n_pre}")
    print(f"   Similarity edges: {n_sim}")

    # Phase 2: Deep extraction
    if args.llm or args.llm_only:
        print("\n[Phase 2] Running LLM deep relationship extraction...")
        if args.llm_only:
            existing_path = GRAPH_DIR / 'dual_graph.json'
            if existing_path.exists():
                graph = json.loads(existing_path.read_text(encoding='utf-8'))
                gstr = f"  Loaded existing graph: {sum(len(v) for v in graph.get('prerequisite',{}).values())} prereq, {sum(len(v) for v in graph.get('similarity',{}).values())} sim edges"
                print(gstr)
            else:
                graph = {'prerequisite': {}, 'similarity': {}, 'weights': {}}

        deep = run_llm_extraction(all_meta, graph)

        if 'error' in deep:
            print(f"  LLM extraction error: {deep['error']}")
        else:
            ep = deep.get('new_prerequisites', [])
            es = deep.get('new_similarities', [])
            print(f"  LLM found: {len(ep)} new prerequisite, {len(es)} new similarity relationships")

            name_index = {m['name']: m for m in all_meta if m}

            filtered_meta = [d for d in all_meta if d and (
                str(Path(d['path']).parts[0]) in DEEP_DIRS or d['size'] > 2000
            )][:30]
            id_to_name = {f"doc_{i}": m['name'] for i, m in enumerate(filtered_meta)}

            for pair in deep.get('prerequisite_pairs', []):
                a_name = id_to_name.get(pair[0])
                b_name = id_to_name.get(pair[1])
                if a_name and b_name:
                    if b_name not in graph['prerequisite'].get(a_name, []):
                        graph['prerequisite'].setdefault(a_name, []).append(b_name)
                    if f"{a_name}||{b_name}" not in graph.get('weights', {}):
                        graph.setdefault('weights', {})[f"{a_name}||{b_name}"] = {
                            "type": "prerequisite", "weight": 0.9, "use_count": 0, "source": "llm",
                            "tag": _edge_tag(name_index.get(a_name, {}), name_index.get(b_name, {}))
                        }

            for pair in deep.get('similarity_pairs', []):
                a_name = id_to_name.get(pair[0])
                b_name = id_to_name.get(pair[1])
                if a_name and b_name:
                    if b_name not in graph['similarity'].get(a_name, []):
                        graph['similarity'].setdefault(a_name, []).append(b_name)
                    if f"{a_name}||{b_name}" not in graph.get('weights', {}):
                        graph.setdefault('weights', {})[f"{a_name}||{b_name}"] = {
                            "type": "similarity", "weight": 0.7, "use_count": 0, "source": "llm",
                            "tag": _edge_tag(name_index.get(a_name, {}), name_index.get(b_name, {}))
                        }

            n_pre = sum(len(v) for v in graph['prerequisite'].values())
            n_sim = sum(len(v) for v in graph['similarity'].values())
            print(f"  After merge: {n_pre} prereq edges, {n_sim} sim edges")

            if ep:
                print(f"\n  New prerequisites from LLM:")
                for r in ep[:10]:
                    print(f"    {r}")
            if es:
                print(f"\n  New similarities from LLM:")
                for r in es[:10]:
                    print(f"    {r}")
    elif not args.llm_only:
        print("\n[Phase 2] Skipped LLM extraction (use --llm flag to run).")
        deep = {'analyzed_docs': sum(1 for m in all_meta if m and (str(Path(m['path']).parts[0]) in DEEP_DIRS or m['size'] > 2000))}

    if args.dry_run:
        _print_dry_run_report(graph, all_meta, n_md_total, excluded, failed)
        return

    # Save
    GRAPH_DIR.mkdir(parents=True, exist_ok=True)

    # Save graph — per-edge weight merge (decay-clock fix) + feedback state preservation
    graph_path = GRAPH_DIR / 'dual_graph.json'
    old = load_old_graph(graph_path) if graph_path.exists() else None
    if isinstance(old, dict):
        merge_preserved_state(graph, old)
    from index_lifecycle import write_json_atomic
    write_json_atomic(graph_path, graph)
    print(f"\n[OK] Graph saved: {graph_path}")

    # Save metadata index
    meta_path = GRAPH_DIR / 'meta_index.json'
    meta_compact = []
    for m in all_meta:
        entry = {
            'name': m['name'],
            'path': m['path'],
            'mtime': m.get('mtime'),
            'tags': m['tags'][:10],
            'headings': m['headings'][:8],
            'summary': m['summary'][:300],
            'size': m['size'],
            'wikilinks': m['wikilinks'][:10],
            'chunks': m.get('chunks', []),
        }
        meta_compact.append(entry)
    write_json_atomic(meta_path, meta_compact)
    print(f"[OK] Metadata saved: {meta_path}")

    # Save deep extraction prep
    deep_path = GRAPH_DIR / 'deep_extraction_prep.json'
    deep_path.write_text(json.dumps(deep, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"[OK] Deep extraction prep: {deep_path}")

    # Print stats
    print(f"\n[Stats] Top connected notes (prerequisite):")
    top_pre = sorted(graph['prerequisite'].items(), key=lambda x: len(x[1]), reverse=True)[:10]
    for name, deps in top_pre:
        print(f"   {name}: {len(deps)} edges -> {deps[:3]}...")

    print(f"\n[Stats] Top connected notes (similarity):")
    top_sim = sorted(graph['similarity'].items(), key=lambda x: len(x[1]), reverse=True)[:10]
    for name, sims in top_sim:
        print(f"   {name}: {len(sims)} edges -> {sims[:3]}...")

    # work-order infra 2: post-build verify + lifecycle meta + lock release
    verify = json.loads(Path(graph_path).read_text(encoding='utf-8'))
    ok_build = bool(verify.get('prerequisite') or verify.get('similarity'))
    write_index_meta(_GD, _VAULT, extra={"nodes": len(set(verify.get('prerequisite', {})) | set(verify.get('similarity', {})))})
    print(f"[OK] index_meta written; post-build verify: {'PASS' if ok_build else 'EMPTY GRAPH - check the vault'}")
    release_build_lock(_GD)


if __name__ == '__main__':
    main()
