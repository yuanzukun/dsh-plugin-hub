/**
 * Model lists taken from the signed-in OAuth account.
 * These requests do not consult the adapter catalog.
 */

import { qwenEndpoint } from "./qwen.js";

const JSON_HEADERS = { accept: "application/json" };
const CODEX_CLIENT_VERSION = "0.156.1";

/** Codex model catalog requires this query; a missing client_version is HTTP 400. */
export function codexModelsUrl(clientVersion = CODEX_CLIENT_VERSION) {
  const url = new URL("https://chatgpt.com/backend-api/codex/models");
  url.searchParams.set("client_version", clientVersion);
  return url.toString();
}

/**
 * Chat models stay in the conversation picker. Image and video models are
 * stored beside the pull and used by tools, so the session model does not change.
 * Embedding, speech, and moderation rows are dropped.
 * @param {unknown} body
 * @returns {{ id: string, name: string, role: "chat" | "image" | "video" }[]}
 */
export function parseModelList(body) {
  const items = [];
  collectItems(body, items);
  const seen = new Set();
  const models = [];
  for (const item of items) {
    if (!item || typeof item !== "object") continue;
    const info = item.info && typeof item.info === "object" ? item.info : item;
    if (info.hidden === true || item.hidden === true) continue;
    const id = firstString(info.id, info.slug, info.model, item.id, item.slug, item.model);
    if (id === undefined || seen.has(id)) continue;
    const role = classifyModel(id, info);
    if (role === "skip") continue;
    seen.add(id);
    const name = firstString(info.name, info.display_name, info.title, item.name) ?? id;
    const model = { id, name, role };
    const contextWindow = positiveInt(
      info.context_window,
      info.contextWindow,
      info.max_input_tokens,
      item.context_window,
      item.max_input_tokens,
    );
    if (contextWindow !== undefined) model.contextWindow = contextWindow;
    if (role === "chat") {
      const reasoningEfforts = reasoningEffortsFrom(info, item);
      if (reasoningEfforts !== undefined) model.reasoningEfforts = reasoningEfforts;
    }
    models.push(model);
  }
  return models;
}

const IMAGE_PREFERENCE = ["grok-imagine-image-2.0", "grok-imagine-image"];
const VIDEO_PREFERENCE = ["grok-imagine-video-1.5", "grok-imagine-video"];

/**
 * One current image model and one current video model.
 * Older aliases stay out of the pull list.
 * @param {{ id: string, name: string, role: string }[]} models
 */
export function preferredMedia(models) {
  return [
    pickMedia(models, "image", IMAGE_PREFERENCE, { id: "grok-imagine-image-2.0", name: "Grok Imagine Image" }),
    pickMedia(models, "video", VIDEO_PREFERENCE, { id: "grok-imagine-video-1.5", name: "Grok Imagine Video" }),
  ];
}

function pickMedia(models, role, order, fallback) {
  for (const id of order) {
    const found = models.find((model) => model.role === role && model.id === id);
    if (found) return found;
  }
  return models.find((model) => model.role === role) ?? { ...fallback, role };
}

function collectItems(body, items) {
  if (Array.isArray(body)) {
    items.push(...body);
    return;
  }
  if (!body || typeof body !== "object") return;
  for (const key of ["models", "data", "items"]) {
    if (Array.isArray(body[key])) items.push(...body[key]);
  }
  if (items.length > 0) return;
  for (const value of Object.values(body)) {
    if (!value || typeof value !== "object" || Array.isArray(value)) continue;
    const info = value.info && typeof value.info === "object" ? value.info : value;
    if (typeof info.id === "string" || typeof info.model === "string") items.push(value);
  }
}

function classifyModel(id, info) {
  const blob = `${id} ${info.name ?? ""} ${info.description ?? ""}`.toLowerCase();
  if (/imagine-video|\bvideo\b|sora|veo/.test(blob)) return "video";
  if (/imagine-image|dall-e|gpt-image|image-gen|flux|aurora/.test(blob)) return "image";
  if (/embed|moderation|whisper|transcri|\btts\b|realtime|speech/.test(blob)) return "skip";
  return "chat";
}

/**
 * @param {string} provider
 * @param {Record<string, unknown>} payload OAuth grant payload. `access` is the bearer token.
 * @returns {Promise<{ id: string, name: string }[]>}
 */
export async function fetchAccountModels(provider, payload) {
  const access = typeof payload.access === "string" ? payload.access : "";
  if (access.length === 0) throw new Error("这次登录里没有 access token，无法拉取模型");
  const request = modelListRequest(provider, access, payload);
  let body = await fetchModelPage(provider, request.url, request.headers);
  // Anthropic pages its catalog: follow has_more / last_id until the list ends.
  if (provider === "anthropic") {
    const rows = Array.isArray(body?.data) ? [...body.data] : [];
    let page = body;
    for (let guard = 0; guard < 20 && page?.has_more === true && typeof page.last_id === "string"; guard++) {
      const next = new URL(request.url);
      next.searchParams.set("after_id", page.last_id);
      page = await fetchModelPage(provider, next.toString(), request.headers);
      if (Array.isArray(page?.data)) rows.push(...page.data);
    }
    body = { data: rows };
  }
  let models = parseModelList(body);
  if (provider === "xai") models = await withGrokMedia(models, access);
  if (models.length === 0) throw new Error(`${provider} 的 OAuth 账号没有返回可用模型`);
  return models;
}

async function fetchModelPage(provider, url, headers) {
  const response = await fetch(url, {
    headers,
    signal: AbortSignal.timeout(20000),
  });
  const text = await response.text();
  if (!response.ok) {
    throw new Error(`${provider} 模型列表返回 ${response.status}${text ? `: ${text.slice(0, 180)}` : ""}`);
  }
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`${provider} 模型列表不是 JSON`);
  }
}

async function withGrokMedia(chatModels, access) {
  const chats = chatModels
    .filter((model) => model.role === "chat")
    .map((model) => ({ ...model, input: model.input ?? ["text", "image"] }));
  let listed = [];
  try {
    const response = await fetch("https://api.x.ai/v1/models", {
      headers: { ...JSON_HEADERS, authorization: `Bearer ${access}` },
      signal: AbortSignal.timeout(15000),
    });
    if (response.ok) listed = parseModelList(await response.json());
  } catch {
    /* Imagine ids below still name the current image and video models. */
  }
  const seen = new Set(chats.map((model) => model.id));
  return [...chats, ...preferredMedia(listed).filter((model) => !seen.has(model.id))];
}

function positiveInt(...values) {
  for (const value of values) {
    if (Number.isInteger(value) && value > 0) return value;
  }
  return undefined;
}

/** Vendor spellings that correspond to a harness thinking level. The stored value stays the vendor string. */
const THINKING_ALIASES = {
  off: "off",
  none: "off",
  disabled: "off",
  minimal: "minimal",
  min: "minimal",
  low: "low",
  medium: "medium",
  med: "medium",
  high: "high",
  xhigh: "xhigh",
  "x-high": "xhigh",
  extra_high: "xhigh",
  "extra-high": "xhigh",
  max: "max",
};

/**
 * Levels the account catalog actually advertises.
 * A missing level stays unset, so the harness treats it as unsupported
 * instead of sending a generic high or xhigh.
 * @param {object} info
 * @param {object} item
 */
export function reasoningEffortsFrom(info, item) {
  const efforts = {};
  for (const source of [info, item]) {
    if (!source || typeof source !== "object") continue;
    collectEffortRows(source.reasoning_efforts, efforts);
    collectEffortRows(source.reasoningEfforts, efforts);
    collectLevelList(source.supported_reasoning_levels, efforts);
    collectLevelList(source.supportedReasoningLevels, efforts);
    collectCapabilityMap(source.capabilities?.effort, efforts);
  }
  return Object.keys(efforts).length > 0 ? efforts : undefined;
}

function collectEffortRows(rows, efforts) {
  if (!Array.isArray(rows)) return;
  for (const row of rows) {
    if (typeof row === "string") {
      assignEffort(efforts, row, row);
      continue;
    }
    if (!row || typeof row !== "object") continue;
    const levelName = firstString(row.id, row.effort, row.level);
    const wire = firstString(row.value, row.wire, row.effort, row.id);
    assignEffort(efforts, levelName, wire);
  }
}

function collectLevelList(rows, efforts) {
  if (!Array.isArray(rows)) return;
  for (const row of rows) {
    if (typeof row === "string") {
      assignEffort(efforts, row, row);
      continue;
    }
    if (!row || typeof row !== "object") continue;
    const effort = firstString(row.effort, row.id, row.value);
    assignEffort(efforts, effort, effort);
  }
}

/**
 * Anthropic lists effort as an object of per-level flags:
 * capabilities.effort = { supported, low: { supported }, ..., max: { supported } }.
 */
function collectCapabilityMap(map, efforts) {
  if (!map || typeof map !== "object" || Array.isArray(map) || map.supported === false) return;
  for (const [key, value] of Object.entries(map)) {
    if (key === "supported") continue;
    if (value && typeof value === "object" && value.supported === true) assignEffort(efforts, key, key);
  }
}

function assignEffort(efforts, levelName, wire) {
  const level = thinkingLevel(levelName);
  const spelling = firstString(wire);
  if (level === undefined || spelling === undefined) return;
  if (efforts[level] !== undefined) return;
  efforts[level] = spelling;
}

function thinkingLevel(value) {
  if (typeof value !== "string") return undefined;
  return THINKING_ALIASES[value.trim().toLowerCase().replaceAll(" ", "_")];
}

/**
 * @param {string} provider
 * @param {string} access
 * @param {Record<string, unknown>} payload
 */
export function modelListRequest(provider, access, payload = {}) {
  const bearer = { ...JSON_HEADERS, authorization: `Bearer ${access}` };
  if (provider === "openai-codex") {
    const headers = { ...bearer };
    const accountId = chatgptAccountId(access) ?? (typeof payload.accountId === "string" ? payload.accountId : undefined);
    if (accountId) headers["chatgpt-account-id"] = accountId;
    return { url: codexModelsUrl(), headers };
  }
  if (provider === "anthropic") {
    return {
      url: "https://api.anthropic.com/v1/models?limit=1000",
      headers: {
        ...bearer,
        "anthropic-version": "2023-06-01",
        "anthropic-beta": "oauth-2025-04-20",
      },
    };
  }
  if (provider === "openrouter") {
    return { url: "https://openrouter.ai/api/v1/models", headers: bearer };
  }
  if (provider === "xai") {
    return { url: "https://cli-chat-proxy.grok.com/v1/models", headers: bearer };
  }
  if (provider === "kimi-coding") {
    return {
      url: "https://api.kimi.com/coding/v1/models",
      headers: { ...bearer, "user-agent": "KimiCLI/1.0" },
    };
  }
  if (provider === "qwen") {
    return { url: `${qwenEndpoint(payload.resourceUrl)}/models`, headers: bearer };
  }
  if (provider === "github-copilot") {
    return {
      url: `${copilotApiBase(access)}/models`,
      headers: {
        ...bearer,
        "user-agent": "GitHubCopilotChat/0.35.0",
        "editor-version": "vscode/1.107.0",
        "editor-plugin-version": "copilot-chat/0.35.0",
        "copilot-integration-id": "vscode-chat",
        "x-github-api-version": "2026-06-01",
      },
    };
  }
  throw new Error(`${provider} 还没有 OAuth 模型列表地址`);
}

function chatgptAccountId(token) {
  try {
    const payload = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString("utf8"));
    const accountId = payload?.["https://api.openai.com/auth"]?.chatgpt_account_id;
    return typeof accountId === "string" && accountId.length > 0 ? accountId : undefined;
  } catch {
    return undefined;
  }
}

function copilotApiBase(token) {
  const match = token.match(/proxy-ep=([^;]+)/);
  if (match?.[1]) return `https://${match[1].replace(/^proxy\./, "api.")}`;
  return "https://api.individual.githubcopilot.com";
}

function firstString(...values) {
  for (const value of values) {
    if (typeof value === "string" && value.trim().length > 0) return value.trim();
  }
  return undefined;
}
