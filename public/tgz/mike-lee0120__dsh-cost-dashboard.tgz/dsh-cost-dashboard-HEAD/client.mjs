/**
 * dsh-cost-dashboard browser bundle.
 *
 * Registers two entry points:
 * - a settings section (费用看板) via `settings.section`;
 * - a sidebar footer action with a dashboard icon via `sidebar.footer.action`
 *   that opens the same dashboard in an anchored panel (the settings nav icons
 *   are hardcoded by the dsh settings shell, so the footer action is how the
 *   plugin gets a dashboard-style icon).
 *
 * The dashboard fetches aggregated usage and cost from the host routes and
 * renders summary cards, a per-day chart, per-model and per-session tables,
 * and a pricing override editor. Every amount is shown in CNY: an entry quoted
 * in USD converts with the configurable `fx.cnyPerUsd` rate.
 *
 * Plain React.createElement throughout - the module-loader factory format has
 * no build step (see @deepseek-ai/dsh-client-modules).
 */
window.__ModuleLoader__.load({
	id: "dsh-cost-dashboard",
	factory: (require) => {
		const module = { exports: {} };
		const exports = module.exports;
		const react = require("react");
		const primitives = require("@deepseek-ai/dsh-client-ui-primitives");
		const h = react.createElement;
		const { useState, useEffect, useMemo, useCallback, useRef, useLayoutEffect } = react;
		const IconDataOutline16 = primitives.IconDataOutline16;

		const NS = "costDashboard";

		const zh = {
			nav: "费用看板",
			title: "费用看板",
			subtitle: "基于本机 dsh 会话日志的模型用量与费用统计",
			refresh: "刷新",
			auto: "每 15 秒自动刷新",
			"mode.tokens": "Tokens",
			"mode.cost": "费用",
			"card.totalCost": "总费用",
			"card.today": "今日费用",
			"card.input": "输入 tokens",
			"card.inputHint": "未命中缓存",
			"card.cacheRead": "缓存命中率",
			"card.cacheReadHint": "命中 {hit} / 未命中 {miss}",
			"card.output": "输出 tokens",
			"card.sessions": "会话数",
			"card.sessionsHint": "{n} 个有用量记录",
			"card.sessionsFoldHint": "{subs} 个子代理会话已并入",
			unpriced: "未配置价格的模型（仅统计 tokens，不计费用）：{models}。可在下方价格配置中补充。",
			"chart.title": "每日趋势",
			"chart.window": "近 {n} 天",
			"chart.max": "峰值 {v}",
			"range.week": "近一周",
			"range.month": "近一月",
			"range.quarter": "近三月",
			"legend.input": "输入",
			"legend.cacheRead": "缓存命中",
			"legend.output": "输出",
			"legend.nonCache": "输入/输出",
			"table.models": "按模型汇总",
			"table.sessions": "按会话汇总",
			"table.sessionsHint": "显示 {shown} / 共 {total} 个会话 · {sort}",
			"sort.cost": "按费用",
			"sort.time": "按时间",
			"sort.hint": "点击切换排序，再次点击反向",
			"col.model": "模型",
			"col.provider": "供应商",
			"col.input": "输入",
			"col.cacheRead": "缓存命中率",
			"col.output": "输出",
			"col.cost": "费用",
			"col.share": "占比",
			"col.tokens": "Tokens",
			"col.session": "会话",
			"col.project": "项目",
			"col.models": "模型",
			"col.time": "时间",
			subagent: "子代理",
			foldedSubagents: "含 {n} 个子代理",
			untitled: "（无标题）",
			multiModel: "共 {n} 个模型",
			"pricing.title": "价格配置",
			"pricing.hint": "保存到 ~/.dsh/cost-dashboard.json，按模型名整体覆盖内置价格。单位：每百万 tokens；看板一律显示人民币，USD 条目按 fx.cnyPerUsd 折算。字段：fx.cnyPerUsd（美元兑人民币，默认 6.79）；每个模型 currency (CNY|USD)、input、inputHit、cacheWrite、output；可选 peak {...} 与峰时窗口 peakHours [[9,12],[14,18]]（北京时间）、peakWeekdays [1,2,3,4,5]（0=周日，默认周一至周五）、peakExcludeDates [\"2026-10-01\"]（法定节假日按空闲计价）；peak 未写的字段回落平价。",
			"pricing.reload": "重新载入",
			"pricing.save": "保存",
			"pricing.saved": "已保存 ✓",
			"pricing.error": "保存失败：{msg}",
			"pricing.overridden": "（覆盖生效中）",
			"error.load": "加载失败：{msg}",
			empty: "还没有任何会话用量数据。",
			loading: "加载中…",
			"meta.files": "{n} 个日志文件",
			"meta.scanMs": "扫描 {n} ms",
			"meta.updated": "更新于 {time}",
			"meta.errors": "{n} 个文件读取失败",
			"meta.pricingErrors": "价格文件告警：{msg}",
			"catalog.ok": "价目表 {source} · 同步于 {time} · {n} 个模型",
			"catalog.stale": "价目表 {source} · 使用缓存（{time}）· {n} 个模型 · {msg}",
			"catalog.error": "价目表同步失败：{msg}",
			"catalog.refresh": "刷新价目",
			"catalog.refreshing": "同步中…",
			"billing.title": "实际账单",
			"billing.hint": "可选：配置供应商只读密钥，显示真实余额与花费，与估算对照。凭证存于 ~/.dsh/cost-dashboard-credentials.json（0600）。国内云厂商（火山/阿里/腾讯）不接 API，价格走配置文件。",
			"billing.balance": "{label} 余额",
			"billing.usage": "{label} 已用 {usage} / 上限 {limit}",
			"billing.credentials": "凭证",
			"billing.save": "保存凭证",
			"billing.saved": "已保存 ✓",
			"billing.refresh": "刷新账单",
			"billing.refreshing": "刷新中…",
			"billing.actual": "实际",
			"billing.estimated": "估算",
			"billing.noData": "配置密钥后显示实际余额与花费",
			"billing.errors": "账单错误：{msg}",
		};

		const en = {
			nav: "Cost Dashboard",
			title: "Cost Dashboard",
			subtitle: "Model usage and spend across local dsh session logs",
			refresh: "Refresh",
			auto: "Auto-refreshes every 15s",
			"mode.tokens": "Tokens",
			"mode.cost": "Cost",
			"card.totalCost": "Total cost",
			"card.today": "Today",
			"card.input": "Input tokens",
			"card.inputHint": "cache miss",
			"card.cacheRead": "Cache hit rate",
			"card.cacheReadHint": "hit {hit} / miss {miss}",
			"card.output": "Output tokens",
			"card.sessions": "Sessions",
			"card.sessionsHint": "{n} with usage",
			"card.sessionsFoldHint": "{subs} subagent logs folded in",
			unpriced: "Models without pricing (tokens counted, cost not): {models}. Add them in the pricing config below.",
			"chart.title": "Daily trend",
			"chart.window": "last {n} days",
			"chart.max": "peak {v}",
			"range.week": "1W",
			"range.month": "1M",
			"range.quarter": "3M",
			"legend.input": "input",
			"legend.cacheRead": "cache read",
			"legend.output": "output",
			"legend.nonCache": "input / output",
			"table.models": "By model",
			"table.sessions": "By session",
			"table.sessionsHint": "showing {shown} of {total} sessions · {sort}",
			"sort.cost": "by cost",
			"sort.time": "by time",
			"sort.hint": "Click to sort, click again to reverse",
			"col.model": "Model",
			"col.provider": "Provider",
			"col.input": "Input",
			"col.cacheRead": "Cache hit",
			"col.output": "Output",
			"col.cost": "Cost",
			"col.share": "Share",
			"col.tokens": "Tokens",
			"col.session": "Session",
			"col.project": "Project",
			"col.models": "Models",
			"col.time": "When",
			subagent: "subagent",
			foldedSubagents: "+{n} subagents",
			untitled: "(untitled)",
			multiModel: "{n} models",
			"pricing.title": "Pricing config",
			"pricing.hint": "Saves to ~/.dsh/cost-dashboard.json; each model entry wholly overrides the builtin one. Rates per 1M tokens; the dashboard always reports CNY, so a USD entry converts with fx.cnyPerUsd. Fields: fx.cnyPerUsd (USD->CNY, default 6.79); per model currency (CNY|USD), input, inputHit, cacheWrite, output; optional peak {...} with its window peakHours [[9,12],[14,18]] (Beijing time), peakWeekdays [1,2,3,4,5] (0 = Sunday, weekdays by default) and peakExcludeDates [\"2026-10-01\"] (statutory holidays bill off-peak); unset peak fields fall back to flat.",
			"pricing.reload": "Reload",
			"pricing.save": "Save",
			"pricing.saved": "Saved ✓",
			"pricing.error": "Save failed: {msg}",
			"pricing.overridden": "(overrides active)",
			"error.load": "Load failed: {msg}",
			empty: "No session usage yet.",
			loading: "Loading…",
			"meta.files": "{n} log files",
			"meta.scanMs": "scanned in {n} ms",
			"meta.updated": "updated {time}",
			"meta.errors": "{n} files failed to read",
			"meta.pricingErrors": "pricing file warning: {msg}",
			"catalog.ok": "prices {source} · synced {time} · {n} models",
			"catalog.stale": "prices {source} · cached ({time}) · {n} models · {msg}",
			"catalog.error": "price sync failed: {msg}",
			"catalog.refresh": "Refresh prices",
			"catalog.refreshing": "Syncing…",
			"billing.title": "Actual billing",
			"billing.hint": "Optional: configure read-only provider keys to show real balances and spend next to the estimate. Credentials are stored at ~/.dsh/cost-dashboard-credentials.json (0600). Domestic cloud vendors (Volcengine/Alibaba/Tencent) are not integrated - their prices come from the config file.",
			"billing.balance": "{label} balance",
			"billing.usage": "{label} used {usage} / limit {limit}",
			"billing.credentials": "Credentials",
			"billing.save": "Save credentials",
			"billing.saved": "Saved ✓",
			"billing.refresh": "Refresh billing",
			"billing.refreshing": "Refreshing…",
			"billing.actual": "Actual",
			"billing.estimated": "Estimate",
			"billing.noData": "Configure keys to show real balances and spend",
			"billing.errors": "Billing errors: {msg}",
		};

		const CSS = `
.cd-root{display:flex;flex-direction:column;gap:16px;font-size:13px}
.cd-head{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.cd-title{font-size:16px;font-weight:600;color:var(--dsw-alias-label-primary)}
.cd-sub{color:var(--dsw-alias-label-tertiary);font-size:12px;flex:1 1 auto;min-width:200px}
.cd-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.cd-toggle{display:inline-flex;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;overflow:hidden}
.cd-toggle button{border:0;background:transparent;color:var(--dsw-alias-label-secondary);padding:4px 12px;font-size:12px;cursor:pointer}
.cd-toggle button.cd-on{background:var(--dsw-alias-fill-l2);color:var(--dsw-alias-label-primary)}
.cd-refresh{border:1px solid var(--dsw-alias-border-l2);background:transparent;color:var(--dsw-alias-label-secondary);border-radius:8px;padding:4px 12px;font-size:12px;cursor:pointer}
.cd-refresh:hover{color:var(--dsw-alias-label-primary)}
.cd-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(148px,1fr));gap:8px}
.cd-card{border:1px solid var(--dsw-alias-border-l2);border-radius:10px;padding:10px 12px;display:flex;flex-direction:column;gap:4px}
.cd-cardLabel{color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:16px}
.cd-cardValue{color:var(--dsw-alias-label-primary);font-size:17px;line-height:22px;font-variant-numeric:tabular-nums;word-break:break-all}
.cd-cardHint{color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:14px}
.cd-error{border:1px solid #b91c1c55;border-radius:10px;background:#b91c1c14;color:#b91c1c;padding:8px 12px}
.cd-notice{border:1px solid var(--dsw-alias-border-l2);border-radius:10px;background:var(--dsw-alias-fill-l1);color:var(--dsw-alias-label-secondary);padding:8px 12px;font-size:12px}
.cd-sectionTitle{font-size:13px;font-weight:600;color:var(--dsw-alias-label-primary)}
.cd-legend{display:flex;gap:14px;flex-wrap:wrap;color:var(--dsw-alias-label-tertiary);font-size:11px;margin-top:4px}
.cd-legendItem{display:inline-flex;align-items:center;gap:5px}
.cd-dot{width:8px;height:8px;border-radius:2px;display:inline-block}
.cd-tableWrap{overflow-x:auto;border:1px solid var(--dsw-alias-border-l2);border-radius:10px}
.cd-table{width:100%;border-collapse:collapse;font-size:12.5px}
.cd-table th{color:var(--dsw-alias-label-tertiary);font-weight:500;text-align:left;padding:7px 10px;white-space:nowrap;font-size:11.5px}
.cd-table td{padding:7px 10px;border-top:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-primary);vertical-align:top}
.cd-sortable{cursor:pointer;user-select:none}
.cd-sortable:hover{color:var(--dsw-alias-label-primary)}
.cd-sessionHeader td{background:var(--dsw-alias-fill-l1)}
.cd-sessionHeaderInner{display:flex;align-items:center;justify-content:space-between;gap:12px}
.cd-sessionTitle{font-weight:600;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cd-sessionMeta{color:var(--dsw-alias-label-tertiary);font-size:11px;display:flex;align-items:center;gap:6px;margin-top:2px}
.cd-modelCount{flex:none;color:var(--dsw-alias-label-secondary);font-size:11px;line-height:20px;background:var(--dsw-alias-fill-l2);border-radius:999px;padding:0 9px}
.cd-modelName{display:inline-flex;align-items:center;gap:7px;font-family:var(--dsw-font-mono)}
.cd-modelDot{width:6px;height:6px;border-radius:50%;background:var(--dsw-alias-label-tertiary);flex:none}
.cd-modelRow td{border-top:1px solid transparent}
.cd-num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.cd-mono{font-family:var(--dsw-font-mono)}
.cd-dim{color:var(--dsw-alias-label-tertiary)}
.cd-badge{display:inline-block;background:var(--dsw-alias-fill-l2);color:var(--dsw-alias-label-secondary);border-radius:5px;padding:0 6px;font-size:10.5px;line-height:17px;margin-right:4px;white-space:nowrap}
.cd-share{position:relative;background:var(--dsw-alias-fill-l1);border-radius:4px;height:6px;min-width:60px;overflow:hidden}
.cd-shareFill{position:absolute;inset:0 auto 0 0;background:#4e83ff66}
.cd-chart{display:flex;flex-direction:column;gap:12px}
.cd-chartRow{display:flex;align-items:baseline;justify-content:space-between;gap:8px}
.cd-chartLabel{color:var(--dsw-alias-label-secondary);font-size:11.5px;font-weight:500}
.cd-chartPeak{color:var(--dsw-alias-label-tertiary);font-size:11px;font-variant-numeric:tabular-nums}
.cd-echart{width:100%}
.cd-details{border:1px solid var(--dsw-alias-border-l2);border-radius:10px;padding:0}
.cd-details>summary{cursor:pointer;padding:10px 12px;color:var(--dsw-alias-label-secondary);font-size:12.5px;list-style:none}
.cd-details>summary::before{content:"▸ ";color:var(--dsw-alias-label-tertiary)}
.cd-details[open]>summary::before{content:"▾ "}
.cd-editor{padding:0 12px 12px;display:flex;flex-direction:column;gap:8px}
.cd-editor textarea{width:100%;min-height:220px;box-sizing:border-box;font-family:var(--dsw-font-mono);font-size:12px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:transparent;color:var(--dsw-alias-label-primary);padding:8px;resize:vertical}
.cd-editorRow{display:flex;align-items:center;gap:8px}
.cd-btn{border:1px solid var(--dsw-alias-border-l2);background:transparent;color:var(--dsw-alias-label-secondary);border-radius:8px;padding:4px 12px;font-size:12px;cursor:pointer}
.cd-btn:hover{color:var(--dsw-alias-label-primary)}
.cd-btnPrimary{border-color:#4e83ff;color:#4e83ff}
.cd-saved{color:#23a55a;font-size:12px}
.cd-meta{color:var(--dsw-alias-label-tertiary);font-size:11px;display:flex;gap:12px;flex-wrap:wrap}
.cd-empty{color:var(--dsw-alias-label-tertiary);padding:24px 0;text-align:center}
.cd-chartCard{border:1px solid var(--dsw-alias-border-l2);border-radius:10px;padding:12px}
.cd-footer{position:relative}
.cd-footerBtn{box-sizing:border-box;cursor:pointer;width:100%;height:36px;color:var(--dsw-alias-label-secondary);background:0 0;border:none;border-radius:10px;align-items:center;gap:8px;padding:0 8px;font-size:12.5px;line-height:18px;display:flex}
.cd-footerBtn:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.cd-footerBtnOpen{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.cd-footerLabel{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cd-footerMask{position:fixed;inset:0;z-index:998;background:var(--dsw-alias-bg-mask-1,rgba(0,0,0,.32))}
.cd-footerPanel{position:fixed;z-index:999;box-sizing:border-box;width:760px;max-width:calc(100vw - 32px);max-height:min(720px,calc(100vh - 120px));background:var(--dsw-alias-bg-layer-2,#fff);border:1px solid var(--dsw-alias-border-l2);border-radius:16px;box-shadow:var(--dsw-shadow-lv3);display:flex;flex-direction:column;overflow:hidden}
.cd-footerPanelHead{flex:none;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:12px 16px;border-bottom:1px solid var(--dsw-alias-border-l2)}
.cd-footerPanelTitle{font-size:14px;font-weight:600;color:var(--dsw-alias-label-primary)}
.cd-footerClose{cursor:pointer;width:28px;height:28px;color:var(--dsw-alias-label-secondary);background:0 0;border:none;border-radius:28px;font-size:16px;line-height:1;display:inline-flex;align-items:center;justify-content:center}
.cd-footerClose:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.cd-footerPanelBody{flex:1;min-height:0;overflow-y:auto;padding:14px 16px}
`;

		const TAG = "dsh-cost-dashboard/styles.css";
		if (typeof document !== "undefined" && document.querySelector(`style[data-plugin-css=${JSON.stringify(TAG)}]`) === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "dsh-cost-dashboard";
			tag.dataset.pluginCss = TAG;
			tag.textContent = CSS;
			document.head.appendChild(tag);
		}

		const COLORS = { input: "#4e83ff", cacheRead: "#23a55a", output: "#9d7bd8" };
		/** Every amount the dashboard shows is CNY; a USD entry converts at this rate. */
		const CNY = "¥";
		const DEFAULT_CNY_PER_USD = 6.79;

		function fmtTokens(value) {
			if (value >= 1e9) return `${(value / 1e9).toFixed(2)}B`;
			if (value >= 1e6) return `${(value / 1e6).toFixed(2)}M`;
			if (value >= 1e4) return `${(value / 1e3).toFixed(1)}K`;
			return String(value);
		}

		function fmtCost(amount) {
			const abs = Math.abs(amount);
			if (abs === 0) return `${CNY}0.00`;
			if (abs < 0.01) return `${CNY}${amount.toFixed(4)}`;
			if (abs >= 10000) return CNY + Math.round(amount).toLocaleString();
			return `${CNY}${amount.toFixed(2)}`;
		}

		function fmtWhen(time) {
			if (!time) return "—";
			const date = new Date(time);
			return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
		}

		/** Human status line for the auto-synced pricing catalog. */
		function catalogStatusText(catalog, t) {
			if (catalog?.error && catalog.modelCount === 0) return t("catalog.error", { msg: catalog.error });
			const time = catalog?.fetchedAt ? fmtWhen(catalog.fetchedAt) : "—";
			if (catalog?.stale && catalog?.error) {
				return t("catalog.stale", { source: catalog.source ?? "litellm", time, n: catalog.modelCount ?? 0, msg: catalog.error });
			}
			return t("catalog.ok", { source: catalog?.source ?? "litellm", time, n: catalog?.modelCount ?? 0 });
		}

		function el(tag, props, ...children) {
			return h(tag, props ?? {}, ...children);
		}

		/**
		 * CNY-equivalent of one {CNY,USD} cost map. The host keeps the source
		 * currency of each pricing entry (imported catalogs quote USD), and this
		 * is the single place the dashboard converts it for display.
		 */
		function toCny(byCurrency, cnyPerUsd) {
			return (byCurrency?.CNY ?? 0) + (byCurrency?.USD ?? 0) * cnyPerUsd;
		}

		/** Local-timezone YYYY-MM-DD for padding empty lead-in days. */
		function localDay(date) {
			return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
		}

		/** Zero-filled empty day used to pad the selected range. */
		function emptyDay(date) {
			return { date, input: 0, cacheRead: 0, cacheWrite: 0, output: 0, costByCurrency: {} };
		}

		/**
		 * Slice the day series to the selected range and pad it with empty
		 * lead-in days so 1W/1M/3M always render the full window.
		 */
		function padDays(days, count) {
			const existing = days.slice(-count);
			if (existing.length >= count) return existing;
			const start = new Date(`${existing[0]?.date ?? localDay(new Date())}T00:00:00`);
			const padded = [];
			for (let i = 0; i < count - existing.length; i++) {
				start.setDate(start.getDate() - 1);
				padded.unshift(emptyDay(localDay(start)));
			}
			return [...padded, ...existing];
		}

		let echartsPromise = null;
		/** Load the vendored ECharts bundle once from the host route. */
		function ensureEcharts() {
			if (typeof window !== "undefined" && window.echarts !== undefined) return Promise.resolve(window.echarts);
			if (echartsPromise !== null) return echartsPromise;
			echartsPromise = new Promise((resolve, reject) => {
				const script = document.createElement("script");
				script.src = "/cost-dashboard/vendor/echarts";
				script.onload = () => resolve(window.echarts);
				script.onerror = () => {
					echartsPromise = null;
					reject(new Error("ECharts failed to load"));
				};
				document.head.appendChild(script);
			});
			return echartsPromise;
		}

		/** Theme-aware axis/tooltip colors read from the page CSS variables. */
		function chartTheme() {
			if (typeof document === "undefined" || typeof getComputedStyle !== "function" || document.documentElement === null) {
				return { text: "#8a8f98", grid: "#e5e7eb", menu: "rgba(17,24,39,0.92)", label: "#f3f4f6" };
			}
			const style = getComputedStyle(document.documentElement);
			const read = (name, fallback) => style.getPropertyValue(name).trim() || fallback;
			return {
				text: read("--dsw-alias-label-tertiary", "#8a8f98"),
				grid: read("--dsw-alias-border-l2", "#e5e7eb"),
				menu: read("--dsw-specific-menu", "rgba(17,24,39,0.92)"),
				label: read("--dsw-alias-label-primary", "#f3f4f6"),
			};
		}

		/** Base line-chart option shared by every daily-trend chart. */
		function baseLineOption(days, theme, formatValue) {
			return {
				animationDuration: 320,
				grid: { left: 4, right: 8, top: 10, bottom: 0, containLabel: true },
				tooltip: {
					trigger: "axis",
					valueFormatter: formatValue,
					backgroundColor: theme.menu,
					borderColor: theme.grid,
					borderWidth: 1,
					textStyle: { color: theme.label, fontSize: 12 },
					axisPointer: { lineStyle: { color: theme.grid } },
				},
				xAxis: {
					type: "category",
					data: days.map((day) => day.date.slice(5)),
					boundaryGap: false,
					axisLine: { lineStyle: { color: theme.grid } },
					axisTick: { show: false },
					axisLabel: { color: theme.text, fontSize: 10, hideOverlap: true },
				},
				yAxis: {
					type: "value",
					splitNumber: 3,
					splitLine: { lineStyle: { color: theme.grid, type: [3, 4] } },
					axisLabel: { color: theme.text, fontSize: 10, formatter: formatValue },
				},
			};
		}

		/** Smooth line with a soft vertical gradient area underneath. */
		function areaSeries(name, data, color) {
			return {
				name,
				type: "line",
				data,
				smooth: 0.35,
				symbol: "circle",
				symbolSize: 5,
				showSymbol: false,
				lineStyle: { width: 2, color },
				itemStyle: { color },
				emphasis: { focus: "series" },
				areaStyle: {
					color: {
						type: "linear",
						x: 0, y: 0, x2: 0, y2: 1,
						colorStops: [
							{ offset: 0, color: `${color}3d` },
							{ offset: 1, color: `${color}05` },
						],
					},
				},
			};
		}

		/** Plain smooth line without area fill. */
		function lineSeries(name, data, color) {
			return {
				name,
				type: "line",
				data,
				smooth: 0.35,
				symbol: "circle",
				symbolSize: 5,
				showSymbol: false,
				lineStyle: { width: 2, color },
				itemStyle: { color },
				emphasis: { focus: "series" },
			};
		}

		/** React host for one ECharts instance; lazy-init, resize, dispose. */
		function EChart({ option, height }) {
			const hostRef = useRef(null);
			const chartRef = useRef(null);
			const optionRef = useRef(option);
			optionRef.current = option;
			useEffect(() => {
				let cancelled = false;
				ensureEcharts().then((echarts) => {
					if (cancelled || hostRef.current === null) return;
					const chart = echarts.init(hostRef.current);
					chartRef.current = chart;
					chart.setOption(optionRef.current);
				}).catch(() => {});
				const onResize = () => chartRef.current?.resize();
				window.addEventListener("resize", onResize);
				return () => {
					cancelled = true;
					window.removeEventListener("resize", onResize);
					chartRef.current?.dispose();
					chartRef.current = null;
				};
			}, []);
			useEffect(() => {
				chartRef.current?.setOption(optionRef.current, { notMerge: true });
			}, [option]);
			return el("div", { ref: hostRef, className: "cd-echart", style: { height } });
		}

		/**
		 * Daily tokens trend: two line charts - non-cache buckets
		 * (input / cache write / output) and cache read on its own scale.
		 */
		function TokensChart({ days, t }) {
			if (days.length === 0) return null;
			const theme = chartTheme();
			const formatTokens = (value) => fmtTokens(value);
			const activeOption = {
				...baseLineOption(days, theme, formatTokens),
				series: [
					lineSeries(t("legend.input"), days.map((day) => day.input), COLORS.input),
					lineSeries(t("legend.output"), days.map((day) => day.output), COLORS.output),
				],
			};
			const cacheOption = {
				...baseLineOption(days, theme, formatTokens),
				series: [areaSeries(t("legend.cacheRead"), days.map((day) => day.cacheRead), COLORS.cacheRead)],
			};
			return el("div", { className: "cd-chart" },
				el("div", { className: "cd-chartRow" }, el("span", { className: "cd-chartLabel" }, t("legend.nonCache"))),
				el(EChart, { option: activeOption, height: 132 }),
				el("div", { className: "cd-chartRow" }, el("span", { className: "cd-chartLabel" }, t("legend.cacheRead"))),
				el(EChart, { option: cacheOption, height: 96 }));
		}

		/** Daily cost trend as one area line, always in CNY. */
		function CostChart({ days, cnyPerUsd, t }) {
			if (days.length === 0) return null;
			const theme = chartTheme();
			const option = {
				...baseLineOption(days, theme, (value) => fmtCost(value)),
				series: [areaSeries(CNY, days.map((day) => toCny(day.costByCurrency, cnyPerUsd)), COLORS.input)],
			};
			return el(EChart, { option, height: 176 });
		}

		function Card({ label, value, hint }) {
			return el("div", { className: "cd-card" },
				el("div", { className: "cd-cardLabel" }, label),
				el("div", { className: "cd-cardValue" }, value),
				hint ? el("div", { className: "cd-cardHint" }, hint) : null);
		}

		function Dashboard(props) {
			const t = props.t;
			const [data, setData] = useState(null);
			const [error, setError] = useState(null);
			const [loading, setLoading] = useState(true);
			const [mode, setMode] = useState("cost");
			const [range, setRange] = useState("7d");
			const [sortKey, setSortKey] = useState("cost");
			const [sortDesc, setSortDesc] = useState(true);
			const [editorOpen, setEditorOpen] = useState(false);
			const [editorText, setEditorText] = useState("");
			const [editorStatus, setEditorStatus] = useState(null);
			const [billing, setBilling] = useState(null);
			const [billingOpen, setBillingOpen] = useState(false);
			const [billingText, setBillingText] = useState("");
			const [billingStatus, setBillingStatus] = useState(null);
			const [billingRefreshing, setBillingRefreshing] = useState(false);
			const alive = useRef(true);

			const fx = data?.fx?.cnyPerUsd ?? DEFAULT_CNY_PER_USD;

			const load = useCallback(async () => {
				try {
					const statsResponse = await fetch("/cost-dashboard/stats", { cache: "no-store" });
					const payload = await statsResponse.json();
					if (!statsResponse.ok) throw new Error(payload?.error ?? `HTTP ${statsResponse.status}`);
					// Billing is optional and may be absent on older hosts - never let it break the dashboard.
					let billingPayload = null;
					try {
						const billingResponse = await fetch("/cost-dashboard/billing", { cache: "no-store" });
						if (billingResponse.ok) billingPayload = await billingResponse.json();
					} catch {
						billingPayload = null;
					}
					if (!alive.current) return;
					setData(payload);
					setBilling(billingPayload);
					setError(null);
				} catch (caught) {
					if (!alive.current) return;
					setError(caught instanceof Error ? caught.message : String(caught));
				} finally {
					if (alive.current) setLoading(false);
				}
			}, []);

			useEffect(() => {
				alive.current = true;
				load();
				const timer = setInterval(load, 15000);
				return () => {
					alive.current = false;
					clearInterval(timer);
				};
			}, [load]);

			const loadPricing = useCallback(async () => {
				const response = await fetch("/cost-dashboard/pricing", { cache: "no-store" });
				const payload = await response.json();
				if (!response.ok) throw new Error(payload?.error ?? `HTTP ${response.status}`);
				const base = payload.override?.models ?? payload.builtin.models;
				setEditorText(JSON.stringify({ fx: payload.fx ?? { cnyPerUsd: DEFAULT_CNY_PER_USD }, models: base }, null, 2));
				setEditorStatus(payload.override ? { kind: "hint", text: t("pricing.overridden") } : null);
			}, [t]);

			const savePricing = useCallback(async () => {
				setEditorStatus({ kind: "busy" });
				try {
					const response = await fetch("/cost-dashboard/pricing", {
						method: "POST",
						headers: { "content-type": "application/json" },
						body: JSON.stringify({ content: editorText }),
					});
					const payload = await response.json();
					if (!response.ok) throw new Error(payload?.error ?? `HTTP ${response.status}`);
					setEditorStatus({ kind: "ok", text: t("pricing.saved") });
					load();
				} catch (caught) {
					setEditorStatus({ kind: "error", text: t("pricing.error", { msg: caught instanceof Error ? caught.message : String(caught) }) });
				}
			}, [editorText, load, t]);

			const [catalogRefreshing, setCatalogRefreshing] = useState(false);
			const refreshCatalog = useCallback(async () => {
				setCatalogRefreshing(true);
				try {
					const response = await fetch("/cost-dashboard/catalog/refresh", { method: "POST" });
					const payload = await response.json();
					if (!response.ok) throw new Error(payload?.error ?? `HTTP ${response.status}`);
				} catch (caught) {
					setError(caught instanceof Error ? caught.message : String(caught));
				} finally {
					setCatalogRefreshing(false);
					load();
				}
			}, [load]);

			const loadBillingCredentials = useCallback(async () => {
				const response = await fetch("/cost-dashboard/billing/credentials", { cache: "no-store" });
				const payload = await response.json();
				if (!response.ok) throw new Error(payload?.error ?? `HTTP ${response.status}`);
				setBillingText(JSON.stringify({ providers: payload.providers ?? {} }, null, 2));
			}, []);

			const saveBillingCredentials = useCallback(async () => {
				setBillingStatus({ kind: "busy" });
				try {
					let parsed;
					try {
						parsed = JSON.parse(billingText);
					} catch (caught) {
						throw new Error(`invalid JSON: ${caught.message}`);
					}
					const response = await fetch("/cost-dashboard/billing/credentials", {
						method: "POST",
						headers: { "content-type": "application/json" },
						body: JSON.stringify({ providers: parsed.providers ?? {} }),
					});
					const payload = await response.json();
					if (!response.ok) throw new Error(payload?.error ?? `HTTP ${response.status}`);
					setBillingStatus({ kind: "ok", text: t("billing.saved") });
					load();
				} catch (caught) {
					setBillingStatus({ kind: "error", text: caught instanceof Error ? caught.message : String(caught) });
				}
			}, [billingText, load, t]);

			const refreshBilling = useCallback(async () => {
				setBillingRefreshing(true);
				try {
					const response = await fetch("/cost-dashboard/billing/refresh", { method: "POST" });
					const payload = await response.json();
					if (!response.ok) throw new Error(payload?.error ?? `HTTP ${response.status}`);
					setBilling(payload);
				} catch (caught) {
					setBilling({ ...billing, meta: { ...(billing?.meta ?? {}), errors: [caught instanceof Error ? caught.message : String(caught)] } });
				} finally {
					setBillingRefreshing(false);
				}
			}, [billing]);

			const summary = data?.summary;
			const rangeDays = range === "7d" ? 7 : range === "30d" ? 30 : 90;
			const rangeLabel = range === "7d" ? t("range.week") : range === "30d" ? t("range.month") : t("range.quarter");
			/** Click a sortable header: switch the key, or flip direction when it is already active. */
			const pickSort = (key) => {
				if (key === sortKey) {
					setSortDesc((desc) => !desc);
					return;
				}
				setSortKey(key);
				setSortDesc(true);
			};
			const sortArrow = (key) => sortKey !== key ? "" : sortDesc ? " ▾" : " ▴";
			const chartDays = useMemo(() => padDays(data?.byDay ?? [], rangeDays), [data, rangeDays]);
			const sessionGroups = useMemo(() => {
				const groups = new Map();
				for (const row of data?.bySession ?? []) {
					// The host keys rows by session, including sessions whose log
					// header was unreadable; fall back to the id for older hosts.
					const key = row.sessionKey ?? row.sessionId ?? `${row.createdAt}|${row.cwd}`;
					let group = groups.get(key);
					if (group === undefined) {
						group = {
							key,
							sessionId: row.sessionId,
							title: row.title,
							project: row.project,
							isSubagent: row.isSubagent,
							subagentCount: row.subagentCount ?? 0,
							modelsTotal: row.modelsTotal,
							createdAt: row.createdAt,
							lastTime: row.lastTime ?? row.createdAt ?? 0,
							costCny: 0,
							models: [],
						};
						groups.set(key, group);
					}
					group.models.push(row);
					group.costCny += toCny(row.costByCurrency, fx);
					const time = row.lastTime ?? row.createdAt ?? 0;
					if (time > group.lastTime) group.lastTime = time;
				}
				const value = sortKey === "time" ? (row) => row.lastTime ?? 0 : (row) => toCny(row.costByCurrency, fx);
				const groupValue = sortKey === "time" ? (group) => group.lastTime : (group) => group.costCny;
				const direction = sortDesc ? -1 : 1;
				for (const group of groups.values()) {
					group.models.sort((left, right) => direction * (value(right) - value(left)));
				}
				return [...groups.values()].sort((left, right) => direction * (groupValue(right) - groupValue(left)));
			}, [data, fx, sortKey, sortDesc]);
			const totalTokens = summary
				? summary.totals.input + summary.totals.cacheRead + summary.totals.cacheWrite + summary.totals.output
				: 0;
			const totalCost = summary ? toCny(summary.costByCurrency, fx) : 0;
			const todayCost = summary ? toCny(summary.todayCostByCurrency, fx) : 0;
			const promptTokens = summary ? summary.totals.input + summary.totals.cacheRead : 0;
			const hitRate = promptTokens > 0 ? (summary.totals.cacheRead / promptTokens) * 100 : 0;

			// Actual-vs-estimate comparison series (aligned to the selected range).
			const billingComparison = useMemo(() => {
				const daily = billing?.daily ?? [];
				if (daily.length === 0 || chartDays.length === 0) return null;
				const actualByDay = new Map();
				for (const row of daily) {
					let bucket = actualByDay.get(row.date);
					if (bucket === undefined) {
						bucket = {};
						actualByDay.set(row.date, bucket);
					}
					bucket[row.currency] = (bucket[row.currency] ?? 0) + row.cost;
				}
				const theme = chartTheme();
				const actual = chartDays.map((day) => toCny(actualByDay.get(day.date), fx));
				const estimated = chartDays.map((day) => toCny(day.costByCurrency, fx));
				return {
					...baseLineOption(chartDays, theme, (value) => fmtCost(value)),
					series: [
						lineSeries(t("billing.estimated"), estimated, COLORS.output),
						lineSeries(t("billing.actual"), actual, COLORS.cacheRead),
					],
				};
			}, [billing, chartDays, fx, t]);

			if (loading && data === null) return el("div", { className: "cd-root" }, el("div", { className: "cd-empty" }, t("loading")));
			if (error !== null && data === null) return el("div", { className: "cd-root" }, el("div", { className: "cd-error" }, t("error.load", { msg: error })));

			return el("div", { className: "cd-root" },
				el("div", { className: "cd-head" },
					el("span", { className: "cd-title" }, t("title")),
					el("span", { className: "cd-sub" }, `${t("subtitle")} · ${t("auto")}`),
					el("div", { className: "cd-actions" },
						el("div", { className: "cd-toggle" },
							el("button", { className: mode === "cost" ? "cd-on" : "", onClick: () => setMode("cost") }, t("mode.cost")),
							el("button", { className: mode === "tokens" ? "cd-on" : "", onClick: () => setMode("tokens") }, t("mode.tokens"))),
						el("button", { className: "cd-refresh", onClick: () => { setLoading(true); load(); } }, t("refresh")))),
				error !== null ? el("div", { className: "cd-error" }, t("error.load", { msg: error })) : null,
				data === null || summary === null || summary.sessions === 0 ? el("div", { className: "cd-empty" }, t("empty")) : el(react.Fragment, null,
					el("div", { className: "cd-cards" },
						el(Card, { label: t("card.totalCost"), value: fmtCost(totalCost), hint: `${t("card.today")}: ${fmtCost(todayCost)}` }),
						el(Card, { label: t("card.input"), value: fmtTokens(summary.totals.input), hint: t("card.inputHint") }),
						el(Card, { label: t("card.cacheRead"), value: `${hitRate.toFixed(1)}%`, hint: t("card.cacheReadHint", { hit: fmtTokens(summary.totals.cacheRead), miss: fmtTokens(summary.totals.input) }) }),
						el(Card, { label: t("card.output"), value: fmtTokens(summary.totals.output) }),
						el(Card, { label: t("card.sessions"), value: String(summary.rootSessions ?? summary.sessions), hint: summary.subagents > 0 ? t("card.sessionsFoldHint", { subs: summary.subagents }) : t("card.sessionsHint", { n: summary.activeSessions }) })),
					data.unpricedModels.length > 0 ? el("div", { className: "cd-notice" }, t("unpriced", { models: data.unpricedModels.join(", ") })) : null,
					el("div", { className: "cd-chartCard" },
						el("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, flexWrap: "wrap", marginBottom: 6 } },
							el("span", { className: "cd-sectionTitle" }, t("chart.title")),
							el("div", { style: { display: "flex", alignItems: "center", gap: 8 } },
								el("div", { className: "cd-toggle" },
									el("button", { className: range === "7d" ? "cd-on" : "", onClick: () => setRange("7d") }, t("range.week")),
									el("button", { className: range === "30d" ? "cd-on" : "", onClick: () => setRange("30d") }, t("range.month")),
									el("button", { className: range === "90d" ? "cd-on" : "", onClick: () => setRange("90d") }, t("range.quarter"))),
								el("span", { className: "cd-dim", style: { fontSize: 11 } }, rangeLabel))),
						mode === "tokens"
							? el("div", { className: "cd-chart" },
								el(TokensChart, { days: chartDays, t }),
								el("div", { className: "cd-legend" },
									el("span", { className: "cd-legendItem" }, el("span", { className: "cd-dot", style: { background: COLORS.input } }), t("legend.input")),
									el("span", { className: "cd-legendItem" }, el("span", { className: "cd-dot", style: { background: COLORS.cacheRead } }), t("legend.cacheRead")),
									el("span", { className: "cd-legendItem" }, el("span", { className: "cd-dot", style: { background: COLORS.output } }), t("legend.output"))))
							: el(CostChart, { days: chartDays, cnyPerUsd: fx, t })),
					el("div", null,
						el("div", { className: "cd-sectionTitle", style: { margin: "4px 0 8px" } }, t("table.models")),
						el("div", { className: "cd-tableWrap" },
							el("table", { className: "cd-table" },
								el("thead", null, el("tr", null,
									el("th", null, t("col.model")),
									el("th", { className: "cd-num" }, t("col.input")),
									el("th", { className: "cd-num" }, t("col.cacheRead")),
									el("th", { className: "cd-num" }, t("col.output")),
									el("th", { className: "cd-num" }, t("col.cost")),
									el("th", null, t("col.share")))),
								el("tbody", null, data.byModel.map((row) => {
									const tokens = row.input + row.cacheRead + row.cacheWrite + row.output;
									const share = totalTokens > 0 ? tokens / totalTokens : 0;
									const rowPrompt = row.input + row.cacheRead;
									const rowHitRate = rowPrompt > 0 ? (row.cacheRead / rowPrompt) * 100 : null;
									return el("tr", { key: `${row.provider}/${row.model}` },
										el("td", null,
											el("span", { className: "cd-mono" }, row.model ?? "—"),
											el("div", { className: "cd-dim", style: { fontSize: 11 } }, row.provider ?? "")),
										el("td", { className: "cd-num", title: String(row.input) }, fmtTokens(row.input)),
										el("td", { className: "cd-num", title: `hit ${fmtTokens(row.cacheRead)} / miss ${fmtTokens(row.input)}` }, rowHitRate === null ? "—" : `${rowHitRate.toFixed(1)}%`),
										el("td", { className: "cd-num", title: String(row.output) }, fmtTokens(row.output)),
										el("td", { className: "cd-num" }, row.priced ? fmtCost(toCny(row.costByCurrency, fx)) : "—"),
										el("td", null, el("div", { className: "cd-share", title: `${(share * 100).toFixed(1)}%` }, el("div", { className: "cd-shareFill", style: { width: `${Math.round(share * 100)}%` } }))));
								}))))),
					el("div", null,
						el("div", { style: { display: "flex", alignItems: "baseline", gap: 8, margin: "4px 0 8px" } },
							el("span", { className: "cd-sectionTitle" }, t("table.sessions")),
							el("span", { className: "cd-dim", style: { fontSize: 11 } }, t("table.sessionsHint", {
								shown: sessionGroups.length,
								total: data.sessionTotal ?? summary.sessions,
								sort: t(sortKey === "time" ? "sort.time" : "sort.cost"),
							}))),
						el("div", { className: "cd-tableWrap" },
							el("table", { className: "cd-table" },
								el("thead", null, el("tr", null,
									el("th", null, t("col.session")),
									el("th", null, t("col.model")),
									el("th", { className: "cd-num" }, t("col.input")),
									el("th", { className: "cd-num" }, t("col.cacheRead")),
									el("th", { className: "cd-num" }, t("col.output")),
									el("th", { className: "cd-num cd-sortable", title: t("sort.hint"), onClick: () => pickSort("cost") }, `${t("col.cost")}${sortArrow("cost")}`),
									el("th", { className: "cd-sortable", title: t("sort.hint"), onClick: () => pickSort("time") }, `${t("col.time")}${sortArrow("time")}`))),
								el("tbody", null, sessionGroups.flatMap((group) => [
									el("tr", { key: `g-${group.key}`, className: "cd-sessionHeader" },
										el("td", { colSpan: 7 },
											el("div", { className: "cd-sessionHeaderInner" },
												el("div", { style: { minWidth: 0 } },
													el("div", { className: "cd-sessionTitle", title: group.title }, group.title ?? t("untitled")),
													el("div", { className: "cd-sessionMeta" },
														group.subagentCount > 0 ? el("span", { className: "cd-badge" }, t("foldedSubagents", { n: group.subagentCount })) : null,
												group.isSubagent ? el("span", { className: "cd-badge" }, t("subagent")) : null,
														el("span", null, group.project ?? ""))),
												group.modelsTotal > 1 ? el("span", { className: "cd-modelCount" }, t("multiModel", { n: group.modelsTotal })) : null))),
									...group.models.map((row) => el("tr", { key: `${row.sessionId}-${row.provider}-${row.model}`, className: "cd-modelRow" },
										el("td", null),
										el("td", null, el("span", { className: "cd-modelName" }, el("span", { className: "cd-modelDot" }), row.model ?? "?")),
										el("td", { className: "cd-num", title: String(row.input) }, fmtTokens(row.input)),
										el("td", { className: "cd-num", title: String(row.cacheRead) }, fmtTokens(row.cacheRead)),
										el("td", { className: "cd-num", title: String(row.output) }, fmtTokens(row.output)),
										el("td", { className: "cd-num" }, fmtCost(toCny(row.costByCurrency, fx))),
										el("td", { className: "cd-dim", style: { whiteSpace: "nowrap" } }, fmtWhen(row.lastTime || row.createdAt)))),
								])))))),
				el("details", { className: "cd-details", open: editorOpen, onToggle: (event) => {
					setEditorOpen(event.currentTarget.open);
					if (event.currentTarget.open && editorText === "") loadPricing().catch((caught) => setEditorStatus({ kind: "error", text: String(caught) }));
				} },
					el("summary", null, t("pricing.title")),
					el("div", { className: "cd-editor" },
						el("div", { className: "cd-dim", style: { fontSize: 11.5 } }, t("pricing.hint")),
						el("textarea", { spellCheck: false, value: editorText, onChange: (event) => setEditorText(event.target.value) }),
						el("div", { className: "cd-editorRow" },
							el("button", { className: "cd-btn cd-btnPrimary", disabled: editorStatus?.kind === "busy", onClick: savePricing }, t("pricing.save")),
							el("button", { className: "cd-btn", onClick: () => loadPricing().catch((caught) => setEditorStatus({ kind: "error", text: String(caught) })) }, t("pricing.reload")),
							editorStatus?.text ? el("span", { className: editorStatus.kind === "error" ? "cd-error" : "cd-saved", style: { padding: "2px 6px" } }, editorStatus.text) : null))),
				el("details", { className: "cd-details", open: billingOpen, onToggle: (event) => {
					setBillingOpen(event.currentTarget.open);
					if (event.currentTarget.open && billingText === "") loadBillingCredentials().catch(() => {});
				} },
					el("summary", null, t("billing.title")),
					el("div", { className: "cd-editor" },
						el("div", { className: "cd-dim", style: { fontSize: 11.5 } }, t("billing.hint")),
						(billing?.balances?.length ?? 0) > 0 ? el("div", { className: "cd-cards" },
							billing.balances.map((balance) => el(Card, {
								key: balance.provider,
								label: t("billing.balance", { label: balance.label }),
								value: fmtCost(toCny({ [balance.currency]: balance.amount }, fx)),
								hint: balance.usage !== undefined ? t("billing.usage", { label: balance.label, usage: fmtCost(toCny({ [balance.currency]: balance.usage }, fx)), limit: fmtCost(toCny({ [balance.currency]: balance.limit }, fx)) }) : undefined,
							}))) : null,
						billingComparison !== null ? el("div", { className: "cd-chartCard", style: { marginTop: 8 } },
							el("div", { className: "cd-chartRow", style: { marginBottom: 6 } },
								el("span", { className: "cd-chartLabel" }, `${t("billing.estimated")} / ${t("billing.actual")}`),
								el("button", { className: "cd-btn", style: { padding: "1px 8px", fontSize: 11 }, disabled: billingRefreshing, onClick: refreshBilling }, billingRefreshing ? t("billing.refreshing") : t("billing.refresh"))),
							el(EChart, { option: billingComparison, height: 160 })) : null,
						(billing?.daily?.length ?? 0) === 0 && (billing?.balances?.length ?? 0) === 0 ? el("div", { className: "cd-empty" }, t("billing.noData")) : null,
						(billing?.meta?.errors?.length ?? 0) > 0 ? el("div", { className: "cd-notice" }, t("billing.errors", { msg: billing.meta.errors.join("；") })) : null,
						el("div", { className: "cd-editorRow", style: { marginTop: 4 } }, el("span", { className: "cd-dim", style: { fontSize: 11.5 } }, t("billing.credentials"))),
						el("textarea", { spellCheck: false, value: billingText, onChange: (event) => setBillingText(event.target.value) }),
						el("div", { className: "cd-editorRow" },
							el("button", { className: "cd-btn cd-btnPrimary", disabled: billingStatus?.kind === "busy", onClick: saveBillingCredentials }, t("billing.save")),
							billingStatus?.text ? el("span", { className: billingStatus.kind === "error" ? "cd-error" : "cd-saved", style: { padding: "2px 6px" } }, billingStatus.text) : null))),
				el("div", { className: "cd-meta" },
					data?.meta ? el("span", null, t("meta.files", { n: data.meta.files })) : null,
					data?.meta ? el("span", null, t("meta.scanMs", { n: data.meta.scanMs })) : null,
					data?.meta ? el("span", null, t("meta.updated", { time: fmtWhen(data.meta.generatedAt) })) : null,
					data?.meta?.errors?.length ? el("span", { title: data.meta.errors.join("\n") }, t("meta.errors", { n: data.meta.errors.length })) : null,
					data?.catalog ? el("span", null, catalogStatusText(data.catalog, t)) : null,
					el("button", { className: "cd-btn", style: { padding: "1px 8px", fontSize: 11 }, disabled: catalogRefreshing, onClick: refreshCatalog }, catalogRefreshing ? t("catalog.refreshing") : t("catalog.refresh")),
					data?.pricingErrors?.length ? el("span", { title: data.pricingErrors.join("\n") }, t("meta.pricingErrors", { msg: data.pricingErrors[0] })) : null));
		}

		/** Sidebar footer action: dashboard icon + anchored panel with the dashboard. */
		function FooterAction({ wide, t }) {
			const [open, setOpen] = useState(false);
			const [anchor, setAnchor] = useState(null);
			const rootRef = useRef(null);
			useLayoutEffect(() => {
				if (!open) return;
				const place = () => {
					const rect = rootRef.current?.getBoundingClientRect();
					if (rect !== undefined) {
						setAnchor({
							left: Math.max(8, Math.min(rect.left, window.innerWidth - 776)),
							bottom: Math.max(8, window.innerHeight - rect.top + 8),
						});
					}
				};
				place();
				window.addEventListener("resize", place);
				return () => window.removeEventListener("resize", place);
			}, [open]);
			useEffect(() => {
				if (!open) return;
				const onKey = (event) => {
					if (event.key === "Escape") setOpen(false);
				};
				window.addEventListener("keydown", onKey);
				return () => window.removeEventListener("keydown", onKey);
			}, [open]);
			return el("div", { className: "cd-footer", ref: rootRef },
				el("button", {
					type: "button",
					className: `cd-footerBtn${open ? " cd-footerBtnOpen" : ""}`,
					title: t("nav"),
					"aria-expanded": open ? "true" : "false",
					onClick: () => setOpen((value) => !value),
				},
					el(IconDataOutline16, { size: 16 }),
					wide ? el("span", { className: "cd-footerLabel" }, t("nav")) : null),
				open ? el("div", { className: "cd-footerMask", onClick: () => setOpen(false) }) : null,
				open ? el("div", { className: "cd-footerPanel", style: anchor ? { left: anchor.left, bottom: anchor.bottom } : undefined },
					el("div", { className: "cd-footerPanelHead" },
						el("span", { className: "cd-footerPanelTitle" }, t("title")),
						el("button", { className: "cd-footerClose", title: "Close", onClick: () => setOpen(false) }, "×")),
					el("div", { className: "cd-footerPanelBody" }, el(Dashboard, { t }))) : null);
		}

		const inject = ["slots", "locale"];

		function apply(ctx) {
			ctx.effect(() => ctx.locale.register(NS, { zh, en }), "cost-dashboard: dictionaries");
			const t = ctx.locale.bind(NS);
			ctx.slots.inject("settings.section", () => ctx.slots.register({
				name: "settings.section",
				id: "cost-dashboard",
				order: 45,
				label: () => t("nav"),
				locale: NS,
				inject: () => ({ t }),
			}, Dashboard));
			ctx.slots.inject("sidebar.footer.action", () => ctx.slots.register({
				name: "sidebar.footer.action",
				id: "cost-dashboard",
				locale: NS,
				inject: () => ({ t }),
			}, FooterAction));
		}

		exports.name = "cost-dashboard";
		exports.inject = inject;
		exports.apply = apply;
		return module.exports;
	},
});
