/**
 * Raw-reasoning restoration for the model-visible surface.
 *
 * The stream transform hides the raw chain of thought from every consumer of
 * the `llm/stream` waterfall — including the agent loop, which assembles the
 * stream into the session's `assistant/message` event. Reasoning models
 * replay their prior reasoning on tool-call turns, so a summarized history
 * degrades multi-step reasoning. This module restores the original reasoning
 * on the MODEL-VISIBLE surface only: after the loop's summary message lands,
 * a replacement `assistant/message` event (surface `replace` op) is appended
 * carrying the raw reasoning. Replacement events are model-only by the
 * session surface contract — the human transcript (and the Web UI, which
 * folds append-origin events exclusively) keeps showing the summary.
 * @module dsh-cot-summerization/history
 */

import { createAssistantMessage } from '@deepseek-ai/dsh-llm'
import type { AssistantMessage, ContentBlock } from '@deepseek-ai/dsh-llm'
import { isAppendSurfaceEvent } from '@deepseek-ai/dsh-session'
import type { SessionEvent, SessionEventMap, SurfaceIntent } from '@deepseek-ai/dsh-session'

/**
 * Raw-reasoning facts recorded while one model stream is rewritten. Populated
 * by {@link transformCoTStream} and consumed when the loop's assembled
 * assistant message lands on the session.
 */
export interface RawCoTCapture {
  /** Whether the upstream stream contained any reasoning at all. */
  sawReasoning: boolean
  /**
   * The assistant content assembled over the UNTOUCHED upstream stream — the
   * exact blocks the adapter produced, in wire order. Set at the finish
   * chunk; the replacement message is rebuilt from these blocks, because the
   * emitted stream reorders them (the reasoning block is re-opened late — at
   * its block-end or at finish — so the loop's first-seen block order can
   * deviate from the wire) and adapters validate replay state against the
   * wire order ("block N does not match assistant content").
   */
  rawBlocks: ContentBlock[] | undefined
  /** Adapter replay state from the terminal finish chunk, when present. */
  replayState: unknown
}

/** A fresh capture for one model call. */
export function createRawCapture(): RawCoTCapture {
  return { sawReasoning: false, rawBlocks: undefined, replayState: undefined }
}

/**
 * Build the replacement assistant message for the model-visible surface: the
 * wire-exact upstream content (raw reasoning restored) with the adapter
 * replay state reattached (the streamed rewrite dropped it because the
 * assembled content no longer matched it).
 *
 * @param message - the landed assistant message from the loop.
 * @param capture - raw facts recorded during the same model stream.
 * @returns the restored message, or undefined when nothing needs restoring:
 *   no reasoning, or the landed content already equals the wire assembly
 *   AND already carries the captured replay state (a genuinely untouched
 *   stream — the transform forwards those finishes verbatim).
 */
export function restoreRawAssistantMessage(
  message: AssistantMessage,
  capture: RawCoTCapture,
): AssistantMessage | undefined {
  if (!capture.sawReasoning) return undefined
  const rawBlocks = capture.rawBlocks
  if (rawBlocks === undefined) return undefined
  const rawReasoning = rawBlocks
    .filter((block) => block.type === 'reasoning')
    .map((block) => block.text)
    .join('')
  if (rawReasoning === '') return undefined
  if (message.source.kind !== 'model') return undefined
  const contentEqual = JSON.stringify(message.content) === JSON.stringify(rawBlocks)
  // A touched stream never carries the finish replay state, so even a
  // wire-identical emission (a non-interleaved verbatim pass-through) needs
  // the replacement to put the captured state back on the surface.
  const stateMissing = capture.replayState !== undefined && message.source.replayState === undefined
  if (contentEqual && !stateMissing) return undefined
  return createAssistantMessage({
    content: rawBlocks,
    source: {
      provider: message.source.provider,
      model: message.source.model,
      ...capture.replayState === undefined ? {} : { replayState: capture.replayState },
    },
  })
}

/** Structural slice of `Session` the restorer needs; keeps tests fake-friendly. */
export interface SessionLike {
  readonly id: string
  append(type: 'assistant/message', data: SessionEventMap['assistant/message'], opts: SurfaceIntent): unknown
}

/** Logger shape shared with the plugin entry. */
export type RestorerLog = (message: string, ...args: unknown[]) => void

/** One tracked model stream per session: its raw capture plus the step identity seen in its chunks. */
interface RawTracker {
  capture: RawCoTCapture
  turn?: number
  step?: number
}

/** Handles the session event feed for raw-history restoration. */
export interface RawHistoryRestorer {
  /** Register the capture of the (single) active model stream for a session. */
  track(sessionId: string, capture: RawCoTCapture): void
  /** Feed one `session/event`; schedules the surface replacement on the landed summary message. */
  handleSessionEvent(session: SessionLike, event: SessionEvent): void
  /** Drop any tracker for a session (turn ended, stream abandoned, session disposed). */
  forget(sessionId: string): void
}

/**
 * Create the raw-history restorer. Pure bookkeeping plus a deferred append:
 * the replacement cannot be appended inside the `session/event` dispatch
 * (append rejects reentrancy), so it lands in a microtask — still well before
 * the loop's next request, which can only happen after asynchronous tool
 * execution.
 */
export function createRawHistoryRestorer(log: RestorerLog = () => {}): RawHistoryRestorer {
  const trackers = new Map<string, RawTracker>()
  return {
    track(sessionId, capture) {
      trackers.set(sessionId, { capture })
    },
    handleSessionEvent(session, event) {
      const key = String(session.id)
      const tracker = trackers.get(key)
      if (tracker !== undefined && event.type === 'assistant/chunk') {
        tracker.turn = event.data.turn
        tracker.step = event.data.step
        return
      }
      if (event.type === 'turn/end') {
        // The turn closed: either the message already landed (tracker
        // consumed) or the stream aborted (nothing to restore).
        trackers.delete(key)
        return
      }
      if (event.type !== 'assistant/message') return
      // Replacement events (including this restorer's own) are not
      // append-origin and must never trigger another restore.
      if (!isAppendSurfaceEvent(event)) return
      if (tracker === undefined) return
      if (tracker.turn === undefined || tracker.turn !== event.data.turn || tracker.step !== event.data.step) return
      trackers.delete(key)
      const replacement = restoreRawAssistantMessage(event.data.message, tracker.capture)
      if (replacement === undefined) return
      const seq = event.seq
      const { turn, step } = event.data
      queueMicrotask(() => {
        try {
          session.append('assistant/message', { turn, step, message: replacement }, {
            surfaceOp: { op: 'replace', start: seq, end: seq },
            sourceEventSeqs: [seq],
          })
        } catch (error) {
          log('cot-summarizer: restoring the raw reasoning on the model-visible surface failed: %s',
            error instanceof Error ? error.message : String(error))
        }
      })
    },
    forget(sessionId) {
      trackers.delete(sessionId)
    },
  }
}
