import { spawnSync } from 'node:child_process'
const tasks=[
  ['node',['--check','index.js']],
  ['node',['--check','client.js']],
  ['node',['tests/host-regression.mjs']],
  ['node',['tests/core-regression.mjs']],
  ['node',['tests/client-regression.mjs']],
  ['node',['tests/dm-regression.mjs']],
  ['node',['tests/dm-watcher-regression.mjs']],
  ['node',['tests/recovery-regression.mjs']],
  ['python',['tests/dm-regression.py']],
  ['python',['tests/dm-dom-regression.py']],
  ['python',['tests/media-regression.py']],
  ['python',['tests/browser-regression.py']],
  ['python',['tests/note-reply-regression.py']],
  ['python',['tests/embedded-js-regression.py']],
  ['node',['selfcheck.mjs']],
]
let failures=0
for(const [command,args] of tasks){
  console.log('\nRUN '+command+' '+args.join(' '))
  const result=spawnSync(command,args,{cwd:new URL('..',import.meta.url),stdio:'inherit',env:{...process.env,PYTHONUTF8:'1'},windowsHide:true,timeout:60000})
  if(result.status!==0){failures++;console.error(result.error?.message||'exit '+result.status)}
}
if(failures)console.error(failures+' test commands failed')
else console.log('\nPASS all offline test commands')
process.exitCode=failures?1:0

