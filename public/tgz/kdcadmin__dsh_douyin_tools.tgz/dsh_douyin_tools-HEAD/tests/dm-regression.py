"""Offline regression: no user browser, no network, no real account actions."""
import asyncio
import json
import os
from pathlib import Path
import runpy
import sys
import types
import unittest

class FastMCP:
    def __init__(self,*a,**kw): self.tools={}
    def tool(self):
        def register(fn): self.tools[fn.__name__]=fn; return fn
        return register
stub=types.ModuleType('mcp.server.fastmcp'); stub.FastMCP=FastMCP
sys.modules['mcp.server.fastmcp']=stub
os.environ['DOUYIN_ALLOW_WRITES']='0'
m=runpy.run_path(str(Path(__file__).resolve().parents[1]/'vendor/douyin-mcp/mcp_server.py'),run_name='dm_tests')
g=m['douyin_dm_snapshot'].__globals__

class ReadMessages(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.saved=dict(g)
        async def nop(*a,**kw): pass
        class Page:
            async def evaluate(self,*a): pass
            async def wait_for_timeout(self,*a): pass
        page=Page()
        class Browser:
            async def context(self): return object()
            async def page_chat(self): return page
            async def page(self): return page
        async def guard(factory,*a): return await factory()
        g.update(_browser=Browser(),_guard=guard,_open_conversation=nop,_goto=nop)
        async def login(*a): return {'loggedIn':True}
        g['_login_state']=login
    async def asyncTearDown(self):
        g.clear(); g.update(self.saved)
    async def test_snapshot_preserves_direction_id_and_sticker(self):
        message={'messageId':'real-1','direction':'outbound','kind':'sticker','text':'','media':['https://p3.douyinpic.com/s.webp'],'attachments':[{'url':'https://p3.douyinpic.com/s.webp','alt':'开心'}]}
        async def snapshot(*a): return [message]
        g['_message_snapshot']=snapshot
        r=json.loads(await m['douyin_dm_snapshot']('Peer'))
        self.assertEqual(r['items'][0].get('direction'),'outbound')
        self.assertEqual(r['items'][0].get('messageId'),'real-1')
        self.assertEqual(r['items'][0].get('media'),message['media'])
    async def test_inbox_unknown_is_not_changed_to_inbound(self):
        async def snapshot(*a): return [{'messageId':'uncertain','direction':'unknown','text':'hello'}]
        g['_message_snapshot']=snapshot
        r=json.loads(await m['douyin_inbox'](nickname='Peer'))
        self.assertEqual(r['items'],[])

class CommentMedia(unittest.TestCase):
    def test_image_only_comment_keeps_attachments(self):
        r=m['_parse_comment']({'cid':'c1','text':'','image_list':[{'url_list':['https://p3.douyinpic.com/comment.webp']}],'user':{'nickname':'Peer'}})
        self.assertEqual(r.get('kind'),'image')
        self.assertEqual(r.get('media'),['https://p3.douyinpic.com/comment.webp'])

class Emitter:
    def __init__(self): self.listeners = {}
    def on(self, event, fn): self.listeners.setdefault(event, []).append(fn)
    def remove_listener(self, event, fn): self.listeners[event].remove(fn)
    def emit(self, event, *args):
        for fn in list(self.listeners.get(event, [])): fn(*args)

def msg(messageId, direction='inbound', text='', kind='text', media=None):
    return {'messageId': messageId, 'direction': direction, 'text': text, 'kind': kind, 'media': media or []}

class WatchPage(Emitter):
    url = 'https://www.douyin.com/jingxuan'
    def __init__(self):
        super().__init__(); self.value = [msg('m1', text='hello')]; self.binding = None; self.closed = False; self.disconnected = False
    def is_closed(self): return self.closed
    async def expose_function(self, name, fn):
        if self.binding: raise ValueError('binding already exists')
        self.binding = fn
    name = 'dsh-douyin-chat'
    async def evaluate(self, script, *args):
        if 'window.name' in script: return self.name
        if 'Array.from(document.querySelectorAll' in script: return self.value
        if script.startswith('() => window.'): self.disconnected = True

class WatchEvents(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.page = WatchPage(); self.context = Emitter(); self.context.pages = [self.page]
        self.watcher = m['DmEventWatcher']()
        await self.watcher.start(self.context)
        await self.watcher.wait(.01)
    async def asyncTearDown(self): await self.watcher.close()
    async def test_websocket_heartbeat_does_not_wake_but_new_message_does(self):
        ws = Emitter(); self.page.emit('websocket', ws)
        ws.emit('framereceived', 'heartbeat')
        self.assertFalse((await self.watcher.wait(.22))['changed'])
        self.page.value.append(msg('m2', kind='sticker', media=['https://p3.douyinpic.com/emoji.webp']))
        ws.emit('framereceived', 'payload not inspected')
        result = await self.watcher.wait(.5)
        self.assertTrue(result['changed']); self.assertEqual(result['reason'], 'websocket')
    async def test_dom_burst_is_coalesced_and_does_not_return_messages(self):
        self.page.value.append(msg('m2', text='private text'))
        for _ in range(20): self.page.binding()
        result = await self.watcher.wait(.5)
        self.assertTrue(result['changed']); self.assertNotIn('private text', json.dumps(result))
        self.assertFalse((await self.watcher.wait(.02))['changed'])
    async def test_navigation_and_close_cleanup_and_restart_binding(self):
        await self.watcher.close()
        self.assertTrue(self.page.disconnected)
        self.assertTrue(all(not x for x in self.page.listeners.values()))
        self.assertFalse(self.context.listeners['page']); self.assertFalse(self.watcher.tasks)
        await self.watcher.start(self.context); await self.watcher.wait(.01)
        self.page.value.append(msg('new-after-restart', text='hi')); self.page.binding()
        self.assertTrue((await self.watcher.wait(.5))['changed'])
    async def test_reconcile_does_not_create_an_event_loop(self):
        self.page.value = [msg('another-conversation', text='hello')]; self.page.binding()
        await self.watcher.acknowledge()
        self.assertFalse((await self.watcher.wait(.02))['changed'])
        self.page.value.append(msg('new-incoming', text='hello')); self.page.binding()
        self.assertTrue((await self.watcher.wait(.5))['changed'])
    async def test_read_receipts_and_own_messages_do_not_wake(self):
        # 已读状态/渲染抖动改文本，最后一条入站消息没变，不算新消息
        self.page.value[-1] = msg('m1', text='hello（已读）')
        self.page.binding()
        self.assertFalse((await self.watcher.wait(.3))['changed'])
        # 自己发出去的消息也不叫醒
        self.page.value.append(msg('mine', direction='outbound', text='ok'))
        self.page.binding()
        self.assertFalse((await self.watcher.wait(.3))['changed'])
    async def test_non_douyin_page_is_not_evaluated(self):
        self.page.url = 'https://example.com/'
        self.page.value.append(msg('not-douyin', text='text')); self.page.binding()
        self.assertFalse((await self.watcher.wait(.02))['changed'])
    async def test_unnamed_or_feed_page_is_not_connected(self):
        for name in ('', 'dsh-douyin-feed'):
            page = WatchPage(); page.name = name
            context = Emitter(); context.pages = [page]
            watcher = m['DmEventWatcher']()
            self.assertIs(await watcher.start(context), False)
            self.assertFalse(watcher.pages)
            await watcher.close()
    async def test_chat_connect_does_not_look_like_a_new_message(self):
        page = WatchPage(); page.name = 'dsh-douyin-chat'
        context = Emitter(); context.pages = [page]
        watcher = m['DmEventWatcher']()
        self.assertIs(await watcher.start(context), True)
        connected = await watcher.wait(.2)
        self.assertEqual(connected['reason'], 'connected')
        self.assertFalse(connected['changed'])
        await watcher.close()
    async def test_close_wakes_pending_waiter(self):
        pending = asyncio.create_task(self.watcher.wait(25))
        await asyncio.sleep(0)
        await self.watcher.close()
        result = await asyncio.wait_for(pending, .2)
        self.assertFalse(result['ok']); self.assertEqual(result['reason'], 'closed')

class LongPollLock(unittest.IsolatedAsyncioTestCase):
    async def test_stop_does_not_open_a_browser(self):
        saved = dict(g)
        class Browser:
            async def context(self): raise AssertionError('stop must not launch a browser')
        class Watcher:
            closed = False
            async def close(self): self.closed = True
        watcher = Watcher(); g.update(_browser=Browser(), _dm_event_watcher=watcher)
        try:
            result = json.loads(await m['douyin_dm_events'](stop=True))
            self.assertTrue(result['stopped']); self.assertTrue(watcher.closed)
        finally: g.clear(); g.update(saved)
    async def test_long_poll_releases_browser_lock(self):
        saved = dict(g); entered = asyncio.Event(); release = asyncio.Event()
        class Browser:
            lock = asyncio.Lock()
            async def context(self): return object()
            async def page_chat(self): return WatchPage()
        class Watcher:
            async def start(self, ctx): pass
            async def wait(self, seconds):
                entered.set(); await release.wait(); return {'ok':True,'changed':False}
        browser = Browser(); g.update(_browser=browser, _dm_event_watcher=Watcher())
        task = asyncio.create_task(m['douyin_dm_events'](.5))
        try:
            await asyncio.wait_for(entered.wait(), .5)
            await asyncio.wait_for(browser.lock.acquire(), .2)
            browser.lock.release(); release.set(); await task
        finally:
            task.cancel(); await asyncio.gather(task, return_exceptions=True)
            g.clear(); g.update(saved)

class MediaCommentTarget(unittest.IsolatedAsyncioTestCase):
    async def test_reordered_image_comments_use_media_and_author(self):
        class Item:
            def __init__(self, data): self.data = data
            async def evaluate(self, script): return self.data
        class Items:
            def __init__(self, rows): self.rows = [Item(x) for x in rows]
            async def count(self): return len(self.rows)
            def nth(self, i): return self.rows[i]
        source = {'cid':'c1','user':{'nickname':'Peer'},'image_list':[{'url_list':['https://p3.douyinpic.com/image.webp?old=1']} ]}
        rows = [{'cid':'','users':['Other'],'media':['https://p3.douyinpic.com/image.webp']},
                {'cid':'','users':['Peer'],'media':['https://p3.douyinpic.com/image.webp?new=1']}]
        items = Items(rows)
        self.assertIs(await m['_find_media_comment'](items,source,'c1'), items.rows[1])
        duplicate = Items([rows[1], rows[1]])
        self.assertIsNone(await m['_find_media_comment'](duplicate,source,'c1'))
        direct = Items([{'cid':'c1','users':[],'media':[]}])
        self.assertIs(await m['_find_media_comment'](direct,source,'c1'),direct.rows[0])

class CommentReceipt(unittest.TestCase):
    def test_draft_already_in_baseline_is_not_a_new_comment(self):
        self.assertFalse(m['_comment_text_arrived']('你好', '你好', '你好'))
    def test_baseline_taken_before_typing_can_see_the_posted_line(self):
        self.assertTrue(m['_comment_text_arrived']('', '你好', '@月亮 你好', '你好'))
    def test_posted_body_matches_when_platform_drops_the_mention(self):
        self.assertTrue(m['_comment_text_arrived']('', '你好呀', '@月亮 你好呀', '你好呀'))

if __name__=='__main__': unittest.main()
