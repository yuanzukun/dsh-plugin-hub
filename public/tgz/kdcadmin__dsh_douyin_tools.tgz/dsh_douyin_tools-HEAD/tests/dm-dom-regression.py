"""Execute the exact embedded extractor against small DOM doubles. No browser/network."""
import ast
import json
from pathlib import Path
import subprocess
root = Path(__file__).resolve().parents[1]
tree = ast.parse((root/'vendor/douyin-mcp/mcp_server.py').read_text(encoding='utf-8'))
fn = next(n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == '_message_snapshot')
source = fn.body[0].value.value.args[0].value
script = r'''
const assert=require('node:assert/strict');
const extract=eval('('+JSON.parse(require('node:fs').readFileSync(0,'utf8'))+')');
global.getComputedStyle=e=>({visibility:'visible',overflowY:e.scroll?'auto':'visible'});
const scroll={scroll:true,scrollHeight:1000,clientHeight:500,getBoundingClientRect:()=>({x:0,width:400})};
function node(o={}) {
 const image={src:'https://p3.douyinpic.com/sticker.webp',alt:'开心',closest:()=>null};
 return {innerText:o.text||'',parentElement:scroll,getClientRects:()=>[{}],scrollHeight:0,clientHeight:0,
 getBoundingClientRect:()=>({x:o.x||10,width:120,top:o.top||10,height:70}),
 getAttribute:k=>(o.attrs||{})[k]||null,
 closest:sel=>{
  if(String(sel).includes('isFromMe')&&(o.x||10)>=200) return {className:'isFromMe'};
  if((o.x||10)<200&&/MessageItem(Text|Emoji|Image|Share)/.test(String(sel))) return {className:'MessageItem'};
  return null;
 },
 querySelector:s=>s.includes('/video/')&&o.video?{href:'https://www.douyin.com/video/7111111111111111111'}:s.includes('Emoji')&&o.sticker?image:null,
 querySelectorAll:s=>s==='img'&&o.sticker?[image]:[]};
}
let primary=[],fallback=[];
global.document={querySelector:()=>({getAttribute:()=> 'self-uid'}),querySelectorAll:s=>
 s==='[data-message-id],[data-msg-id]'?primary:
 s.includes('Textbubble')?fallback.filter(x=>x.type==='text').map(x=>x.e):
 s.includes('ShareAweme')?fallback.filter(x=>x.type==='share').map(x=>x.e):
 s.includes('Emojiemoji')?fallback.filter(x=>x.type==='emoji').map(x=>x.e):[]};
primary=[node({video:true,text:'视频作者名字',attrs:{'data-message-id':'platform-out','data-sender-id':'self-uid','data-direction':'inbound'}})];
assert.equal(extract()[0].direction,'outbound');assert.equal(extract()[0].awemeId,'7111111111111111111');
console.log('PASS sender identity outranks author text and contradictory direction');
primary=[node({sticker:true,attrs:{'data-message-id':'sticker','data-sender-id':'peer-uid'}})];
let message=extract()[0];assert.equal(message.direction,'inbound');assert.equal(message.kind,'sticker');assert.equal(message.attachments[0].alt,'开心');
console.log('PASS primary image-only sticker keeps sender and media');
primary=[node({text:'ambiguous',attrs:{'data-message-id':'unknown'}})];
assert.equal(extract()[0].direction,'unknown');console.log('PASS missing direction stays unknown');
primary=[];fallback=[{type:'share',e:node({video:true,text:'作者一',x:250,top:100})}];
message=extract()[0];assert.equal(message.direction,'outbound');const stableId=message.messageId;
fallback.unshift({type:'text',e:node({text:'older',x:10,top:10})});
assert.equal(extract().at(-1).messageId,stableId);assert.equal(extract()[0].direction,'inbound');
console.log('PASS fallback direction uses conversation bounds and IDs survive prepending history');
fallback=[{type:'emoji',e:node({sticker:true,top:10})},{type:'emoji',e:node({sticker:true,top:100})}];
const rows=extract();assert.equal(rows.length,2);assert.notEqual(rows[0].messageId,rows[1].messageId);assert.equal(rows[0].kind,'sticker');
console.log('PASS identical adjacent stickers retain separate fallback IDs');
'''
r = subprocess.run(['node','-e',script],input=json.dumps(source),encoding='utf-8',capture_output=True,timeout=10)
print(r.stdout,end='')
if r.stderr: print(r.stderr)
raise SystemExit(r.returncode)
