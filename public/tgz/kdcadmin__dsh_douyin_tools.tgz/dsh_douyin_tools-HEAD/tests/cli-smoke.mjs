import { findDesktopCli } from '../lib/dsh-cli.mjs'
import { runCommand } from '../lib/process.mjs'
import { fileURLToPath } from 'node:url'
import assert from 'node:assert/strict'
const cli=findDesktopCli({pluginDir:fileURLToPath(new URL('..',import.meta.url))})
if(!cli)throw new Error('No verified desktop command shim found')
const result=await runCommand(cli.command,[...cli.args,'--version'],{env:{...process.env,...cli.env},timeoutMs:20000})
console.log(JSON.stringify({source:cli.source,command:cli.command,version:result.output.trim()}))
const help=await runCommand(cli.command,[...cli.args,'--help'],{env:{...process.env,...cli.env},timeoutMs:20000})
assert.ok(help.output.includes('--profile') && help.output.includes('--patch'),'current CLI must accept headless profile and overlay flags')
console.log('PASS current desktop CLI supports --profile and --patch')

