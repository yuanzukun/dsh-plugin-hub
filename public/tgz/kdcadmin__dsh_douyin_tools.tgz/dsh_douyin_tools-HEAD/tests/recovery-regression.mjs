import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const dir = mkdtempSync(join(tmpdir(), 'dy-recover-'))
process.env.DSH_DOUYIN_HOME = dir
mkdirSync(join(dir, 'dm-log'), { recursive: true })
writeFileSync(join(dir, 'ledger.json'), JSON.stringify({
  actions: { a: { status: 'pending', kind: 'message' } },
  comments: [], replies: {}, published: {},
}))
writeFileSync(join(dir, 'dm-log', '2026-11-08.json'), JSON.stringify({
  day: '2026-11-08',
  items: [{ status: 'pending', name: '旧', replyText: '还在输入框里', at: 1 }],
}))
writeFileSync(join(dir, 'dm-log', '2026-11-11.json'), JSON.stringify({
  day: '2026-11-11',
  items: [{ status: 'pending', name: '新', at: 2 }],
}))

const { apply } = await import('../index.js')
const host = { tools: { register() {} }, settings: { describe: () => [] }, webServer: { register() {} }, logger: {}, effect() {} }
apply(host, {})
const ledger = JSON.parse(readFileSync(join(dir, 'ledger.json'), 'utf8'))
ledger.actions.live = { status: 'pending', kind: 'message' }
writeFileSync(join(dir, 'ledger.json'), JSON.stringify(ledger))
apply(host, {})

const after = JSON.parse(readFileSync(join(dir, 'ledger.json'), 'utf8'))
const old = JSON.parse(readFileSync(join(dir, 'dm-log', '2026-11-08.json'), 'utf8'))
const recent = JSON.parse(readFileSync(join(dir, 'dm-log', '2026-11-11.json'), 'utf8'))
assert.equal(after.actions.a.status, 'interrupted')
assert.equal(after.actions.live.status, 'pending')
assert.equal(old.items[0].status, 'interrupted')
assert.equal(recent.items[0].status, 'failed')
assert.equal(recent.items[0].replied, false)
rmSync(dir, { recursive: true, force: true })
console.log('PASS shutdown recovery covers old days and does not mark them sent')
