import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync, readFileSync, existsSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { apply } from '../index.js'
import { McpClient } from '../lib/mcp.mjs'

const dir=mkdtempSync(join(import.meta.dirname,'.headless-'))
process.env.DSH_DOUYIN_HOME=dir
const tools=new Map(),cleanup=[],calls=[]
const old=McpClient.prototype.call
McpClient.prototype.call=async function(name,args){
  calls.push({name,args})
  return name==='douyin_watch'?{ok:true,transcript:'offline fixture',partial:true}:{ok:true,verified:true,cid:'fixture-comment'}
}
try{
  apply({tools:{register(t){tools.set(t.name,t)}},settings:{describe:()=>[]},
    effect(fn){const c=fn();if(typeof c==='function')cleanup.push(c)},logger:{info(){}},
    webServer:{register(){return()=>{}}}}, {})
  const cli=join(dir,'fixture.cjs'),output=join(dir,'result.json')
  const source=[
    "const fs=require('node:fs');",
    "const overlay=fs.readFileSync(process.argv[5],'utf8');",
    "const url=overlay.match(/DOUYIN_PROXY_URL: '([^']+)'/)[1], token=overlay.match(/DOUYIN_PROXY_TOKEN: '([^']+)'/)[1];",
    "const send=async(name,args)=>{const r=await fetch(url,{method:'POST',headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:JSON.stringify({name,args})});return {code:r.status,result:await r.json()}};",
    "(async()=>{const results=[];",
    "results.push(await send('douyin_publish',{}));",
    "results.push(await send('douyin_watch',{aweme_id:'7111111111111111111',seconds:15}));",
    "results.push(await send('douyin_watch',{aweme_id:'7222222222222222222',seconds:15}));",
    "results.push(await send('douyin_comment',{aweme_id:'7111111111111111111',text:'wrong',mention:'Other'}));",
    "results.push(await send('douyin_comment',{aweme_id:'7111111111111111111',text:'fixture',mention:'Audit'}));",
    "results.push(await send('douyin_comment',{aweme_id:'7222222222222222222',text:'fixture',mention:'Audit',force:true}));",
    "fs.writeFileSync("+JSON.stringify(output)+",JSON.stringify(results));})().catch(e=>{console.error(e.message);process.exitCode=1});",
  ].join('\n')
  writeFileSync(cli,source)
  const cfg=await tools.get('dy_config').execute({patch:{dshBin:cli,autoComment:true,mentionName:'Audit',autoCommentPlain:false,commentPerDay:1,commentPerRound:1,pickPerRound:1,perDay:2,reportLevel:'off'}})
  assert.equal(cfg.ok,true)
  const result=await tools.get('dy_run').execute({mode:'headless'})
  assert.equal(result.started,true)
  const duplicate=await tools.get('dy_run').execute({mode:'headless'})
  assert.equal(duplicate.started,false)
  let state
  for(let i=0;i<100;i++){
    if(existsSync(join(dir,'state.json')))state=JSON.parse(readFileSync(join(dir,'state.json')))
    if(state?.headless?.status!=='running')break
    await new Promise(r=>setTimeout(r,100))
  }
  assert.equal(state?.headless?.status,'completed',state?.headless?.error || readFileSync(join(dir,'duty.log'),'utf8').slice(-1000))
  const results=JSON.parse(readFileSync(output))
  assert.equal(results[0].code,403)
  assert.equal(results[1].result.ok,true)
  assert.equal(results[2].result.blocked,true)
  assert.equal(results[3].result.ok,false)
  assert.equal(results[4].result.verified,true)
  assert.equal(results[5].result.blocked,true)
  assert.equal(calls.filter(c=>c.name==='douyin_comment').length,1)
  assert.equal(calls.filter(c=>c.name==='douyin_watch').length,1)
  assert.equal(existsSync(join(dir,'headless-overlay.yml')),false)
  const ledger=JSON.parse(readFileSync(join(dir,'ledger.json')))
  assert.equal(Object.keys(ledger.picks).length,1)
  assert.equal(ledger.comments.length,1)
  console.log('PASS headless host integration: selected quota, recipient, daily cap, force stripping, duplicate run and credential cleanup')
}finally{
  McpClient.prototype.call=old
  for(const f of cleanup.reverse())f()
  rmSync(dir,{recursive:true,force:true})
}

