"""Offline regression: extract exact functions through AST, replace browser/ffmpeg/model.

Regression tests: require corrected media lifecycle and error reporting.
"""
from __future__ import annotations

import ast
import io
import json
import os
import subprocess
import sys
import tempfile
import time
import types
import wave
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / "vendor/douyin-mcp/mcp_server.py"
tree = ast.parse(SOURCE.read_text(encoding="utf-8"))


def extracted(name, env):
    node = next(n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name)
    node.decorator_list = []
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(SOURCE), "exec"), env)
    return env[name]


def wav_bytes():
    out = io.BytesIO()
    with wave.open(out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes(b"\0\0" * 1600)
    return out.getvalue()


class Array:
    def __init__(self, value=b""):
        self.value = value

    def tobytes(self):
        return self.value

    def astype(self, _):
        return self

    def __truediv__(self, _):
        return self

    def __len__(self):
        return len(self.value) // 2


fake_numpy = types.SimpleNamespace(int16="int16", float32="float32", frombuffer=lambda b, **kw: Array(b),
                                   concatenate=lambda xs: Array(b"".join(x.value for x in xs)), zeros=lambda *a, **kw: Array())


class Page:
    def __init__(self):
        self.context = self
        self.request = self
        self.created = 0
        self.closed = 0
        self.listeners = []
        self.url = "https://audit.invalid"

    async def new_page(self):
        self.created += 1
        return self

    async def cookies(self, *args):
        return []

    async def close(self):
        self.closed += 1

    def on(self, event, callback):
        self.listeners.append(callback)

    def remove_listener(self, event, callback):
        if callback in self.listeners:
            self.listeners.remove(callback)

    async def wait_for_timeout(self, _):
        pass

    async def evaluate(self, js, *args):
        if "if (!v) return []" in js:
            return ["https://audit.invalid/media"]
        if "v.duration" in js:
            return 30
        if "r.url" in js:
            return ""
        return None

    async def get(self, *args, **kwargs):
        return self

    status = 200

    async def body(self):
        return b"fake media"


observations = []


def probe(name, reproduced, detail):
    observations.append(bool(reproduced))
    print(f"{'PASS' if reproduced else 'FAIL'} {name}: {detail}")


async def main():
    old_run = subprocess.run
    old_numpy = sys.modules.get("numpy")
    sys.modules["numpy"] = fake_numpy
    try:
        async def goto(*a, **kw):
            pass
        with tempfile.TemporaryDirectory(prefix=".douyin-audit-py-", dir=SOURCE.parents[2]) as folder:
            home = Path(folder)
            env = {"Path": Path, "HOME": home, "json": json, "os": os,
                   "_extract_aweme_id": lambda s: s,
                   "_ok": lambda **kw: {"ok": True, **kw},
                   "_err": lambda error, **kw: {"ok": False, "error": error, **kw}}
            watch = extracted("_watch_core", env)
            os.environ.pop("DOUYIN_VIDEO_LAB", None)
            missing = await watch(Page(), "7111111111111111111", 90)
            probe("missing video lab returns an error", missing.get("ok") is False and "run.py" in str(missing.get("error", "")), missing.get("error"))
            cache = home / "media/7111111111111111111.90.v4.json"
            cache.parent.mkdir(parents=True, exist_ok=True)
            cache.write_text('{"ok":true,"schemaVersion":4,"duration":30,"transcript":"cached speech"}', encoding="utf-8")
            hit = await watch(Page(), "7111111111111111111", 90)
            probe("v4 cache hit skips the lab", hit.get("cached") is True and hit.get("transcript") == "cached speech", hit)
            cache.unlink()
            stale = home / "media/7111111111111111111.90.v2.json"
            stale.write_text('{"ok":true,"schemaVersion":2,"transcript":"stale"}', encoding="utf-8")
            ignored = await watch(Page(), "7111111111111111111", 90)
            probe("v2 cache is not reused", ignored.get("cached") is not True and "run.py" in str(ignored.get("error", "")), ignored.get("error"))
        source = SOURCE.read_text(encoding="utf-8")
        probe("MCP tool registration enforces environment allowlist", "DOUYIN_MCP_TOOLS" in source and "restricted_tool" in source, "registration reads allowlist")
        defs = {n.name for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        probe("comment has no undefined retry helper", "await _open_comment_box(" not in source, "no undefined helper call")
        probe("browser uses owned pages instead of sweeping user tabs", "await _sweep_tabs(" not in source and "owned_pages" in source, "owned page tracking present")
        class PostsPage:
            async def context(self):
                return self

            async def page(self):
                return self

            async def evaluate(self, js, *args):
                if "location.pathname" in js:
                    return "audit-user-id"
                return {"aweme_list": [{"aweme_id": "7111111111111111111", "desc": "Old video", "create_time": int(time.time()) - 30 * 86400}], "has_more": False}

        async def guard(factory, *a):
            return await factory()

        env = {"_browser": PostsPage(), "_goto": goto, "_guard": guard, "j": lambda x: x, "time": time,
               "_ok": lambda **kw: {"ok": True, **kw}, "_err": lambda msg, **kw: {"ok": False, **kw}, "_login_state": lambda *a: None}
        async def login(*a): return {"loggedIn": True, "uid": "audit-user-id"}
        env["_login_state"] = login
        result = await extracted("douyin_my_posts", env)(days=3)
        probe("days=3 excludes 30-day-old videos", len(result["items"]) == 0, result)
    finally:
        subprocess.run = old_run
        if old_numpy is None:
            sys.modules.pop("numpy", None)
        else:
            sys.modules["numpy"] = old_numpy
    print(f"\nRegression checks: {sum(observations)}/{len(observations)} passed. No live actions performed.")
    return 0 if all(observations) else 1


if __name__ == "__main__":
    # Every await is an immediate in-memory stub. Driving it directly avoids
    # Windows event-loop socket/pipe setup in restricted audit environments.
    coroutine = main()
    try:
        coroutine.send(None)
        raise RuntimeError("Audit unexpectedly suspended on real I/O")
    except StopIteration as done:
        raise SystemExit(done.value)
