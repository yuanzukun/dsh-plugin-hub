import assert from 'node:assert/strict'
import vm from 'node:vm'
import { readFileSync } from 'node:fs'
const registrations=[],requests=[],states=[]
let hook=0,module
const config={watchSeconds:321,localRound:false,headlessModel:'provider/test',autoClean:false,replyWorksDays:7,perDay:5,replyPerRun:0,keywords:[]}
const status={ok:true,config,windows:{noon:{},night:{}},nextWindow:{},python:{via:'path'},perDay:5,pickedToday:0,build:{version:'0.2.1'}}
class Component{constructor(props){this.props=props}}
const React={
  Component,
  createElement(type,props,...children){return {type,props:{...props,children:children.length===1?children[0]:children}}},
  useState(initial){const i=hook++;if(!(i in states))states[i]=i===0?status:i===2?'run':i===5?{...config}:typeof initial==='function'?initial():initial;return [states[i],v=>{states[i]=typeof v==='function'?v(states[i]):v}]},
  useEffect(){},useCallback(fn){return fn},useRef(value){return {current:value}},useMemo(fn){return fn()},
}
const fetch=async(url,options={})=>{
  requests.push({url,options})
  return {ok:true,json:async()=>url.endsWith('/status')?status:url.endsWith('/config')?{ok:true,config,host:{ok:true}}:{ok:true}}
}
const sandbox={window:{__ModuleLoader__:{load(m){module=m.factory(()=>React)}},addEventListener(){}},
  document:{createElement(){return {setAttribute(){},remove(){}}},head:{appendChild(){}}},
  fetch,console,setTimeout,clearTimeout,setInterval,clearInterval}
vm.runInNewContext(readFileSync(new URL('../client.js',import.meta.url),'utf8'),sandbox)
module.apply({slots:{inject(name,fn){fn()},register(spec,render){registrations.push({spec,render})}},effect(){},get(){}})
const panel=registrations.find(r=>r.spec.id==='douyin-life').render()
hook=0
const tree=panel.type(panel.props)
function all(node,out=[]){
  if(!node||typeof node!=='object')return out
  if(Array.isArray(node)){for(const n of node)all(n,out);return out}
  out.push(node)
  if(typeof node.type==='function'&&!node.type.prototype?.render){all(node.type(node.props),out)}
  else all(node.props?.children,out)
  return out
}
const nodes=all(tree)
const buttons=nodes.filter(n=>n.type==='button')
const run=buttons.find(n=>n.props.children==='现在跑一轮')
assert.equal(run.props.disabled,true)
console.log('PASS busy buttons use a real boolean disabled attribute')
const save=buttons.find(n=>n.props.children==='保存')
await save.props.onClick()
const body=JSON.parse(requests.find(r=>r.url.endsWith('/config')&&r.options.method==='POST').options.body)
const patch=body.patch||body
for(const k of ['watchSeconds','localRound','headlessModel','autoClean','replyWorksDays','replyPerRun'])assert.equal(patch[k],config[k],k)
console.log('PASS settings save preserves advanced fields and zero reply count')
const memTab=nodes.find(n=>n.type&&n.type.name==='DouyinMemTab')
const memory=memTab.type(memTab.props)
const guardNode=memory.type(memory.props)
const Guard=guardNode.type
assert.ok(Guard.prototype instanceof Component)
assert.equal(typeof Guard.getDerivedStateFromError,'function')
const guard=new Guard({Comp:()=>null})
guard.state=Guard.getDerivedStateFromError(new Error('fixture failure'))
assert.equal(guard.render().props.role,'alert')
guard.componentDidCatch(new Error('fixture failure'))
assert.ok(requests.some(r=>r.url==='/api/douyin-duty/log'))
console.log('PASS memory error boundary exposes fallback and reports rendering error')
assert.ok(nodes.some(n=>n.type==='span'&&n.props.children==='环境待自检'))
console.log('PASS unknown environment is not displayed as ready')
console.log('4 passed, 0 failed')

