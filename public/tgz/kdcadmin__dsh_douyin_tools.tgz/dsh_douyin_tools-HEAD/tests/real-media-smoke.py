"""Real ffmpeg + real Whisper worker, using silence and cached model only.
This validates decoding and process startup; it does not exercise Douyin URLs.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import wave
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument("--model-cache",required=True)
parser.add_argument("--python-runtime",default=sys.executable)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
env={**os.environ,"HF_HUB_OFFLINE":"1","TRANSFORMERS_OFFLINE":"1",
     "HUGGINGFACE_HUB_CACHE":str(Path(args.model_cache).resolve()),"PYTHONUTF8":"1"}
with tempfile.TemporaryDirectory(prefix=".real-media-",dir=root/"tests") as temp:
    home=Path(temp)
    env["DSH_DOUYIN_HOME"]=str(home)
    env["HF_HOME"]=str(home/"models")
    fixture=home/"source.wav"
    with wave.open(str(fixture),"wb") as f:
        f.setnchannels(2);f.setsampwidth(2);f.setframerate(44100);f.writeframes(b"\0"*4*44100)
    decoded=home/"decoded.wav"
    result=subprocess.run([shutil.which("ffmpeg") or "ffmpeg","-y","-i",str(fixture),"-t","1","-vn","-ac","1","-ar","16000",str(decoded)],capture_output=True,timeout=30)
    assert result.returncode==0,result.stderr.decode("utf-8","replace")
    with wave.open(str(decoded),"rb") as f:
        assert (f.getnchannels(),f.getframerate(),f.getsampwidth())==(1,16000,2)
        assert f.getnframes()>0
    worker=subprocess.run([args.python_runtime,str(root/"vendor/douyin-mcp/mcp_server.py"),"--transcribe-wav",str(decoded)],env=env,capture_output=True,timeout=120)
    assert worker.returncode==0,worker.stderr.decode("utf-8","replace")
    result=json.loads(worker.stdout.decode("utf-8"))
    assert result["transcript"]=="" and result["language"]=="zh",result
    print(json.dumps({"ok":True,"checks":2,"ffmpeg":"actual PCM conversion","worker":"real cached base model; silence has no fabricated speech","network":"offline"},ensure_ascii=False))


