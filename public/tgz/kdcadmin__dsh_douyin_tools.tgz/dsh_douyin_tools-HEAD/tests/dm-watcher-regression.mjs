// Exercise the host scheduler with fake timers and fake MCP. Never start a browser/model.
import assert from 'node:assert/strict'
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { McpClient } from '../lib/mcp.mjs'
import { apply } from '../index.js'
const dir = mkdtempSync(join(import.meta.dirname,'.dm-watcher-'))
process.env.DSH_DOUYIN_HOME = dir
const originalCall = McpClient.prototype.call, originalTimeout = globalThis.setTimeout
let scheduled, event = {ok:true,changed:false}, reads = 0, waits = 0, acknowledgements = 0, clock = Date.now()
const originalNow = Date.now, cleanup = []
const config = {dmAutoReply:false,msgAllowTo:'Peer',autoClean:false,peakValley:false,reportLevel:'off',overlayMcp:false}
const save = patch => { Object.assign(config,patch); writeFileSync(join(dir,'config.json'),JSON.stringify(config)) }
save({})
McpClient.prototype.call = async function(name,args) {
  if (name === 'douyin_dm_snapshot') { reads++; return {ok:true,items:[]} }
  assert.equal(name,'douyin_dm_events')
  if (args.acknowledge) { acknowledgements++; return {ok:true,changed:false} }
  waits++; return event
}
globalThis.setTimeout = (fn,ms) => { scheduled = {fn,ms}; return {unref(){}} }
Date.now = () => clock
try {
  apply({tools:{register(){}},settings:{describe:()=>[]},webServer:{register(){}},logger:{},
    effect(fn,label){if(label?.includes('收 MCP'))cleanup.push(fn())}}, {})
  const tick = async () => { const next = scheduled; scheduled = null; await next.fn(); return scheduled }
  assert.equal(scheduled.ms,3000)
  await tick(); assert.equal(reads,0); assert.equal(waits,0); assert.equal(scheduled.ms,10000)
  console.log('PASS disabled watcher makes no browser calls')
  save({dmAutoReply:true})
  await tick(); assert.equal(reads,1); assert.equal(acknowledgements,1)
  for(let i=0;i<3;i++) await tick()
  assert.equal(reads,1); assert.equal(waits,3)
  console.log('PASS event heartbeats do not poll the inbox')
  event = {ok:true,changed:true}; await tick(); assert.equal(reads,2)
  console.log('PASS incoming event triggers reconciliation')
  event = {ok:false,error:'offline'}; await tick(); assert.equal(scheduled.ms,5000)
  await tick(); assert.equal(scheduled.ms,10000)
  // Reconciliation remains available even while the event endpoint is failing.
  clock += 120001; await tick(); assert.equal(reads,3)
  event = {ok:true,changed:false}; await tick(); assert.equal(reads,3)
  console.log('PASS disconnect backs off and periodic reconciliation still runs')
  const pending = scheduled
  for(const f of cleanup) f()
  scheduled = null; await pending.fn(); assert.equal(scheduled,null)
  console.log('PASS disposal stops rescheduling')
} finally {
  Date.now = originalNow; globalThis.setTimeout = originalTimeout; McpClient.prototype.call = originalCall
  for(const f of cleanup) f()
  rmSync(dir,{recursive:true,force:true})
}
