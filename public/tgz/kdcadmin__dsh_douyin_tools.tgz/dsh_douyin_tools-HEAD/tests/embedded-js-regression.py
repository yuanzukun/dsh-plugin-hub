"""Syntax-check embedded JavaScript without executing DOM or network actions."""
import ast
import json
import subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
tree=ast.parse((root/"vendor/douyin-mcp/mcp_server.py").read_text(encoding="utf-8"))
items=[]
for node in ast.walk(tree):
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr in ("evaluate","evaluate_handle","wait_for_function") and node.args:
        first=node.args[0]
        if isinstance(first,ast.Constant) and isinstance(first.value,str):
            items.append({"line":node.lineno,"source":first.value})
js="""const fs=require('node:fs');const items=JSON.parse(fs.readFileSync(0,'utf8'));let errors=0;
for(const x of items){try{new Function('return ('+x.source+'\\n)')}catch(e){errors++;console.log('FAIL line '+x.line+': '+e.message)}}
console.log(items.length+' embedded JavaScript snippets checked, '+errors+' errors');process.exitCode=errors?1:0;"""
r=subprocess.run(["node","-e",js],input=json.dumps(items),encoding="utf-8",capture_output=True,timeout=30)
print(r.stdout,end="")
if r.stderr:print(r.stderr)
raise SystemExit(r.returncode)

