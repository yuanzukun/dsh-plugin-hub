import assert from 'node:assert/strict'
import { existsSync } from 'node:fs'
assert.ok(existsSync(new URL('../lib/action-proxy.mjs', import.meta.url)), 'headless must use an authenticated host action proxy')
const { createActionProxy } = await import('../lib/action-proxy.mjs')
let allowed = new Set(['douyin_video']), calls = []
const proxy = await createActionProxy({ allowed: () => allowed, execute: async (name, args) => { calls.push({ name, args }); return { ok: true } } })
try {
  const send = (name, token = proxy.token, args = {}) => fetch(proxy.url, { method: 'POST', headers: { authorization: 'Bearer ' + token, 'content-type': 'application/json' }, body: JSON.stringify({ name, args }) })
  assert.equal((await send('douyin_video', 'bad')).status, 403)
  assert.equal((await send('douyin_publish')).status, 403)
  assert.equal(calls.length, 0)
  assert.equal((await send('douyin_video', proxy.token, { aweme_id: '123456', force: true })).status, 200)
  assert.equal(calls[0].args.force, undefined)
  allowed.clear()
  assert.equal((await send('douyin_video')).status, 403)
  console.log('PASS proxy authentication, live allowlist, and force stripping')
} finally { await proxy.close() }
