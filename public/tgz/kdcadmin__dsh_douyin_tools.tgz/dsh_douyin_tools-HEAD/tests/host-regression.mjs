import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, existsSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { EventEmitter } from 'node:events'
import { McpClient } from '../lib/mcp.mjs'
import { dayKey } from '../lib/state.mjs'
let active
const oldCall = McpClient.prototype.call
McpClient.prototype.call = async function (name, args) { active.calls.push({ name, args }); return active.respond(name, args) }
const { apply } = await import('../index.js')
let passed = 0, failed = 0
async function test(name, body) {
  const dir = mkdtempSync(join(import.meta.dirname, '.dy-regression-')), tools = new Map(), cleanup = [], routes = []
  process.env.DSH_DOUYIN_HOME = dir
  let seq = 0
  const e = {
    dir, calls: [],
    respond(n) {
      if (n === 'douyin_feed') return { ok: true, items: [{ aweme_id: String(7000000000000000000n + BigInt(++seq)), title: 'Audit video', duration: 30000, digg: 100 }] }
      if (n === 'douyin_my_posts') return { ok: true, items: [{ aweme_id: '7111111111111111111' }] }
      if (n === 'douyin_comments') return { ok: true, items: [{ cid: '123456', user: 'Contact', text: 'Hello' }] }
      if (n === 'douyin_inbox') return { ok: true, items: [{ name: 'AuditContact', peerId: 'peer1', conversationId: 'conv1', messageId: 'msg1', direction: 'inbound', preview: 'Hello', text: 'AuditContact 刚刚 Hello' }] }
      if (n === 'douyin_watch') return { ok: false, error: 'No audio' }
      return { ok: true, verified: true, messageId: 'sent1', cid: 'posted1', sent: ['hello'], outcomes: [{ kind: 'text', status: 'succeeded' }] }
    },
    read(f) { return existsSync(join(dir, f)) ? JSON.parse(readFileSync(join(dir, f), 'utf8')) : {} },
    write(f, x) { writeFileSync(join(dir, f), JSON.stringify(x)) },
    exec(n, a = {}) { return tools.get(n).execute(a) },
    async cfg(patch) { const r = await e.exec('dy_config', { patch }); if (!r.ok && typeof patch.autoComment !== 'string') throw new Error(r.error || r.hint || 'Config failed'); return r },
    async http(path, method = 'GET', data = {}) {
      const req = new EventEmitter(); Object.assign(req, { method, url: '/api/douyin-duty' + path, headers: {} })
      let status, value
      const p = routes[0].handler(req, { writeHead(s) { status = s }, end(b) { value = JSON.parse(b) } })
      queueMicrotask(() => { req.emit('data', Buffer.from(JSON.stringify(data))); req.emit('end') }); await p
      return { status, value }
    },
    sent(n) { return e.calls.filter(x => x.name === n) },
  }
  // These tests must never discover or launch the user's real model CLI.
  e.write('config.json', { dmAutoReply: false, overlayMcp: false })
  active = e
  const originalTimer=globalThis.setTimeout
  globalThis.setTimeout=(fn,ms,...args)=>{if(ms>120000)e.tick=fn;return originalTimer(fn,ms,...args)}
  try {
  apply({ tools: { register(t) { tools.set(t.name, t) } }, webServer: { register(r) { routes.push(r); return () => {} } },
    settings: { describe: () => [] }, effect(f) { const c = f(); if (typeof c === 'function') cleanup.push(c) }, logger: { info() {} } }, {})
  } finally { globalThis.setTimeout=originalTimer }
  try { await body(e); passed++; console.log('PASS ' + name) }
  catch (err) { failed++; console.log('FAIL ' + name + ': ' + err.message) }
  finally { for (const c of cleanup.reverse()) c(); rmSync(dir, { recursive: true, force: true }) }
}
try {
  await test('configuration fields survive save and reload', async e => { await e.cfg({ autoClean: false, replyWorksDays: 7 }); const c = (await e.exec('dy_config')).config; assert.equal(c.autoClean, false); assert.equal(c.replyWorksDays, 7) })
  await test('ledger preserves all action families', async e => { await e.cfg({dmReply:true}); e.write('ledger.json', { comments: [], replies: {}, published: {}, shares: { old: { day: dayKey() } }, plainComments: { old: {} }, dm: { old: {} } }); await e.exec('dy_dm_round'); const l = e.read('ledger.json'); assert.ok(l.shares.old); assert.ok(l.plainComments.old); assert.ok(l.dm.old) })
  await test('same inbound message is replied only once', async e => { await e.cfg({ dmReply:true, dmReplyPerDay: 1 }); await e.exec('dy_dm_round'); await e.exec('dy_dm_round'); assert.equal(e.sent('douyin_chat_send').length, 1) })
  await test('inbox failure remains a failure', async e => { await e.cfg({dmReply:true}); const base=e.respond; e.respond=(n,a)=>n==='douyin_inbox'?{ok:false,needLogin:true}:base(n,a); const r=await e.exec('dy_dm_round'); assert.equal(r.ok,false); assert.equal(r.needLogin,true) })
  await test('outbound previews never trigger replies', async e => { await e.cfg({dmReply:true}); const base=e.respond; e.respond=(n,a)=>n==='douyin_inbox'?{ok:true,items:[{name:'AuditContact',messageId:'out1',direction:'outbound',preview:'hello'}]}:base(n,a); await e.exec('dy_dm_round'); assert.equal(e.sent('douyin_chat_send').length,0) })
  await test('reply round honors disabled gate', async e => { await e.exec('dy_reply_round'); assert.equal(e.sent('douyin_comment').length,0) })
  await test('direct reply honors gate and does not consume top-level quota', async e => { await e.exec('dy_reply',{aweme_id:'7111111111111111111',cid:'123456',text:'Hello'}); assert.equal(e.sent('douyin_comment').length,0); assert.equal((e.read('ledger.json').comments||[]).length,0) })
  await test('replyPerRun zero sends nothing', async e => { await e.cfg({autoReply:true,replyPerRun:0}); await e.exec('dy_reply_round'); assert.equal(e.sent('douyin_comment').length,0) })
  await test('failed reply can retry without consuming success quota', async e => { await e.cfg({autoReply:true}); const base=e.respond; let attempts=0; e.respond=(n,a)=>n==='douyin_comment'&&++attempts===1?{ok:false,error:'not sent'}:base(n,a); await e.exec('dy_reply_round'); await e.exec('dy_reply_round'); assert.equal(e.sent('douyin_comment').length,2); assert.equal((await e.exec('dy_status')).doing.todayReplies,1) })
  await test('plain comments respect daily cap across rounds', async e => { await e.cfg({autoCommentPlain:true,plainCommentPerDay:1,watchBeforeAct:false}); await e.exec('dy_run'); await e.exec('dy_run'); assert.equal(e.sent('douyin_comment').length,1) })
  await test('local share requires explicit contact allowlist', async e => { await e.cfg({shareToNick:'Unlisted',autoCommentPlain:false,watchBeforeAct:false}); await e.exec('dy_run'); assert.equal(e.sent('douyin_share_video').length,0) })
  await test('allowlist uses complete names', async e => { await e.cfg({msgAllowTo:'ABCDAllowed'}); await e.exec('dy_chat_send',{nickname:'ABCDOther',text:'Hello'}); assert.equal(e.sent('douyin_chat_send').length,0) })
  await test('direct share respects zero daily cap', async e => { await e.cfg({msgAllowTo:'AuditContact',sharePerDay:0}); await e.exec('dy_share',{aweme_id:'7111111111111111111',to:'AuditContact'}); assert.equal(e.sent('douyin_share_video').length,0) })
  await test('failed watch does not produce public comment', async e => { await e.cfg({autoCommentPlain:true}); await e.exec('dy_run'); assert.equal(e.sent('douyin_comment').length,0) })
  await test('reportLevel off suppresses markdown but retains quota', async e => { await e.cfg({reportLevel:'off',autoCommentPlain:false}); await e.exec('dy_run'); assert.equal(existsSync(join(e.dir,'out',dayKey()+'.md')),false); assert.equal((await e.exec('dy_status')).pickedToday,1) })
  await test('concurrent rounds cannot exceed quota', async e => { await e.cfg({perDay:1,autoCommentPlain:false}); await Promise.all([e.exec('dy_run'),e.exec('dy_run')]); assert.equal(e.sent('douyin_feed').length,1); assert.equal((await e.exec('dy_status')).pickedToday,1) })
  await test('concurrent comments cannot exceed quota', async e => { await e.cfg({autoComment:true,mentionName:'Audit',commentPerDay:1}); const a={aweme_id:'7111111111111111111',text:'Hello'}; await Promise.all([e.exec('dy_comment',a),e.exec('dy_comment',a)]); assert.equal(e.sent('douyin_comment').length,1) })
  await test('sequential top-level duplicate is blocked', async e => { await e.cfg({autoComment:true,mentionName:'Audit'}); const a={aweme_id:'7111111111111111111',text:'Hello'}; await e.exec('dy_comment',a); await e.exec('dy_comment',a); assert.equal(e.sent('douyin_comment').length,1) })
  await test('old failure count does not permanently disable comments', async e => { e.write('state.json',{day:dayKey(),commentFails:2}); await e.cfg({autoCommentPlain:true,watchBeforeAct:false}); await e.exec('dy_run'); assert.equal(e.sent('douyin_comment').length,1) })
  await test('status includes browser diagnostics', async e => { assert.ok('cdp' in (await e.http('/status')).value) })
  await test('frontend error log route is available', async e => { assert.equal((await e.http('/log','POST',{msg:'audit'})).status,200) })
  await test('empty mention and zero round cap prevent local mention', async e => { await e.cfg({autoComment:true,mentionName:'',commentPerRound:0,autoCommentPlain:false,watchBeforeAct:false}); await e.exec('dy_run'); assert.equal(e.sent('douyin_comment').length,0) })
  await test('disabled share attachment sends neither text nor sticker', async e => { await e.cfg({shareToNick:'AuditContact',msgAllowTo:'AuditContact',shareWithNote:false,autoCommentPlain:false,watchBeforeAct:false}); await e.exec('dy_run'); assert.equal(e.sent('douyin_chat_batch').length,0) })
  await test('malformed response is not success', async e => { await e.cfg({autoComment:true,mentionName:'Audit'}); const base=e.respond;e.respond=(n,a)=>n==='douyin_comment'?'malformed':base(n,a); const r=await e.exec('dy_comment',{aweme_id:'7111111111111111111',text:'Hello'}); assert.equal(r.ok,false); assert.equal((e.read('ledger.json').comments||[]).length,0) })
  await test('invalid config does not enable actions', async e => { const r=await e.cfg({autoComment:'false',perDay:2.5}); assert.equal(r.ok,false); assert.equal((await e.exec('dy_config')).config.autoComment,false) })
  await test('contact revocation takes effect before send', async e => { await e.cfg({msgAllowTo:'AuditContact'}); e.write('config.json',{...e.read('config.json'),msgAllowTo:''}); await e.exec('dy_chat_send',{nickname:'AuditContact',text:'Hello'}); assert.equal(e.sent('douyin_chat_send').length,0) })
  await test('cleanup removes completed media', async e => { mkdirSync(join(e.dir,'media'));writeFileSync(join(e.dir,'media','audit.wav'),'audit');const r=await e.exec('dy_cleanup');assert.equal(existsSync(join(e.dir,'media','audit.wav')),false);assert.equal(r.ok,true) })
  await test('editing markdown does not change migrated selection quota', async e => { await e.cfg({autoCommentPlain:false});await e.exec('dy_run');writeFileSync(join(e.dir,'out',dayKey()+'.md'),'### 7999999999999999999\n### 7888888888888888888\n');assert.equal((await e.exec('dy_status')).pickedToday,1) })
  await test('cover proxy refuses loopback before fetch', async e => { const r=await e.http('/cover?u='+encodeURIComponent('http://127.0.0.1:8188/history'));assert.equal(r.status,400) })
  await test('ComfyUI publishes only outputs of its own prompt', async e => {
    const output=join(e.dir,'comfy');mkdirSync(output);writeFileSync(join(output,'a.mp4'),'a');writeFileSync(join(output,'b.mp4'),'b')
    await e.cfg({autoPublish:true,comfyOutputDir:output,comfyWorkflow:'{"1":{}}'})
    const oldFetch=globalThis.fetch
    globalThis.fetch=async u=>({ok:true,text:async()=>JSON.stringify(String(u).endsWith('/prompt')?{prompt_id:'A'}:{A:{status:{completed:true},outputs:{'1':{videos:[{filename:'a.mp4',subfolder:'',type:'output'}]}}}})})
    try{await e.exec('dy_publish',{latest:true});assert.equal(e.sent('douyin_publish')[0]?.args.video_path,join(output,'a.mp4'))}finally{globalThis.fetch=oldFetch}
  })
  await test('unknown run mode is rejected', async e => { const r=await e.exec('dy_run',{mode:'typo'});assert.equal(r.ok,false);assert.equal(r.started,undefined) })
  await test('unknown send consumes reserved quota and is not retried', async e => {
    await e.cfg({autoComment:true,mentionName:'Audit',commentPerDay:1})
    const base=e.respond;e.respond=(n,a)=>n==='douyin_comment'?{ok:false,status:'unknown',error:'ack lost'}:base(n,a)
    await e.exec('dy_comment',{aweme_id:'7111111111111111111',text:'Hello'})
    await e.exec('dy_comment',{aweme_id:'7222222222222222222',text:'Other'})
    assert.equal(e.sent('douyin_comment').length,1)
    assert.equal(Object.values(e.read('ledger.json').actions)[0].status,'unknown')
  })
  await test('direct comment reply uses reply gate and reply ledger', async e => {
    await e.cfg({autoReply:true,autoComment:false})
    const r=await e.exec('dy_comment',{aweme_id:'7111111111111111111',reply_cid:'123456',text:'Hello'})
    assert.equal(r.ok,true);assert.equal(e.sent('douyin_comment')[0].args.mention,'')
    assert.equal(e.read('ledger.json').comments.length,0)
    assert.equal(e.read('ledger.json').replies['123456'].ok,true)
  })
  await test('reply to another persons work is refused', async e => {
    await e.cfg({autoReply:true})
    await e.exec('dy_reply',{aweme_id:'7222222222222222222',cid:'123456',text:'Hello'})
    assert.equal(e.sent('douyin_comment').length,0)
  })
  await test('malformed nested ledger prevents writes and is preserved', async e => {
    await e.cfg({autoComment:true,mentionName:'Audit'});e.write('ledger.json',{actions:[]})
    const before=readFileSync(join(e.dir,'ledger.json'),'utf8')
    const r=await e.exec('dy_comment',{aweme_id:'7111111111111111111',text:'Hello'})
    assert.equal(r.ok,false);assert.equal(e.sent('douyin_comment').length,0)
    assert.equal(readFileSync(join(e.dir,'ledger.json'),'utf8'),before)
  })
  await test('report-off failure writes no report and watched cards use ledger', async e => {
    await e.cfg({reportLevel:'off'})
    await e.exec('dy_run')
    assert.equal((await e.http('/watched')).value.items.length,1)
    const base=e.respond;e.respond=(n,a)=>n==='douyin_feed'||n==='douyin_hot'?{ok:false,items:[]}:base(n,a)
    await e.exec('dy_run')
    assert.equal(existsSync(join(e.dir,'out',dayKey()+'.md')),false)
  })
  await test('skipLive reaches Python tools and sticker pick is forwarded',async e=>{
    await e.cfg({skipLive:false,msgAllowTo:'A B'})
    await e.exec('dy_run')
    await e.exec('dy_chat_sticker',{nickname:'A B',pick:3})
    assert.equal(e.sent('douyin_feed')[0].args.skip_live,false)
    assert.equal(e.sent('douyin_chat_sticker')[0].args.pick,3)
  })
  await test('zero comment round cap also stops plain comments',async e=>{
    await e.cfg({autoCommentPlain:true,commentPerRound:0,watchBeforeAct:false})
    await e.exec('dy_run');assert.equal(e.sent('douyin_comment').length,0)
  })
  await test('share attachment is a string and does not claim full viewing',async e=>{
    await e.cfg({msgAllowTo:'AuditContact',shareToNick:'AuditContact',watchBeforeAct:false,shareWithNote:true})
    await e.exec('dy_run')
    const parts=JSON.parse(e.sent('douyin_chat_batch')[0].args.messages)
    assert.equal(typeof parts[0].text,'string');assert.equal(parts[0].text.includes('看完'),false)
  })

  await test('legacy failed archived replies are removed from success index', async e => {
    const dir=join(e.dir,'ledger','2026','01');mkdirSync(dir,{recursive:true})
    writeFileSync(join(dir,'01.json'),JSON.stringify({replies:{'123456':{ok:false},'234567':{ok:true}}}))
    writeFileSync(join(e.dir,'replied-cids.txt'),'123456\n234567\n345678\n')
    e.write('ledger.json',{})
    await e.exec('dy_status')
    assert.deepEqual(readFileSync(join(e.dir,'replied-cids.txt'),'utf8').trim().split('\n'),['234567','345678'])
  })
  await test('failed streak sticker never falls back to unsolicited text',async e=>{
    await e.cfg({peakValley:false,streakNick:'AuditContact',msgAllowTo:'AuditContact',dmReply:false,autoReply:false})
    const base=e.respond;e.respond=(n,a)=>n==='douyin_chat_sticker'?{ok:false,status:'failed',error:'no sticker'}:base(n,a)
    await e.tick()
    assert.equal(e.sent('douyin_chat_sticker').length,1)
    assert.equal(e.sent('douyin_chat_send').length,0)
  })
} finally { McpClient.prototype.call=oldCall }
const fakeServer=`let ready=false;require('node:readline').createInterface({input:process.stdin}).on('line',s=>{const m=JSON.parse(s);if(m.method==='initialize')setTimeout(()=>process.stdout.write(JSON.stringify({id:m.id,result:{}})+'\\n'),80);else if(m.method==='notifications/initialized')ready=true;else if(m.id)process.stdout.write(JSON.stringify(ready?{id:m.id,result:{content:[{type:'text',text:'{"ok":true}'}]}}:{id:m.id,error:{message:'not initialized'}})+'\\n')})`
const c=new McpClient({command:process.execPath,args:['-e',fakeServer]})
try{const r=await Promise.all([c.call('a'),c.call('b')]);assert.ok(r.every(x=>x.ok));passed++;console.log('PASS concurrent MCP initialization')}catch(e){failed++;console.log('FAIL concurrent MCP initialization: '+e.message)}finally{c.stop()}
console.log(`${passed} passed, ${failed} failed`);process.exitCode=failed?1:0
