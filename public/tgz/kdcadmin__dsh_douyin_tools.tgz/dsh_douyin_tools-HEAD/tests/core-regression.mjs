import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, existsSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { ensureHomeFiles, writeJson } from '../lib/state.mjs'
import { withActionLock } from '../lib/actions.mjs'
import { coverUrl, publicAddress, imageType } from '../lib/covers.mjs'
import { runCommand } from '../lib/process.mjs'
import { findDesktopCli } from '../lib/dsh-cli.mjs'
const root=mkdtempSync(join(import.meta.dirname,'.core-'))
let passed=0
async function test(name,fn){await fn();passed++;console.log('PASS '+name)}
try{
  await test('atomic JSON failure preserves previous content',()=>{
    const path=join(root,'data.json');writeJson(path,{value:1})
    const cyclic={};cyclic.self=cyclic
    assert.throws(()=>writeJson(path,cyclic))
    assert.equal(JSON.parse(readFileSync(path)).value,1)
  })
  await test('known legacy runtime upgrades with a backup',()=>{
    const home=join(root,'legacy');mkdirSync(home)
    const old=readFileSync(new URL('../docs/repair-backup/mcp_server.py.before',import.meta.url))
    writeFileSync(join(home,'mcp_server.py'),old)
    assert.equal(ensureHomeFiles(join(import.meta.dirname,'..'),home).copied,true)
    assert.ok(readFileSync(join(home,'mcp_server.py.bak')).equals(old))
  })
  await test('user-modified runtime is preserved and new source staged',()=>{
    const home=join(root,'edited');mkdirSync(home);writeFileSync(join(home,'mcp_server.py'),'custom source')
    assert.equal(ensureHomeFiles(join(import.meta.dirname,'..'),home).reason,'kept')
    assert.equal(readFileSync(join(home,'mcp_server.py'),'utf8'),'custom source')
    assert.ok(existsSync(join(home,'mcp_server.py.new')))
  })
  await test('completed lock context cannot bypass a later lock',async()=>{
    const home=join(root,'lock');mkdirSync(home);const order=[];let later,fire
    await withActionLock(home,async()=>{
      await withActionLock(home,async()=>order.push('nested'))
      later=new Promise(resolve=>{fire=()=>withActionLock(home,async()=>order.push('late')).then(resolve)})
      // Timer inherits this AsyncLocalStorage context, but will run after release.
      setTimeout(()=>fire(),20)
    })
    await withActionLock(home,async()=>{order.push('first');await new Promise(r=>setTimeout(r,60));order.push('last')})
    await later;assert.deepEqual(order,['nested','first','last','late'])
  })
  await test('cover validation rejects local URLs and active content',()=>{
    assert.throws(()=>coverUrl('https://douyinpic.com.evil.example/a.png'))
    assert.throws(()=>coverUrl('http://127.0.0.1/'))
    for(const ip of ['127.0.0.1','10.0.0.1','169.254.169.254','192.168.1.1','::1','::ffff:127.0.0.1'])assert.equal(publicAddress(ip),false)
    assert.equal(publicAddress('8.8.8.8'),true)
    assert.throws(()=>imageType(Buffer.from('<svg onload="alert(1)"/>')))
    assert.equal(imageType(Buffer.from([255,216,255])),'image/jpeg')
  })
  await test('desktop CLI discovery uses verified current shim',()=>{
    const install=join(root,'install'), resources=join(install,'resources'), bin=join(resources,'runtime','cli','bin')
    mkdirSync(bin,{recursive:true})
    writeFileSync(join(install,'DeepSeek Harness.exe'),'fixture')
    writeFileSync(join(resources,'app.asar'),'fixture')
    const shim=String.raw`set "ELECTRON_RUN_AS_NODE=1" --expose-internals @deepseek-ai\dsh-desktop-host\lib\cli.js`
    writeFileSync(join(bin,'dsh.cmd'),shim)
    const cli=findDesktopCli({pluginDir:join(install,'plugins','fixture'),resourcesPath:'',execPath:join(root,'node.exe'),dshHome:''})
    assert.equal(cli.command,join(install,'DeepSeek Harness.exe'))
    assert.equal(cli.env.ELECTRON_RUN_AS_NODE,'1')
    assert.equal(cli.shell,false)
  })
  await test('process failures and timeouts reject without crashing host',async()=>{
    await assert.rejects(runCommand('missing-douyin-audit-command',[]))
    await assert.rejects(runCommand(process.execPath,['-e','process.exit(2)']))
    await assert.rejects(runCommand(process.execPath,['-e','setInterval(()=>{},1000)'],{timeoutMs:100}))
  })
}finally{rmSync(root,{recursive:true,force:true})}
console.log(passed+' passed, 0 failed')

