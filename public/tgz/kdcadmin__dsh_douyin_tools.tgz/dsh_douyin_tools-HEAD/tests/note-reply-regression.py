"""Offline regression: note replies go through the comment API once.

No browser, no network, no account action.
"""
import asyncio
import os
import sys
import types
import unittest
from pathlib import Path
import runpy

class FastMCP:
    def __init__(self, *a, **kw):
        self.tools = {}

    def tool(self):
        def register(fn):
            self.tools[fn.__name__] = fn
            return fn
        return register

stub = types.ModuleType("mcp.server.fastmcp")
stub.FastMCP = FastMCP
sys.modules["mcp.server.fastmcp"] = stub
os.environ["DOUYIN_ALLOW_WRITES"] = "0"
loaded = runpy.run_path(
    str(Path(__file__).resolve().parents[1] / "vendor/douyin-mcp/mcp_server.py"),
    run_name="note_reply_tests",
)
g = loaded["_note_reply_via_api"].__globals__


class Page:
    def __init__(self, payload):
        self.payload = payload
        self.scripts = []
        self.args = []

    async def evaluate(self, script, arg=None):
        self.scripts.append(script)
        self.args.append(arg)
        if isinstance(self.payload, Exception):
            raise self.payload
        return self.payload


class NoteReply(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self._saved = {
            "_fetch_comments_api": g["_fetch_comments_api"],
            "_publish_reply_api": g["_publish_reply_api"],
        }

    def tearDown(self):
        g.update(self._saved)

    async def test_publish_script_posts_once_with_reply_id(self):
        page = Page({
            "http": 200,
            "json": {
                "status_code": 0,
                "comment": {
                    "cid": "9001",
                    "aweme_id": "7701762401935477385",
                    "text": "收到",
                    "reply_id": "7701872889788793640",
                },
            },
        })
        result = await g["_publish_reply_api"](page, "7701762401935477385", "收到", "7701872889788793640")
        self.assertTrue(result["sent"])
        self.assertEqual(len(page.scripts), 1)
        script = page.scripts[0]
        self.assertIn("/aweme/v1/web/comment/publish/", script)
        self.assertIn("method: 'POST'", script)
        self.assertIn("reply_id: replyCid", script)
        self.assertEqual(page.args[0]["replyCid"], "7701872889788793640")
        self.assertNotIn("document.cookie", script)
        self.assertIn("credentials: 'include'", script)

    async def test_note_reply_returns_verified_receipt(self):
        calls = []

        async def fetch_comments(page, aid, num=30):
            return [{"cid": "7701872889788793640", "text": "[666][666][666]", "user": "GI666"}]

        async def publish(page, aid, text, reply_cid):
            calls.append((aid, text, reply_cid))
            return {
                "sent": True,
                "http": 200,
                "data": {
                    "status_code": 0,
                    "comment": {"cid": "9001", "aweme_id": aid, "text": text, "reply_id": reply_cid},
                },
            }

        g["_fetch_comments_api"] = fetch_comments
        g["_publish_reply_api"] = publish
        op = {"submitted": False}
        token = g["_OPERATION"].set(op)
        try:
            notes = []
            result = await g["_note_reply_via_api"](
                None, "7701762401935477385", "收到", "7701872889788793640", notes,
            )
        finally:
            g["_OPERATION"].reset(token)
        self.assertTrue(result["ok"])
        self.assertTrue(result["verified"])
        self.assertEqual(result["evidence"], "comment-publish-api")
        self.assertEqual(calls, [("7701762401935477385", "收到", "7701872889788793640")])
        self.assertTrue(op["submitted"])
        self.assertTrue(any("没有依赖评论面板" in n for n in notes))

    async def test_request_that_never_left_can_fall_back(self):
        async def fetch_comments(page, aid, num=30):
            return [{"cid": "7701887181573882666"}]

        async def publish(page, aid, text, reply_cid):
            return {"sent": False, "error": "socket closed"}

        g["_fetch_comments_api"] = fetch_comments
        g["_publish_reply_api"] = publish
        op = {"submitted": False}
        token = g["_OPERATION"].set(op)
        try:
            result = await g["_note_reply_via_api"](
                None, "7701762401935477385", "收到", "7701887181573882666", [],
            )
        finally:
            g["_OPERATION"].reset(token)
        self.assertIsNone(result)
        self.assertFalse(op["submitted"])

    async def test_platform_reject_is_not_retried_from_the_page(self):
        async def fetch_comments(page, aid, num=30):
            return [{"cid": "7701887181573882666"}]

        async def publish(page, aid, text, reply_cid):
            return {"sent": True, "http": 200, "data": {"status_code": 8}}

        g["_fetch_comments_api"] = fetch_comments
        g["_publish_reply_api"] = publish
        result = await g["_note_reply_via_api"](
            None, "7701762401935477385", "收到", "7701887181573882666", [],
        )
        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "failed")
        self.assertIn("没有再从页面发一次", result["error"])

    async def test_unknown_cid_does_not_post(self):
        posted = []

        async def fetch_comments(page, aid, num=30):
            return [{"cid": "1"}]

        async def publish(page, aid, text, reply_cid):
            posted.append(reply_cid)
            return {"sent": True, "http": 200, "data": {}}

        g["_fetch_comments_api"] = fetch_comments
        g["_publish_reply_api"] = publish
        result = await g["_note_reply_via_api"](
            None, "7701762401935477385", "收到", "7701872889788793640", [],
        )
        self.assertFalse(result["ok"])
        self.assertEqual(posted, [])

    async def test_evaluate_failure_is_not_sent(self):
        result = await g["_publish_reply_api"](Page(RuntimeError("page closed")), "1", "收到", "2")
        self.assertFalse(result["sent"])
        self.assertIn("page closed", result["error"])


if __name__ == "__main__":
    unittest.main()
