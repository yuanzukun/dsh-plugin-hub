"""No Chrome/network: exercise original Python send/registration functions with boundary doubles."""
import json
import os
import runpy
import sys
import types
from pathlib import Path

class FastMCP:
    def __init__(self, *a, **kw): self.tools = {}
    def tool(self):
        def register(fn): self.tools[fn.__name__] = fn; return fn
        return register
stub=types.ModuleType('mcp.server.fastmcp');stub.FastMCP=FastMCP
sys.modules['mcp.server.fastmcp']=stub
os.environ['DOUYIN_MCP_TOOLS']='douyin_video,douyin_chat_send'
os.environ['DOUYIN_ALLOW_WRITES']='0'
path=Path(__file__).resolve().parents[1]/'vendor/douyin-mcp/mcp_server.py'
m=runpy.run_path(str(path),run_name='regression_module')
g=m['_send_chat_part'].__globals__
RealNet=m['Net']
passed=failed=0
def check(name, ok):
    global passed,failed
    if ok: passed+=1; print('PASS '+name)
    else: failed+=1; print('FAIL '+name)
def run(coro):
    try: coro.send(None)
    except StopIteration as result: return result.value
    raise RuntimeError('Unexpected real I/O in test')

check('tool list enforces allowlist and write capability',set(m['mcp'].tools)=={'douyin_video'})
class Page:
    def __init__(self): self.keyboard=self
    async def click(self,*a,**kw): pass
    async def press(self,*a,**kw): pass
    async def type(self,*a,**kw): pass
    async def wait_for_timeout(self,*a): pass
page=Page()
for label,after,expected in [
 ('new outgoing message confirms send',[{'messageId':'new','direction':'outbound','text':'hello'}],True),
 ('incoming identical text is not confirmation',[{'messageId':'new','direction':'inbound','text':'hello'}],False),
 ('missing acknowledgement is unknown',[],False),
 ('old message is not new confirmation',[{'messageId':'old','direction':'outbound','text':'hello'}],False),
]:
    calls=[0]
    async def snapshot(*a):
        calls[0]+=1
        return [{'messageId':'old','direction':'outbound','text':'hello'}] if calls[0]==1 else after
    g['_message_snapshot']=snapshot
    result=run(m['_send_chat_part'](page,page,{'kind':'text','text':'hello'}))
    check(label,result.get('verified',False)==expected and (expected or result.get('status')=='unknown'))

async def guard(fn,*a):return await fn()
class Browser:
    async def context(self):return page
    async def page(self):return page
    async def page_chat(self):return page
async def open_chat(*a):return page
async def part(*a):
    return {'ok':True,'verified':True,'messageId':'a'} if a[-1]['kind']=='text' else {'ok':False,'status':'failed'}
g.update({'_guard':guard,'_browser':Browser(),'_open_conversation':open_chat,'_send_chat_part':part})
r=json.loads(run(m['douyin_chat_batch']('Audit',json.dumps([{'kind':'text','text':'hello'},{'kind':'sticker','keyword':'x'}]))))
check('batch exposes partial result without false sticker success',not r['ok'] and r['status']=='partial' and r['outcomes'][1]['status']=='failed')
check('message delimiter is not interpreted as commands',not json.loads(run(m['douyin_chat_batch']('Audit','a|sticker:b')))['ok'])
# The feed switch must reach its actual consumer.
seen={}
async def feed(*a,**kw):seen.update(kw);return {"ok":True,"items":[]}
g["_feed_core"]=feed
run(m["douyin_feed"](skip_live=False))
check("skip_live false reaches feed implementation",seen.get("skip_live") is False)

# Publishing needs a POST receipt and the correct platform identity.
async def unverified(*a,**kw):return {"ok":True}
g["_publish_unverified_core"]=unverified
for label,items,draft,expected in [
    ("publish requires POST receipt",[{"method":"GET","data":{"aweme_id":"old"}}],False,False),
    ("publish confirms platform work ID",[{"method":"POST","afterSubmit":True,"data":{"status_code":0,"aweme":{"aweme_id":"new"}}}],False,True),
    ("draft confirms draft ID",[{"method":"POST","afterSubmit":True,"data":{"status_code":0,"draft":{"draft_id":"d1"}}}],True,True),
    ("platform rejection is not success",[{"method":"POST","afterSubmit":True,"data":{"status_code":8,"aweme":{"aweme_id":"bad"}}}],False,False),
    ("pre-submit receipt is not current publish confirmation",[{"method":"POST","afterSubmit":False,"data":{"status_code":0,"aweme":{"aweme_id":"old"}}}],False,False),
]:
    class FakeNet:
        def __init__(self,*a):self.items=items;self.closed=False
        def close(self):self.closed=True
    g["Net"]=FakeNet
    result=run(m["_publish_core"](page,page,"x.mp4","title","",draft))
    check(label,result.get("verified",False)==expected and result["ok"]==expected)

# Existing cards of the same video do not confirm a new share.
class SharePage(Page):
    def locator(self,*a):return self
    @property
    def first(self):return self
    async def count(self):return 1
    async def hover(self,**kw):pass
    async def evaluate(self,js,*a):return True if "document.body" in js else {"ok":True}
share_page=SharePage()
async def goto(*a,**kw):pass
async def login(*a):return {"loggedIn":True}
g.update({"_goto":goto,"_login_state":login})
for label,message_id,expected in [("old video card cannot confirm share","old",False),("new outbound video card confirms share","new",True)]:
    count=[0]
    async def snapshot(*a):
        count[0]+=1
        return [{"messageId":"old" if count[0]==1 else message_id,"direction":"outbound","awemeId":"7111111111111111111"}]
    g["_message_snapshot"]=snapshot
    result=run(m["_share_core"](share_page,share_page,"7111111111111111111","Audit"))
    check(label,result.get("verified",False)==expected)

# Headless Python uses host proxy without opening a browser, preserving schema defaults.
os.environ["DOUYIN_MCP_TOOLS"]="douyin_feed"
os.environ["DOUYIN_PROXY_URL"]="http://127.0.0.1:12345/action"
os.environ["DOUYIN_PROXY_TOKEN"]="fixture"
m2=runpy.run_path(str(path),run_name="proxy_registration_regression")
requests=[]
class Response:
    def raise_for_status(self):pass
    def json(self):return {"ok":True,"items":[]}
class Client:
    def __init__(self,**kw):pass
    async def __aenter__(self):return self
    async def __aexit__(self,*a):pass
    async def post(self,url,**kw):requests.append((url,kw));return Response()
httpx=types.ModuleType("httpx");httpx.AsyncClient=Client
sys.modules["httpx"]=httpx
result=json.loads(run(m2["mcp"].tools["douyin_feed"](skip_live=False)))
check("Python headless proxy preserves tool arguments and bearer token",result["ok"] and requests[0][1]["json"]["args"]["skip_live"] is False and requests[0][1]["headers"]["Authorization"]=="Bearer fixture")

class EventPage:
    def __init__(self):self.listeners={}
    def on(self,event,fn):self.listeners[event]=fn
    def remove_listener(self,event,fn):self.listeners.pop(event,None)
class Request:
    method="POST"
    url="https://www.douyin.com/aweme/create"
class Receipt:
    headers={"content-type":"application/json"}
    def __init__(self,request):self.request=request
    async def text(self):return '{"status_code":0,"aweme_id":"fixture"}'
operation={"submitted":False}
token=g['_OPERATION'].set(operation)
try:
    ep=EventPage();net=RealNet(ep,lambda u:True)
    old_request=Request();net._on_request(old_request)
    operation['submitted']=True
    new_request=Request();net._on_request(new_request)
    run(net._grab(Receipt(old_request),old_request.url))
    run(net._grab(Receipt(new_request),new_request.url))
    check('receipt capture distinguishes pre-submit requests',[r['afterSubmit'] for r in net.items]==[False,True])
    net.close();check('receipt close removes request and response listeners',not ep.listeners)
finally:g['_OPERATION'].reset(token)

print(f'{passed} passed, {failed} failed')
raise SystemExit(bool(failed))
