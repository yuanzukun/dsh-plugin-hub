/**
 * Package version, single-sourced (pinned to package.json by the test suite).
 * @module dsh-lit-harvest/version
 */

/** The package version. */
export const VERSION = '0.1.2'
