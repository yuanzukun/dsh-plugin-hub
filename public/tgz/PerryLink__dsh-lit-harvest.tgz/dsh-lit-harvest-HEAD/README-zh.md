<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/assets/dsh-lit-harvest-hero-zh-dark.webp">
  <img src="docs/assets/dsh-lit-harvest-hero-zh-light.webp" width="100%" alt="dsh-lit-harvest 配图：fixture 里的同一个 DOI 在四个脚本化源中命中 —— sources[] 合并 openalex、crossref、arxiv 与 europepmc 为一条记录，3 条 OA pdf 链接取并集，citedBy 从 12 抬到 15；右侧是充分性检查的 gaps[] fracture 与它的下一轮 query">
</picture>

# dsh-lit-harvest

**一次搜四个索引，解析 OA 全文链接，证据够了就停 —— 全程确定性。**

*OpenAlex + Crossref + arXiv + Europe PMC 一次调用，Unpaywall 解析 OA 链接，配额 + 子主题覆盖与显式缺口，有界采集循环，运行记录落进 REP。循环里没有 LLM，不抓站，不绕付费墙。*

最近一次核验：DeepSeek Harness `dsh-v0.2.3-alpha.1`（2026-11-22）。

[English](README.md) · [Español](README-es.md) · [Português](README-pt.md) · [हिन्दी](README-hi.md)

[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%5E22.19%20%7C%7C%20%3E%3D24.9-brightgreen.svg)]()
[![DSH plugin](https://img.shields.io/badge/dsh--plugin-✅-green)](https://github.com/topics/dsh-plugin)

</div>

---

## 工具

| 工具 | 作用 |
|---|---|
| `lit_search` | 按请求的源并发检索，按 DOI → arXiv id → 归一化标题去重合并，保留每个来源与 PDF 字段，逐源报告错误 |
| `lit_resolve_oa` | 保留来源已给的链接；用 Unpaywall 查 DOI（需要 `mailto`）；逐项报告失败 |
| `lit_sufficiency` | 配额（core/total）+ 子主题覆盖（标题/摘要/关键词，中文单字 + 双字）；返回 `gaps[]` 与 `nextQueries[]` |
| `lit_harvest_run` | 有界循环：检索 → 充分性 → 按缺口下一轮；达标或 `maxRounds` 停止；持久化一条运行记录 |

每条命中都带来源、来源 id、`fetchedAt` 与命中它的 query。某个源失败会记成 `{source, code, message}`，绝不会变成“没有结果”。

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/assets/dsh-lit-harvest-flow-v5-dark.svg">
  <img src="docs/assets/dsh-lit-harvest-flow-v5-light.svg" width="100%" alt="dsh-lit-harvest 结构图：一次 query 扇出到 OpenAlex、Crossref、arXiv 与 Europe PMC，命中先按 DOI、再按 arXiv id、最后按归一化标题合并，配额与子主题覆盖给出显式缺口和下一轮 query，有界循环最终落一条 REP 运行记录；图内标签就是真实的工具名与字段名">
</picture>

*结构：检索 → 合并 → 判定；`sufficiency` 与运行记录是两条输出，`lit_harvest_run` 会一直循环到配额与子主题覆盖都满足，或到达 `maxRounds`。图内只有工具名与字段名，五语共用同一张结构图。*

## 数据源

| 源 | 查询 | OA 链接 |
|---|---|---|
| OpenAlex | `api.openalex.org/works` | `best_oa_location.pdf_url` |
| Crossref | `api.crossref.org/works` | 仅 landing page |
| arXiv | `export.arxiv.org/api/query` | `link[title=pdf]` |
| Europe PMC | `www.ebi.ac.uk/europepmc/rest/search` | `fullTextUrlList` 里的 PDF |
| Unpaywall | `api.unpaywall.org/v2/{doi}` | `best_oa_location` + `oa_locations` |

只允许这五个 host；拒绝重定向、显式超时、按 host 串行并限速。

## 安装

```sh
dsh plugin --profile <name> add dsh-lit-harvest
dsh --profile <name> --dump-config | grep dsh-lit-harvest
```

解析 DOI 前先配联系人：

```yaml
mailto: you@example.org
```

检索时 `mailto` 可选（只影响 polite pool）；**Unpaywall 查 DOI 必须有它**，缺了会返回 `MAILTO_REQUIRED`，而不是悄悄给空链接。

## 运行记录

`lit_harvest_run` 每次运行持久化一条 JSON 快照：

```text
topic, subtopics, generatedAt, plugin/version, settings,
rounds[{round, query, found, newPapers, sufficient, gaps, perSource, errors}],
papers[]（合并去重）,
sufficiency{coreCount, totalCount, minCore, minTotal, coverage[], gaps[], nextQueries[]}
```

- 挂了 `ctx.researchEvidence` → 一条 REP 证据（`application/json`），附一个 `source-status` 检查。
- 没挂 → `<root>/runs/<runId>.json`（默认 `.lit-harvest`）。
- `persist: false` → 不写任何东西。

run id = `sha256(topic, subtopics, queries, 论文标识)[:16]`，同一检索重跑得到同一个 id。

## 它不做什么

- **不做 LLM 相关性判断。** 配额、覆盖、缺口都是词法、可重算的；语义重排不在范围内。
- **不下载/解析全文。** 那是 `dsh-doc-anchor`；这里只给链接。
- **不抓 CNKI。** 中文文献走 `dsh-source-cnki` 的导出。
- **不绕付费墙。** 只用数据源给出的 OA 链接。
- **不查撤稿。** 那是 `dsh-retraction-watch`。
- **不静默修补。** 失败的源留在 `errors[]`；不完整的运行会标注。

## 兼容性

| | |
|---|---|
| DeepSeek Harness | `dsh-v0.2.2-rc.4`（本机实测）—— peer 区间 `>=0.2.1-0 <0.3.0 \|\| >=0.2.2-0 <0.3.0` |
| Node | `^22.19.0 \|\| >=24.9.0`（实测 `24.22.1`），仅 ESM |
| Peers | `@perrylink/dsh-research-core ^0.1.0`、`@deepseek-ai/cordis ^4.0.5-alpha.1`、`@deepseek-ai/dsh-tools`、`@deepseek-ai/schemastery ^3.18.5-alpha.1` |
| 运行时依赖 | **零** |

## 配置

| 键 | 默认 | 含义 |
|---|---|---|
| `enabled` | `true` | `false` 不挂任何工具 |
| `root` | `.lit-harvest` | 运行记录兜底根目录 |
| `mailto` | — | polite pool 联系人；Unpaywall 必需 |
| `userAgent` | `dsh-lit-harvest/0.1.0 (…)` | 发给每个源 |
| `timeoutMs` | `15000` | 单请求超时 |
| `minIntervalMs` | `150` | 同 host 请求间隔 |
| `retries` | `1` | 429/503 重试次数 |
| `maxResults` | `25` | `lit_search` 单源上限 |
| `maxRounds` / `perRound` | `3` / `10` | 采集循环上限 |
| `minCore` / `minTotal` | `5` / `10` | 默认配额 |

## 开发

![dsh-lit-harvest 测试套件：6 个测试文件的真实运行 —— 4 个充分性测试、3 个包契约测试、3 个合并去重测试、6 个运行时测试、5 个 provider 测试与挂载契约全部通过](docs/assets/dsh-lit-harvest-demo.gif)

*动图是 2026-11-21 真实运行的 `pnpm test` 输出（6 个测试文件、22 个测试，scripted HTTP，不联网）。插件没有 CLI，它自己的测试套件就是那次运行 —— 四个源被解析、一个 DOI 被合并、缺口与运行记录。*

```sh
pnpm install
pnpm run check:lockfile
pnpm typecheck
pnpm test
pnpm build
pnpm verify:package
```

锁文件按 `pnpm install --lockfile-only` 的原样提交（两段：pnpm 自身的管理文档 + 项目文档），本地 `pnpm install` 不会改写它；`pnpm run check:lockfile` 在它与 `package.json` 不一致或丢失该形式时失败。

测试用 scripted HTTP 与内联 fixture，不需要外网。

## 许可

Apache-2.0，见 [LICENSE](LICENSE)。
