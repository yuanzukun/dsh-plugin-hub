/** The board store against a real in-memory SQLite database: lifecycle, ordering, and history. */

import { afterEach, describe, expect, it } from 'vitest'
import { spawn, type ChildProcess } from 'node:child_process'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import {
  TaskConflictError,
  TaskStore,
  TaskNotFoundError,
  judgeRunByProcess,
  type TaskStoreOptions,
} from '../../src/host/store.ts'
import { currentRunOwner, type RunOwner } from '../../src/host/run-owner.ts'
import { systemProbes } from '../../src/host/process-identity.ts'
import { legacyStartRun } from './legacy-build.ts'
import { TaskValidationError } from '../../src/domain/validate.ts'
import type { Task, TaskStatus } from '../../src/domain/types.ts'

const OPTIONS: TaskStoreOptions = {
  newTaskPlacement: 'top',
  defaultStatus: 'backlog',
  journalMode: 'wal',
  busyTimeoutMs: 1000,
}

const open: TaskStore[] = []

/**
 * A throwaway board.
 * @param overrides - options differing from the test defaults.
 * @returns the store, closed automatically after the test.
 */
function board(overrides: Partial<TaskStoreOptions> = {}): TaskStore {
  const store = new TaskStore(':memory:', { ...OPTIONS, ...overrides })
  open.push(store)
  return store
}

/** A stable clock so timestamps in assertions are exact. */
let clock = 1_700_000_000_000

/**
 * Advance and read the test clock.
 * @returns the next epoch-ms stamp.
 */
function tick(): number {
  clock += 1000
  return clock
}

afterEach(() => {
  for (const store of open.splice(0)) store.close()
})

describe('create', () => {
  it('stores the canonical card and its first history entry', () => {
    const store = board()
    const task = store.create(
      { title: '  Ship   the  board  ', body: '  detail\n\n  ', labels: ['UI', 'ui', ' Board '], priority: 'high' },
      { actor: 'user', sessionId: 's1' },
      tick(),
    )
    expect(task.title).toBe('Ship the board')
    expect(task.body).toBe('detail')
    expect(task.labels).toEqual(['board', 'ui'])
    expect(task.priority).toBe('high')
    expect(task.status).toBe('backlog')
    expect(task.ref).toBe(1)
    expect(task.archived).toBe(false)
    expect(task.createdBy).toBe('user')
    expect(task.sessionId).toBe('s1')
    expect(task.id).toMatch(/^t_[0-9a-z]{22}$/u)

    const detail = store.detail(task.id)
    expect(detail.activity).toHaveLength(1)
    expect(detail.activity[0]?.kind).toBe('created')
    expect(detail.activity[0]?.to).toBe('Ship the board')
    expect(detail.activity[0]?.sessionId).toBe('s1')
  })

  it('never reuses a display number, even after a delete', () => {
    const store = board()
    const first = store.create({ title: 'one' }, { actor: 'user' }, tick())
    const second = store.create({ title: 'two' }, { actor: 'user' }, tick())
    expect([first.ref, second.ref]).toEqual([1, 2])
    store.remove(second.id)
    const third = store.create({ title: 'three' }, { actor: 'user' }, tick())
    expect(third.ref).toBe(3)
  })

  it('stamps completedAt when a card is created already done', () => {
    const store = board()
    const at = tick()
    const task = store.create({ title: 'already finished', status: 'done' }, { actor: 'user' }, at)
    expect(task.completedAt).toBe(at)
  })

  it('rejects an empty title without writing anything', () => {
    const store = board()
    expect(() => store.create({ title: '   ' }, { actor: 'agent' }, tick())).toThrow(TaskValidationError)
    expect(store.read().tasks).toHaveLength(0)
    expect(store.revision()).toBe(0)
  })
})

describe('ordering', () => {
  it('places new cards at the top when configured to', () => {
    const store = board({ newTaskPlacement: 'top' })
    const first = store.create({ title: 'first' }, { actor: 'user' }, tick())
    const second = store.create({ title: 'second' }, { actor: 'user' }, tick())
    expect(store.read().tasks.map(task => task.id)).toEqual([second.id, first.id])
  })

  it('places new cards at the bottom when configured to', () => {
    const store = board({ newTaskPlacement: 'bottom' })
    const first = store.create({ title: 'first' }, { actor: 'user' }, tick())
    const second = store.create({ title: 'second' }, { actor: 'user' }, tick())
    expect(store.read().tasks.map(task => task.id)).toEqual([first.id, second.id])
  })

  it('drops a card between the two neighbours a drag named', () => {
    const store = board({ newTaskPlacement: 'bottom' })
    const a = store.create({ title: 'a' }, { actor: 'user' }, tick())
    const b = store.create({ title: 'b' }, { actor: 'user' }, tick())
    const c = store.create({ title: 'c' }, { actor: 'user' }, tick())
    store.update(c.id, { place: { after: a.id, before: b.id } }, { actor: 'user' }, tick())
    expect(store.read().tasks.map(task => task.title)).toEqual(['a', 'c', 'b'])
  })

  it('moves a card into another column at the named position', () => {
    const store = board({ newTaskPlacement: 'bottom' })
    const a = store.create({ title: 'a', status: 'todo' }, { actor: 'user' }, tick())
    const b = store.create({ title: 'b', status: 'todo' }, { actor: 'user' }, tick())
    const dragged = store.create({ title: 'dragged', status: 'backlog' }, { actor: 'user' }, tick())

    const moved = store.update(
      dragged.id,
      { status: 'todo', place: { after: a.id, before: b.id } },
      { actor: 'user' },
      tick(),
    )
    expect(moved.status).toBe('todo')
    const todo = store.read({ status: ['todo'] }).tasks.map(task => task.title)
    expect(todo).toEqual(['a', 'dragged', 'b'])
  })

  it('lands at an end when a named neighbour has since left the column', () => {
    const store = board({ newTaskPlacement: 'bottom' })
    const a = store.create({ title: 'a' }, { actor: 'user' }, tick())
    const b = store.create({ title: 'b' }, { actor: 'user' }, tick())
    store.remove(a.id)
    // `after` no longer resolves: the drop still lands, rather than throwing the gesture away.
    const placed = store.update(b.id, { place: { after: a.id } }, { actor: 'user' }, tick())
    expect(placed.id).toBe(b.id)
    expect(store.read().tasks).toHaveLength(1)
  })

  it('ignores a named neighbour that now sits in another column', () => {
    const store = board({ newTaskPlacement: 'bottom' })
    store.create({ title: 'a', status: 'todo' }, { actor: 'user' }, tick())
    store.create({ title: 'b', status: 'todo' }, { actor: 'user' }, tick())
    const c = store.create({ title: 'c', status: 'todo' }, { actor: 'user' }, tick())
    // Another writer moved the neighbour to the backlog between the drag and the drop.
    const elsewhere = store.create({ title: 'elsewhere', status: 'backlog' }, { actor: 'user' }, tick())

    store.update(c.id, { place: { before: elsewhere.id } }, { actor: 'user' }, tick())

    // Its rank orders a different column; landing "before" it would have put c at the top of todo.
    expect(store.read({ status: ['todo'] }).tasks.map(task => task.title)).toEqual(['a', 'b', 'c'])
  })

  it('lands directly below a neighbour named alone, not past the cards that follow it', () => {
    const store = board({ newTaskPlacement: 'bottom' })
    const a = store.create({ title: 'a' }, { actor: 'user' }, tick())
    store.create({ title: 'b' }, { actor: 'user' }, tick())
    const c = store.create({ title: 'c' }, { actor: 'user' }, tick())

    store.update(c.id, { place: { after: a.id } }, { actor: 'user' }, tick())

    expect(store.read().tasks.map(task => task.title)).toEqual(['a', 'c', 'b'])
  })

  it('keeps every column independently ordered', () => {
    const store = board({ newTaskPlacement: 'bottom' })
    const statuses: TaskStatus[] = ['backlog', 'todo', 'in_progress', 'blocked', 'done']
    for (const status of statuses) {
      for (let index = 0; index < 3; index++) {
        store.create({ title: `${status}-${index}`, status }, { actor: 'user' }, tick())
      }
    }
    const view = store.read()
    for (const status of statuses) {
      const column = view.tasks.filter(task => task.status === status)
      expect(column.map(task => task.title)).toEqual([`${status}-0`, `${status}-1`, `${status}-2`])
    }
    expect(view.counts).toEqual({ backlog: 3, todo: 3, in_progress: 3, blocked: 3, done: 3 })
  })
})

describe('update', () => {
  it('logs only the fields that actually changed', () => {
    const store = board()
    const task = store.create({ title: 'title', priority: 'normal' }, { actor: 'user' }, tick())
    store.update(task.id, { title: 'title', priority: 'normal' }, { actor: 'user' }, tick())
    expect(store.detail(task.id).activity).toHaveLength(1)
    expect(store.revision()).toBe(1)

    store.update(task.id, { title: 'renamed' }, { actor: 'user' }, tick())
    const kinds = store.detail(task.id).activity.map(entry => entry.kind)
    expect(kinds).toEqual(['created', 'title'])
  })

  it('stamps and clears completedAt across the done boundary', () => {
    const store = board()
    const task = store.create({ title: 'work' }, { actor: 'user' }, tick())
    const doneAt = tick()
    expect(store.update(task.id, { status: 'done' }, { actor: 'user' }, doneAt).completedAt).toBe(doneAt)
    expect(store.update(task.id, { status: 'todo' }, { actor: 'user' }, tick()).completedAt).toBeUndefined()
  })

  it('clears a clearable field with null and leaves an absent key alone', () => {
    const store = board()
    const task = store.create(
      { title: 'card', assignee: 'nav', labels: ['x'], dueAt: 1_700_000_000_000, body: 'body' },
      { actor: 'user' },
      tick(),
    )
    const cleared = store.update(task.id, { assignee: null, labels: null, dueAt: null }, { actor: 'user' }, tick())
    expect(cleared.assignee).toBeUndefined()
    expect(cleared.labels).toEqual([])
    expect(cleared.dueAt).toBeUndefined()
    expect(cleared.body).toBe('body')
  })

  it('rolls the whole patch back when one field is invalid', () => {
    const store = board()
    const task = store.create({ title: 'original' }, { actor: 'user' }, tick())
    expect(() =>
      store.update(task.id, { title: 'renamed', priority: 'nonsense' as never }, { actor: 'user' }, tick()),
    ).toThrow(TaskValidationError)
    expect(store.detail(task.id).task.title).toBe('original')
    expect(store.detail(task.id).activity).toHaveLength(1)
  })

  it('refuses an unknown card', () => {
    const store = board()
    expect(() => store.update('t_0000000000000000000000', { title: 'x' }, { actor: 'user' }, tick()))
      .toThrow(TaskNotFoundError)
  })
})

describe('archive', () => {
  it('hides a card from the board while keeping everything attached to it', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    store.addComment(task.id, 'a note', { actor: 'user' }, tick())

    const archivedAt = tick()
    const archived = store.setArchived(task.id, true, { actor: 'user' }, archivedAt)
    expect(archived.archived).toBe(true)
    expect(archived.archivedAt).toBe(archivedAt)
    expect(store.read().tasks).toHaveLength(0)
    expect(store.read({ archived: 'archived' }).tasks).toHaveLength(1)
    expect(store.read({ archived: 'all' }).tasks).toHaveLength(1)
    expect(store.counts().archivedCount).toBe(1)
    expect(store.detail(task.id).comments).toHaveLength(1)

    const restored = store.setArchived(task.id, false, { actor: 'user' }, tick())
    expect(restored.archived).toBe(false)
    expect(restored.archivedAt).toBeUndefined()
    expect(store.read().tasks).toHaveLength(1)
    expect(store.detail(task.id).activity.map(entry => entry.kind))
      .toEqual(['created', 'comment', 'archived', 'restored'])
  })

  it('is a no-op when the card is already in the requested state', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    const before = store.revision()
    store.setArchived(task.id, false, { actor: 'user' }, tick())
    expect(store.revision()).toBe(before)
  })
})

describe('comments', () => {
  it('writes, edits, and deletes a comment', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    const comment = store.addComment(task.id, '  first note  ', { actor: 'agent', sessionId: 's9' }, tick())
    expect(comment.body).toBe('first note')
    expect(comment.author).toBe('agent')
    expect(comment.createdAt).toBe(comment.updatedAt)

    const editedAt = tick()
    const edited = store.editComment(comment.id, 'revised note', editedAt)
    expect(edited.body).toBe('revised note')
    expect(edited.updatedAt).toBe(editedAt)
    expect(edited.createdAt).toBe(comment.createdAt)

    store.removeComment(comment.id, tick())
    expect(store.detail(task.id).comments).toHaveLength(0)
  })

  it('rejects an empty comment', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    expect(() => store.addComment(task.id, '   ', { actor: 'user' }, tick())).toThrow(TaskValidationError)
  })

  it('refuses a comment on an unknown card', () => {
    const store = board()
    expect(() => store.addComment('t_0000000000000000000000', 'hi', { actor: 'user' }, tick()))
      .toThrow(TaskNotFoundError)
  })

  it('takes comments and history with the card when it is deleted', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    store.addComment(task.id, 'note', { actor: 'user' }, tick())
    store.remove(task.id)
    expect(() => store.detail(task.id)).toThrow(TaskNotFoundError)
    expect(store.read({ archived: 'all' }).tasks).toHaveLength(0)
  })
})

describe('query', () => {
  /**
   * Seed a small board covering every filter dimension.
   * @param store - the board to fill.
   * @returns the created cards by name.
   */
  function seed(store: TaskStore): { alpha: Task; beta: Task; gamma: Task } {
    const alpha = store.create(
      { title: 'Alpha login flow', body: 'OAuth handshake', status: 'todo', priority: 'urgent', labels: ['auth'], assignee: 'Nav' },
      { actor: 'user' },
      tick(),
    )
    const beta = store.create(
      { title: 'Beta search', body: 'ranking', status: 'in_progress', priority: 'low', labels: ['search', 'ui'] },
      { actor: 'user' },
      tick(),
    )
    const gamma = store.create(
      { title: 'Gamma 100% coverage', status: 'done', priority: 'normal', labels: ['ui'] },
      { actor: 'user' },
      tick(),
    )
    return { alpha, beta, gamma }
  }

  it('filters by status, priority, assignee, and label', () => {
    const store = board()
    const { alpha, beta, gamma } = seed(store)
    expect(store.read({ status: ['todo'] }).tasks.map(t => t.id)).toEqual([alpha.id])
    expect(store.read({ priority: ['low', 'normal'] }).tasks.map(t => t.id).sort())
      .toEqual([beta.id, gamma.id].sort())
    expect(store.read({ assignee: 'nav' }).tasks.map(t => t.id)).toEqual([alpha.id])
    expect(store.read({ labels: ['ui'] }).tasks.map(t => t.id).sort()).toEqual([beta.id, gamma.id].sort())
    expect(store.read({ labels: ['ui', 'search'] }).tasks.map(t => t.id)).toEqual([beta.id])
  })

  it('searches title and body case-insensitively', () => {
    const store = board()
    const { alpha, beta } = seed(store)
    expect(store.read({ search: 'ALPHA' }).tasks.map(t => t.id)).toEqual([alpha.id])
    expect(store.read({ search: 'handshake' }).tasks.map(t => t.id)).toEqual([alpha.id])
    expect(store.read({ search: 'ranking' }).tasks.map(t => t.id)).toEqual([beta.id])
  })

  it('treats LIKE wildcards in a search as literal text', () => {
    const store = board()
    const { gamma } = seed(store)
    expect(store.read({ search: '100%' }).tasks.map(t => t.id)).toEqual([gamma.id])
    // A bare `%` would match everything if it reached SQLite unescaped.
    expect(store.read({ search: '%%%' }).tasks).toHaveLength(0)
    expect(store.read({ search: '_' }).tasks).toHaveLength(0)
  })

  it('does not let a label match by prefix', () => {
    const store = board()
    store.create({ title: 'card', labels: ['review'] }, { actor: 'user' }, tick())
    expect(store.read({ labels: ['rev'] }).tasks).toHaveLength(0)
    expect(store.read({ labels: ['review'] }).tasks).toHaveLength(1)
  })

  it('reports whole-board counts regardless of the filter', () => {
    const store = board()
    seed(store)
    const view = store.read({ status: ['todo'] })
    expect(view.tasks).toHaveLength(1)
    expect(view.counts).toEqual({ backlog: 0, todo: 1, in_progress: 1, blocked: 0, done: 1 })
  })

  it('keeps outstanding work when a limit cuts the read', () => {
    const store = board()
    for (let index = 0; index < 3; index++) store.create({ title: `done ${index}`, status: 'done' }, { actor: 'user' }, tick())
    store.create({ title: 'doing', status: 'in_progress' }, { actor: 'user' }, tick())
    store.create({ title: 'next', status: 'todo' }, { actor: 'user' }, tick())
    store.create({ title: 'stuck', status: 'blocked' }, { actor: 'user' }, tick())

    // Alphabetically `blocked, done, in_progress, todo`: a cut at three returned finished work and
    // hid what is being worked on.
    expect(store.read({ limit: 3 }).tasks.map(task => task.status)).toEqual(['todo', 'in_progress', 'blocked'])
  })

  it('caps a read at the requested limit', () => {
    const store = board()
    for (let index = 0; index < 10; index++) {
      store.create({ title: `card ${index}` }, { actor: 'user' }, tick())
    }
    expect(store.read({ limit: 4 }).tasks).toHaveLength(4)
    expect(() => store.read({ limit: 0 })).toThrow(TaskValidationError)
  })
})

describe('runs', () => {
  it('marks a card running and records how the run ended', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    const owner = currentRunOwner('s1')
    const running = store.startRun(task.id, 'task-1', owner, { actor: 'user', sessionId: 's1' }, tick())
    expect(running.runningJobId).toBe('task-1')
    expect(store.runMarker(task.id)).toMatchObject({ taskId: task.id, ref: task.ref, jobId: 'task-1', owner })
    expect(running.runOwnerUnknown).toBeUndefined()

    const finished = store.finishRun(
      task.id,
      { jobId: 'task-1', status: 'completed', detail: 'exit 0', startedAt: 1, finishedAt: 2 },
      owner,
      { actor: 'system' },
      tick(),
      { report: 'did the thing', completedStatus: 'done' },
    )
    expect(finished?.current).toBe(true)
    expect(finished?.task.runningJobId).toBeUndefined()
    expect(finished?.task.status).toBe('done')
    expect(finished?.task.lastRun).toEqual({
      jobId: 'task-1', status: 'completed', detail: 'exit 0', startedAt: 1, finishedAt: 2,
    })
    expect(store.runMarker(task.id)).toBeUndefined()
    expect(store.detail(task.id).comments.map(comment => comment.body)).toEqual(['did the thing'])
    expect(store.detail(task.id).activity.map(entry => entry.kind))
      .toEqual(['created', 'run-started', 'run-finished', 'comment', 'status'])
  })

  it('refuses a second run on a card that already has one', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    store.startRun(task.id, 'task-1', currentRunOwner('s1'), { actor: 'user' }, tick())
    expect(() => store.startRun(task.id, 'task-2', currentRunOwner('s1'), { actor: 'user' }, tick()))
      .toThrow(/already running as job task-1/u)
  })

  it('does not let another process\'s settlement of the same job id clear this run', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    // Job ids are per-process counters: process A and process B both have a `task-1`.
    const mine = currentRunOwner('s1')
    store.startRun(task.id, 'task-1', mine, { actor: 'user' }, tick())
    const elsewhere = { ...mine, instance: 'another-process', pid: mine.pid + 1 }

    const settled = store.finishRun(
      task.id,
      { jobId: 'task-1', status: 'failed', startedAt: 1, finishedAt: 2 },
      elsewhere,
      { actor: 'system' },
      tick(),
      { completedStatus: 'done' },
    )

    expect(settled?.current).toBe(false)
    expect(settled?.task.runningJobId).toBe('task-1')
    expect(settled?.task.status).toBe('backlog')
    expect(settled?.task.lastRun).toBeUndefined()
  })

  it('keeps a late settlement\'s outcome when the marker was already swept', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    const owner = currentRunOwner('s1')
    store.startRun(task.id, 'task-1', owner, { actor: 'user' }, tick())
    store.reconcileRuns(() => ({ kind: 'interrupted' }), tick())

    const settled = store.finishRun(
      task.id,
      { jobId: 'task-1', status: 'completed', startedAt: 1, finishedAt: 2 },
      owner,
      { actor: 'system' },
      tick(),
      { completedStatus: 'done' },
    )

    expect(settled?.current).toBe(false)
    expect(settled?.task.lastRun?.status).toBe('completed')
    // The automatic move belongs to a current run only.
    expect(settled?.task.status).toBe('backlog')
  })

  it('tolerates a card deleted while its run was live', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    const owner = currentRunOwner('s1')
    store.startRun(task.id, 'task-1', owner, { actor: 'user' }, tick())
    store.remove(task.id)
    const settled = store.finishRun(
      task.id,
      { jobId: 'task-1', status: 'killed', startedAt: 1, finishedAt: 2 },
      owner,
      { actor: 'system' },
      tick(),
    )
    expect(settled).toBeUndefined()
  })

  it('records a settled verdict from the sweep as the run\'s outcome', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    store.startRun(task.id, 'task-1', currentRunOwner('s1'), { actor: 'user' }, tick())
    const summary = { jobId: 'task-1', status: 'failed', detail: 'boom', startedAt: 1, finishedAt: 2 } as const

    expect(store.reconcileRuns(() => ({ kind: 'settled', summary }), tick())).toBe(1)

    expect(store.detail(task.id).task.lastRun).toEqual(summary)
    expect(store.detail(task.id).activity.at(-1)).toMatchObject({ kind: 'run-finished', from: 'task-1', to: 'failed' })
  })
})

describe('the stale-run sweep, judged by owner process', () => {
  const children: ChildProcess[] = []

  afterEach(() => {
    for (const child of children.splice(0)) child.kill('SIGKILL')
  })

  /**
   * A real second process, standing in for another dsh on the same board.
   * @returns the running child.
   */
  async function otherProcess(): Promise<ChildProcess> {
    const child = spawn(process.execPath, ['-e', 'setInterval(() => {}, 1000)'], { stdio: 'ignore' })
    children.push(child)
    await new Promise<void>((resolve) => { child.once('spawn', () => { resolve() }) })
    return child
  }

  /**
   * The owner record another process on this machine would have written.
   * @param pid - that process's pid.
   * @returns the owner, with the process start read the way that process would have read its own.
   */
  function ownerAt(pid: number): RunOwner {
    const { processStart: _mine, ...rest } = currentRunOwner('s1')
    const start = systemProbes.startToken(pid)
    return { ...rest, pid, ...start === undefined ? {} : { processStart: start } }
  }

  /**
   * A board with one card whose run is owned as described.
   * @param owner - the owner to record.
   * @returns the store and the card id.
   */
  function markedBoard(owner: RunOwner): { store: TaskStore; taskId: string } {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    store.startRun(task.id, 'task-1', owner, { actor: 'user' }, tick())
    return { store, taskId: task.id }
  }

  it('leaves a run owned by a live process on this host alone', async () => {
    const child = await otherProcess()
    const pid = child.pid as number
    const { store, taskId } = markedBoard({ ...ownerAt(pid), instance: 'b' })

    expect(store.reconcileRuns(judgeRunByProcess, tick())).toBe(0)
    expect(store.detail(taskId).task.runningJobId).toBe('task-1')
  })

  it('clears a run whose owner process has exited', async () => {
    const child = await otherProcess()
    const pid = child.pid as number
    const { store, taskId } = markedBoard({ ...ownerAt(pid), instance: 'b' })
    const exited = new Promise<void>((resolve) => { child.once('exit', () => { resolve() }) })
    child.kill('SIGKILL')
    await exited

    expect(store.reconcileRuns(judgeRunByProcess, tick())).toBe(1)
    expect(store.detail(taskId).task.runningJobId).toBeUndefined()
    expect(store.detail(taskId).activity.at(-1)).toMatchObject({ kind: 'run-finished', to: 'interrupted' })
  })

  it('leaves this process\'s own run for the job registry to judge', () => {
    const { store, taskId } = markedBoard(currentRunOwner('s1'))
    expect(store.reconcileRuns(judgeRunByProcess, tick())).toBe(0)
    expect(store.detail(taskId).task.runningJobId).toBe('task-1')
  })

  it('treats an earlier holder of this process\'s pid as gone', () => {
    const { store } = markedBoard({ ...currentRunOwner('s1'), instance: 'a-previous-process' })
    expect(store.reconcileRuns(judgeRunByProcess, tick())).toBe(1)
  })

  it('never sweeps a run owned on another machine, whose processes it cannot probe', () => {
    const { store } = markedBoard({ ...currentRunOwner('s1'), machine: 'another-machine', pid: 1, instance: 'x' })
    expect(store.reconcileRuns(judgeRunByProcess, tick())).toBe(0)
  })

  it('clears a run whose pid now belongs to a process that started later', async () => {
    const child = await otherProcess()
    const pid = child.pid as number
    const reused = { ...ownerAt(pid), instance: 'b', processStart: 'linux:an-earlier-boot:1' }
    if (process.platform === 'darwin') reused.processStart = 'darwin:1'
    const { store, taskId } = markedBoard(reused)

    const expected = process.platform === 'darwin' || process.platform === 'linux' ? 1 : 0
    expect(store.reconcileRuns(judgeRunByProcess, tick())).toBe(expected)
    expect(store.detail(taskId).task.runningJobId === undefined).toBe(expected === 1)
  })

  it('keeps this process\'s run its own even when the host name it recorded has since changed', () => {
    const { store, taskId } = markedBoard({ ...currentRunOwner('s1'), host: 'the-name-before-a-network-change' })
    expect(store.reconcileRuns(judgeRunByProcess, tick())).toBe(0)
    expect(store.detail(taskId).task.runningJobId).toBe('task-1')
  })
})

describe('a running marker with no recorded owner', () => {
  const directories: string[] = []

  afterEach(() => {
    for (const created of directories.splice(0)) rmSync(created, { recursive: true, force: true })
  })

  /**
   * A file board with one card an older build marked running.
   * @returns the store, the card id, and the database path.
   */
  function legacyMarked(): { store: TaskStore; taskId: string; path: string } {
    const directory = mkdtempSync(join(tmpdir(), 'dsh-tasks-legacy-'))
    directories.push(directory)
    const path = join(directory, 'tasks.db')
    const store = new TaskStore(path, OPTIONS)
    open.push(store)
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    legacyStartRun(path, task.id, 'task-4', 's-old', tick())
    return { store, taskId: task.id, path }
  }

  it('is never swept: no process can tell whether the build that wrote it is still running it', () => {
    const { store, taskId } = legacyMarked()

    expect(store.reconcileRuns(judgeRunByProcess, tick())).toBe(0)

    const { task, activity } = store.detail(taskId)
    expect(task.runningJobId).toBe('task-4')
    expect(task.runOwnerUnknown).toBe(true)
    expect(activity.map(entry => entry.kind)).toEqual(['created', 'run-started'])
  })

  it('carries the dispatch the board recorded for it, so the job registry can be asked about it', () => {
    const { store, taskId } = legacyMarked()
    expect(store.runMarker(taskId)).toMatchObject({ jobId: 'task-4', owner: undefined, started: { sessionId: 's-old', at: clock } })
  })

  it('is cleared on an explicit request that names the marker', () => {
    const { store, taskId } = legacyMarked()

    const task = store.clearUnknownRun(taskId, 'task-4', { actor: 'user', sessionId: 's1' }, tick())

    expect(task.runningJobId).toBeUndefined()
    expect(task.runOwnerUnknown).toBeUndefined()
    expect(store.detail(taskId).activity.at(-1)).toMatchObject({ kind: 'run-finished', actor: 'user', from: 'task-4', to: 'interrupted' })
  })

  it('refuses a clear that names a different run, rather than clearing whatever holds the card now', () => {
    const { store, taskId } = legacyMarked()
    expect(() => store.clearUnknownRun(taskId, 'task-5', { actor: 'user' }, tick())).toThrow(TaskValidationError)
    expect(store.detail(taskId).task.runningJobId).toBe('task-4')
  })

  it('refuses to clear a run whose owner is recorded; that run is stopped, not forgotten', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    store.startRun(task.id, 'task-1', currentRunOwner('s1'), { actor: 'user' }, tick())
    expect(() => store.clearUnknownRun(task.id, 'task-1', { actor: 'user' }, tick())).toThrow(/stop/u)
    expect(store.detail(task.id).task.runningJobId).toBe('task-1')
  })

  it('treats a clear that arrives after the marker is already gone as done', () => {
    const { store, taskId } = legacyMarked()
    store.clearUnknownRun(taskId, 'task-4', { actor: 'user' }, tick())
    expect(store.clearUnknownRun(taskId, 'task-4', { actor: 'user' }, tick()).runningJobId).toBeUndefined()
  })
})

describe('revision', () => {
  it('advances on every write and stands still on a read', () => {
    const store = board()
    expect(store.revision()).toBe(0)
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    expect(store.revision()).toBe(1)
    store.update(task.id, { title: 'renamed' }, { actor: 'user' }, tick())
    expect(store.revision()).toBe(2)
    store.read()
    store.detail(task.id)
    expect(store.revision()).toBe(2)
  })

  it('moves when another connection edits the file, as `sqlite3` would', () => {
    const directory = mkdtempSync(join(tmpdir(), 'dsh-tasks-revision-'))
    const path = join(directory, 'tasks.db')
    const store = new TaskStore(path, OPTIONS)
    const outside = new DatabaseSync(path)
    try {
      const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
      const before = store.revision()

      outside.prepare("UPDATE tasks SET status = 'done' WHERE id = ?").run(task.id)
      const afterEdit = store.revision()
      expect(afterEdit).not.toBe(before)

      outside.prepare('INSERT INTO comments (id, task_id, body, author, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)')
        .run('c_0000000000000000000001', task.id, 'by hand', 'user', 1, 1)
      expect(store.revision()).not.toBe(afterEdit)
      expect(store.detail(task.id).task.status).toBe('done')
    } finally {
      outside.close()
      store.close()
      rmSync(directory, { recursive: true, force: true })
    }
  })
})

describe('optimistic concurrency', () => {
  it('refuses an edit made against a card someone else has changed since', () => {
    const store = board()
    const task = store.create({ title: 'original' }, { actor: 'user' }, tick())
    store.update(task.id, { title: 'changed by the agent' }, { actor: 'agent' }, tick())

    expect(() => store.update(task.id, { title: 'my edit' }, { actor: 'user' }, tick(), task.updatedAt))
      .toThrow(TaskConflictError)
    expect(store.detail(task.id).task.title).toBe('changed by the agent')
  })

  it('applies an edit whose expected stamp is current', () => {
    const store = board()
    const task = store.create({ title: 'original' }, { actor: 'user' }, tick())
    expect(store.update(task.id, { title: 'mine' }, { actor: 'user' }, tick(), task.updatedAt).title).toBe('mine')
  })
})

describe('createMany', () => {
  it('keeps the given order with top placement', () => {
    const store = board({ newTaskPlacement: 'top' })
    store.create({ title: 'already there' }, { actor: 'user' }, tick())
    store.createMany([{ title: 'a' }, { title: 'b' }, { title: 'c' }], { actor: 'agent' }, tick())
    expect(store.read().tasks.map(task => task.title)).toEqual(['a', 'b', 'c', 'already there'])
  })

  it('keeps the given order with bottom placement, per column', () => {
    const store = board({ newTaskPlacement: 'bottom' })
    store.create({ title: 'already there' }, { actor: 'user' }, tick())
    store.createMany(
      [{ title: 'a' }, { title: 'x', status: 'todo' }, { title: 'b' }, { title: 'y', status: 'todo' }],
      { actor: 'agent' },
      tick(),
    )
    expect(store.read().tasks.map(task => task.title)).toEqual(['already there', 'a', 'b', 'x', 'y'])
  })

  it('writes nothing when any card in the batch is invalid', () => {
    const store = board()
    expect(() => store.createMany([{ title: 'fine' }, { title: '   ' }], { actor: 'agent' }, tick()))
      .toThrow(TaskValidationError)
    expect(store.read().tasks).toEqual([])
    expect(store.revision()).toBe(0)
  })
})

describe('commentCounts', () => {
  it('counts every requested card\'s comments in one read', () => {
    const store = board()
    const a = store.create({ title: 'a' }, { actor: 'user' }, tick())
    const b = store.create({ title: 'b' }, { actor: 'user' }, tick())
    const c = store.create({ title: 'c' }, { actor: 'user' }, tick())
    store.addComment(a.id, 'one', { actor: 'user' }, tick())
    store.addComment(a.id, 'two', { actor: 'user' }, tick())
    store.addComment(b.id, 'three', { actor: 'user' }, tick())

    const counts = store.commentCounts([a.id, b.id, c.id])
    expect(counts.get(a.id)).toBe(2)
    expect(counts.get(b.id)).toBe(1)
    expect(counts.get(c.id)).toBeUndefined()
    expect(store.commentCounts([]).size).toBe(0)
  })
})

describe('outstanding', () => {
  it('orders the model-facing digest by urgency, then by activity', () => {
    const store = board()
    store.create({ title: 'someday', status: 'backlog', priority: 'low' }, { actor: 'user' }, tick())
    store.create({ title: 'finished', status: 'done', priority: 'urgent' }, { actor: 'user' }, tick())
    store.create({ title: 'blocking', status: 'blocked', priority: 'urgent' }, { actor: 'user' }, tick())
    store.create({ title: 'doing', status: 'in_progress', priority: 'urgent' }, { actor: 'user' }, tick())

    expect(store.outstanding(10).map(task => task.title)).toEqual(['doing', 'blocking', 'someday'])
  })

  it('leaves archived cards out', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    store.setArchived(task.id, true, { actor: 'user' }, tick())
    expect(store.outstanding(10)).toHaveLength(0)
  })
})

describe('byRef', () => {
  it('resolves the display number a person or model would quote', () => {
    const store = board()
    const task = store.create({ title: 'card' }, { actor: 'user' }, tick())
    expect(store.byRef(task.ref)?.id).toBe(task.id)
    expect(store.byRef(999)).toBeUndefined()
  })
})
