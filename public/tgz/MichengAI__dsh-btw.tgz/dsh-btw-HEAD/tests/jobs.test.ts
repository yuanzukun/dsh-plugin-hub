import { afterEach, describe, expect, it, vi } from 'vitest'
import { sanitizeModelAnswer, SideJobs, type ChildRun, type StartChild } from '../src/server/jobs'

function deferred<T>() {
  let resolve!: (value: T) => void
  let reject!: (reason: unknown) => void
  const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no })
  return { promise, resolve, reject }
}
const answer = { stopReason: 'completed', output: [{ type: 'text', text: '答案' }] }
const tick = () => new Promise<void>(resolve => setImmediate(resolve))
afterEach(() => { vi.useRealTimers() })

describe('一次性旁问生命周期', () => {
  it.each(['zh', 'en'] as const)('关闭失败返回本地化提示，原始错误记日志且保留额度（%s）', async locale => {
    const dispose = vi.fn().mockRejectedValue(new Error('provider internal failure'))
    const onError = vi.fn()
    const jobs = new SideJobs(async () => ({ result: Promise.resolve(answer), dispose }), 90_000, { onError })
    expect((await jobs.ask('A', 'request01', '问题', undefined, undefined, locale)).kind).toBe('success')
    onError.mockClear()
    expect(await jobs.close('A', 'request01')).toEqual({ kind: 'error', text: locale === 'zh'
      ? '资源清理失败，请再次关闭重试。'
      : 'Cleanup failed. Close again to retry.' })
    expect(onError).toHaveBeenCalledWith(expect.objectContaining({ message: expect.stringContaining('provider internal failure') }))
    expect(jobs.size).toBe(1)
    dispose.mockResolvedValue(undefined)
    expect((await jobs.close('A', 'request01')).kind).toBe('success')
    expect(jobs.size).toBe(0)
  })

  it('默认 30 分钟兜底超时保护并发配额，允许长时间思考直到完成', async () => {
    vi.useFakeTimers()
    const pending = deferred<typeof answer>()
    const dispose = vi.fn(async () => {})
    const jobs = new SideJobs(async () => ({ result: pending.promise, dispose }))
    const task = jobs.ask('parent', 'request01', '深度思考题')
    // 超过旧的 90s (例如推进 10 分钟 600s)，依然正常思考不中断
    await vi.advanceTimersByTimeAsync(600_000)
    expect(jobs.size).toBe(1)
    pending.resolve(answer)
    await vi.advanceTimersByTimeAsync(0)
    expect(await task).toEqual({ kind: 'success', text: '答案' })
    expect(jobs.size).toBe(0)
  })

  it('超过 30 分钟兜底看门狗后主动取消，防止极端假死占满名额', async () => {
    vi.useFakeTimers()
    const pending = deferred<typeof answer>()
    const dispose = vi.fn(async () => {})
    const jobs = new SideJobs(async () => ({ result: pending.promise, dispose }))
    const task = jobs.ask('parent', 'request01', '假死题')
    // 推进超过 30 分钟 (1800s + 1s)
    await vi.advanceTimersByTimeAsync(1_800_001)
    expect((await task).kind).toBe('error')
    expect(jobs.size).toBe(0)
  })

  it('正常完成后释放子代理', async () => {
    const dispose = vi.fn(async () => {})
    const start = vi.fn<StartChild>(async () => ({ result: Promise.resolve(answer), dispose }))
    const jobs = new SideJobs(start)
    expect(await jobs.ask('parent', 'request01', '为什么？')).toEqual({ kind: 'success', text: '答案' })
    expect(dispose).toHaveBeenCalledTimes(1)
    expect(jobs.size).toBe(0)
  })

  it('关闭等待迟到的启动结果并清理，答案不再返回', async () => {
    const starting = deferred<ChildRun>()
    const start = vi.fn<StartChild>(() => starting.promise)
    const dispose = vi.fn(async () => {})
    const jobs = new SideJobs(start)
    const task = jobs.ask('parent', 'request01', '为什么？')
    const closing = jobs.close('parent', 'request01')
    starting.resolve({ result: Promise.resolve(answer), dispose })
    expect((await task).kind).toBe('error')
    expect(await closing).toEqual({ kind: 'success', text: '' })
    expect(dispose).toHaveBeenCalledTimes(1)
  })

  it('取消不依赖模型响应；取消对应请求，不影响另一请求', async () => {
    const pending = deferred<typeof answer>()
    const dispose = vi.fn(async () => {})
    const jobs = new SideJobs(async () => ({ result: pending.promise, dispose }))
    const first = jobs.ask('parent', 'request01', 'A')
    const second = jobs.ask('other', 'request02', 'B')
    await tick()
    await jobs.close('parent', 'request01')
    expect((await first).kind).toBe('error')
    expect(jobs.size).toBe(1)
    pending.resolve(answer)
    expect((await second).kind).toBe('success')
    expect(dispose).toHaveBeenCalledTimes(2)
  })

  it('关闭先于运行到达时不再启动子代理', async () => {
    const start = vi.fn<StartChild>()
    const jobs = new SideJobs(start)
    await jobs.close('parent', 'request01')
    expect((await jobs.ask('parent', 'request01', 'A')).kind).toBe('error')
    expect(start).not.toHaveBeenCalled()
  })

  it('会话隔离，不能关闭另一会话的请求', async () => {
    const pending = deferred<typeof answer>()
    const jobs = new SideJobs(async () => ({ result: pending.promise, dispose: async () => {} }))
    const task = jobs.ask('parent', 'request01', 'A')
    await jobs.close('other', 'request01')
    expect(jobs.size).toBe(1)
    pending.resolve(answer)
    expect((await task).kind).toBe('success')
  })

  it('清理失败可重试，不能显示成功关闭', async () => {
    const dispose = vi.fn().mockRejectedValueOnce(new Error('清理失败')).mockResolvedValue(undefined)
    const onError = vi.fn()
    const jobs = new SideJobs(async () => ({ result: Promise.resolve(answer), dispose }), 90_000, { onError })
    expect(await jobs.ask('parent', 'request01', 'A')).toEqual({ kind: 'success', text: '答案' })
    expect(onError).toHaveBeenCalledWith(expect.objectContaining({ message: expect.stringContaining('清理失败') }))
    expect(jobs.size).toBe(1)
    expect((await jobs.close('parent', 'request01')).kind).toBe('success')
    expect(jobs.size).toBe(0)
  })

  it('拒绝重复请求，避免多次启动与重复费用', async () => {
    const pending = deferred<typeof answer>()
    const start = vi.fn<StartChild>(async () => ({ result: pending.promise, dispose: async () => {} }))
    const jobs = new SideJobs(start)
    const task = jobs.ask('parent', 'request01', 'A')
    expect((await jobs.ask('parent', 'request01', 'A')).kind).toBe('error')
    pending.resolve(answer)
    await task
    expect(start).toHaveBeenCalledTimes(1)
  })

  it('启动超时及时返回，迟到的子代理仍清理且不提前释放额度', async () => {
    vi.useFakeTimers()
    const starting = deferred<ChildRun>()
    const dispose = vi.fn(async () => {})
    const jobs = new SideJobs(() => starting.promise, 5, { cleanupTimeoutMs: 10, onError: vi.fn() })
    const task = jobs.ask('parent', 'request01', 'A')
    const result = vi.fn()
    void task.then(result)
    await vi.advanceTimersByTimeAsync(6)
    expect(result).toHaveBeenCalledWith({ kind: 'error', text: '旁问超时，已取消。' })
    expect(jobs.size).toBe(1)
    const closing = jobs.close('parent', 'request01')
    await vi.advanceTimersByTimeAsync(11)
    expect((await closing).kind).toBe('error')
    starting.resolve({ result: Promise.reject(new Error('迟到的失败')), dispose })
    await vi.advanceTimersByTimeAsync(0)
    expect(dispose).toHaveBeenCalledTimes(1)
    expect(jobs.size).toBe(0)
    expect((await task).kind).toBe('error')
  })

  it('启动取消后迟到的拒绝释放额度，不产生未处理异常', async () => {
    vi.useFakeTimers()
    const starting = deferred<ChildRun>()
    const jobs = new SideJobs(() => starting.promise, 5, { cleanupTimeoutMs: 10, onError: vi.fn() })
    const task = jobs.ask('parent', 'request01', 'A')
    await vi.advanceTimersByTimeAsync(6)
    expect((await task).kind).toBe('error')
    starting.reject(new Error('启动失败'))
    await vi.advanceTimersByTimeAsync(0)
    expect(jobs.size).toBe(0)
  })

  it('清理挂起不吞答案，关闭有界且重复关闭不并行重入清理', async () => {
    vi.useFakeTimers()
    const cleanup = deferred<void>()
    const dispose = vi.fn(() => cleanup.promise)
    const jobs = new SideJobs(async () => ({ result: Promise.resolve(answer), dispose }), 90_000, { cleanupTimeoutMs: 10, onError: vi.fn() })
    const task = jobs.ask('parent', 'request01', 'A')
    const result = vi.fn()
    void task.then(result)
    await vi.advanceTimersByTimeAsync(11)
    expect(result).toHaveBeenCalledWith({ kind: 'success', text: '答案' })
    expect(jobs.size).toBe(1)
    const closing = jobs.close('parent', 'request01')
    const again = jobs.close('parent', 'request01')
    await vi.advanceTimersByTimeAsync(11)
    expect((await closing).kind).toBe('error')
    expect((await again).kind).toBe('error')
    expect(dispose).toHaveBeenCalledTimes(1)
    cleanup.resolve()
    await vi.advanceTimersByTimeAsync(0)
    expect(jobs.size).toBe(0)
    expect((await jobs.close('parent', 'request01')).kind).toBe('success')
  })

  it('卸载清理拒绝不抛出，重试完成后才通知保护可释放', async () => {
    const dispose = vi.fn().mockRejectedValue(new Error('清理失败'))
    const onIdle = vi.fn()
    const onError = vi.fn()
    const jobs = new SideJobs(async () => ({ result: Promise.resolve(answer), dispose }), 90_000, { onIdle, onError })
    await jobs.ask('parent', 'request01', 'A')
    await expect(jobs.dispose()).resolves.toBeUndefined()
    expect(jobs.size).toBe(1)
    expect(onIdle).not.toHaveBeenCalled()
    expect((await jobs.ask('parent', 'request02', 'B')).kind).toBe('error')
    dispose.mockResolvedValue(undefined)
    await jobs.dispose()
    await jobs.dispose()
    expect(jobs.size).toBe(0)
    expect(onIdle).toHaveBeenCalledTimes(1)
    expect(onError).toHaveBeenCalled()
  })

  it('卸载不等待永久挂起的启动，迟到子代理完成清理后通知空闲', async () => {
    vi.useFakeTimers()
    const starting = deferred<ChildRun>()
    const onIdle = vi.fn()
    const dispose = vi.fn(async () => {})
    const jobs = new SideJobs(() => starting.promise, 90_000, { cleanupTimeoutMs: 10, onIdle, onError: vi.fn() })
    const task = jobs.ask('parent', 'request01', 'A')
    const unloaded = vi.fn()
    void jobs.dispose().then(unloaded)
    await vi.advanceTimersByTimeAsync(11)
    expect(unloaded).toHaveBeenCalledTimes(1)
    expect(onIdle).not.toHaveBeenCalled()
    expect((await task).kind).toBe('error')
    starting.resolve({ result: Promise.resolve(answer), dispose })
    await vi.advanceTimersByTimeAsync(0)
    expect(dispose).toHaveBeenCalledTimes(1)
    expect(onIdle).toHaveBeenCalledTimes(1)
  })

  it('全局八路额度包含超时但尚未清理的启动', async () => {
    vi.useFakeTimers()
    const starts = Array.from({ length: 8 }, () => deferred<ChildRun>())
    let next = 0
    const start = vi.fn<StartChild>(() => starts[next++]!.promise)
    const jobs = new SideJobs(start, 5, { cleanupTimeoutMs: 10, onError: vi.fn() })
    const tasks = starts.map((_, index) => jobs.ask(`session-${index}`, 'request01', 'A'))
    await vi.advanceTimersByTimeAsync(6)
    expect((await jobs.ask('new-session', 'request02', 'B')).text).toContain('较多')
    expect(start).toHaveBeenCalledTimes(8)
    for (const pending of starts) pending.resolve({ result: Promise.resolve(answer), dispose: async () => {} })
    await vi.advanceTimersByTimeAsync(0)
    await Promise.all(tasks)
    expect(jobs.size).toBe(0)
  })

  it('清洗模型因上下文惯性残留的 <tool_call> 与 <function_call> 标签伪代码', () => {
    expect(sanitizeModelAnswer('这是正常回答')).toBe('这是正常回答')
    expect(sanitizeModelAnswer('这是前文<tool_call>\n{"name":"read_file"}\n</tool_call>这是后文')).toBe('这是前文这是后文')
    expect(sanitizeModelAnswer('<function_call>{"test": 1}</function_call>\n解释如下：OK')).toBe('解释如下：OK')
    expect(sanitizeModelAnswer('```tool_call\n{"action": "test"}\n```\n结论是正确的')).toBe('结论是正确的')
    expect(sanitizeModelAnswer('<tool_call>\n{"name": "fail"}\n</tool_call>')).toBe('')
  })

  it('调用方连接 signal 中断不终止后台任务，子代理继续推进至完成并支持 query 查回答案', async () => {
    const pending = deferred<typeof answer>()
    const dispose = vi.fn(async () => {})
    const jobs = new SideJobs(async () => ({ result: pending.promise, dispose }))
    const controller = new AbortController()
    const task = jobs.ask('parent', 'request-resumable-1', '长耗时问题', controller.signal)

    // 模拟 HTTP 连接在 300s 断开（signal.abort）
    controller.abort(new Error('This operation was aborted'))
    const outcome = await task
    // 调用方本次 ask 被中断
    expect(outcome.kind).toBe('error')

    // 但后台子代理没有被杀死！jobs.query 显示 running
    expect(jobs.query('parent', 'request-resumable-1')).toEqual({ state: 'running' })
    expect(dispose).not.toHaveBeenCalled()

    // 随后模型完成作答
    pending.resolve(answer)
    await tick()

    // 状态转为 done，答案被安全缓存，dispose 被正常释放
    expect(jobs.query('parent', 'request-resumable-1')).toEqual({
      state: 'done',
      result: { kind: 'success', text: '答案' },
    })
    expect(dispose).toHaveBeenCalledTimes(1)
  })

  it('close 既能中止运行中任务，也能清理已完成结果缓存与墓碑防重入', async () => {
    const dispose = vi.fn(async () => {})
    const jobs = new SideJobs(async () => ({ result: Promise.resolve(answer), dispose }))
    await jobs.ask('parent', 'request-clean-1', '测试')
    expect(jobs.query('parent', 'request-clean-1')).toEqual({
      state: 'done',
      result: { kind: 'success', text: '答案' },
    })

    // 主动关闭清理缓存
    await jobs.close('parent', 'request-clean-1')
    expect(jobs.query('parent', 'request-clean-1')).toEqual({ state: 'not-found' })
  })

  it('传入已中断的 signal 时立即早退返回取消，不启动子代理且不分配任务额度', async () => {
    const start = vi.fn()
    const jobs = new SideJobs(start)
    const controller = new AbortController()
    controller.abort(new Error('提前中断'))
    const outcome = await jobs.ask('parent', 'req-pre-aborted', '问题', controller.signal)
    expect(outcome.kind).toBe('error')
    expect(outcome.text).toContain('取消')
    expect(start).not.toHaveBeenCalled()
    expect(jobs.size).toBe(0)
  })

  it('completed 结果超过字符预算或容量时，从最旧条目开始淘汰，保留最新条目', async () => {
    const jobs = new SideJobs(async req => ({
      result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: req.question }] } as any),
      dispose: async () => {},
    }))

    // 产生一个 1.5MB 的旧结果
    const bigText1 = 'A'.repeat(1_500_000)
    await jobs.ask('parent', 'req-1', bigText1)
    expect(jobs.query('parent', 'req-1').state).toBe('done')

    // 产生第二个 1MB 的新结果，两者相加 2.5MB > 2MB 预算
    const bigText2 = 'B'.repeat(1_000_000)
    await jobs.ask('parent', 'req-2', bigText2)

    // 最旧的 req-1 应该被淘汰，最新的 req-2 依然保留
    expect(jobs.query('parent', 'req-1').state).toBe('not-found')
    expect(jobs.query('parent', 'req-2').state).toBe('done')
  })
})
