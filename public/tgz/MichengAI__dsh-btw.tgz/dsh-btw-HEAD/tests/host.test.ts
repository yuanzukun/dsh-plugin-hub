import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { Context as ContextType } from '@deepseek-ai/cordis'
import type { ToolRuntime as RuntimeType } from '@deepseek-ai/dsh-tools'
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { CommandDefinition } from '@deepseek-ai/dsh-commands'
import { apply } from '../src/index'
import { QUERY_COMMAND, RUN_COMMAND } from '../src/shared'
import { translate } from '../src/locales'
import { SIDE_MAX_OUTPUT_TOKENS } from '../src/limits'
import { createAnswerOnlyGuard } from '../src/server/tool-guard'

// 默认验证锁文件中的宿主版本；允许显式指定旧版依赖图做兼容回归。
const runtimeRoot = process.env.DSH_RUNTIME_ROOT ?? fileURLToPath(new URL('../node_modules', import.meta.url))
const modulePath = (name: string) => pathToFileURL(join(runtimeRoot, '@deepseek-ai', name, 'lib', 'index.js')).href
const runtimeVersion = JSON.parse(readFileSync(join(runtimeRoot, '@deepseek-ai', 'dsh-tools', 'package.json'), 'utf8')).version
afterEach(() => { vi.useRealTimers() })

describe(`DSH ${runtimeVersion} 真实运行时`, () => {
  const load = async () => {
    const { Context } = await import(/* @vite-ignore */ modulePath('cordis')) as { Context: typeof ContextType }
    const { ToolRuntime } = await import(/* @vite-ignore */ modulePath('dsh-tools')) as { ToolRuntime: typeof RuntimeType }
    const { createScope } = await import(/* @vite-ignore */ modulePath('dsh-scope')) as {
      createScope(ctx: ContextType, key: object): { ctx: ContextType; dispose(): Promise<void> }
    }
    return { Context, ToolRuntime, createScope }
  }

  const setupTools = async (ctx: any, ToolRuntime: any) => {
    if (!ctx.tools) new ToolRuntime(ctx)
    if (typeof ctx.tools?.setExecutor === 'function') {
      const pipelinePath = pathToFileURL(join(runtimeRoot, '@deepseek-ai', 'dsh-tools', 'lib', 'pipeline.js')).href
      const toolsPath = pathToFileURL(join(runtimeRoot, '@deepseek-ai', 'dsh-tools', 'lib', 'index.js')).href
      const { ToolExecutionPipeline, executeToolBatch } = await import(/* @vite-ignore */ pipelinePath)
      const { projectToolSchema } = await import(/* @vite-ignore */ toolsPath) as { projectToolSchema: (d: any, f: boolean) => any }
      const pipeline = new ToolExecutionPipeline(ctx)
      ctx.tools.setExecutor({
        describe: (tools: any[]) => ({ schemas: tools.map(t => projectToolSchema(t, false)) }),
        execute: async (input: any) => {
          const isSingleCall = !input.calls && input.name
          const batchInput = isSingleCall
            ? { ...input, calls: [{ id: input.callId, name: input.name, arguments: JSON.stringify(input.arguments ?? {}) }] }
            : input
          const outcome = await executeToolBatch(batchInput, pipeline, () => 10)
          return isSingleCall ? (outcome.results[0]?.result ?? outcome) : outcome
        },
      })
    }
  }

  it('根 fiber 拒绝 effect 时仍能激活并注册 btw', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })
    ctx.provide('subagents', { getProvider: () => undefined })
    const fiber = ctx.root.fiber as { effect(execute: () => unknown, label?: string): unknown }
    const rootEffect = fiber.effect.bind(ctx.root.fiber)
    fiber.effect = (execute, label) => {
      if (label === 'tools.guard()') throw new Error('dsh-tui: root.effect is unavailable from a plugin activation')
      return rootEffect(execute, label)
    }
    const plugin = ctx.plugin(apply)
    try {
      await plugin.await()
    } catch (error) {
      throw new Error(error instanceof Error ? error.message : String(error))
    }
    expect(commands.has('btw')).toBe(true)
    await plugin.dispose()
    await ctx.fiber.dispose()
  })

  it('空白名单之外的自有工具与 run_code 也被拒绝，主任务工具可执行', async () => {
    const { Context, ToolRuntime, createScope } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const body = vi.fn(async () => 'executed')
    ctx.tools.register({ name: 'normal', description: '测试工具', parameters: { type: 'object', properties: {} }, output: { schema: { type: 'string' }, render: value => [{ type: 'text', text: String(value) }] }, execute: body })
    const protection = createAnswerOnlyGuard(new Set(['owned']))
    ctx.tools.guard(protection)
    // alpha.2+ 移除 presentAs('both')：native 覆盖子作用域自有工具；ptc 覆盖宿主 run_code。
    const childNative = { session: {} } as unknown as Agent
    const scopeNative = createScope(ctx, childNative)
    scopeNative.ctx.tools.register({ name: 'child_local', description: '子作用域工具', parameters: { type: 'object', properties: {} }, output: { schema: { type: 'string' }, render: value => [{ type: 'text', text: String(value) }] }, execute: body })
    if (typeof (scopeNative.ctx.tools as any).presentAs === 'function') {
      (scopeNative.ctx.tools as any).presentAs('native')
    } else {
      await setupTools(scopeNative.ctx, ToolRuntime)
    }
    protection.own(childNative)
    expect(ctx.tools.get('normal', childNative)).toBeDefined()
    expect(ctx.tools.get('child_local', childNative)).toBeDefined()
    const blockedLocal = await (ctx.tools as any).execute({ name: 'child_local', callId: 'test-local' as never, arguments: {}, agent: childNative, signal: new AbortController().signal })
    expect(blockedLocal.isError).toBe(true)
    expect(JSON.stringify(blockedLocal.content)).toContain('BTW 仅允许文字回答，禁止执行任何工具。')

    const childPtc = { session: {} } as unknown as Agent
    const scopePtc = createScope(ctx, childPtc)
    if (typeof (scopePtc.ctx.tools as any).presentAs === 'function') {
      (scopePtc.ctx.tools as any).presentAs('ptc')
      protection.own(childPtc)
      expect(ctx.tools.get('run_code', childPtc)).toBeDefined()
      const blockedRun = await (ctx.tools as any).execute({ name: 'run_code', callId: 'test-run' as never, arguments: { description: 'x', code: '1' }, agent: childPtc, signal: new AbortController().signal })
      expect(blockedRun.isError).toBe(true)
      expect(JSON.stringify(blockedRun.content)).toContain('BTW 仅允许文字回答，禁止执行任何工具。')
      expect(body).not.toHaveBeenCalled()
    }

    // 唯一放行：发回自己父会话的 send_message（不是新注册的工具，保持 tool 列表不变）。
    const sendBody = vi.fn(async () => 'sent')
    ctx.tools.register({ name: 'send_message', description: '发消息给另一个 agent', parameters: { type: 'object', properties: { agent_id: { type: 'string' }, message: { type: 'string' } }, required: ['agent_id', 'message'] }, output: { schema: { type: 'string' }, render: value => [{ type: 'text', text: String(value) }] }, execute: sendBody })
    const childReply = { session: { header: { id: 'btw-child', parentSession: 'parent-session' } } } as unknown as Agent
    protection.own(childReply)
    const reply = await (ctx.tools as any).execute({ name: 'send_message', callId: 'test-reply' as never, arguments: { agent_id: 'parent-session', message: '回答' }, agent: childReply, signal: new AbortController().signal })
    expect(reply.isError).not.toBe(true)
    expect(sendBody).toHaveBeenCalledOnce()

    // 同一个 send_message 发给别的 agent 仍然被拒。
    const misrouted = await (ctx.tools as any).execute({ name: 'send_message', callId: 'test-misroute' as never, arguments: { agent_id: 'someone-else', message: '回答' }, agent: childReply, signal: new AbortController().signal })
    expect(misrouted.isError).toBe(true)
    expect(JSON.stringify(misrouted.content)).toContain('BTW 仅允许文字回答，禁止执行任何工具。')
    expect(sendBody).toHaveBeenCalledOnce()

    const result = await (ctx.tools as any).execute({ name: 'normal', callId: 'main' as never, arguments: {}, signal: new AbortController().signal })
    expect(result.isError).not.toBe(true)
    expect(body).toHaveBeenCalledOnce()
    await scopeNative.dispose()
    await scopePtc.dispose()
    await ctx.fiber.dispose()
  })

  it('根上下文 session/event 能认领尚未返回 localAgent 的子代理', async () => {
    const { Context, ToolRuntime, createScope } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })
    const child = { session: { snapshotEvents: () => { throw new Error('生产路径不应再读 snapshotEvents') } } } as unknown as Agent
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { toolFilter: true, persona: true } }),
      start: async (_provider: string, options: { label: string }) => {
        ctx.emit('session/event', child.session as never, { type: 'subagent/descriptor', data: { label: options.label } } as never)
        return { result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: 'ok' }] }), dispose: async () => {} }
      },
    })
    const plugin = ctx.plugin(apply)
    await plugin.await()
    const scope = createScope(ctx, child)
    const body = vi.fn(async () => 'executed')
    scope.ctx.tools.register({ name: 'child_local', description: '子作用域工具', parameters: { type: 'object', properties: {} }, output: { schema: { type: 'string' }, render: value => [{ type: 'text', text: String(value) }] }, execute: body })
    await commands.get(RUN_COMMAND)!.handler({ agent: { session: { header: { id: 'main' } } }, rawInput: JSON.stringify({ id: 'request-evt', question: '问题' }), signal: new AbortController().signal } as never)
    const blocked = await (ctx.tools as any).execute({ name: 'child_local', callId: 'event' as never, arguments: {}, agent: child, signal: new AbortController().signal })
    expect(blocked.isError).toBe(true)
    expect(body).not.toHaveBeenCalled()
    await plugin.dispose()
    await scope.dispose()
    await ctx.fiber.dispose()
  })

  it('startActivation 路径收紧旁问输出预算，取 min 避免抬高小预算路由', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })
    const dispose = vi.fn(async () => {})
    const startActivation = vi.fn(async (_spec: {
      provider: string
      request: { parent: unknown; agentOptions?: { maxTokens?: number }; prompt: readonly { type: string; text: string }[] }
    }) => ({
      result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: '旁问答案' }] }),
      dispose,
    }))
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true, agentPreset: false, outputSchema: true, depthLimit: true } }),
      startActivation,
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()
    // 1. 父任务为小预算路由 (4096) 时，不能抬高到 32000
    const outcome1 = await commands.get(RUN_COMMAND)!.handler({
      agent: { session: { header: { id: 'main' } }, options: { maxTokens: 4096 } },
      rawInput: JSON.stringify({ id: 'small-budget-req', question: '小预算' }),
      signal: new AbortController().signal,
    } as never)
    expect(outcome1).toEqual({ kind: 'success', text: '旁问答案' })
    const spec0 = startActivation.mock.calls[0]![0]
    expect(spec0.provider).toBe('fork')
    expect(spec0.request.parent).toBeDefined()
    expect(spec0.request.prompt).toEqual([{ type: 'text', text: expect.stringContaining('小预算') }])
    expect(spec0.request.agentOptions).toEqual({ maxTokens: 4096 })

    // 2. 父任务为大上下文 (256000) 时，收紧到 32000
    await commands.get(RUN_COMMAND)!.handler({
      agent: { session: { header: { id: 'main' } }, options: { maxTokens: 256_000 } },
      rawInput: JSON.stringify({ id: 'large-budget-req', question: '大预算' }),
      signal: new AbortController().signal,
    } as never)
    expect(startActivation.mock.calls[1]![0].request.agentOptions).toEqual({ maxTokens: SIDE_MAX_OUTPUT_TOKENS })

    // 3. 父任务未显式配置 maxTokens 时，缺省使用 32000
    await commands.get(RUN_COMMAND)!.handler({
      agent: { session: { header: { id: 'main' } } },
      rawInput: JSON.stringify({ id: 'default-budget-req', question: '缺省预算' }),
      signal: new AbortController().signal,
    } as never)
    expect(startActivation.mock.calls[2]![0].request.agentOptions).toEqual({ maxTokens: SIDE_MAX_OUTPUT_TOKENS })

    await plugin.dispose()
    await ctx.fiber.dispose()
  })

  it('subagents.start 不改系统提示与工具定义，并传递 agentOptions 预算限制', async () => {
    const { Context, ToolRuntime, createScope } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })

    const child = { session: {} } as Agent & { ctx?: ContextType }
    let scope: { ctx: ContextType; dispose(): Promise<void> }
    const dispose = vi.fn(async () => {})
    const startLegacy = vi.fn(async (_provider: string, options: {
      parent: Agent
      label: string
      agentOptions?: { maxTokens?: number }
      toolFilter?: unknown
      persona?: unknown
      prompt: readonly { type: string; text: string }[]
    }) => {
      scope = createScope(ctx, child)
      child.ctx = scope.ctx
      // persona / toolFilter 会改写请求前缀，使旁问无法复用主会话的 prompt cache
      expect(options.toolFilter).toBeUndefined()
      expect(options.persona).toBeUndefined()
      expect(options.agentOptions).toEqual({ maxTokens: 4096 })
      return { result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: 'start 回退答案' }] }), localAgent: child, dispose }
    })

    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { toolFilter: true, persona: true, agentOptions: true } }),
      start: startLegacy,
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()

    const outcome = await commands.get(RUN_COMMAND)!.handler({
      agent: { session: { header: { id: 'main' } }, options: { maxTokens: 4096 } },
      rawInput: JSON.stringify({ id: 'legacy-req', question: '旧版问题' }),
      signal: new AbortController().signal,
    } as never)

    expect(outcome).toEqual({ kind: 'success', text: 'start 回退答案' })
    expect(startLegacy).toHaveBeenCalledOnce()
    expect(dispose).toHaveBeenCalledOnce() // 正常完成在 SideJobs execute 结束时调用 cleanup 释放

    // start 回退返回的 localAgent 也要纳入工具拦截
    const currentScope = scope!
    currentScope.ctx.tools.register({ name: 'legacy_tool', description: '测试工具', parameters: { type: 'object', properties: {} }, output: { schema: { type: 'string' }, render: v => [{ type: 'text', text: String(v) }] }, execute: vi.fn() })
    const blocked = await (ctx.tools as any).execute({ name: 'legacy_tool', callId: 'test-call' as never, arguments: {}, agent: child, signal: new AbortController().signal })
    expect(blocked.isError).toBe(true)
    expect(JSON.stringify(blocked.content)).toContain('BTW 仅允许文字回答，禁止执行任何工具。')

    await plugin.dispose()
    if (scope!) await scope.dispose()
    await ctx.fiber.dispose()
  })

  it('插件卸载期间保护持续到子代理清理完成', async () => {
    const { Context } = await load()
    const ctx = new Context()
    const commands = new Map<string, CommandDefinition>()
    let protectedNow = false
    let finishCleanup!: () => void
    let cleanupStarted = false
    ctx.provide('tools', { guard: () => ctx.effect(() => { protectedNow = true; return () => { protectedNow = false } }) })
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true, agentPreset: false, outputSchema: true, depthLimit: true } }),
      start: async () => ({ result: new Promise(() => {}), dispose: () => { cleanupStarted = true; return new Promise<void>(resolve => { finishCleanup = resolve }) } }),
    })
    const plugin = ctx.plugin(apply)
    await plugin.await()
    const answer = commands.get(RUN_COMMAND)!.handler({ agent: { session: { header: { id: 'main' } } }, rawInput: JSON.stringify({ id: 'request-123', question: '问题' }), signal: new AbortController().signal } as never)
    await Promise.resolve()
    const unload = plugin.dispose()
    await vi.waitFor(() => expect(cleanupStarted).toBe(true))
    expect(protectedNow).toBe(true)
    finishCleanup()
    await unload
    await answer
    expect(protectedNow).toBe(false)
    await ctx.fiber.dispose()
  })

  it('卸载清理挂起时按时退出，真实工具保护延续到迟到清理成功', async () => {
    const { Context, ToolRuntime, createScope } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })
    let finishCleanup!: () => void
    const cleanup = new Promise<void>(resolve => { finishCleanup = resolve })
    const dispose = vi.fn(() => cleanup)
    const child = { session: {} } as Agent & { ctx?: ContextType }
    let scope: { ctx: ContextType; dispose(): Promise<void> }
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true, agentPreset: false, outputSchema: true, depthLimit: true } }),
      start: async () => {
        scope = createScope(ctx, child)
        child.ctx = scope.ctx
        return { result: new Promise(() => {}), localAgent: child, dispose }
      },
    })
    const plugin = ctx.plugin(apply)
    await plugin.await()
    vi.useFakeTimers()
    const answer = commands.get(RUN_COMMAND)!.handler({ agent: { session: { header: { id: 'main' } } }, rawInput: JSON.stringify({ id: 'request-123', question: '问题' }), signal: new AbortController().signal } as never)
    await vi.advanceTimersByTimeAsync(0)
    const body = vi.fn(async () => 'executed')
    scope!.ctx.tools.register({ name: 'orphan_tool', description: '未释放子代理的工具', parameters: { type: 'object', properties: {} }, output: { schema: { type: 'string' }, render: value => [{ type: 'text', text: String(value) }] }, execute: body })
    const unload = plugin.dispose()
    const finished = vi.fn()
    void unload.then(finished)
    await vi.advanceTimersByTimeAsync(5_001)
    expect(finished).toHaveBeenCalledTimes(1)
    expect(commands.has(RUN_COMMAND)).toBe(false)
    expect((await answer)?.kind).toBe('error')
    expect(dispose).toHaveBeenCalledTimes(1)
    const blocked = await (ctx.tools as any).execute({ name: 'orphan_tool', callId: 'orphan' as never, arguments: {}, agent: child, signal: new AbortController().signal })
    expect(blocked.isError).toBe(true)
    expect(body).not.toHaveBeenCalled()
    finishCleanup()
    await vi.advanceTimersByTimeAsync(0)
    const released = await (ctx.tools as any).execute({ name: 'orphan_tool', callId: 'released' as never, arguments: {}, agent: child, signal: new AbortController().signal })
    expect(released.isError).not.toBe(true)
    expect(body).toHaveBeenCalledTimes(1)
    await scope!.dispose()
    await ctx.fiber.dispose()
  })

  it('卸载时启动仍挂起，迟到句柄被清理且注销保护', async () => {
    const { Context } = await load()
    const ctx = new Context()
    const commands = new Map<string, CommandDefinition>()
    let protectedNow = false
    let finishStart!: (run: { result: Promise<unknown>; localAgent?: object; dispose: () => Promise<void> }) => void
    ctx.provide('tools', { guard: () => ctx.effect(() => { protectedNow = true; return () => { protectedNow = false } }) })
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true, agentPreset: false, outputSchema: true, depthLimit: true } }),
      start: () => new Promise(resolve => { finishStart = resolve as typeof finishStart }),
    })
    const plugin = ctx.plugin(apply)
    await plugin.await()
    vi.useFakeTimers()
    const answer = commands.get(RUN_COMMAND)!.handler({ agent: { session: { header: { id: 'main' } } }, rawInput: JSON.stringify({ id: 'request-123', question: '问题' }), signal: new AbortController().signal } as never)
    const unload = plugin.dispose()
    await vi.advanceTimersByTimeAsync(5_001)
    await expect(unload).resolves.toBeUndefined()
    expect(protectedNow).toBe(true)
    const dispose = vi.fn(async () => {})
    finishStart({ result: new Promise(() => {}), dispose })
    await vi.advanceTimersByTimeAsync(0)
    expect(dispose).toHaveBeenCalledTimes(1)
    expect(protectedNow).toBe(false)
    expect((await answer)?.kind).toBe('error')
    await ctx.fiber.dispose()
  })

  it('Issue #21: 错过 agent/created 时凭预登记 childId 与快照回退确定性拦截工具', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })

    let capturedChildId: string | undefined
    let resolveRun!: (value: { stopReason: string; output: readonly { type: string; text?: string }[] }) => void
    const runPromise = new Promise<{ stopReason: string; output: readonly { type: string; text?: string }[] }>(resolve => { resolveRun = resolve })

    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true, outputSchema: true } }),
      startActivation: async (spec: { childId: string }) => {
        capturedChildId = spec.childId
        return {
          result: runPromise,
          dispose: async () => {},
        }
      },
    })

    const body = vi.fn(async () => 'should-not-run')
    ctx.tools.register({
      name: 'ops_bash',
      description: '执行命令',
      parameters: { type: 'object', properties: {} },
      output: { schema: { type: 'string' }, render: v => [{ type: 'text', text: String(v) }] },
      execute: body,
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()

    // 发起旁问任务（非阻塞挂起）
    const sideAsk = commands.get(RUN_COMMAND)!.handler({
      agent: { session: { header: { id: 'main' } } },
      rawInput: JSON.stringify({ id: 'issue-21-req', question: '测试命令拦截' }),
      signal: new AbortController().signal,
    } as never)

    // 等待 startActivation 被调用并记录分配的 childId
    await vi.waitFor(() => expect(capturedChildId).toBeDefined())

    // 1. 模拟子代理在 live 段尝试执行 ops_bash，由于预登记了 childId，凭 agent.id 立即单调拒绝
    const blockedById = await (ctx.tools as any).execute({
      name: 'ops_bash',
      callId: 'call-1' as never,
      arguments: {},
      agent: { id: capturedChildId } as never,
      signal: new AbortController().signal,
    })
    expect(blockedById.isError).toBe(true)
    expect(JSON.stringify(blockedById.content)).toContain('BTW 仅允许文字回答，禁止执行任何工具。')
    expect(body).not.toHaveBeenCalled()

    // 2. 模拟以 session.header.id 传入（包装 agent 场景），同样单调拒绝
    const blockedByHeader = await (ctx.tools as any).execute({
      name: 'ops_bash',
      callId: 'call-2' as never,
      arguments: {},
      agent: { session: { header: { id: capturedChildId } } } as never,
      signal: new AbortController().signal,
    })
    expect(blockedByHeader.isError).toBe(true)
    expect(JSON.stringify(blockedByHeader.content)).toContain('BTW 仅允许文字回答，禁止执行任何工具。')
    expect(body).not.toHaveBeenCalled()

    // 3. 无 id 可依（既不是预登记 id，也读不到投影）时，仍凭子会话快照里的 descriptor 标签拦截
    const blockedBySnapshot = await (ctx.tools as any).execute({
      name: 'ops_bash',
      callId: 'call-3' as never,
      arguments: {},
      agent: {
        session: {
          snapshotEvents: () => [{ type: 'subagent/descriptor', data: { version: 3, mode: 'continuable', provider: 'fork', label: translate()('agent.name') } }],
        },
      } as never,
      signal: new AbortController().signal,
    })
    expect(blockedBySnapshot.isError).toBe(true)
    expect(JSON.stringify(blockedBySnapshot.content)).toContain('BTW 仅允许文字回答，禁止执行任何工具。')
    expect(body).not.toHaveBeenCalled()

    // 结束旁问
    resolveRun({ stopReason: 'completed', output: [{ type: 'text', text: '完成回答' }] })
    await sideAsk

    // 任务结束后预登记 id 必须释放，避免残留 id 长期拦截已结束的子会话
    const released = await (ctx.tools as any).execute({
      name: 'ops_bash',
      callId: 'call-4' as never,
      arguments: {},
      agent: { id: capturedChildId } as never,
      signal: new AbortController().signal,
    })
    expect(released.isError).toBeFalsy()
    expect(body).toHaveBeenCalledTimes(1)

    await plugin.dispose()
    await ctx.fiber.dispose()
  })

  it('0.2.2-rc.2+ 扁平 startActivation（存在 rootOf）与动态 replyHint 适配 { agent: "lead" }', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })

    const sendBody = vi.fn(async () => 'sent')
    ctx.tools.register({
      name: 'send_message',
      description: 'Send a message to an agent.',
      parameters: { type: 'object', properties: { agent: { type: 'string' }, message: { type: 'string' } }, required: ['agent', 'message'] },
      output: { schema: { type: 'string' }, render: v => [{ type: 'text', text: String(v) }] },
      execute: sendBody,
    })

    const receivedSpecs: Array<Record<string, unknown>> = []
    const rootAgent = { id: 'main', session: { header: { id: 'main' } }, options: { maxTokens: 4096 } } as unknown as Agent
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true, outputSchema: true } }),
      rootOf: (caller: object) => caller === rootAgent ? rootAgent : rootAgent,
      namesOf: (caller: object) => caller === rootAgent ? { self: 'lead' } : { self: 'agent-1', parent: 'lead' },
      startActivation: async (spec: Record<string, unknown>) => {
        receivedSpecs.push(spec)
        const childId = spec.childId as string
        const child = { id: childId, session: { header: { id: childId, parentSession: 'main' } } } as unknown as Agent
        // 子代理在运行期通过新版 send_message({ agent: 'lead' }) 回传必须放行
        const replyRes = await (ctx.tools as any).execute({
          name: 'send_message',
          callId: 'call-lead' as never,
          arguments: { agent: 'lead', message: '完成结论' },
          agent: child,
          signal: new AbortController().signal,
        })
        expect(replyRes.isError).not.toBe(true)
        // 旧版误用或传给别的 agent 必须拦截
        const wrongRes = await (ctx.tools as any).execute({
          name: 'send_message',
          callId: 'call-other' as never,
          arguments: { agent: 'other-agent', message: '越权' },
          agent: child,
          signal: new AbortController().signal,
        })
        expect(wrongRes.isError).toBe(true)
        return {
          result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: '扁平回答' }] }),
          dispose: async () => {},
        }
      },
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()
    const outcome = await commands.get(RUN_COMMAND)!.handler({
      agent: rootAgent,
      rawInput: JSON.stringify({ id: 'flat-rc2-req', question: '测试扁平启动' }),
      signal: new AbortController().signal,
    } as never)

    expect(outcome).toEqual({ kind: 'success', text: '扁平回答' })
    expect(sendBody).toHaveBeenCalledOnce()
    expect(receivedSpecs).toHaveLength(1)
    const spec = receivedSpecs[0]!
    expect(spec.request).toBeUndefined()
    expect(spec.parent).toBe(rootAgent)
    expect(spec.agentOptions).toEqual({ maxTokens: 4096 })
    expect(spec.delivery).toBe('caller')
    const promptText = (spec.prompt as Array<{ text: string }>)[0]!.text
    expect(promptText).toContain('agent 为 "lead"')
    expect(promptText).not.toContain('agent_id')

    await plugin.dispose()
    await ctx.fiber.dispose()
  })

  it('<= 0.2.2-rc.1 旧版 send_message({ agent_id }) 时 replyHint 保持提示 agent_id = parentId', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (command: CommandDefinition) => { commands.set(command.name, command); return () => { commands.delete(command.name) } } })

    ctx.tools.register({
      name: 'send_message',
      description: 'Send a message to an agent.',
      parameters: { type: 'object', properties: { agent_id: { type: 'string' }, message: { type: 'string' } }, required: ['agent_id', 'message'] },
      output: { schema: { type: 'string' }, render: v => [{ type: 'text', text: String(v) }] },
      execute: async () => 'sent',
    })

    const prompts: string[] = []
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true } }),
      startActivation: async (spec: { request: { prompt: readonly { type: string; text: string }[] } }) => {
        prompts.push(spec.request.prompt.map(b => b.text).join(''))
        return {
          result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: '旧版回答' }] }),
          dispose: async () => {},
        }
      },
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()
    const outcome = await commands.get(RUN_COMMAND)!.handler({
      agent: { session: { header: { id: 'main-legacy' } } },
      rawInput: JSON.stringify({ id: 'legacy-hint-req', question: '旧版提示' }),
      signal: new AbortController().signal,
    } as never)

    expect(outcome).toEqual({ kind: 'success', text: '旧版回答' })
    expect(prompts[0]).toContain('agent_id 为 "main-legacy"')

    await plugin.dispose()
    await ctx.fiber.dispose()
  })

  it('宿主提供 connection 时注册 JOB_ROUTE_PATH 路由供只读状态查询', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (c: CommandDefinition) => { commands.set(c.name, c); return () => { commands.delete(c.name) } } })
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true } }),
      startActivation: async () => ({
        result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: '路由查询回答' }] }),
        dispose: async () => {},
      }),
    })

    let registeredRoute: any
    ctx.provide('connection', {
      fetch: {
        register: (route: any) => {
          registeredRoute = route
          return () => { registeredRoute = undefined }
        },
      },
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()

    expect(registeredRoute).toBeDefined()
    expect(registeredRoute.path).toBe('/api/michengai-btw/job')

    // 未启动任务查询
    const missingRes = await registeredRoute.fetch(new Request('http://127.0.0.1/api/michengai-btw/job?session=main&id=none'))
    expect(await missingRes.json()).toEqual({ state: 'not-found' })

    // 启动任务并完成
    await commands.get(RUN_COMMAND)!.handler({
      agent: { session: { header: { id: 'main' } } },
      rawInput: JSON.stringify({ id: 'route-test-1', question: '查验' }),
      signal: new AbortController().signal,
    } as never)

    // 通过 Fetch 路由取回完成结果
    const doneRes = await registeredRoute.fetch(new Request('http://127.0.0.1/api/michengai-btw/job?session=main&id=route-test-1'))
    expect(await doneRes.json()).toEqual({
      state: 'done',
      result: { kind: 'success', text: '路由查询回答' },
    })

    await plugin.dispose()
    expect(registeredRoute).toBeUndefined()
    await ctx.fiber.dispose()
  })

  it('宿主后加载 connection 服务时，通过 inject 仍能正确注册 fetch 路由', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    ctx.provide('commands', { register: () => () => {} })
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true } }),
      startActivation: async () => ({
        result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: '' }] }),
        dispose: async () => {},
      }),
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()

    let registeredRoute: any
    // 在插件加载之后才 provide connection 服务
    ctx.provide('connection', {
      fetch: {
        register: (route: any) => {
          registeredRoute = route
          return () => { registeredRoute = undefined }
        },
      },
    })
    await new Promise(resolve => setTimeout(resolve, 0))

    expect(registeredRoute).toBeDefined()
    expect(registeredRoute.path).toBe('/api/michengai-btw/job')

    await plugin.dispose()
    await ctx.fiber.dispose()
  })

  it('/btw 终端命令在调用方 signal 中断时自动调用 close 取消任务，防止 token 浪费', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (c: CommandDefinition) => { commands.set(c.name, c); return () => { commands.delete(c.name) } } })

    const dispose = vi.fn(async () => {})
    let resolvePending!: (val: any) => void
    const pending = new Promise(resolve => { resolvePending = resolve })
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true } }),
      startActivation: async () => ({
        result: pending as any,
        dispose,
      }),
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()

    const controller = new AbortController()
    const task = commands.get('btw')!.handler({
      agent: { session: { header: { id: 'main-tui' } } },
      rawInput: '终端旁问',
      signal: controller.signal,
    } as never)

    // 用户在终端按下 Ctrl+C，触发 signal abort
    controller.abort(new Error('Terminal interrupted'))
    const outcome = await task
    expect(outcome.kind).toBe('error')

    // 等待 close 释放
    await new Promise(resolve => setTimeout(resolve, 10))
    expect(dispose).toHaveBeenCalled()
    resolvePending({ stopReason: 'completed', output: [] })

    await plugin.dispose()
    await ctx.fiber.dispose()
  })

  it('btw-run 内部命令在 invocation.signal abort 后任务继续在后台运行，不被取消（核心断线恢复不变量）', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (c: CommandDefinition) => { commands.set(c.name, c); return () => { commands.delete(c.name) } } })

    const dispose = vi.fn(async () => {})
    let resolvePending!: (val: any) => void
    const pending = new Promise(resolve => { resolvePending = resolve })
    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true } }),
      startActivation: async () => ({
        result: pending as any,
        dispose,
      }),
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()

    const controller = new AbortController()
    const runTask = commands.get(RUN_COMMAND)!.handler({
      agent: { session: { header: { id: 'main-web' } } },
      rawInput: JSON.stringify({ id: 'web-job-1', question: '长耗时问题' }),
      signal: controller.signal,
    } as never)

    // 模拟前端长连接 300s 发生超时，触发 invocation.signal abort
    controller.abort(new Error('Failed to fetch'))
    await runTask

    // 核心断线恢复不变量：btw-run 绝不主动调用 close，任务继续保持 running
    expect(dispose).not.toHaveBeenCalled()
    const queryResBefore = await commands.get(QUERY_COMMAND)!.handler({
      agent: { session: { header: { id: 'main-web' } } },
      rawInput: 'web-job-1',
    } as never)
    expect(JSON.parse((queryResBefore as any).text)).toEqual({ state: 'running' })

    // 后台完成计算
    resolvePending({ stopReason: 'completed', output: [{ type: 'text', text: '恢复出的答案' }] })
    await new Promise(resolve => setTimeout(resolve, 10))

    // query 可以正确取回结果
    const queryResAfter = await commands.get(QUERY_COMMAND)!.handler({
      agent: { session: { header: { id: 'main-web' } } },
      rawInput: 'web-job-1',
    } as never)
    expect(JSON.parse((queryResAfter as any).text)).toEqual({
      state: 'done',
      result: { kind: 'success', text: '恢复出的答案' },
    })

    await plugin.dispose()
    await ctx.fiber.dispose()
  })

  it('btw TUI 命令正常完成后，请求级 signal 的迟到 abort 不会清除已缓存的结果', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (c: CommandDefinition) => { commands.set(c.name, c); return () => { commands.delete(c.name) } } })

    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true } }),
      startActivation: async () => ({
        result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: 'TUI 答案' }] }) as any,
        dispose: async () => {},
      }),
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()

    const fixedId = 'fixed-tui-job-id'
    const originalRandomUUID = globalThis.crypto.randomUUID
    globalThis.crypto.randomUUID = () => fixedId as any

    try {
      const controller = new AbortController()
      const task = commands.get('btw')!.handler({
        agent: { session: { header: { id: 'main-settle' } } },
        rawInput: '终端命令',
        signal: controller.signal,
      } as never)

      const outcome = await task
      expect(outcome).toEqual({ kind: 'success', text: 'TUI 答案' })

      // 宿主在命令完成后回收请求资源触发 signal abort
      controller.abort(new Error('Request settled'))
      await new Promise(resolve => setTimeout(resolve, 10))

      // 验证迟到 abort 没有把 completed 缓存误删：使用 btw-query 查询原任务，状态仍为 done
      const queryOutcome = await commands.get('btw-query')!.handler({
        rawInput: fixedId,
        agent: { session: { header: { id: 'main-settle' } } },
      } as never)
      expect(queryOutcome).toEqual({
        kind: 'success',
        text: JSON.stringify({ state: 'done', result: { kind: 'success', text: 'TUI 答案' } }),
      })
    } finally {
      globalThis.crypto.randomUUID = originalRandomUUID
    }

    await plugin.dispose()
    await ctx.fiber.dispose()
  })

  it('btw TUI 命令传入已 abort 的 signal 时直接取消且不产生多余 close 报错', async () => {
    const { Context, ToolRuntime } = await load()
    const ctx = new Context()
    ctx.provide('systemPrompt', { tools: () => () => {}, section: () => () => {}, getSectionOrder: () => 0 })
    await setupTools(ctx, ToolRuntime)
    const commands = new Map<string, CommandDefinition>()
    ctx.provide('commands', { register: (c: CommandDefinition) => { commands.set(c.name, c); return () => { commands.delete(c.name) } } })

    ctx.provide('subagents', {
      getProvider: () => ({ inheritsParentContext: true, capabilities: { agentOptions: true } }),
      startActivation: async () => ({
        result: Promise.resolve({ stopReason: 'completed', output: [{ type: 'text', text: 'TUI 答案' }] }) as any,
        dispose: async () => {},
      }),
    })

    const plugin = ctx.plugin(apply)
    await plugin.await()

    const controller = new AbortController()
    controller.abort(new Error('Pre-aborted'))

    const outcome = await commands.get('btw')!.handler({
      agent: { session: { header: { id: 'main-pre-abort' } } },
      rawInput: '提前取消命令',
      signal: controller.signal,
    } as never)

    expect(outcome.kind).toBe('error')

    await plugin.dispose()
    await ctx.fiber.dispose()
  })
})
