// 跟随宿主主题令牌，避免系统深色偏好覆盖 DSH 手动选择的外观。
export const CSS = `
.btw-reference-preview{display:block;margin-top:6px;max-height:3.2em;overflow:hidden;overflow-wrap:anywhere;line-height:1.6;color:var(--dsw-alias-label-primary)}
.btw-selection-dialog{position:fixed;box-sizing:border-box;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary)}
.btw-selection-menu{position:fixed;display:inline-flex;align-items:center;gap:6px;margin:0;width:max-content;max-width:calc(100vw - 16px);padding:0;inset:auto;border:none;background:transparent;box-shadow:none;pointer-events:auto;z-index:1000}
.btw-selection-menu button{display:inline-flex;align-items:center;justify-content:center;corner-shape:round;background:var(--dsw-alias-button-floating-fill);border:1px solid var(--dsw-alias-border-l3,rgba(0,0,0,0.1));box-shadow:var(--dsw-elevation-panel);color:var(--dsw-alias-label-primary);font:var(--dsw-font-xs-13);cursor:pointer;border-radius:999px;padding:5px 12px;min-height:28px;white-space:nowrap;user-select:none;transition:background-color 120ms ease}
.btw-selection-menu button:hover{background:var(--dsw-alias-button-floating-hover)}
.btw-selection-menu button:focus-visible{background:var(--dsw-alias-button-floating-hover);outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:1px}
.btw-selection-modal{max-width:min(520px,calc(100vw - 32px))!important}
.btw-selection-label{display:flex;flex-direction:column;gap:8px;margin-top:12px;font-size:13px;font-weight:500;color:var(--dsw-alias-label-primary)}
.btw-selection-modal textarea{box-sizing:border-box;width:100%;min-height:96px;resize:vertical;font:inherit;font-size:13px;line-height:1.5;padding:10px 12px;border:1px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-md,8px);background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary)}
.btw-selection-modal textarea:focus{border-color:var(--dsw-alias-state-business-primary);outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:-1px}
.btw-selection-actions{display:flex;justify-content:flex-end;align-items:center;gap:8px}
.btw-selection-hint{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:1.6;margin:10px 4px}
.btw-reference{padding:0 14px 10px;font-size:12px}
.btw-reference summary{cursor:pointer;color:var(--dsw-alias-label-secondary)}
.btw-reference blockquote{margin:8px 0 0;padding:8px;border-left:2px solid var(--dsw-alias-border-l2);white-space:pre-wrap;overflow-wrap:anywhere;max-height:150px;overflow:auto}
.btw-selection-modal .btw-reference{padding:0}
.btw-reference-tag{display:inline-flex;align-items:center;font-size:11px;font-weight:500;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-interactive-bg-hover);padding:1px 6px;border-radius:4px;border:1px solid var(--dsw-alias-border-l3);margin-right:4px}
.btw-dock{display:flex;flex:none;flex-direction:column;gap:8px;width:calc(100% - var(--dsh-composer-side-clearance,0px) - var(--dsh-composer-side-clearance,0px));max-width:var(--dsh-composer-card-max-width,100%);margin:0 auto;max-height:440px;overflow:auto;padding:4px 0 10px;box-sizing:border-box;letter-spacing:0}
.btw-bubble{background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l2);border-radius:12px;min-width:0;flex-shrink:0;font-size:13px;line-height:1.6;font-family:var(--dsw-font-family,inherit);letter-spacing:0}
.btw-header{display:flex;align-items:center;gap:8px;padding:8px 10px 8px 14px;min-width:0;min-height:44px}
.btw-symbol{display:flex;align-items:center;color:var(--dsw-alias-label-secondary);height:28px;flex-shrink:0}
.btw-question{flex:1;min-width:0;overflow-wrap:anywhere;font-size:13px;font-weight:500;line-height:22px;max-height:66px;overflow:auto}
.btw-actions{display:flex;gap:4px;flex-shrink:0}
.btw-actions button{display:grid;place-items:center;width:28px;height:28px;padding:0;border:0;border-radius:50%;background:transparent;color:var(--dsw-alias-label-secondary);cursor:pointer;flex:none;transition:background-color 120ms ease}
.btw-actions button:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.btw-actions button:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary,var(--dsw-alias-label-primary));outline-offset:-2px}
.btw-actions button.btw-action-stop{color:var(--dsw-alias-state-error-primary,var(--dsw-alias-label-primary))}
.btw-actions button.btw-action-stop:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-state-error-primary,var(--dsw-alias-label-primary))}
.btw-actions button:disabled{cursor:wait;opacity:.5}
.btw-status{display:flex;align-items:center;gap:8px;padding:0 14px 12px;color:var(--dsw-alias-label-secondary);font-size:13px}
.btw-spinner{animation:btw-spin 1.2s linear infinite}@keyframes btw-spin{to{transform:rotate(360deg)}}
.btw-answer{padding:0 14px 14px;max-height:300px;overflow:auto;overflow-wrap:anywhere;font-size:13px;line-height:1.7}
.btw-answer>*:first-child{margin-top:0}.btw-answer>*:last-child{margin-bottom:0}
.btw-answer p{margin:8px 0}.btw-answer h1,.btw-answer h2,.btw-answer h3{font-size:15px;line-height:1.5;margin:12px 0 6px;font-weight:600}
.btw-answer pre{max-width:100%;overflow:auto;background:var(--dsw-alias-markdown-code-block);padding:10px;border-radius:8px;white-space:pre;font-size:12px}.btw-answer .katex-display{max-width:100%;overflow:auto}
.btw-answer code{font-family:Consolas,monospace;font-size:12px}.btw-answer :not(pre)>code{background:var(--dsw-alias-markdown-code-block);border-radius:4px;padding:1px 3px}.btw-answer a{color:var(--dsw-alias-label-primary);text-decoration:underline;text-underline-offset:2px;overflow-wrap:anywhere}
.btw-answer table{display:block;max-width:100%;overflow:auto;border-collapse:collapse}.btw-answer th,.btw-answer td{border:1px solid var(--dsw-alias-border-l2);padding:5px 9px}
.btw-answer ul,.btw-answer ol{padding-left:22px}.btw-answer blockquote{margin:8px 0;padding-left:10px;border-left:2px solid var(--dsw-alias-border-l4);color:var(--dsw-alias-label-secondary)}
.btw-error{margin:0;padding:0 14px 12px;font-size:13px;color:var(--dsw-alias-state-error-primary);overflow-wrap:anywhere}
.btw-anchor-highlight{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:2px;animation:btw-pulse 1.6s ease-out}
@keyframes btw-pulse{0%{background-color:var(--dsw-alias-interactive-bg-hover-accent,rgba(59,130,246,0.2))}100%{background-color:transparent}}
.btw-settings{display:flex;flex-direction:column;gap:12px;padding:12px 0;max-width:640px}
.btw-settings[data-btw-settings="loading"]{font-size:12px;color:var(--dsw-alias-label-secondary)}
.btw-settings-title{margin:0;font-size:14px;font-weight:600;color:var(--dsw-alias-label-primary);line-height:1.4}
.btw-settings-description{margin:0;font-size:12px;line-height:1.6;color:var(--dsw-alias-label-secondary)}
.btw-settings-summary{margin:0;font-size:12px;line-height:1.6;color:var(--dsw-alias-label-secondary)}
.btw-settings-warning{margin:0;font-size:12px;line-height:1.5;color:var(--dsw-alias-state-warning-primary,var(--dsw-alias-label-secondary))}
.btw-settings-field{display:flex;flex-direction:column;gap:6px}
.btw-settings-label{font-size:12px;font-weight:600;color:var(--dsw-alias-label-primary)}
.btw-settings-textarea{font:inherit;font-size:12px;line-height:1.6;padding:8px 10px;border-radius:8px;border:1px solid var(--dsw-alias-border-l3);background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);resize:vertical;box-sizing:border-box}
.btw-settings-prompt{min-height:120px}
.btw-settings-textarea:focus{outline:none;border-color:var(--dsw-alias-state-business-primary)}
.btw-settings-textarea:disabled{opacity:0.6;cursor:not-allowed}
.btw-settings-hint{font-size:11px;line-height:1.5;color:var(--dsw-alias-label-secondary)}
.btw-settings-error{margin:0;font-size:12px;line-height:1.5;color:var(--dsw-alias-state-error-primary,var(--dsw-alias-label-primary))}
.btw-settings-actions{display:flex;align-items:center;gap:8px}
.btw-settings-saved{font-size:11px;color:var(--dsw-alias-state-success-primary,var(--dsw-alias-label-secondary))}
@media(max-width:480px){.btw-dock{max-height:330px}.btw-header{padding:6px 8px 6px 12px;gap:6px}.btw-answer{padding:0 12px 12px;max-height:230px}.btw-status,.btw-error{padding-left:12px}.btw-actions{gap:0}.btw-actions button{width:36px;height:36px}}
@media(prefers-reduced-motion:reduce){.btw-spinner{animation:none}.btw-actions button{transition:none}}
.btw-native-ask-action{corner-shape:round;background:var(--dsw-alias-button-floating-fill);box-shadow:var(--dsw-elevation-panel);color:var(--dsw-alias-label-primary);font:var(--dsw-font-xs-13);cursor:pointer;border:none;border-radius:999px;padding:5px 10px;display:inline-flex;align-items:center}
.btw-native-ask-action:focus-visible{background:var(--dsw-alias-button-floating-hover)}
@media(hover:hover){.btw-native-ask-action:hover{background:var(--dsw-alias-button-floating-hover)}}
.btw-official-quote-node{display:inline-flex;align-items:baseline;gap:4px;box-sizing:border-box;max-width:min(80%,300px);margin:0;padding:0;vertical-align:baseline;color:var(--dsw-alias-state-business-primary);font-size:var(--dsh-content-font-size,14px);line-height:calc(20px + var(--dsh-content-font-delta,0px));cursor:pointer;text-decoration:none}
.btw-quote-marker{display:grid;place-items:center;align-self:center;flex:none;width:16px;height:16px;padding:0;color:inherit;user-select:none;pointer-events:none}
.btw-quote-icon{width:16px;height:16px}
.btw-quote-text{min-width:0;padding:0;border:none;outline:none;background:none;color:inherit;font:inherit;line-height:inherit;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.btw-quote-popover-text{display:block;padding:8px 10px;color:var(--dsw-alias-label-primary);font-size:14px;line-height:20px;overflow-wrap:anywhere;white-space:pre-wrap;max-width:min(520px,calc(100vw - 32px))}
.btw-official-quote-group{display:flex;flex-direction:column;align-items:flex-start;gap:4px;margin:0 0 6px 0;padding:0;max-width:100%}
[data-text-interaction-surface]{display:inline-flex!important;flex-direction:row!important;align-items:center!important;gap:6px!important}
[data-text-interaction-surface] button:not(.btw-native-ask-button){order:1!important;margin:0!important}
[data-text-interaction-surface] button.btw-native-ask-button{order:2!important;margin:0!important}
.btw-selection-menu button:first-child{order:1!important}
.btw-selection-menu button:last-child{order:2!important}
`
