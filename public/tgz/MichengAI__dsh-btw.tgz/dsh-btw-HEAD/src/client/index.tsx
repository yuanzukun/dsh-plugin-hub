import React from 'react'
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-commands/remote'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { TypertClientRemote } from '@deepseek-ai/dsh-typert-protocol'
import type { PickOutcome } from '@deepseek-ai/dsh-client-ui-input-trigger/client'
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { SlotRegistry } from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-chat/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { SessionId } from '@deepseek-ai/dsh-session/types'
import { MessageCircle } from 'lucide-react'
import { CLOSE_COMMAND, DEFAULT_TIMEOUT_MS, INTERNAL_COMMANDS, JOB_ROUTE_PATH, QUERY_COMMAND, RUN_COMMAND, type SideJobStatus, type SideResult } from '../shared'
import { BubbleStore, SideRequestNotStartedError } from './bubbles'
import { BubbleDock } from './BubbleView'
import { QuoteStore } from './quotes'
import { SelectionAsk } from './SelectionAsk'
import { CSS } from './styles'
import { createQuoteTriggerSource } from './trigger-source'
import { quoteUserTextRule, QuoteUserTextNode } from './user-quote-chip'
import { createOfficialQuoteRule, OfficialQuotePreview, safeRegisterUserTextRule } from './official-quote'
import { NativeBtwAskAction, safeRegisterInteraction } from './NativeBtwAsk'
import { LOCALE_DICTIONARIES, normalizeLocale, NS, type BtwTranslate } from '../locales'
import { BtwSettingsCard, type BtwSettingsFace } from './SettingsCard'
import { createSettingsScope, BUNDLE_NAME, ROW_CONFIG_KEY, type BtwSettingsScope, type HostConfigForms } from './settings-scope'

export const inject = ['slots', 'remote', 'remote.commands', 'locale', 'conversation', 'sessions']

function BtwCommandIcon({ size = 16, className }: { size?: number; className?: string }): React.JSX.Element {
  return <MessageCircle size={size} className={className} />
}

function sessionIdOf(session: unknown): string {
  if (typeof session === 'string') return session
  if (session && typeof session === 'object' && 'sessionId' in session) return String((session as { sessionId: unknown }).sessionId)
  return String(session)
}

type LiveCommandUi = {
  candidates?: (...args: unknown[]) => unknown
  dispatch?: (pick: { candidate?: { name?: string }; session?: unknown; span?: unknown }) => unknown
  matchSpace?: (session: unknown, token: string) => unknown
  matchEnter?: (session: unknown, line: string, signal: AbortSignal, envelope: { attachments?: number; images?: number }) => unknown
  execute?: (session: unknown, line: string, attachments?: unknown) => unknown
}

/** 官方认领闭包在 commandUi 上；改 remote.commands 拦不到真实提交。 */
function attachOfficialBtw(commandUi: unknown, claim: (sessionId: string) => PickOutcome, t: BtwTranslate, isSubagent: (sessionId: string) => boolean): () => void {
  const live = commandUi as LiveCommandUi | undefined
  if (!live) return () => {}
  const restore: Array<() => void> = []

  if (typeof live.candidates === 'function') {
    const original = live.candidates
    live.candidates = async (...args: unknown[]) => {
      const rows = await original.apply(live, args)
      if (!Array.isArray(rows)) return rows
      return rows.filter((row: unknown) => !(isSubagent(sessionIdOf(args[0])) && row && typeof row === 'object' && 'name' in row && row.name === 'btw')).map((row: unknown) => {
        if (!row || typeof row !== 'object' || !('name' in row) || (row as { name: unknown }).name !== 'btw') return row
        const item = row as { name: string; icon?: unknown }
        return {
          ...item,
          label: t('command.label'),
          description: t('command.description'),
          hint: t('command.hint'),
          icon: item.icon ?? BtwCommandIcon,
        }
      })
    }
    restore.push(() => { live.candidates = original })
  }

  if (typeof live.dispatch === 'function') {
    const original = live.dispatch.bind(live)
    live.dispatch = pick => pick.candidate?.name === 'btw' ? (isSubagent(sessionIdOf(pick.session)) ? undefined : claim(sessionIdOf(pick.session))) : original(pick)
    restore.push(() => { live.dispatch = original })
  }

  if (typeof live.matchSpace === 'function') {
    const original = live.matchSpace.bind(live)
    live.matchSpace = (session, token) => token === '/btw' ? (isSubagent(sessionIdOf(session)) ? undefined : claim(sessionIdOf(session))) : original(session, token)
    restore.push(() => { live.matchSpace = original })
  }

  if (typeof live.matchEnter === 'function') {
    const original = live.matchEnter.bind(live)
    live.matchEnter = async (session, line, signal, envelope) => {
      if (!/^\/btw(?:\s|$)/.test(line.trim())) return original(session, line, signal, envelope)
      if (isSubagent(sessionIdOf(session))) throw new Error(t('error.subagent'))
      if (envelope?.attachments || envelope?.images) throw new Error(t('error.removeAttachments'))
      return claim(sessionIdOf(session))
    }
    restore.push(() => { live.matchEnter = original })
  }

  if (typeof live.execute === 'function') {
    const original = live.execute.bind(live)
    live.execute = async (session, line, attachments) => {
      if (!/^\/btw(?:\s|$)/.test(line)) return original(session, line, attachments)
      if (isSubagent(sessionIdOf(session))) return { kind: 'error', text: t('error.subagent') }
      if (Array.isArray(attachments) && attachments.length) return { kind: 'error', text: t('error.attachments') }
      const outcome = claim(sessionIdOf(session))
      if (!outcome || typeof outcome !== 'object' || !('claim' in outcome)) return { kind: 'error', text: t('error.backend') }
      try {
        return await outcome.claim.submit(line.replace(/^\/btw\s*/, '').trim(), undefined as never, [])
      } catch (error) {
        return { kind: 'error', text: error instanceof Error ? error.message : String(error) }
      }
    }
    restore.push(() => { live.execute = original })
  }

  return () => restore.forEach(dispose => dispose())
}

export function apply(ctx: Context): void {
  ctx.effect(() => ctx.locale.register(NS, LOCALE_DICTIONARIES))
  const t = ctx.locale.bind(NS)
  const slots = ctx.get('slots') as SlotRegistry
  const remote = ctx.get('remote') as TypertClientRemote
  const sessions = ctx.get('sessions') as unknown as ISessions
  // 普通分叉也有父会话；只使用宿主明确给出的子代理身份，不按 parentId 猜测。
  const isSubagent = (id: string): boolean => Boolean(sessions.subagentAddress?.(id as SessionId)) || sessions.list?.getSnapshot().byId[id as SessionId]?.origin === 'subagent'
  const execute = async (session: string, line: string, signal?: AbortSignal): Promise<SideResult> => {
    const response = await remote.commands.execute(session as SessionId, line, [], signal)
    if (!response.ok) {
      const failure = response.error
      const code: string = failure.code
      const details = failure.details
      const reason = details && typeof details === 'object' && 'reason' in details && typeof details.reason === 'string' ? details.reason : undefined
      const ownedBySubagent = (code === 'agent-busy' || code === 'session/agent-busy')
        && (reason === 'use subagent delivery for this child session' || failure.message === `session "${session}" is owned by subagent routing`)
      if (ownedBySubagent) throw new SideRequestNotStartedError(t('error.subagent'))
      throw new Error(failure.message)
    }
    if (!response.value) throw new Error(t('error.backend'))
    return { kind: response.value.result.kind, text: response.value.result.text ?? '' }
  }

  const pollResult = async (session: string, id: string, signal: AbortSignal): Promise<SideResult> => {
    const startTime = Date.now()
    let delay = 50
    let httpAvailable = typeof window !== 'undefined' && typeof window.fetch === 'function'
    let commandQueryAttempts = 0
    let consecutiveFailures = 0
    let firstFailureTime = 0
    let lastError: Error | undefined

    while (!signal.aborted && Date.now() - startTime < DEFAULT_TIMEOUT_MS) {
      if (delay > 0) {
        await new Promise(resolve => setTimeout(resolve, delay))
      }
      // 自适应退避：50ms -> 1000ms -> 2000ms -> 3000ms -> 4000ms -> 5000ms 封顶
      delay = Math.min(delay < 1000 ? 1000 : delay + 1000, 5000)
      if (signal.aborted) break

      let status: SideJobStatus | undefined
      let transportSuccess = false

      if (httpAvailable) {
        try {
          const resp = await window.fetch(`${JOB_ROUTE_PATH}?session=${encodeURIComponent(session)}&id=${encodeURIComponent(id)}`, { signal })
          if (resp.status === 404 || resp.status === 401 || resp.status === 403) {
            httpAvailable = false
          } else if (resp.ok) {
            transportSuccess = true
            status = await resp.json() as SideJobStatus
          } else {
            lastError = new Error(`HTTP ${resp.status}`)
          }
        } catch (err) {
          if (signal.aborted) break
          lastError = err instanceof Error ? err : new Error(String(err))
        }
      }

      // 内部命令通道在 HTTP 不可用时作为全量保底通道持续轮询；在 HTTP 可用时仅作为边缘冗余探测最多尝试 2 次，避免产生过多会话命令事件日志
      const shouldQueryViaCommand = !status && !signal.aborted && (!httpAvailable || commandQueryAttempts < 2)
      if (shouldQueryViaCommand) {
        try {
          if (httpAvailable) commandQueryAttempts++
          const queryRes = await execute(session, `/${QUERY_COMMAND} ${id}`, signal)
          if (queryRes.kind === 'success' && queryRes.text) {
            transportSuccess = true
            status = JSON.parse(queryRes.text) as SideJobStatus
          }
        } catch (err) {
          if (signal.aborted) break
          lastError = err instanceof Error ? err : new Error(String(err))
        }
      }

      if (transportSuccess) {
        consecutiveFailures = 0
        firstFailureTime = 0
      } else {
        consecutiveFailures++
        if (firstFailureTime === 0) firstFailureTime = Date.now()
        // 允许宿主网络重连/切换缓冲（宿主客户端重连退避可达 15~30s），持续失败超 60 秒且失败达 6 次以上认定传输中断
        if (consecutiveFailures >= 6 && Date.now() - firstFailureTime >= 60_000) {
          if (lastError && typeof console !== 'undefined' && console.debug) {
            console.debug('[dsh-btw] side-ask polling failed due to network disruption:', lastError)
          }
          throw new Error(t('error.network'))
        }
      }

      if (status?.state === 'done' && status.result) {
        return status.result
      }
      if (status?.state === 'not-found' && Date.now() - startTime > 10_000) {
        throw new Error(t('error.backend'))
      }
    }
    if (signal.aborted) throw new Error(t('error.cancelled'))
    if (lastError && typeof console !== 'undefined' && console.debug) {
      console.debug('[dsh-btw] side-ask polling timeout, last error:', lastError)
    }
    throw new Error(t('error.timeout'))
  }

  const runWithRecovery = async (session: string, id: string, question: string, signal: AbortSignal, reference?: string): Promise<SideResult> => {
    try {
      return await execute(session, `/${RUN_COMMAND} ${JSON.stringify({ id, question, reference, locale: normalizeLocale(t('locale.id')) })}`, signal)
    } catch (error) {
      if (signal.aborted) throw error
      if (error instanceof SideRequestNotStartedError) throw error
      return await pollResult(session, id, signal)
    }
  }

  const store = new BubbleStore({
    run: (session, id, question, signal, reference) => runWithRecovery(session, id, question, signal, reference),
    close: (session, id) => execute(session, `/${CLOSE_COMMAND} ${id}`),
  }, t)
  const quoteStore = new QuoteStore()

  const claim = (sessionId: SessionId): PickOutcome => ({ claim: {
    name: 'btw', token: '/btw ', get hint() { return t('command.hint') },
    submit: async (args, _actx, attachments) => {
      if (isSubagent(sessionId)) return { kind: 'error', text: t('error.subagent') }
      if (attachments.length) return { kind: 'error', text: t('error.attachments') }
      try {
        await store.ask(sessionId, args.trim())
        return { kind: 'success' }
      } catch (error) { return { kind: 'error', text: error instanceof Error ? error.message : String(error) } }
    },
  } })
  const registerTriggerSource = (inputTriggers: unknown) => {
    const it = inputTriggers as { registerSource?: (src: unknown) => () => void } | undefined
    if (it && typeof it.registerSource === 'function') {
      return it.registerSource(createQuoteTriggerSource({ quoteStore, t }))
    }
    return undefined
  }

  const registerUserTextRule = (uiConversation: unknown) => {
    const uc = uiConversation as {
      userText?: {
        definitions?: Map<string, unknown>
        has?: (id: string) => boolean
        register?: (rule: unknown) => () => void
        subscribe?: (listener: () => void) => () => void
      }
    } | undefined
    if (uc?.userText) {
      const disposers: Array<() => void> = []
      const ut = uc.userText

      let offOfficialShim: (() => void) | undefined
      let syncing = false
      const isOfficialQuotePresent = () => Boolean(ut.definitions?.has('quote') || ut.has?.('quote'))

      // 响应式动态注销/登记：与官方插件注册表事件联动
      // 官方规则存在时，不仅在 match() 中让位，更直接从注册表中物理注销，彻底失效宿主 Evaluator matcher 缓存
      const syncShim = () => {
        if (syncing) return
        syncing = true
        try {
          const hasOfficial = isOfficialQuotePresent()
          if (hasOfficial && offOfficialShim) {
            offOfficialShim()
            offOfficialShim = undefined
          } else if (!hasOfficial && !offOfficialShim) {
            offOfficialShim = safeRegisterUserTextRule(ut, createOfficialQuoteRule(isOfficialQuotePresent))
          }
        } finally {
          syncing = false
        }
      }

      syncShim()
      if (typeof ut.subscribe === 'function') {
        const unsub = ut.subscribe(syncShim)
        disposers.push(unsub)
      }

      disposers.push(() => {
        if (offOfficialShim) {
          offOfficialShim()
          offOfficialShim = undefined
        }
      })

      const offLegacy = safeRegisterUserTextRule(ut, quoteUserTextRule)
      if (typeof offLegacy === 'function') disposers.push(offLegacy)
      return () => {
        disposers.forEach(d => d())
      }
    }
    return undefined
  }

  const registerInteractions = (uiConversation: unknown) => {
    const uc = uiConversation as { interactions?: { definitions?: Map<string, unknown>; has?: (id: string) => boolean; register?: (item: unknown) => () => void } } | undefined
    if (uc?.interactions) {
      return safeRegisterInteraction(uc.interactions, {
        id: 'michengai-btw',
        onInteraction(request: any) {
          if (request.trigger !== 'selection' || request.readText() === null) return
          if (isSubagent(request.sessionId)) return
          request.open()
        },
      })
    }
    return undefined
  }

  if (typeof ctx.inject === 'function') {
    ctx.inject(['commandUi'], scope => attachOfficialBtw(scope.get('commandUi'), sessionId => claim(sessionId as SessionId), t, isSubagent))
    ctx.inject(['inputTriggers'], scope => {
      const off = registerTriggerSource(scope.get('inputTriggers'))
      if (typeof off === 'function') scope.effect(() => off)
    })
    ctx.inject(['uiConversation'], scope => {
      const offRule = registerUserTextRule(scope.get('uiConversation'))
      const offInteractions = registerInteractions(scope.get('uiConversation'))
      if (typeof offRule === 'function') scope.effect(() => offRule)
      if (typeof offInteractions === 'function') scope.effect(() => offInteractions)
    })
  } else {
    ctx.effect(() => attachOfficialBtw(ctx.get('commandUi'), sessionId => claim(sessionId as SessionId), t, isSubagent))
    const offTrigger = registerTriggerSource(ctx.get('inputTriggers'))
    if (typeof offTrigger === 'function') ctx.effect(() => offTrigger)
    const offRule = registerUserTextRule(ctx.get('uiConversation'))
    if (typeof offRule === 'function') ctx.effect(() => offRule)
    const offInteractions = registerInteractions(ctx.get('uiConversation'))
    if (typeof offInteractions === 'function') ctx.effect(() => offInteractions)
  }

  ctx.effect(() => {
    const style = document.createElement('style')
    style.dataset.plugin = '@michengai/dsh-btw'
    style.dataset.pluginCss = '@michengai/dsh-btw/client.css'
    style.dataset.michengaiBtw = ''
    style.textContent = CSS
    ;(document.head ?? document.documentElement).append(style)
    return () => style.remove()
  })
  ctx.effect(() => () => store.dispose())

  function Dock(props: PropsRuntime<'conversation.input.dock'> & { t: BtwTranslate }): React.JSX.Element {
    const session = (ctx.get('sessions') as unknown as ISessions).scope(props.session.sessionId)

    return (
      <>
        {!props.session.subagent && !isSubagent(props.session.sessionId) && (
          <SelectionAsk
            key={props.session.sessionId}
            store={store}
            sessionId={props.session.sessionId}
            t={props.t}
            input={session ? ctx.conversation.input.for(session) : undefined}
          />
        )}
        <BubbleDock store={store} sessionId={props.session.sessionId} t={props.t} />
      </>
    )
  }
  slots.inject('conversation.input.dock', () => slots.register({ name: 'conversation.input.dock', id: 'michengai-btw', order: -50, locale: NS }, Dock))
  try {
    slots.inject('conversation.chat.text-interaction', () => {
      try {
        return (slots.register as any)({
          name: 'conversation.chat.text-interaction',
          key: 'btw',
          locale: NS,
          order: 10,
        }, NativeBtwAskAction as any)
      } catch {
        return () => {}
      }
    })
  } catch {}

  slots.inject('conversation.user.text.node', () => {
    const disposers: Array<() => void> = []
    try {
      const offOfficial = slots.register({
        name: 'conversation.user.text.node',
        key: 'dsh-btw-blockquote',
        priority: 100,
        locale: NS,
      }, (({ node }: { node: { data: { text: string } } }) => <OfficialQuotePreview text={node.data.text} />) as any)
      if (typeof offOfficial === 'function') disposers.push(offOfficial)
    } catch {}

    try {
      const offLegacy = slots.register({
        name: 'conversation.user.text.node',
        key: 'dsh-btw-quote',
        priority: 90,
        locale: NS,
      }, QuoteUserTextNode as any)
      if (typeof offLegacy === 'function') disposers.push(offLegacy)
    } catch {}

    return () => disposers.forEach(d => d())
  })
  slots.inject('conversation.chat.commandview', () => {
    const off = INTERNAL_COMMANDS.map(key => slots.register({ name: 'conversation.chat.commandview', key }, () => null))
    return () => off.forEach(dispose => dispose())
  })

  // 设置卡片挂在宿主 Plugins 页的配置槽里，位置与 `dsh-subagent-default-model` 完全一致。
  // `configForms` 是宿主 0.1.7+ 的客户端设置面；用软注入，宿主没有它时卡片直接不出现，
  // 不能让整个客户端插件因为少了这个服务而激活失败。
  ctx.inject(['configForms'], scope => {
    const forms = scope.get('configForms') as HostConfigForms | undefined
    if (!forms) return
    const settingsScope: BtwSettingsScope = createSettingsScope(forms)
    const face: BtwSettingsFace = { scope: settingsScope }
    // 这两个槽的 SlotMap 契约由宿主 plugin-manager 包声明，btw 不依赖它，
    // 因此按结构化形状注册：宿主有该槽时才渲染，没有时 register 只是空转。
    const loose = slots as unknown as {
      inject(name: string, callback: () => () => void): () => void
      register(options: { name: string; key: string; priority: number; locale: string; inject?: () => object }, component: unknown): () => void
    }
    // 两个槽都要注册，缺一个用户就找不到入口：
    //   · `plugins.bundle.config` —— 插件详情页里那块显眼的配置区（key = 包名）。
    //   · `plugins.row.config`    —— 「组成部分」列表里那一行的小箭头（key = `<包名>#<行 id>`）。
    // 只注册行级槽时，详情页没有任何配置区，用户必须先展开列表才看得到一个箭头按钮。
    const cards: { name: string; key: string }[] = [
      { name: 'plugins.bundle.config', key: BUNDLE_NAME },
      { name: 'plugins.row.config', key: ROW_CONFIG_KEY },
    ]
    for (const card of cards) {
      scope.effect(() => loose.inject(card.name, () => loose.register({
        name: card.name,
        key: card.key,
        priority: 30,
        locale: NS,
        inject: () => face,
      }, (
        // `view` 必须原样透传：宿主对同一个槽先用 `'summary'` 要列表里的一行，
        // 再用 `'page'` 要表单。丢掉它，列表的每一行都会渲染成整张表单。
        props: { t: BtwTranslate; view?: 'summary' | 'page' },
      ) => <BtwSettingsCard t={props.t as never} scope={face.scope} view={props.view} />)))
    }
  })
}
