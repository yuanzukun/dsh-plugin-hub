import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { describe, it } from 'node:test'
import { fileURLToPath } from 'node:url'

const bundle = readFileSync(
  join(dirname(fileURLToPath(import.meta.url)), 'client.bundle.js'),
  'utf8',
)

describe('client bundle', () => {
  it('registers with the Harness module loader', () => {
    assert.match(bundle, /window\.__ModuleLoader__\.load\(/)
    assert.match(bundle, /id: "dsh-zh-hant-hk"/)
    assert.match(bundle, /繁體中文/)
    let registered: { id?: string; exports?: { apply?: unknown; inject?: unknown } } | undefined
    const window = {
      __ModuleLoader__: {
        load(handoff: { id: string; factory: (require: unknown) => unknown }) {
          registered = { id: handoff.id, exports: handoff.factory(() => undefined) as { apply?: unknown; inject?: unknown } }
        },
      },
    }
    const fn = new Function('window', bundle)
    fn(window)
    assert.equal(registered?.id, 'dsh-zh-hant-hk')
    assert.equal(typeof registered?.exports?.apply, 'function')
    assert.deepEqual(registered?.exports?.inject, ['locale', 'connection', 'remote', 'settingsScope'])
  })
})
