import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { convertPluginText, installZhHantHook, isMarkedRoot, type ZhHantHkApi } from './dom-hook.js'

describe('dom hook', () => {
  it('converts simplified to Hong Kong wording', () => {
    assert.equal(convertPluginText('设置'), '設定')
    assert.equal(convertPluginText('会话'), '對話')
    assert.equal(convertPluginText('Read Only'), '唯讀')
    assert.equal(convertPluginText('hello world'), 'hello world')
  })

  it('detects opted-in roots', () => {
    assert.equal(isMarkedRoot(null), false)
    assert.equal(isMarkedRoot({ closest: () => null } as unknown as Element), false)
    assert.equal(isMarkedRoot({ closest: () => ({}) } as unknown as Element), true)
  })

  it('publishes window.__zhHantHk__ for other plugins', () => {
    globalThis.window = {} as Window & typeof globalThis
    try {
      installZhHantHook()
      const api = (globalThis.window as unknown as { __zhHantHk__?: ZhHantHkApi }).__zhHantHk__
      assert.ok(api)
      assert.equal(api?.convertText('设置'), '設定')
      assert.equal(typeof api?.toTraditional, 'function')
      assert.equal(typeof api?.applyPhrases, 'function')
      assert.equal(typeof api?.isMarked, 'function')
      assert.equal(typeof api?.mark, 'function')
    } finally {
      delete (globalThis as { window?: unknown }).window
    }
  })
})
