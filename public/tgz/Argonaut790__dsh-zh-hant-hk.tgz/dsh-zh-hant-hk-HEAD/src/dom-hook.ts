import { applyHkPhrases } from './apply-phrases.js'
import { toTraditional } from './s2t.js'

/** Opt-in marker a plugin sets on its own UI root to get full conversion. */
export const MARKED_SELECTOR = '[data-zh-hant]'

/**
 * Full Hong Kong conversion for a plugin-owned string: character-level
 * Simplified → Traditional, then the HK phrase table.
 */
export function convertPluginText(text: string): string {
  return applyHkPhrases(toTraditional(text))
}

/**
 * True when el (or an ancestor) opted in via `data-zh-hant` / mark().
 * Text inside opted-in roots is fully converted; everything else only gets
 * the exact English permission-label rewrite, so user content stays intact.
 */
export function isMarkedRoot(el: Element | null): boolean {
  return el !== null && el.closest(MARKED_SELECTOR) !== null
}

/** Facade handed to other plugins as `window.__zhHantHk__`. */
export interface ZhHantHkApi {
  /** Character-level Simplified → Traditional (leaves everything else). */
  toTraditional(text: string): string
  /** Hong Kong lexical replacements (設置 → 設定, 會話 → 對話, …). */
  applyPhrases(text: string): string
  /** applyPhrases(toTraditional(text)) — the full conversion. */
  convertText(text: string): string
  /** True when el (or an ancestor) opted in. */
  isMarked(el: Element): boolean
  /** Opt a UI root in: its text nodes are converted while zh-Hant is active. */
  mark(el: Element): Element
}

declare global {
  interface Window {
    __zhHantHk__?: ZhHantHkApi
  }
}

/**
 * Publish the opt-in conversion API for other plugins.
 * Overwriting on re-apply keeps HMR-reloaded copies fresh; the functions are
 * stateless so a plugin holding an old reference still gets identical output.
 */
export function installZhHantHook(): void {
  if (typeof window === 'undefined') return
  window.__zhHantHk__ = {
    toTraditional,
    applyPhrases: applyHkPhrases,
    convertText: convertPluginText,
    isMarked: (el) => isMarkedRoot(el),
    mark(el) {
      el.setAttribute('data-zh-hant', '')
      return el
    },
  }
}
