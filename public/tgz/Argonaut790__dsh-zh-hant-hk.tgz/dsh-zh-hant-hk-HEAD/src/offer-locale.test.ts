import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { offerZhHant, type LocaleRuntimeLike, type SettingsScopeLike } from './offer-locale.js'

function mockRuntime(active = 'zh'): LocaleRuntimeLike & {
  snapshot: { active: string; locales: { id: string; label: string }[]; revision: number }
} {
  const locale: LocaleRuntimeLike & {
    snapshot: { active: string; locales: { id: string; label: string }[]; revision: number }
  } = {
    snapshot: {
      active,
      locales: [
        { id: 'zh', label: '中文' },
        { id: 'en', label: 'English' },
      ],
      revision: 0,
    },
    getLocale() {
      return locale.snapshot
    },
    setLocale(id: string) {
      const match = locale.snapshot.locales.find((item) => item.id === id)
      if (match === undefined) throw new Error(`locale "${id}" is not registered`)
      locale.publish?.(match.id, true)
    },
    publish(next: string) {
      locale.snapshot = {
        ...locale.snapshot,
        active: next,
        revision: locale.snapshot.revision + 1,
      }
    },
  }
  return locale
}

function mockScope(initial?: boolean) {
  let enabled = initial ?? false
  const listeners = new Set<() => void>()
  return {
    getSnapshot() {
      return { value: { enabled } }
    },
    subscribe(fn: () => void) {
      listeners.add(fn)
      return () => { listeners.delete(fn) }
    },
    set(field: string, value: unknown) {
      if (field === 'enabled') enabled = Boolean(value)
      for (const fn of listeners) fn()
    },
  }
}

describe('offerZhHant', () => {
  it('adds 繁體中文 and can select it', () => {
    const locale = mockRuntime('zh')
    offerZhHant(locale, mockScope())
    assert.ok(locale.getLocale().locales?.some((item) => item.id === 'zh-Hant'))
    locale.setLocale?.('zh-Hant')
    assert.equal(locale.getLocale().active, 'zh-Hant')
  })

  it('is idempotent and can return to 中文', () => {
    const locale = mockRuntime('en')
    const scope = mockScope()
    offerZhHant(locale, scope)
    offerZhHant(locale, scope)
    const hant = locale.getLocale().locales?.filter((item) => item.id === 'zh-Hant') ?? []
    assert.equal(hant.length, 1)
    locale.setLocale?.('zh-Hant')
    locale.setLocale?.('zh')
    assert.equal(locale.getLocale().active, 'zh')
  })

  it('persists the toggle through the settings scope', () => {
    const locale = mockRuntime('zh')
    const scope = mockScope()
    offerZhHant(locale, scope)
    locale.setLocale?.('zh-Hant')
    assert.equal(scope.getSnapshot().value.enabled, true)
    locale.setLocale?.('zh')
    assert.equal(scope.getSnapshot().value.enabled, false)
  })

  it('restores 繁體中文 when the scope already reports enabled', () => {
    const locale = mockRuntime('zh')
    offerZhHant(locale, mockScope(true))
    assert.equal(locale.getLocale().active, 'zh-Hant')
  })
})
