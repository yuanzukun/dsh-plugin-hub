import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { applyHkPhrases, rewriteExactUiLabel } from './apply-phrases.js'

describe('applyHkPhrases', () => {
  it('leaves unrelated English unchanged', () => {
    assert.equal(applyHkPhrases('New Session'), 'New Session')
  })

  it('rewrites hardcoded permission product labels', () => {
    assert.equal(applyHkPhrases('Read Only'), '唯讀')
    assert.equal(applyHkPhrases('Workspace Write'), '工作區寫入')
    assert.equal(applyHkPhrases('Full access'), '完整存取')
    assert.equal(applyHkPhrases('確認啟用 Full access？'), '確認啟用完整存取？')
    assert.equal(applyHkPhrases('訪問模式，當前：Full access'), '訪問模式，當前：完整存取')
    assert.equal(applyHkPhrases('Enable Full access'), '啟用完整存取')
    assert.equal(applyHkPhrases('Default'), '預設')
    assert.equal(applyHkPhrases('plan mode 已開啟，按下關閉'), 'plan mode 已開啟，按下關閉')
    assert.equal(applyHkPhrases('正在加載 skill'), '正在載入 skill')
    assert.equal(applyHkPhrases('Agent 預設'), 'Agent 預設')
    assert.equal(applyHkPhrases('啟用 Full access 後，agent 將減少確認步驟'), '啟用完整存取後，agent 將減少確認步驟')
    assert.equal(applyHkPhrases('此子代理暫時只讀'), '此 sub-agent 暫時唯讀')
    assert.equal(applyHkPhrases('{n} 個子代理運行中'), '{n} 個 sub-agent 運行中')
    assert.equal(applyHkPhrases('支持檔案編輯'), '支援檔案編輯')
    assert.equal(applyHkPhrases('API Key'), 'API Key')
    assert.equal(applyHkPhrases('Think'), 'Think')
  })

  it('rewrites an exact product-label text node only', () => {
    assert.equal(rewriteExactUiLabel('Full access'), '完整存取')
    assert.equal(rewriteExactUiLabel('Think'), 'Think')
    assert.equal(rewriteExactUiLabel('Default'), '預設')
    assert.equal(rewriteExactUiLabel('  Read Only  '), '  唯讀  ')
    assert.equal(rewriteExactUiLabel('use Read Only mode'), 'use Read Only mode')
  })

  it('rewrites stock Traditional calques into Hong Kong wording', () => {
    assert.equal(applyHkPhrases('新會話'), '新對話')
    assert.equal(applyHkPhrases('展開其餘 3 個會話'), '展開其餘 3 個對話')
    assert.equal(applyHkPhrases('設置'), '設定')
    assert.equal(applyHkPhrases('通用設置'), '一般設定')
    assert.equal(applyHkPhrases('保存'), '儲存')
    assert.equal(applyHkPhrases('加載中…'), '載入中…')
    assert.equal(applyHkPhrases('重命名會話'), '重新命名對話')
    assert.equal(applyHkPhrases('歸檔會話'), '封存對話')
    assert.equal(applyHkPhrases('分叉會話'), '分支對話')
    assert.equal(applyHkPhrases('打開配置文件'), '開啟設定檔')
    assert.equal(applyHkPhrases('給智能體發消息'), '向 Agent 傳送訊息')
    assert.equal(applyHkPhrases('資料夾'), '檔案夾')
    assert.equal(applyHkPhrases('緩存命中'), '快取命中')
    assert.equal(applyHkPhrases('復制成功'), '複製成功')
    assert.equal(applyHkPhrases('{n}分鍾'), '{n}分鐘')
    assert.equal(applyHkPhrases('視圖選項'), '檢視選項')
    assert.equal(applyHkPhrases('空閒'), '閒置')
    assert.equal(applyHkPhrases('對話'), '對話')
    assert.equal(applyHkPhrases('描述你想要構建的內容'), '描述你想要建立的內容')
  })
})
