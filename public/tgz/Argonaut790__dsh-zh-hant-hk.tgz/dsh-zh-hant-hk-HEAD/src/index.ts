import z from 'schemastery'

/** Host loader entry. The wording patch lives in the browser half. */
export const name = 'zh-hant-hk'

/** User-settings namespace persisting the Traditional Chinese toggle. */
const PREF_NS = 'dsh-zh-hant-hk'

/** Schemastery schema validated and persisted by the Host settings service. */
const PrefsSchema = z.object({
  enabled: z.boolean().default(false),
})

/**
 * Register the plugin's settings namespace so the browser half can persist
 * the 繁體中文 toggle in the Host user-settings document (settings.yaml)
 * instead of origin-scoped localStorage, which the Desktop app's random
 * web port wipes on every launch.
 */
export function apply(ctx: {
  inject(deps: string[], cb: (sctx: { settings: { register(ns: string, schema: unknown): unknown } }) => void): void
}): void {
  ctx.inject(['settings'], (sctx) => {
    sctx.settings.register(PREF_NS, PrefsSchema)
  })
}
