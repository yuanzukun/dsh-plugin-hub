import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { rewriteTextNode } from './watch-labels.js'

/** Fake element whose closest() reports an opted-in root. */
const marked = (): Element => ({ closest: () => ({}) }) as unknown as Element
/** Fake element with no opted-in ancestor. */
const plain = (): Element => ({ closest: () => null }) as unknown as Element

describe('rewriteTextNode', () => {
  it('fully converts text inside an opted-in plugin root', () => {
    assert.equal(rewriteTextNode('设置', marked()), '設定')
    assert.equal(rewriteTextNode('会话', marked()), '對話')
  })

  it('leaves unmarked text alone (user content is safe)', () => {
    assert.equal(rewriteTextNode('设置', plain()), '设置')
    assert.equal(rewriteTextNode('会话', plain()), '会话')
  })

  it('still rewrites exact English permission labels outside marked roots', () => {
    assert.equal(rewriteTextNode('Read Only', plain()), '唯讀')
    assert.equal(rewriteTextNode('Full access', plain()), '完整存取')
  })

  it('does not rewrite a sentence that merely mentions an English label', () => {
    assert.equal(rewriteTextNode('Click Full access to continue', plain()), 'Click Full access to continue')
  })
})
