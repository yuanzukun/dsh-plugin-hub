import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { toTraditional } from './s2t.js'

describe('toTraditional', () => {
  it('converts official Simplified chrome to Traditional', () => {
    assert.equal(toTraditional('设置'), '設置')
    assert.equal(toTraditional('语言'), '語言')
    assert.equal(toTraditional('新会话'), '新會話')
    assert.equal(toTraditional('外观'), '外觀')
  })

  it('leaves Traditional and English alone', () => {
    assert.equal(toTraditional('設置'), '設置')
    assert.equal(toTraditional('Read Only'), 'Read Only')
  })
})
