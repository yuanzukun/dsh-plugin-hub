import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { HK_PHRASES, UI_LABELS } from './phrases.js'

function assertLongestFirst(pairs: readonly [string, string][], label: string): void {
  for (let i = 1; i < pairs.length; i++) {
    const prev = pairs[i - 1]![0]
    const cur = pairs[i]![0]
    assert.ok(
      prev.length >= cur.length,
      `${label} order: "${prev}" (${prev.length}) must precede "${cur}" (${cur.length})`,
    )
  }
}

describe('phrase tables', () => {
  it('keeps longer keys before shorter ones', () => {
    assertLongestFirst(UI_LABELS, 'UI_LABELS')
    assertLongestFirst(HK_PHRASES, 'HK_PHRASES')
  })
})
