import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import { apply, type LocaleLike } from './client.js'
import type { SettingsScopeLike } from './offer-locale.js'

function mockLocale(active: string): LocaleLike & { revision: number } {
  const dicts = new Map<string, Record<string, string>>()
  const locale: LocaleLike & { revision: number } = {
    revision: 0,
    translate(ns, key, params) {
      const template = dicts.get(ns)?.[key] ?? key
      if (!params) return template
      return template.replace(/\{(\w+)\}/g, (match, name) =>
        name in params ? String(params[name]) : match,
      )
    },
    bind(ns) {
      return (key, params) => locale.translate(ns, key, params)
    },
    getLocale() {
      return { active }
    },
    register(ns, _locale, dict) {
      dicts.set(ns, dict)
      locale.revision += 1
      return () => { dicts.delete(ns) }
    },
  }
  locale.register('workspace', 'zh-Hant', {
    'session.new': '新會話',
    'settings': '設置',
    'access.confirm.title': '確認啟用 Full access？',
  })
  return locale
}

function mockSettingsScopeBinder(): { bind(): SettingsScopeLike } {
  return {
    bind() {
      let enabled = false
      return {
        getSnapshot: () => ({ value: { enabled } }),
        subscribe: () => () => {},
        set: (_field, value) => { enabled = Boolean(value) },
      }
    },
  }
}

describe('client apply', () => {
  it('rewrites zh-Hant bind output and is idempotent', () => {
    const locale = mockLocale('zh-Hant')
    const ctx = { locale, settingsScope: mockSettingsScopeBinder() }
    apply(ctx)
    apply(ctx)
    const t = locale.bind('workspace')
    assert.equal(t('session.new'), '新對話')
    assert.equal(t('settings'), '設定')
    assert.equal(t('access.confirm.title'), '確認啟用完整存取？')
    assert.ok(locale.revision >= 1)
  })

  it('leaves simplified Chinese alone', () => {
    const locale = mockLocale('zh')
    locale.register('workspace', 'zh', { 'session.new': '新会话' })
    apply({ locale, settingsScope: mockSettingsScopeBinder() })
    assert.equal(locale.bind('workspace')('session.new'), '新会话')
  })

  it('converts official Simplified chrome when zh-Hant is active', () => {
    const locale = mockLocale('zh-Hant')
    locale.register('workspace', 'zh', {
      'session.new': '新会话',
      'settings': '设置',
    })
    apply({ locale, settingsScope: mockSettingsScopeBinder() })
    const t = locale.bind('workspace')
    assert.equal(t('session.new'), '新對話')
    assert.equal(t('settings'), '設定')
  })

  it('converts a t captured before apply (other-plugin ordering hole)', () => {
    const locale = mockLocale('zh-Hant')
    const early = locale.bind('workspace')
    apply({ locale, settingsScope: mockSettingsScopeBinder() })
    assert.equal(early('session.new'), '新對話')
  })
})
