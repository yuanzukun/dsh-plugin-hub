import { applyHkPhrases, rewriteExactUiLabel } from './apply-phrases.js'
import { convertPluginText, isMarkedRoot } from './dom-hook.js'
import { toTraditional } from './s2t.js'

const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT', 'CODE', 'PRE'])

/**
 * Decide the rewrite for one text node: full Hong Kong conversion inside an
 * opted-in plugin root (`data-zh-hant`), exact permission-label rewrite
 * everywhere else — user content is never touched.
 * @param raw - raw text-node value.
 * @param parent - the node's parent element (null when unknown).
 */
export function rewriteTextNode(raw: string, parent: Element | null): string {
  return isMarkedRoot(parent) ? convertPluginText(raw) : rewriteExactUiLabel(raw)
}

/**
 * Walk visible chrome: full-convert opted-in plugin roots, replace hardcoded
 * English permission labels elsewhere.
 * @param root - document or a mutated subtree.
 */
export function rewriteUiLabelTree(root: ParentNode): void {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement
      if (parent === null) return NodeFilter.FILTER_REJECT
      if (SKIP_TAGS.has(parent.tagName) || parent.isContentEditable) {
        return NodeFilter.FILTER_REJECT
      }
      return NodeFilter.FILTER_ACCEPT
    },
  })
  let node = walker.nextNode()
  while (node !== null) {
    const raw = node.nodeValue
    if (raw !== null) {
      const next = rewriteTextNode(raw, node.parentElement)
      if (next !== raw) node.nodeValue = next
    }
    node = walker.nextNode()
  }

  const scope = root instanceof Element ? root : document.body
  if (scope === null) return
  for (const el of scope.querySelectorAll<HTMLElement>('[aria-label], [title]')) {
    const label = el.getAttribute('aria-label')
    if (label !== null) {
      const next = applyHkPhrases(toTraditional(label))
      if (next !== label) el.setAttribute('aria-label', next)
    }
    const title = el.getAttribute('title')
    if (title !== null) {
      const next = applyHkPhrases(toTraditional(title))
      if (next !== title) el.setAttribute('title', next)
    }
  }
}

/**
 * Keep rewriting permission labels after React puts the English strings back.
 * @param isZhHant - true while the active UI locale is zh-Hant.
 */
export function watchUiLabels(isZhHant: () => boolean): void {
  if (typeof document === 'undefined') return

  let scheduled = false
  const run = (): void => {
    scheduled = false
    if (!isZhHant() || document.body === null) return
    rewriteUiLabelTree(document.body)
  }
  const schedule = (): void => {
    if (scheduled) return
    scheduled = true
    requestAnimationFrame(run)
  }

  const start = (): void => {
    if (document.body === null) {
      document.addEventListener('DOMContentLoaded', start, { once: true })
      return
    }
    const observer = new MutationObserver(schedule)
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['aria-label', 'title', 'data-zh-hant'],
    })
    run()
  }
  start()
}
