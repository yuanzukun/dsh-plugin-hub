import { HK_PHRASES, UI_LABELS } from './phrases.js'

const EXACT_UI_LABELS = new Map(UI_LABELS)

/**
 * Apply Hong Kong lexical replacements to UI text.
 * English product labels (Read Only, Full access, …) are rewritten even
 * when the string has no Chinese. Other English is left alone.
 * @param text - stock copy, Traditional or mixed.
 * @returns Hong Kong wording.
 */
export function applyHkPhrases(text: string): string {
  if (typeof text !== 'string' || text.length === 0) return text
  let out = text
  for (const [from, to] of UI_LABELS) {
    if (out.includes(from)) out = out.split(from).join(to)
  }
  for (const [from, to] of HK_PHRASES) {
    if (out.includes(from)) out = out.split(from).join(to)
  }
  return out
}

/**
 * Rewrite a text node only when its trimmed value is an exact product label.
 * Avoids touching user messages that merely mention those English words.
 * @param text - raw text-node value, possibly with surrounding whitespace.
 * @returns localized label, or the original string.
 */
export function rewriteExactUiLabel(text: string): string {
  const trimmed = text.trim()
  const mapped = EXACT_UI_LABELS.get(trimmed)
  if (mapped === undefined) return text
  return text.replace(trimmed, mapped)
}
