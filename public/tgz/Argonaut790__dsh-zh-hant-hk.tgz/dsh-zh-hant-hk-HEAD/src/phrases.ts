/**
 * Hardcoded English product labels. These often never go through
 * `locale.bind`; they are rewritten in bind output and as exact DOM text.
 * Longer keys must stay first.
 *
 * Hong Kong UI keeps product words in English (Agent, skill, Think,
 * plan mode, API Key). Only translate ordinary chrome.
 */
export const UI_LABELS: readonly [string, string][] = [
  ['Enable Full access?', '啟用完整存取？'],
  ['Enable Full access', '啟用完整存取'],
  ['Workspace Write', '工作區寫入'],
  [' Full access ', '完整存取'],
  [' Full access', '完整存取'],
  ['Full access', '完整存取'],
  ['Read Only', '唯讀'],
  ['Default', '預設'],
]

/**
 * Hong Kong wording applied to already-Traditional DeepSeek Harness copy.
 *
 * The stock harness converts Simplified → Traditional character-by-character
 * (会话 → 會話). These replacements run after that pass. Longer keys must
 * stay first so a short key cannot nibble a longer one.
 */
export const HK_PHRASES: readonly [string, string][] = [
  ['Agent preset', 'Agent 預設'],
  ['給智能體發消息', '向 Agent 傳送訊息'],
  ['給智能體發訊息', '向 Agent 傳送訊息'],
  ['智能體預設', 'Agent 預設'],
  ['智能體循環', 'Agent 循環'],
  ['通用設置', '一般設定'],
  ['配置文件', '設定檔'],
  ['子智能體', ' sub-agent '],
  ['已啓用', '已啟用'],
  ['文件夾', '檔案夾'],
  ['資料夾', '檔案夾'],
  ['重命名', '重新命名'],
  ['隱私權', '私隱權'],
  ['子代理', ' sub-agent '],
  ['智能體', 'Agent'],
  ['自定義', '自訂'],
  ['保存', '儲存'],
  ['信息', '資訊'],
  ['內存', '記憶體'],
  ['分叉', '分支'],
  ['分鍾', '分鐘'],
  ['刷新', '重新整理'],
  ['創建', '建立'],
  ['加載', '載入'],
  ['命令', '指令'],
  ['啓用', '啟用'],
  ['後臺', '後台'],
  ['復制', '複製'],
  ['打開', '開啟'],
  ['搜索', '搜尋'],
  ['收起', '收合'],
  ['文件', '檔案'],
  ['會話', '對話'],
  ['歸檔', '封存'],
  ['注冊', '註冊'],
  ['消息', '訊息'],
  ['添加', '新增'],
  ['登錄', '登入'],
  ['發送', '傳送'],
  ['短信', '短訊'],
  ['空閒', '閒置'],
  ['粘貼', '貼上'],
  ['緩存', '快取'],
  ['行爲', '行為'],
  ['視圖', '檢視'],
  ['視頻', '影片'],
  ['設置', '設定'],
  ['詳情', '詳細資料'],
  ['賬戶', '帳戶'],
  ['跳過', '略過'],
  ['郵箱', '電郵'],
  ['開啓', '開啟'],
  ['隱私', '私隱'],
  ['默認', '預設'],
  ['構建', '建立'],
  ['支持', '支援'],
  ['導出', '匯出'],
  ['只讀', '唯讀'],
  ['裏', '裡'],
]
