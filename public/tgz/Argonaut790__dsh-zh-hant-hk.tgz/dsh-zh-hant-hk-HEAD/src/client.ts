import { applyHkPhrases } from './apply-phrases.js'
import { installZhHantHook } from './dom-hook.js'
import { offerZhHant, type SettingsScopeLike } from './offer-locale.js'
import { toTraditional } from './s2t.js'
import { watchUiLabels } from './watch-labels.js'

const PATCHED = Symbol.for('dsh-zh-hant-hk')

/** User-settings namespace persisted by the Host half (see index.ts). */
const PREF_NS = 'dsh-zh-hant-hk'

/** Minimal locale service face used by this plugin. */
export interface LocaleLike {
  bind(ns: string): (key: string, params?: Record<string, unknown>) => string
  translate(ns: string, key: string, params?: Record<string, unknown>): string
  getLocale(): { active: string }
  register(ns: string, locale: string, dict: Record<string, string>): () => void
}

/** Wait for the stock locale service and the settings transport. */
export const inject = ['locale', 'connection', 'remote', 'settingsScope']

/**
 * Wrap `locale.translate` so zh-Hant strings get Hong Kong wording.
 * `locale.bind` returns closures that call `this.translate` at call time, so a
 * translate-level patch reaches `t` functions other plugins captured before
 * this plugin applied — a bind-level wrap could not, and every plugin's
 * strings (official or third-party) ride the same translate path.
 * Bumps the locale revision so already-mounted UI seats rebind.
 * @param ctx - client context that already provides `locale`.
 */
export function apply(ctx: {
  locale: LocaleLike
  settingsScope: { bind(spec: { namespace: string }): SettingsScopeLike }
}): void {
  const locale = ctx.locale
  const marked = locale as LocaleLike & { [PATCHED]?: boolean }
  if (marked[PATCHED]) return
  marked[PATCHED] = true

  const originalTranslate = locale.translate.bind(locale)
  locale.translate = (ns, key, params) => {
    const text = originalTranslate(ns, key, params)
    return locale.getLocale().active === 'zh-Hant'
      ? applyHkPhrases(toTraditional(text))
      : text
  }

  offerZhHant(locale, ctx.settingsScope.bind({ namespace: PREF_NS }))

  // Registry change publishes a new revision; render seats re-derive `t`.
  locale.register('dsh-zh-hant-hk', 'zh', { _: '_' })
  watchUiLabels(() => locale.getLocale().active === 'zh-Hant')
  installZhHantHook()
}
