const ZH_HANT = { id: 'zh-Hant', label: '繁體中文' } as const
const PREF_FIELD = 'enabled'

export type LocaleOption = { id: string; label: string }

/** Runtime face of official LocaleRuntime (some fields are JS-public only). */
export type LocaleRuntimeLike = {
  getLocale(): { active: string; locales?: readonly LocaleOption[]; revision?: number }
  snapshot?: { active: string; locales: readonly LocaleOption[]; revision: number }
  setLocale?(id: string): void
  publish?(active: string, localeChanged: boolean): void
  adopt?(host: unknown): void
}

/** Minimal settings-scope face used to persist the toggle in settings.yaml. */
export type SettingsScopeLike = {
  getSnapshot(): { value?: { enabled?: boolean } }
  subscribe(listener: () => void): () => void
  set(field: string, value: unknown): unknown
}

export function readZhHantPref(scope?: SettingsScopeLike): boolean {
  return scope?.getSnapshot().value?.enabled === true
}

export function writeZhHantPref(scope: SettingsScopeLike | undefined, on: boolean): void {
  scope?.set(PREF_FIELD, on)
}

/**
 * Put 繁體中文 in the official Language menu and keep the selection alive
 * across restarts by persisting it in the Host settings document instead of
 * localStorage (which the Desktop app's random web port clears every launch).
 */
export function offerZhHant(locale: LocaleRuntimeLike, scope?: SettingsScopeLike): void {
  const snap = locale.getLocale()
  const locales = snap.locales
  if (locales && !locales.some((item) => item.id === 'zh-Hant') && locale.snapshot) {
    locale.snapshot = Object.freeze({
      active: snap.active,
      locales: Object.freeze([...locales, ZH_HANT]),
      revision: snap.revision ?? 0,
    })
    locale.publish?.(snap.active, true)
  }

  const restore = () => {
    if (readZhHantPref(scope) && locale.getLocale().active !== 'zh-Hant') {
      locale.publish?.('zh-Hant', true)
    }
  }

  const originalSet = locale.setLocale?.bind(locale)
  if (originalSet) {
    locale.setLocale = (id: string) => {
      if (id === 'zh-Hant') {
        writeZhHantPref(scope, true)
        const active = locale.getLocale().active
        if (active !== 'zh' && active !== 'zh-Hant') originalSet('zh')
        locale.publish?.('zh-Hant', true)
        return
      }
      writeZhHantPref(scope, false)
      originalSet(id)
    }
  }

  // Re-apply after the settings scope finishes its background load, and on
  // any later change (e.g. another client window toggling the preference).
  scope?.subscribe?.(restore)

  const originalAdopt = locale.adopt?.bind(locale)
  if (originalAdopt) {
    locale.adopt = (host: unknown) => {
      originalAdopt(host)
      restore()
    }
  }

  restore()
}
