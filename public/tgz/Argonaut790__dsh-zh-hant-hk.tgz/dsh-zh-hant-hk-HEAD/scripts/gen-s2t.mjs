import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const raw = readFileSync(join(process.env.TEMP, 'STCharacters.txt'), 'utf8')
const s = []
const t = []
for (const line of raw.split(/\r?\n/)) {
  if (!line || line.startsWith('#')) continue
  const [from, rest] = line.split('\t')
  if (!from || !rest) continue
  const to = rest.trim().split(/\s+/)[0]
  if (!to || from === to) continue
  if ([...from].length !== 1 || [...to].length !== 1) continue
  s.push(from)
  t.push(to)
}

const src = `/**
 * Character-level Simplified → Traditional.
 * Table from OpenCC STCharacters (Apache-2.0):
 * https://github.com/BYVoid/OpenCC
 */
const S = ${JSON.stringify(s.join(''))}
const T = ${JSON.stringify(t.join(''))}
const FROM = [...S]
const TO = [...T]
const MAP = new Map<string, string>()
for (let i = 0; i < FROM.length; i++) MAP.set(FROM[i]!, TO[i]!)

/** Convert Simplified characters; leave everything else as-is. */
export function toTraditional(text: string): string {
  if (typeof text !== 'string' || text.length === 0) return text
  let out = ''
  for (const ch of text) out += MAP.get(ch) ?? ch
  return out
}
`

const out = join(dirname(fileURLToPath(import.meta.url)), '..', 'src', 's2t.ts')
writeFileSync(out, src, 'utf8')
console.log('pairs', s.length, 'bytes', Buffer.byteLength(src))
