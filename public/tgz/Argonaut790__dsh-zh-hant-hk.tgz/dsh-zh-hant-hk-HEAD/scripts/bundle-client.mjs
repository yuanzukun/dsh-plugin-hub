import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const lib = join(root, 'lib')

/**
 * Drop ESM import/export so the files can live inside a CJS factory.
 * @param source - tsc-emitted ESM.
 * @returns statements only.
 */
function stripEsm(source) {
  return source
    .replace(/^import\b.*$/gm, '')
    .replace(/^export /gm, '')
    .trim()
}

const body = [
  stripEsm(readFileSync(join(lib, 'phrases.js'), 'utf8')),
  stripEsm(readFileSync(join(lib, 's2t.js'), 'utf8')),
  stripEsm(readFileSync(join(lib, 'apply-phrases.js'), 'utf8')),
  stripEsm(readFileSync(join(lib, 'offer-locale.js'), 'utf8')),
  stripEsm(readFileSync(join(lib, 'dom-hook.js'), 'utf8')),
  stripEsm(readFileSync(join(lib, 'watch-labels.js'), 'utf8')),
  stripEsm(readFileSync(join(lib, 'client.js'), 'utf8')),
].join('\n\n')

const bundle = `window.__ModuleLoader__.load({
	id: "dsh-zh-hant-hk",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
${body.split('\n').map((line) => (line.length === 0 ? '' : `\t\t${line}`)).join('\n')}
		exports.apply = apply;
		exports.inject = inject;
		return module.exports;
	}
});
`

writeFileSync(join(lib, 'client.bundle.js'), bundle)
