/**
 * Decide the rewrite for one text node: full Hong Kong conversion inside an
 * opted-in plugin root (`data-zh-hant`), exact permission-label rewrite
 * everywhere else — user content is never touched.
 * @param raw - raw text-node value.
 * @param parent - the node's parent element (null when unknown).
 */
export declare function rewriteTextNode(raw: string, parent: Element | null): string;
/**
 * Walk visible chrome: full-convert opted-in plugin roots, replace hardcoded
 * English permission labels elsewhere.
 * @param root - document or a mutated subtree.
 */
export declare function rewriteUiLabelTree(root: ParentNode): void;
/**
 * Keep rewriting permission labels after React puts the English strings back.
 * @param isZhHant - true while the active UI locale is zh-Hant.
 */
export declare function watchUiLabels(isZhHant: () => boolean): void;
