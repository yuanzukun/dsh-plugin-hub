import { type SettingsScopeLike } from './offer-locale.js';
/** Minimal locale service face used by this plugin. */
export interface LocaleLike {
    bind(ns: string): (key: string, params?: Record<string, unknown>) => string;
    translate(ns: string, key: string, params?: Record<string, unknown>): string;
    getLocale(): {
        active: string;
    };
    register(ns: string, locale: string, dict: Record<string, string>): () => void;
}
/** Wait for the stock locale service and the settings transport. */
export declare const inject: string[];
/**
 * Wrap `locale.translate` so zh-Hant strings get Hong Kong wording.
 * `locale.bind` returns closures that call `this.translate` at call time, so a
 * translate-level patch reaches `t` functions other plugins captured before
 * this plugin applied — a bind-level wrap could not, and every plugin's
 * strings (official or third-party) ride the same translate path.
 * Bumps the locale revision so already-mounted UI seats rebind.
 * @param ctx - client context that already provides `locale`.
 */
export declare function apply(ctx: {
    locale: LocaleLike;
    settingsScope: {
        bind(spec: {
            namespace: string;
        }): SettingsScopeLike;
    };
}): void;
