/**
 * Apply Hong Kong lexical replacements to UI text.
 * English product labels (Read Only, Full access, …) are rewritten even
 * when the string has no Chinese. Other English is left alone.
 * @param text - stock copy, Traditional or mixed.
 * @returns Hong Kong wording.
 */
export declare function applyHkPhrases(text: string): string;
/**
 * Rewrite a text node only when its trimmed value is an exact product label.
 * Avoids touching user messages that merely mention those English words.
 * @param text - raw text-node value, possibly with surrounding whitespace.
 * @returns localized label, or the original string.
 */
export declare function rewriteExactUiLabel(text: string): string;
