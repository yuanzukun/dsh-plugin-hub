/** Convert Simplified characters; leave everything else as-is. */
export declare function toTraditional(text: string): string;
