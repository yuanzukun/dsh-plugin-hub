export type LocaleOption = {
    id: string;
    label: string;
};
/** Runtime face of official LocaleRuntime (some fields are JS-public only). */
export type LocaleRuntimeLike = {
    getLocale(): {
        active: string;
        locales?: readonly LocaleOption[];
        revision?: number;
    };
    snapshot?: {
        active: string;
        locales: readonly LocaleOption[];
        revision: number;
    };
    setLocale?(id: string): void;
    publish?(active: string, localeChanged: boolean): void;
    adopt?(host: unknown): void;
};
/** Minimal settings-scope face used to persist the toggle in settings.yaml. */
export type SettingsScopeLike = {
    getSnapshot(): {
        value?: {
            enabled?: boolean;
        };
    };
    subscribe(listener: () => void): () => void;
    set(field: string, value: unknown): unknown;
};
export declare function readZhHantPref(scope?: SettingsScopeLike): boolean;
export declare function writeZhHantPref(scope: SettingsScopeLike | undefined, on: boolean): void;
/**
 * Put 繁體中文 in the official Language menu and keep the selection alive
 * across restarts by persisting it in the Host settings document instead of
 * localStorage (which the Desktop app's random web port clears every launch).
 */
export declare function offerZhHant(locale: LocaleRuntimeLike, scope?: SettingsScopeLike): void;
