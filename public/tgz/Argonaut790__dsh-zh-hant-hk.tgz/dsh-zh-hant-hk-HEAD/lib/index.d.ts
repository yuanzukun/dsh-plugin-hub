/** Host loader entry. The wording patch lives in the browser half. */
export declare const name = "zh-hant-hk";
/**
 * Register the plugin's settings namespace so the browser half can persist
 * the 繁體中文 toggle in the Host user-settings document (settings.yaml)
 * instead of origin-scoped localStorage, which the Desktop app's random
 * web port wipes on every launch.
 */
export declare function apply(ctx: {
    inject(deps: string[], cb: (sctx: {
        settings: {
            register(ns: string, schema: unknown): unknown;
        };
    }) => void): void;
}): void;
