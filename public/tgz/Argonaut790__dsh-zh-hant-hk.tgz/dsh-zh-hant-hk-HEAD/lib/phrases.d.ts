/**
 * Hardcoded English product labels. These often never go through
 * `locale.bind`; they are rewritten in bind output and as exact DOM text.
 * Longer keys must stay first.
 *
 * Hong Kong UI keeps product words in English (Agent, skill, Think,
 * plan mode, API Key). Only translate ordinary chrome.
 */
export declare const UI_LABELS: readonly [string, string][];
/**
 * Hong Kong wording applied to already-Traditional DeepSeek Harness copy.
 *
 * The stock harness converts Simplified → Traditional character-by-character
 * (会话 → 會話). These replacements run after that pass. Longer keys must
 * stay first so a short key cannot nibble a longer one.
 */
export declare const HK_PHRASES: readonly [string, string][];
