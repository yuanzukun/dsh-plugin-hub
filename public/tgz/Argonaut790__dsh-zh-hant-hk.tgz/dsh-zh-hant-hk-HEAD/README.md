# dsh-zh-hant-hk

Hong Kong Traditional Chinese wording for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness).

The official UI converts Simplified Chinese to Traditional **character by character**. That turns mainland software terms into strings Hong Kong people do not say:

| Stock 繁體 | This plugin |
|---|---|
| 新會話 | **新對話** |
| 設置 | **設定** |
| 保存 | **儲存** |
| 加載中 | **載入中** |
| 重命名 | **重新命名** |
| 資料夾 | **檔案夾** |
| 默認 | **預設** |
| Read Only | **唯讀** |
| Workspace Write | **工作區寫入** |
| Full access | **完整存取** |
| 子代理 | **sub-agent** |

Product words stay English, as Hong Kong UI usually does: **Agent**, **sub-agent**, **skill**, **Think**, **plan mode**, **API Key**.

The Conversation tab is already 「對話」. After this plugin, “New session” matches it.

Official DeepSeek Harness currently only lists **中文** and **English**. This plugin adds **繁體中文** to that menu, converts Simplified chrome to Traditional, then applies the Hong Kong wording above.

## Install

From any directory:

```bash
dsh plugin --profile web add github:Argonaut790/dsh-zh-hant-hk
```

Or from a local checkout:

```bash
dsh plugin --profile web add /home/you/Programming/dsh-zh-hant-hk
```

Then restart (or refresh) `dsh web` and set the UI language to **繁體中文**.

Remove with:

```bash
dsh plugin --profile web remove dsh-zh-hant-hk
```

A checkout that already contains `lib/` installs without a build step. After you edit sources, run `npm test` (that rebuilds `lib/` and the Harness client bundle). The file Harness loads is `lib/client.bundle.js`, not the plain TypeScript emit.

## How it works

This package is a DeepSeek Harness **profile bundle**:

1. `cordis.patch.yml` inserts the plugin into the composed loader tree.
2. The browser half waits for `locale`, adds **繁體中文** to the Language menu, wraps `locale.translate` (the single path every bound `t` runs through), converts Simplified chrome to Traditional, and applies the Hong Kong phrase table only when the active locale is `zh-Hant`.
3. Hardcoded English permission labels (`Read Only`, `Workspace Write`, `Full access`) are rewritten in the DOM, because those strings never go through the locale service.
4. The browser loads `lib/client.bundle.js`, which registers through Harness `window.__ModuleLoader__`. Plain `tsc` output cannot be served as the client entry.
5. Simplified Chinese and English are unchanged.

It does not fork the harness and does not rewrite every string by hand.

## Other plugins

**Anything that renders through the locale service is covered automatically.** The `locale.translate` wrap is service-wide: whether a plugin registers its own namespace and binds it at boot, or re-derives `t` per render, its output is converted when 繁體中文 is active — including `t` functions another plugin captured *before* this plugin loaded (they call `this.translate` at call time, so the patch still catches them). Plugins that only ship `en` dictionaries stay English, matching the HK convention of keeping product words in English.

**Hardcoded strings need an opt-in.** To protect user content, text nodes are not converted wholesale. A plugin that hardcodes Simplified Chinese in its own UI opts its root in, and this plugin's DOM watcher converts it (and keeps converting after re-renders):

```js
// plain DOM / vanilla JS
window.__zhHantHk__.mark(myRootEl)

// or simply
myRootEl.setAttribute('data-zh-hant', '')
```

The watcher fully converts text nodes, `aria-label` and `title` inside opted-in roots while 繁體中文 is active. Everything outside stays untouched.

The API published as `window.__zhHantHk__`:

| Member | Purpose |
|---|---|
| `toTraditional(text)` | character-level Simplified → Traditional |
| `applyPhrases(text)` | Hong Kong lexical replacements |
| `convertText(text)` | both of the above |
| `isMarked(el)` | whether `el` (or an ancestor) opted in |
| `mark(el)` | opt a UI root in |

`<code>`/`<pre>`/inputs and editable content are never rewritten, even inside opted-in roots.

## Develop

```bash
npm test
```

## Publish

1. Put this repo on GitHub.
2. Add the topic `dsh-plugin` so other Harness users can find it.
3. Point `package.json` `repository.url` at that repo if the owner differs.
4. Tell people:

```bash
dsh plugin --profile web add github:Argonaut790/dsh-zh-hant-hk
```

## 中文

官方 Language 而家得「中文」同 English。呢個插件會加「繁體中文」，再把簡體轉成繁體，然後改成港式用詞：新對話、設定、儲存、檔案夾、唯讀、完整存取。產品詞維持英文：Agent、sub-agent、skill、Think、plan mode、API Key。唔會寫「子 Agent」。

```bash
dsh plugin --profile web add /path/to/dsh-zh-hant-hk
```

## License

MIT
