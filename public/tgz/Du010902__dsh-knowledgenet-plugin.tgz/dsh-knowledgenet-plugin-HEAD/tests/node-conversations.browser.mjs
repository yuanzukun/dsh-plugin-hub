import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {existsSync,readdirSync,statSync,readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';

/**
 * 节点对话浏览器 E2E（真实构建产物 `client.js` + 真实 DSH 侧栏控制器）。
 *
 * 选择器约定：「打开新对话」按钮的无障碍名字带「＋」前缀（`LITERAL` 里是 `＋ 打开新对话`）✓
 * ⇒ 统一用 `{name:/打开新对话/}` 匹配 ✓；写死 `exact:true` 会因前缀而永远等不到 ✗（本文件曾因此超时）。
 */

if(!process.env.KN_PROJECT)throw Error('Set KN_PROJECT to the DSH checkout used to build the plugin.');
const root=resolve(process.env.KN_PROJECT).replace(/\\/g,'/');
const pluginRoot=fileURLToPath(new URL('../',import.meta.url)).replace(/\\/g,'/').replace(/\/$/,'');
/**
 * 测试工具链（rolldown / playwright）**不写死版本号** ✓：DSH 升级后 `.pnpm` 目录名会变成
 * `rolldown@1.2.x` ✗（旧写法写死 `rolldown@1.0.3` ⇒ 这个 E2E 直接 ERR_MODULE_NOT_FOUND 跑不起来 ✗）。
 * 与 `tests/inline-format.browser.mjs` 的 `resolveTooling()` 同一套约定 ✓：
 * rolldown 优先取本仓库 `.tmp-build-deps`（为浏览器测试准备的那份 ✓），再退回 DSH 项目；
 * playwright 取 DSH 项目；都可用 `KN_ROLLDOWN` / `KN_PLAYWRIGHT` 覆盖 ✓。
 */
function pnpmEntries(base){try{return readdirSync(base).filter(name=>!name.startsWith('@'));}catch{return [];}}
function firstExisting(candidates,label){for(const candidate of candidates)if(candidate&&existsSync(candidate))return candidate;throw Error('找不到'+label+'；尝试过：\n'+candidates.filter(Boolean).join('\n'));}
const rolldownPath=firstExisting([process.env.KN_ROLLDOWN,...[pluginRoot+'/.tmp-build-deps',root].flatMap(base=>pnpmEntries(base+'/node_modules/.pnpm').filter(name=>name.startsWith('rolldown@')).map(name=>base+'/node_modules/.pnpm/'+name+'/node_modules/rolldown/dist/index.mjs'))],'rolldown');
const {rolldown}=await import(pathToFileURL(rolldownPath).href);
const playwrightPath=firstExisting([process.env.KN_PLAYWRIGHT,...pnpmEntries(root+'/node_modules/.pnpm').filter(name=>name.startsWith('playwright@')).map(name=>root+'/node_modules/.pnpm/'+name+'/node_modules/playwright/index.mjs')],'playwright');
const {chromium}=await import(pathToFileURL(playwrightPath).href);
const require=createRequire(root+'/package.json');
const ts=require('typescript');const paths=ts.readConfigFile(root+'/tsconfig.base.json',ts.sys.readFile).config.compilerOptions.paths;
let installed = '';
if (process.env.KN_INSTALLED_ASAR) {
 const asar = require(root+'/node_modules/.pnpm/@electron+asar@3.4.1/node_modules/@electron/asar');
 const file = asar.listPackage(process.env.KN_INSTALLED_ASAR).find(path=>path.includes('dsh-client-ui-sidebar-right')&&path.endsWith('client.js'));
 installed = asar.extractFile(process.env.KN_INSTALLED_ASAR,file.slice(1)).toString().replace('exports.apply = apply;', 'exports.apply = apply; exports.createSidebarRightController = createSidebarRightController; exports.SidebarRightTabRegistry = SidebarRightTabRegistry; exports.createSidebarRightStore = createSidebarRightStore;');
}
const entry=`import React from 'react';import * as ReactDOM from 'react-dom';import * as JSX from 'react/jsx-runtime';import{createRoot}from'react-dom/client';
import{NodeConversations}from'${pluginRoot}/src/client/NodeConversations.tsx';
import{attachConversationServices,nodeConversations}from'${pluginRoot}/src/client/node-conversations.ts';
import{createSidebarRightController}from'${root}/packages/client/ui-sidebar-right/src/client/service.ts';
import{SidebarRightTabRegistry}from'${root}/packages/client/ui-sidebar-right/src/client/tab-registry.ts';
import{createSidebarRightStore}from'${root}/packages/client/ui-sidebar-right/src/client/stores.ts';
import * as Dock from '${root}/packages/client/ui-dockkit/src/index.ts';
import * as Store from '${root}/packages/client/store/src/index.ts';
window.__ModuleLoader__={load:({factory})=>{window.installed=factory(name=>({'@deepseek-ai/dsh-client-ui-primitives':{},'react/jsx-runtime':JSX,'react':React,'react-dom':ReactDOM,'@deepseek-ai/dsh-client-ui-dockkit':Dock,'@deepseek-ai/dsh-client-store':Store}[name]));}};
${installed}
const selectedRegistry=window.installed?.SidebarRightTabRegistry??SidebarRightTabRegistry;
const selectedStore=window.installed?.createSidebarRightStore??createSidebarRightStore;
const registry=new selectedRegistry({effect:fn=>fn()});for(const kind of ['guide','knowledgenet','browser'])registry.register({id:kind,kind,multiple:kind==='browser',title:()=>kind});registry.register({id:'document',kind:'document',patterns:['dsh-resource://file/**'],title:()=> '文档'});
const host={autoFullscreen:()=>false,openWithFocus:(id,fn)=>fn(),closeWithFocus:(id,p,fn)=>fn()};const {controller,adopt,show}=window.installed?window.installed.createSidebarRightController(registry,()=>{},host):createSidebarRightController(registry,()=>{});const stores=new Map();const store=id=>{if(!stores.has(id)){const value=selectedStore(()=>({kind:'guide',title:'guide'})).create();stores.set(id,value);adopt(id,value);}return stores.get(id);};let release=()=>{};function bind(id){release();const value=store(id);if(show){show(id);return;}release=controller.bind({sessionId:id,actions:value.actions,surfaces:value.getSnapshot().bySession,closeWithFocus:(p,fn)=>fn(),openWithFocus:fn=>fn(),canSplitPane:()=>true});}
bind('old');controller.openTab('knowledgenet',{params:{root:'library'}});controller.openTab('browser',{params:{url:'https://example.com'}});controller.openResource('dsh-resource://file/report.md',{params:{line:12}});controller.focus(controller.tabsIn('old').find(t=>t.kind==='knowledgenet').id);
window.__ModuleLoader__={load:({factory})=>{window.plugin=factory(name=>({'react':React,'react-dom':ReactDOM,'react/jsx-runtime':JSX}[name]));}};
window.mountNote=()=>{window.plugin.attachConversationServices(()=>({sessions:{create:async()=>'chat-1',list:{getSnapshot:()=>({byId:{'chat-1':{blank:false,title:'历史对话'}}})}},uiWorkspace:{openSession:()=>{}}}));/* 「在资源管理器中显示」走插件自己的宿主路由 ✓：这里用假 fetcher 记录请求（不会真的拉起资源管理器 ✓） */window.revealCalls=[];const node=document.createElement('div');document.body.appendChild(node);const noteRoot=createRoot(node);const fetcher=async(_url,options)=>{const body=JSON.parse(options.body);if(body.kind==='reveal-note'){window.revealCalls.push(body);return{json:async()=>({ok:true,path:'Nodes/a.md'})};}return{json:async()=>({ok:true,document:{nodeId:'node-a',title:'笔记',path:'Nodes/a.md',text:'正文',hash:'hash',revision:1}})};};noteRoot.render(React.createElement(window.plugin.NodeDocumentEditor,{nodeId:'node-a',libraryKey:'library',target:{root:'library'},fetcher,onClose:()=>{},onOpenConversation:()=>{window.cachedAtNavigation=window.plugin.recallDraft(window.plugin.draftKey('library','node-a'));noteRoot.unmount();}}));};
window.records=[];window.opened=[];const sessionListeners=new Set();const workspaceListeners=new Set();window.summary={phase:'ready',byId:{'chat-1':{blank:true,displayTitle:'新对话'}}};window.workspace={archivedSessionIds:[]};window.fetch=async(url,options)=>{const body=JSON.parse(options.body);if(body.kind==='record-node-conversation')window.records.push({sessionId:body.conversationId,createdAt:Date.now()});return{ok:true,json:async()=>({ok:true,root:'library',cwd:'/workspace',conversations:window.records})};};
attachConversationServices(()=>({sessions:{create:async()=>'chat-1',list:{getSnapshot:()=>window.summary,subscribe:fn=>{sessionListeners.add(fn);return()=>sessionListeners.delete(fn);}}},workspaces:{list:{getSnapshot:()=>window.workspace,subscribe:fn=>{workspaceListeners.add(fn);return()=>workspaceListeners.delete(fn);}}},uiWorkspace:{openSession:id=>{window.opened.push(id);release();if(show)show(id);setTimeout(()=>bind(id),100);}},sidebarRight:controller}));
window.startChat=()=>{window.summary={phase:'ready',byId:{'chat-1':{blank:false,title:'第一轮标题'}}};for(const fn of sessionListeners)fn();};window.renameChat=()=>{window.summary.byId['chat-1'].title='更新后的标题';for(const fn of sessionListeners)fn();};window.archiveChat=()=>{window.workspace.archivedSessionIds=['chat-1'];for(const fn of workspaceListeners)fn();};
window.sidebarResult=()=>({mounted:controller.mounted.getSnapshot(),expanded:controller.isExpanded(),tabs:controller.tabsIn('chat-1').map(t=>({kind:t.kind,params:(()=>{try{return controller.tabDomain.occurrence('chat-1',t).navigation.getSnapshot().params;}catch{return null;}})()})),old:controller.tabsIn('old').map(t=>t.kind),active:controller.active()?.kind});window.actions=nodeConversations;

window.mountPrerequisiteFlow=()=>{
 bind('old');let graph={nodes:[{id:'parent',title:'原节点'}],edges:[]};const recordsByNode={};const listeners=new Set();
 window.fetch=async(url,options)=>{const body=JSON.parse(options.body);if(body.kind==='add-prerequisite'){graph={nodes:[...graph.nodes,{id:'prerequisite',title:body.title}],edges:[{fromId:'parent',toId:'prerequisite'}]};}if(body.kind==='record-node-conversation'){(recordsByNode[body.nodeId]??=[]).push({sessionId:body.conversationId,createdAt:Date.now()});}return{ok:true,json:async()=>({ok:true,root:'library',cwd:'/workspace',conversations:recordsByNode[body.nodeId]??[]})};};
 window.plugin.attachConversationServices(()=>({sessions:{create:async()=>'flow-chat',list:{getSnapshot:()=>({phase:'ready',byId:{'flow-chat':{blank:true,title:'新对话'}}}),subscribe:fn=>{listeners.add(fn);return()=>listeners.delete(fn);}}},sidebarRight:controller,uiWorkspace:{openSession:id=>{window.flowOpened=id;if(show)show(id);else release();setTimeout(()=>bind(id),150);}}}));
 const element=document.createElement('div');element.id='flow';document.body.appendChild(element);const flowRoot=createRoot(element);
 function Flow(){const[node,setNode]=React.useState('parent');const[g,setGraph]=React.useState(graph);return React.createElement(window.plugin.NodeDocumentEditor,{key:node,nodeId:node,libraryKey:'library',target:{root:'library',sessionId:'old'},graph:g,onRelationsChanged:()=>setGraph(graph),onOpenNode:setNode,onClose:()=>{},fetcher:async()=>({json:async()=>({ok:true,document:{nodeId:node,title:node==='parent'?'原节点':'刚创建的前置',path:'Nodes/'+node+'.md',text:'正文',hash:'hash',revision:1}})}),onOpenConversation:id=>window.plugin.nodeConversations.open(id)});}
 flowRoot.render(React.createElement(Flow));window.flowRecords=()=>recordsByNode;window.flowSide=()=>({mounted:controller.mounted.getSnapshot(),expanded:controller.isExpanded(),kinds:controller.tabsIn('flow-chat').map(t=>t.kind),old:controller.tabsIn('old').map(t=>t.kind)});
};
window.mountPracticePicker=()=>{
  const holder=document.createElement('div'); holder.id='practice'; document.body.appendChild(holder);
  const root=createRoot(holder);
  const attempts=[]; const drafts=[]; const opened=[];
  window.practice={attempts,drafts,opened,blocked:true};
  attachConversationServices(()=>({
    sessions:{create:async()=>{const id='practice-'+(attempts.length+1);attempts.push(id);return id;},retain:id=>({binding:id,release(){}})},
    conversation:{input:{requestDraftInitialization(id,options){if(window.practice.blocked)return 'blocked';drafts.push({id,...options});return 'applied';}}},
    uiWorkspace:{openSession:id=>opened.push(id)},
  }));
  window.showPracticeNode=(nodeId)=>root.render(React.createElement(NodeConversations,{nodeId,title:'同名节点',target:{root:'library'},onOpen:id=>nodeConversations.open(id)}));
  window.showPracticeNode('node-a');
};
const pickerRoot=createRoot(document.getElementById('app'));window.unmountPicker=()=>pickerRoot.unmount();window.prepareSlowCreation=()=>attachConversationServices(()=>({sessions:{create:()=>new Promise(resolve=>{window.finishCreation=()=>resolve('chat-2');}),list:{getSnapshot:()=>({phase:'ready',byId:{'chat-1':{blank:false},'chat-2':{blank:false}}})}},uiWorkspace:{openSession:id=>window.opened.push(id)}}));pickerRoot.render(React.createElement(NodeConversations,{nodeId:'node-a',target:{root:'library'},onOpen:id=>nodeConversations.open(id)}));`;
const build=await rolldown({input:'virtual:entry',plugins:[{name:'local',resolveId(id,importer){if(id==='virtual:entry')return id;if(['react','react-dom','react-dom/client','react/jsx-runtime'].includes(id))return createRequire(root+'/node_modules/.pnpm/react-dom@18.3.1_react@18.3.1/node_modules/react-dom/package.json').resolve(id);if(paths[id]){let file=resolve(root,paths[id][0]);if(existsSync(file)&&statSync(file).isDirectory())file=resolve(file,'index.ts');return file;}if(!id.startsWith('.')&&!id.includes(':/')){try{return createRequire(importer&&importer!=='virtual:entry'?importer:root+'/packages/client/ui-sidebar-right/package.json').resolve(id);}catch{try{return require.resolve(id);}catch{}}}},load(id){if(id==='virtual:entry')return entry;if(id.endsWith('.css'))return {code:'export default {}',moduleType:'js'};}}]});
const output=await build.generate({format:'iife'});await build.close();const code=output.output.find(o=>o.type==='chunk').code;
const compiled=readFileSync(pluginRoot+'/client.js','utf8').replace('exports.apply = apply;','exports.apply = apply; exports.NodeDocumentEditor = NodeDocumentEditor; exports.recallDraft = recallDraft; exports.draftKey = draftKey; exports.attachConversationServices = attachConversationServices; exports.nodeConversations = nodeConversations;');
const server=createServer((request,response)=>{response.setHeader('Content-Type',request.url.endsWith('.js')?'text/javascript; charset=utf-8':'text/html; charset=utf-8');response.end(request.url==='/app.js'?code:request.url==='/plugin.js'?compiled:'<!doctype html><meta charset="utf-8"><div id="app"></div><script src="/app.js"></script><script src="/plugin.js"></script>');});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({executablePath:process.env.KN_CHROME ?? 'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
try {
  const practicePage=await browser.newPage();
  await practicePage.goto('http://127.0.0.1:'+server.address().port);
  await practicePage.evaluate(()=>window.mountPracticePicker());
  const practicePicker=practicePage.locator('#practice');
  await practicePicker.getByRole('button',{name:'对话 0',exact:true}).click();
  const quiz=practicePicker.getByRole('button',{name:'AI 提问',exact:true});
  await quiz.click();
  await practicePicker.getByRole('alert').filter({hasText:'无法打开练习'}).waitFor();
  await practicePage.evaluate(()=>{window.practice.blocked=false;});
  await quiz.click();
  await practicePage.waitForFunction(()=>window.practice.opened.length===1);
  await practicePage.evaluate(()=>window.showPracticeNode('node-b'));
  await practicePicker.getByRole('button',{name:/^对话 \d+$/}).click();
  await practicePicker.getByRole('button',{name:'自述理解',exact:true}).click();
  await practicePage.waitForFunction(()=>window.practice.opened.length===2);
  const practice=await practicePage.evaluate(()=>window.practice);
  if(practice.attempts.length!==2 || !practice.drafts[0]?.prompt.includes('"id":"node-a"')
    || !practice.drafts[1]?.prompt.includes('"id":"node-b"') || !practice.drafts[1]?.prompt.includes('我的理解：')) throw Error(JSON.stringify(practice));
  await practicePage.close();
} catch (error) {
  await browser.close();
  await new Promise(r=>server.close(r));
  throw error;
}
try{const page=await browser.newPage();const errors=[];page.on('pageerror',e=>{errors.push(e.message);console.error('PAGE ERROR:',e.message);});page.on('console',msg=>{if(msg.type()==='error'){errors.push(msg.text());console.error(msg.text());}});await page.goto('http://127.0.0.1:'+server.address().port);await page.getByRole('button',{name:'对话 0',exact:true}).click();if(await page.getByRole('button',{name:'围绕节点提问',exact:true}).count())throw Error('已删除入口仍存在');await page.getByRole('button',{name:/打开新对话/}).click();await page.waitForFunction(()=>window.sidebarResult().mounted==='chat-1');const side=await page.evaluate(()=>window.sidebarResult());await page.waitForFunction(()=>window.sidebarResult().tabs.some(t=>t.kind==='browser'&&t.params?.url==='https://example.com'));const restoredSide=await page.evaluate(()=>window.sidebarResult());Object.assign(side,restoredSide);if(!side.expanded||side.active!=='knowledgenet'||!['knowledgenet','browser','document'].every(k=>side.tabs.some(t=>t.kind===k))||!side.tabs.some(t=>t.kind==='browser'&&t.params.url==='https://example.com'))throw Error(JSON.stringify(side));await page.evaluate(()=>window.startChat());await page.getByRole('button',{name:'对话 1',exact:true}).waitFor();await page.getByRole('button',{name:'对话 1',exact:true}).click();await page.getByRole('button',{name:/第一轮标题/}).waitFor();await page.evaluate(()=>window.renameChat());await page.getByRole('button',{name:/更新后的标题/}).waitFor();await page.evaluate(()=>window.archiveChat());await page.getByRole('button',{name:'对话 0',exact:true}).waitFor();await page.evaluate(()=>window.mountNote());const editor=page.locator('.kn-editor .ProseMirror');await editor.waitFor();/* 「在资源管理器中显示」：按钮要在标题栏出现，点一下向**插件宿主路由**发 `{kind:"reveal-note", nodeId}` ✓（假 fetcher ⇒ 不会真开资源管理器 ✓）。
 * 用 dispatchEvent 而不是真实鼠标点击：这个测试页是**浅 DOM + 没挂插件样式**的裸页面，编辑器挂上后上方 picker 弹层的开合会让布局在 pointerdown/up 之间跳动，真实鼠标坐标会点偏（实测落到了 aside ✗）；这里只验证"按钮在 + 点击接线正确"✓，真实可点性由标准 button + 标题栏样式契约保证 ✓。 */
const revealButton=page.locator('.kn-editor').getByRole('button',{name:'在资源管理器中显示',exact:true});await revealButton.waitFor();if(!await revealButton.isVisible())throw Error('「在资源管理器中显示」按钮不可见');await revealButton.dispatchEvent('click');await page.waitForFunction(()=>window.revealCalls.length>=1);const reveal=await page.evaluate(()=>window.revealCalls.at(-1));if(reveal?.kind!=='reveal-note'||reveal?.nodeId!=='node-a'||reveal?.root!=='library')throw Error('在资源管理器中显示的请求不对：'+JSON.stringify(reveal));await editor.click();await page.keyboard.press('End');await page.keyboard.insertText('最后输入');await page.locator('.kn-editor').getByRole('button',{name:'对话 1',exact:true}).click();await page.locator('.kn-editor').getByRole('button',{name:/历史对话/}).click();const draft=await page.evaluate(()=>window.cachedAtNavigation);if(!draft?.draft.includes('最后输入'))throw Error('切换前草稿没有最新输入：'+JSON.stringify(draft));await page.evaluate(()=>window.prepareSlowCreation());const picker=page.locator('#app');const create=picker.getByRole('button',{name:/打开新对话/});if(!await create.isVisible())await picker.getByRole('button',{name:'对话 1',exact:true}).click();await create.click();await page.waitForFunction(()=>typeof window.finishCreation==='function');const before=await page.evaluate(()=>window.opened.length);await page.evaluate(()=>{window.unmountPicker();window.finishCreation();});await page.waitForFunction(()=>window.records.some(record=>record.sessionId==='chat-2'));await page.evaluate(()=>Promise.resolve());if(await page.evaluate(()=>window.opened.length)!==before)throw Error('卸载后仍发生跳转');await page.evaluate(()=>window.mountPrerequisiteFlow());const flow=page.locator('#flow');/* 「＋ 添加前置」在「前置」弹窗里（用户第十三轮移入 ✓）⇒ 先打开「前置」列表 ✓ */await flow.getByRole('button',{name:'前置 0',exact:true}).click();await flow.getByRole('button',{name:'＋ 添加前置',exact:true}).click();await flow.getByRole('textbox',{name:'前置节点名称',exact:true}).fill('刚创建的前置');/* 用户要求：输入名字后直接 Enter = 点「新建…并设为前置」✓（不再点那颗按钮 ✓） */await page.keyboard.press('Enter');await flow.getByRole('button',{name:'刚创建的前置',exact:true}).click();await flow.locator('.kn-editor-title').filter({hasText:'刚创建的前置'}).waitFor();await flow.getByRole('button',{name:'对话 0',exact:true}).click();await flow.getByRole('button',{name:/打开新对话/}).click();await page.waitForFunction(()=>window.flowSide().expanded&&window.flowSide().kinds.includes('document'));const finalSide=await page.evaluate(()=>window.flowSide());if(finalSide.mounted!=='flow-chat'||!['knowledgenet','browser','document'].every(kind=>finalSide.kinds.includes(kind)&&finalSide.old.includes(kind)))throw Error(JSON.stringify(finalSide));const flowRecords=await page.evaluate(()=>window.flowRecords());if(flowRecords.prerequisite?.[0]?.sessionId!=='flow-chat'||flowRecords.parent)throw Error('前置节点对话关联错误：'+JSON.stringify(flowRecords));if(errors.length)throw Error(errors.join('\n'));console.log((installed?'安装版侧栏':'源码版侧栏')+'浏览器通过：新建前置→打开笔记→创建对话完整组件流程通过；真实 DSH 侧栏控制器恢复图谱、浏览器、文档标签与导航参数；首次消息、改名、归档实时更新，最新富文本输入在切换前同步缓存，组件卸载后迟到创建不再跳转，无运行时错误。');}finally{await browser.close();await new Promise(r=>server.close(r));}

