/**
 * `SpaceNavigation` 的插件自有替代实现：内部导航控制器。
 *
 * 依 `design/knowledgenet-interior-navigation.md`。对引擎保持**同一套接口**
 * （`camera` / `basis()` / `command()` / `fitAll()` / `setFrameContext()` / `update()` /
 * `cancelPointer()` / `dispose()`），所以接线只需要把 `engine.ts` 的导入换掉 ✓。
 *
 * 与上游的两点根本区别：
 * 1. **拖动只旋转图谱 S**（绕固定球心 C），用"抓取点投影约束"求解 ⇒
 *    正在抓取的那一块按指针方向移动，球前球后都一致 ✓（上游绕 target 环绕时球背面必然反向 ✗）；
 * 2. 姿态用完整四元数 Q（含滚转），右/上轴由 Q 给出，没有极点翻转 ✓。
 *
 * **平面模式**（用户 2026-11-11，节点数 ≤ `SPACE_FLAT_MAX_NODES`）：
 * 引擎按节点数显式调用 `setFlat(true)` ⇒ 图谱 S 归位、相机固定正面、
 * 拖动**不再旋转**（Shift 平移保留）；节点绘制与 UI 样式一律不变 ✓。
 *
 * 渲染/标签/拾取全部走 `basis()` 给出的**等效相机基向量**（把 S 折进去），
 * 所以那些既有代码一行都不用改 ✓。
 */
import { boundsOf, pickEdge, pickNode, type Bounds } from "../vendor/upstream/graph3d/camera.ts";
import { DRAG_THRESHOLD } from "../vendor/upstream/graph3d/types.ts";
import type { CameraCommand, CameraState, ProjectedNode, Vec3, Viewport } from "../vendor/upstream/graph3d/types.ts";
import type { ContextHit } from "../vendor/upstream/graph3d/navigation.ts";

import {
  aimAt,
  anchorFromRay,
  anchorReachable,
  applySceneRotation,
  displayOf,
  dragAnchorTo,
  dragGainAt,
  effectiveBasis,
  fitSphere,
  grabAnchor,
  panEye,
  projectDisplay,
  quatConjugate,
  quatSlerp,
  radiusAbout,
  spinStep,
  SPIN_FALLBACK_GAIN,
  type DragGain,
  type GrabAnchor,
  type InteriorState,
} from "./interior-navigation.ts";
import { pickClippedEdge } from "./edge-picking.ts";
import { currentQuat, freeBasis, quatMultiply, quatNormalize, type Quat } from "./trackball.ts";

/** 定位动画时长（毫秒）；「减少动态效果」时降为 1ms（与上游一致） */
const FOCUS_DURATION_MS = 620;
/** 视野角（与引擎渲染、`fitDistance` 用的一致） */
const FOV_DEG = 50;
/**
 * 取景安全区（px）：头行与底部提示语各留 64（沿用旧版），左右各留一点给标签。
 * 可用区域 = 画布去掉这些边距后的矩形。
 */
const FRAME_INSETS = { top: 64, bottom: 64, left: 12, right: 12 } as const;
/**
 * 用户 2026-10-30 最终口径：以"旋转过程中节点可能占据的**最大平面面积**"为准 ——
 * 即包围球投影圆的直径 = 可用区域短边的 `TARGET_COVERAGE`（86%，落在 80%–90% 内 ✓）。
 * 球投影与旋转角度无关 ⇒ 相机距离固定，旋转时不会一缩一放 ✓（用户实测反馈）。
 */
const TARGET_COVERAGE = 0.86;
/** 插在 `camera` 上的内部状态键：让上游的内存相机缓存也能带上完整状态 ✓ */
const STATE_KEY = "knInterior";

/**
 * 平面模式（节点数 ≤ 3）的取景口径。
 *
 * 三维模式必须按「旋转安全球」留白（相机能转，任意朝向都不能裁切 ✗）；
 * 平面模式**不能旋转** ⇒ 按节点在 x/y 平面上的真实包围盒取景即可，画面更满 ✓。
 * 节点外观不变：屏幕半径由渲染层固定（构建期补丁 ✓），取景只改相机距离。
 */
const FLAT_TARGET_COVERAGE = 0.86;
/** 平面取景时给节点边缘与标签留的边距（CSS 像素） */
const FLAT_FRAME_PADDING_PX = 18;

/**
 * 平面模式的**正面姿态**：相机在 +Z 侧朝 −Z 看、世界 +Y 向上。
 *
 * 即单位四元数：`rotateVec(q, [0,0,-1]) = [0,0,-1]`、`rotateVec(q, [0,1,0]) = [0,1,0]` ✓。
 * 用字面量而不是 `quatLookAt()`：后者要经过一次叉乘/分支，正面这个特例没必要绕一圈 ✓。
 */
const FRONT_VIEW: Quat = [0, 0, 0, 1];

/**
 * 「用户按了重新整理」的窗口事件名。
 *
 * 面板按钮在重排布局的同时广播它 ✓；控制器据此：
 * 取消进行中的抓取 ✓、等新布局完成后再**采一次球心**并取景 ✓
 * —— 不再用 `smooth` 参数去猜"这是不是重排"（那个参数只表示要不要动画 ✗，文档 P2）。
 * 负载带库身份：多面板并存时只认自己那一个 ✓。
 */
export const RELAYOUT_EVENT = "kn-relayout-request";

/** 重排请求的兜底时限（毫秒）：等不到"布局收敛"就用当前包围体兜一次 ✓ */
const RELAYOUT_DEADLINE_MS = 2000;

/** 这次取景是**为什么**发生的（引擎显式传入；不能用 `smooth` 猜 ✗） */
export type FitReason = "initial" | "settle" | "command";

/** 挂在 `camera` 上的内部状态（`frozen` = 球心已冻结，缓存恢复时要一起带回来 ✓） */
type CarriedState = InteriorState & { frozen?: boolean };
type CameraWithState = CameraState & { [STATE_KEY]?: CarriedState };

/** 控制器选项：与上游 `NavigationOptions` 同形（这样引擎侧不用改） */
export interface InteriorNavigationOptions {
  element: HTMLElement;
  initial: CameraState;
  edgeLength: number;
  /**
   * 知识库身份（引擎构造时从**显式选项**里带过来 ✓）。
   * 重新整理事件按它认领：两个图谱面板并存时只响应自己那一个 ✓。
   */
  libraryKey?: string;
  getProjected(): ProjectedNode[];
  getEdges(): ReadonlyArray<{ from: number; to: number }>;
  onSelect(index: number | null): void;
  onHover(index: number | null): void;
  onEdgeHover?(index: number | null): void;
  onSelectEdge?(index: number | null): void;
  onContextMenu(hit: ContextHit, clientX: number, clientY: number): void;
  onLocate(): void;
  onCameraChange(): void;
  onUserCameraInput?(): void;
}

interface PointerState {
  id: number;
  startX: number;
  startY: number;
  lastX: number;
  lastY: number;
  moved: boolean;
  captured: boolean;
  panning: boolean;
}

interface Animation {
  start: number;
  duration: number;
  fromEye: Vec3;
  toEye: Vec3;
  fromView: readonly [number, number, number, number];
  toView: readonly [number, number, number, number];
}

const lerp3 = (a: Vec3, b: Vec3, t: number): Vec3 => [
  a[0] + (b[0] - a[0]) * t,
  a[1] + (b[1] - a[1]) * t,
  a[2] + (b[2] - a[2]) * t,
];
const clampNum = (value: number, min: number, max: number): number => Math.min(max, Math.max(min, value));

export class InteriorNavigation {
  /**
   * 对外的相机视图（**等效相机**：布局坐标系里的位置与姿态）。
   * 只用于持久化与调试；`basis()` 才是渲染真正用的那份 ✓。
   */
  camera: CameraWithState;

  private state: InteriorState;
  private pointer: PointerState | null = null;
  private grab: GrabAnchor | null = null;
  /**
   * 拖动阶段（文档 §建议的交互与实现）：
   * - `"grab"`：抓取点跟手（局部投影约束求解 ✓）；
   * - `"spin"`：连续增量旋转（抓取点不可达/停滞/病态后切换 ✓）。
   * 一次拖动里**只在进入时切一次** ✓（直到松开；不在中途反复重抓 ✗）。
   */
  private dragPhase: "grab" | "spin" = "grab";
  /** 连续阶段用的增益（由最后可信的局部映射取逆 ✓） */
  private spinGain: DragGain | null = null;
  /** 连续阶段的增量起点（切换时重置 ⇒ 不补算历史上到不了的位移 ✓） */
  private spinLastX = 0;
  private spinLastY = 0;
  private animation: Animation | null = null;
  /**
   * 这个实例是否**已经采纳过球心**。
   *
   * 球心规则（2026-10-30 修正）：首次进入先采一次；**布局收敛后**再按收敛后的几何中心校准
   * （用户没操作过相机，或这是明确点「重新整理」）；用户转过视角之后不再自动改。
   * 有了这个标记，引擎后续因为选中/聚焦/换结构而发的收敛取景不会把球心丢在原地
   * （用户 2026-10 复查："双击节点时旋转中心又被放到这个节点上" ✗；
   *  2026-10-30 又指出"旋转中心不在几何中心" ✗ ⇒ 见 `fitAll()` 的 settleAdopt）。
   */
  private centerAdopted = false;
  private suppressClick = false;
  private suppressedTimer: number | undefined;
  private disposed = false;
  private hover: number | null = null;
  private hoverEdge: number | null = null;
  private bounds: Bounds = boundsOf(new Float32Array(0), 0);
  private viewport: Viewport = { width: 800, height: 600 };
  /** 用户是否已经自己操作过相机：操作过就**冻结球心** ✓ */
  private userInteracted = false;
  /** 节点坐标（引擎每帧交过来；线段拾取需要世界坐标 ✓） */
  private positions: Float32Array | null = null;
  private positionCount = 0;
  /** 是否已按"以固定球心 C 为中心"量过半径 ✓（量过就不再被 bounds.radius 覆盖 ✗） */
  private radiusMeasured = false;
  /**
   * 是否要在下一帧按**旋转安全距离**复核（用户 2026-10-30 最终口径）。
   *
   * 相机从缓存恢复 / 布局刚结算时，构图可能是按旧图算的 ⇒
   * 在 `setFrameContext()` 里重算一次距离（按包围球投影圆定距离，旋转时不变 ✓）。
   */
  private coveragePending = true;
  /**
   * 是否处于**平面模式**（节点数 ≤ 3）：
   * 布局在 z=0 平面上（构建期补丁负责 ✓），相机固定正面、拖动不旋转 ✓。
   */
  private flat = false;
  /** 刚进入平面模式：下一帧按**当前坐标**重采球心与半径（相机缓存可能来自另一张图 ✓） */
  private flatRecentering = false;
  /** 收到明确的重新整理请求、正等新布局完成 ✓ */
  private relayoutPending = false;
  private relayoutDeadline = 0;
  /** 重排期间用户自己操作过 ⇒ 不再自动取景覆盖他的视角 ✓ */
  private interactedSinceRelayout = false;
  /** 本实例绑定的知识库身份（**构造选项**里显式带进来；重新整理事件按它认领 ✓） */
  private readonly libraryKey: string;
  /*
   * 注意：这里**不用**构造参数属性（`constructor(private readonly options…)`）——
   * Node 的 strip-only TS 模式直接拒绝那种写法（ERR_UNSUPPORTED_TYPESCRIPT_SYNTAX），
   * 而我们的单测就是直接加载 `.ts` 源码跑的 ✗。
   */
  private readonly options: InteriorNavigationOptions;

  constructor(options: InteriorNavigationOptions) {
    this.options = options;
    this.libraryKey = options.libraryKey ?? "";
    this.state = this.seedState(options.initial);
    this.camera = { ...options.initial } as CameraWithState;
    this.syncCamera();
    const element = options.element;
    element.addEventListener("pointerdown", this.onPointerDown);
    element.addEventListener("pointermove", this.onPointerMove);
    element.addEventListener("pointerup", this.onPointerUp);
    element.addEventListener("pointercancel", this.onPointerCancel);
    element.addEventListener("pointerleave", this.onPointerLeave);
    element.addEventListener("dblclick", this.onDoubleClick);
    element.addEventListener("contextmenu", this.onContextMenu);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("blur", this.onWindowBlur);
    window.addEventListener(RELAYOUT_EVENT, this.onRelayoutRequest);
    document.addEventListener("visibilitychange", this.onVisibilityChange);
  }

  /**
   * 「重新整理」请求（面板广播）。
   * @param event - 负载里带库身份；不是本实例的库就忽略 ✓。
   */
  private onRelayoutRequest = (event: Event): void => {
    const detail = (event as CustomEvent<{ libraryKey?: string }>).detail;
    if (detail !== undefined && detail !== null
      && typeof detail.libraryKey === "string" && detail.libraryKey !== this.libraryKey) {
      return;
    }
    this.relayoutPending = true;
    this.interactedSinceRelayout = false;
    this.relayoutDeadline = (typeof performance === "undefined" ? 0 : performance.now()) + RELAYOUT_DEADLINE_MS;
    /* 重排开始就取消进行中的抓取（文档要求）✓ */
    this.cancelPointer();
  };

  /* ------------------------------ 状态与基向量 ------------------------------ */

  /**
   * 从上游相机状态播种：优先用缓存里带过来的完整状态；
   * 没有（老缓存 / 首次打开）⇒ 按文档的兼容做法：
   * **以旧 target 初始化 C、以单位四元数初始化 S**，P/Q 由 `freeBasis` 反推 ✓。
   */
  private seedState(initial: CameraState): InteriorState {
    const carried = (initial as CameraWithState)[STATE_KEY];
    if (carried !== undefined && Array.isArray(carried.center) && Array.isArray(carried.eye)) {
      /*
       * **"球心已冻结"也要一起恢复**（文档 P1）：
       * 恢复完整状态却把 `userInteracted` 留在 false，会让随后的 fitAll 把
       * 已经冻结的球心当成"还没操作过的初始球心"再挪一次 ✗。
       */
      this.userInteracted = carried.frozen === true;
      return {
        center: [...carried.center],
        eye: [...carried.eye],
        view: [...carried.view],
        scene: [...carried.scene],
        radius: Number.isFinite(carried.radius) && carried.radius > 0 ? carried.radius : 20,
      };
    }
    const basis = freeBasis(initial, initial.target);
    return {
      center: [...initial.target],
      eye: [...basis.position],
      view: currentQuat(initial),
      scene: [0, 0, 0, 1],
      radius: 20,
    };
  }

  /** 把内部状态同步到对外的 `camera`（持久化 / 调试用；渲染不走它 ✓） */
  private syncCamera(): void {
    const basis = effectiveBasis(this.state);
    const offset: Vec3 = [
      basis.position[0] - this.state.center[0],
      basis.position[1] - this.state.center[1],
      basis.position[2] - this.state.center[2],
    ];
    const distance = Math.hypot(offset[0], offset[1], offset[2]) || 1;
    const forward = basis.forward;
    this.camera.target = [...this.state.center];
    this.camera.distance = distance;
    this.camera.q = this.effectiveQuat();
    this.camera.pitch = Math.asin(clampNum(-forward[1], -1, 1));
    this.camera.angle = Math.atan2(-forward[0], -forward[2]);
    this.camera[STATE_KEY] = {
      center: [...this.state.center],
      eye: [...this.state.eye],
      view: [...this.state.view],
      scene: [...this.state.scene],
      radius: this.state.radius,
      /* 冻结标记：缓存恢复时要一起带回来，否则球心会被再挪一次 ✗ */
      frozen: this.userInteracted,
    };
  }

  /** 等效姿态（把 S 折进 Q）：布局坐标系里相机朝向 */
  private effectiveQuat(): Quat {
    /*
     * 必须与 `effectiveBasis()` 一致：那里三条轴都是 `S⁻¹` 作用到 Q 的轴上，
     * 所以对外姿态 = `inverse(S) × Q` ✓。
     * （曾经写成 `S × Q` ✗ —— 调试/持久化看到的姿态会与真正渲染的基向量不一致，
     *  将来谁拿这份姿态去推算就会算错。文档开发备注点名的就是这个。）
     */
    return quatNormalize(quatMultiply(quatConjugate(this.state.scene), this.state.view));
  }

  /** 渲染/投影/拾取用的基向量（= 布局坐标系的相机；S 已折进去） */
  basis() {
    return effectiveBasis(this.state);
  }

  /** 当前是否处于平面模式（节点数 ≤ 3；单测与自检用 ✓） */
  get flatMode(): boolean {
    return this.flat;
  }

  /* ------------------------------ 平面模式 ------------------------------ */

  /**
   * 切换**平面模式**（引擎按节点数显式通知；阈值见 `src/client/space-flat.ts` ✓）。
   *
   * 进入平面模式时：
   * - 图谱旋转 S 归位（不再绕球心转）✓；
   * - 相机姿态 Q 归位到**正面**（+Z 看向 −Z）✓；
   * - 球心/半径等下一帧按**当前坐标**重采一次（相机缓存可能来自另一张图 ✓）；
   * - 清掉「用户动过相机 / 已采过球心」标记 —— 平面模式不能旋转，
   *   球心应当始终跟着当前图的几何中心（布局收敛后 `fitAll("settle")` 会再校准一次 ✓）。
   *
   * 离开平面模式**只解除输入限制**：保留当前（正面）视角，用户可继续自由旋转 ✓；
   * 不强制把视角转回某个"3D 默认角"，那反而会把人正在看的方向拽走 ✗。
   *
   * @param flat - 是否进入平面模式。
   */
  setFlat(flat: boolean): void {
    const next = flat === true;
    if (next === this.flat) return;
    this.flat = next;
    this.cancelPointer();
    this.animation = null;
    if (next) {
      this.faceFront(this.state, Math.max(1, this.eyeDistance()));
      this.flatRecentering = true;
      this.coveragePending = true;
      this.userInteracted = false;
      this.centerAdopted = false;
      this.radiusMeasured = false;
    } else {
      this.flatRecentering = false;
    }
    this.syncCamera();
    this.options.onCameraChange();
  }

  /** 把相机放成正面姿态并把机位摆在球心正前方 `distance` 处（平面模式专用 ✓） */
  private faceFront(state: InteriorState, distance: number): void {
    state.scene = FRONT_VIEW;
    state.view = FRONT_VIEW;
    state.eye = [state.center[0], state.center[1], state.center[2] + distance];
  }

  /** 当前相机到球心的距离（显示世界；异常时退回持久化相机里的 distance ✓） */
  private eyeDistance(): number {
    const offset = [
      this.state.eye[0] - this.state.center[0],
      this.state.eye[1] - this.state.center[1],
      this.state.eye[2] - this.state.center[2],
    ];
    const distance = Math.hypot(offset[0]!, offset[1]!, offset[2]!);
    if (Number.isFinite(distance) && distance > 0) return distance;
    return Number.isFinite(this.camera.distance) && this.camera.distance > 0 ? this.camera.distance : 1;
  }

  /**
   * 平面模式下的**几何中心**：节点 x/y 包围盒的中心（z = 0）。
   *
   * 与 `boundsOf()` 的 center 数学上一致，但这里只认平面坐标、且**不**依赖旧的中心：
   * 平面模式不能旋转，构图应该始终以当前图的几何中心为准 ✓。
   *
   * @param positions - 节点坐标。
   * @param count - 节点数。
   * @returns 中心点；没有有限坐标时返回 null ✓。
   */
  private flatBoxCenter(positions: Float32Array, count: number): Vec3 | null {
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    for (let index = 0; index < count; index += 1) {
      const x = positions[index * 3];
      const y = positions[index * 3 + 1];
      if (x === undefined || y === undefined || !Number.isFinite(x) || !Number.isFinite(y)) continue;
      minX = Math.min(minX, x);
      maxX = Math.max(maxX, x);
      minY = Math.min(minY, y);
      maxY = Math.max(maxY, y);
    }
    if (!Number.isFinite(minX) || !Number.isFinite(minY)) return null;
    return [(minX + maxX) / 2, (minY + maxY) / 2, 0];
  }

  /**
   * 平面模式的取景距离：按**节点在 x/y 平面上的真实包围盒**填满可用区域。
   *
   * 做法：先按"包围盒 + 四周边距"装进可用区域求出「屏幕像素 / 世界单位」，
   * 再乘 `FLAT_TARGET_COVERAGE`（留一点呼吸感 ✓），最后用透视关系反解距离：
   * `distance = focalPx / scale`（节点在 z=0 ⇒ 深度恒为距离 ✓）。
   *
   * 与三维的「旋转安全球」相比：三维要保证任意朝向都不裁切（所以只能按球算 ✓）；
   * 平面模式不能旋转，按真实包围盒取景才能让两三个节点撑满画布、不缩成中间一小团 ✓。
   * 节点外观不受影响：屏幕半径由渲染层固定（构建期补丁 ✓），这里只改相机距离。
   *
   * @param positions - 节点坐标（x/y/z 连续存放）。
   * @param count - 节点数。
   * @returns 相机到球心的距离；坐标不可用时返回 null（调用方退回旋转安全距离 ✓）。
   */
  private flatFitDistance(positions: Float32Array, count: number): number | null {
    if (count <= 0 || positions.length < count * 3) return null;
    const [centerX, centerY] = this.state.center;
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;
    for (let index = 0; index < count; index += 1) {
      const x = positions[index * 3];
      const y = positions[index * 3 + 1];
      if (x === undefined || y === undefined || !Number.isFinite(x) || !Number.isFinite(y)) continue;
      minX = Math.min(minX, x - centerX);
      maxX = Math.max(maxX, x - centerX);
      minY = Math.min(minY, y - centerY);
      maxY = Math.max(maxY, y - centerY);
    }
    if (!Number.isFinite(minX) || !Number.isFinite(minY)) return null;
    const usableWidth = Math.max(80, this.viewport.width - FRAME_INSETS.left - FRAME_INSETS.right);
    const usableHeight = Math.max(80, this.viewport.height - FRAME_INSETS.top - FRAME_INSETS.bottom);
    const tanHalfV = Math.tan((FOV_DEG * Math.PI) / 360);
    const focalPx = this.viewport.height / 2 / tanHalfV;
    const boxW = Math.max(0, maxX - minX);
    const boxH = Math.max(0, maxY - minY);
    const paddingPx = FLAT_FRAME_PADDING_PX * 2;
    let scale: number;
    if (boxW <= 1e-6 && boxH <= 1e-6) {
      /* 单节点：按一个"虚拟的节点 + 标签盒"取景，节点居中但不贴到相机上 ✓ */
      scale = (FLAT_TARGET_COVERAGE * Math.min(usableWidth, usableHeight)) / paddingPx;
    } else {
      scale = Math.min(
        (usableWidth - paddingPx) / Math.max(boxW, 1e-6),
        (usableHeight - paddingPx) / Math.max(boxH, 1e-6),
      ) * FLAT_TARGET_COVERAGE;
    }
    if (!(Number.isFinite(scale) && scale > 0)) return null;
    const distance = focalPx / scale;
    return Number.isFinite(distance) && distance > 0 ? distance : null;
  }

  /** 外部（每帧）更新：包围体、视口、节点坐标（线段拾取要用世界坐标 ✓） */
  setFrameContext(bounds: Bounds, viewport: Viewport, positions?: Float32Array, count?: number): void {
    this.bounds = bounds;
    const resized = viewport.width !== this.viewport.width || viewport.height !== this.viewport.height;
    this.viewport = viewport;
    /* 画布尺寸变了（侧栏拖宽/窗口缩放）⇒ 构图可能过大或过小，下一帧复核占比 ✓ */
    if (resized) this.coveragePending = true;
    if (positions !== undefined) {
      this.positions = positions;
      this.positionCount = count ?? positions.length / 3;
    }
    /*
     * 刚进入平面模式：球心/半径按**当前坐标**重采一次 ✓
     * （相机缓存可能来自另一张更大的图；不能旋转时让球心落在当前图的几何中心附近，
     *  随后布局收敛的 `fitAll("settle")` 还会再校准一次 ✓）。
     */
    if (this.flatRecentering) {
      this.flatRecentering = false;
      if (this.positions !== null && this.positionCount > 0
        && Number.isFinite(bounds.radius) && bounds.radius > 0) {
        this.state.center = [...bounds.center];
        const radius = radiusAbout(this.positions, this.positionCount, this.state.center);
        if (radius > 0) {
          this.state.radius = radius;
          this.radiusMeasured = true;
        }
        this.faceFront(this.state, Math.max(1, this.eyeDistance()));
        this.coveragePending = true;
      }
    }
    /*
     * **球心不在这里跟随**（文档：布局持续计算期间不要每帧重算操作球心 ✗）——
     * 每帧跟着包围体中心走会让画面在布局收敛时自己漂移。
     * 球心只在 `fitAll()`（初次取景 / 新布局完成 / 明确重新整理）时采一次 ✓。
     * 操作球半径也随之冻结：拖动期间不换 ✓；而且一旦按"以 C 为中心"量过（`fitAll` ✓），
     * 就**不再**用绕 `bounds.center` 的那个半径覆盖它 ✗（文档 P2：后者未必包住全部节点 ✓）。
     */
    if (this.pointer === null && !this.radiusMeasured
      && Number.isFinite(bounds.radius) && bounds.radius > 0) {
      this.state.radius = bounds.radius;
    }
    /*
     * 重排请求进来后迟迟等不到"布局收敛"：到点就用**当前**包围体兜一次 ✓
     * （典型情形是布局收敛事件没来；兜底后仍然保留待办 —— 真收敛时再采一次更准的 ✓）。
     */
    if (this.pointer === null && this.relayoutPending && this.relayoutDeadline > 0
      && (typeof performance === "undefined" || performance.now() >= this.relayoutDeadline)) {
      this.relayoutDeadline = 0;
      if (Array.isArray(bounds.center) && bounds.radius > 0) {
        this.state.center = [...bounds.center];
        this.state.radius = bounds.radius;
        this.radiusMeasured = false;
      }
    }
    if (this.coveragePending && this.pointer === null && this.animation === null
      && this.positions !== null && this.positionCount > 0
      && this.viewport.width > 0 && this.viewport.height > 0) {
      this.coveragePending = false;
      this.ensureCoverage(this.positions, this.positionCount);
    }
    this.syncCamera();
  }

  /* ------------------------------- 相机命令 ------------------------------- */

  command(command: CameraCommand, index: number | null, positions: Float32Array, count: number): void {
    this.positions = positions;
    this.positionCount = count;
    if (command.type === "fitAll") {
      this.fitAll(positions, count, true);
      return;
    }
    if (index === null || index < 0 || index >= count) return;
    /* 用户明确要"定位到某个节点" ⇒ 不要再用占比兜底把镜头拉回全景 ✗ */
    this.coveragePending = false;
    const target: Vec3 = [
      positions[index * 3] ?? 0,
      positions[index * 3 + 1] ?? 0,
      positions[index * 3 + 2] ?? 0,
    ];
    /*
     * 定位（按 F / 选中搜索结果）：**只移动并转向这个节点** ✓
     *
     * 注意**双击不走到这里**（2026-10-29 用户要求：双击只选中，既不改旋转中心、
     * 也不放大局部视图 ✗）。
     *
     * 用户 2026-10-29 第一轮要求删掉「双击节点把转动中心变成该节点」：
     * 球心 C 与图谱旋转 S **都不动**（与 `design/knowledgenet-interior-navigation.md`
     * 的"F 或双击定位 ⇒ 保留球心"一致 ✓）。球心只在「首次进入」与「明确重新整理」时变，
     * 见 `fitAll()` 的采纳规则 ✓。
     *
     * 于是定位只走 `aimAt`：把相机放到目标前方、视线对准它（onCameraChange 照旧 ✓），
     * 不 `recenterOn`、不改 `centerAdopted / userInteracted`（那会把"定位"误记成
     * "用户动过球心"，之后收敛取景就不敢再按承诺取景 ✗）。
     */
    const distance = clampNum(this.options.edgeLength * 2.6, 40, Math.max(60, this.bounds.radius));
    const from = { eye: [...this.state.eye] as Vec3, view: this.state.view };
    this.animateTo(from, this.aimTarget(target, distance), true);
  }

  /**
   * 「适应窗口」。
   *
   * @param positions - 节点坐标。
   * @param count - 节点数。
   * @param smooth - 是否带动画（**只决定动画**，不再用来推断"是否重排" ✗）。
   * @param reason - 这次取景的**原因**（引擎显式传入 ✓）：
   *  - `"initial"`：首次取景；
   *  - `"settle"`：布局**收敛后**的取景 —— 重新整理请求就是在这里才被兑现 ✓；
   *  - `"command"`：工具栏/命令触发的取景（**重新整理按钮点下去时也会立刻来一次** ✗，
   *    它测的还是重排前的坐标 ⇒ 绝不能在这里采球心、更不能消费掉待办标记 ✗）。
   */
  fitAll(
    positions: Float32Array,
    count: number,
    smooth: boolean,
    reason: FitReason = "command",
  ): void {
    this.positions = positions;
    this.positionCount = count;
    const bounds = boundsOf(positions, count);
    this.bounds = bounds;
    /*
     * 球心更新时机（文档 P2：**不复用 `smooth`**，改用明确原因 ✓）：
     * - 用户还没操作过 且 是首次取景 / 布局收敛 ⇒ 采当前布局中心（进入一个库时的初始球心 ✓）；
     * - 收到过**明确的重新整理请求**、并且这次是**布局收敛后**的取景 ⇒ 采新球心 ✓（承诺兑现 ✓）；
     * - 其它情况（尤其"命令"那次立即取景）⇒ **什么都不动** ✓。
     */
    /*
     * **先保存判断，再清标记**（复查指出的次序问题 ✗）：
     * 这两个判断都依赖 `relayoutPending`，而它会在下面被清掉 ⇒ 必须先算再用 ✓
     * （否则"用户在重排期间操作过就跳过取景"永远失效，完成时照样把镜头拉走 ✗）。
     */
    const settlingRelayout = reason === "settle" && this.relayoutPending;
    const skipFraming = settlingRelayout && this.interactedSinceRelayout;
    /*
     * 球心采纳规则（2026-10-30 用户反馈修正：**旋转中心必须落在图的几何中心**）：
     *
     * 1. 首次取景（初始云 / 有布局缓存但没有相机缓存）⇒ 先按当时坐标采一次，保证立刻能看 ✓；
     * 2. **布局收敛后**（`settle`）⇒ 只要用户没动过相机（或这是明确的重新整理），就用**收敛后
     *    的包围盒中心**再采一次 —— 引擎的"初始取景"发生在力导向**还没收敛**时，坐标云随后会
     *    整体偏移；不重采的话转动中心会停在旧云的几何中心，看起来"不在图中心"✗（用户实测）。
     *    用户拖动/滚轮会关掉引擎的 autoFit，那种情况引擎根本不发这次 settle 取景 ⇒ 不抢视角 ✓。
     * 3. 其余（尤其 `command` 那次立即取景）⇒ 不动球心 ✓。
     */
    const firstTime = !this.centerAdopted
      && !this.userInteracted
      && (reason === "initial" || reason === "settle");
    const settleAdopt = reason === "settle"
      && this.pointer === null
      && (!this.userInteracted || this.relayoutPending);
    const adoptCenter = firstTime || settleAdopt;
    if (adoptCenter && Number.isFinite(bounds.radius) && bounds.radius > 0) {
      this.state.center = [...bounds.center];
      this.radiusMeasured = false;
      this.measureRadius(positions, count);
      /* 首次那一采之后，"布局再次收敛"仍可按上面的规则把中心校准到新的几何中心 ✓ */
      if (firstTime) this.centerAdopted = true;
      /* 只有"布局收敛"这一次才算兑现了重排请求 ✓ */
      if (reason === "settle") {
        this.relayoutPending = false;
        this.relayoutDeadline = 0;
      }
    } else {
      /* 球心不动，但半径始终按"以 C 为中心"量 ✓（操作球 / 取景 / 小地图共用它 ✓） */
      this.measureRadius(positions, count);
    }
    if (reason === "settle") this.interactedSinceRelayout = false;
    if (skipFraming) {
      this.syncCamera();
      this.options.onCameraChange();
      return;
    }
    /*
     * 取景距离用**操作球半径**（以固定球心 C 量出来的那个 ✓），
     * 而不是绕 `bounds.center` 的包围半径 —— 两者在球心冻结于别处时会不一样，
     * 用后者会出现"取景按另一个球算"的错位 ✗（文档要求三处共用同一个半径 ✓）。
     *
     * 取景距离不再按"当前投影"收紧（那样旋转会一缩一放 ✗），而是按**旋转安全的包围球**：
     * 以"旋转过程中节点可能占据的最大平面面积"= 球投影圆为准，让球投影直径占
     * 可用区域短边的 80%–90% ⇒ 旋转时距离不变、任何角度都不裁切 ✓
     * （用户 2026-10-30 最终口径）。
     */
    const framingRadius = this.state.radius > 0 ? this.state.radius : bounds.radius;
    /*
     * 平面模式不能旋转 ⇒ 按**真实平面包围盒**取景（比"旋转安全球"更满 ✓）；
     * 坐标不可用时退回旋转安全距离，构图不会失常 ✓。
     */
    const distance = this.flat
      ? this.flatFitDistance(positions, count) ?? this.rotationSafeDistance(framingRadius)
      : this.rotationSafeDistance(framingRadius);
    const from = { eye: [...this.state.eye] as Vec3, view: this.state.view };
    this.animateTo(from, this.fitTarget(framingRadius, distance), smooth);
  }

  /**
   * 以**固定球心 C** 为基准量半径：`max|X − C|` ✓（文档 P2）
   */
  private measureRadius(positions: Float32Array, count: number): void {
    const radius = radiusAbout(positions, count, this.state.center);
    if (radius > 0) {
      this.state.radius = radius;
      this.radiusMeasured = true;
    }
  }

  /**
   * 当前相机下节点投影包围盒占**可用区域**的比例（0–1+）。
   *
   * 只按**节点中心**量、不含标签余量：标签越界时引擎的标签规划器会直接跳过，
   * 不会出现"贴边半个字"的遮挡 ✓。
   * 用于诊断与单测；拿不到坐标/视口时返回 null。
   *
   * @param positions - 节点坐标；缺省用最近一帧的坐标。
   * @param count - 节点数。
   * @returns 占比；拿不到坐标/视口时返回 null。
   */
  measureCoverage(positions = this.positions, count = this.positionCount): number | null {
    if (positions === null || count <= 0 || this.viewport.width <= 0 || this.viewport.height <= 0) return null;
    const box = this.projectedBox(this.state, positions, count);
    if (box === null) return null;
    return this.coverageOf(box);
  }

  /**
   * 缓冲/兜底：把相机距离复位到**旋转安全**的包围球取景（用户 2026-10-30 最终口径）。
   *
   * 为什么不是"按当前投影收紧"：那样旋转到不同角度时投影范围会变，只能跟着一缩一放 ✗
   * （用户实测："旋转的过程中整个节点显示区域的缩小和放大，体验不是很好"）。
   * 现在按"节点可能占据的最大平面面积" = **包围球的投影圆** 来定距离：
   * 球在任意旋转下投影都是同一个圆 ⇒ 距离不变、旋转时不缩放、任何角度都不裁切 ✓。
   *
   * 只在缓存相机恢复 / 布局结算 / 侧栏改宽时调用一次，只调距离，不动球心/朝向 ✓。
   *
   * **平面模式例外**：不能旋转 ⇒ 球心也要跟着当前图的几何中心走 ✓
   * （布局收敛那次取景读到的是插值中的坐标，最终位置可能差几个世界单位；
   *  相机距离又很近，这点偏差在屏幕上会被放大成明显的偏心 + 顶部标签被裁掉 ✗）。
   *
   * @param positions - 节点坐标；缺省用最近一帧的坐标。
   * @param count - 节点数。
   * @returns 是否真的改了相机。
   */
  ensureCoverage(positions = this.positions, count = this.positionCount): boolean {
    if (this.disposed || this.pointer !== null || this.animation !== null) return false;
    if (positions === null || count <= 0 || this.viewport.width <= 0 || this.viewport.height <= 0) return false;
    /* 平面模式：球心对准当前平面包围盒的中心（不能旋转 ⇒ 构图以几何中心为准 ✓） */
    let recentered = false;
    if (this.flat) {
      const center = this.flatBoxCenter(positions, count);
      if (center !== null
        && (Math.abs(center[0] - this.state.center[0]) > 1e-3
          || Math.abs(center[1] - this.state.center[1]) > 1e-3)) {
        this.state.center = center;
        recentered = true;
      }
    }
    /* 用**当前真实坐标**量球半径（缓存恢复的半径可能来自一张更大的旧图 ✗） */
    const radius = radiusAbout(positions, count, this.state.center);
    if (!(Number.isFinite(radius) && radius > 0)) return false;
    /*
     * 平面模式：按真实平面包围盒取景（不能旋转 ⇒ 不必按旋转安全球留白 ✓）；
     * 其余情况仍按旋转安全距离 ✓。
     */
    const distance = this.flat
      ? this.flatFitDistance(positions, count) ?? this.rotationSafeDistance(radius)
      : this.rotationSafeDistance(radius);
    if (!(Number.isFinite(distance) && distance > 0)) return false;
    const offset: Vec3 = [
      this.state.eye[0] - this.state.center[0],
      this.state.eye[1] - this.state.center[1],
      this.state.eye[2] - this.state.center[2],
    ];
    const current = Math.hypot(offset[0], offset[1], offset[2]);
    if (!recentered && current > 0 && Math.abs(distance - current) <= Math.max(0.5, current * 0.005)) return false;
    this.state.radius = radius;
    this.radiusMeasured = true;
    fitSphere(this.state, radius, distance);
    /* 平面模式：fitSphere 会沿"当前机位方向"放机位；平面要求严格的正面姿态 ✓ */
    if (this.flat) this.faceFront(this.state, Math.max(1, distance));
    this.syncCamera();
    this.options.onCameraChange();
    return true;
  }

  /** 布局结算等时机由引擎调用：下一帧按旋转安全距离复核 ✓（幂等） */
  markCoveragePending(): void {
    this.coveragePending = true;
  }

  /**
   * **旋转安全**的取景距离（用户 2026-10-30 最终口径）。
   *
   * 把整团节点看成包围球：球在任意旋转下投影都是同一个圆，
   * 所以按"**球投影直径 = 可用区域短边的 `TARGET_COVERAGE`**"反解距离即可。
   * 节点都在球内 ⇒ 任意旋转角度都不会被转出画面；距离只由半径与视口决定，
   * 与当前朝向无关 ⇒ 旋转过程中不会一缩一放 ✓。
   *
   * 推导：球投影的屏幕半径 = `focalPx · R / √(d² − R²)`，令其等于目标半径 ⇒
   * `d = R · √(1 + (focalPx / targetPx)²)`。
   *
   * 透视下球体轮廓是精确圆、与朝向无关；标签越界会被标签规划器跳过 ✓。
   *
   * @param radius - 以球心 C 量的包围球半径。
   * @returns 取景距离。
   */
  private rotationSafeDistance(radius: number): number {
    if (!(Number.isFinite(radius) && radius > 0)) return 200;
    const tanHalfV = Math.tan((FOV_DEG * Math.PI) / 360);
    const focalPx = this.viewport.height / 2 / tanHalfV;
    const usableWidth = Math.max(80, this.viewport.width - FRAME_INSETS.left - FRAME_INSETS.right);
    const usableHeight = Math.max(80, this.viewport.height - FRAME_INSETS.top - FRAME_INSETS.bottom);
    const usableMin = Math.min(usableWidth, usableHeight);
    const targetRadiusPx = Math.max(1, (TARGET_COVERAGE * usableMin) / 2);
    const distance = radius * Math.sqrt(1 + Math.pow(focalPx / targetRadiusPx, 2));
    return Math.max(distance, radius * 1.05);
  }

  /** 把节点投影到屏幕，返回**节点中心的包围盒**（px） */
  private projectedBox(
    state: InteriorState,
    positions: Float32Array,
    count: number,
  ): { minX: number; minY: number; maxX: number; maxY: number } | null {
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let seen = 0;
    for (let index = 0; index < count; index += 1) {
      const x = positions[index * 3];
      const y = positions[index * 3 + 1];
      const z = positions[index * 3 + 2];
      if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) continue;
      const display = displayOf(state, [x!, y!, z!]);
      const hit = projectDisplay(state, this.viewport, FOV_DEG, display);
      if (hit === null) return null;
      minX = Math.min(minX, hit.x);
      maxX = Math.max(maxX, hit.x);
      minY = Math.min(minY, hit.y);
      maxY = Math.max(maxY, hit.y);
      seen += 1;
    }
    return seen === 0 ? null : { minX, minY, maxX, maxY };
  }

  /** 投影包围盒 → 可用区域占比（只按节点中心 ✓） */
  private coverageOf(box: { minX: number; minY: number; maxX: number; maxY: number }): number {
    const usableWidth = Math.max(80, this.viewport.width - FRAME_INSETS.left - FRAME_INSETS.right);
    const usableHeight = Math.max(80, this.viewport.height - FRAME_INSETS.top - FRAME_INSETS.bottom);
    return Math.max(
      (box.maxX - box.minX) / usableWidth,
      (box.maxY - box.minY) / usableHeight,
    );
  }

  /**
   * 每帧推进定位/取景动画（P 线性插值、Q 球面插值）。
   *
   * **只有这里才把插值结果写进 state**（文档 P2）：命令之后、第一帧之前，
   * 状态必须还停在出发前 —— 否则按下取消动画时会从"终点"开始操作，产生突发移动 ✗，
   * 同步出去的 camera 也会提前暴露终点 ✗。
   */
  update(now: number): boolean {
    if (this.disposed) return false;
    const animation = this.animation;
    if (!animation) return false;
    const t = clampNum((now - animation.start) / animation.duration, 0, 1);
    const eased = 1 - Math.pow(1 - t, 3);
    this.state.eye = lerp3(animation.fromEye, animation.toEye, eased);
    this.state.view = quatSlerp(animation.fromView, animation.toView, eased);
    if (t >= 1) {
      /* 收尾时提交**精确终点**，别留插值残差 ✓ */
      this.state.eye = [...animation.toEye] as Vec3;
      this.state.view = animation.toView;
      this.animation = null;
    }
    this.syncCamera();
    this.options.onCameraChange();
    return true;
  }

  /**
   * 启动一次位姿动画。
   *
   * @param from - 起点（调用时的实际状态 ✓ —— 连续定位就自然接着上一次的插值位置 ✓）。
   * @param to - 终点（在临时副本上算出来的，提交之前不影响 state ✓）。
   * @param smooth - 是否要动画；「减少动态效果」或非 smooth ⇒ 立即提交且不留待执行动画 ✓。
   */
  private animateTo(
    from: { eye: Vec3; view: Quat },
    to: { eye: Vec3; view: Quat },
    smooth: boolean,
  ): void {
    const duration = smooth && !this.reducedMotion() ? FOCUS_DURATION_MS : 1;
    if (duration <= 1) {
      /* 立即到位：明确同步提交，并把待执行动画清掉 ✓ */
      this.state.eye = [...to.eye] as Vec3;
      this.state.view = to.view;
      this.animation = null;
      this.syncCamera();
      this.options.onCameraChange();
      return;
    }
    this.animation = {
      start: performance.now(),
      duration,
      fromEye: [...from.eye] as Vec3,
      toEye: [...to.eye] as Vec3,
      fromView: from.view,
      toView: to.view,
    };
    /* 起点不变：这里同步出去的仍是"出发前"的状态 ✓ */
    this.syncCamera();
    this.options.onCameraChange();
  }

  /** 在**临时副本**上算出"对准目标"的位姿（不碰真实状态 ✓） */
  private aimTarget(target: Vec3, distance: number): { eye: Vec3; view: Quat } {
    const draft = this.draftState();
    aimAt(draft, target, distance);
    return { eye: draft.eye, view: draft.view };
  }

  /** 在**临时副本**上算出"适应窗口"的位姿（不碰真实状态 ✓） */
  private fitTarget(radius: number, distance: number): { eye: Vec3; view: Quat } {
    const draft = this.draftState();
    fitSphere(draft, radius, distance);
    /* 平面模式：取景也必须保持正面姿态（fitSphere 只沿"当前机位方向"退到球外 ✓） */
    if (this.flat) this.faceFront(draft, Math.max(1, distance));
    return { eye: draft.eye, view: draft.view };
  }

  /** 复制一份状态用于试算 ✓ */
  private draftState(): InteriorState {
    return {
      center: [...this.state.center],
      eye: [...this.state.eye],
      view: [...this.state.view],
      scene: [...this.state.scene],
      radius: this.state.radius,
    };
  }

  /* ------------------------------- 指针交互 ------------------------------- */

  private local(event: { clientX: number; clientY: number }): { x: number; y: number } {
    const rect = this.options.element.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  private onPointerDown = (event: PointerEvent): void => {
    /* 右键留给节点菜单：这里完全不参与相机 */
    if (event.button !== 0) return;
    this.options.element.focus({ preventScroll: true });
    this.animation = null;
    const point = this.local(event);
    /*
     * 按下时**记录候选抓取点**（此时还不旋转）：
     * 必须用**按下那一刻**的指针位置取锚点 —— 等到越过阈值才取的话，
     * 指针已经离开节点几十像素，节点上就抓不到了（实测会退化成球面锚点 ✗）。
     */
    this.grab = this.flat || event.shiftKey ? null : this.buildGrab(point.x, point.y);
    /* 每次按下都从"抓取阶段"开始 ✓（连续阶段只在一次拖动里切一次 ✓） */
    this.dragPhase = "grab";
    this.spinGain = null;
    this.pointer = {
      id: event.pointerId,
      startX: point.x,
      startY: point.y,
      lastX: point.x,
      lastY: point.y,
      moved: false,
      captured: false,
      panning: event.shiftKey,
    };
    this.options.element.dataset.dragging = "true";
  };

  private onPointerMove = (event: PointerEvent): void => {
    const point = this.local(event);
    const pointer = this.pointer;
    if (pointer !== null && pointer.id === event.pointerId) {
      const dx = point.x - pointer.startX;
      const dy = point.y - pointer.startY;
      if (!pointer.moved && Math.hypot(dx, dy) > DRAG_THRESHOLD) {
        pointer.moved = true;
        /* 真的开始拖了才捕获指针：在 pointerdown 就捕获会把随后的 click 一并重定向 ✗ */
        this.options.element.setPointerCapture(event.pointerId);
        pointer.captured = true;
        /*
         * 只有**真的动过相机**才算"用户接管了视角" ✓：
         * 平面模式的普通拖动不旋转（不该被记成动过相机，否则后续取景/复核会误以为有人在操控 ✗）；
         * Shift 平移（任何模式）与三维模式的拖动才算 ✓。
         */
        if (pointer.panning || !this.flat) {
          this.userInteracted = true;
          this.interactedSinceRelayout = true;
        }
      }
      if (pointer.moved) {
        /*
         * 平面模式（节点数 ≤ 3）：**拖动不旋转图谱**（用户 2026-11-11 要求：
         * "无法用鼠标拖动旋转查看"）；Shift 平移保留 —— 它只动机位、不改朝向 ✓。
         * 短点击/悬停/右键不受影响（它们走下面的 click 与悬停路径 ✓）。
         */
        const cameraMoved = pointer.panning || !this.flat;
        if (cameraMoved) this.options.onUserCameraInput?.();
        if (pointer.panning) {
          const unit = clampNum(this.state.radius, 30, 400) * 0.0016;
          panEye(this.state, point.x - pointer.lastX, point.y - pointer.lastY, unit);
        } else if (cameraMoved && this.grab !== null) {
          if (this.dragPhase === "grab") {
            /*
             * 第一阶段：**抓取点跟手**（局部投影约束）。
             * 目标 = 抓取点初始屏幕位置 + 从按下点到当前位置的**总位移** ✓。
             */
            const target = { x: this.grab.screen.x + dx, y: this.grab.screen.y + dy };
            /*
             * 先做**可达性**判断：只转图谱时锚点始终在半径 r 的球面上，
             * 指针射线与那个球无交点 ⇒ 几何上永远到不了 ✗（提前判出来，别让求解器在边界振荡 ✓）。
             */
            const reachable = anchorReachable(this.state, this.viewport, FOV_DEG, this.grab.layout, target);
            const result = reachable
              ? dragAnchorTo(this.state, this.viewport, FOV_DEG, this.grab.layout, target)
              : { iterations: 0, error: Number.POSITIVE_INFINITY, lost: false, stalled: true, progressed: false };
            /*
             * **随手保存最后一次「条件良好」的映射**（文档要求 ✓）：
             * 连续阶段的增益必须来自这里 —— 到边界时那个 J 已经退化，
             * 拿它取逆会得到方向乱跳的角度（实测符号会翻 ✗）。
             */
            if (!result.stalled && !result.lost) {
              const refresh = dragGainAt(this.state, this.viewport, FOV_DEG, this.grab.layout);
              if (refresh !== null) this.spinGain = refresh;
            }
            /*
             * 不可达 / 停滞 / 病态 / 掉到相机后面 ⇒ 切到**连续旋转阶段** ✓
             * （不重置 scene、不动球心与相机、也不补算历史上到不了的位移 ✓）。
             */
            if (result.lost || result.stalled) this.enterContinuousSpin(point);
          } else {
            this.applyContinuousSpin(point);
          }
          /*
           * 旋转期间**不调相机距离**：取景距离是按包围球（任意旋转下的最大投影圆）定的，
           * 旋转本身不会再裁切；若这里跟着收紧就会一缩一放 ✗
           * （用户 2026-10-30："旋转过程中整个节点显示区域缩小和放大，体验不好"）。
           */
        }
        if (cameraMoved) {
          this.syncCamera();
          this.options.onCameraChange();
        }
        this.setHover(null);
      }
      pointer.lastX = point.x;
      pointer.lastY = point.y;
      return;
    }
    /* 没在拖动时才更新悬停：拖动越过节点不该频繁弹信息 */
    this.applyHover(this.hitTest(point.x, point.y));
  };

  /** 建立抓取点：节点优先，其次操作包围球面 ✓ */
  private buildGrab(x: number, y: number): GrabAnchor | null {
    return grabAnchor(this.state, this.viewport, FOV_DEG, this.options.getProjected(), x, y);
  }

  /**
   * 切到**连续旋转阶段**（文档 §第二阶段）。
   *
   * - 把当前位置设为新的**增量起点** ✓（后续用相邻事件的 dx/dy，不再追赶按下时的绝对目标 ✓）；
   * - 增益取自"最后一次条件良好的局部映射" ✓：优先用抓取点当前的 J，
   *   没有就用**按下时的球面参考区域**（相机射线命中的近侧/内壁 ✓），
   *   再没有才用相机自身轴的兜底增益 ✓；
   * - 不重置 scene、不动 C/P/Q ✓。
   *
   * @param point - 切换发生时的指针位置（画布内坐标）。
   */
  private enterContinuousSpin(point: { x: number; y: number }): void {
    this.dragPhase = "spin";
    this.spinLastX = point.x;
    this.spinLastY = point.y;
    const grab = this.grab;
    /*
     * 增益优先用抓取阶段**最后保存的那份条件良好的映射** ✓
     * —— 到边界时才现算的 J 已经退化，方向会乱跳（实测符号会翻 ✗）。
     */
    if (this.spinGain === null && grab !== null) {
      /* 一次都没保存过（例如按下就立刻不可达）⇒ 用"按下时的球面参考区域"重建映射 ✓ */
      const reference = anchorFromRay(this.state, this.viewport, FOV_DEG, grab.screen.x, grab.screen.y);
      this.spinGain = reference === null
        ? null
        : dragGainAt(this.state, this.viewport, FOV_DEG, reference.layout);
    }
    if (this.spinGain === null) this.spinGain = SPIN_FALLBACK_GAIN;
  }

  /**
   * 连续旋转一步：用**相邻事件**的增量映射成角度增量 ✓，限幅后累积到 `scene` ✓。
   * @param point - 当前指针位置（画布内坐标）。
   */
  private applyContinuousSpin(point: { x: number; y: number }): void {
    const gain = this.spinGain ?? SPIN_FALLBACK_GAIN;
    const dx = point.x - this.spinLastX;
    const dy = point.y - this.spinLastY;
    this.spinLastX = point.x;
    this.spinLastY = point.y;
    if (dx === 0 && dy === 0) return;
    const step = spinStep(this.state, gain, dx, dy);
    applySceneRotation(this.state, step.delta);
  }

  /** 只读快照（诊断与测试用；不外泄可变引用 ✓） */
  interiorSnapshot(): {
    center: Vec3;
    eye: Vec3;
    view: Quat;
    scene: Quat;
    radius: number;
    dragPhase: "none" | "grab" | "spin";
  } {
    return {
      center: [...this.state.center],
      eye: [...this.state.eye],
      view: [...this.state.view],
      scene: [...this.state.scene],
      radius: this.state.radius,
      dragPhase: this.pointer === null || this.grab === null ? "none" : this.dragPhase,
    };
  }

  private hitTest(x: number, y: number): ContextHit {
    const projected = this.options.getProjected();
    const node = pickNode(projected, x, y);
    if (node !== null) return { kind: "node", index: node };
    const edges = this.options.getEdges();
    /*
     * 关系拾取换成**插件自有**的"先按近裁剪面裁线段、再投影命中" ✓：
     * 上游 `pickEdge()` 只要有一个端点不可见就整条跳过 ✗，而相机进入云团后
     * "一个端点在身后"很正常 —— 于是屏幕上画着的线却点不到（文档 P2）。
     * 没有坐标时（还没同步过）退回上游实现，行为不至于更差 ✓。
     */
    const edge = this.positions !== null && this.positionCount > 0
      ? pickClippedEdge(this.positions, edges, this.basis(), this.viewport, FOV_DEG, x, y)
      : pickEdge(projected, edges, x, y);
    if (edge !== null) return { kind: "edge", index: edge };
    return { kind: "canvas" };
  }

  private applyHover(hit: ContextHit): void {
    this.setHover(hit.kind === "node" ? hit.index : null);
    this.setEdgeHover(hit.kind === "edge" ? hit.index : null);
  }

  private onPointerUp = (event: PointerEvent): void => {
    const pointer = this.pointer;
    if (pointer === null || pointer.id !== event.pointerId) return;
    this.pointer = null;
    this.grab = null;
    /* 连续旋转阶段只活在一次拖动里 ✓（下次按下重新选新的可见区域 ✓） */
    this.dragPhase = "grab";
    this.spinGain = null;
    delete this.options.element.dataset.dragging;
    if (pointer.captured && this.options.element.hasPointerCapture(event.pointerId)) {
      this.options.element.releasePointerCapture(event.pointerId);
    }
    if (pointer.moved) {
      /* 拖动之后浏览器还会补一次 click：用它拦住"转一下顺便换了当前节点" */
      this.suppressClick = true;
      if (this.suppressedTimer !== undefined) window.clearTimeout(this.suppressedTimer);
      this.suppressedTimer = window.setTimeout(() => {
        this.suppressClick = false;
      }, 60);
      return;
    }
    const point = this.local(event);
    const hit = this.hitTest(point.x, point.y);
    if (hit.kind === "node") {
      this.options.onSelect(hit.index);
      this.options.onSelectEdge?.(null);
      return;
    }
    if (hit.kind === "edge") {
      this.options.onSelectEdge?.(hit.index);
      return;
    }
    this.options.onSelect(null);
    this.options.onSelectEdge?.(null);
  };

  private onPointerCancel = (): void => {
    this.cancelPointer();
  };

  private onPointerLeave = (): void => {
    if (this.pointer === null) {
      this.setHover(null);
      this.setEdgeHover(null);
    }
  };

  private onDoubleClick = (event: MouseEvent): void => {
    if (this.suppressClick) return;
    const point = this.local(event);
    const hit = this.hitTest(point.x, point.y);
    if (hit.kind === "edge") {
      this.options.onSelectEdge?.(hit.index);
      return;
    }
    /*
     * 双击 = **只选中**（与单击同一个动作），不再"定位/放大局部视图" ✓。
     *
     * 用户 2026-10-29 第二轮："点击之后放大局部视图的功能你没动，这个也一块删了" ——
     * 第一轮已删掉"把球心搬过去"，这一轮把双击触发的相机定位也删掉：
     * 双击后画面**不缩放、不飞镜头**。按 F 键仍可显式定位（那一次只动相机、不改球心 ✓）。
     */
    this.options.onSelect(hit.kind === "node" ? hit.index : null);
  };

  private onContextMenu = (event: MouseEvent): void => {
    event.preventDefault();
    const point = this.local(event);
    const hit = this.hitTest(point.x, point.y);
    if (hit.kind === "node") this.options.onSelect(hit.index);
    if (hit.kind === "edge") this.options.onSelectEdge?.(hit.index);
    this.cancelPointer();
    this.options.onContextMenu(hit, event.clientX, event.clientY);
  };

  private setHover(index: number | null): void {
    if (this.hover === index) return;
    this.hover = index;
    this.options.onHover(index);
  }

  private setEdgeHover(index: number | null): void {
    if (this.hoverEdge === index) return;
    this.hoverEdge = index;
    this.options.onEdgeHover?.(index);
  }

  /* -------------------------------- 键盘 -------------------------------- */

  private onKeyDown = (event: KeyboardEvent): void => {
    if (event.code !== "KeyF") return;
    if (event.isComposing || event.ctrlKey || event.metaKey || event.altKey) return;
    const active = document.activeElement as HTMLElement | null;
    const focused =
      active !== null && (active === this.options.element || this.options.element.contains(active));
    if (!focused) return;
    event.preventDefault();
    this.options.onLocate();
  };

  private onWindowBlur = (): void => {
    this.cancelPointer();
  };

  private onVisibilityChange = (): void => {
    if (document.hidden) this.cancelPointer();
  };

  /** 丢掉未完成的拖动/抓取（切后台、失焦、右键菜单）✓ */
  cancelPointer(): void {
    this.pointer = null;
    this.grab = null;
    /* 两个阶段的状态一起清（失焦/取消都不该留下半个连续阶段 ✓） */
    this.dragPhase = "grab";
    this.spinGain = null;
    this.spinLastX = 0;
    this.spinLastY = 0;
    delete this.options.element.dataset.dragging;
  }

  /* ------------------------------- 动画 ------------------------------- */

  private reducedMotion(): boolean {
    return typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    const element = this.options.element;
    element.removeEventListener("pointerdown", this.onPointerDown);
    element.removeEventListener("pointermove", this.onPointerMove);
    element.removeEventListener("pointerup", this.onPointerUp);
    element.removeEventListener("pointercancel", this.onPointerCancel);
    element.removeEventListener("pointerleave", this.onPointerLeave);
    element.removeEventListener("dblclick", this.onDoubleClick);
    element.removeEventListener("contextmenu", this.onContextMenu);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("blur", this.onWindowBlur);
    window.removeEventListener(RELAYOUT_EVENT, this.onRelayoutRequest);
    document.removeEventListener("visibilitychange", this.onVisibilityChange);
    if (this.suppressedTimer !== undefined) window.clearTimeout(this.suppressedTimer);
    this.pointer = null;
    this.grab = null;
    this.animation = null;
  }
}

/* 让"定位"在没有任何姿态变化时也能工作：quatFromAxisAngle 等由 trackball 提供 ✓ */
