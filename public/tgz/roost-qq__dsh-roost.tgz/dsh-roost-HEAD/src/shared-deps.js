/**
 * 宿主级共享依赖（`deps/`）
 * ============================================================
 *
 * 有些依赖不是某个扩展私有的：`ffmpeg` 既能给 B 站扩展抽帧，也能给
 * 以后的语音转码、图片处理用。让每个扩展各装一份 62 MB，是纯粹的浪费，
 * 而且用户点三次「一键安装」就得等三遍。
 *
 * 所以装在这里：`<dataDir>/deps/`，跟着宿主数据目录走——
 *
 *   · 升级扩展不丢（扩展目录会被覆盖，宿主数据目录不会）；
 *   · 卸载扩展不删（别的扩展还要用）；
 *   · 一份装了全部复用（框架自己的功能也走 `ffmpegBinary()`）。
 *
 * 两个必须记住的坑：
 *
 *   1. **主包只有 24 KB 胶水代码**。62 MB 的 `ffmpeg.exe` 在同版本的
 *      平台子包（`@ffmpeg-installer/win32-x64`）里。`--omit=optional`、
 *      杀毒隔离、装到一半断电，都会留下「主包在、二进制没了」的半坏状态。
 *      所以判定「能不能用」永远以**可执行文件在不在**为准，不看
 *      `require.resolve`。
 *   2. **只装白名单**。面板上能点的东西如果能让机器执行任意包，那面板
 *      被改一下就等于交出了整台机器。白名单是这条链路的唯一闸门。
 */

import { existsSync, mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { join, delimiter } from 'node:path';
import { execFile } from 'node:child_process';
import { dataDir } from './config.js';
import { registryArgs } from './npm-registry.js';

/**
 * 允许安装的包。加新包前先想清楚：它有没有 postinstall 脚本？
 * 会不会在安装时执行任意代码？有脚本的一律不要——`--ignore-scripts`
 * 装不上，去掉 `--ignore-scripts` 就等于让 npm 跑别人的代码。
 *
 * `@ffmpeg-installer/*` 的平台子包把静态二进制直接打进 tarball，
 * 没有 postinstall，所以能安全地装在 `--ignore-scripts` 下。
 */
export const WHITELIST = Object.freeze({
  '@ffmpeg-installer/ffmpeg': {
    range: '^1.1.0',
    size: '~62MB',
    desc: '视频抽帧、音频转码',
  },
  /**
   * 二维码生成（B 站扫码登录用）。纯 JS、无安装脚本，`--ignore-scripts`
   * 装得上；用的是 `create()` 只取位矩阵，不碰它画图那部分。
   *
   * 扩展那边是「装了就优先用、没装就用内置兜底」，所以这个包缺失不会
   * 让扫码不可用，只是版本上限低一些。
   */
  qrcode: {
    range: '^1.5.4',
    size: '~1.6MB（含传递依赖）',
    desc: '生成二维码（扫码登录）',
  },
});

const FFMPEG = '@ffmpeg-installer/ffmpeg';

/** 装在哪：跟着宿主数据目录，升级/卸载扩展都不动它 */
export function depsDir() {
  return join(dataDir(), 'deps');
}

/** 平台子包目录名；不认识的平台返回空串 */
function platformDir() {
  const arch = process.arch === 'arm64' ? 'arm64' : 'x64';
  if (process.platform === 'win32') return `win32-${arch}`;
  if (process.platform === 'darwin') return `darwin-${arch}`;
  if (process.platform === 'linux') return `linux-${arch}`;
  return '';
}

/**
 * ffmpeg 可执行文件的绝对路径；没装 / 平台不认识返回空串。
 *
 * **不 spawn**：面板每秒都可能问一次状态，起进程太贵。
 * 「能不能真跑」由第一次真正用到它的时候暴露。
 *
 * @param {{fresh?: boolean}} [o] `fresh` 丢掉缓存重看磁盘（刚装完用）
 */
let ffmpegCache; // undefined=没查过；''=没有；string=路径
export function ffmpegBinary({ fresh = false } = {}) {
  if (fresh) ffmpegCache = undefined;
  if (ffmpegCache !== undefined) return ffmpegCache;

  const plat = platformDir();
  if (!plat) {
    ffmpegCache = '';
    return ffmpegCache;
  }
  const base = join(depsDir(), 'node_modules', '@ffmpeg-installer', plat);
  const exe = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';
  const p = join(base, exe);
  ffmpegCache = existsSync(p) ? p : '';
  return ffmpegCache;
}

/** 已装包读到版本；没装返回空串 */
function installedVersion(name) {
  const file = join(depsDir(), 'node_modules', name, 'package.json');
  try {
    return String(JSON.parse(readFileSync(file, 'utf8')).version ?? '');
  } catch {
    return '';
  }
}

/**
 * 系统 PATH 上的 ffmpeg；没有返回空串。
 *
 * 用户很可能已经用 apt / brew / choco / scoop 装过系统级 ffmpeg，
 * 再为它下 62MB 的 npm 包纯属浪费。这里只**扫 PATH 目录**看可执行文件
 * 在不在，不 spawn——面板随时可能问状态，起进程太贵。
 *
 * @param {{fresh?: boolean}} [o]
 * @returns {string}
 */
let systemFfmpegCache; // undefined=没查过；''=没有；string=路径
export function systemFfmpeg({ fresh = false } = {}) {
  if (fresh) systemFfmpegCache = undefined;
  if (systemFfmpegCache !== undefined) return systemFfmpegCache;

  const names = process.platform === 'win32'
    ? ['ffmpeg.exe', 'ffmpeg.cmd', 'ffmpeg.bat']
    : ['ffmpeg'];
  const dirs = String(process.env.PATH || process.env.Path || '')
    .split(delimiter)
    .map((d) => d.trim().replace(/^"|"$/g, ''))
    .filter(Boolean);

  for (const d of dirs) {
    for (const n of names) {
      const p = join(d, n);
      if (existsSync(p)) {
        systemFfmpegCache = p;
        return p;
      }
    }
  }
  systemFfmpegCache = '';
  return '';
}

/**
 * 这次该用哪个 ffmpeg：**装好的那份优先，其次系统 PATH**。
 *
 * 装好的那份是平台子包里的静态二进制，版本行为都确定；系统那份不可控但
 * 能省 62MB。调用方要的是「能转码就行」，两份都算数。
 *
 * @param {{fresh?: boolean}} [o]
 * @returns {{path: string, source: 'managed'|'system'|''}}
 */
export function resolveFfmpeg({ fresh = false } = {}) {
  const own = ffmpegBinary({ fresh });
  if (own) return { path: own, source: 'managed' };
  const sys = systemFfmpeg({ fresh });
  if (sys) return { path: sys, source: 'system' };
  return { path: '', source: '' };
}

/**
 * 当前正在装的那个包。
 *
 * **为什么放在模块里而不是让面板自己算时间**：`install()` 是一次
 * 几十秒到几分钟的 npm 调用，面板那边只能靠「点了之后过了多久」猜。
 * 用户在装到一半时刷新页面、或者干脆去点别的卡片再回来，前端那个
 * 计时器就没了——于是「明明在装，界面却写着没装」，再点一次等于
 * 排进第二次安装。状态放这里，谁问都答同一个真相。
 *
 * `step` 由 npm 的 stdout 推进一步（下载 / 解包 / 完成），目前只是
 * 大致阶段，够让用户看出「在动」。
 */
let current = null;

/**
 * 当前状态。**同步**：只读文件，面板可以随便问。
 *
 * `ready` 只由**必需项**决定；目前白名单里全是可选（用到才装），
 * 所以 `ready` 恒为 true，面板按 `packages[].available` 逐项显示。
 */
export function status() {
  const packages = {};
  for (const [name, meta] of Object.entries(WHITELIST)) {
    const version = installedVersion(name);
    const binary = name === FFMPEG ? ffmpegBinary({ fresh: true }) : '';
    /**
     * **以二进制为准**，不看版本号：包目录在、`package.json` 也在、
     * 但 exe 被删了（杀毒隔离 / 装一半断了），这时版本号会骗人说「装了」。
     * 反过来手动拷一份 exe 进来、没有主包 package.json，也应该判可用。
     */
    packages[name] = {
      version,
      available: name === FFMPEG ? Boolean(binary) : Boolean(version),
      binary,
      /**
       * 系统 PATH 上那份 ffmpeg（**不并进 `available`**）。
       *
       * `available` 的语义是「宿主装好的那份能不能用」，面板的「一键安装」
       * 按钮按它显示；把系统那份混进去会让按钮显示「已装好」，而装的目录
       * 里其实什么都没有。系统那份单独给，面板可以据此提示「不用再下 62MB」。
       */
      system: name === FFMPEG ? systemFfmpeg() : '',
      range: meta.range,
      size: meta.size,
      desc: meta.desc,
    };
  }
  return {
    dir: depsDir(),
    ffmpeg: ffmpegBinary(),
    /** 系统里那份 ffmpeg 的路径；没有就是空串 */
    systemFfmpeg: systemFfmpeg(),
    packages,
    /** 正在装：`{ name, startedAt, elapsedMs, step }`；没在装就是 null */
    installing: current
      ? { ...current, elapsedMs: Math.max(0, Date.now() - current.startedAt) }
      : null,
  };
}

/** 安装串行化：连点「一键安装」不该起两个 npm 互相踩目录 */
let chain = Promise.resolve();
/** 同一个包正在装：后来者等同一份结果，不重复下载 */
const inflight = new Map();

/**
 * npm 子进程的环境。
 *
 * 继承 `process.env`（npm 要读一大堆自己的配置：代理、缓存目录、userconfig…），
 * 但**摘掉本进程的密钥**——装依赖的子进程没理由看到 QQ AppSecret 或面板口令。
 * 以前这里是裸继承，等于把宿主进程的整个环境交给一个要联网的工具。
 *
 * 用「摘掉」而不是白名单：白名单一旦漏掉一个 `npm_config_*`，
 * 表现是「用户配了代理/源却不生效」，那种问题极难排查。
 */
function npmEnv() {
  const out = {};
  for (const [k, v] of Object.entries(process.env)) {
    if (/^(QQ_|ROOST_SECRET|ROOST_TOKEN|ROOST_PANEL)/i.test(k)) continue;
    out[k] = v;
  }
  return out;
}

/**
 * 安装白名单里的包。
 *
 * 返回 `{ ok, name, path, message, skipped }`，**不抛**：装失败的原因要原样
 * 带回面板，抛出去只会变成一句「500 内部错误」。
 *
 * @param {string} [name]
 * @param {{log?: Function, timeoutMs?: number, registry?: string, preferSystem?: boolean}} [o]
 *   `registry` 来自配置 `update.registry`，空则由 npm-registry 自己解析；
 *   `preferSystem` 为真时，系统 PATH 上已有 ffmpeg 就直接复用、不下载。
 */
export function install(name = FFMPEG, {
  log = () => {},
  timeoutMs = 300_000,
  registry = '',
  preferSystem = false,
} = {}) {
  const pkg = String(name ?? '').trim();
  if (!Object.hasOwn(WHITELIST, pkg)) {
    return Promise.resolve({ ok: false, name: pkg, message: `不在白名单里：${pkg || '(空)'}` });
  }

  /**
   * 已经能用就不跑 npm：这是最省事、也最不容易出错的「重装」。
   */
  if (pkg === FFMPEG) {
    const own = ffmpegBinary({ fresh: true });
    if (own) {
      return Promise.resolve({ ok: true, name: pkg, path: own, skipped: true, source: 'managed', message: '已经装好了' });
    }
    /**
     * 系统 PATH 上那份 ffmpeg：**只有调用方明确说「用系统的」才跳过安装**。
     *
     * 默认不跳过是有原因的：扩展是通过受管块里的 `ROOST_DEPS_DIR` 找
     * `<deps>/node_modules/@ffmpeg-installer/<plat>/ffmpeg.exe` 的，
     * 那是扩展和宿主之间唯一的约定。系统 PATH 上的那份它们看不见，
     * 直接跳过会让「面板说装好了、扩展说没装」——比多下 62MB 难查得多。
     *
     * 想让宿主自己省下这 62MB，把 `preferSystem` 打开（面板以后可以给个开关），
     * 但那时扩展得自己会找 PATH，不能只认 `ROOST_DEPS_DIR`。
     */
    const sys = systemFfmpeg({ fresh: true });
    if (sys && preferSystem) {
      return Promise.resolve({
        ok: true, name: pkg, path: sys, skipped: true, source: 'system',
        message: `系统里已有 ffmpeg（${sys}），按你的选择直接复用，不再下载 62MB`,
      });
    }
    if (sys) {
      log(`系统里已有 ffmpeg（${sys}），但仍会装一份到共享目录：扩展只认 ROOST_DEPS_DIR`);
    }
  } else if (installedVersion(pkg)) {
    /**
     * 纯 JS 包（qrcode）以前没有预检：每次点安装都跑一遍 npm，白等几十秒。
     * 目录里已经有就直接复用。
     */
    return Promise.resolve({
      ok: true, name: pkg, path: join(depsDir(), 'node_modules', pkg), skipped: true, source: 'managed',
      message: '已经装好了',
    });
  }
  if (inflight.has(pkg)) return inflight.get(pkg);

  const run = async () => {
    const dir = depsDir();
    try {
      mkdirSync(dir, { recursive: true });
      /**
       * npm 需要一个 package.json 才当项目目录用。**合并已有依赖**：
       * npm 7+ 会按这份清单 prune，只写本次这个包的话，先装的别的包
       * 会在下次安装时被静默删掉。
       */
      const file = join(dir, 'package.json');
      let cur = {};
      try {
        cur = JSON.parse(readFileSync(file, 'utf8'));
      } catch { /* 首次安装：没有旧文件很正常 */ }
      const deps = {};
      for (const [k, v] of Object.entries(cur?.dependencies ?? {})) {
        if (Object.hasOwn(WHITELIST, k)) deps[k] = String(v);
      }
      deps[pkg] = WHITELIST[pkg].range;
      writeFileSync(
        file,
        `${JSON.stringify({ name: 'dsh-roost-deps', private: true, dependencies: deps }, null, 2)}\n`,
        'utf8',
      );
    } catch (e) {
      return { ok: false, name: pkg, message: `准备目录失败：${e?.message ?? e}` };
    }

    const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
    /**
     * 源：配置里的 `update.registry` > 环境变量 > `.npmrc` > 官方。
     * 解析到官方时不加参数，参数与以前完全一致。
     */
    const regArgs = registryArgs({ override: registry });
    log(`开始安装共享依赖 ${pkg}（${WHITELIST[pkg].size}）→ ${dir}${regArgs.length ? `，源 ${regArgs[0].replace('--registry=', '')}` : ''}`);
    /**
     * 心跳：面板靠 `status().installing` 显示「已等待 N 秒」。
     *
     * npm 在这里几乎没有可读的阶段输出（`--loglevel=error`），所以
     * 「进度」只能是**时间 + 一行最后输出**。这不精确，但足以区分
     * 「在装」和「没动」——用户要的就是这个。
     */
    current = { name: pkg, startedAt: Date.now(), step: '' };
    return await new Promise((resolve) => {
      const child = execFile(
        npm,
        /**
         * `--ignore-scripts`：安装期不许执行任何包自带的脚本。
         * 白名单里的包都是静态二进制，不需要脚本；开着它就等于
         * 把「面板点一下」变成「机器上跑任意 postinstall」。
         */
        ['install', pkg, ...regArgs, '--no-audit', '--no-fund', '--loglevel=error', '--ignore-scripts'],
        {
          cwd: dir,
          timeout: timeoutMs,
          windowsHide: true,
          maxBuffer: 8 * 1024 * 1024,
          /** 继承环境但摘掉本进程密钥，见 `npmEnv()` */
          env: npmEnv(),
          /**
           * Windows 必须走 shell：Node 20 起 `execFile('npm.cmd')` 会直接
           * `EINVAL`（不能 spawn 批处理，除非过 shell）。参数里没有空格，
           * 拼进命令行是安全的；路径走 `cwd`，不参与拼接。
           */
          shell: process.platform === 'win32',
        },
        (err, _stdout, stderr) => {
          current = null;
          if (err) {
            const why = String(stderr || err.message || '').replace(/\s+/g, ' ').trim().slice(0, 400);
            log(`共享依赖安装失败：${why}`);
            return resolve({ ok: false, name: pkg, message: `安装失败：${why || '未知原因'}` });
          }
          const bin = pkg === FFMPEG ? ffmpegBinary({ fresh: true }) : '';
          if (pkg === FFMPEG && !bin) {
            return resolve({
              ok: false, name: pkg,
              message: '装完了但没找到 ffmpeg 可执行文件（平台子包可能没装上）',
            });
          }
          log(`共享依赖已就绪：${pkg}${bin ? ` → ${bin}` : ''}`);
          resolve({ ok: true, name: pkg, path: bin, message: '装好了' });
        },
      );
      /** 只留最后一行非空输出给面板看；`current` 可能已被上面的回调清掉 */
      const keep = (buf) => {
        const last = String(buf || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean).pop();
        if (last && current && current.name === pkg) current.step = last.slice(0, 120);
      };
      child?.stdout?.on?.('data', keep);
      child?.stderr?.on?.('data', keep);
    });
  };

  const task = chain.then(run, run).finally(() => inflight.delete(pkg));
  /** 失败不把链条卡死：下一次调用照样能跑 */
  chain = task.then(() => undefined, () => undefined);
  inflight.set(pkg, task);
  return task;
}

/** 给宿主内部用的便捷判断：ffmpeg 能不能用（以后语音转码、图片处理都能调） */
export function hasFfmpeg() {
  return Boolean(ffmpegBinary());
}
