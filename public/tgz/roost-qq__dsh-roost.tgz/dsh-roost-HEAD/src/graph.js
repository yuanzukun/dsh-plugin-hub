/**
 * 知识图谱：**纯 SQLite 三表，不引 Neo4j / Graphiti**。
 *
 * 为什么不引图数据库：这一层要存的东西是"她记得谁是谁、谁跟谁什么关系"，
 * 量级是几千条边，不是百万。为一个几千行的图拉起一个 JVM 服务，
 * 部署成本远大于它带来的查询能力（框架还是零依赖）。
 *
 * 三张表：
 *   entity   人 / 地点 / 东西。名字 + 别名，openid 记在 meta 里
 *   edge     关系，**双时态**：valid_from / valid_to
 *   episode  原始片段。图抽错了能拿它重建——**兜底比聪明重要**
 *
 * 双时态是这套设计的核心：
 *   「我住在杭州」→ 边(用户 —住在→ 杭州) valid_from=10月，valid_to=NULL
 *   后来「我搬到上海了」→ **不删杭州那条**，给它 valid_to=今天，再插一条上海
 *   问「现在住哪」→ `valid_to IS NULL` 只剩上海
 *   问「九月住哪」→ `asOf(九月)` 还能答杭州
 *   删了旧边就再也答不了后者，人也确实是这样记事的。
 *
 * 作用域：边带 `chat_id`，空串表示"跨群"。
 *   群里的梗只在这个群可见（防串场），关于主人本人的事实走跨群。
 *   这个归属由巩固时的模型给（三元组带 scope），不在这一层猜。
 */

import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
/** 实体/关系名是模型抽的，同样会带换行；注入前压成单行（见 `memory-line.js`） */
import { oneLine } from './memory-line.js';

/**
 * "同一时刻只能有一个值"的关系。
 *
 * 只有这些关系在"改主意"时需要把旧边关掉；「喜欢」这类可以有多个并存
 * （喜欢吃辣 ≠ 不喜欢吃甜），关掉就丢信息了。
 */
const FUNCTIONAL = /住|叫|名字|生日|工作|职业|年龄|学校|城市|老家|电话|手机|邮箱|上班|所在地/;

const normKey = (s) =>
  String(s ?? '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .slice(0, 60);

/** 一条边的可读形状 */
const edgeView = (r) => ({
  id: Number(r.id),
  src: String(r.src_name ?? ''),
  rel: String(r.rel ?? ''),
  dst: String(r.dst_name ?? ''),
  from: Number(r.valid_from ?? 0),
  to: r.valid_to == null ? null : Number(r.valid_to),
  chatId: String(r.chat_id ?? ''),
  episodeId: r.episode_id == null ? null : Number(r.episode_id),
});

/**
 * @param {object} o
 * @param {string} o.file  graph.sqlite 路径
 * @param {(m:string)=>void} [o.log]
 */
export function createGraph({ file, log = () => {} } = {}) {
  let db = null;
  let ready = false;
  let broken = false;

  function open() {
    if (ready) return db;
    ready = true;
    if (broken) return null;
    try {
      mkdirSync(dirname(file), { recursive: true });
      const { DatabaseSync } = process.getBuiltinModule
        ? process.getBuiltinModule('node:sqlite')
        : { DatabaseSync: null };
      if (!DatabaseSync) throw new Error('当前 Node 没有 node:sqlite');
      db = new DatabaseSync(file);
      db.exec('PRAGMA journal_mode=WAL');
      db.exec('PRAGMA synchronous=NORMAL');
      db.exec(`
        CREATE TABLE IF NOT EXISTS entity (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          key TEXT NOT NULL,
          name TEXT NOT NULL,
          aliases_json TEXT NOT NULL DEFAULT '[]',
          first_seen INTEGER NOT NULL DEFAULT 0,
          last_seen INTEGER NOT NULL DEFAULT 0,
          kind TEXT NOT NULL DEFAULT 'thing',
          chat_id TEXT NOT NULL DEFAULT ''
        );
        CREATE UNIQUE INDEX IF NOT EXISTS entity_key ON entity(key, chat_id);

        CREATE TABLE IF NOT EXISTS episode (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          at INTEGER NOT NULL,
          chat_id TEXT NOT NULL DEFAULT '',
          text TEXT NOT NULL,
          journal_id TEXT
        );

        CREATE TABLE IF NOT EXISTS edge (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          src_id INTEGER NOT NULL,
          rel TEXT NOT NULL,
          dst_id INTEGER NOT NULL,
          valid_from INTEGER NOT NULL,
          valid_to INTEGER,
          episode_id INTEGER,
          chat_id TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS edge_src ON edge(src_id, rel);
        CREATE INDEX IF NOT EXISTS edge_chat ON edge(chat_id, valid_to);

        /**
         * 墓碑：用户明确说过「这条关系不该存在」。
         *
         * 为什么需要单独一张表：光删 edge 没用——日记原文还在，
         * 凌晨巩固会把同一件事重新抽出来。删了又长回来，比删不掉更让人火大。
         *
         * 用 normKey(名字) 而不是 entity.id：实体删掉重建之后 id 会变，
         * 名字才是稳定标识。
         *
         * chat_id='' 表示**所有会话**都别再写（全局屏蔽）；
         * 带具体 id 就只拦那一个会话——同一个关系在 A 群是真的、B 群是错的，
         * 这种情况必须能分开。
         */
        CREATE TABLE IF NOT EXISTS suppress (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          src_key TEXT NOT NULL,
          rel TEXT NOT NULL,
          dst_key TEXT NOT NULL,
          chat_id TEXT NOT NULL DEFAULT '',
          at INTEGER NOT NULL,
          why TEXT NOT NULL DEFAULT ''
        );
        CREATE UNIQUE INDEX IF NOT EXISTS suppress_uniq
          ON suppress(src_key, rel, dst_key, chat_id);
      `);
      /**
       * "同一关系同一时刻只有一条活边"用**部分唯一索引**表达。
       * 普通 UNIQUE 在 SQLite 里把 NULL 当互不相等，挡不住重复活边。
       */
      db.exec(
        'CREATE UNIQUE INDEX IF NOT EXISTS edge_alive ON edge(src_id, rel, dst_id) WHERE valid_to IS NULL',
      );
      return db;
    } catch (e) {
      broken = true;
      db = null;
      log(`知识图谱不可用（${e.message}），记忆只剩 facts 和日记`);
      return null;
    }
  }

  const enabled = () => Boolean(open());

  /** 拿实体 id；没有就建。aliases 里已有的名字也能命中同一个实体 */
  function ensureEntity(name, { chatId = '', at = Date.now(), kind = 'thing', aliases = [] } = {}) {
    const d = open();
    if (!d) return 0;
    const raw = String(name ?? '').trim().slice(0, 60);
    const key = normKey(raw);
    if (!key) return 0;

    const hit = d.prepare('SELECT id, aliases_json FROM entity WHERE key=? AND chat_id=?').get(key, chatId);
    if (hit) {
      d.prepare('UPDATE entity SET last_seen=?, name=? WHERE id=?').run(at, raw || hit.name || raw, hit.id);
      return Number(hit.id);
    }
    // 别名反查：先找找有没有别的实体把它当别名
    const like = `%"${key}"%`;
    const byAlias = d
      .prepare('SELECT id FROM entity WHERE aliases_json LIKE ? AND chat_id=?')
      .get(like, chatId);
    if (byAlias) return Number(byAlias.id);

    const r = d
      .prepare(
        'INSERT INTO entity(key,name,aliases_json,first_seen,last_seen,kind,chat_id) VALUES (?,?,?,?,?,?,?)',
      )
      .run(key, raw, JSON.stringify((aliases || []).map(normKey).filter(Boolean)), at, at, kind, chatId);
    return Number(r.lastInsertRowid);
  }

  /**
   * 查实体 id，**不建新的**。找不到返回 0。
   *
   * 关边 / 删边用：`ensureEntity` 会顺手插一条实体，为了关一条边而造出
   * 两条孤儿实体纯属垃圾数据。命中规则和 `ensureEntity` 一致（先精确 key，
   * 再按别名反查），只是少了「没有就插」这一步。
   */
  function findEntityId(name, chatId = '') {
    const d = open();
    if (!d) return 0;
    const key = normKey(String(name ?? '').trim().slice(0, 60));
    if (!key) return 0;
    try {
      const hit = d.prepare('SELECT id FROM entity WHERE key=? AND chat_id=?').get(key, chatId);
      if (hit) return Number(hit.id);
      const byAlias = d
        .prepare('SELECT id FROM entity WHERE aliases_json LIKE ? AND chat_id=?')
        .get(`%"${key}"%`, chatId);
      return byAlias ? Number(byAlias.id) : 0;
    } catch {
      return 0;
    }
  }

  function addEpisode({ at = Date.now(), chatId = '', text = '', journalId = null } = {}) {
    const d = open();
    if (!d) return 0;
    const r = d
      .prepare('INSERT INTO episode(at,chat_id,text,journal_id) VALUES (?,?,?,?)')
      .run(Number(at) || Date.now(), chatId, String(text ?? '').slice(0, 2000), journalId);
    return Number(r.lastInsertRowid);
  }

  /**
   * 加一条边。同一条边（同一 src/rel/dst 且还活着）重复来就只更新时间，不重复插。
   *
   * 功能性关系（住在/叫/生日…）遇到不同的 dst 时，**把旧边关掉而不是删掉**，
   * 这就是双时态的落点。
   */
  function addEdge({ src, rel, dst, at = Date.now(), chatId = '', episodeId = null } = {}) {
    const d = open();
    if (!d) return 0;
    const r0 = String(rel ?? '').trim().slice(0, 40);
    if (!src || !dst || !r0) return 0;
    const t = Number(at) || Date.now();
    const sid = ensureEntity(src, { chatId, at: t });
    const did = ensureEntity(dst, { chatId, at: t });
    if (!sid || !did || sid === did) return 0;

    const alive = d
      .prepare('SELECT * FROM edge WHERE src_id=? AND rel=? AND dst_id=? AND valid_to IS NULL')
      .get(sid, r0, did);
    if (alive) return Number(alive.id);

    if (FUNCTIONAL.test(r0)) {
      // 旧的同关系活边全部关掉（valid_to 打上现在的时间，不是删除）
      d.prepare('UPDATE edge SET valid_to=? WHERE src_id=? AND rel=? AND valid_to IS NULL').run(t, sid, r0);
    }

    const r = d
      .prepare(
        'INSERT INTO edge(src_id,rel,dst_id,valid_from,valid_to,episode_id,chat_id) VALUES (?,?,?,?,NULL,?,?)',
      )
      .run(sid, r0, did, t, episodeId, chatId);
    return Number(r.lastInsertRowid);
  }

  /**
   * 关掉一条边（约定办完了、关系结束了）。
   * 不传 dst 就把这组 (src, rel) 的活边全关。
   *
   * `aliases` 一起关：换机器人之后「这条约定」横跨好几个 openid，
   * 只关当前键的话，旧键那条活边还能被别名读出来——约定永远办不完。
   */
  function closeEdge({ src, rel, dst = '', at = Date.now(), chatId = '', aliases = [] } = {}) {
    const d = open();
    if (!d) return 0;
    const t = Number(at) || Date.now();
    const r0 = String(rel ?? '').trim();
    const keys = chatKeys(chatId, aliases);
    /** 空 chatId = 不分会话，和 `suppressEdge` 的全局语义一致 */
    const scopes = keys.length ? keys : [''];
    let n = 0;
    for (const key of scopes) {
      /**
       * 实体是**按会话隔离**的（`entity(key, chat_id)` 唯一），所以每个键都要
       * 各自查一遍 id。用同一个 id 去关别的键的边，`changes` 恒为 0。
       */
      const sid = findEntityId(src, key);
      if (!sid) continue;
      if (dst) {
        const did = findEntityId(dst, key);
        if (!did) continue;
        n += Number(
          d
            .prepare('UPDATE edge SET valid_to=? WHERE src_id=? AND rel=? AND dst_id=? AND valid_to IS NULL')
            .run(t, sid, r0, did).changes || 0,
        );
      } else {
        n += Number(
          d.prepare('UPDATE edge SET valid_to=? WHERE src_id=? AND rel=? AND valid_to IS NULL').run(t, sid, r0).changes || 0,
        );
      }
    }
    return n;
  }

  /**
   * 删掉一条关系，并记住「别再写回来」。
   *
   * 光 DELETE 是不够的：日记原文还在，凌晨巩固会把同一件事重新抽出来。
   * 所以这里是一个事务里的两步——删干净 + 立墓碑。
   *
   * 删的是**同名全部边**（活边 + 已经结束的），不只是活边：
   * 用户说"这条关系不对"时，面板「以前成立、现在不成立」那栏里还留着一条
   * 一模一样的，等于没删掉。
   *
   * 实体不级联删：可能还有别的边引用它，孤儿本身无害。
   *
   * @param {object} o
   * @param {string} o.src 主语
   * @param {string} o.rel 关系名
   * @param {string} o.dst 宾语
   * @param {string} [o.chatId] 只在这个会话里屏蔽；空串 = 所有会话
   * @param {string} [o.why] 为什么删（面板上显示，省得以后想不起）
   * @returns {{ok:boolean, removed:number, reason?:string}}
   */
  function suppressEdge({ src, rel, dst, chatId = '', why = '', at = Date.now(), aliases = [] } = {}) {
    const d = open();
    if (!d) return { ok: false, removed: 0, reason: '图谱没启用' };
    const s = String(src ?? '').trim();
    const r = String(rel ?? '').trim();
    const o = String(dst ?? '').trim();
    if (!s || !r || !o) return { ok: false, removed: 0, reason: 'src / rel / dst 都得有' };

    const t = Number(at) || Date.now();
    const sk = normKey(s);
    const ok = normKey(o);
    const cid = String(chatId ?? '');
    /**
     * 删边要覆盖**所有别名键**，墓碑只立一条（立在当前键上）。
     *
     * 只删当前键的话：读路径带别名把旧键的边读出来了（面板看得见），
     * 用户点「删掉这条」→ `removed: 0` → 一刷新它还在。
     * 墓碑不用每个键都立一条：`isSuppressed` 已经会看别名键。
     */
    const keys = chatKeys(chatId, aliases);

    let removed = 0;
    try {
      d.exec('BEGIN');
      /**
       * 删边用**名字**定位，不经过 `ensureEntity`。
       *
       * `ensureEntity` 会顺手把不存在的实体插进去——为了删一条边而造出
       * 两条实体，纯属垃圾。这里直接 join 名字。
       */
      const del = d.prepare(
        `DELETE FROM edge WHERE rel=? AND src_id IN (SELECT id FROM entity WHERE key=?)
         AND dst_id IN (SELECT id FROM entity WHERE key=?) AND chat_id=?`,
      );
      if (!keys.length) {
        /**
         * `chatId` 空 = **全局屏蔽**（面板「这条关系不对，所有会话都别写」）。
         * 这时候删的是**所有会话**的边，不是只删 `chat_id=''` 那几条——
         * 旧实现靠 `(?='' OR chat_id=?)` 做到这点，改成按键循环之后
         * 必须显式保留，否则「全局删除」会变成「几乎什么都没删」。
         */
        removed = Number(
          d
            .prepare(
              `DELETE FROM edge WHERE rel=? AND src_id IN (SELECT id FROM entity WHERE key=?)
               AND dst_id IN (SELECT id FROM entity WHERE key=?)`,
            )
            .run(r, sk, ok).changes || 0,
        );
      } else {
        for (const key of keys) removed += Number(del.run(r, sk, ok, key).changes || 0);
      }
      d.prepare(
        `INSERT INTO suppress(src_key, rel, dst_key, chat_id, at, why) VALUES (?,?,?,?,?,?)
         ON CONFLICT(src_key, rel, dst_key, chat_id)
         DO UPDATE SET at=excluded.at, why=excluded.why`,
      ).run(sk, r, ok, cid, t, String(why ?? '').slice(0, 120));
      d.exec('COMMIT');
    } catch (e) {
      try {
        d.exec('ROLLBACK');
      } catch {}
      return { ok: false, removed: 0, reason: e?.message || String(e) };
    }
    return { ok: true, removed };
  }

  /** 撤销屏蔽。撤销之后巩固会重新把它抽回来——这是对的，不是 bug */
  function unsuppressEdge({ id, src, rel, dst, chatId } = {}) {
    const d = open();
    if (!d) return { ok: false, removed: 0, reason: '图谱没启用' };
    try {
      if (id) {
        return { ok: true, removed: Number(d.prepare('DELETE FROM suppress WHERE id=?').run(Number(id)).changes || 0) };
      }
      const sk = normKey(src);
      const r = String(rel ?? '').trim();
      const ok = normKey(dst);
      if (!sk || !r || !ok) return { ok: false, removed: 0, reason: 'id 或者 src/rel/dst 得有' };
      const cid = String(chatId ?? '');
      return {
        ok: true,
        removed: Number(
          d.prepare('DELETE FROM suppress WHERE src_key=? AND rel=? AND dst_key=? AND chat_id=?')
            .run(sk, r, ok, cid).changes || 0,
        ),
      };
    } catch (e) {
      return { ok: false, removed: 0, reason: e?.message || String(e) };
    }
  }

  /**
   * 这条关系是不是被屏蔽过。
   *
   * 两条命中路径：**本会话**的墓碑，或者 `chat_id=''` 的全局墓碑。
   * 反过来不成立——只屏蔽了 A 群，B 群照样能写。
   *
   * @returns {boolean}
   */
  function isSuppressed({ src, rel, dst, chatId = '', aliases = [] } = {}) {
    const d = open();
    if (!d) return false;
    const sk = normKey(src);
    const r = String(rel ?? '').trim();
    const ok = normKey(dst);
    if (!sk || !r || !ok) return false;
    try {
      /**
       * 别名键也看：墓碑可能立在换机器人之前的旧键上。
       * 不看的话，旧键屏蔽过的关系会被巩固原样写回来。
       */
      const keys = chatKeys(chatId, aliases);
      const hit = d
        .prepare(
          `SELECT 1 FROM suppress WHERE src_key=? AND rel=? AND dst_key=?
           AND (chat_id='' OR chat_id IN (${keys.map(() => '?').join(',') || "''"})) LIMIT 1`,
        )
        .get(sk, r, ok, ...keys);
      return Boolean(hit);
    } catch {
      return false;
    }
  }

  /** 面板用：列出屏蔽清单（新删的在前） */
  function suppressed({ chatId = '', limit = 50 } = {}) {
    const d = open();
    if (!d) return [];
    try {
      const sql = chatId
        ? 'SELECT * FROM suppress WHERE chat_id=? OR chat_id=\'\' ORDER BY at DESC LIMIT ?'
        : 'SELECT * FROM suppress ORDER BY at DESC LIMIT ?';
      const rows = chatId ? d.prepare(sql).all(chatId, limit) : d.prepare(sql).all(limit);
      return rows.map((r) => ({
        id: r.id,
        src: r.src_key,
        rel: r.rel,
        dst: r.dst_key,
        chatId: r.chat_id,
        at: r.at,
        why: r.why,
      }));
    } catch {
      return [];
    }
  }

  const SELECT_EDGE = `
    SELECT e.*, s.name AS src_name, t.name AS dst_name
    FROM edge e
    JOIN entity s ON s.id = e.src_id
    JOIN entity t ON t.id = e.dst_id
  `;
  /**
   * `chat_id` 的过滤片段：`(e.chat_id IN (?,?) OR e.chat_id='')`。
   *
   * `aliases` 是换机器人之后的备用键（号码 + 该号码名下的所有 openid）。
   * 图谱按会话隔离，不带别名的话旧边读不到——「她记得以前」就成了空话。
   * 跨群（`chat_id=''`）那一支保持原样，不受影响。
   *
   * @returns {{sql: string, args: string[]}} 没有 chatId 时返回空片段
   */
  /**
   * 当前键 + 别名，去重、去空、当前键排第一。
   *
   * 读路径和写路径（关边 / 删边）都要用同一份。写路径漏掉它，
   * 就会出现「读得到、删不掉」——用户说「这条关系不对」，删完一刷新还在。
   */
  function chatKeys(chatId, aliases) {
    const keys = [];
    for (const k of [chatId, ...(Array.isArray(aliases) ? aliases : [])]) {
      const v = String(k ?? '').trim();
      if (v && !keys.includes(v)) keys.push(v);
    }
    return keys;
  }

  function chatScope(chatId, aliases, col = 'e.chat_id') {
    const keys = chatKeys(chatId, aliases);
    if (!keys.length) return { sql: '', args: [] };
    return { sql: ` AND (${col} IN (${keys.map(() => '?').join(',')}) OR ${col}='')`, args: keys };
  }

  /** 现在的状态：只要活边。`chatId` 给定时包含跨群（chat_id=''）的边 */
  function nowEdges({ chatId = '', limit = 50, aliases = [] } = {}) {
    const d = open();
    if (!d) return [];
    const scope = chatScope(chatId, aliases);
    const sql = `${SELECT_EDGE} WHERE e.valid_to IS NULL${scope.sql} ORDER BY e.valid_from DESC LIMIT ?`;
    return d.prepare(sql).all(...scope.args, limit).map(edgeView);
  }

  /** 某个时刻的状态（"九月住哪"）。双时态的第二个维度 */
  function edgesAsOf(ts, { chatId = '', limit = 50, aliases = [] } = {}) {
    const d = open();
    if (!d) return [];
    const t = Number(ts) || Date.now();
    const scope = chatScope(chatId, aliases);
    const sql = `${SELECT_EDGE} WHERE e.valid_from<=? AND (e.valid_to IS NULL OR e.valid_to>?)${scope.sql} ORDER BY e.valid_from DESC LIMIT ?`;
    return d.prepare(sql).all(t, t, ...scope.args, limit).map(edgeView);
  }

  /** 已经结束的边（想看"改过什么主意"时用） */
  function endedEdges({ chatId = '', limit = 50, aliases = [] } = {}) {
    const d = open();
    if (!d) return [];
    const scope = chatScope(chatId, aliases);
    const sql = `${SELECT_EDGE} WHERE e.valid_to IS NOT NULL${scope.sql} ORDER BY e.valid_to DESC LIMIT ?`;
    return d.prepare(sql).all(...scope.args, limit).map(edgeView);
  }

  function entities({ chatId = '', limit = 50, aliases = [] } = {}) {
    const d = open();
    if (!d) return [];
    const scope = chatScope(chatId, aliases, 'chat_id');
    const sql = `SELECT * FROM entity WHERE 1=1${scope.sql} ORDER BY last_seen DESC LIMIT ?`;
    return d.prepare(sql)
      .all(...scope.args, limit)
      .map((r) => ({
        id: Number(r.id),
        name: String(r.name),
        aliases: (() => {
          try {
            return JSON.parse(r.aliases_json || '[]');
          } catch {
            return [];
          }
        })(),
        firstSeen: Number(r.first_seen || 0),
        lastSeen: Number(r.last_seen || 0),
        kind: String(r.kind || 'thing'),
      }));
  }

  /**
   * 注入用的一段文字。
   *
   * 只给"现在还成立的"边，且压到 `A —关系→ B` 一行一条。
   * 为什么不把历史边一起给：那是查档案的活，不是聊天的活，
   * 给了反而让她把"以前住杭州"当"现在住杭州"说出去。
   */
  function text({ chatId = '', max = 300, limit = 10, aliases = [] } = {}) {
    if (!enabled()) return '';
    const rows = nowEdges({ chatId, limit, aliases });
    if (!rows.length) return '';
    const lines = rows.map((e) => `${oneLine(e.src)}—${oneLine(e.rel)}→${oneLine(e.dst)}`);
    let out = '';
    for (const line of lines) {
      if (out.length + line.length + 3 > max) break;
      out += (out ? '\n' : '') + '· ' + line;
    }
    return out;
  }

  /**
   * 某个实体牵涉到的日记 id。
   *
   * 用途：检索的**第三路**（关键词 / 向量 / 实体）。问"张三最近在忙什么"时
   * 字面命中往往很差，但图谱里"张三—工作在→X"是现成的，能把她带到对的日记上。
   *
   * 走 `episode.journal_id` 反查，**不改表结构**——episode 本来就记着来源日记。
   * （更准的做法是 edge 直接存 journal_id，但那要迁移；先用现成的。）
   */
  function linkedJournalIds(entityName, { chatId = '', limit = 20, aliases = [] } = {}) {
    const d = open();
    if (!d) return [];
    const key = normKey(entityName);
    if (!key) return [];
    try {
      const scope = chatScope(chatId, aliases, 'g.chat_id');
      const sql = `SELECT DISTINCT e.journal_id AS jid
           FROM entity n
           JOIN edge g ON (g.src_id = n.id OR g.dst_id = n.id)
           JOIN episode e ON e.id = g.episode_id
           WHERE n.key = ? AND e.journal_id IS NOT NULL${scope.sql}
           LIMIT ?`;
      const rows = d.prepare(sql).all(key, ...scope.args, limit);
      return rows.map((r) => String(r.jid)).filter(Boolean);
    } catch (e) {
      log(`实体反查日记失败：${e.message}`);
      return [];
    }
  }

  /**
   * 从命中实体**再扩一跳**取日记（P1，2026-11-18）。
   *
   * `linkedJournalIds()` 只走「实体 → 它自己的边 → 日记」。问「张三最近忙什么」
   * 时，如果那些日记里压根没出现「张三」三个字，就一条也捞不到。这一层多走
   * 一步：命中实体 A 的邻接实体 B（A—关系→B 或 B—关系→A），再取 B 牵涉的日记。
   *
   * 三条必须守住的边界，缺一条就会串味：
   *  1. **`keys` 为空直接不启用**。`chatScope()` 在 keys 为空时返回空片段 =
   *     不过滤 = 全表扫，私聊 / 没有别名的场景会把所有会话的日记都联想进来。
   *  2. **只卡日记归属，不卡片边归属**。串味的本质是「把别的群的日记内容带进来」，
   *     而日记归属由 `episode.chat_id` 决定——边和实体允许挂全局（`chat_id=''`）。
   *     真实库里 84 个实体有 36 个是全局的（「主人」「倦飞之鸟」这种跨会话的人），
   *     如果连实体和边都限定本会话，二跳在真实数据上恒为空，等于没做。
   *  3. **只走活边**（`valid_to IS NULL`），并排除自环（`m.key <> n.key`）。
   *
   * 走 `episode.journal_id` 反查，和第一跳一样**不改表结构**；二跳没有"这条边
   * 自己记的日记"这种精度要求，多绕一层 join 足够。
   *
   * @returns {string[]} 日记 id，按日记时间倒序、已去重
   */
  function adjacentJournalIds(entityName, { chatId = '', limit = 3, aliases = [] } = {}) {
    const d = open();
    if (!d) return [];
    const key = normKey(entityName);
    if (!key) return [];
    const keys = chatKeys(chatId, aliases);
    if (!keys.length) return [];
    const marks = keys.map(() => '?').join(',');
    try {
      const sql = `SELECT ep.journal_id AS jid, MAX(ep.at) AS latest
           FROM entity n
           JOIN edge g1 ON (g1.src_id = n.id OR g1.dst_id = n.id)
           JOIN entity m ON m.id = CASE WHEN g1.src_id = n.id THEN g1.dst_id ELSE g1.src_id END
           JOIN edge g2 ON (g2.src_id = m.id OR g2.dst_id = m.id)
           JOIN episode ep ON ep.id = g2.episode_id
           WHERE n.key = ?
             AND (n.chat_id IN (${marks}) OR n.chat_id='')
             AND g1.valid_to IS NULL AND g2.valid_to IS NULL
             AND ep.chat_id IN (${marks})
             AND ep.journal_id IS NOT NULL
             AND m.key <> n.key
           GROUP BY ep.journal_id
           ORDER BY latest DESC
           LIMIT ?`;
      const rows = d.prepare(sql).all(key, ...keys, ...keys, limit);
      return rows.map((r) => String(r.jid)).filter(Boolean);
    } catch (e) {
      log(`邻接联想失败：${e.message}`);
      return [];
    }
  }

  /** 这条 (主语, 关系) 现在有没有活边。给"改主意"的护栏用 */
  /**
   * 这组 (src, rel) 还有没有活边。
   *
   * `aliases` 一起看：换机器人之后旧活边在旧键下，只看当前键会判成「没有」，
   * 于是 `op='update'` 不去关旧边，新边加上去 → 带别名读出来**两个答案**。
   */
  function hasActive(src, rel, { chatId = '', aliases = [] } = {}) {
    const d = open();
    if (!d) return false;
    const r0 = String(rel ?? '').trim();
    if (!src || !r0) return false;
    const keys = chatKeys(chatId, aliases);
    for (const key of keys.length ? keys : ['']) {
      /** 用查找而不是 `ensureEntity`：问一句「有没有」不该顺手造实体 */
      const sid = findEntityId(src, key);
      if (!sid) continue;
      const row = d
        .prepare('SELECT id FROM edge WHERE src_id=? AND rel=? AND valid_to IS NULL LIMIT 1')
        .get(sid, r0);
      if (row) return true;
    }
    return false;
  }

  function stats() {
    const d = open();
    if (!d) return { enabled: false, entities: 0, edges: 0, episodes: 0 };
    const one = (sql) => Number(d.prepare(sql).get()?.c || 0);
    return {
      enabled: true,
      entities: one('SELECT COUNT(*) c FROM entity'),
      edges: one('SELECT COUNT(*) c FROM edge WHERE valid_to IS NULL'),
      ended: one('SELECT COUNT(*) c FROM edge WHERE valid_to IS NOT NULL'),
      episodes: one('SELECT COUNT(*) c FROM episode'),
    };
  }

  /**
   * 按会话统计（「账号迁移」页扫描用）。只读。
   *
   * `edges` 只数**现在还成立的**边（`valid_to IS NULL`），和 `stats()` 同口径；
   * 结束掉的边算进去会让「这个键还有没有记忆」看起来虚高。
   */
  function scanChats() {
    const d = open();
    if (!d) return [];
    const out = new Map();
    const bump = (col, sql) => {
      for (const r of d.prepare(sql).all()) {
        const k = String(r.chat_id || '');
        if (!k) continue;
        const e = out.get(k) || { chatId: k, edges: 0, episodes: 0 };
        e[col] = Number(r.c || 0);
        out.set(k, e);
      }
    };
    bump('edges', 'SELECT chat_id, COUNT(*) c FROM edge WHERE valid_to IS NULL GROUP BY chat_id');
    bump('episodes', 'SELECT chat_id, COUNT(*) c FROM episode GROUP BY chat_id');
    return [...out.values()];
  }

  /**
   * 把一批旧键的图谱痕迹**整体搬**到号码键下（一键改写用），然后旧键不再有数据。
   *
   * 难点全在唯一约束上，不能一句 `UPDATE ... SET chat_id=?` 了事：
   *   · `entity` 有 `UNIQUE(key, chat_id)` —— 目标键下已有同名实体时要合并，
   *     并把引用旧实体 id 的边重定向，不能撞约束。
   *   · `edge` 有 `edge_alive` 部分唯一索引 `(src_id, rel, dst_id) WHERE valid_to IS NULL`
   *     —— 合并实体后可能产生重复活边，要先去重。
   *   · `suppress` 也有唯一索引，同组合的墓碑只留一条。
   *
   * 整个流程一个事务：中途任何一步失败全部回滚，不能留下「改了一半」的图谱。
   */
  function rekey(fromKeys, toKey) {
    const to = String(toKey ?? '').trim();
    const keys = [
      ...new Set((Array.isArray(fromKeys) ? fromKeys : []).map((k) => String(k ?? '').trim()).filter(Boolean)),
    ].filter((k) => k !== to);
    const d = open();
    const zero = { entities: 0, edges: 0, episodes: 0, suppress: 0, mergedEntities: 0 };
    if (!to || !keys.length || !d) return zero;
    const marks = keys.map(() => '?').join(',');

    d.exec('BEGIN');
    try {
      /** 1. 旧实体 → 目标键下同名实体的 id；没有同名的就原地改归属 */
      const idMap = new Map();
      const dropEntities = new Set();
      const oldEnts = d.prepare(`SELECT id, key FROM entity WHERE chat_id IN (${marks})`).all(...keys);
      for (const e of oldEnts) {
        const hit = d.prepare('SELECT id FROM entity WHERE key=? AND chat_id=?').get(e.key, to);
        if (hit) {
          idMap.set(e.id, hit.id);
          dropEntities.add(e.id);
        } else {
          idMap.set(e.id, e.id);
        }
      }

      /** 2. 目标键下已有的活边，用来判重 */
      const alive = new Set();
      for (const r of d.prepare('SELECT src_id, rel, dst_id FROM edge WHERE chat_id=? AND valid_to IS NULL').all(to)) {
        alive.add(`${r.src_id}\u0000${r.rel}\u0000${r.dst_id}`);
      }

      /** 3. 旧边：算好新 id，重复的活边删掉，其余改归属 */
      const delEdge = d.prepare('DELETE FROM edge WHERE id=?');
      const updEdge = d.prepare('UPDATE edge SET src_id=?, dst_id=?, chat_id=? WHERE id=?');
      let edges = 0;
      const oldEdges = d.prepare(`SELECT * FROM edge WHERE chat_id IN (${marks})`).all(...keys);
      for (const e of oldEdges) {
        const ns = idMap.get(e.src_id) ?? e.src_id;
        const nd = idMap.get(e.dst_id) ?? e.dst_id;
        const k = `${ns}\u0000${e.rel}\u0000${nd}`;
        if (e.valid_to == null && alive.has(k)) {
          /** 目标键下已经有一条一模一样的活边了，旧键这条是重复 */
          delEdge.run(e.id);
          continue;
        }
        updEdge.run(ns, nd, to, e.id);
        if (e.valid_to == null) alive.add(k);
        edges += 1;
      }

      /** 4. 删掉被合并掉的旧实体，剩下的改归属 */
      const delEnt = d.prepare('DELETE FROM entity WHERE id=?');
      for (const id of dropEntities) delEnt.run(id);
      const updEnt = d.prepare('UPDATE entity SET chat_id=? WHERE id=?');
      let entities = 0;
      for (const e of oldEnts) {
        if (dropEntities.has(e.id)) continue;
        entities += Number(updEnt.run(to, e.id).changes || 0);
      }

      /** 5. 原始片段直接改归属（引用的是行 id，不受实体合并影响） */
      const episodes = Number(
        d.prepare(`UPDATE episode SET chat_id=? WHERE chat_id IN (${marks})`).run(to, ...keys).changes || 0,
      );

      /** 6. 墓碑：目标键已有同组合就保留那条，删掉旧键的重复 */
      let suppress = 0;
      const oldSup = d.prepare(`SELECT * FROM suppress WHERE chat_id IN (${marks})`).all(...keys);
      for (const s of oldSup) {
        const dup = d
          .prepare('SELECT id FROM suppress WHERE src_key=? AND rel=? AND dst_key=? AND chat_id=?')
          .get(s.src_key, s.rel, s.dst_key, to);
        if (dup) {
          d.prepare('DELETE FROM suppress WHERE id=?').run(s.id);
          continue;
        }
        d.prepare('UPDATE suppress SET chat_id=? WHERE id=?').run(to, s.id);
        suppress += 1;
      }

      d.exec('COMMIT');
      return { entities, edges, episodes, suppress, mergedEntities: dropEntities.size };
    } catch (e) {
      try { d.exec('ROLLBACK'); } catch {}
      throw e;
    }
  }

  /**
   * 把图清掉，**episode 留着**。
   *
   * 抽错了（模型把"喜欢"抽成"住在"）时，正确的修法是从原始片段重建，
   * 而不是手工删边。所以这个函数故意不碰 episode 表。
   */
  function reset({ keepEpisodes = true } = {}) {
    const d = open();
    if (!d) return false;
    d.exec('DELETE FROM edge');
    d.exec('DELETE FROM entity');
    if (!keepEpisodes) d.exec('DELETE FROM episode');
    return true;
  }

  /**
   * 删掉某个会话在图谱里的**全部痕迹**：原始片段、边、实体。
   *
   * 为什么必须有：「彻底删除日记」以前只删 journal 表，而 `episode.text`
   * 里存着当天日记正文的拼接（最多 1200 字，见 consolidate 写 episode 的地方），
   * 边是抽出来的关系——原文在另一个文件里完整留了一份，
   * 用户要的「这些记录不许存在」就成了一句空话。
   *
   * 墓碑（`suppress`）**故意不删**：那是"这条关系别再记"的指令，
   * 删了之后巩固会把用户明确删掉的关系重新抽回来。
   *
   * @returns {{episodes:number, edges:number, entities:number}}
   */
  function purgeChat(chatId) {
    const d = open();
    const zero = { episodes: 0, edges: 0, entities: 0 };
    if (!d) return zero;
    d.exec('BEGIN');
    try {
      /** 顺序：先边（引用实体）、再实体、最后片段 */
      const edges = Number(d.prepare('DELETE FROM edge WHERE chat_id=?').run(chatId).changes || 0);
      const entities = Number(d.prepare('DELETE FROM entity WHERE chat_id=?').run(chatId).changes || 0);
      const episodes = Number(d.prepare('DELETE FROM episode WHERE chat_id=?').run(chatId).changes || 0);
      d.exec('COMMIT');
      return { episodes, edges, entities };
    } catch (e) {
      try {
        d.exec('ROLLBACK');
      } catch {}
      log(`清图谱失败（图谱里的原文可能还在）：${e.message}`);
      return zero;
    }
  }

  function episodes({ chatId = '', limit = 20 } = {}) {
    const d = open();
    if (!d) return [];
    const sql = chatId
      ? 'SELECT * FROM episode WHERE chat_id=? ORDER BY at DESC LIMIT ?'
      : 'SELECT * FROM episode ORDER BY at DESC LIMIT ?';
    return d.prepare(sql).all(...(chatId ? [chatId, limit] : [limit]));
  }

  return {
    enabled,
    addEpisode,
    addEdge,
    closeEdge,
    /** 删一条关系 + 立墓碑（删了不会再被巩固写回来） */
    suppressEdge,
    /** 撤销屏蔽 */
    unsuppressEdge,
    /** 这条关系是不是被屏蔽过（巩固写之前要问一句） */
    isSuppressed,
    /** 屏蔽清单（面板用） */
    suppressed,
    ensureEntity,
    /**
     * 删掉一个实体及其所有关系边（面板星图详情「删掉这个实体」）。
     * 只删当前会话（或全局）的痕迹，不碰别的群。
     */
    removeEntity(ref, { chatId = '', aliases = [] } = {}) {
      const d = open();
      if (!d) return { ok: false, message: '图谱没打开' };
      const raw = String(ref ?? '').trim();
      if (!raw) return { ok: false, message: '没给实体' };

      /**
       * **优先按 id 删**。星图里的实体可能来自别名会话（换机器人前的旧 openid），
       * 按「当前 chatId + 名字」查会一条都匹配不上——表现就是点删除弹出
       * 「没做成」但不说为什么。id 是实体行自己的主键，跨会话唯一。
       */
      const byId = Number(raw);
      let rows = [];
      if (Number.isInteger(byId) && byId > 0) {
        rows = d.prepare('SELECT id FROM entity WHERE id = ?').all(byId);
      }
      if (!rows.length) {
        const key = normKey(raw);
        const scope = [String(chatId || ''), '', ...(Array.isArray(aliases) ? aliases.map(String) : [])]
          .filter((v, i, a) => a.indexOf(v) === i);
        const marks = scope.map(() => '?').join(',');
        rows = d.prepare(
          `SELECT id FROM entity WHERE (key = ? OR name = ?) AND chat_id IN (${marks})`,
        ).all(key, raw, ...scope);
      }
      if (!rows.length) return { ok: false, message: '没找到这个实体（可能刚被删过）' };
      let edges = 0;
      for (const r of rows) {
        edges += Number(d.prepare('DELETE FROM edge WHERE src_id = ? OR dst_id = ?').run(r.id, r.id).changes || 0);
        d.prepare('DELETE FROM entity WHERE id = ?').run(r.id);
      }
      return { ok: true, removed: rows.length, edges, message: `删掉了 ${rows.length} 个实体、${edges} 条关系` };
    },
    nowEdges,
    edgesAsOf,
    endedEdges,
    entities,
    episodes,
    linkedJournalIds,
    /** P1：命中实体的邻接实体牵涉的日记（二跳，默认关，见 `features.graphAdjacent`） */
    adjacentJournalIds,
    /** 彻底删某个会话在图谱里的痕迹（日记被彻底删除时跟着走） */
    purgeChat,
    hasActive,
    text,
    stats,
    /** 按会话统计（「账号迁移」页扫描用），只读 */
    scanChats,
    /** 一键改写：把一批旧键的图谱痕迹整体搬到号码键下（事务） */
    rekey,
    reset,
    isFunctional: (rel) => FUNCTIONAL.test(String(rel ?? '')),
    close() {
      try {
        db?.close();
      } catch {}
      db = null;
      ready = false;
    },
  };
}
