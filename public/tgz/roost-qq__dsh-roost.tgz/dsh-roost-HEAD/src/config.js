/**
 * 插件配置。存在 DSH 的数据目录里，不碰 Roost 的配置。
 *
 * 为什么不复用 Roost 的 config/bot.json：那份里是 AppID / Secret 这类凭证，
 * 属于「机器人运行环境」；这里是「DSH 这边怎么被找到、用什么人格」，
 * 生命周期不一样，混在一起升级和迁移都麻烦。
 */

import { readFileSync, writeFileSync, chmodSync, mkdirSync, existsSync, renameSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { homedir } from 'node:os';
/**
 * 频道发帖的默认值放在 `channel-post.js` 里（那份才是唯一来源），
 * 这里只展开一次。该模块不 import 本文件，不会形成循环依赖。
 */
import { POST_DEFAULTS } from './channel-post.js';

/** 数据目录：默认 ~/.dsh/dsh-roost，可用 DSH_ROOST_DATA 覆盖 */
export function dataDir() {
  const d = process.env.DSH_ROOST_DATA || join(homedir(), '.dsh', 'dsh-roost');
  if (!existsSync(d)) mkdirSync(d, { recursive: true });
  return d;
}

const FILE = () => join(dataDir(), 'config.json');

/**
 * 首次接入向导的版本号。
 *
 * 参考 aurabot 的 `setupDone`，但用**递增版本**而不是布尔：这个版本移除了
 * ai-chat、只留直连，老用户升级后必须重新接一遍，不能像 aurabot 那样
 * 「老配置直接算完成」。以后再出破坏性迁移，把这个数 +1 即可让所有人重走。
 *
 * 配置里存的是「已经走到第几版」（`setup.wizardVersion`），低于它就弹向导。
 * 新装 = 0，老配置没有这个字段 = 0，两种人都得走，正好符合要求。
 */
export const WIZARD_VERSION = 1;

export const DEFAULTS = {
  /**
   * 总开关。关掉后**全停**：消息一条不接（不进模型、不写记忆、不占额度）、
   * 出站一条不发、六个定时行为与两个启动补跑一起停。
   *
   * 缺省 `true`：老配置没有这个键，升级后行为必须逐字节一致。
   * 面板本身照常可用——它走宿主 HTTP，不经 QQ 通道。
   */
  enabled: true,
  /**
   * 试运行。照常收消息、照常跑模型、照常写记忆与日记，只是**不真的发到 QQ**。
   *
   * 拦截点在最底层的 `channel.send`（四条出站路径的唯一汇合处），
   * 另加短记的 `publish()`——它直接 `callQq('putThread')`，不走通道。
   *
   * 缺省 `false`：不做任何人的默认动作。
   */
  dryRun: false,
  server: {
    /** 固定服务的端口（/v1 控制面、TTS、健康检查）。端口被占会自动顺延 */
    port: 17321,
    /** 共享密钥。请求要带 X-Roost-Token 头；留空表示不校验（只绑本机时可行） */
    token: '',
  },
  /**
   * 可选语音合成。默认关闭：不请求上游、不加载本地模型。
   * provider 的输出通过固定回环服务交给调用方，音频格式由响应 Content-Type 指明。
   */
  tts: {
    enabled: false,
    /**
     * openai = OpenAI 兼容 /audio/speech；gpt-sovits = 原生 API；sherpa = 本地 ONNX（离线）；
     * edge = 微软在线朗读；mimo = 小米 MiMo（音频从 chat/completions 里以 base64 回）
     */
    provider: 'openai',
    /** OpenAI-compatible API 根地址，需包含版本前缀（例如 /v1） */
    baseUrl: '',
    apiKey: '',
    model: '',
    voice: '',
    timeoutSec: 30,
    maxChars: 300,
    /**
     * 语速倍率，四个 provider **共用这一个**。1 是原速。
     *
     * 范围 0.5–2：各家上限不同（OpenAI 到 4、微软 rate 到 +200%），
     * 取交集最保守，面板上一个输入框切换 provider 时不用重填。
     * 各 provider 内部再各自夹紧一次。
     *
     * 以前只有 `sherpa.speed`，云端和 GPT-SoVITS 都没得调——同一个「语速」
     * 分成两套配置最容易出现「改了没反应，因为改的不是当前 provider 那份」。
     */
    speed: 1,
    gptSovits: {
      /** GPT-SoVITS 安装目录（含 api_v2.py 和 runtime 的那层）。填了就能在面板一键启动 */
      installDir: '',
      /** 要用的角色名（面板扫描出来的下拉）。留空 = 用 tts_infer.yaml 里已经加载的那个 */
      model: '',
      /**
       * 手动指定权重路径，**优先于上面按角色名自动配对的结果**。
       *
       * 自动配对靠 `guessCharacter()` 从文件名猜角色名，权重一多（用户实测
       * 有 15 个）很容易把不同 epoch、不同角色的 GPT/SoVITS 配错一对，
       * 表现就是「输出正常但音色完全不对」。填了这两个就以它为准。
       * 路径是 **GPT-SoVITS 服务进程**能读到的（绝对路径最稳），留空 = 用扫描结果。
       */
      gptWeights: '',
      sovitsWeights: '',
      /** GPT-SoVITS API 根地址，例如 http://127.0.0.1:9880 */
      baseUrl: '',
      /** 反向代理可选 Bearer 密钥；原生本地 API 通常留空 */
      apiKey: '',
      /** GPT-SoVITS 服务进程能读取到的参考音频路径 */
      referWavPath: '',
      promptText: '',
      promptLanguage: '中文',
      textLanguage: '中文',
      /** api.py 常见协议字段命名：v1=refer_wav_path，v2=ref_audio_path */
      apiVersion: 'v1',
      /** 原生 API 默认根路由；兼容 fork 可指定其固定相对路由 */
      endpointPath: '/',
    },
    /**
     * 微软在线朗读（Edge TTS）。
     *
     * 不用填地址、不用填 Key，选一个音色就能用；依赖在面板一键装到
     * `dataDir/tts-edge/node_modules`。**文本会发到微软的服务器**，
     * 介意隐私就换本地 sherpa。
     */
    edge: {
      voice: 'zh-CN-XiaoxiaoNeural',
    },
    /**
     * 小米 MiMo（`mimo-v2.5-tts` 系列）。
     *
     * 它**没有** `/audio/speech`：音频是走 `POST /chat/completions` 合成的，
     * 以 base64 回在 `choices[0].message.audio.data` 里。所以必须单独一个
     * provider——填进 openai 分支的话，`status()` 会判「已配置」，
     * 直到真正合成才 404（issue #4 实测）。
     *
     * `messages` 里 **`assistant` 那条才是要念的文本**，`user` 那条是语气/
     * 音色描述（`voicedesign` 模型下必填）。没有 `speed` 参数，固定原速。
     */
    mimo: {
      /** 根地址，含版本前缀；代码里会自动接 `/chat/completions` */
      baseUrl: 'https://api.xiaomimimo.com/v1',
      apiKey: '',
      model: 'mimo-v2.5-tts',
      /** 预置音色见 `src/tts.js` 的 `MIMO_VOICES`；`voiceclone` 模型也可填样本 */
      voice: 'mimo_default',
      /** 语气提示，会作为 `user` 消息发出去 */
      prompt: '请用自然、亲切的语气朗读下面这句话。',
    },
    /**
     * 本地 ONNX 推理（sherpa-onnx-node）。
     *
     * 引擎和模型都不进插件目录，放在数据目录里：
     *   · `dataDir/tts-runtime/node_modules` —— 原生模块（23MB），删目录即卸载
     *   · `dataDir/tts-models/<模型>`         —— 模型文件（aishell3 约 30MB）
     *
     * 这样 DSH 更新插件时不会把用户装的东西覆盖掉，也方便一键安装/卸载。
     */
    sherpa: {
      /** 目前只有 aishell3（30MB / 8kHz / 174 个音色），加模型要在 tts.js 的 SHERPA_MODELS 里登记 */
      model: 'aishell3',
      /** 留空 = 数据目录/tts-models/vits-icefall-zh-aishell3；填了就按填的找 */
      modelDir: '',
      /** 说话人编号（aishell3 是 0-173），换一个就是换一个音色 */
      sid: 88,
      /**
       * 语速已经统一到 `tts.speed`（四个 provider 共用一份）。
       * 这里**不再有** `speed` 字段：留着一个改了不生效的同名字段，
       * 比没有更让人困惑——「我明明改了语速」却听不出区别。
       */
      /** CPU 线程数。2 已经够快，加多了在小机器上反而抢 CPU */
      numThreads: 2,
    },
  },
  /**
   * 5.11 安全防护：危险命令二次确认 + 出站 URL 的 SSRF 校验。
   * 两项都默认开；`allowPrivate` 是给自建内网服务留的显式开关，
   * 不是「看起来像本机就放行」。
   */
  security: {
    dangerousConfirm: true,
    ssrf: {
      allowPrivate: false,
      allowHosts: [],
    },
  },
  chat: {
    /**
     * 5.13 单聊「正在输入」：回合开始前先告诉对方在打字（官方 msg_type=6）。
     * 一轮可能跑几十秒，没有这个提示时对方看到的是完全没反应。
     * 每会话 60 秒最多一次；只对私聊。默认开，嫌多可以关。
     */
    typing: true,
    /** 一轮最多等多久（秒）：留余量给回话，别让用户干等 */
    turnTimeoutSec: 150,
    /**
     * 给不给她「翻聊天记录」的工具（`chat_look`）。
     *
     * 和 `memory.tools` 同一信任级别：都是只读，关掉不影响她说话。
     * 默认开；面板「能力」页能关（见 `features.js` 的 `chatTools`）。
     */
    tools: true,
    /**
     * 同一会话最多排几条消息。
     *
     * 默认 2：实测单轮中位 2–3 秒，第二条最多等几秒，成本远小于「丢消息」。
     * `0` = 关掉排队，行为和以前一致（忙时回「上一条还在想」）。
     */
    queueMax: 2,
    /**
     * 轮到它时剩余时间不足这么多秒就不跑了。
     *
     * 一轮超过 180 秒体验就很差了，跑一次模型 + 工具链常见十几秒；剩不到 30 秒还开跑，
     * 大概率赶不上回话窗口，白烧一次调用。
     */
    queueMinBudgetSec: 30,
    /**
     * 允许**在群里**查别的群的消息。
     *
     * 默认关。关着时跨群查询只在主人私聊里可用——因为群里的回复是
     * 所有人都看得见的，一旦允许「在 A 群问 B 群聊了啥」，B 群的对话就漏给 A 群了。
     *
     * 打开后**仍然只对主人开放**：这是个「我知道风险、我担着」的开关，
     * 不是「给群友开权限」。目标也仍然只能是群，别人的私聊永远不查。
     */
    crossChatInGroup: false,
    /**
     * 群友能不能用 `chat_look`（会话查询工具）。
     *
     * 默认关 —— 20:42 主人拍板「做成能力页选项、主人自选」：不硬编码
     * owner-only，也不默认放开。打开后只是把 `chat_look` 加进 member/admin
     * 等档位的工具白名单；`tools.js` 的 execute 仍按 bucket / kind / 目标群
     * 硬拒跨会话，群友永远只能翻当前会话，别人的私聊任何情况下都不查。
     *
     * ⚠️ 必须显式写 false：`features.js:273` 的 `readFeatures()` 对 toggle
     * 缺省返回 true（没配 = 开）。省略这一行等于默认给群友放权。
     */
    chatLookForMembers: false,
    /**
     * 上游模型报 502/429/超时时的**插件层补重试**。
     *
     * 为什么 DSH 自己重试 5 次了还要我们再试：
     * DSH 的重试是同一个请求连发 5 次，退避最长 7.8 秒，全在同一条连接上。
     * 上游要是整个网关挂了 30 秒，它 5 次全挂（实测就是 502 连挂两轮）。
     * 我们等几秒**重新投一轮**，等于给它一个「上游恢复了」的窗口。
     *
     * 只对上游错误重试。blocked（要人工处理）/ empty / busy 重投只会刷屏。
     */
    upstreamRetry: {
      enabled: true,
      /** 补几次。1 = 失败后再补 1 轮，总共 2 轮 */
      attempts: 1,
      /** 补重试前等多久（毫秒） */
      delayMs: 3000,
      /**
       * **整轮的总预算（秒）**。
       *
       * 每一次尝试各自有 `turnTimeoutSec`（150 秒）的超时，
       * 补一次重试就变成 150+3+150=303 秒——远超一轮可接受的总时长，
       * 超了它就报「宿主没回话」，群里那边也已经错过时机了。
       *
       * 所以留一个整体预算，重投前先看还剩多少，够才投。
       * 默认 170 秒，留 10 秒余量给收尾回话。
       */
      budgetSec: 170,
    },
  },
  /**
   * QQ 会话挂到哪个 DSH 工作区。
   *
   * 默认给机器人单开一个工作区（`<数据目录>/workspace`），
   * 不跟你的日常会话挤在同一个默认工作区里——否则机器人一开，
   * 满屏都是「QQ · xxx」的会话，还容易点到。
   * 想改回默认工作区，把 dir 设成 `__default__`。
   */
  workspace: {
    /** 工作区目录。留空 = <数据目录>/workspace；`__default__` = 用 DSH 默认工作区 */
    dir: '',
    /** 工作区名字。留空 = 跟随目录名（DSH 默认）；填了就按这个名字建/改 */
    name: '',
  },
  /**
   * 每一档权限能用什么：`all` = 全部工具，`chat` = 只能聊天。
   *
   * **默认只有主人能用工具。** 群聊里说话的是谁不受你控制，
   * 所以默认收紧——想让普通群友也能用（比如让他帮你看个文件），
   * 自己把 member 改成 all。
   *
   * `unknown` 是兜底：拿不到权限信息时按最严处理。不建议放开。
   */
  permissions: {
    owner: 'all',
    admin: 'chat',
    member: 'chat',
    unknown: 'chat',
  },
  /** 一键流程用：装到哪、装哪个版本 */
  setup: {
    /** 留空 = <数据目录>/roost */
    roostDir: '',
    /**
     * 首次接入向导已完成到第几版。低于 `WIZARD_VERSION` 时面板强制弹向导，
     * 走完（直连自测通过）才写回当前版本。
     */
    wizardVersion: 0,
    /** 本版「暂时跳过」过了没有：跳过不写 wizardVersion，概览页仍会催 */
    wizardSkippedVersion: 0,
    /**
     * 一键装下载的框架版本 —— **现在只是兜底**。
     *
     * 安装时会先问「最新是哪个」（npm latest → Gitee tags），问到就用最新的，
     * 问不到（断网之类）才退回这里。
     *
     * 为什么改成动态：这个字段是人手填的，每次框架发版都要记得改，
     * 漏一次新机器就装回旧版——之前停在 v0.8.1/v0.8.3 而框架已经 0.8.6，
     * 就是这个原因。人手维护的版本号必然会漂。
     */
    version: 'v0.8.6',
    /**
     * 用哪种方式接入机器人（第 7 期起可切）。
     * `qr` = 官方扫码；`manual` = 自己填 AppID / AppSecret。
     */
    registration: 'qr',
  },
  /**
   * 记忆：日记（三级）/ 知识图谱 / 检索 / 凌晨巩固。
   *
   * 全部默认开着且**不花白天的钱**：日记写入是本地 SQLite，巩固在凌晨做，
   * 向量默认关（要额外一个 /embeddings 端点，不配就纯关键词）。
   */
  memory: {
    /**
     * 记忆库容量（面板「分层与遗忘」可调）。
     * `total` 默认 40，与升级前写死的值一致；`perTier` 是每层额外配额，
     * 0 / 不填 = 不限。先按层裁、再按总数裁，临时层不会把长期层挤光。
     */
    capacity: {
      total: 40,
      perTier: {},
    },
    enabled: true,
    /**
     * 这些会话**不记也不读**（纯净模式）。
     *
     * 为什么需要：全局 `enabled` 一关全关，可真实场景往往是"就这个群别带记忆"——
     * 群里有人要求别记，或者不想让她把别处的梗带进来。按会话关，别处照常。
     *
     * 三条语义（照 dsh-pure-mode 的做法）：
     *   · **写入也停**：只挡注入的话，关着时说的话第二天还会从日记里冒出来；
     *   · **不动已有记忆**：关掉 ≠ 清空，关回来还在（要清用「清空本会话记忆」）；
     *   · **整轮一致**：注入、检索、写日记、记忆工具全按同一个判断走。
     * 分散着判必然漏一处 —— 漏在「写日记」上是"关着还照记"，漏在「注入」上是
     * "关了还照说"，两种在面板上都看不出来。
     */
    offChats: [],
    /** 到期天数：普通几天后压成半句，重要两三周后压成一句。critical 永不到期 */
    keepDays: { normal: 3, important: 21 },
    /**
     * 每多少轮**全量**重注一次记忆。
     *
     * 为什么不全量每轮注：`systemPrompt.context` 每个请求都要重发一遍，
     * 全量记忆几百字，15 轮就是白烧十几倍 token。平时只给"最近说的 + 检索引擎命中的几条"，
     * 每 15 轮把全量铺一次，防止细节被上下文压缩吃掉。
     */
    deepEvery: 15,
    /** 注入的条数 */
    topK: 6,
    hits: 3,
    /**
     * 把易变内容（刚才说到 / 命中 / 条数）移出 system prompt，改拼进用户消息。
     *
     * 为什么要移：system prompt 每个请求都重发，内容一变整段 prompt cache
     * 就失效。`false` 退回旧行为（全部塞 system prompt，前缀每轮都变）。
     */
    freezeSystem: true,
    /**
     * 给模型注册记忆工具（`memory_search` / `memory_note`），让她能主动翻日记。
     * 关掉只是不注册，自动注入那条路照常。
     */
    tools: true,
    /** 凌晨几点巩固（本地时间）。错过就下次检查时补跑 */
    consolidateHour: 4,
    /** 巩固用的会话标识（内部用，不连 QQ） */
    consolidateChat: 'consolidate',
    /**
     * 向量检索（可选）。填成 `{ model:'bge-m3', baseUrl:'http://x/v1', apiKey:'k' }`
     * 才开；留空就是纯关键词，不报错。
     */
    embedding: null,
    /**
     * 可选过期策略（调研报告 D11）。
     *
     * 2026-11-08 主人拍板「两类都做，让用户自由开关」→ 拆成**两路各自一个
     * mode**，共用阈值与最短保护期：
     *   · `factsMode`   自动提炼的事实（w=1、非手记）；默认 `expire`
     *   · `journalMode` 低等级日记行；默认 `off`（碰检索候选集，风险高一档）
     * 三态仍只用一个字段：`off` / `expire`（作废不删行）/ `purge`（真删，先备份）。
     * 不拆成 `enabled` 布尔 + 枚举，否则又出现「两份真相」。
     *
     * `thresholdPct` 用整数百分数（5 = R < 0.05）而不是小数，
     * 因为能力页的 number 控件只收整数（`normalizeSetting` 明确拒非整数）。
     *
     * 注意：默认开的只是**策略档位**，不会自动改盘上数据。要点面板上的
     * 「应用」才落 `until`/`invalid_at`，没点之前记忆文件逐字节不变。
     *
     * `appliedAt` 是「用户手动点过一次『应用』」的凭据（0 = 没点过）。
     * 没点过时凌晨的自动 sweep 一律跳过，默认用户的数据零改动；点过之后
     * 才按当前策略每天自动重复。「一键恢复」会把它清回 0，否则第二天又把
     * 刚恢复的条目重新作废。
     */
    retention: {
      factsMode: 'expire',
      journalMode: 'off',
      thresholdPct: 5,
      minProtectDays: 30,
      appliedAt: 0,
    },
  },
  /** 心情影响发送概率（调研报告 B2）。状态本身在 mood.json，这里只放开关。
   *  3.5：halfLifeHours=回中性半衰期（≥0.5）、baseline=衰减落点（夹在 0.45–0.9，
   *  必须高于低阈值 0.4，否则「衰减到不了低档」这条设计被反过来打破） */
  mood: {
    effects: false,
    halfLifeHours: 4,
    baseline: 0.5,
  },
  /**
   * 错峰（D10 / 3.2）。mode 两种：
   *   · 'self'：原自定判据——谷时窗口 + 安静期（默认，升级前后一致）；
   *   · 'official'：DeepSeek 官方峰时——北京时间工作日（不含法定节假日）
   *     9–12 / 14–18 为高峰，其余空闲；与计价档位同一份判据。
   * deferHeavy 开了才把锁库/过期压缩这类重活限到谷时跑（默认关，行为不变）。
   * holidays 覆盖内置节假日表，结构同 offpeak.js 的 CN_HOLIDAY_TABLE
   *（键是年份），只写要覆盖的年份。
   */
  offpeak: {
    mode: 'self',
    startHour: 0,
    endHour: 6,
    quietMinutes: 20,
    deferHeavy: false,
    holidays: null,
  },
  /**
   * 用量金额（3.1）。pricing 覆盖内置价目：键是「模型名含这个子串」（小写），
   * 值是 `{ label?, peak: {uncached, cacheRead, cacheWrite, output}, idle: {...} }`，
   * 元 / 百万 tokens。内置只放核过官方页的 DeepSeek 两档（见 src/pricing.js）；
   * 其它厂商标「未定价」不猜折扣。价格会过期，面板注明「以官网为准」。
   */
  usage: {
    pricing: {},
  },
  /**
   * 召回参数（3.3 / B3）。默认值 = 原写死值，升级后行为一模一样；
   * 调坏了把值删掉（或空）就回到默认——预算类键 `|| 默认` 兜底。
   *
   * **刻意不做「最低相关度」**：检索是 RRF 名次融合（k=60），
   * 相邻名次分差只有 ~1.6%，没有跨路可比的分数，
   * 那个旋钮调了也没反应（见路线图 §0.8 第 4 条）。
   */
  recall: {
    /**
     * 重排候选（Reranker）。默认关：重排会改变注入顺序 = 改变她先想起什么，
     * 升级不该悄悄换一批。开了之后：配了向量走向量相似度，没配走确定性规则。
     */
    rerank: {
      enabled: false,
      /** 相关性占多少，剩下给 RRF 原名次 */
      weight: 0.6,
      useVector: true,
    },
    /** 关键词 / 向量各取多少条进融合（原写死 40） */
    perPath: 40,
    /** 参与联想的实体上限（原写死 40） */
    entityLimit: 40,
    /** 每个实体联想几条日记（原写死 5） */
    linkLimit: 5,
    /**
     * 邻接联想（二跳）每个实体再取几条（`features.graphAdjacent` 打开才用）。
     *
     * 比 `linkLimit` 小是有意的：这一层是猜测，宁可少联想几条，也不要拿
     * 一堆弱关联去挤真正的直接证据。
     */
    adjacentLimit: 3,
    /** 平时（非深度重注）记忆注入预算，字（原写死 600） */
    residentMax: 600,
    /** 每 N 轮那次全量重注的预算，字（原写死 1200） */
    deepMax: 1200,
    /** 易变段（拼在用户消息里、每轮都发）预算，字（原写死 480） */
    dynMax: 480,
  },
  /**
   * 备份（4.3 定时 + 4.4 云备份）。
   * schedule：每天到点自动导一份 zip 到本地 backups/（按最近一份完整备份
   * 的落盘时间判断今天跑没跑过，重启不丢状态）；keep 留最近几份，超了删最旧。
   * remote：先 AES-256-GCM 加密再推——passphrase 没配就拒推，不推明文；
   * Gitee 推前硬校验 private===true（公开仓等于全量泄露）。
   * maxBytes 是推送体积上限（不是本地导出上限），默认 200MB。
   */
  backup: {
    schedule: { enabled: false, hour: 4, keep: 7 },
    remote: {
      kind: '',
      gitee: { owner: '', repo: '', token: '', branch: 'master' },
      webdav: { url: '', user: '', pass: '' },
      passphrase: '',
      maxBytes: 209_715_200,
    },
  },
  /** 人物小档案（D7）：数据落在 profiles.json，清除入口独立，不挂会话级清空 */
  profiles: {
    enabled: false,
  },
  /** 经历层（D8）：数据落在 events.json，随 memory.clear 清 */
  events: {
    enabled: false,
  },
  /**
   * 出站防复读（leak-guard 低配版，默认关）。
   * 开着时她回复里整段复述了注入的记忆块/档案，出站前删掉那几句。
   */
  leakGuard: {
    enabled: false,
  },
  /**
   * 对外联动（实验，默认关）：别的 DSH 插件 `ctx.get('aurabot')` 拿她。
   * 只给主动发送 + 只读状态；**接口可能变**，面板标「实验」。
   */
  bridge: {
    enabled: false,
  },
  /** 用户扩展总闸（F）：一期 HTTP/独立进程，默认关；目录 extensions/ 不受升级覆盖 */
  extensions: {
    enabled: false,
    /**
     * 市场数据源：`github` / `gitee` / `custom`。
     *
     * 默认 `github`（官方源）。国内访问 `raw.githubusercontent.com` 与
     * `codeload.github.com` 经常被重置，面板会报「连接被重置」——那台机器
     * 换成 `gitee` 就能用（同一份仓库的镜像，索引字节数实测完全一致）。
     * `custom` 给自建镜像 / 内网源用，地址填在 `indexUrl`。
     */
    marketSource: 'github',
    /**
     * `custom` 时用的索引地址；预设源忽略这一项。
     *
     * 要 https（或本机回环 http）。**内网 http 镜像**（`http://192.168.x.x/…`）
     * 需要先在「安全 → 网络访问」里打开 `security.ssrf.allowPrivate`——
     * 放行之后运行期仍由 SSRF 防护逐 IP 校验，不是把防护整个关掉。
     */
    indexUrl: '',
    /**
     * 覆盖 / 删除「用户手写」扩展目录前的整目录备份，保留几天（默认 7）。
     *
     * 备份落在 `data/backups/ext-<id>-<YYYYMMDD>-<HHMMSS>/`，是误点覆盖之后
     * 唯一的退路，所以**不能无限堆**：手写目录里常有 `node_modules`，一次备份
     * 就是几十上百 MB，攒几个月能把盘吃干净。每次新备份顺手清掉过期的，
     * 而且**只清这个命名格式的目录**——用户自己往 `backups/` 里放的东西不碰。
     *
     * 0 或负数 = 永久保留（要长期留证的人用这个）。
     */
    backupKeepDays: 7,
  },
  /**
   * 对话收尾：**她也会把话说完，然后退场**。
   *
   * 只做私聊——群里没有「聊完」这回事，一直有人说话。
   * 收尾**不发消息、不动记忆**，只记「收在哪 / 下次怎么接」，给两处用：
   * 下一轮提示词（接得上）、主动搭话的刹车（刚说完晚安别又冒出来）。
   */
  closing: {
    enabled: true,
    /** 收尾记录多久后失效。太旧的「上次聊到」接上去反而怪 */
    ttlDays: 7,
    /** 收尾后多久内不「随性搭话」（分钟）。只拦随性，不拦约定 */
    coolMinutes: 90,
    /** 最多留几个会话的收尾记录，防止文件无限长 */
    maxChats: 200,
  },
  /**
   * QQ 动作工具（`qq_send` / `qq_close`）：把「发言」交给模型自己调。
   *
   * 关掉就退回老行为——模型输出一整段，宿主原样 postReply。
   * 开着的话模型可以决定分几段说、说完要不要退场，也可以一句都不说。
   */
  qqTools: {
    enabled: true,
    /** 单轮最多几段。QQ 被动回复同一条消息只让回 5 次（msg_seq 1–5），留余量 */
    maxParts: 3,
  },
  /**
   * 她自己改资料：昵称 / 简介 / 头像 / 菜单（面板「人设 → 资料」页）。
   *
   * ## 为什么没有「限额」
   *
   * 网上流传的「官方机器人资料每月只能改 5 次」出自 2023 年版 `tencent-connect/bot-docs`
   * 的 README，同一份文件还写着「个人开发者不能开群」——早已不成立。现行
   * `bot.qq.com/wiki` 没有这一节，实改也没碰到限制。所以**真实上限未知**，
   * 这里不编数字：`cooldownMin: 0` = 完全不检查时间，要限自己填。
   *
   * ## 两个键各管什么
   *
   *   · `enabled`     —— 工具**注册不注册**。关掉之后它不在 schema 里，
   *                      模型不可能去调（不是「注册了再拒绝」，那样模型会以为能用）。
   *   · `cooldownMin` —— 两次写之间的最小间隔，对谁调的都一样。0 = 不限。
   *
   * ## 为什么开关放在 config 而不是能力页
   *
   * 能力页管的是「哪一档人能调」，这里管的是「她能不能自己动」。两件事。
   * 而且这几项要跟人设放一起看（她叫什么、能不能换名字），所以归「人设」组。
   *
   * `awareness` 只读上下文，不触发任何动作：让她知道现在什么心情、多久没人说话。
   * `proactive` 是允许她在主动搭话那一轮顺手改，默认关——那是「未经请求的自动化」，
   * 不是限额问题。
   */
  selfExpression: {
    menu: { enabled: true, cooldownMin: 0 },
    /**
     * `confirm` = 改之前先私聊主人问一句，主人回「确认」才执行。
     * `unattended` = 没人看着的轮次（主动搭话 / 夜间巩固）允不允许改。
     * **两个键都必须写在这里**：`pruneTo` 只保留 `DEFAULTS` 里有的键，漏了的话
     * 面板上打开、存盘时会被静默裁掉（配置回读还是旧值）。
     *
     * `unattended` 的初始值按「敏感度」给：简介允许、昵称头像不允许；
     * 面板上三项都能单独改，用户自己定。
     */
    /** 简介（OneBot 的 longNick） */
    sign: { enabled: true, cooldownMin: 0, confirm: false, unattended: true },
    /** 昵称；改了要连人格卡的 `selfName` 一起改，否则会出现资料卡和自称对不上 */
    name: { enabled: true, cooldownMin: 0, confirm: false, unattended: false },
    /**
     * 头像。`anyPath` = 本机图片路径能不能超出数据目录。
     *
     * 默认 `true`：老用户就是拿桌面/相册里的一张图当头像的，升级不该收掉。
     * 关掉之后 `qq_avatar` 的 `path` 分支只认数据目录内的文件——这一条挡的
     * 不是主人手滑，是「提示词注入成功一次就把本机任意图传成公开头像」。
     * 同样是**键必须写在这里**，否则 `pruneTo` 会把面板打开的值裁掉。
     */
    avatar: { enabled: true, cooldownMin: 0, confirm: false, unattended: false, anyPath: true },
    awareness: { mood: true, silence: true },
    proactive: { enabled: false, fields: ['menu'] },
  },
  /**
   * 发文件（`qq_send_file`）。
   *
   * **默认不限制路径**：这台机器只有主人能调工具（`permissions.owner = 'all'`，
   * 其余档位是 `chat`，工具在轮开始前就被收走），所以"能发哪些文件"本来就
   * 等价于"主人想让发哪些文件"。再套一层白名单只会挡住他自己的正当操作。
   *
   * `restrictPaths` 留给需要收紧的场景（比如把机器人借给别人用）：
   * 打开后只允许 `<数据目录>/workspace`、`<数据目录>/images` 和 `extraRoots`。
   */
  sendFile: {
    /** true = 只允许白名单目录；false（默认）= 全盘可发 */
    restrictPaths: false,
    /**
     * 额外允许的根目录（绝对路径）。
     *
     * 只在 `restrictPaths` 为 true 时有意义——默认配置下填了也不看。
     * 典型用途：模型把文件生成在某个固定的项目目录里。
     */
    extraRoots: [],
  },
  /**
   * 次数配额：**防刷屏、防烧钱，不是安全边界**。
   *
   * 这里只存**覆盖值**，默认表在 `src/quota.js` 的 `QUOTA_DEFAULTS`。
   * 不在这里抄一份完整默认表，是因为抄了必然会漂：改了代码里的默认值，
   * 老部署的文件里还躺着旧数字（`compact.enabled` 那次就是这么出问题的）。
   *
   * 例：`{ voice: { max: 5 }, file: { max: 0 } }`（后者等于禁掉发文件）
   */
  quota: {},
  /**
   * 觉醒（第 5 期）：**只唤醒，做不做她自己定**。
   *
   * 以前 `speakUp` 是"到点就发一句"，现在是"到点问她一句，她可以说不"。
   * 总开关仍是 `speakUp.enabled`；这里管的是"怎么判断值不值得说"。
   */
  awake: {
    enabled: true,
    /** 清醒时段（小时）。半夜叫醒人是最糟的一种主动 */
    awakeFrom: 8,
    awakeTo: 23,
    /** 多久没聊才算「想你」 */
    missAfterHours: 6,
    /** 机会分低于这个值，连模型都不问 */
    minScore: 0.35,
    /** 「随性」每天最多几次。最尴尬的一类，必须限量 */
    casualPerDay: 1,
    /**
     * 群聊主动白名单：`[{ chatId, name, enabled }]`。
     * **默认空 = 群主动全关**。群里主动极易被踢，必须手动一个个开。
     */
    groups: [],
    /** 每个群每天最多几次 */
    maxPerGroupPerDay: 3,
    /** 群里冷场多少分钟才考虑插话 */
    groupQuietMinutes: 45,
  },
  /**
   * 上下文压缩（第 6 期）：到阈值就开新会话 + 摘要开场，旧会话保留。
   * 不用 `session/fork`（它是复制前缀，方向相反，见 compact.js 文件头）。
   */
  compact: {
    enabled: true,
    /**
     * 群聊到多少占用就压。
     *
     * 60% 是早期折中值，后来证明偏低：每换一次会话 prompt 缓存整段失效，
     * 对照 `qq-dsh-bridge` 实测（阈值 15% → 95%，单步 45–55 秒 → 3–4 秒），
     * 压得越勤越慢。抬到 85%，留 15% 余量容纳一次长回复的突增。
     */
    atPercentGroup: 85,
    /** 私聊单轮更小，75% 已经够早；别学编码 agent 撑到 90% */
    atPercentC2C: 75,
    /** 新会话开场带几条最近原话（用户多留、她自己少留） */
    keepRecentUser: 8,
    keepRecentBot: 3,
    /** 读不到用量时的兜底：聊到这么多轮就压 */
    maxTurns: 40,
  },
  /** 通道：只保留框架外接协议直连。以后接别的平台时再往这里加 */
  channel: {
    current: 'roost',
  },
  /**
   * roost 外接协议（`roost-host/1`）—— 直连框架，不经过任何中间层。
   *
   * 默认关着，由「首次接入向导」或接入页的「一键直连」打开并写好 url / token。
   * 通道恒为 `roost`，没有第二个开关要拨。
   *
   * 只在向导完成（真跑过一次直连自测）之后才算接好；没配对就开着，
   * 会出现「面板显示已开启、事件一条都进不来」的半通状态，最难查。
   *
   * `url` 形如 `http://127.0.0.1:6801`，端口在 roost 面板「外接」页里看
   * （`6800 + sha1(botId)%100`，每只鸟不一样）。
   */
  roostHost: {
    enabled: false,
    url: '',
    /** 外接页里配的那个 token；两边必须一致，否则 401 */
    token: '',
    /**
     * 事件通道用哪条。**RPC 永远走 HTTP（`POST /rpc`）**，这里只选事件流。
     *
     * 协议两条事件通道能力完全一样（同一套方法表、同一条事件流、同一个 seq
     * 补拉语义），所以选哪条都不影响功能：
     *   · `auto` —— 装了可选依赖 `ws` 就用 WS，没装就用 SSE（默认）
     *   · `sse`  —— 只用 HTTP + SSE，零依赖
     *   · `ws`   —— 只用 WS；对面没开 `/ws` 就报错，不回退
     *
     * 为什么默认 `auto` 而不是固定 SSE：装了 ws 的机器能拿到更低的延迟和
     * 双向能力；没装的照旧零依赖。`auto` 下 WS 一旦连不上（对面版本老、
     * 没装 ws、被反代挡），本进程内会记住并改用 SSE，不会每次重连都撞一遍。
     */
    transport: 'auto',
    /**
     * 启动 DSH（插件加载）时要不要顺手把 Roost 拉起来。
     *
     * 默认关：Roost 是个独立进程，有些人是手动管它的（或者跑在另一台机器上），
     * 不该由插件擅自拉起。打开后只在「配置了直连 + 当前没在跑」时才启动。
     */
    autoStart: false,
    /**
     * 这一轮要不要下载图片给模型看（注意：关掉之后模型只能看到「发来一张图」）。
     *
     * 三态：
     *   `true`   总是发（老行为，默认）
     *   `false`  不发，只给一行文字提示
     *   `'auto'` 问 DSH 这个模型能不能看图：**明确说看不了**才不发；
     *            DSH 没声明（`inputModalities` 缺省）就照发——把「未知」当
     *            「不支持」会把图白白丢掉，比降级更糟。
     */
    vision: true,
    /**
     * 一次最多看几张图。旧 ai-chat 面板的 `maxImages`，直连后一度写死成 4，
     * 这里恢复成可配（0 = 不看图；上限 8，防止一张图几百 token 撑爆上下文）。
     */
    maxImages: 4,
    /**
     * 回复走 Markdown 消息类型。旧 ai-chat 面板的 `markdown` 开关。
     * 关掉后加粗列表不渲染、`<qqbot-at-user>` 真 @ 也会退化成纯文字。
     */
    markdown: true,
    /** 合并窗口：连着发的几句攒成一段再回。私聊 / 被 @ / 命令不受它影响 */
    merge: {
      waitSec: 1.5,
      maxSec: 6,
    },
    /**
     * 接话策略。
     *
     * **以前这些全在 ai-chat 插件里**（`decide.js`），直连之后框架会把每条
     * 群消息都推过来，没有这一层就等于群里每句话都触发一轮模型调用。
     *
     * 只对**群里没被 @ 的消息**生效：私聊、被 @、命令永远直接接。
     *
     *   mode: ai       —— 每条都看（默认）
     *         mention  —— 只在被 @ 时回
     *         window   —— @ 之后 windowMin 分钟内继续接
     *         engaged  —— 在 ai 基础上，刚说过话的 3 分钟内算「在聊」接着聊
     *
     * 其余是刹车：冷却（冷却期内的消息攒着不丢）、每分钟/每小时条数、
     * 静默时段、两分钟突发上限、短问必答。数值 0 / 起止相同 = 关闭。
     */
    decide: {
      mode: 'ai',
      /** 连聊最多接几次（旧 ai-chat `policyEngagedMaxTurns` 默认 6）。直连后曾在代码里硬编码成 3 */
      engagedMaxTurns: 6,
      windowMin: 3,
      cooldownSec: 20,
      maxRepliesPerMin: 3,
      maxPerHour: 0,
      burstMax: 0,
      quietStartHour: 0,
      quietEndHour: 0,
      /**
       * 对外静默窗口（`HH:mm`，跨夜，留空 = 不启用）：这段内**只有主人叫得醒她**，
       * 别人的 @ / 引用 / 唤醒词 / 追问都不起轮次。
       *
       * 与上面那对 `quietStart/EndHour` **正交**，别合并：那对管「她别插话」
       * （对主人），这对管「别人别叫醒她」。合成一个键之后，最常见的
       * 「深夜别插嘴、但我喊她要在」就表达不出来了。
       */
      guestQuietFrom: '',
      guestQuietTo: '',
      shortAskMustReply: false,
      silent: false,
      /** 这些词开头的不接：别的插件靠它们干活，别抢 */
      ignoreWords: ['/'],
    },
  },
  /**
   * 群聊策略的补充层（2.2b）。
   *
   * **为什么不把静默时段 / 每小时上限再抄一份进来**：`roostHost.decide`
   * 里早就有 `quietStartHour` / `quietEndHour` / `maxPerHour`，2.2a 也已经
   * 在群聊页露出来了。同名参数放两处就是「两份真相」——用户改了上面那份、
   * 下面这份没动，判据该听谁的永远说不清（tts.speed 那次就是这么踩的坑）。
   * 所以这里**只放 decide 里真的没有的东西**：
   *
   *   · `interruptChance` —— 插话概率，真·新判据；
   *   · `briefMaxItems`   —— 主人私聊问「某群刚聊了什么」时回几条（C5-1）；
   *   · `overrides`       —— **按群覆写**，这才是 2.2b 新给的能力：
   *                          静默时段、每小时上限、冷却、接话方式、插话概率
   *                          都能给单个群单独设，全局值仍留在 decide（2.2a）。
   *
   * `overrides` 用**空对象当开放字典**（键是群 openid，形状不可知），
   * `pruneTo` 见到空 shape 会整份保留；写成 `{ sample: … }` 反而会被裁掉。
   * 形状：`{ "<群openid>": { mode?, cooldownSec?, maxPerHour?, …,
   * interruptChance? } }`，只有白名单里的键生效（见 roost-decide.js）。
   *
   * **默认值必须等于升级前的行为**：`interruptChance = 100` = 句句都接，
   * `overrides = {}` = 没有例外。老配置没这个段，读出来也是这两个值，
   * 升级前后她接话的频率一模一样。
   */
  group: {
    /** 群里没人明确叫她时，有多大概率接这句（0–100）。100 = 全接（原行为） */
    interruptChance: 100,
    /** 主人私聊问群聊摘要时，最多回几条时间线；上限 50（和 chat_look 一致） */
    briefMaxItems: 20,
    /** 按群覆写：{ [chatId]: { … } }。空 = 所有群都用同一套全局设置 */
    overrides: {},
  },
  /**
   * 频道（`guild` 文字子频道 / `dm` 频道私信）。
   *
   * 总开关**默认关**。关着时 dsh-roost 在入口丢弃频道事件，
   * **不动框架的 intents 订阅**——框架照常收、照常推给别的订阅者，
   * 这边只是不处理（协议层没有动态退订，这是唯一可行做法）。
   *
   * 注意：新键必须写在这里。`saveConfig()` 用 `pruneTo(DEFAULTS)` 裁剪，
   * DEFAULTS 之外的键会被静默丢掉——面板读不到、存了也不落盘。
   */
  guild: {
    /** 总开关：默认关。开之前先确认框架侧已订阅频道事件（见「频道总览」） */
    enabled: false,
    /**
     * 会话粒度：
     * · `guild`（默认）—— 一个频道一个会话，同频道的子频道/论坛/公告共用；
     * · `channel` —— 一个子频道一个会话，各版块互不串。
     * 频道私信固定**一人一个**，不受这里影响。
     */
    sessionMode: 'guild',
    /** 面板勾选的订阅位预设：basic = 只开官方默认有权限的三位 */
    intentsPreset: 'basic',
    /** 按频道覆写：{ [sessionKey]: { … } }，键用 `guild:<guildId>` */
    overrides: {},
  },
  /**
   * 频道发帖：让她在频道的一个论坛版块里，每天写几篇留着的小记。
   *
   * **默认值必须在这里列全**：`pruneTo()` 按 DEFAULTS 的键裁剪，没列的键会被
   * 静默丢掉（`persona.bySender` 那次就栽在这上面）。所以直接展开模块里的
   * `POST_DEFAULTS`，保证"默认值"只有一份定义。
   */
  channelPost: { ...POST_DEFAULTS },
  /**
   * 主人的**其他渠道 id**。
   *
   * 同一个人在不同渠道是不同 id：群/私聊是 `member_openid`，频道是 `author.id`
   * （频道成员 id，另一套标识空间）。框架的 `owners` 只认一种，于是主人在频道里
   * 被算成普通成员——2026-11-17 实机：她在频道私信里反问「资料卡上就写着天道酬勤」。
   *
   * 这里存的 id 命中 `payload.sender.id` 就按主人算（见 host 的入站提升）。
   * 只影响 dsh-roost 自己的判档，不动框架 owners。
   */
  ownerAliases: [],
  /**
   * 手填的机器人 AppID。
   *
   * 正常情况下从框架 `system.hello` 读；但外接协议断开、或框架配置里没有
   * appId 时读不到。而「加机器人」那条链接只要 appid 就能拼，没有理由
   * 因为读不到就让人干看着。填一次就存这儿，优先于协议查询。
   */
  shareAppid: '',
  /**
   * 主动搭话：主人一阵子没找你，你主动在私聊里说句话。
   * **只在私聊，不在群里**；默认关着。
   */
  speakUp: {
    enabled: false,
    /** 主人私聊的 openid，空 = 不工作 */
    chatId: '',
    awakeFrom: 8,
    awakeTo: 23,
    minIntervalMinutes: 180,
    maxIntervalMinutes: 480,
    maxPerDay: 3,
    prompt: '',
  },
  /**
   * 4.6 互动召回 `is_wakeup`：单聊。官方口径是「用户主动对话后 30 天内，
   * 当天 / 1–3 天 / 3–7 天 / 7–30 天四个窗口各 1 条」——窗口不等长，
   * 且是相对最后一次互动算的，超 30 天没有额度（见 src/wakeup.js）。
   * 和主动搭话是**两本账**（那边按天，这边按窗口）。
   * 默认关：没让机器人主动找人之前，不该凭空多一条消息。
   */
  /**
   * 扩展主动消息通道（0.4）。扩展只投递素材，措辞、门闸、额度、审批全在宿主。
   * `enabled` 默认开：装扩展时主人已确认过 `proactive:write` 这个敏感 scope，
   * 再让他在宿主面板开第二道总开关，只会造成「明明装了却什么都不发」。
   * 真正决定发不发的是**扩展侧每一项功能的开关**（见 B 站扩展 0.4）。
   */
  extProactive: {
    enabled: true,
    /** 通道自己的每日额度；和 speakUp 的今日开口账是两本，别混 */
    maxPerDay: 50,
    /** 群分享要不要先问主人「发不发」；开了就攒待批，回「发 1」才发 */
    approval: false,
    /** 允许素材发群（仍要 group_push 授权） */
    allowGroup: true,
  },
  wakeup: {
    enabled: false,
    /** 多久没互动才算「久不说话」。默认 72h，实际只命中后两个窗口；调小可覆盖前两个 */
    idleHours: 72,
    /** 官方硬上限，写在这里是为了让面板能显示，代码里不接受放宽 */
    windowDays: 30,
    awakeFrom: 9,
    awakeTo: 22,
  },
  /**
   * 自驱引擎（实验，**默认全关**）。
   *
   * 这是唯一「没人叫她、她自己决定要做事」的模块。和「授权分级」铁律的冲突点
   * 很具体：无人值守时的工具调用，出事没有人在场喊停。所以四个开关全是关的：
   * `enabled` 关 → 一行代码都不跑；`allowAct` 关 → 只让她想、不让她动手；
   * `heartbeatMin` 为 0 → 不自动心跳，只能从面板手动点；
   * `seeds` 空 → 没东西可琢磨。
   *
   * 详见 `src/autotelic.js` 与 `src/autotelic-ledger.js`（哈希链账本）。
   */
  autotelic: {
    enabled: false,
    allowAct: false,
    /** 一天最多推进几次（立项不算次数） */
    maxPerDay: 2,
    /** 连续失败几次自动卡住 */
    failLimit: 2,
    /** 卡住多久（小时） */
    stuckHours: 12,
    /** 心跳间隔（分钟）。0 = 不自动跑 */
    heartbeatMin: 0,
    quietStartHour: 0,
    quietEndHour: 0,
    maxOutputChars: 1200,
    /** 她想琢磨的方向。空数组 = 不立项 */
    seeds: [],
  },
  /**
   * 表情包库：往目录里丢图就行，文件名当标签（`开心_猫.png` → 开心、猫）。
   * 插件把清单写进提示词，模型在正文里写 `<<image: 完整路径>>` 发图
   * （图文同条，按位置排版）；写 `<<image-alone: 路径>>` 则是「单独发一条图」。
   */
  stickers: {
    enabled: true,
    /**
     * 表情包目录。留空 = `<数据目录>/stickers`（只有这个默认目录会被自动创建）。
     *
     * 也可以写数组，把几个目录合并成一个库：
     *     "dir": ["D:\\表情包", "E:\\旧图备份"]
     * 同名分类相加计数，「未分类」也相加。
     *
     * 用户填的路径**不会**被自动创建——填错盘符时不该在他盘上凭空造目录。
     * 面板「设置 → 表情包」可以直接增删，会按数量自动写回字符串或数组。
     */
    dir: '',
    /**
     * 缓存图同步：把 `<数据目录>/images/` 里「像表情包」的图搬成未分类。
     *
     * 不做内容识别——群成员档位没有 `read_image`，模型看不见他们发的图。
     * 判断标准只有尺寸：边长、长宽比、体积。实测能切掉截图和壁纸。
     * 面板「表情包 → 同步缓存图」里可改，改完即时生效。
     */
    sync: {
      /** 长边上限，超过基本是截图/壁纸 */
      maxEdge: 1024,
      /** 长宽比上限，截图和长条图都远大于它 */
      maxRatio: 1.8,
      minBytes: 5120,
      maxBytes: 1048576,
    },
  },
  /**
   * 按聊天选模型（E6）。
   *
   * `byChat[chatId] = { provider, model, reasoningEffort? }`；没配就沿用 DSH
   * 的全局默认模型。chatId 是 QQ 的 openid，私聊和群都适用（各自唯一，
   * 不用再按 kind 分一层）。空对象当开放字典，`pruneTo` 会整份保留。
   */
  model: {
    byChat: {},
    /**
     * 按会话类型默认（E6 补全）：`c2c` / `group` 各一份。
     * 优先级：`byChat[chatId]` > `byKind[kind]` > `default` > DSH 全局默认。
     * 给「所有私聊统一用 A 模型、所有群统一用 B 模型」用。
     */
    byKind: { c2c: {}, group: {} },
    /**
     * 5.4：没单独配时按会话类型给推荐强度（私聊 high / 群聊 low）。
     * 显式设了 `byChat` / `byKind` / `effort` 的都优先；关掉就完全回落原行为。
     */
    effortByKind: true,
    /**
     * 所有聊天的默认模型（面板「聊天用的模型」那张卡）。
     *
     * 单独一层而不是直接写 byKind 的两个键：写 byKind 会让人以为
     * 「私聊/群聊分别配过」，而这里表达的是「我用这一个，别的都别管」。
     * 空对象 = 跟随 DSH 的全局默认。
     */
    default: {},
    /**
     * 全局思考强度（`low` / `high` / `max`，空 = 不传、让模型用自己的默认档）。
     *
     * 只在某一级**没有**显式写 `reasoningEffort` 时兜底。真正下传之前还会经
     * `pickReasoningEffort` 问一次宿主认不认这一档——很多模型没有推理元数据，
     * 硬塞会在 provider I/O 之前整轮失败。
     */
    effort: '',
  },
  persona: {
    /** 当前用哪个人格（对应 personas/<id>.md） */
    current: 'default',
    /** 按会话指定：{ "群openid": "personaId" }，留空就用 current */
    byChat: {},
    /**
     * 按**人**指定：{ "发送者openid": "personaId" }。
     *
     * 优先级高于 byChat：同一个人在群里和私聊里都用他专属那一套。
     * 为什么单独一层而不是往 byChat 里塞 "u:" 前缀：两类键会混在一起，
     * 删人格时的 clearRefs 之类的遍历要不停地区分前缀，迟早出错。
     * **必须写在这里**，否则 pruneTo() 会把整层静默裁掉。
     */
    bySender: {},
    scope: {
      /**
       * 4.5 人格隔离总开关，默认关（升级前后行为逐字一致）。
       * 归属策略**不放在这里**：它由使用者在「人格」页显式选
       * （A 共享 / B 归某个人格 / C 逐会话指定），单独存在
       * persona-ownership.json。没选策略就不许开，见 persona-scope.js。
       */
      enabled: false,
    },
    /**
     * **她的名字，全局唯一。**
     *
     * 0.11 起名字是「账号身份」而不是「人格属性」：换人格只换说话方式，
     * 名字不变（和 QQ-agent 的 botName 同款）。人格文件里的 `name` 已废弃，
     * 只当面板标签用（`label`）。
     *
     * 默认给「大肥鱼」——新装用户直接用这个；老用户由迁移读一次原人格名。
     */
    name: '大肥鱼',
    /**
     * 聊天内切人格指令（抄 AstrBot 的 /persona）：默认关、只对主人生效、
     * **不落盘**（进程重启失效），只影响当前会话。
     * 支持 `前缀`（列表）、`前缀 off`（回全局）、`前缀 <名字>`（切换，名字可带空格）。
     */
    command: { enabled: false, prefix: '/persona' },
    text: '',
    rulesPrivate: '这是和主人的私聊，可以放开聊。',
    rulesSocial: '这是群聊，说话要短，别刷屏。',
    /**
     * 近处指令（SillyTavern `post_history_instructions` 的近似）。
     *
     * DSH 没有「插到对话历史之后」的入口，我们只能把 order 排到最后，
     * 至少在 system 块里离历史最近。留空就用内置那一句。
     */
    near: '',
    /**
     * 人格仓库（「从仓库更新」按钮用的）。
     *
     * 默认源写死在 `persona-repo.js`（GitHub raw → Gitee raw 自动换）。
     * 这里留一个空数组当覆盖口：国内用户想换成自己的镜像或 fork 时填进来，
     * 填了就不再用默认那两个。域名必须在白名单里（只认
     * `raw.githubusercontent.com` / `gitee.com`），否则面板就成了内网探测器。
     */
    repo: {
      /**
       * 例：["https://raw.githubusercontent.com/我/我的fork/main"]
       *
       * **填人格目录的地址**（index.json 就在它下面），不是仓库 URL 本身。
       * 官方仓库的根目录就是人格目录，所以结尾到 `main` 为止；如果你 fork 后
       * 把人格放在子目录里，这里要带上那个子目录名。
       */
      sources: [],
    },
    /**
     * 每轮注入的人格正文字符上限。
     *
     * 角色卡类人格（QQ-Agent 那批）动辄上万字符，全量注入会把上下文吃光、
     * 历史被挤掉。超了按小节优先级裁剪（见 `personas.js` 的 `trimPersonaBody`），
     * 不超则原样注入——内置那 8 份都在 300 字符内，走不到裁剪分支。
     * 设 0 表示不裁剪（回到以前的全量注入）。
     */
    maxChars: 8000,
  },

  /**
   * 本体自更新（设置页最上面那一块）。
   *
   * 默认走 npm 官方源；国内想换镜像填这里。空 = 用 DSH 自己配的 registry。
   * 只更新 dsh-roost 这一个包，不接受任意包名。
   *
   * **同一份值也给「装别人的东西」用**：宿主级共享依赖（ffmpeg / qrcode）的
   * `npm install`、语音引擎的 tgz 直链下载，都读这里。面板里改一处，
   * 三条下载路径一起生效。
   */
  update: {
    registry: '',
    /**
     * 5.8 测试版通道：`latest` = 稳定版，`beta` = 测试版（npm dist-tag）。
     * 切通道只改比较目标，不改安装方式；`beta` 没发布时自动回落 `latest`。
     */
    channel: 'latest',
  },
};

function merge(base, patch) {
  if (!patch || typeof patch !== 'object') return base;
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const [k, v] of Object.entries(patch)) {
    out[k] = v && typeof v === 'object' && !Array.isArray(v) ? merge(base?.[k] ?? {}, v) : v;
  }
  return out;
}

/**
 * 改过默认值的字段：值还等于**旧默认**就升级。
 *
 * 为什么需要这一步：`saveConfig` 写的是整份合并后的配置，所以任何在面板上
 * 点过一下的部署，磁盘上都躺着当时那份默认值——那是我们写进去的，不是用户选的。
 * 只改 `DEFAULTS` 对它们完全无效（实测：改完 compact.js 的 85/75，老部署照旧 60/40）。
 *
 * 只在"值还等于旧默认"时才动：用户真调过的一律不碰。代价是"用户恰好也选了 60"
 * 会被顺带升级——压缩阈值改回来只需在面板上点两下，比"改了默认值却没人拿到"轻。
 */
const UPGRADED = [{ path: ['compact', 'atPercentGroup'], from: 60, to: 85 },
  { path: ['compact', 'atPercentC2C'], from: 40, to: 75 }];

function upgradeOldDefaults(cfg) {
  for (const u of UPGRADED) {
    const [a, b] = u.path;
    if (cfg?.[a]?.[b] === u.from) cfg[a][b] = u.to;
  }
  return cfg;
}

/**
 * 磁盘上的**原始**配置，不合并默认值。
 *
 * 迁移必须用它判断「用户到底设过没有」：`loadConfig()` 会把 `DEFAULTS`
 * 合并进来，于是老用户配置里明明没有 `persona.name`，读出来却是「大肥鱼」——
 * 拿合并结果判断就会误以为用户选过，永远读不到他原来的「小栖」。
 */
export function readRawConfig() {
  try {
    const j = JSON.parse(readFileSync(FILE(), 'utf8'));
    if (!j || typeof j !== 'object' || Array.isArray(j)) return null;
    return j;
  } catch {
    /**
     * 没有文件、或者 JSON 坏了，都返回 null。
     *
     * 两者对迁移的意义一样：**配置不可信，别拿默认值去覆盖它**。
     * 区分开的话，坏配置会被当成「新装」，然后 `patchConfig` 一把写成默认值，
     * 用户那份「坏但还能手工救」的配置就没了。
     */
    return null;
  }
}

/**
 * 配置文件的版本号（mtime）。整份保存前用它做冲突检测：
 * 面板打开后别处又改过配置，直接覆盖会把别人的修改抹掉。
 */
export function configRevision() {
  try {
    // 用内容哈希而不是 mtime：同一毫秒内的两次写，mtime 分不出来
    return createHash('sha256').update(readFileSync(FILE())).digest('hex').slice(0, 16);
  } catch {
    return '';
  }
}

/**
 * 把老的 `tts.sherpa.speed` 迁到 `tts.speed`（语速统一之前只有前者）。
 *
 * 不迁的话，以前调过语速的用户升级后语速悄悄回到原速——面板上完全看不出来，
 * 只会觉得「声音变快了/变慢了」。就地改 `saved`（用户文件的那份），
 * 之后任何一次保存都会把新字段固化下来。
 *
 * 只在 `tts.speed` 还没写过时迁，用户自己设过就以他为准。
 */
/**
 * 移除 ai-chat 后，老配置里 `channel.current === 'qq'` 已经没有对应实现。
 *
 * 不迁移的后果很隐蔽：`active()` 返回 null，主动搭话、发测试消息、模型工具
 * 发消息全都在 `channel.send` 处抛错，而面板看不出「为什么突然一个字都不回」。
 * 归一成 `roost` 之后，至少通道是可用的；但老用户还没有 url / token，
 * 所以向导仍会强制弹出来带他重新接一遍——迁移只保证「不崩」，不假装「已配好」。
 */
export function migrateChannel(saved) {
  if (saved?.channel && String(saved.channel.current || '') === 'qq') {
    saved.channel.current = 'roost';
  }
  return saved;
}

export function migrateTtsSpeed(saved) {
  const tts = saved?.tts;
  if (!tts || typeof tts !== 'object') return false;
  if (tts.speed !== undefined) return false;
  const legacy = Number(tts.sherpa?.speed);
  if (!Number.isFinite(legacy) || legacy <= 0) return false;
  tts.speed = legacy;
  return true;
}

/**
 * 阶段 2 的 D11 只有单个 `memory.retention.mode`（当时开关是 staged，面板改不了，
 * 只有手改过 config.json 的人会有），阶段 4c 拆成两路。
 *
 * 老值只带到 **facts 路**：journal 一路一律保持默认关。不能因为一次升级就把
 * 日记检索也打开——那是「改配置却悄悄改了她记得什么」。
 * 和 tts 迁移一样就地改 `saved`，之后任何一次保存会把新字段固化下来。
 */
export function migrateRetentionMode(saved) {
  const r = saved?.memory?.retention;
  if (!r || typeof r !== 'object' || r.mode === undefined) return false;
  const legacy = String(r.mode);
  if (r.factsMode === undefined) {
    r.factsMode = ['off', 'expire', 'purge'].includes(legacy) ? legacy : 'off';
  }
  if (r.journalMode === undefined) r.journalMode = 'off';
  delete r.mode;
  return true;
}

/**
 * 同步等一小会儿（只有出错才走这里，正常路径零开销）。
 *
 * 用 `Atomics.wait` 而不是 `execSync('sleep')`：不建子进程、不会被沙箱拦。
 */
function sleepSync(ms) {
  try {
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
  } catch { /* 环境不支持就当场不睡，最多多试两次 */ }
}

export function loadConfig() {
  /**
   * 读配置要重试。
   *
   * Windows 上杀毒 / 备份 / 同步盘会在文件被短暂占用时抛 `EBUSY` / `EPERM`，
   * 断电或进程被杀会留下 0 字节或写了一半的文件——这几种几十毫秒内就自愈。
   * 而「一次失败就回落默认值」的后果是**灾难性的**：这里返回全默认，上层
   * `patchConfig` 一写盘就固化了，用户只是重启了一次，配置却永久变默认。
   *
   * 三次都读不出来时**先把坏文件挪走再回落**：留着那份「坏但还能手工救」的
   * 内容，比直接覆盖掉强。新装（ENOENT）是正常情况，不重试、也不备份。
   */
  let saved = {};
  for (let i = 0; i < 3; i++) {
    try {
      const text = readFileSync(FILE(), 'utf8');
      if (!text.trim()) throw Object.assign(new Error('配置文件是空的'), { code: 'EMPTYFILE' });
      saved = JSON.parse(text);
      break;
    } catch (e) {
      if (e?.code === 'ENOENT') break;
      if (i === 2) {
        try {
          const bak = `${FILE()}.bad-${Date.now()}`;
          renameSync(FILE(), bak);
          console.warn(`[roost] 配置读不出来（${e?.code || e?.message}），已备份到 ${bak}，本次按默认值启动`);
        } catch { /* 备份也失败就认了，至少别把启动卡死 */ }
        saved = {};
      } else {
        sleepSync(30);
      }
    }
  }
  migrateTtsSpeed(saved);
  migrateRetentionMode(saved);
  migrateChannel(saved);
  return upgradeOldDefaults(merge(structuredClone(DEFAULTS), saved));
}

/**
 * 按 DEFAULTS 的形状裁剪：DEFAULTS 里没有的键一律丢掉。
 *
 * 为什么需要：`merge` 只对**对象值**递归合并，key 本身照样写进去——所以
 * `merge(DEFAULTS, { tokenSet: true })` 反而会把 `tokenSet` 加上。展示字段
 * 和用户手写的错键都得靠这一步挡掉。
 *
 * 两条特殊规则：
 *   · **空对象当开放字典**（`persona.byChat` 的键是群 openid，形状不可知）→ 整份保留
 *   · **数组整体保留**（元素类型不可知，只校验它确实是数组）
 */
function pruneTo(shape, value) {
  if (Array.isArray(shape)) return Array.isArray(value) ? value : structuredClone(shape);
  if (shape && typeof shape === 'object') {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return structuredClone(shape);
    const keys = Object.keys(shape);
    if (keys.length === 0) return value;
    const out = {};
    for (const k of keys) out[k] = pruneTo(shape[k], value[k]);
    return out;
  }
  return value === undefined ? shape : value;
}

const SECRET_MASK = '******';
const SECRET_PATHS = [
  ['server', 'token'],
  ['roostHost', 'token'],
  ['memory', 'embedding', 'apiKey'],
  ['tts', 'apiKey'],
  ['tts', 'gptSovits', 'apiKey'],
  ['tts', 'mimo', 'apiKey'],
];

function valueAt(root, path) {
  return path.reduce((value, key) => value && typeof value === 'object' ? value[key] : undefined, root);
}

/**
 * E7：把配置里已知的密钥交给日志脱敏器（`redact.js` 的 `setSecretProvider`）。
 * 和上面的 `SECRET_PATHS` **共用一份名单**，别在别处再抄一遍路径；
 * 掩码值（`******`）和空串不算密钥。
 */
export function collectSecrets(cfg) {
  const out = [];
  for (const p of SECRET_PATHS) {
    const v = valueAt(cfg || {}, p);
    if (typeof v === 'string' && v && v !== SECRET_MASK) out.push(v);
  }
  return out;
}

function putAt(root, path, value) {
  let node = root;
  for (const key of path.slice(0, -1)) {
    if (!node[key] || typeof node[key] !== 'object' || Array.isArray(node[key])) node[key] = {};
    node = node[key];
  }
  node[path.at(-1)] = value;
}

/**
 * Masked values in a config-editor submission mean "keep existing", not a new secret.
 *
 * 导出是为了给**非保存**的提交路径复用：`/tts/preview` 收到的是面板草稿
 * （密钥已按 `publicConfig()` 打成 `******`），不还原就会把掩码当真实 Key
 * 发给上游，面板上显示「鉴权失败」—— 用户只会以为 Key 被弄丢了。
 */
export function restoreMaskedSecrets(next, stored) {
  const out = structuredClone(next && typeof next === 'object' ? next : {});
  for (const path of SECRET_PATHS) {
    if (valueAt(out, path) !== SECRET_MASK) continue;
    const previous = valueAt(stored, path);
    putAt(out, path, typeof previous === 'string' ? previous : '');
  }
  return out;
}

/**
 * 密钥路径上只允许字符串。
 *
 * 上面那个回填只认**恰好等于 `******` 的字符串**——如果配置编辑器提交的是
 * `{"apiKey": ["******"]}`（数组、对象），它既不会被回填、也不会被拦，
 * 会原样写进磁盘，之后每次读配置都拿到一个非字符串的"密钥"，
 * 发请求时拼出 `Bearer ******,******` 这种鬼东西（2026-11-03 审查发现）。
 * 这里统一拍平：非字符串一律当"没设置"。
 */
function coerceSecrets(cfg) {
  for (const path of SECRET_PATHS) {
    const v = valueAt(cfg, path);
    if (v !== undefined && typeof v !== 'string') putAt(cfg, path, '');
  }
  return cfg;
}

function maskSecrets(value) {
  const out = structuredClone(value);
  for (const path of SECRET_PATHS) {
    const secret = valueAt(out, path);
    if (typeof secret === 'string' && secret) putAt(out, path, SECRET_MASK);
  }
  return out;
}

export function saveConfig(next) {
  /**
   * 基线用 **DEFAULTS**，不用 `loadConfig()`。
   *
   * 面板的「配置全文」允许直接编辑 JSON，用户删掉一个字段就是想让它没了。
   * 但以前基线是磁盘上的旧配置，而 `merge` 只遍历用户提交的 key —— 删掉的字段
   * 会从旧配置里原样补回来，**删除操作静默失效**（实测：删 `memory.injectCount`
   * 和整个 `workspace` 段，保存后都还在）。
   *
   * 换成 DEFAULTS 做基线后：删掉 = 回落到默认值，既尊重删除动作，又保证结构完整
   * （不会出现 `cfg.xxx` 是 undefined）。
   *
   * 再用 `pruneTo` 裁一遍，把 DEFAULTS 之外的键（展示字段 `tokenSet`、手写错键）
   * 挡在磁盘外面。
   *
   * 前提是 DEFAULTS 覆盖所有合法字段。已核对真实配置：除了 `tokenSet`，
   * 没有任何 DEFAULTS 之外的路径。
   */
  const safeNext = restoreMaskedSecrets(next, readRawConfig() || {});
  const merged = merge(structuredClone(DEFAULTS), safeNext);
  const cfg = coerceSecrets(pruneTo(DEFAULTS, merged));
  writeFileSync(FILE(), JSON.stringify(cfg, null, 2), 'utf8');
  /**
   * 权限收紧：这份文件里有 `roostHost.token`、`server.token`、几个 apiKey。
   *
   * 不收紧的话 Unix 上默认 0644 —— **同机其他用户能直接读到 token**。
   * Windows 上 chmod 基本是 no-op（靠目录 ACL），所以失败一律吞：
   * 「保存成功」比「权限没设上去」重要，不能因为后者把前者搞挂。
   */
  try {
    chmodSync(FILE(), 0o600);
  } catch {
    /* Windows / 只读挂载 / 权限不足：忽略，配置已经写下去了 */
  }
  return cfg;
}

/**
 * 改一个键，其它不动。
 *
 * 为什么必须有它
 * --------------
 * `saveConfig(next)` 的基线是 **DEFAULTS**，而 `merge` 只遍历 `next` 里的键
 * （见上面两处注释）。也就是说：**提交一个局部 patch，其它段全部回落到默认值**。
 *
 * 实测（临时数据目录）：先存 `{server:{token:'REAL', port:4321}}`，
 * 再存 `{memory:{offChats:['g1']}}` → 磁盘上 `token` 变成空串、`port` 变成 17321。
 * 也就是说「静音一个会话」会把 QQ 的 token 和端口一起重置。
 *
 * 所以约定：
 *   · **整份替换**（面板「配置全文」）用 `saveConfig` —— 删字段才会真的删掉；
 *   · **改一个键**（快捷操作、`/personas/use`、关键词配置）用 `patchConfig`。
 *
 * 实现上以**当前磁盘配置**为基线合并，再交给 `saveConfig` 走一遍 DEFAULTS 裁剪，
 * 这样既有「其它段不动」，又保住「结构完整、DEFAULTS 之外的键进不来」。
 */
export function patchConfig(patch) {
  return saveConfig(merge(loadConfig(), patch));
}

/** 给面板看：密钥打码 */
export function publicConfig(cfg) {
  /**
   * 先按 DEFAULTS 裁一遍，再统一遮住所有密钥路径。
   *
   * 不额外加 tokenSet / apiKeySet 字段：空串表示未设置，****** 表示已经设置。
   * `saveConfig` 会把这些掩码回填成磁盘中的原值；显式提交空串仍能清除密钥。
   */
  return maskSecrets(pruneTo(DEFAULTS, cfg));
}
