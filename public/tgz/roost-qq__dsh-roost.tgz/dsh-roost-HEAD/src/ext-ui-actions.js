/**
 * 扩展页面「动作按钮」的投递队列。
 * ============================================================
 *
 * 背景：扩展页面的按钮不能直接把代码塞进面板（那就是 6.1 挡掉的东西），
 * 也不能由宿主替它执行——宿主不认识扩展的业务。所以做成「按钮 → 排队 →
 * 扩展自己来取」：
 *
 *   面板点按钮 → 宿主校验「这个 action 在清单里声明过」→ 入队
 *   扩展轮询 `GET /v1/ext-ui/actions` → 取走并执行 → 下次刷新页面看到结果
 *
 * 为什么是内存队列而不是写文件：
 *   · 动作是「此刻的意图」，宿主重启后补发昨天的「现在刷一轮」没有意义；
 *   · 不落盘就不会有清理问题，也不会污染扩展目录（索引 sha256 按整目录算）。
 *
 * 边界：
 *   · 按 `extId` 隔离，扩展只能取自己的（`extId` 来自令牌，不信请求体）；
 *   · 有 TTL（默认 2 分钟），过期的动作取不出来，避免扩展离线一小时后
 *     一上线把攒着的十几个「刷一轮」全跑一遍；
 *   · 有容量上限，防止某个扩展被反复点击把内存撑大。
 */

import { randomUUID } from 'node:crypto';

export const ACTION_TTL_MS = 120_000;
export const MAX_ACTIONS = 32;
export const MAX_PER_EXT = 8;

export function createUiActionQueue({
  now = () => Date.now(),
  ttlMs = ACTION_TTL_MS,
  max = MAX_ACTIONS,
  maxPerExt = MAX_PER_EXT,
  log = () => {},
} = {}) {
  /** extId -> [{ action, nonce, at }] */
  const store = new Map();
  /**
   * 长轮询的等待者：extId -> Set<唤醒函数>。
   *
   * 扩展是 stdio 子进程，宿主没有它的 stdin 句柄（那条管道属于 DSH 的 MCP
   * 客户端），所以「直接推一条消息过去」在协议上做不到。替代方案是**长轮询**：
   * 扩展发一个请求过来，宿主把它挂住，动作一入队就立刻返回——对用户来说
   * 就是实时的，代价只是一个空闲的本机连接。
   */
  const waiters = new Map();

  const alive = (it, t) => it && t - it.at <= ttlMs;
  const prune = (t) => {
    let removed = 0;
    for (const [extId, list] of store) {
      const next = list.filter((it) => alive(it, t));
      removed += list.length - next.length;
      if (next.length) store.set(extId, next);
      else store.delete(extId);
    }
    return removed;
  };
  const total = () => {
    let n = 0;
    for (const list of store.values()) n += list.length;
    return n;
  };

  /**
   * 入队。`action` 必须是清单里声明过的 id（校验在路由层做，这里只做形状校验，
   * 因为队列不该知道某个扩展声明了什么）。
   */
  function push(extId, action, payload = null) {
    const key = String(extId ?? '').trim();
    const act = String(action ?? '').trim();
    if (!key || !act) return { ok: false, reason: 'bad_request', message: '缺扩展 id 或动作名' };
    /**
     * 动作可以带一小段参数（弹幕表单这类），但必须是很小的普通对象：
     * 队列在宿主内存里，塞大对象等于让面板能占宿主的堆。
     */
    let body = null;
    if (payload !== null && payload !== undefined) {
      if (typeof payload !== 'object' || Array.isArray(payload)) {
        return { ok: false, reason: 'bad_request', message: '动作参数必须是一个对象' };
      }
      let json = '';
      try { json = JSON.stringify(payload); } catch { json = ''; }
      if (!json || json.length > 2000) {
        return { ok: false, reason: 'bad_request', message: '动作参数太大或无法序列化（上限 2000 字符）' };
      }
      body = JSON.parse(json);
    }
    const t = now();
    prune(t);
    if (total() >= max) {
      return { ok: false, reason: 'busy', message: '动作队列满了，等扩展取走再点' };
    }
    const list = store.get(key) || [];
    if (list.length >= maxPerExt) {
      return { ok: false, reason: 'busy', message: '这个扩展还有没处理完的点击，稍等几秒' };
    }
    /** 同一个动作连点只留一条：用户手抖点三下不该刷三轮（带参数的动作不合并） */
    if (!body && list.some((it) => it.action === act)) {
      return { ok: true, deduped: true, pending: list.length, message: '这个动作已经在排队了' };
    }
    const item = { action: act, nonce: randomUUID(), at: t, payload: body };
    store.set(key, [...list, item]);
    /** 有人挂着长轮询就立刻唤醒，别让它等满 25 秒 */
    for (const wake of [...(waiters.get(key) || [])]) {
      try { wake(); } catch { /* 单个等待者出错不影响别人 */ }
    }
    log(`扩展 ${key} 的动作已排队：${act}`);
    return { ok: true, nonce: item.nonce, pending: list.length + 1, message: '已交给扩展，几秒后刷新看结果' };
  }

  /** 读即消费：扩展取走后队列清空，避免它每轮都重复执行同一个点击。 */
  function take(extId) {
    const key = String(extId ?? '').trim();
    if (!key) return { ok: false, reason: 'bad_request', message: '缺扩展 id' };
    const t = now();
    const list = store.get(key) || [];
    const actions = list.filter((it) => alive(it, t));
    store.delete(key);
    return {
      ok: true,
      actions: actions.map((it) => ({ action: it.action, nonce: it.nonce, at: it.at, payload: it.payload ?? null })),
      dropped: list.length - actions.length,
    };
  }

  /** 只读快照，面板显示「有几个待处理」用；不消费。 */
  function peek(extId) {
    const key = String(extId ?? '').trim();
    const t = now();
    const list = (store.get(key) || []).filter((it) => alive(it, t));
    return { ok: true, pending: list.length, actions: list.map((it) => it.action) };
  }

  /**
   * 等到「这个扩展有动作」或超时。
   *
   * 超时不是错误：长轮询本来就会空手回去，扩展紧接着再发一个即可。
   */
  function wait(extId, timeoutMs = 25_000) {
    const key = String(extId ?? '').trim();
    if (!key) return Promise.resolve();
    return new Promise((resolve) => {
      let timer = null;
      const done = () => {
        if (timer) clearTimeout(timer);
        const set = waiters.get(key);
        if (set) {
          set.delete(done);
          if (!set.size) waiters.delete(key);
        }
        resolve();
      };
      /**
       * **不要 unref**：这个定时器就是「把请求挂住」本身。unref 之后事件循环
       * 一看没别的活就直接退出，Promise 永远不 resolve（测试里表现为
       * `cancelledByParent`，真实宿主里表现为长轮询偶尔不返回）。
       */
      timer = setTimeout(done, Math.max(0, Math.min(60_000, Number(timeoutMs) || 0)));
      const set = waiters.get(key) || new Set();
      set.add(done);
      waiters.set(key, set);
    });
  }

  function clear(extId) {
    const key = String(extId ?? '').trim();
    const had = store.get(key)?.length ?? 0;
    store.delete(key);
    return { ok: true, cleared: had };
  }

  return { push, take, peek, wait, clear, prune, total, sizeOf: (extId) => (store.get(String(extId ?? '').trim()) || []).length };
}
