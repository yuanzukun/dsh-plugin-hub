/**
 * 凌晨巩固：把昨天的一天"睡一觉消化掉"。
 *
 * 为什么放在凌晨：白天不该为记忆花一分钱。打分、压缩、抽三元组这些
 * 都要调模型，一旦塞进对话链路，每条消息都要多一次调用（比聊天本身还贵）。
 * 攒到凌晨，一天一次，成本可以忽略。
 *
 * 做五件事：
 *   1. 打分     ── 模型复核昨天的三级判断（白天的规则只是粗分）
 *   2. 升降级   ── 升级的变"重要"，降级的变"普通"（**critical 不许降**）
 *   3. 到期压缩 ── 到期的日记压成一句/半句，**原文不动**
 *   4. 提取约定 ── "说好下次…"进长期记忆和知识图谱（约定是有状态的，办完要关掉）
 *   5. 一句摘要 ── 昨天一句话，注入时用它顶一整天
 *   顺带抽三元组进图谱——抽错也不要紧，episode 留着能重建。
 *
 * **只是提醒，不是命令**（大肥鱼原话）：模型给的等级建议是"建议"，
 * 这里有硬护栏——不删任何东西、不降 critical、单次改动有上限。
 * 模型抽风时宁可少改，不能把记忆改坏。
 */

import { dayOf } from './journal.js';
import { RE_CORRECTION, MIN_BOT_LINES } from './self.js';
import { isRevocation, isIdentityFact, isPoliteRevocation } from './journal-bridge.js';

/** 单次巩固最多改多少条等级。防模型一口气把整天的日记全升成 critical */
const MAX_RANK_CHANGES = 30;

/** 一次喂给模型的最大条数 / 字数。超了按"等级高优先 + 时间新优先"截 */
const MAX_ROWS = 80;
const MAX_INPUT_CHARS = 6000;

/** 一天最多处理几个会话。群特别多的部署要收敛，不然凌晨会连发几十次调用 */
const MAX_CHATS_PER_RUN = 5;

const pad = (n) => String(n).padStart(2, '0');
const hhmm = (ts) => {
  const d = new Date(ts);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

/** 昨天的日期串（巩固处理的是"刚过完的那一天"） */
export function yesterdayOf(now = Date.now()) {
  return dayOf(now - 86_400_000);
}

/**
 * 从模型输出里抠 JSON。
 *
 * 不能直接 JSON.parse：模型十次有三次会包一层 ```json 或者前后带一句话。
 * 抠第一个 `{` 到最后一个 `}` 是这类场景的通用解法。
 */
export function parseJsonLoose(text) {
  const s = String(text ?? '');
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  if (a < 0 || b <= a) return null;
  try {
    return JSON.parse(s.slice(a, b + 1));
  } catch {
    return null;
  }
}

/**
 * A10③：模型把输出预算全花在思考上、一个 JSON 都没给，值得再试一次。
 *
 * 对方的做法是「放宽 maxTokens 到 16000 重试」，**我们照搬不了**：
 * 巩固走 DSH 宿主会话，输出预算在会话配置里，`turn.run()` 只有
 * source / images / timeoutMs 三个可选参数，调用点改不了上限。
 * 能做的等价物是**把要求收紧一次**：只认「空输出」和「长篇但没有
 * `{`」这两种真·思考吃光预算的形态，别的坏输出保持原样退回机械压缩，
 * 免得每天凌晨平白多调一次模型。
 */
export function needsJsonRetry(raw, plan) {
  if (plan) return false;
  const s = String(raw ?? '');
  return !s.trim() || (s.length > 200 && !s.includes('{'));
}

/** 重试不重发那一整天的记录，只在末尾追加一句硬要求（省输入 token） */
export function terseJsonPrompt(prompt) {
  return `${String(prompt ?? '')}\n\n（上一轮没有给出 JSON。这次不要思考过程、不要解释，直接输出一个 JSON 对象。）`;
}

/**
 * 没有模型（或模型抽风）时的机械压缩。
 *
 * 截前 40 字而不是"丢掉"：铁律是压不是删，机械手段也得遵守。
 * 截出来的东西当然不如模型写的那句，但它至少留住了开头那半句。
 */
export function mechanicalDigest(text, max = 40) {
  const s = String(text ?? '').replace(/\s+/g, ' ').trim();
  if (s.length <= max) return s;
  return s.slice(0, max - 1) + '…';
}

/**
 * 按"等级高 + 时间新"挑要喂给模型的条目，并压到字数上限。
 */
export function pickRows(rows, { maxRows = MAX_ROWS, maxChars = MAX_INPUT_CHARS } = {}) {
  const W = { critical: 3, important: 2, normal: 1 };
  const sorted = [...rows].sort(
    (a, b) => (W[b.level] ?? 1) - (W[a.level] ?? 1) || b.at - a.at,
  );
  const out = [];
  let used = 0;
  for (const r of sorted) {
    const line = `[${r.id}] ${hhmm(r.at)} ${r.role === 'bot' ? '她' : r.sender || '某人'}(${r.level}): ${r.text}`;
    if (out.length >= maxRows || used + line.length > maxChars) continue;
    out.push({ row: r, line });
    used += line.length;
  }
  // 喂给模型时按时间正序，读起来才像一天
  out.sort((a, b) => a.row.at - b.row.at);
  return out;
}

/**
 * **L3 语义兜底的候选集**（批次 2 的第三级，00:5x 补做）。
 *
 * L1（引用精确作废）/ L2（显式改口句式）在写日记时就能确定性命中；
 * 命中的旧行已被 `invalidate` 标失效，而 `byDay()` 统一过滤失效行，
 * 所以**这里拿到的天然就是「L1/L2 没处理掉的」**。
 *
 * 只剩一种情况需要模型：同一会话里还留着 ≥2 条高等级记录，且后面
 * 明确推翻了前面（改口句指不出具体旧约定、L2 因此没敢作废）。
 *
 * 与 §10.6 原规格的一处技术调整（20:42「想到更好的就用你的」授权）：
 * 原写「无显式改口词时判一次」，这里改成**把改口句当时间上界**。
 * 理由：L2 命中时旧行已失效、撤销句又不 append，于是「当天有改口句
 * 却仍剩 ≥2 条高等级行」恰恰是 L2 未命中的信号；按原规格跳过会漏掉
 * 真机 P4 的残余。时间上界同时挡住「把新约定误作废」。
 *
 * @returns {{ids:string[], before:number, lines:string[]}|null} 条件不满足返回 null
 */
export function l3Candidates(rows, { maxRows = 12 } = {}) {
  const list = Array.isArray(rows) ? rows : [];
  const high = list
    .filter((r) => r && r.kind === 'chat' && r.role === 'user'
      && (r.level === 'critical' || r.level === 'important')
      && !r.invalidAt
      && !isIdentityFact(r.text)
      && !isRevocation(r.text))
    .slice(-maxRows);
  if (high.length < 2) return null;

  /**
   * 时间上界只认**用户说的、真正的改口**。
   *
   * 00:5x 独立复核抓到的 P0：原来 `revokes` 把当天所有含改口词的行都算上，
   * 还取 `Math.min`（最早那条）。于是更早一句客套「不用了谢谢」、甚至 bot
   * 回声里的「别再发图了」，都会把上界压到所有约定之前，`apply()` 的
   * `row.at >= before` 把全部候选挡掉 —— L3 静默不触发。
   *
   * 三处收紧：只收 user/chat；排除 L2 已识别的纯客套（复用同一判据）；
   * 取**最后**一条合格改口句（改口之后才定下的新约定仍被挡，旧约定不误挡）。
   */
  const revokes = list.filter((r) => r && r.role === 'user' && r.kind === 'chat'
    && isRevocation(r.text) && !isPoliteRevocation(r.text));
  const before = revokes.length ? Math.max(...revokes.map((r) => Number(r.at) || 0)) : 0;
  const lines = [
    ...high.map((r) => `[${r.id}] ${hhmm(r.at)} ${r.sender || '某人'}(${r.level}): ${r.text}`),
    ...revokes.slice(-3).map((r) => `（改口）${hhmm(r.at)} ${r.sender || '某人'}: ${r.text}`),
  ];
  return { ids: high.map((r) => r.id), before, lines };
}

/** 拼提示词 */
/** 旧事实进 prompt 的上限（D6）：多了既烧 token，又让模型挑花眼 */
export const MAX_PROMPT_FACTS = 10;

/**
 * D6：把 agreements 的一条归一化成 `{text, op, old}`。
 *
 * 老模型 / 老盘上跑出来的 `agreements` 是纯字符串数组，必须继续按新增处理；
 * 新格式是对象三态。缺 `old` 的 update/outdated 一律退化成 add——没有定位词
 * 就让模型去「作废某条旧约定」，等于给它一张空白支票。
 */
export function normalizeAgreement(raw) {
  if (typeof raw === 'string') return { text: raw.trim(), op: 'add', old: '', status: 'fact' };
  const o = raw && typeof raw === 'object' ? raw : {};
  const text = String(o.text ?? '').trim();
  const want = String(o.op ?? '').toLowerCase();
  const op = ['add', 'update', 'outdated'].includes(want) ? want : 'add';
  const old = String(o.old ?? '').trim();
  /**
   * 可信度：只认 `hearsay`，其它一律 `fact`。
   *
   * 为什么默认 fact 而不是"让模型必须表态"：老 prompt 跑出来的输出里没有
   * 这个字段，天天有历史输出没这个键；默认 fact 才能让老行为逐字节不变，
   * 也不会因为模型漏写就把一条真事实降级成"听说的"。
   */
  const status = String(o.status ?? '').toLowerCase() === 'hearsay' ? 'hearsay' : 'fact';
  if (!text) return { text: '', op: 'add', old: '', status: 'fact' };
  if (!old && op !== 'add') return { text, op: 'add', old: '', status, degraded: '缺 old 定位词' };
  return { text, op, old, status };
}

/**
 * D6：只读地算出这一条会怎么处置，给 dry-run 预览用。
 *
 * 判据和 `memory.supersede()` 一致（活事实里 `includes(old)`，0 条 / 多条都不猜），
 * 但**这里不是最终护栏**：真正落盘时仍由 `supersede()` 再判一次，
 * 预览和真实之间若有别名/并发差异，宁可退化成新增，也不会误作废。
 */
export function planAgreementOp(item, facts = []) {
  const base = { text: item.text, op: item.op, old: item.old };
  if (item.op === 'add' || !item.old) return { ...base, will: 'add', reason: '新增' };
  const hits = (Array.isArray(facts) ? facts : [])
    .filter((f) => !f?.until && String(f?.text ?? '').includes(item.old))
    .map((f) => String(f.text));
  if (!hits.length) {
    return { ...base, will: 'add', reason: `没找到包含「${item.old}」的活事实，不猜，按新增` };
  }
  if (hits.length > 1) {
    return { ...base, will: 'add', reason: `「${item.old}」匹配 ${hits.length} 条，不猜，按新增`, candidates: hits };
  }
  return { ...base, will: 'supersede', reason: `唯一定位「${hits[0]}」`, match: hits[0] };
}

export function buildPrompt({ day, chatName, items, revocation = null, facts = [], profiles = null }) {
  const factLines = (Array.isArray(facts) ? facts : [])
    .map((f) => String(f ?? '').trim()).filter(Boolean)
    .slice(0, MAX_PROMPT_FACTS)
    .map((f, i) => `  [${i + 1}] ${f}`);
  /**
   * D7：人物档案是**可选**的一项。关着时下面两段条件都插空串，
   * 整个 prompt 与未上线前逐字节一致——否则等于给所有默认用户改了
   * 巩固提示词（模型输出会跟着变，属于静默回归）。
   */
  const withProfiles = Boolean(profiles?.enabled);
  const fmt = [
    '{"summary":"...","ranks":[["id","level"]],"compress":[{"id":"...","digest":"..."}],',
    ' "triples":[{"s":"...","rel":"...","o":"...","scope":"global"}],',
    ' "agreements":["...", {"text":"...","op":"update","old":"..."}],"closed":[]',
    revocation ? ',"revoked":[]' : '',
    withProfiles ? ',"profiles":[{"who":"显示名","openid":"拿不到就留空","impression":"一小句","tips":"一小句"}]' : '',
    '}',
  ].join('');
  return [
    `下面是你 ${day} 这天在「${chatName || '一个会话'}」里聊过的话（她=你自己说的，其他人=对方说的）。`,
    '请做四件事，只输出一个 JSON，不要解释、不要代码块围栏：',
    '',
    '1. summary：把这一天写成**一句话**，不超过 60 字。要具体（谁说了什么要紧的事），不要写"聊了一些话题"。',
    '2. ranks：你觉得等级判错了的条目，给 ["id","等级"]。等级只能是 critical / important / normal。',
    '   · critical = 关于这个人身份的事实、他明确要求你记住的',
    '   · important = 情绪、约定、偏好、值得记住的细节',
    '   · normal = 寒暄、"嗯""好"这类',
    '3. compress：已经过时的日常琐碎，压成一句（不超过 40 字）。压缩时**必须原样保留**这几类：',
    '   人名 / 地名 / 物品名 / 数字 / 日期与时间 / 待办与承诺 / 否定（他说“不要什么”）/ 金额。',
    '   不要写成“某个地方”“那个东西”——以后要靠这些名词才找得到。真正重要的事不要放进这里。',
    '   （为什么要逐条点名：只说“保留重要信息”时，模型会把“答应下周三前给答复”这种带时间的承诺压掉，',
    '     它在模型的判断里不够“重要”，但漏掉就是忘了答应过的事。）',
    '4. triples：从里面抽出"谁—什么关系—什么"的三元组，格式',
    '   {"s":"主语","rel":"关系","o":"宾语","scope":"global"|"chat","op":"add"|"update"|"invalidate"}。',
    '   · op=add：新事实，和已有的不冲突',
    '   · op=update：**同一个人同一关系换了值**（"住在"从杭州变上海）→ 会自动把旧的那条作废',
    '   · op=invalidate：这条不再成立，而且没有新值（分手了、搬走了但没说去哪）',
    '   · 拿不准就写 add——写 update 会关掉旧值，宁可多留一条也不要误删',
    '   · scope=global：关于主人本人的事实（住处、名字、生日、工作、长期偏好）',
    '   · scope=chat：只在这个群成立的（群友的绰号、群内梗、小圈子关系）',
    '   · rel 用两三个字的动词或名词（住在/喜欢/叫/生日是/工作在/养了/认识）',
    '   · 没有可抽的就给空数组',
    '5. agreements：里面出现的"约定 / 答应 / 说好要办的事"，一条一句；没有就给空数组。',
    '   若这一天里**改了以前记下的约定**、或**以前的约定已经不算了**，那一条改写成对象：',
    '   {"text":"新约定","op":"update"|"outdated","old":"旧说法里能唯一定位它的几个字"}。',
    '   · op=update：旧约定换成新说法 → 按 old 找到那一条作废，再记下新的',
    '   · op=outdated：旧约定不再成立、也没有新值 → 只作废，不记新的',
    '   · 其余照旧给字符串（= 新增）。old 找不到、或匹配到多条时我不会猜，一律按新增处理；',
    '     所以拿不准就写字符串，宁可多留一条，也不要误作废。',
    /**
     * 可信度：只教模型认「转述」这一种，不教它认「猜的」。
     *
     * 转述是最常见的失真来源（"张三说他下周三出差"被记成"主人下周三出差"），
     * 而"猜的"应当由程序按来源判定，不该让模型给自己的输出打分。
     */
    '   · 若这条约定**不是你亲耳听当事人说的**（是别人转述、或记录里说"某某说他…"），',
    '     在对象里加 "status":"hearsay"；是本人说的、或拿不准，就**不要写**这个键（默认当本人说的）。',
    '6. closed：以前答应过、今天明显已经办完的约定，给 [{"s":"主语","rel":"约定","o":"那件事"}]；没有就给空数组',
    /**
     * D7 第 8 项：把「对一个人的印象」交给每天这次巩固顺带提炼。
     * 不另开一次模型调用（凌晨一天一次的成本不变），也不放在消息热链路上。
     * 关着时模型连这个选项都看不到，输出形状与老版本完全一致。
     */
    ...(withProfiles ? [
      '8. profiles：今天**明显看得出来**的、对某个人的印象和跟他相处要注意什么，给',
      '   [{"who":"显示名","openid":"他的 openid（拿不到就留空）","impression":"一小句印象","tips":"一小句相处建议"}]；',
      '   · 只写当天真有依据的，别猜、别把群里的玩笑当结论，也别写身份事实（那是 triples 的活）',
      '   · 已有的档案列在下面，改口就照实写新的一条，别重复',
      '   · 没有就给空数组——宁可漏，也别编一个出来',
    ] : []),
    /**
     * 第 7 项只在 L3 候选成立时才加。合并进巩固这一次调用，不再单独调模型：
     * 凌晨一天一次的成本不变，也不会给消息热链路添任何调用。
     */
    ...(revocation ? [
      '7. revoked：下面「需要判定的重要记录」里，如果**后面一条明确推翻了前面一条**，',
      '   把被推翻那条的 id 放进数组，最多一条。同一件事改了主意、明确说不用/别再、后一条否定前一条才算；',
      '   只是话题相近、补充细节、或两件能同时成立的事，都不算。',
      '   拿不准就给空数组——宁可多留一条，也不要误作废。id 必须原样照抄方括号里的值。',
    ] : []),
    '',
    '输出格式（严格按这个键名）：',
    fmt,
    ...(factLines.length
      ? ['', '—— 你已经记得的事（判断 update / outdated 时对照；old 要从这里摘） ——', ...factLines]
      : []),
    ...(withProfiles && Array.isArray(profiles?.lines) && profiles.lines.length
      ? ['', '—— 已经写过的熟人档案（要改就照实写新的，别重复） ——', ...profiles.lines]
      : []),
    '',
    '—— 下面是一天的记录 ——',
    ...items.map((i) => i.line),
    ...(revocation ? ['', '—— 需要判定的重要记录 ——', ...revocation.lines] : []),
  ].join('\n');
}

/**
 * 拼自述的提示词（第五层）。
 *
 * 和巩固其他几件事分开拼、单独调一次：素材不同——这里要的是**她自己说过的话**
 * 和**被纠正的时刻**，而巩固给的是混在一起的一整天。混在同一个 prompt 里，
 * 模型会把它写成第二份日记摘要。
 *
 * @param {object} o
 * @param {string} o.day
 * @param {Array<{text:string, at:number}>} o.said  当天她自己说过的话
 * @param {Array<{text:string, at:number}>} o.corrected 被纠正时对方说的话
 */
export function buildSelfPrompt({ day, said = [], corrected = [] } = {}) {
  const lines = [
    `下面是 ${day} 你自己说过的话（只有你说的），以及今天被对方纠正的时刻。`,
    '',
    '请用两三句话写下**关于你自己**的：',
    '· 今天你觉得自己哪里做得不够好',
    '· 你打算怎么改',
    '· 或者你对自己的新发现',
    '',
    '要求：',
    '· 只写你自己。不要写对方的事、不要复述聊了什么——那是日记的活。',
    '· 不要写「作为 AI」「作为一个语言模型」。',
    '· 不超过 100 字，口语，像随手记的一笔。',
    '· 今天确实没什么可写的，就只输出 `<<skip>>`，什么都别加。',
    '',
    '—— 你说过的话 ——',
    ...said.map((x) => `· ${x.text}`),
  ];
  if (corrected.length) {
    lines.push('', '—— 被纠正的时刻 ——', ...corrected.map((x) => `· ${x.text}`));
  }
  return lines.join('\n');
}

/**
 * @param {object} o
 * @param {object} o.journal  createJournal() 的返回
 * @param {object} o.graph    createGraph() 的返回
 * @param {object} o.memory   createMemory() 的返回（约定要沉进 facts）
 * @param {object} [o.self]   createSelf() 的返回（第五层：自我叙述）
 * @param {(p:string)=>Promise<string>} [o.generate] 没给就只做机械压缩
 */
export function createConsolidate({ journal, graph, memory, self = null, generate = null, aliasesOf = () => [], log = () => {}, now = () => Date.now(), profiles = null, profilesEnabled = false } = {}) {
  /**
   * D7：开关判据留在 host（config 是唯一真相），这里只认「有没有实例 + 开没开」。
   * 传函数是为了运行时改配置能立刻生效，不用重启 DSH。
   */
  const profOn = () => Boolean(profiles) && (typeof profilesEnabled === 'function'
    ? profilesEnabled() === true : profilesEnabled === true);
  /** 上一次的结果，面板和 /consolidate 接口读它 */
  let last = null;
  let running = false;

  /** 这天这个会话是不是已经巩固过了（摘要条目在就算） */
  function done(day, chatId) {
    return Boolean(journal.get(`day:${day}:${chatId || 'global'}`));
  }

  /**
   * 巩固一天。
   *
   * @param {object} o
   * @param {string} [o.day]  'YYYY-MM-DD'，默认昨天
   * @param {boolean} [o.dry] 只算不写（调试用）
   */
  async function run({ day = '', dry = false } = {}) {
    const t = now();
    const target = String(day || yesterdayOf(t));
    if (running) return { ok: false, reason: '上一次巩固还没跑完' };
    running = true;

    const stats = {
      ok: true,
      day: target,
      at: t,
      dry,
      chats: 0,
      rows: 0,
      ranked: 0,
      compressed: 0,
      triples: 0,
      agreements: 0,
      closed: 0,
      /** L3 语义兜底：这次巩固标失效的旧约定条数（不删行） */
      revoked: 0,
      digests: 0,
      /** 被墓碑挡下来的条数（用户删过、巩固又抽出来的） */
      suppressed: 0,
      /** 第五层：这条自述写没写（0/1），没写的理由放 selfSkip */
      self: 0,
      selfSkip: '',
      /** D7：这次巩固写下的熟人档案条数（默认关时恒 0） */
      profiles: 0,
      /** D6：dry-run 预览会列出每条约定的处置计划；另记护栏退化/作废的次数 */
      agreementOps: [],
      fallback: 0,
      outdated: 0,
      updated: 0,
      mode: generate ? 'model' : 'mechanical',
      errors: [],
    };

    try {
      const rows = journal.byDay(target);
      stats.rows = rows.length;

      /** 没有日记也要建摘要（"这天没说话"本身是信息），但只在有模型时才有意义 */
      if (!rows.length) {
        stats.ok = false;
        stats.reason = '这天没有日记';
        last = stats;
        return stats;
      }

      /** 按会话分组：串场防护要求摘要和三元组都带归属 */
      const groups = new Map();
      for (const r of rows) {
        const k = r.chatId || '';
        if (!groups.has(k)) groups.set(k, []);
        groups.get(k).push(r);
      }

      const todo = [...groups.entries()].filter(([cid]) => !done(target, cid)).slice(0, MAX_CHATS_PER_RUN);
      stats.skipped = [...groups.keys()].filter((cid) => done(target, cid));
      if (groups.size > MAX_CHATS_PER_RUN) {
        stats.truncated = [...groups.keys()].slice(MAX_CHATS_PER_RUN);
        log(`今天有 ${groups.size} 个会话，先处理 ${MAX_CHATS_PER_RUN} 个，其余留到明天`);
      }

      for (const [chatId, list] of todo) {
        stats.chats += 1;
        const items = pickRows(list);
        const chatName = list.find((r) => r.chatId === chatId)?.chatId?.slice(0, 8) || '';
        /**
         * L3 候选在这轮就算好：条件不成立时 `buildPrompt` 不带第 7 项，
         * 模型连「可以作废」这个选项都看不到，不会自作主张。
         */
        const revocation = l3Candidates(list);
        let plan = null;

        if (generate) {
          try {
            const prompt = buildPrompt({
              day: target, chatName, items, revocation,
              facts: factsForPrompt(chatId),
              profiles: profilesForPrompt(),
            });
            let raw = await generate(prompt);
            plan = parseJsonLoose(raw);
            if (needsJsonRetry(raw, plan)) {
              log(`巩固 ${target}/${chatName}：模型没写出 JSON，收紧要求再试一次`);
              try {
                raw = await generate(terseJsonPrompt(prompt));
                plan = parseJsonLoose(raw);
              } catch (e) {
                /** 重试失败不算新错误：主调用已经成功，照旧退回机械压缩 */
                log(`巩固 ${target}/${chatName} 重试失败：${e.message}`);
              }
            }
            if (!plan) {
              log(`巩固 ${target}/${chatName}：模型输出不是 JSON，退回机械压缩`);
              stats.errors.push('模型输出解析失败');
            }
          } catch (e) {
            log(`巩固 ${target}/${chatName} 调模型失败：${e.message}`);
            stats.errors.push(`调模型失败：${e.message}`);
          }
        }

        const res = apply({ day: target, chatId, list, plan, dry, revocation });
        for (const k of ['ranked', 'compressed', 'triples', 'agreements', 'closed', 'revoked', 'digests', 'suppressed', 'fallback', 'outdated', 'updated', 'profiles']) {
          stats[k] += res[k] || 0;
        }
        stats.agreementOps.push(...(res.agreementOps || []));

        /**
         * 摘要条目：即使模型给了 summary 也要落一条。
         * 没有模型时写机械摘要（"这天聊了 N 句"），
         * 因为注入那边按"有没有摘要"决定深度，缺了会一直深度重注。
         */
        if (!dry) {
          const summary =
            String(plan?.summary ?? '').trim() ||
            `这天聊了 ${list.length} 句${list.length > 6 ? '，其中有些值得记的' : ''}。`;
          journal.add({
            id: `day:${target}:${chatId || 'global'}`,
            at: list[list.length - 1].at,
            chatId,
            role: 'digest',
            kind: 'digest',
            level: 'important',
            text: summary.slice(0, 200),
          });
          stats.digests += 1;
        }
      }

      /**
       * 第五层：自述。
       *
       * 放在所有会话处理完之后，用**跨群的汇总**写一条——
       * 自述是关于「她这个人」的，一个群一份会分裂成好几个她。
       * 素材和巩固其他几件事不同（只有她自己说的话 + 被纠正的时刻），
       * 所以单独拼 prompt、单独调一次，不和 summary/ranks 混在一起。
       */
      if (self && generate && !dry) {
        try {
          const r = await writeSelf({ day: target, rows });
          if (r.written) stats.self = 1;
          else stats.selfSkip = r.why || '';
        } catch (e) {
          stats.errors.push(`写自述失败：${e.message}`);
          log(`写自述失败：${e.message}`);
        }
      }

      /** 顺手补向量的位置：这里只报数，实际补算由宿主在填充向量后调 setVec */
      stats.needVec = journal.noVec(20).length;
    } catch (e) {
      stats.ok = false;
      stats.reason = e?.message ?? String(e);
      log(`巩固失败：${stats.reason}`);
    } finally {
      running = false;
    }

    last = stats;
    return stats;
  }

  /**
   * 写一条自述。
   *
   * 触发条件是 **C 方案：按量 or 被纠正**：
   *   · 按量：当天她自己说了 `MIN_BOT_LINES` 条以上 —— 冷清的一天硬写一条
   *     「今天没说什么」，只是往库里灌水
   *   · 被纠正：**哪怕只说了三句**也要写。被纠正那一刻是最值钱的素材，
   *     纯按量的话「说错一句就被怼」的日子永远轮不到她复盘——
   *     而这恰恰是她最该记住的那天
   *
   * 最后一道门是模型自己的：`<<skip>>` 是**正常结局**，不是失败。
   *
   * 素材只取 `role='bot'` 的行和被纠正的时刻：自述不是复盘，
   * 把对方说的话也塞进去，写出来必然是第二份日记摘要。
   */
  async function writeSelf({ day, rows }) {
    const said = rows
      .filter((r) => r.role === 'bot' && r.kind === 'chat')
      .map((r) => ({ text: String(r.text || '').slice(0, 60), at: r.at }));
    const corrected = rows
      .filter((r) => r.role !== 'bot' && RE_CORRECTION.test(String(r.text || '')))
      .map((r) => ({ text: String(r.text || '').slice(0, 80), at: r.at }));

    // 一句没说就没有「关于她自己」的素材，被纠正也无从谈起
    if (!said.length) return { written: false, why: '她这天没说话' };
    if (said.length < MIN_BOT_LINES && !corrected.length) {
      return { written: false, why: `只说了 ${said.length} 条、也没被纠正，不值得写` };
    }

    /**
     * 截断是刻意的：她说的话取最近 20 条、被纠正最多 6 条。
     * 给多了模型会写成「今天聊了 A、B、C」的流水账——那是 digest 的活。
     */
    const raw = await generate(
      buildSelfPrompt({ day, said: said.slice(-20), corrected: corrected.slice(-6) }),
    );
    const text = String(raw ?? '').trim();
    if (!text || /<<\s*skip\s*>>/i.test(text)) {
      return { written: false, why: '她自己觉得没什么可写的' };
    }

    // 标记和包裹的引号摘干净：自述是要注入提示词的，带 `<<x>>` 会漏给模型
    const clean = text
      .replace(/<<[^>]*>>/g, '')
      .replace(/^["「『]|["」』]$/g, '')
      .trim();
    if (!clean) return { written: false, why: '去掉标记后没内容' };

    self.add({ text: clean.slice(0, 200), day, at: rows[rows.length - 1].at });
    log(`写了自述（${day}）：${clean.slice(0, 40)}`);
    return { written: true };
  }

  /**
   * 把模型的"建议"落到库里。
   *
   * 每条建议都要能被拒绝：id 对不上就跳过、等级非法就跳过、
   * critical 降级由 journal.setLevel 那道护栏挡掉。**宁可少改。**
   */
  /**
   * D6：给 prompt 的旧事实（≤10 条）。拿不到就给空——机械模式、
   * 或老版本没这些方法的 memory 实例照样能把巩固跑完。
   */
  function factsForPrompt(chatId) {
    try {
      const r = memory?.listRanked?.(chatId, aliasesOf(chatId)) || { global: [], chat: [] };
      return [...(r.global || []), ...(r.chat || [])].slice(0, MAX_PROMPT_FACTS);
    } catch {
      return [];
    }
  }

  /** D6：给 dry-run 判据的旧事实，要带 `until` 才能排掉已经作废的 */
  function factsForApply(chatId) {
    try {
      const full = memory?.listFull?.(chatId, aliasesOf(chatId)) || { global: [], chat: [] };
      return [...(full.global || []), ...(full.chat || [])];
    } catch {
      return [];
    }
  }

  /**
   * D7：给巩固 prompt 的已有档案对照。
   * 故意用 `recent()` 而不是 `text()`——后者是带防漏出台头的**注入块**，
   * 而且写着天级渲染缓存；在这里调会把缓存提前冻住，注入侧当天就再也不更新了。
   */
  function profilesForPrompt() {
    if (!profOn() || !profiles?.recent) return null;
    try {
      const lines = profiles.recent(6).map((r) =>
        `· ${r.name || r.key}（${r.key}）：${r.impression || ''}${r.tips ? `；相处：${r.tips}` : ''}`);
      return { enabled: true, lines };
    } catch {
      return { enabled: true, lines: [] };
    }
  }

  function apply({ day, chatId, list, plan, dry, revocation = null }) {
    const out = { ranked: 0, compressed: 0, triples: 0, agreements: 0, closed: 0, revoked: 0, digests: 0, suppressed: 0, agreementOps: [], fallback: 0, outdated: 0, updated: 0, profiles: 0 };
    const byId = new Map(list.map((r) => [r.id, r]));
    const at = list.length ? list[list.length - 1].at : now();

    /* 1. 等级复核 */
    const ranks = Array.isArray(plan?.ranks) ? plan.ranks : [];
    let changed = 0;
    for (const item of ranks) {
      if (changed >= MAX_RANK_CHANGES) break;
      const [id, level] = Array.isArray(item) ? item : [item?.id, item?.level];
      const row = byId.get(String(id ?? ''));
      if (!row || !['critical', 'important', 'normal'].includes(level)) continue;
      if (row.level === level) continue;
      if (dry) {
        out.ranked += 1;
        changed += 1;
        continue;
      }
      // critical → 别的等级，这里会返回 false（护栏在 journal 里）
      if (journal.setLevel(row.id, level)) {
        out.ranked += 1;
        changed += 1;
      }
    }

    /* 2. 压缩：模型点名的 + 自己到期的 */
    const plans = Array.isArray(plan?.compress) ? plan.compress : [];
    const seen = new Set();
    for (const item of plans) {
      const id = String(item?.id ?? '');
      const digest = String(item?.digest ?? '').trim();
      if (!id || !digest || seen.has(id)) continue;
      const row = byId.get(id);
      if (!row || row.level === 'critical') continue;
      seen.add(id);
      if (dry) {
        out.compressed += 1;
        continue;
      }
      if (journal.compress(id, digest)) out.compressed += 1;
    }
    /**
     * "到期自动压"**不在这里做了**。
     *
     * 原来这段在 `apply()` 里，而 `apply()` 是**按会话**调用的——
     * 3 个群就扫 3 遍全库（每遍 5000 行全文）。更要紧的是它挂在 `run(day)` 上：
     * `dueDay()` 只在"昨天有日记"时才跑，没人说话的日子积压就停在那儿。
     *
     * 现在由 `compressDue()` 独立跑（宿主每 10 分钟一轮），与按天摘要解耦。
     * 模型在这里点名的条目照旧压（上面那段），两件事互不影响。
     */

    /* 3. 三元组 → 图谱（先落 episode，抽错能重建） */
    const triples = Array.isArray(plan?.triples) ? plan.triples : [];
    if (triples.length && graph?.enabled?.() && !dry) {
      const ep = graph.addEpisode({
        at,
        chatId,
        text: `[${day}] ` + list.slice(0, 12).map((r) => r.text).join(' / ').slice(0, 1200),
        journalId: list[0]?.id ?? null,
      });
      for (const tr of triples) {
        const s = String(tr?.s ?? '').trim();
        const rel = String(tr?.rel ?? '').trim();
        const o = String(tr?.o ?? '').trim();
        if (!s || !rel || !o) continue;
        // scope=global 的边挂在跨群，chat 的只挂这个群
        const scope = String(tr?.scope ?? 'chat') === 'global' ? '' : chatId;
        /**
         * 改主意靠模型给 `op`，不再靠"关系名里有没有'住'字"这种正则。
         * 「我搬到上海了」不含"住/在"，正则漏判 → 两条"住在"并存，
         * 问"现在住哪"两个都返回。
         *
         * 护栏：`update` 只有在**确实存在同名活边**时才作废旧值；
         * 没有活边就退化成 add —— 宁可多留一条，也不要因为模型多写一个
         * `update` 把唯一那条事实关掉。
         */
        const op = String(tr?.op ?? '').toLowerCase();
        /**
         * 关边 / 查墓碑都带别名：换机器人之后「这条关系」横跨好几个 openid，
         * 只按当前键处理的话，旧键那条活边关不掉、旧键的墓碑也查不到——
         * 表现是「说改主意了，问起来还是两个答案」。
         */
        const als = aliasesOf(scope);
        if (op === 'invalidate') {
          if (graph.closeEdge({ src: s, rel, dst: o, at, chatId: scope, aliases: als })) out.closed += 1;
          continue;
        }
        /**
         * 用户删过的关系**不许再写回来**。
         *
         * 这是墓碑真正生效的地方：`graph.suppressEdge` 只是删了行并记了一笔，
         * 如果这里不问一句，下一次巩固会把同一件事从日记里重新抽出来——
         * 用户会看到"删了又长回来"，那比删不掉更让人火大。
         *
         * 查的是 `scope`：删的时候选了"只删这个会话"，那别的会话照样能写；
         * 选的是全局，`chat_id=''` 的墓碑对所有会话都命中。
         */
        if (graph.isSuppressed?.({ src: s, rel, dst: o, chatId: scope, aliases: als })) {
          out.suppressed += 1;
          continue;
        }
        if (op === 'update' && graph.hasActive?.(s, rel, { chatId: scope, aliases: als })) {
          graph.closeEdge({ src: s, rel, at, chatId: scope, aliases: als });
        }
        if (graph.addEdge({ src: s, rel, dst: o, at, chatId: scope, episodeId: ep })) out.triples += 1;
      }
    } else if (dry) {
      out.triples += triples.length;
    }

    /* 4. 约定 → 长期事实（D6：比对旧记忆，op=add/update/outdated） */
    const agreements = Array.isArray(plan?.agreements) ? plan.agreements : [];
    const factsNow = factsForApply(chatId);
    for (const a of agreements) {
      const item = normalizeAgreement(a);
      if (!item.text) continue;
      const preview = planAgreementOp(item, factsNow);
      out.agreementOps.push(preview);

      /** dry-run 只算不写：把每条会怎么处置摆出来，面板/CLI 能直接看 */
      if (dry) {
        out.agreements += item.op === 'outdated' ? 0 : 1;
        continue;
      }
      /**
       * 约定也有墓碑。删掉的那条如果又从日记里被抽出来，
       * 会同时污染 facts 和图谱两个地方，所以两边都得先问一句。
       *
       * `aliases` 必须带：墓碑可能立在**新**键上（用户在新会话里删的），
       * 而巩固是按**旧**键跑（昨天的日记还在旧键下）。
       * 不带的话查不到墓碑，约定被原样写回来，读路径带别名又能读出来——
       * 用户看到的就是「删了又长回来」。
       */
      if (graph?.isSuppressed?.({ src: '主人', rel: '约定', dst: item.text.slice(0, 40), chatId, aliases: aliasesOf(chatId) })) {
        out.suppressed += 1;
        continue;
      }
      /**
       * 真实处置的**终极护栏**在 `memory.supersede()`：命中 0 条 / 多条都不猜。
       * 预览说能作废、真跑却不敢时一律退化成新增，绝不误作废一条无关的事实。
       */
      if (preview.will === 'supersede') {
        /**
         * `status` 一起递进去：`memory.supersede()` 会拦住"听说的顶掉本人说的"。
         * 拦下来在这里退化成新增（新信息不丢），而不是静默关掉一条真事实。
         */
        const r = memory?.supersede?.(chatId, item.old, { at, status: item.status });
        if (!r?.ok) {
          out.fallback += 1;
          out.agreementOps[out.agreementOps.length - 1] = {
            ...preview, will: 'add', reason: `护栏拦下：${r?.why || '没有 supersede 接口'}`,
          };
          if (item.op === 'outdated') continue;
        } else if (item.op === 'outdated') {
          out.outdated += 1;
          continue;
        } else {
          out.updated += 1;
        }
      }
      /**
       * 约定**不能跨群**，这条以前是错的。
       *
       * 原来写死 `scope='global'` + `chatId: ''`，于是群里的约定
       * （「替某人喊话给某个群」「群主要求用 Markdown 回复」）会出现在
       * **每一个**会话里——包括私聊主动搭话的提示词。实际后果是模型
       * 在私聊里对着「替 X 喊话 Y」这种只有群里才有意义的事做决策，
       * 自己都觉得别扭，最后往往选择不说。
       *
       * 全局可见是有意为之的只有**身份事实**（他是谁、住在哪）；
       * 「答应过要办的事」天然属于说这句话的那个会话。
       *
       * `chatId` 为空时（老日记没有归属）退回全局：宁可放错位置，
       * 也不要因为拿不到 id 就把一条约定静默丢掉。
       */
      memory.add(
        chatId,
        `约定：${item.text.slice(0, 160)}`,
        chatId ? 'chat' : 'global',
        { status: item.status },
      );
      graph?.addEdge?.({ src: '主人', rel: '约定', dst: item.text.slice(0, 40), at, chatId });
      out.agreements += 1;
    }

    /* 4.5 D7：熟人小档案 —— 每天巩固顺带提炼，天级写入，不进消息热链路 */
    if (profOn()) {
      const ppl = Array.isArray(plan?.profiles) ? plan.profiles : [];
      for (const p of ppl) {
        const who = String(p?.who ?? '').trim().slice(0, 24);
        if (!who) continue;
        if (dry) {
          out.profiles += 1;
          continue;
        }
        try {
          profiles.note({
            who,
            openid: String(p?.openid ?? '').slice(0, 64),
            impression: String(p?.impression ?? ''),
            tips: String(p?.tips ?? ''),
            /** 换机器人后 openid 变了，归到同一条档案（报告 §15.1-D） */
            aliases: aliasesOf(chatId),
            /** 私聊里说话人 openid === chatId，靠它把新 openid 也归户 */
            current: chatId,
          });
          out.profiles += 1;
        } catch (e) {
          log(`写人物档案失败：${e.message}`);
        }
      }
    }

    /* 5. 办完的约定 → 关掉活边（不删，valid_to 打上时间） */
    const closed = Array.isArray(plan?.closed) ? plan.closed : [];
    for (const c of closed) {
      const s = String(c?.s ?? '').trim();
      const rel = String(c?.rel ?? '约定').trim();
      const o = String(c?.o ?? '').trim();
      if (!s || !o) continue;
      if (dry) {
        out.closed += 1;
        continue;
      }
      /**
       * `chatId` 必须跟**建边时**一致，否则关不掉。
       *
       * 实体是**按会话**存的（`entity WHERE key=? AND chat_id=?`），
       * `closeEdge` 靠 `src_id` 定位：用 `''` 去找「主人」会拿到另一个
       * 实体行，`src_id` 对不上 → 一条都关不掉，约定永远留在"没办完"里。
       *
       * 换机器人之后「建边时」可能是旧键，所以别名要一起关。
       */
      out.closed += graph?.closeEdge?.({ src: s, rel, dst: o, at, chatId, aliases: aliasesOf(chatId) }) || 0;
    }

    /* 6. L3 语义兜底：模型点名的旧约定标失效（**不删行**，留原文与出处） */
    if (revocation && Array.isArray(plan?.revoked)) {
      const allow = new Set(revocation.ids);
      const picked = [];
      for (const raw of plan.revoked) {
        /** 一次最多作废一条：模型判错的代价远大于多留一条旧约定 */
        if (picked.length >= 1) break;
        const id = String(raw ?? '');
        const row = byId.get(id);
        if (!row || !allow.has(id)) continue;              // 只认本轮候选集里的 id
        if (revocation.before > 0 && row.at >= revocation.before) continue; // 只作废改口之前的旧行
        picked.push(id);
      }
      if (picked.length) {
        if (dry) {
          out.revoked += picked.length;                  // dry 只算不写
        } else if (typeof journal.invalidate === 'function') {
          out.revoked += Number(journal.invalidate(picked, {
            at,
            supersededBy: `consolidate:${day}`,
          })) || 0;
        }
      }
    }

    return out;
  }

  /**
   * 过期压缩：把"到期且还没压过"的条目各压成一句。
   *
   * 为什么独立成一个节拍，而不是留在 `run(day)` 里：
   *   · `dueDay()` 的判据是"昨天有日记"，没人说话的日子它直接返回空，
   *     积压的过期条目就停在那儿没人管；
   *   · 原来它写在 `apply()` 里，而 `apply()` 是**按会话**跑的 —— N 个群扫 N 遍。
   *
   * 压的是机械摘要（本地截断 40 字），不调模型，所以每轮几百条也不花钱；
   * 压不完的下一轮接着来（取料只返回 `digest IS NULL` 的，压过的自然退出）。
   *
   * @param {{limit?: number, dry?: boolean}} [o]
   * @returns {Promise<{ok: boolean, compressed: number, due: number, remaining: number, reason?: string}>}
   */
  async function compressDue({ limit = 500, dry = false } = {}) {
    const out = { ok: true, compressed: 0, due: 0, remaining: 0 };
    try {
      const rows = journal.dueToCompress(now(), limit);
      out.due = rows.length;
      for (const row of rows) {
        if (dry) {
          out.compressed += 1;
          continue;
        }
        /** 只写 digest、不动 text —— 遗忘靠压缩，原文永远留着 */
        if (journal.compress(row.id, mechanicalDigest(row.text))) out.compressed += 1;
      }
      out.remaining = typeof journal.dueCount === 'function' ? journal.dueCount(now()) : 0;
      return out;
    } catch (e) {
      out.ok = false;
      out.reason = e?.message ?? String(e);
      log(`过期压缩失败：${out.reason}`);
      return out;
    }
  }

  /**
   * 该不该跑。
   *
   * 判定只看两件事：到了巩固点钟没有、这天的摘要存不存在。
   * **不额外存"上次跑过"的状态文件**——摘要本身就是凭据，
   * 少一个可能和真实状态不一致的地方。
   *
   * @returns {string} 要巩固的日期；不用跑就空串
   */
  function dueDay({ hour = 4, at = now() } = {}) {
    const d = new Date(at);
    if (d.getHours() < hour) return '';
    const target = yesterdayOf(at);
    const rows = journal.byDay(target);
    if (!rows.length) return '';
    const chats = new Set(rows.map((r) => r.chatId || ''));
    for (const cid of chats) if (!done(target, cid)) return target;
    return '';
  }

  return {
    run,
    /** 过期压缩（宿主每 10 分钟调一次，和按天巩固解耦） */
    compressDue,
    dueDay,
    done,
    status: () => last,
    /** 供测试注入假时钟 */
    _now: now,
  };
}
