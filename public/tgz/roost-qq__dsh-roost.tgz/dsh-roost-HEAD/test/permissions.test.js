/**
 * 权限档位 → 工具收走的测试。
 *
 * 盯的是一个**看不见的** bug：`tools.restrict({ deny })` 会校验工具名，
 * 只要有一个名字不存在就整批拒绝（`names unknown global tools …`）。
 * 我们之前写死的 `['bash','pwsh','shell','fs',…]` 是按 OneBot 时代想象的，
 * 这版 DSH 里一个都没有——于是「群友只能用聊天」这条硬限制**从来没生效过**，
 * 而且失败被日志层吞掉，面板上只剩一个空白的冒号。
 *
 * 所以这里测的不是「名字对不对」（那是 DSH 的事），而是：
 * 清单必须来自 DSH、白名单之外一律收走、读不到清单要**明说没收成**而不是装作收住了。
 *
 * 跑法：node --test test/permissions.test.js
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { planGuestTools, planDenyTools, planPersonaTools, GUEST_KEEP_TOOLS, AWAKE_DENY_TOOLS, OUTPUT_TOOLS, isOwnerSender } from '../src/permissions.js';

/** 这版 DSH 真实报出来的全局工具（2026-10-28 面板日志里抄的） */
const REAL_TOOLS = [
  'edit', 'list_mcp_resource_templates', 'list_mcp_resources', 'load_workspace_dependencies',
  'mcp__graphflow__gf_edit', 'mcp__graphflow__gf_exec', 'mcp__graphflow__gf_macro',
  'mcp__graphflow__gf_read', 'ops_read_files', 'pwd', 'read', 'read_image',
  'read_mcp_resource', 'working_directory', 'write',
];

const fakeTools = (names) => ({ schemas: () => names.map((name) => ({ name })) });

test('真实清单：除了白名单全收走', () => {
  const plan = planGuestTools(fakeTools(REAL_TOOLS));
  assert.equal(plan.ok, true);
  for (const n of REAL_TOOLS) assert.ok(plan.deny.includes(n), `${n} 应该被收走`);
  assert.equal(plan.deny.length, REAL_TOOLS.length);
});

test('白名单里的工具不会被收走', () => {
  const all = [...REAL_TOOLS, ...GUEST_KEEP_TOOLS];
  const plan = planGuestTools(fakeTools(all));
  assert.equal(plan.ok, true);
  for (const n of GUEST_KEEP_TOOLS) assert.ok(!plan.deny.includes(n), `${n} 不该被收走`);
});

test('自己注册的工具只要不在白名单里，一样收走', () => {
  // memory_note 是写长期记忆的，给群友等于允许往记忆里投毒
  const plan = planGuestTools(fakeTools([...REAL_TOOLS, 'memory_note']));
  assert.equal(plan.ok, true);
  assert.ok(plan.deny.includes('memory_note'));
});

test('DSH 以后加了新工具，默认也是收走的（fail-closed）', () => {
  const plan = planGuestTools(fakeTools([...REAL_TOOLS, 'some_new_shell_tool']));
  assert.equal(plan.ok, true);
  assert.ok(plan.deny.includes('some_new_shell_tool'));
});

test('旧黑名单那串名字：现在一个都不会出现在 deny 里', () => {
  // 这些名字 DSH 根本没有，硬塞进去会让 restrict 整批抛错
  const plan = planGuestTools(fakeTools(REAL_TOOLS));
  for (const n of ['bash', 'pwsh', 'shell', 'fs', 'fs-search', 'fs_search', 'web', 'web-fetch']) {
    assert.ok(!plan.deny.includes(n), `${n} 不该出现——DSH 没有这个工具`);
  }
});

test('没有 schemas()：明说收不成，不装作收住了', () => {
  assert.equal(planGuestTools({ restrict() {} }).ok, false);
  assert.match(planGuestTools({ restrict() {} }).reason, /schemas/);
});

test('schemas() 抛错：给出原因', () => {
  const plan = planGuestTools({ schemas() { throw new Error('服务没就绪'); } });
  assert.equal(plan.ok, false);
  assert.match(plan.reason, /服务没就绪/);
});

test('清单是空的：明说没收成', () => {
  const plan = planGuestTools(fakeTools([]));
  assert.equal(plan.ok, false);
  assert.match(plan.reason, /空/);
});

test('清单里全是白名单：没有可收的，也明说', () => {
  const plan = planGuestTools(fakeTools([...GUEST_KEEP_TOOLS]));
  assert.equal(plan.ok, false);
  assert.match(plan.reason, /白名单/);
});

test('schemas() 返回的不是数组也不炸', () => {
  const plan = planGuestTools({ schemas: () => null });
  assert.equal(plan.ok, false);
});

test('工具项没有 name 的会被跳过，不会算出空字符串', () => {
  const plan = planGuestTools({ schemas: () => [{ name: 'write' }, {}, null, { name: '' }] });
  assert.equal(plan.ok, true);
  assert.deepEqual(plan.deny, ['write']);
});

test('兼容 { tool: { name } } 这种包装', () => {
  const plan = planGuestTools({ schemas: () => [{ tool: { name: 'edit' } }] });
  assert.equal(plan.ok, true);
  assert.deepEqual(plan.deny, ['edit']);
});

test('可以自己传白名单（给以后别的档位用）', () => {
  const plan = planGuestTools(fakeTools(['edit', 'read', 'pwd']), ['read']);
  assert.deepEqual(plan.deny, ['edit', 'pwd']);
});

/* ---------------- 主动搭话：收走「回复当前消息」那两个 ---------------- */

/**
 * 主动搭话那一轮没有"正在回的那条消息"，`qq_send` 挂着只会诱导模型调它，
 * 调了必然失败，然后按提示 `<<skip>>`——一轮模型调用白花（线上撞到过）。
 */
test('主动搭话：只收 qq_send / qq_close / qq_send_file，记忆工具留着', () => {
  const all = [...REAL_TOOLS, 'qq_send', 'qq_close', 'qq_send_file', 'memory_search', 'memory_note'];
  const plan = planDenyTools(fakeTools(all));
  assert.equal(plan.ok, true);
  assert.deepEqual(plan.deny.sort(), ['qq_close', 'qq_send', 'qq_send_file']);
  assert.ok(!plan.deny.includes('memory_search'), '她翻日记在主动开口时同样有用');
  assert.ok(!plan.deny.includes('memory_note'), '记事也一样');
});

test('主动搭话：这一轮没挂 qq 工具就明说没得收，不硬来', () => {
  const plan = planDenyTools(fakeTools(['memory_search', 'read']));
  assert.equal(plan.ok, false);
  assert.match(plan.reason, /本来就没挂/);
});

test('主动搭话：读不到清单要明说，不能装作收住了', () => {
  assert.equal(planDenyTools({}).ok, false);
  assert.match(planDenyTools({}).reason, /schemas/);
  assert.match(planDenyTools({ schemas() { throw new Error('没就绪'); } }).reason, /读不到/);
  assert.match(planDenyTools({ schemas: () => [] }).reason, /报不出/);
});

test('主动搭话：名字取自 schemas()，两种形状都认', () => {
  const plan = planDenyTools({ schemas: () => [{ tool: { name: 'qq_send' } }, { name: 'qq_close' }, {}] });
  assert.deepEqual(plan.deny.sort(), ['qq_close', 'qq_send']);
});

test('主动搭话：名单是可传的，默认就是那三个', () => {
  /**
   * `qq_send_file` 必须在这个名单里：主动搭话没有"正在回的那条消息"，
   * 工具一调必然失败（`fileOf` 会返回 `no-payload`），模型只好按提示
   * `<<skip>>`，一轮模型调用白花。它和 `qq_send` 是完全一样的失败形态。
   */
  assert.deepEqual(AWAKE_DENY_TOOLS, ['qq_send', 'qq_close', 'qq_send_file']);
  const plan = planDenyTools(fakeTools(['qq_send', 'qq_close']), ['qq_close']);
  assert.deepEqual(plan.deny, ['qq_close']);
});

/* ---------------- 人格级工具限制（P1） ---------------- */

/**
 * 人格文件里的 `tools` 是**第三个**限制来源（另外两个是档位、主动搭话）。
 * 语义：null = 不限制 / [] = 一个都不给 / [a,b] = 只给这些。
 *
 * 最容易做错的是「和档位取交集」：人格写了 `[edit]`，群友说话时也不能给 edit。
 */
test('人格工具：[] 表示一个都不给（仓库装来的人格默认这个）', () => {
  const plan = planPersonaTools(fakeTools(REAL_TOOLS), []);
  assert.equal(plan.ok, true);
  assert.equal(plan.deny.length, REAL_TOOLS.length, '全都要收走');
});

test('人格工具：[a,b] 只留这两个，其余收走', () => {
  const all = [...REAL_TOOLS, 'memory_search', 'qq_send'];
  const plan = planPersonaTools(fakeTools(all), ['memory_search', 'qq_send']);
  assert.equal(plan.ok, true);
  assert.ok(!plan.deny.includes('memory_search'));
  assert.ok(!plan.deny.includes('qq_send'));
  assert.ok(plan.deny.includes('edit'));
  assert.equal(plan.deny.length, all.length - 2);
});

test('人格工具：和档位取交集——人格放开的，群友也拿不到', () => {
  const all = [...REAL_TOOLS, ...GUEST_KEEP_TOOLS];
  // 人格说可以用 edit，但群友档只允许 GUEST_KEEP_TOOLS
  const plan = planPersonaTools(fakeTools(all), ['edit', 'memory_search'], GUEST_KEEP_TOOLS);
  assert.equal(plan.ok, true);
  assert.ok(plan.deny.includes('edit'), '群友不该因为人格写了就拿到 edit');
  assert.ok(!plan.deny.includes('memory_search'), '两边都允许的才留下');
});

test('人格工具：null / 非数组表示「不限制」，不产生 deny', () => {
  const plan = planPersonaTools(fakeTools(REAL_TOOLS), null);
  assert.equal(plan.ok, false);
  assert.match(plan.reason, /没有声明/);
});

test('人格工具：清单为空时明说没算成，不假装收住了', () => {
  const plan = planPersonaTools(fakeTools([]), []);
  assert.equal(plan.ok, false);
  assert.match(plan.reason, /报不出工具清单/);
});

test('人格工具：输出通道永远保留（tools: [] 是「别碰机器」，不是「别说话」）', () => {
  const all = [...REAL_TOOLS, ...OUTPUT_TOOLS, 'qq_send_file'];
  const plan = planPersonaTools(fakeTools(all), []);
  assert.equal(plan.ok, true);
  assert.ok(!plan.deny.includes('qq_send'), 'qq_send 不能被收走，否则 907 的提示词会变成谎话');
  assert.ok(!plan.deny.includes('qq_close'));
  /**
   * `qq_send_file` 和上面两个**必须区分开**。
   *
   * `qq_send`/`qq_close` 只影响「怎么说」；`qq_send_file` 是「读这台机器任意
   * 路径的文件并发出去」——是能力，不是表达方式。`OUTPUT_TOOLS` 在
   * `planPersonaTools` 里是**无条件并回去**的，一旦把发文件塞进去，
   * 群友档（默认 `chat`）在人格写 `tools: []` 时会重新拿到它，
   * 群里随便一个人说「把 D:\xxx 发我」就能把任意文件外发出去。
   * 2026-11-02 实际踩过这条，所以这里钉死。
   */
  assert.ok(plan.deny.includes('qq_send_file'), '发文件是「读文件外发」，人格 tools:[] 必须收走');
  assert.ok(plan.deny.includes('edit'));
});

test('人格工具：全都允许时返回 nothing（调用方别当告警打）', () => {
  const all = ['memory_search'];
  const plan = planPersonaTools(fakeTools(all), ['memory_search']);
  assert.equal(plan.ok, false);
  assert.equal(plan.nothing, true);
});

test('人格工具：keep=[] 这种极端值也不能把输出通道切掉', () => {
  const all = [...REAL_TOOLS, ...OUTPUT_TOOLS, 'qq_send_file'];
  const plan = planPersonaTools(fakeTools(all), ['edit'], []);
  assert.equal(plan.ok, true);
  assert.ok(!plan.deny.includes('qq_send'), '输出通道永远不收');
  assert.ok(!plan.deny.includes('qq_close'));
  assert.ok(plan.deny.includes('qq_send_file'), '发文件不是输出通道，档位不许就得收');
  assert.ok(plan.deny.includes('edit'), '人格放开但档位不许的，照样收');
});

/**
 * 主人判定：看**发送者**，不看 chatId。
 *
 * 2026-11-16 用户反馈：「粒度是 chatId 不是发送者，在群里就直接认群的 openid」。
 * 两处踩到（扩展素材审批的 `isOwner`、改资料的确认按钮），根因同一个——
 * 私聊里 chatId 恰好等于那个人，群里 chatId 是群 openid。
 */
test('主人判定：私聊里发送者等于主人 → 算', () => {
  assert.equal(isOwnerSender({ senderId: 'u1', kind: 'c2c', ownerId: 'u1' }), true);
  assert.equal(isOwnerSender({ senderId: 'u1', kind: 'dm', ownerId: 'u1' }), true);
});

test('主人判定：框架说这一句是 owner 档 → 算（它本来就是按发送者算的）', () => {
  assert.equal(isOwnerSender({ senderId: 'u1', bucket: 'owner', kind: 'group', ownerId: 'u9' }), true);
});

test('主人判定：群里 chatId 是群 openid，绝不能拿它当主人', () => {
  /** 主人把「主动搭话」填成群时 ownerId 就是群 openid；群里谁说话 chatId 都是它 */
  assert.equal(isOwnerSender({ senderId: 'member1', bucket: 'member', kind: 'group', ownerId: 'g1' }), false);
  assert.equal(isOwnerSender({ senderId: '', bucket: 'member', kind: 'group', ownerId: 'g1' }), false);
});

test('主人判定：没有发送者一律不算（主动搭话那类没有真人的轮次）', () => {
  assert.equal(isOwnerSender({ senderId: '', bucket: 'owner', kind: 'c2c', ownerId: 'u1' }), false);
  assert.equal(isOwnerSender({}), false);
});

test('主人判定：群档位不是 owner 的普通成员 → 不算', () => {
  assert.equal(isOwnerSender({ senderId: 'm1', bucket: 'manager', kind: 'group', ownerId: 'u1' }), false);
  assert.equal(isOwnerSender({ senderId: 'm1', bucket: 'unknown', kind: 'group', ownerId: 'u1' }), false);
});
