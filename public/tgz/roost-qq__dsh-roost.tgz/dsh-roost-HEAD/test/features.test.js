import { test } from 'node:test';
import assert from 'node:assert/strict';

import { FEATURES, FEATURE_GROUPS, visibleFeatures, visibleGroups, readFeatures, rawFeature, forcedDenyTools, patchForFeature, cannotEnable, featureDef, kindOf, readSettings, normalizeSetting } from '../src/features.js';
import { resolvePolicy, defaultStore, PINNED_KEEP } from '../src/capabilities.js';
import { DEFAULTS } from '../src/config.js';

const POOL = [
  'memory_search',
  'memory_note',
  'qq_send',
  'qq_close',
  'qq_send_file',
  'sticker_pick',
  'edit',
  'read',
  'gh_repo',
];

const ALL_ON = {
  speakUp: { enabled: true },
  awake: { enabled: true },
  memory: { enabled: true, tools: true },
  closing: { enabled: true },
  qqTools: { enabled: true },
  sendFile: { enabled: true },
  stickers: { enabled: true },
  tts: { enabled: true },
  compact: { enabled: true },
  persona: { command: { enabled: true } },
};

test('features：每个开关的 path 都能在对应来源里找到，没有空指路牌', () => {
  /**
   * 这条看起来像废话，但它挡住的是最尴尬的一类 bug：
   * 界面上一排开关，其中一个读的是不存在的字段，于是永远显示「开」，
   * 关掉了什么也没发生，还没人发现。
   */
  for (const f of FEATURES) {
    assert.ok(f.id, 'id 必填');
    assert.ok(f.label, `${f.id} 缺 label`);
    assert.ok(Array.isArray(f.path) && f.path.length, `${f.id} 缺 path`);
    assert.ok(f.source === 'config' || f.source === 'store', `${f.id} 的 source 只能是 config/store`);
    assert.ok(Array.isArray(f.affects), `${f.id} 的 affects 必须是数组`);
    assert.ok(Array.isArray(f.requires), `${f.id} 的 requires 必须是数组`);
  }

  // 分组要覆盖全部，漏一个就说明有个开关在界面上永远不出现
  const grouped = new Set(FEATURE_GROUPS.flatMap((g) => g.ids));
  for (const f of FEATURES) assert.ok(grouped.has(f.id), `${f.id} 没进任何分组`);
  for (const id of grouped) assert.ok(featureDef(id), `分组里有个不存在的开关 ${id}`);
});

test('features：数值项拒空值（Number(\'\') === 0 会静默关掉排队）', () => {
  /**
   * 真实 bug：能力页的数字输入框清空后失焦，前端把 `''` 提交上来，
   * 后端 `Number('')` 得 0，而 `queueMax.min` 恰好是 0（0 = 关掉排队，合法），
   * 于是写进 config 并回「已保存」——排队被静默关掉，用户完全看不出来。
   */
  const f = featureDef('queueMax');
  for (const v of ['', '  ', null, undefined, false, [], {}]) {
    assert.equal(normalizeSetting(f, v), null, `空值 ${JSON.stringify(v)} 必须被拒`);
    assert.equal(patchForFeature('queueMax', v), null, `patch 也必须拒 ${JSON.stringify(v)}`);
  }
  /** 0 本身是合法值，别为了挡空串把它一起误伤 */
  assert.equal(normalizeSetting(f, 0), 0, '0 = 关掉排队，是合法值');
  assert.equal(normalizeSetting(f, 4), 4);
  assert.equal(normalizeSetting(f, 11), null, '超过 max 要拒');
  assert.equal(normalizeSetting(f, -1), null, '低于 min 要拒');
  assert.equal(normalizeSetting(f, 2.5), null, '非整数要拒');
});

test('features：全开时什么都不收', () => {
  const deny = forcedDenyTools(ALL_ON, { features: { sendFile: true } }, POOL);
  assert.deepEqual(deny, []);
});

test('features：关「分段说话」要收掉 qq_send 和 qq_close（钉住项也拦不住）', () => {
  /**
   * 这条是功能层的**根本语义**：钉住项约束的是「用户策略不许乱关」，
   * 而功能整个关掉是更上层的事。两者顺序写反，就会出现
   * 「页面上关着分段说话，模型还在调 qq_send」。
   */
  const cfg = { ...ALL_ON, qqTools: { enabled: false } };
  const deny = forcedDenyTools(cfg, {}, POOL);
  assert.ok(deny.includes('qq_send'));
  assert.ok(deny.includes('qq_close'));
  assert.ok(!deny.includes('sticker_pick'), '不该连累别的');

  // 钉住项里确实有 qq_send，所以这条真的在测覆盖关系
  assert.ok(PINNED_KEEP.includes('qq_send'));

  const store = defaultStore();
  const r = resolvePolicy({ pool: POOL, bucket: 'owner', store, forceDeny: deny });
  assert.ok(r.ok);
  assert.ok(!r.allow.includes('qq_send'), '功能关了，主人也不该还能调');
  assert.ok(r.forced.includes('qq_send'), '要能说清「是被功能关掉的」');
});

test('features：关「记忆」收记忆工具，但不动别的档位配置', () => {
  const cfg = { ...ALL_ON, memory: { enabled: false, tools: true } };
  const deny = forcedDenyTools(cfg, {}, POOL).sort();
  assert.deepEqual(deny, ['memory_note', 'memory_search']);

  // 记性关了但表情包还在
  assert.ok(!deny.includes('sticker_pick'));
});

test('features：依赖项关着时，本项显示为关（只影响显示，不改配置）', () => {
  /**
   * `awake` 是「先想想要不要开口」，它靠 `speakUp` 排期。
   * 总闸关了，判断层就是个空转的开关，界面上不该显示成「开」。
   */
  const cfg = { ...ALL_ON, speakUp: { enabled: false } };
  const on = readFeatures(cfg, {});
  assert.equal(on.speakUp, false);
  assert.equal(on.awake, false, '依赖 speakUp，应连带显示为关');

  // 但配置原文没被改：rawFeature 仍然是用户填的那个值
  assert.equal(rawFeature(cfg, {}, 'awake'), true);
});

test('features：没写过的字段当「开」，写了 false 才是关', () => {
  /**
   * 老配置里 `tts.enabled` 可能整个不存在。若把 `undefined` 当关，
   * 用户升级之后会发现语音、表情包全没了——而他从没关过。
   */
  const on = readFeatures({}, {});
  for (const f of FEATURES) {
    /** 非布尔项（保留期下拉）不参与开关语义，`0` 是「永久」不是「关」 */
    if (kindOf(f) !== 'toggle') continue;
    /**
     * 例外：声明了 `default: false` 的「放宽权限」类开关，没配过也必须当关。
     * 其余 toggle 保持历史语义（老配置升级不丢功能）。
     */
    assert.equal(
      on[f.id],
      f.default === false ? false : true,
      f.default === false ? `${f.id} 默认关，空配置下也应当是关` : `${f.id} 在空配置下应当是开`,
    );
  }
  assert.equal(on.chatLookForMembers, false, '群友查记录默认关，不能靠「没配」变成开');
  assert.equal(rawFeature({}, {}, 'chatLookForMembers'), false, '面板显示的原始值也按默认关');
  assert.equal(
    readFeatures({ chat: { chatLookForMembers: true } }, {}).chatLookForMembers,
    true,
    '显式写了 true 才真的放行',
  );
  /**
   * 非布尔项的默认值单独验一次。
   *
   * 这里用一个**临时**定义验机制本身：账本的保留期不在 dsh-roost 的 config 里
   * （它在 bot 那边），所以不能拿它当例子——那会变成「面板显示永久、实际按 7 天删」。
   */
  /**
   * 不整对象 deepEqual 了：阶段 2 起会陆续新增非布尔项，写死两个键等于
   * 每加一个开关就要改一次老用例，而且失败信息看不出是谁缺默认值。
   * 新增项的默认值由下面「骨架：新开关默认值都是关」那条统一验。
   */
  const settings = readSettings({}, {});
  assert.equal(settings.queueMax, 2, '非布尔项取定义里的默认值');
  assert.equal(settings.queueMinBudgetSec, 30, '非布尔项取定义里的默认值');

  assert.equal(readFeatures({ tts: { enabled: false } }, {}).voice, false);
});

test('features：发文件存在 store 里，其余存 config，不混', () => {
  const p = patchForFeature('sendFile', false);
  assert.deepEqual(p, { store: { features: { sendFile: false } } });

  const q = patchForFeature('qqTools', false);
  assert.deepEqual(q, { config: { qqTools: { enabled: false } } });

  // 三层路径要折对，写错一层就是「改了没反应」
  const m = patchForFeature('memoryTools', false);
  assert.deepEqual(m, { config: { memory: { tools: false } } });
});

test('features：想开但前置没满足时，给一句人话', () => {
  const cfg = { ...ALL_ON, speakUp: { enabled: false } };
  const why = cannotEnable(cfg, {}, 'awake');
  assert.ok(why.includes('主动搭话'), `应当指出要先开哪一项，实际：${why}`);

  assert.equal(cannotEnable(ALL_ON, {}, 'awake'), '');
  assert.equal(cannotEnable(ALL_ON, {}, '没这个开关'), '没有这个开关');
});

test('features：forcedDenyTools 只返回池子里真有的名字', () => {
  /**
   * `tools.restrict` 一个名字不认识就整批拒绝（0.10.10 那次，
   * 白名单从没生效过）。所以功能层也只能吐池内名字。
   */
  const cfg = { ...ALL_ON, memory: { enabled: false, tools: false } };
  const deny = forcedDenyTools(cfg, {}, ['edit', 'read']);
  assert.deepEqual(deny, [], '池子里没有记忆工具，就不该吐那几个名字');

  // 不传 pool 时给全集，交给调用方按实际挂载过滤
  const all = forcedDenyTools(cfg, {}).sort();
  assert.deepEqual(all, ['memory_note', 'memory_search']);
});

// ---- 阶段 2：配置骨架（新功能开关先注册、功能分批上线）----

test('骨架：每个 config 来源的开关都能在 DEFAULTS 里找到真实字段', () => {
  /**
   * `saveConfig()` 会按 DEFAULTS 的形状裁剪，DEFAULTS 里没有的键一律丢掉。
   * 所以「面板保存成功、下次读又回去了」这类 bug 只能靠这条测试挡：
   * 光在 features.js 写个 path 是不够的，config.js 必须同步登记。
   */
  for (const f of FEATURES) {
    if (f.source !== 'config') continue;
    let cur = DEFAULTS;
    for (const k of f.path) {
      assert.ok(cur !== null && typeof cur === 'object', `${f.id} 的 path ${f.path.join('.')} 指到了非对象`);
      assert.ok(Object.hasOwn(cur, k), `${f.id} 的 path ${f.path.join('.')} 在 DEFAULTS 里没有「${k}」`);
      cur = cur[k];
    }
    if (f.default !== undefined) assert.deepEqual(cur, f.default, `${f.id} 的 DEFAULTS 值要和 default 一致`);
  }
});

test('骨架清零：阶段 5 拆完 staged 后所有开关都该上线且可见', () => {
  /**
   * §11 坑 1 / 门 G5：阶段 5 把最后一个骨架 `extensions` 上线，
   * 这条断言从「还剩 >= 1 个」翻成「必须为空」。三处联动缺一处就红：
   * features.js 去 staged + routes.test.js 清 NOT_SHIPPED + JSON_SECTIONS 补 extensions。
   */
  const staged = FEATURES.filter((f) => f.staged);
  assert.equal(staged.length, 0, `骨架开关必须全上线，还剩 ${staged.map((f) => f.id).join('、')}`);
  assert.deepEqual(visibleFeatures(), FEATURES, '所有开关都该下发到面板');
  assert.ok(visibleFeatures().some((f) => f.id === 'extensions'), '用户扩展开关要能在能力页高级组里找到');
  assert.deepEqual(FEATURES.find((f) => f.id === 'extensions')?.affects, [],
    'extensions 不该收走任何工具（开关只管加载，权限走能力页）');
  // 默认配置下，上线的开关一个工具都不许收走
  assert.deepEqual(forcedDenyTools(DEFAULTS, {}, POOL), []);

  const groups = visibleGroups();
  assert.ok(groups.every((g) => g.ids.length), '空组不该下发');
  const visibleIds = new Set(visibleFeatures().map((f) => f.id));
  for (const g of groups) for (const id of g.ids) assert.ok(visibleIds.has(id), `${id} 不该出现在可见分组里`);
});

test('骨架：字符串枚举 select 能存能取，数字型 select 行为不变', () => {
  const f = featureDef('retentionFactsMode');
  assert.equal(kindOf(f), 'select');
  assert.equal(normalizeSetting(f, 'off'), 'off');
  assert.equal(normalizeSetting(f, 'expire'), 'expire');
  assert.equal(normalizeSetting(f, 'purge'), 'purge');
  assert.equal(normalizeSetting(f, 'PURGE'), null, '大小写不猜，静默写错值比拒绝更糟');
  assert.equal(normalizeSetting(f, ''), null);
  assert.equal(normalizeSetting(f, null), null);
  assert.equal(normalizeSetting(f, 0), null, '数字 0 不该被当成某个枚举');
  assert.deepEqual(patchForFeature('retentionFactsMode', 'expire'), {
    config: { memory: { retention: { factsMode: 'expire' } } },
    value: 'expire',
  });
  /** 两路是独立开关：改 facts 绝不能顺带写 journal */
  assert.deepEqual(patchForFeature('retentionJournalMode', 'purge'), {
    config: { memory: { retention: { journalMode: 'purge' } } },
    value: 'purge',
  });

  // 老的数字型 select（带 options/custom）保持原样
  const numeric = { kind: 'select', options: [{ value: 7 }, { value: 30 }], min: 1, max: 365, custom: true };
  assert.equal(normalizeSetting(numeric, '7'), 7);
  assert.equal(normalizeSetting(numeric, 14), 14, 'custom 允许选项外的整数');
  assert.equal(normalizeSetting(numeric, 'abc'), null);
});

test('骨架：新开关默认值与 DEFAULTS 对齐，裸配置读出来也绝不会误开', () => {
  const on = readFeatures({});
  for (const id of ['moodEffects', 'profiles', 'events', 'extensions']) {
    assert.equal(on[id], false, `${id} 默认必须关`);
  }
  const settings = readSettings({});
  /** 主人 2026-11-08 定：facts 路默认开「作废」，journal 路默认关 */
  assert.equal(settings.retentionFactsMode, 'expire');
  assert.equal(settings.retentionJournalMode, 'off');
  assert.equal(settings.retentionThresholdPct, 5);
  assert.equal(settings.retentionMinProtectDays, 30);
  assert.deepEqual(readSettings(DEFAULTS), settings, 'DEFAULTS 与裸配置的默认值必须一致');
});
