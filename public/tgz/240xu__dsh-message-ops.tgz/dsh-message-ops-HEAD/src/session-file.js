/**
 * dsh-message-ops — 会话文件机制（纯 Node，零 npm 依赖）。
 *
 * DSH 的 JSONL 持久化格式：一份会话日志 = 多个独立 zstd 帧的串联，
 *   帧 0 = 恰好一行 session header JSON（以 \n 结尾，帧带 checksum）
 *   之后每帧 = 一批以 \n 分隔的事件行（NDJSON）
 * 回写 = 重排帧：header 帧 + 事件帧。node:zlib 自 Node 23.5 起暴露
 * zstdCompressSync / zstdDecompressSync，零依赖即可压缩/解压，
 * Windows / Termux / Linux 行为一致。旧格式 session.jsonl.zstd（单帧
 * 整文件）读取走同一帧扫描路径，单帧等效于解压整份。
 * @module dsh-message-ops/session-file
 */

import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { constants, zstdCompressSync, zstdDecompressSync } from "node:zlib";

const ZSTD_MAGIC = 0xfd2fb528;

/** 带语义状态码的操作错误（单点：HTTP 直接映射 status，工具端转失败文本）。 */
export class OpsError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

/** messageText 的「合格 text 段」选择口径（单点）：type==='text' 且非空白。 */
function textSegments(e) {
  const msg = e && e.data && e.data.message;
  const content = msg && Array.isArray(msg.content) ? msg.content : (e && e.data && e.data.content);
  if (!Array.isArray(content)) return [];
  const out = [];
  for (const c of content) {
    if (c && c.type === "text" && typeof c.text === "string" && c.text.trim()) out.push(c.text);
  }
  return out;
}

/** 从 message 事件提取首个非空 text 块（listMessages / ops-core 共用单点）。 */
export function messageText(e) {
  const segs = textSegments(e);
  return segs.length ? segs[0] : "";
}

/**
 * message 事件的**全量** text（/text 路由用单点，别在路由里再造口径）。
 *
 * 宿主把长文本拆成多个 content 段（seq 6830 实测 = 321+7954+20 三段的
 * compaction checkpoint），只取首段 = 摘要被拦腰截断。合并规则与 messageText
 * **同一条口径**：段选择器共用 textSegments（非文本段按 messageText 的规则跳过），
 * 差异只在聚合——全部合格段按 "\\n\\n" 接回（content 段是切块，接缝丢过换行，
 * "\\n\\n" 恰好还原段落边界，也不会把「。」「#」硬粘成一行）。
 */
export function messageTextFull(e) {
  const segs = textSegments(e);
  return segs.join("\n\n");
}

/** 与 DSH 宿主一致：帧带 checksum（ZSTD_c_checksumFlag=1）。 */
function compressFrame(input) {
  return zstdCompressSync(Buffer.from(input, "utf8"), {
    params: { [constants.ZSTD_c_checksumFlag]: 1 },
  });
}

/**
 * 按 RFC 8878 计算一个 zstd 帧的精确结束偏移。
 * 魔数可能出现在压缩载荷内，因此不能用 Buffer.indexOf 定帧界。
 * @returns {{end:number}|{error:'truncated'|'malformed'}}
 */
function zstdFrameEnd(buf, start) {
  if (start + 4 > buf.length || buf.readUInt32LE(start) !== ZSTD_MAGIC) return { error: "malformed" };
  let p = start + 4;
  if (p >= buf.length) return { error: "truncated" };
  const fhd = buf[p++];
  if ((fhd & 0x18) !== 0) return { error: "malformed" };
  const fcsFlag = fhd >> 6;
  const singleSegment = (fhd >> 5) & 1;
  const checksum = (fhd >> 2) & 1;
  const dictFlag = fhd & 3;
  if (!singleSegment) {
    if (p >= buf.length) return { error: "truncated" };
    p += 1;
  }
  const dictSize = [0, 1, 2, 4][dictFlag];
  const fcsSize = fcsFlag === 0 ? (singleSegment ? 1 : 0) : [0, 2, 4, 8][fcsFlag];
  p += dictSize + fcsSize;
  if (p > buf.length) return { error: "truncated" };
  for (;;) {
    if (p + 3 > buf.length) return { error: "truncated" };
    const bh = buf[p] | (buf[p + 1] << 8) | (buf[p + 2] << 16);
    p += 3;
    const last = bh & 1;
    const type = (bh >> 1) & 3;
    const size = bh >>> 3;
    if (type === 3) return { error: "malformed" };
    const payload = type === 1 ? 1 : size;
    if (p + payload > buf.length) return { error: "truncated" };
    p += payload;
    if (last) break;
  }
  if (checksum) {
    if (p + 4 > buf.length) return { error: "truncated" };
    p += 4;
  }
  return { end: p };
}

/**
 * 扫描串联 zstd 流的完整帧边界（不解压块）。
 * 帧界按结构计算，任何非帧字节或畸形帧都 fail-closed。
 * @returns {{frames: {start:number,end:number}[], tornStart?: number}}
 */
export function scanZstdFrames(buf) {
  const frames = [];
  let offset = 0;
  while (offset < buf.length) {
    const start = offset;
    if (buf.length - offset < 4) return { frames, tornStart: start };
    if (buf.readUInt32LE(offset) !== ZSTD_MAGIC) {
      throw new Error(`corrupt zstd session log: invalid frame magic at byte ${offset}`);
    }
    const parsed = zstdFrameEnd(buf, offset);
    if (parsed.error === "truncated") {
      frames.push({ start, end: buf.length });
      return { frames, tornStart: start };
    }
    if (parsed.error) {
      throw new Error(`corrupt zstd session log: malformed frame at byte ${offset}`);
    }
    frames.push({ start, end: parsed.end });
    offset = parsed.end;
  }
  return { frames };
}

/**
 * 逐行解帧：首个 type:"session" 行作 header，其余行作事件。
 * 一条路径同时覆盖两种持久化格式（compat-audit P0）：
 *   - v3 多帧：帧 0 = 恰一行 header，其后每帧一批事件行；
 *   - 旧单帧 session.jsonl.zstd：整个文件一帧，解压出多行 NDJSON，
 *     首行 header、其余事件——旧实现把帧 0 整段 JSON.parse 会直接崩。
 * 撕裂行（JSON.parse 失败）按宿主「完整前缀」语义跳过。
 */
function collectHeaderAndEvents(text, events) {
  let header = null;
  for (const line of text.split("\n")) {
    const t = line.trim();
    if (!t) continue;
    let json;
    try { json = JSON.parse(t); } catch { continue; /* torn record: skip */ }
    if (!header && json && typeof json === "object" && json.type === "session") { header = json; continue; }
    events.push(json);
  }
  return header;
}

/**
 * 读取会话日志 → { header, events }。两种格式（v3 多帧 / 旧单帧）同一条
 * 逐行扫描路径，见 collectHeaderAndEvents。
 */
export function readSessionFile(file) {
  const buf = fs.readFileSync(file);
  const { frames } = scanZstdFrames(buf);
  if (frames.length === 0) throw new Error("empty or header-less session log");
  const events = [];
  let header = null;
  for (const f of frames) {
    const text = zstdDecompressSync(buf.subarray(f.start, f.end)).toString("utf8");
    const found = collectHeaderAndEvents(text, events);
    if (!header) header = found;
  }
  if (!header) throw new Error(`session log ${file}: no {type:"session"} header line in any frame`);
  return { header, events };
}

/** Read only the first zstd frame (header); a damaged body cannot block titles. */
export function readSessionHeader(file) {
  const buf = fs.readFileSync(file);
  if (buf.length < 4 || buf.readUInt32LE(0) !== ZSTD_MAGIC) {
    throw new Error(`session log ${file}: no zstd header frame`);
  }
  const parsed = zstdFrameEnd(buf, 0);
  if (parsed.error) throw new Error(`session log ${file}: ${parsed.error} header frame`);
  const text = zstdDecompressSync(buf.subarray(0, parsed.end)).toString("utf8");
  for (const line of text.split("\n")) {
    const t = line.trim();
    if (!t) continue;
    let json;
    try { json = JSON.parse(t); } catch { continue; }
    if (json && typeof json === "object" && json.type === "session") return json;
  }
  throw new Error(`session log ${file}: no {type:"session"} header line in the first frame`);
}

/** 物化整份日志：header 帧（恰一行）+ 单一事件帧（全部事件行）。 */
export function encodeSessionFile(header, events) {
  const headerText = JSON.stringify(header) + "\n";
  const bodyText = events.map((e) => JSON.stringify(e)).join("\n") + "\n";
  return Buffer.concat([compressFrame(headerText), compressFrame(bodyText)]);
}

/** 会话根目录（尊重 DSH_HOME；Windows/Termux 通吃）。 */
export function sessionsRoot() {
  const home = process.env.DSH_HOME || path.join(os.homedir(), ".dsh");
  return path.join(home, "sessions");
}

const SESSION_ID_RE = /^(session-)?[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function isSessionId(v) {
  return typeof v === "string" && SESSION_ID_RE.test(v);
}

/** 会话 id 的两种拼写（带/不带 session- 前缀）。 */
export function sessionIdVariants(sessionId) {
  const variants = new Set([sessionId]);
  if (sessionId.startsWith("session-")) variants.add(sessionId.slice("session-".length));
  else variants.add(`session-${sessionId}`);
  return [...variants];
}

/**
 * 在 sessions 根下定位会话目录：扫每个 project-slug 目录找 <slug>/<id>/，
 * 避免在插件里重推 workspace 路径编码。
 * @returns {{dir: string, logPath: string}[]}
 */
export function findSessionDirs(sessionId) {
  const root = sessionsRoot();
  let slugs = [];
  try { slugs = fs.readdirSync(root, { withFileTypes: true }); } catch { return []; }
  const variants = sessionIdVariants(sessionId);
  const found = [];
  for (const slug of slugs) {
    if (!slug.isDirectory()) continue;
    for (const variant of variants) {
      const dir = path.join(root, slug.name, variant);
      try {
        if (!fs.statSync(dir).isDirectory()) continue;
      } catch { continue; }
      // 探测序列（用户实测 DSH 已升级 v4 格式）：v4 → v3 → 旧单帧，
      // 高版本优先；文件名与 header.version 对应，读取逻辑三格式同构。
      let logPath = null;
      for (const name of ["session.v4.jsonl.zstd", "session.v3.jsonl.zstd", "session.jsonl.zstd"]) {
        const candidate = path.join(dir, name);
        try { fs.statSync(candidate); logPath = candidate; break; } catch { /* probe next */ }
      }
      if (!logPath) continue;
      if (!found.some((f) => f.dir === dir)) found.push({ dir, logPath });
    }
  }
  return found;
}

/** 新建会话 id（与宿主同款 session-<uuid> 拼写）。 */
export function newSessionId() {
  return `session-${crypto.randomUUID()}`;
}

/** 从事件流提取消息级列表（user/assistant/system message + tool/call 摘要）。 */
/**
 * turn 号 → 该 turn 首/末事件 seq 的映射。
 *
 * 0.9.1：宿主把「回合页脚/过程条/错误」渲染成 node-key 为 `9:turn-tail<turn>` /
 * `12:turn-process<turn>` / `10:turn-error<turn>` 的行 —— 它们的 id 就是 turn 号，
 * 不带 seq。回滚边界落在某个 turn 之后时，这些行也必须一起藏，否则会留下
 * 「孤立的分支/复制按钮」，视觉上像"只回滚了一半"。
 *
 * @returns {{starts: Map<number, number>, ends: Map<number, number>}}
 */
export function turnBounds(events) {
  const starts = new Map();
  const ends = new Map();
  for (const e of events) {
    if (!e || typeof e.seq !== "number") continue;
    const t = e.data && e.data.turn;
    if (!Number.isSafeInteger(t)) continue;
    if (e.type === "turn/start") starts.set(t, e.seq);
    else if (e.type === "turn/end") ends.set(t, e.seq);
  }
  return { starts, ends };
}

export function listMessages(events) {
  const syntheticTurns = new Set();
  for (const e of events) {
    if (e && e.type === "turn/start" && e.data && e.data.reason === "message-ops"
      && Number.isSafeInteger(e.data.turn)) syntheticTurns.add(e.data.turn);
  }
  const messages = [];
  for (const e of events) {
    if (!e || typeof e.seq !== "number") continue;
    if (e.type === "user/message" || e.type === "assistant/message" || e.type === "system/message") {
      const text = messageText(e);
      const msg = e.data && e.data.message;
      // id：宿主持久化的消息身份（user 在 data.id、assistant 在 data.message.id），
      // 供 0.2.0 assistant-actions 槽（ownerProps={messageId}）反查 seq。
      // marker：本事件是 revert/delete 落定的 replace 标记 → 对话框据此提供「恢复」模式。
      const isReplaceMarker = !!(e.surfaceOp && typeof e.surfaceOp === "object" && e.surfaceOp.op === "replace");
      messages.push({
        seq: e.seq,
        type: e.type,
        role: (msg && msg.role) || (e.type === "user/message" ? "user" : e.type === "assistant/message" ? "assistant" : "system"),
        id: (msg && msg.id) || e.data.id || null,
        marker: isReplaceMarker,
        snippet: text.replace(/\s+/g, " ").trim().slice(0, 160),
        // 0.4.0 composer 回填：user 消息携带全文（revert 后 setDraft 原文）
        fullText: e.type === "user/message" ? text : null,
        // 0.4.1 dock：replace 标记携带范围与来源（区分手工回撤 vs compaction）
        range: isReplaceMarker && e.surfaceOp.startSeq != null && e.surfaceOp.endSeq != null
          ? { start: e.surfaceOp.startSeq, end: e.surfaceOp.endSeq } : null,
        sourceKind: (e.data && e.data.source && e.data.source.kind) || null,
        // 0.4.2：恢复标记引用（restore 的 notice 事件带回它所恢复的标记 seq）
        restoresSeq: (e.type === "system/message" && e.data && typeof e.data.restoresSeq === "number")
          ? e.data.restoresSeq : null,
        time: e.time ?? null,
        turn: (e.data && e.data.turn) ?? null,
        syntheticTurn: syntheticTurns.has(e.data && e.data.turn) || undefined,
        // 0.9.1：assistant 节点的宿主 node-key 是 `14:assistant-step<turn>:<step>`，
        // 没有 step 就无法把渲染行映射回日志 seq → 回滚时助手回答藏不掉。
        step: (e.data && e.data.step) ?? null,
      });
    } else if (e.type === "tool/call") {
      const d = e.data || {};
      const name = d.name || (d.call && d.call.name) || "tool";
      messages.push({
        seq: e.seq, type: "tool/call", role: "tool", snippet: `[tool] ${name}`,
        time: e.time ?? null, turn: d.turn ?? null, step: d.step ?? null,
        // 0.9.1：工具节点的宿主 node-key 是 `9:tool-call<callId>`
        id: d.callId ?? null,
      });
    }
  }
  return messages;
}

/**
 * 读取一条 replace surfaceOp 的区间（共用单点，读写端拼写必须一致）。
 * 兼容两种拼写：当前运行时 {op:'replace', startSeq, endSeq} 与
 * dsh-src 较新副本的 {op:'replace', start, end}；其余视为非法返回 null。
 */
export function readReplaceOp(e) {
  const op = e && e.surfaceOp;
  if (!op || typeof op !== "object" || op.op !== "replace") return null;
  const startSeq = Number.isSafeInteger(op.startSeq) ? op.startSeq : op.start;
  const endSeq = Number.isSafeInteger(op.endSeq) ? op.endSeq : op.end;
  if (!Number.isSafeInteger(startSeq) || !Number.isSafeInteger(endSeq)) return null;
  return { startSeq, endSeq };
}

/**
 * 从磁盘事件流推导「被遮蔽」seq 集合：后来发生的 surface replace 事件
 * 遮蔽 [startSeq..endSeq]（append-only：遮蔽仍在日志但不再可见）。
 */
/**
 * marker 的 commit 语义（0.10.1，对齐 opencode）。
 *
 * 用户反馈：「我把消息改完发出去了，恢复弹窗还在，我不知道它让我恢复到哪去」。
 *
 * opencode 的 session.revert 是**单个可清空字段**，不是 marker 列表：
 *   core/src/session/session.ts:165
 *     // Commit a staged revert only after preparation succeeds, before admitting new work.
 *     if (session.revert) yield* SessionRevert.commit(bus, session)
 *   即 **Session.prompt（用户发出下一条消息）时自动 commit**，projector 随后
 *   `DELETE WHERE seq >= boundary.seq` 并把 `revert` 置 null；
 *   UI 侧（app/.../use-session-commands.tsx）只有会灰掉的 undo/redo 命令：
 *     disabled: !actions.session.data.revertMessageID()
 *   —— 它**根本没有常驻弹窗**，状态一清零 affordance 就没意义了。
 *   compact 时同样 commit（session.ts:251）。
 *
 * 我们是 append-only 日志，marker 落盘后永不消失，所以必须自己算「已提交」。
 *
 * 判据 = marker 之后出现**真实用户输入**（`source.kind === 'user'`）。
 * 这是一等字段（全量实测 672 条），三类干扰天然可分、**无需重写 injected 正则**：
 *   - 注入行      → tool-jobs / agent-instructions / runtime-context / skill-catalog
 *                    / subagent-settled / model-selection / team-message …（各 41~172 条）
 *   - 重放副本    → plugin:@240xu/dsh-message-ops（restore 写入）
 *   - 真实输入    → user
 *
 * @param {Array<object>} messages  listMessages 的输出（会被就地打上 committed）
 */
export function markCommitted(messages) {
  const realUserSeqs = [];
  for (const m of messages) {
    if (m && m.type === "user/message" && m.sourceKind === "user") realUserSeqs.push(m.seq);
  }
  for (const m of messages) {
    if (!m || m.marker !== true) continue;
    m.committed = realUserSeqs.some((seq) => seq > m.seq);
  }
  return messages;
}

const MAX_SPAN = 1_000_000;

/**
 * M1 护栏：超 span 上限直接抛（fail loud；与 session-search 同款常量与阈值，
 * 对方仓库不碰、本仓库自行持有常量）。路由层 catch 把 OpsError.status 映射为
 * 404——历史 0.10.x marker 的区间都是个位数，一百万量级只可能来自损坏行或
 * 伪造 marker，不允许把它卡死事件循环。
 */
export function computeShadowed(events) {
  const shadowed = new Set();
  for (const e of events) {
    const range = readReplaceOp(e);
    if (!range) continue;
    // M2′（0.10.9）：反向区间 [start>end] —— 引擎 foldSurface 的替换遮蔽是
    // 「节点索引序重算」（dsh-session/types/surface.js:299-327 replacementRange
    // 用 nodes.indexOf + nodes.slice）。数值方向本身合法，宿主判 clean（语料
    // afcc0453 的 9 个 compact-checkpoint 反向 marker 复演实证，m2-probe）。
    // 磁盘口径下唯一等价的推导源是顶层 sourceEventSeqs（折叠凭据 = 被消费的
    // 原事件序列）；无凭据时无法等价推导，保持旧约定忽略。
    if (range.startSeq > range.endSeq) {
      const src = e.sourceEventSeqs;
      if (!Array.isArray(src)) continue;
      for (const s of src) {
        if (Number.isInteger(s) && s >= 0 && s < e.seq) shadowed.add(s);
      }
      continue;
    }
    if (range.endSeq - range.startSeq > MAX_SPAN) {
      throw new OpsError(
        `surface replace span too large: [${range.startSeq}..${range.endSeq}] exceeds MAX_SPAN=${MAX_SPAN} — refusing to materialize (corrupt or hostile replace marker?)`,
        404,
      );
    }
    for (let s = range.startSeq; s <= range.endSeq; s++) shadowed.add(s);
  }
  return shadowed;
}

const yieldToLoop = () => new Promise((resolve) => setImmediate(resolve));

/**
 * readSessionFile 的异步变体：文件读取走 fs.promises.readFile（线程池，
 * 不阻塞事件循环——10.8MB 同步读是 19ms 的额外阻塞），逐帧解压循环每
 * framesPerYield 帧向事件循环让出一次（setImmediate），避免大日志把 GUI 的
 * tick 卡死数秒。帧边界扫描是原生 indexOf（见 scanZstdFrames，3~6ms）。
 * 真正昂贵的 zstdDecompressSync + JSON.parse 在让出点之间执行。
 * @returns {{header, events, frameCount, partial}}
 *   partial：帧数超过 frameBudget（默认 500）时为 true，调用方应向
 *   用户提示「仅完整读取，无截断，但本次请求耗时可能较长」。
 */
export async function readSessionFileAsync(file, { framesPerYield = 8, frameBudget = 500 } = {}) {
  const buf = await fs.promises.readFile(file);
  const { frames } = scanZstdFrames(buf);
  if (frames.length === 0) throw new Error("empty or header-less session log");
  const events = [];
  let header = null;
  let framesSinceYield = 0;
  for (const f of frames) {
    const text = zstdDecompressSync(buf.subarray(f.start, f.end)).toString("utf8");
    const found = collectHeaderAndEvents(text, events);
    if (!header) header = found;
    if (++framesSinceYield >= framesPerYield) {
      framesSinceYield = 0;
      await yieldToLoop();
    }
  }
  if (!header) throw new Error(`session log ${file}: no {type:"session"} header line in any frame`);
  const bodyFrames = frames.length - 1;
  return { header, events, frameCount: bodyFrames, partial: bodyFrames > frameBudget };
}
