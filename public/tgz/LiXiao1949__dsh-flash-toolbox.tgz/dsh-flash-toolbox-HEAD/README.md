# dsh-flash-toolbox  ·  V1.2

DSH 侧边栏里的**刷机工具箱**：设备信息、软件管理、安装与文件传输、显示控制、系统界面、电池管理、无极调节、控机脚本、Shell 终端，共十个分区。

每一条操作都会真的发到设备上执行，并回报是哪个后端跑的、原始输出是什么。没有模拟数据，也不会把失败显示成成功。

## 平台支持

| 宿主 | 角色 | 说明 |
| --- | --- | --- |
| **Windows 10 / 11** | 控制台 | 复用本机 adb server（5037），手机插 USB 就能操作；也可直连设备的 5555 |
| **macOS / Linux** | 控制台 | 同上，需要本机有在跑的 adb server |
| **Android 手机（DSHBox）** | 控制台 + 本机 | 本机二进制后端只能读 `getprop`/`toybox`/`logcat`；要改系统设置必须走 ADB 或 Root，Shizuku 只放开只读白名单 |

宿主是 Windows 时，「本机二进制」后端会自动标记为不可用 —— 它依赖 `/system/bin/*`，那不是 Windows 该有的东西。

![Windows 下的连接页](preview/ui-connect-windows.jpg)

## 界面

![软件分区](preview/ui-apps.jpg)

深色科技风格，卡片式分区，顶部是实时状态条（后端、机型、SDK），下面是可横向滚动的分区导航。

每个功能名后面有一个**圆形问号**，点一下弹出一个小窗口，写明这个功能具体做什么、用到哪个系统接口、取值范围是多少、失败了会怎样。说明写在功能旁边，不占正文。

气泡是固定定位并按锚点自动翻转（贴近屏幕底部时向上弹），不会被卡片的圆角裁切：

![问号说明气泡](preview/ui-device-help.jpg)

## 分区与功能

### 连接

| 功能 | 做什么 |
| --- | --- |
| 传输方式 | 自动 / **ADB Server**（5037）/ 直连设备（5555） |
| 扫描设备 | `host:devices-l`，列出 adb server 认到的所有设备及其状态 |
| 连接 / 断开 | 建立或释放会话 |
| 后端切换 | ADB / Root / Shizuku / 本机二进制，或交给自动选择 |
| 客户端密钥 | 仅直连设备时需要：首次连接生成 RSA 密钥并存在 profile 的 `.flash-toolbox` 目录 |

**ADB Server（5037）** 是桌面上的默认路径：复用电脑里已经在跑的 adb server，手机插 USB 即被识别，不需要 `adb tcpip`，手机上也不会再弹第二次授权。

**直连设备（5555）** 直接连设备自己的 adbd，适合模拟器、或已经执行过 `adb tcpip 5555` 的手机。

选「自动」时先试 ADB Server，不通再试直连。

### 设备

| 功能 | 做什么 |
| --- | --- |
| 设备与系统 | `getprop` 全量读取，挑出品牌、型号、Android 版本、SDK、安全补丁、ABI、SoC、序列号、指纹、编译类型 |
| CPU 频率 | 逐核读 `cpufreq/scaling_cur_freq`、`scaling_max_freq`、`scaling_governor`，实时条形显示占用 |
| 重置 android_id | 向 `Settings.Secure.android_id` 写入新的 16 位随机值 |
| 重启 / Bootloader / Fastbootd / Recovery / EDL / 关机 | `reboot`、`reboot bootloader`、`reboot fastboot`、`reboot recovery`、`reboot edl`、`reboot -p` |

### 软件

| 功能 | 做什么 |
| --- | --- |
| 软件列表 | `pm list packages`，可筛全部 / 第三方（`-3`）/ 系统（`-s`），带搜索 |
| 前台活动 | `dumpsys activity activities` 解析 `mResumedActivity`，退化为 `dumpsys window` 的 `mCurrentFocus` |
| 启用 / 停用 | `pm enable`、`pm disable-user --user 0` |
| 启动 | `monkey -p 包名 -c android.intent.category.LAUNCHER 1` |
| 强行停止 | `am force-stop` |
| 清除数据 | `pm clear` |
| 软件详情 | `dumpsys package` |
| 恢复系统软件 | `pm install-existing` |
| 卸载锁定 / 解锁 | `cmd package set-user-restriction no_uninstall 包名 true/false` |
| 卸载 / 保留数据卸载 | `pm uninstall`、`pm uninstall -k` |
| 操作记录 | 本次会话的动作时间线，倒序显示 |
| Google 套件批量 | 对 15 个 GMS 核心包批量 `pm enable` / `pm disable-user` |

### 安装

| 功能 | 做什么 |
| --- | --- |
| 安装 APK | 推送到 `/data/local/tmp` 后 `pm install -r`，装完删临时文件 |
| 拆分安装 | 多选时走 `pm install-create` / `install-write` / `install-commit`，用于 App Bundle 分片 |
| 推送文件 | `shell:cat > 路径` 直接写入设备路径 |
| 提取安装包 | `pm path` 找到 `base.apk`，`cp` 到 `/sdcard/Download/包名-时间戳.apk` |

### 显示

| 功能 | 做什么 |
| --- | --- |
| 分辨率 | `wm size 宽x高`，可一键 `wm size reset` |
| 密度 | `wm density DPI`，可 `wm density reset` |
| 按键模拟 | `input keyevent`：HOME / BACK / APP_SWITCH / MENU / ENTER / POWER / WAKEUP / 音量 |
| 截图 | `screencap -p`，ADB 模式下先写临时文件再 base64 拉回，避免二进制走文本通道被截断 |

### 界面

| 功能 | 做什么 |
| --- | --- |
| 状态栏图标 | `settings put secure icon_blacklist`，逗号分隔，留空全部恢复 |
| 时钟 | `clock_seconds` 控制显示秒，`time_12_24` 控制 12/24 小时制 |
| 快捷设置磁贴 | `settings put secure sysui_qs_tiles` |
| 沉浸模式 | `settings put global policy_control immersive.full=*` |
| 网络检测 | 关闭 captive portal 探测与「网络质量差」提示 |

### 电池

| 功能 | 做什么 |
| --- | --- |
| 电池信息 | `dumpsys battery` 解析成电量、状态、健康、电压、温度、AC/USB/无线 |
| 参数模拟 | `dumpsys battery set level/status/ac/usb/wireless`、`unplug`、`reset` |
| 定时统计 | 每 5 秒采样一次，保留 120 条，导出 CSV 做放电曲线 |

### 调节

| 功能 | 做什么 |
| --- | --- |
| 字体大小 | `settings put system font_scale`，0.5 ~ 3.0 |
| 动画倍率 | 窗口 / 过渡 / 属性三个 `animation_scale` 同时设置，或一键归零 |
| 自动锁屏 | `settings put system screen_off_timeout`，秒数换算毫秒 |

### 脚本

| 功能 | 做什么 |
| --- | --- |
| 脚本编辑 | 内置编辑器，支持导入 `.bat`、导出 `.bat` |
| 解释执行 | 自己实现 BAT 子集：`@echo off`、`rem`、`echo`、`set` 与 `%VAR%` 替换、标签与 `goto`、`timeout /t`、`pause`、`exit`；`adb shell …` 行真的发给设备 |
| 执行日志 | 逐行标注 行号 / 类型 / 结果，不支持的语法明确标出，不静默跳过 |

### 终端

| 功能 | 做什么 |
| --- | --- |
| Shell | 直接执行命令，ADB 后端下管道、重定向、通配符全部有效；每条命令标注执行后端与退出码 |

### 关于

![关于页](preview/ui-about.jpg)

| 项 | 内容 |
| --- | --- |
| 开发者 | 李晓 |
| GitHub | [LiXiao1949](https://github.com/LiXiao1949) |
| QQ | 1640444672 |
| 版本 | **V1.2** |

版本号同时写在 `package.json`、`/status` 接口与界面常量里：界面优先读接口，接口不可用时回落到内置常量。

## 后端

功能能不能跑，取决于当前后端：

| 后端 | 权限 | 说明 |
| --- | --- | --- |
| **ADB（TCP）** | 完整 | `pm` / `wm` / `settings` / `am` / `dumpsys` / `screencap` / `reboot` 全部可用 |
| **Root（su）** | 完整 | 设备已 root 且 su 可执行时自动探测 |
| **Shizuku（Pilot）** | 只读 | `getprop` / `dumpsys` / `pm list` / `settings get` / `appops get` / `wm size\|density` / `screencap` |
| **本机二进制** | 只读 | `getprop` / `toybox` / `logcat` 可直接执行 |

选「自动」时按 ADB → Root → Shizuku → 本机二进制 的顺序取最强可用者。

## 接入 ADB

### Windows：插上就能用（推荐）

1. 电脑装好 [platform-tools](https://developer.android.com/tools/releases/platform-tools)，确认 `adb devices` 能看到手机。
2. 手机开「开发者选项 → USB 调试」，插数据线，手机弹窗点「允许」。
3. 工具箱 → 连接 → 传输方式选 **ADB Server** → 「扫描设备」→ 选中设备 → 连接。

`adb devices` 是空的就先跑一次 `adb start-server`（或 `adb kill-server && adb start-server`）再扫描。

### 模拟器 / 真机同网：直连 5555

- **模拟器**：雷电 `127.0.0.1:5555`、MuMu `127.0.0.1:7555`、夜神 `127.0.0.1:62001`，填端口直接连。
- **真机同网**：电脑上执行一次 `adb tcpip 5555`，拔线，填手机 IP + 5555。
- **手机连自身**：开发者选项开「无线调试」，直连 `127.0.0.1:5555`。

首次直连会生成 RSA 密钥并在手机上弹授权框，勾选「始终允许」。签名 RSASSA-PKCS1-v1_5 + SHA1，公钥按 adbd 的 `RSAPublicKey` 结构编码。

### 手机宿主：需要更高权限

手机上的 DSH 里跑这个工具箱时，宿主是普通 app（`uid=10xxx`），碰不到 `pm` / `wm` / `settings`。要真正改系统，按能力从高到低：

| 路径 | 需要什么 |
| --- | --- |
| ADB 直连 | 无线调试或 `adb tcpip`（权限最完整，推荐） |
| Root | 设备已 root，`su -c` 可用 |
| Shizuku | 只读白名单：`getprop` / `dumpsys` / `pm list` / `settings get` / `appops get` / `wm size\|density` |
| 本机二进制 | 不用授权，但只能 `getprop` / `toybox` / `logcat` |

## 目录结构

```
dsh-flash-toolbox/
├── package.json          dsh.bundle.patch + dsh.client.platform=web
├── cordis.patch.yml      插入 dsh-flash-toolbox 这一行 loader entry
├── assets/logo.svg       侧边栏图标
├── lib/
│   ├── index.js          host 半：等 webServer 就位后挂路由
│   ├── routes.js         /dsh-flash-toolbox/api/* 路由
│   ├── http.js           同源/登录校验、JSON 收发
│   ├── adb.js             直连设备的 ADB 客户端（CNXN/AUTH/OPEN/WRTE/CLSE）
│   ├── adb-server.js      本地 adb server 客户端（5037，host:transport + shell）
│   ├── backends.js       后端探测、能力矩阵、统一执行入口
│   ├── features.js       每个功能对应的真实命令
│   └── client.js         浏览器半：十个分区 + 问号说明气泡
└── scripts/
    └── smoke-client.cjs  无浏览器自测
```

## 接口

| 方法 | 路径 | 作用 |
| --- | --- | --- |
| GET | `/status` | 后端快照、设备摘要、ADB 状态 |
| POST | `/connect` `{mode,host,port,serial}` | 建立连接，mode = auto / server / device |
| POST | `/devices` `{host,port}` | 列出 adb server 认到的设备 |
| POST | `/disconnect` | 断开 |
| POST | `/backend` `{id}` | 切换后端 |
| POST | `/exec` `{command,timeoutMs}` | 执行 shell 命令 |
| GET | `/props` · `/cpu` | 系统属性 · CPU 频率 |
| POST | `/reboot` `{mode}` · `/hide-id` | 重启 · 重置 android_id |
| POST | `/packages` `{op,…}` | 列表 / 前台 / 各类 pm 操作 / GMS 批量 |
| POST | `/install` `{files:[{data}]}` · `/push` · `/pull` · `/extract` | 安装、推送、拉取、提取 |
| POST | `/display` `{op,…}` · `/ui` `{op,…}` · `/tune` `{op,…}` · `/battery` `{op,…}` | 各分区操作 |
| POST | `/script` `{source}` | 解释执行 BAT 子集 |
| GET | `/screenshot` | 返回 PNG |

所有接口先过 host 自己的 `connection.requestRejection()`，再校 `Host`、`sec-fetch-site`、`Origin`。

## 自测

```bash
node scripts/smoke-client.cjs   # 或 npm test
```

在 Node 里用假的 `__ModuleLoader__` / `react` / `document` 逐个分区渲染一遍：检查 `apply()` 返回 disposer、三个 slot 注册正确、十个分区都能渲染出内容、每个功能都挂着问号说明。

## 说明

- 所有写入类命令都需要 ADB 或 Root 后端；只有本机二进制时，界面会如实回报「需要 ADB」而不是假装成功。
- 分辨率、DPI、动画倍率改动可能让界面显示异常，每张卡都配了恢复按钮。
- `reboot edl` 只有部分高通机型支持，其余会返回失败原因。
- 安装包、推送文件最大 256 MB。
