// `node scripts/smoke-client.cjs` — load the client bundle outside a browser:
// stub the module loader, react and document, run apply(), then render the page
// once per tab. Catches registration mistakes and render-time ReferenceErrors
// without needing a DOM.
const path = require('node:path')

const bundlePath = process.argv[2] || path.join(__dirname, '..', 'lib', 'client.js')

let loaded = null
global.window = {
  __ModuleLoader__: {
    load(options) {
      loaded = options
    },
  },
  fetch: () => {
    throw new Error('smoke: fetch should not run during render')
  },
  addEventListener: () => {},
  removeEventListener: () => {},
  setInterval: () => 0,
  clearInterval: () => {},
  setTimeout: () => 0,
  innerWidth: 380,
  URL: { createObjectURL: () => '', revokeObjectURL: () => {} },
  Blob: class {},
}

global.document = {
  createElement: () => ({ setAttribute() {}, remove() {}, click() {} }),
  head: { appendChild() {} },
  addEventListener() {},
  removeEventListener() {},
}

const h = (type, props, ...children) => ({ type, props: props || {}, children })
let seed = []
let seedCursor = 0
function nextSeeded(initial) {
  if (seedCursor >= seed.length) return typeof initial === 'function' ? initial() : initial
  const value = seed[seedCursor]
  seedCursor += 1
  return value
}
function expand(node, depth) {
  if (depth > 60 || node === null || node === undefined || typeof node !== 'object') return node
  if (Array.isArray(node)) return node.map((one) => expand(one, depth + 1))
  const { type, props, children } = node
  if (typeof type === 'function') {
    return expand(type(Object.assign({}, props, { children: children.length === 1 ? children[0] : children })), depth + 1)
  }
  return Object.assign({}, node, { children: expand(children, depth + 1) })
}
function collectText(node, out, depth) {
  if (depth > 80) return out
  if (node === null || node === undefined || typeof node === 'boolean') return out
  if (typeof node === 'string' || typeof node === 'number') {
    out.push(String(node))
    return out
  }
  if (Array.isArray(node)) {
    for (const child of node) collectText(child, out, depth + 1)
    return out
  }
  if (typeof node === 'object') collectText(node.children, out, depth + 1)
  return out
}

const React = {
  createElement: h,
  Fragment: 'fragment',
  useState: (initial) => [nextSeeded(initial), () => {}],
  useCallback: (fn) => fn,
  useEffect: () => {},
  useLayoutEffect: () => {},
  useMemo: (fn) => fn(),
  useRef: (value) => ({ current: value }),
}
const requireTable = (name) => {
  if (name === 'react') return React
  throw new Error(`unexpected module request: ${name}`)
}

require(path.resolve(bundlePath))

const problems = []
if (loaded === null) problems.push('bundle never called window.__ModuleLoader__.load')
if (loaded.id !== '@local/dsh-flash-toolbox') problems.push(`unexpected module id: ${loaded.id}`)

const mod = loaded.factory(requireTable)
if (typeof mod.apply !== 'function') problems.push('missing mod.apply')
if (mod.name !== 'dsh-flash-toolbox') problems.push(`unexpected mod.name: ${mod.name}`)

const registrations = []
const injections = []
let dispose = null
const ctx = {
  slots: {
    inject(name, callback) {
      injections.push(name)
      callback()
      return () => {}
    },
    register(spec, component) {
      registrations.push({ spec, component })
      return () => {}
    },
  },
}

let threw = null
try {
  dispose = mod.apply(ctx)
} catch (error) {
  threw = error
}
if (threw !== null) problems.push(`apply() threw: ${threw && threw.stack}`)
if (typeof dispose !== 'function') problems.push('apply() did not return a disposer')

const byName = new Map()
for (const row of registrations) {
  const name = row.spec.name
  if (!byName.has(name)) byName.set(name, [])
  byName.get(name).push(row)
  if (row.spec.id === undefined && row.spec.key === undefined) problems.push(`slot ${name} has neither id nor key`)
  if (name !== 'main' && typeof row.spec.order !== 'number') problems.push(`list slot ${name} has no numeric order`)
  if (typeof row.component !== 'function') problems.push(`slot ${name} has no component function`)
  if (name === 'main' && row.spec.key !== 'dsh-flash-toolbox') problems.push(`main key is ${row.spec.key}`)
  if (name === 'sidebar.panellist' && row.spec.id !== 'dsh-flash-toolbox') problems.push(`panellist id is ${row.spec.id}`)
}
for (const name of ['main', 'sidebar.panellist', 'settings.section']) {
  if (!byName.has(name)) problems.push(`slot ${name} was not registered`)
}

const status = {
  active: 'adb',
  app: { name: '刷机工具箱', version: '1.2.0' },
  backends: [
    { id: 'adb', label: 'ADB（TCP）', connected: true, target: '127.0.0.1:5555', capabilities: 'full', detail: '已连接 127.0.0.1:5555' },
    { id: 'su', label: 'Root（su）', connected: false, capabilities: 'full', detail: '未检测到可用的 su' },
    { id: 'shizuku', label: 'Shizuku（Pilot）', connected: false, capabilities: 'read-only', detail: '未安装 Mobile Pilot' },
    { id: 'local', label: '本机二进制', connected: true, capabilities: 'read-only', detail: 'getprop / toybox / logcat 可直接执行' },
  ],
  device: {
    brand: 'Redmi',
    model: '22127RK46C',
    android: '16',
    sdk: '36',
    abi: 'arm64-v8a',
    serial: 'ABC123',
    fingerprint: 'Redmi/xxx',
  },
  adb: { connected: true, mode: 'server', target: 'server:127.0.0.1:5037/R58M12ABCDE', keyPath: '/root/projects/.dsh/profiles/web/.flash-toolbox/adb_key.pem', server: '127.0.0.1:5037' },
  deviceError: null,
}

const TABS = ['connect', 'home', 'apps', 'files', 'display', 'system', 'battery', 'tune', 'script', 'shell', 'about']
const EXPECT = {
  connect: '连接设备',
  home: '设备与系统',
  apps: '软件列表',
  files: '安装 APK',
  display: '分辨率与密度',
  system: '状态栏图标',
  battery: '电池信息',
  tune: '字体大小',
  script: '控机脚本',
  shell: 'Shell 终端',
  about: '关于',
}

const rendered = []
const mainRow = (byName.get('main') || [])[0]

for (const tabId of TABS) {
  seed = [status, tabId, null, false]
  seedCursor = 0
  try {
    const texts = collectText(expand(mainRow.component({ surface: 'panel' }), 0), [], 0)
    const joined = texts.join(' | ')
    const wanted = EXPECT[tabId]
    if (!joined.includes(wanted)) problems.push(`tab ${tabId} never renders「${wanted}」`)
    if (!joined.includes('?')) problems.push(`tab ${tabId} renders no help dot`)
    if (!joined.includes('刷机工具箱')) problems.push(`tab ${tabId} never shows the headline`)
    if (tabId === 'home' && !joined.includes('22127RK46C')) problems.push('home tab never shows the device model')
    if (tabId === 'connect' && !joined.includes('127.0.0.1:5555')) problems.push('connect tab never shows the adb target')
    if (tabId === 'battery' && joined.includes('获取')) problems.push('battery tab leaked placeholder text')
    if (tabId === 'about') {
      if (!joined.includes('李晓')) problems.push('about tab never shows the developer name')
      if (!joined.includes('LiXiao1949')) problems.push('about tab never shows the github account')
      if (!joined.includes('1640444672')) problems.push('about tab never shows the QQ number')
      if (!joined.includes('V1.2')) problems.push('about tab never shows the version V1.2')
    }
    rendered.push(`${tabId}: ${joined.length} chars, ${(joined.match(/\?/g) || []).length} help marks`)
  } catch (error) {
    problems.push(`rendering tab ${tabId} threw: ${error && error.stack}`)
  }
}

// The settings surface renders the same page.
seed = [status, 'home', null, false]
seedCursor = 0
try {
  const sectionRow = (byName.get('settings.section') || [])[0]
  const texts = collectText(expand(sectionRow.component({}), 0), [], 0)
  if (!texts.join(' ').includes('刷机工具箱')) problems.push('settings surface never renders the headline')
} catch (error) {
  problems.push(`rendering settings surface threw: ${error && error.stack}`)
}

// The sidebar row is just the icon.
try {
  const row = (byName.get('sidebar.panellist') || [])[0]
  const tree = row.component({ size: 16 })
  if (tree === null || tree === undefined) problems.push('sidebar icon rendered nothing')
} catch (error) {
  problems.push(`rendering sidebar icon threw: ${error && error.stack}`)
}

seed = []
seedCursor = 0

console.log('module id      :', loaded.id)
console.log('mod.name       :', mod.name)
console.log('injections     :', injections.join(', '))
console.log(
  'registrations  :',
  registrations.map((row) => `${row.spec.name}#${row.spec.id || row.spec.key}@${row.spec.order}`).join(' | '),
)
console.log('rendered       :')
for (const line of rendered) console.log('  -', line)
console.log(problems.length === 0 ? 'SMOKE OK' : `SMOKE FAILED\n - ${problems.join('\n - ')}`)
process.exit(problems.length === 0 ? 0 : 1)
