import { mkdirSync, readFileSync, writeFileSync } from "node:fs"
import { tmpdir } from "node:os"
import { join } from "node:path"
import { gunzipSync } from "node:zlib"

export const name = "models-dev-reasoning"
export const inject = ["settings"]

const NS = "llm-pi-ai"
const CACHE = join(tmpdir(), "dsh-models-dev-reasoning.json")
const CACHE_MS = 24 * 60 * 60 * 1000
const API_URL = "https://models.dev/api.json"
const TARBALL_URL = "https://api.github.com/repos/anomalyco/models.dev/tarball/dev"
const LABS = ["openai", "anthropic", "xai", "moonshotai", "deepseek"]
const HINTS = [
  ["deepseek", "deepseek"],
  ["claude", "anthropic"],
  ["kimi", "moonshotai"],
  ["grok", "xai"],
  ["gpt", "openai"],
]
const LEVELS = new Set(["off", "minimal", "low", "medium", "high", "xhigh", "max"])
const LAB_FILE = new RegExp(
  `/(?:models/(${LABS.join("|")})|providers/(${LABS.join("|")})/models)/([^/]+)\\.toml$`,
)

function stem(id) {
  return id
    .toLowerCase()
    .replace(/-openai-compact$/, "")
    .replace(/-latest$/, "")
    .replace(/-\d{8}$/, "")
    .split("-")
    .filter((part) => !/^\d{4,}$/.test(part))
    .join("-")
}

export function matchId(localId, ids) {
  const normalized = localId
    .toLowerCase()
    .replace(/-openai-compact$/, "")
    .replace(/-latest$/, "")
  if (ids.includes(normalized)) return normalized
  if (!normalized.includes("-") && !normalized.includes(".")) return
  const localStem = stem(normalized)
  const stemHits = ids.filter((id) => stem(id) === localStem)
  if (stemHits.length === 1) return stemHits[0]
  if (stemHits.includes(normalized)) return normalized
  const prefix = ids.filter((id) => id.startsWith(`${normalized}-`) || id.startsWith(`${normalized}.`))
  if (prefix.length === 1) return prefix[0]
}

function hintedProvider(id) {
  const bare = id.slice(id.lastIndexOf("/") + 1).toLowerCase()
  return HINTS.find(([prefix]) => bare === prefix || bare.startsWith(`${prefix}-`) || bare.startsWith(`${prefix}.`))?.[1]
}

function parseReasoning(toml) {
  const hasReasoning = /^\s*reasoning\s*=/m.test(toml)
  const hasOptions = /reasoning_options/.test(toml) || /type\s*=\s*"(?:toggle|effort|budget_tokens)"/.test(toml)
  if (!hasReasoning && !hasOptions) return
  const efforts = []
  const values = toml.match(/values\s*=\s*\[([^\]]*)\]/)
  if (values) {
    for (const match of values[1].matchAll(/"([^"]+)"/g)) efforts.push(match[1])
  }
  return {
    reasoning: !/^\s*reasoning\s*=\s*false\s*$/m.test(toml),
    toggle: /type\s*=\s*"toggle"/.test(toml),
    efforts,
  }
}

function fromApiEntry(entry) {
  if (entry == null || typeof entry !== "object") return
  const options = Array.isArray(entry.reasoning_options) ? entry.reasoning_options : []
  const efforts = []
  let toggle = false
  for (const option of options) {
    if (option?.type === "toggle") toggle = true
    if (option?.type === "effort" && Array.isArray(option.values)) {
      for (const value of option.values) {
        if (typeof value === "string" && value) efforts.push(value)
      }
    }
  }
  if (entry.reasoning === false && efforts.length === 0 && !toggle) {
    return { reasoning: false, toggle: false, efforts: [] }
  }
  if (entry.reasoning === false && efforts.length === 0 && !toggle && options.length === 0) {
    return { reasoning: false, toggle: false, efforts: [] }
  }
  if (entry.reasoning !== false && (toggle || efforts.length > 0 || entry.reasoning === true)) {
    return { reasoning: true, toggle, efforts }
  }
}

export function toReasoningEfforts(entry) {
  if (!entry) return
  if (!entry.reasoning) return false
  const efforts = [...entry.efforts]
  if (entry.toggle && !efforts.includes("none") && !efforts.includes("off")) efforts.unshift("none")
  if (efforts.length === 0) return
  const mapped = {}
  for (const effort of efforts) {
    const level = effort === "none" ? "off" : effort
    if (!LEVELS.has(level)) continue
    mapped[level] = level === "off" ? null : level
  }
  const keys = Object.keys(mapped)
  if (keys.length === 0) return
  if (keys.length === 1 && keys[0] === "off") return
  return mapped
}

function indexTarGz(buf) {
  const data = gunzipSync(buf)
  const catalog = {}
  const overlays = {}
  let offset = 0
  while (offset + 512 <= data.length) {
    if (data[offset] === 0) break
    const name = data.subarray(offset, offset + 100).toString("utf8").replace(/\0.*$/, "")
    const prefix = data.subarray(offset + 345, offset + 500).toString("utf8").replace(/\0.*$/, "")
    const size = Number.parseInt(data.subarray(offset + 124, offset + 136).toString("utf8").replace(/\0/g, "").trim(), 8) || 0
    const type = String.fromCharCode(data[offset + 156])
    const full = prefix ? `${prefix}/${name}` : name
    offset += 512
    const hit = (type === "0" || type === "\0") && LAB_FILE.exec(full)
    if (hit) {
      const entry = parseReasoning(data.subarray(offset, offset + size).toString("utf8"))
      if (entry) (hit[2] ? overlays : catalog)[`${hit[2] ?? hit[1]}/${hit[3]}`] = entry
    }
    offset += Math.ceil(size / 512) * 512
  }
  return { ...catalog, ...overlays }
}

function indexApiJson(api) {
  const catalog = {}
  for (const [provider, block] of Object.entries(api ?? {})) {
    const models = block?.models
    if (models == null || typeof models !== "object") continue
    for (const [id, entry] of Object.entries(models)) {
      const parsed = fromApiEntry(entry)
      if (parsed) catalog[`${provider}/${id}`] = parsed
    }
  }
  return catalog
}

function lookup(catalog, modelId) {
  const bare = modelId.slice(modelId.lastIndexOf("/") + 1)
  const hinted = hintedProvider(bare)
  const groups = new Map()
  for (const key of Object.keys(catalog)) {
    const slash = key.indexOf("/")
    const provider = key.slice(0, slash)
    const id = key.slice(slash + 1)
    if (!groups.has(provider)) groups.set(provider, [])
    groups.get(provider).push(id)
  }
  const tryProvider = (provider) => {
    const ids = groups.get(provider)
    if (!ids) return
    const hit = matchId(bare, ids)
    return hit ? catalog[`${provider}/${hit}`] : undefined
  }
  if (hinted) {
    const official = tryProvider(hinted)
    if (official) return official
  }
  for (const provider of groups.keys()) {
    if (provider === hinted) continue
    const hit = tryProvider(provider)
    if (hit) return hit
  }
}

async function fetchText(url, ms) {
  const signal = AbortSignal.timeout(ms)
  const res = await fetch(url, {
    signal,
    headers: { "User-Agent": "dsh-models-dev-reasoning" },
  })
  if (!res.ok) throw new Error(`${url} -> ${res.status}`)
  return res
}

async function loadCatalog() {
  try {
    const cached = JSON.parse(readFileSync(CACHE, "utf8"))
    if (Date.now() - cached.fetchedAt < CACHE_MS && cached.catalog && typeof cached.catalog === "object") {
      return cached.catalog
    }
  } catch {
    // miss
  }
  let catalog
  try {
    const res = await fetchText(API_URL, 20_000)
    catalog = indexApiJson(await res.json())
  } catch {
    const res = await fetchText(TARBALL_URL, 60_000)
    catalog = indexTarGz(Buffer.from(await res.arrayBuffer()))
  }
  try {
    writeFileSync(CACHE, JSON.stringify({ fetchedAt: Date.now(), catalog }))
  } catch {
    // cache is optional
  }
  return catalog
}

function modelRow(model, efforts) {
  const row = { id: model.id }
  if (typeof model.name === "string" && model.name && model.name !== model.id) row.name = model.name
  if (efforts !== undefined) row.reasoningEfforts = efforts
  else if (model.reasoningEfforts !== undefined) row.reasoningEfforts = model.reasoningEfforts
  return row
}

async function fill(ctx) {
  const section = ctx.settings.get(NS)
  const providers = section?.providers
  if (providers == null || typeof providers !== "object") return
  const catalog = await loadCatalog()
  const ops = []
  for (const [providerId, provider] of Object.entries(providers)) {
    const models = provider?.models
    if (!Array.isArray(models) || models.length === 0) continue
    let changed = false
    const next = models.map((model) => {
      if (model?.id == null || model.reasoningEfforts !== undefined) return modelRow(model, model?.reasoningEfforts)
      const efforts = toReasoningEfforts(lookup(catalog, String(model.id)))
      if (efforts === undefined) return modelRow(model)
      changed = true
      return modelRow(model, efforts)
    })
    if (changed) ops.push({ op: "set", path: ["providers", providerId, "models"], value: next })
  }
  if (ops.length === 0) return
  await ctx.settings.mutate(NS, ops)
  ctx.logger?.info?.(`${name}: wrote reasoningEfforts for ${ops.length} provider(s)`)
}

export function apply(ctx) {
  ctx.effect(() => {
    let cancelled = false
    const run = async () => {
      for (let i = 0; i < 50 && !cancelled; i++) {
        if (ctx.settings.get(NS) !== undefined) {
          try {
            await fill(ctx)
          } catch (error) {
            ctx.logger?.warn?.(`${name}: ${error instanceof Error ? error.message : String(error)}`)
          }
          return
        }
        await new Promise((resolve) => setTimeout(resolve, 200))
      }
    }
    run()
    return () => {
      cancelled = true
    }
  })
}
