/**
 * dsh-models-dev-reasoning
 *
 * Port of the OpenChamber / OpenCode plugin pair
 * `openai-model-discovery.ts` + `openai-compatible-hermes-variants.ts`:
 *
 * 1. discovery — for every hand-declared `llm-pi-ai` route with a `baseURL`,
 *    call `${baseURL}/models` and merge the offered text models into the
 *    route's `models` list.
 * 2. reasoning — fetch models.dev (24h cache, stale-on-error) and map each
 *    model's `reasoning_options` onto DSH's `reasoningEfforts`
 *    (`{ off: null, low: "low", ... }`), so the model picker offers thinking
 *    levels for models DSH does not describe itself.
 * 3. catalog metadata — fill `contextWindow`, `maxTokens` and image input
 *    from the same catalog for discovered and pre-existing rows.
 *
 * Writes go through `ctx.settings.mutate("llm-pi-ai", ...)`, the same seam
 * `dsh-model-context-catalog` uses, so results persist in the profile patch
 * layer exactly like a manual Models-page edit. Existing values are never
 * overwritten: a field is only filled when the model row leaves it unset.
 *
 * @module dsh-models-dev-reasoning
 */

import fsp from 'node:fs/promises'
import http2 from 'node:http2'
import os from 'node:os'
import path from 'node:path'

export const name = 'models-dev-reasoning'
export const inject = ['settings']

const SETTINGS_NAMESPACE = 'llm-pi-ai'
const CACHE_VERSION = 3
const CATALOG_URL = 'https://models.dev/api.json'
const DEFAULT_TTL_HOURS = 24

/** Levels the llm-pi-ai config schema accepts, in escalation order. */
const THINKING_LEVELS = ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max']

/** Native labs win an id collision in the models.dev catalog index. */
const NATIVE_LABS = new Set([
  'openai', 'anthropic', 'google', 'xai', 'moonshotai', 'moonshotai-cn', 'deepseek',
  'alibaba', 'alibaba-cn', 'zhipuai', 'minimax', 'minimax-cn', 'volcengine', 'tencent-tokenhub',
])

/** Same non-text filter the OpenCode plugin used. */
const NON_TEXT_MODEL = /(?:^|[-_.])(audio|embed(?:ding)?|image|imagine|moderation|rerank|speech|translation|tts|video|whisper)(?:$|[-_.])/i
const INACTIVE_STATUSES = new Set(['shutdown', 'retiring', 'retired', 'deprecated'])

const DEFAULT_CONFIG = Object.freeze({
  discovery: true,
  reasoning: true,
  catalogUrl: CATALOG_URL,
  ttlHours: DEFAULT_TTL_HOURS,
  refreshIntervalHours: 6,
  timeoutMs: 20_000,
  catalogTimeoutMs: 30_000,
  cacheFile: '',
  providers: [],
  transport: 'auto',
  minIntervalMs: 60_000,
  debounceMs: 2_000,
  bootDelayMs: 1_500,
})

function normalizeConfig(raw) {
  const input = raw && typeof raw === 'object' ? raw : {}
  const config = { ...DEFAULT_CONFIG }
  for (const key of ['discovery', 'reasoning']) {
    if (typeof input[key] === 'boolean') config[key] = input[key]
  }
  for (const key of ['catalogUrl', 'cacheFile', 'transport']) {
    if (typeof input[key] === 'string' && input[key].trim()) config[key] = input[key].trim()
  }
  for (const key of ['ttlHours', 'refreshIntervalHours', 'timeoutMs', 'catalogTimeoutMs', 'minIntervalMs', 'debounceMs', 'bootDelayMs']) {
    const value = Number(input[key])
    if (Number.isFinite(value) && value > 0) config[key] = value
  }
  if (Array.isArray(input.providers)) {
    config.providers = input.providers.filter((id) => typeof id === 'string' && id.length > 0)
  }
  return config
}

function dshHome() {
  const fromEnv = process.env.DSH_HOME
  if (typeof fromEnv === 'string' && fromEnv.trim()) return fromEnv.trim()
  return path.join(os.homedir(), '.dsh')
}

function cacheFilePath(config) {
  return config.cacheFile || path.join(dshHome(), 'cache', 'models-dev-reasoning.json')
}

// ── models.dev catalog ──────────────────────────────────────────────────────

function positiveInteger(value) {
  return Number.isSafeInteger(value) && value > 0 ? value : undefined
}

function normalizeInput(modalities) {
  const list = Array.isArray(modalities) ? modalities.filter((item) => item === 'text' || item === 'image') : []
  return list.length > 0 ? list : undefined
}

/**
 * Map a models.dev entry onto DSH `reasoningEfforts`.
 * `false` means "this model does not reason"; `undefined` means the catalog
 * cannot express its toggle-only reasoning with effort levels DSH understands.
 */
function effortsFromModel(model) {
  if (!model || model.reasoning !== true) return false
  const options = Array.isArray(model.reasoning_options) ? model.reasoning_options : []
  const effort = options.find((option) => option && option.type === 'effort' && Array.isArray(option.values))
  if (!effort) return undefined
  const efforts = { off: null }
  for (const value of effort.values) {
    if (value === null || value === undefined) continue
    const level = String(value).toLowerCase()
    if (!THINKING_LEVELS.includes(level) || level === 'off') continue
    efforts[level] = String(value)
  }
  return Object.keys(efforts).length > 1 ? efforts : undefined
}

function catalogEntry(providerId, model) {
  return {
    id: model.id,
    name: typeof model.name === 'string' && model.name ? model.name : model.id,
    provider: providerId,
    native: NATIVE_LABS.has(providerId),
    contextWindow: positiveInteger(model.limit?.context),
    maxTokens: positiveInteger(model.limit?.output),
    input: normalizeInput(model.modalities?.input),
    efforts: effortsFromModel(model),
  }
}

function indexCatalog(json) {
  const entries = []
  for (const [providerId, provider] of Object.entries(json ?? {})) {
    const models = provider?.models
    if (!models || typeof models !== 'object') continue
    for (const model of Object.values(models)) {
      if (!model || typeof model.id !== 'string' || model.id.length === 0) continue
      entries.push(catalogEntry(providerId, model))
    }
  }
  return entries
}

function buildIndex(entries) {
  const byId = new Map()
  for (const entry of entries) {
    const key = entry.id.toLowerCase()
    const previous = byId.get(key)
    if (!previous || (entry.native && !previous.native)) byId.set(key, entry)
  }
  return { byId, ids: [...byId.keys()] }
}

function stem(id) {
  return id
    .toLowerCase()
    .replace(/-openai-compact$/, '')
    .replace(/-latest$/, '')
    .replace(/-(?:\d{8}|\d{6}|\d{4})$/, '')
    .replace(/\./g, '-')
}

/**
 * Ported from `openai-compatible-hermes-variants.ts` `matchId`: exact id
 * first, then conservative alias/date/stem forms. Bare aliases like `grok`
 * are deliberately refused so a short reseller id never matches a random
 * model.
 */
function matchId(localId, index) {
  if (!localId || !index) return undefined
  const exact = index.byId.get(localId.toLowerCase())
  if (exact) return exact
  const normalized = localId.toLowerCase().replace(/-openai-compact$/, '').replace(/-latest$/, '')
  const direct = index.byId.get(normalized)
  if (direct) return direct
  if (!/[-.]/.test(normalized)) return undefined
  const { ids, byId } = index
  const localStem = stem(normalized)
  const equivalent = ids.filter((id) => id.replace(/\./g, '-') === normalized.replace(/\./g, '-'))
  if (equivalent.length === 1) return byId.get(equivalent[0])
  const stemHits = ids.filter((id) => stem(id) === localStem)
  const date = normalized.match(/-(\d{4}|\d{6}|\d{8})$/)?.[1]
  if (date) {
    const dated = stemHits.filter((id) => {
      const other = id.match(/-(\d{4}|\d{6}|\d{8})$/)?.[1]
      if (!other) return false
      return date.length === 4 || other.length === 4
        ? date.slice(-4) === other.slice(-4)
        : date.slice(-6) === other.slice(-6)
    })
    if (dated.length === 1) return byId.get(dated[0])
    const base = stemHits.filter((id) => id.replace(/\./g, '-') === localStem)
    if (base.length === 1) return byId.get(base[0])
  }
  if (stemHits.length === 1) return byId.get(stemHits[0])
  if (stemHits.includes(normalized)) return byId.get(normalized)
  const prefix = ids.filter((id) => id.startsWith(`${normalized}-`) || id.startsWith(`${normalized}.`))
  if (prefix.length === 1) return byId.get(prefix[0])
  return undefined
}

async function readCache(file) {
  try {
    const raw = JSON.parse(await fsp.readFile(file, 'utf8'))
    if (raw?.version !== CACHE_VERSION || !Array.isArray(raw.entries) || raw.entries.length === 0) return undefined
    return raw
  } catch {
    return undefined
  }
}

async function writeCache(file, data) {
  await fsp.mkdir(path.dirname(file), { recursive: true })
  const temporary = `${file}.${process.pid}.tmp`
  await fsp.writeFile(temporary, JSON.stringify(data), 'utf8')
  await fsp.rename(temporary, file)
}

/** Fresh cache → network → stale cache; a failed refresh never throws. */
async function loadCatalog(ctx, config) {
  const file = cacheFilePath(config)
  const cached = await readCache(file)
  if (cached && Date.now() - Number(cached.fetchedAt) < config.ttlHours * 3_600_000) return cached.entries
  try {
    const response = await fetch(config.catalogUrl, {
      headers: { Accept: 'application/json', 'User-Agent': 'dsh-models-dev-reasoning' },
      signal: AbortSignal.timeout(config.catalogTimeoutMs),
    })
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    const entries = indexCatalog(await response.json())
    if (entries.length === 0) throw new Error('catalog contained no models')
    await writeCache(file, { version: CACHE_VERSION, fetchedAt: Date.now(), entries })
    ctx.logger?.info?.(`${name}: refreshed models.dev catalog (${entries.length} models)`)
    return entries
  } catch (error) {
    ctx.logger?.warn?.(`${name}: catalog refresh failed (${error instanceof Error ? error.message : String(error)}); ${cached ? 'using stale cache' : 'reasoning levels unchanged'}`)
    return cached?.entries
  }
}

// ── provider discovery ──────────────────────────────────────────────────────

async function resolveApiKey(ctx, ref) {
  if (typeof ref !== 'string' || ref.length === 0) return undefined
  const credentials = ctx.get?.('credentials')
  if (credentials) {
    try {
      const hit = await credentials.resolve(ref)
      const value = hit?.value ?? hit
      if (typeof value === 'string' && value.length > 0) return value
    } catch {
      // fall through to the ambient environment
    }
  }
  const ambient = process.env[ref]
  return typeof ambient === 'string' && ambient.length > 0 ? ambient : undefined
}

function usableModel(record) {
  if (!record || typeof record.id !== 'string' || record.id.length === 0) return false
  if (NON_TEXT_MODEL.test(record.id)) return false
  if (INACTIVE_STATUSES.has(String(record.status ?? '').toLowerCase())) return false
  const tasks = Array.isArray(record.task_type) ? record.task_type : undefined
  if (tasks && tasks.length > 0 && !tasks.includes('TextGeneration')) return false
  return true
}

function fetchJson(url, headers, timeoutMs) {
  return fetch(url, { headers, signal: AbortSignal.timeout(timeoutMs) }).then(async (response) => {
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    return response.json()
  })
}

/**
 * HTTP/2 GET. Some OpenAI-compatible gateways reset Node's HTTP/1.1 TLS
 * connections (curl and ALPN h2 succeed while `fetch` dies with ECONNRESET),
 * so discovery tries h2 before falling back to fetch.
 */
function http2Json(url, headers, timeoutMs) {
  return new Promise((resolve, reject) => {
    const target = new URL(url)
    if (target.protocol !== 'https:') {
      reject(new Error('http2 transport requires an https URL'))
      return
    }
    const client = http2.connect(target.origin)
    let settled = false
    const finish = (error, value) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      try { client.close() } catch { /* already closed */ }
      if (error) reject(error)
      else resolve(value)
    }
    const timer = setTimeout(() => finish(new Error(`timeout after ${timeoutMs}ms`)), timeoutMs)
    timer.unref?.()
    client.on('error', (error) => finish(error))
    const request = client.request({
      ':method': 'GET',
      ':path': `${target.pathname}${target.search}`,
      ...Object.fromEntries(Object.entries(headers).map(([key, value]) => [key.toLowerCase(), String(value)])),
    })
    let status = 0
    const chunks = []
    request.on('response', (responseHeaders) => { status = Number(responseHeaders[':status']) })
    request.on('data', (chunk) => chunks.push(chunk))
    request.on('end', () => {
      if (status < 200 || status >= 300) {
        finish(new Error(`HTTP ${status}`))
        return
      }
      try {
        finish(undefined, JSON.parse(Buffer.concat(chunks).toString('utf8')))
      } catch (error) {
        finish(error)
      }
    })
    request.on('error', (error) => finish(error))
    request.end()
  })
}

async function requestJson(url, headers, timeoutMs, transport = 'auto') {
  if (transport === 'http2' || (transport === 'auto' && /^https:/i.test(url))) {
    try {
      return await http2Json(url, headers, timeoutMs)
    } catch (error) {
      if (transport === 'http2') throw error
    }
  }
  return fetchJson(url, headers, timeoutMs)
}

/** GET `${baseURL}/models`; [] when the route has no resolvable key. */
async function fetchProviderModels(ctx, providerId, profile, config) {
  const baseURL = String(profile.baseURL ?? '').replace(/\/+$/, '')
  if (!/^https?:/i.test(baseURL)) return []
  const headers = { ...(profile.headers ?? {}) }
  const hasAuthorization = Object.keys(headers).some((key) => key.toLowerCase() === 'authorization')
  if (!hasAuthorization) {
    const key = await resolveApiKey(ctx, profile.apiKeyEnv)
    if (!key) {
      ctx.logger?.info?.(`${name}: ${providerId} has no resolvable apiKeyEnv; skipping discovery`)
      return []
    }
    headers.Authorization = `Bearer ${key}`
  }
  const body = await requestJson(`${baseURL}/models`, headers, config.timeoutMs, config.transport)
  const records = Array.isArray(body) ? body : body?.data
  if (!Array.isArray(records)) throw new Error('response is not a model list')
  return records.filter(usableModel).map((record) => ({
    id: record.id,
    name: typeof record.name === 'string' && record.name ? record.name : record.id,
    contextWindow: positiveInteger(record.token_limits?.context_window)
      ?? positiveInteger(record.context_window)
      ?? positiveInteger(record.context_length)
      ?? positiveInteger(record.max_input_tokens),
    maxTokens: positiveInteger(record.token_limits?.max_output_token_length)
      ?? positiveInteger(record.max_output_tokens),
    input: normalizeInput(record.modalities?.input_modalities),
  }))
}

/** A configured `models[]` entry for a discovered model. */
function entryFromDiscovered(record, catalog) {
  const entry = { id: record.id, name: catalog?.name ?? record.name ?? record.id }
  const contextWindow = catalog?.contextWindow ?? record.contextWindow
  if (contextWindow) entry.contextWindow = contextWindow
  const maxTokens = catalog?.maxTokens ?? record.maxTokens
  if (maxTokens) entry.maxTokens = maxTokens
  const input = catalog?.input ?? record.input
  if (input?.length) entry.input = [...input]
  entry.reasoningEfforts = catalog?.efforts ?? false
  return entry
}

/** Fill only the fields an existing row leaves unset. */
function enrichExisting(entry, record, catalog) {
  const next = { ...entry }
  if (next.contextWindow === undefined) {
    const value = catalog?.contextWindow ?? record?.contextWindow
    if (value) next.contextWindow = value
  }
  if (next.maxTokens === undefined) {
    const value = catalog?.maxTokens ?? record?.maxTokens
    if (value) next.maxTokens = value
  }
  if (!next.input?.length) {
    const value = catalog?.input ?? record?.input
    if (value?.length) next.input = [...value]
  }
  if (next.reasoningEfforts === undefined && catalog?.efforts) next.reasoningEfforts = catalog.efforts
  return next
}

// ── settings reconciliation ─────────────────────────────────────────────────

function findDescriptor(ctx) {
  const descriptors = ctx.settings.describe({ redactSecrets: true })
  return Array.isArray(descriptors)
    ? descriptors.find((descriptor) => String(descriptor?.ns) === SETTINGS_NAMESPACE)
    : undefined
}

function sameModels(left, right) {
  return JSON.stringify(left) === JSON.stringify(right)
}

async function planProviders(ctx, config, providers, catalogIndex) {
  const operations = []
  for (const [providerId, profile] of Object.entries(providers ?? {})) {
    if (!profile || typeof profile !== 'object' || Array.isArray(profile)) continue
    if (config.providers.length > 0 && !config.providers.includes(providerId)) continue
    if (profile.modelOverrides && Object.keys(profile.modelOverrides).length > 0) {
      ctx.logger?.info?.(`${name}: ${providerId} declares modelOverrides; leaving it untouched`)
      continue
    }
    const configured = Array.isArray(profile.models) ? profile.models : []
    const api = String(profile.api ?? '')
    const canDiscover = config.discovery && (api === '' || /openai/i.test(api))
    const discovered = canDiscover
      ? await fetchProviderModels(ctx, providerId, profile, config).catch((error) => {
        ctx.logger?.warn?.(`${name}: discovery failed for ${providerId} (${error instanceof Error ? error.message : String(error)}); keeping existing models`)
        return []
      })
      : []
    if (configured.length === 0 && discovered.length === 0) continue

    const next = configured.map((entry) => ({ ...entry }))
    const order = new Map()
    next.forEach((entry, index) => order.set(String(entry.id).toLowerCase(), index))

    for (const record of discovered) {
      const key = record.id.toLowerCase()
      const catalog = catalogIndex ? matchId(record.id, catalogIndex) : undefined
      const index = order.get(key)
      if (index === undefined) {
        order.set(key, next.length)
        next.push(entryFromDiscovered(record, catalog))
      } else {
        next[index] = enrichExisting(next[index], record, catalog)
      }
    }

    if (catalogIndex) {
      for (let index = 0; index < next.length; index += 1) {
        const entry = next[index]
        if (!entry || typeof entry.id !== 'string' || entry.id.length === 0) continue
        const catalog = matchId(entry.id, catalogIndex)
        if (catalog) next[index] = enrichExisting(entry, undefined, catalog)
      }
    }

    if (!sameModels(configured, next)) {
      operations.push({ op: 'set', path: ['providers', providerId, 'models'], value: next })
    }
  }
  return operations
}

async function commitOperations(ctx, operations) {
  if (operations.length === 0) return false
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const descriptor = findDescriptor(ctx)
    if (!descriptor) {
      ctx.logger?.warn?.(`${name}: llm-pi-ai settings namespace is unavailable`)
      return false
    }
    try {
      await ctx.settings.mutate(SETTINGS_NAMESPACE, operations, descriptor.revision)
      return true
    } catch (error) {
      if (error?.code === 'SETTINGS_CONFLICT') continue
      throw error
    }
  }
  ctx.logger?.warn?.(`${name}: settings kept changing; giving up this round`)
  return false
}

/** One full pass: catalog → discovery → reasoning → settings mutate. */
async function reconcile(ctx, config) {
  const descriptor = findDescriptor(ctx)
  if (!descriptor) {
    ctx.logger?.warn?.(`${name}: llm-pi-ai settings namespace is unavailable`)
    return false
  }
  const providers = descriptor.value?.providers
  if (!providers || typeof providers !== 'object') return false

  const catalog = config.reasoning ? await loadCatalog(ctx, config) : undefined
  const catalogIndex = catalog ? buildIndex(catalog) : undefined
  const operations = await planProviders(ctx, config, providers, catalogIndex)
  const changed = await commitOperations(ctx, operations)
  if (changed) ctx.logger?.info?.(`${name}: updated ${operations.length} provider model list(s)`)
  return changed
}

// ── plugin entry ────────────────────────────────────────────────────────────

export function apply(ctx, rawConfig) {
  const config = normalizeConfig(rawConfig)
  let queue = Promise.resolve()
  let debounceTimer
  let bootTimer
  let intervalTimer
  let lastWriteAt = 0
  let lastRunAt = 0

  const run = (reason, force = false) => {
    queue = queue.then(async () => {
      if (!force && lastRunAt !== 0 && Date.now() - lastRunAt < config.minIntervalMs) return
      lastRunAt = Date.now()
      try {
        const changed = await reconcile(ctx, config)
        if (changed) lastWriteAt = Date.now()
      } catch (error) {
        ctx.logger?.warn?.(`${name}: reconcile failed (${reason}): ${error instanceof Error ? error.message : String(error)}`)
      }
    })
  }

  const schedule = (reason) => {
    if (debounceTimer) clearTimeout(debounceTimer)
    debounceTimer = setTimeout(() => run(reason), config.debounceMs)
    debounceTimer.unref?.()
  }

  const stopDocument = ctx.on('settings/document-updated', (namespace) => {
    if (String(namespace) !== SETTINGS_NAMESPACE) return
    // Ignore the echo of our own write to avoid a discovery round trip.
    if (Date.now() - lastWriteAt < 5_000) return
    schedule('settings')
  })
  const stopVolatile = ctx.on('loader/volatile-update', () => schedule('volatile'), { global: true })
  const stopReload = ctx.on('app-boot/config-reload', () => schedule('reload'))

  const boot = async () => {
    for (let attempt = 0; attempt < 30; attempt += 1) {
      if (findDescriptor(ctx)) break
      await new Promise((resolve) => setTimeout(resolve, 500))
    }
    run('boot', true)
  }

  bootTimer = setTimeout(() => {
    boot().catch((error) => ctx.logger?.warn?.(`${name}: boot failed: ${error instanceof Error ? error.message : String(error)}`))
  }, config.bootDelayMs)
  bootTimer.unref?.()
  intervalTimer = setInterval(() => schedule('timer'), config.refreshIntervalHours * 3_600_000)
  intervalTimer.unref?.()

  ctx.effect(() => () => {
    if (debounceTimer) clearTimeout(debounceTimer)
    if (bootTimer) clearTimeout(bootTimer)
    if (intervalTimer) clearInterval(intervalTimer)
    stopDocument?.()
    stopVolatile?.()
    stopReload?.()
  })
}

/** Internal hooks for the offline test harness; not part of the plugin API. */
export const internals = {
  effortsFromModel,
  indexCatalog,
  buildIndex,
  matchId,
  entryFromDiscovered,
  enrichExisting,
  normalizeConfig,
  usableModel,
  requestJson,
  reconcile,
}
