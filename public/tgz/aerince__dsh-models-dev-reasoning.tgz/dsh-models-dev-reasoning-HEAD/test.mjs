/**
 * Offline verification for index.js: no DSH, no network.
 * Run: node test.mjs
 */
import assert from 'node:assert/strict'
import path from 'node:path'
import { internals } from './index.js'

const cacheFile = path.join(process.env.TEMP ?? '.', `dsh-mmr-test-${process.pid}.json`)
const catalogUrl = 'https://catalog.test/api.json'
const providerUrl = 'https://provider.test/v1'

const catalog = {
  deepseek: {
    id: 'deepseek',
    models: {
      'deepseek-v4-pro': {
        id: 'deepseek-v4-pro',
        name: 'DeepSeek V4 Pro',
        reasoning: true,
        reasoning_options: [{ type: 'effort', values: [null, 'low', 'high', 'max'] }],
        limit: { context: 256000, output: 65536 },
        modalities: { input: ['text'] },
      },
    },
  },
  openai: {
    id: 'openai',
    models: {
      'gpt-5.6': {
        id: 'gpt-5.6',
        name: 'GPT-5.6',
        reasoning: true,
        reasoning_options: [{ type: 'effort', values: ['low', 'medium', 'high'] }],
        limit: { context: 400000, output: 128000 },
        modalities: { input: ['text', 'image'] },
      },
      'text-embedding-3': {
        id: 'text-embedding-3',
        reasoning: false,
        modalities: { input: ['text'] },
      },
    },
  },
  qwen: {
    id: 'qwen',
    models: {
      'qwen3-toggle': {
        id: 'qwen3-toggle',
        reasoning: true,
        reasoning_options: [{ type: 'toggle' }],
      },
    },
  },
}

const providerModels = {
  data: [
    { id: 'deepseek-v4-pro-0901' },
    { id: 'gpt-5.6' },
    { id: 'custom-plain' },
    { id: 'text-embedding-3' },
    { id: 'speech-tts-1' },
    { id: 'retired-model', status: 'retired' },
  ],
}

const fetchCalls = []
globalThis.fetch = async (url, options = {}) => {
  fetchCalls.push(String(url))
  if (String(url) === catalogUrl) {
    return new Response(JSON.stringify(catalog), { status: 200, headers: { 'content-type': 'application/json' } })
  }
  if (String(url) === `${providerUrl}/models`) {
    assert.equal(options.headers?.Authorization, 'Bearer test-key', 'discovery must send the resolved key')
    return new Response(JSON.stringify(providerModels), { status: 200, headers: { 'content-type': 'application/json' } })
  }
  throw new Error(`unexpected fetch ${url}`)
}

let revision = 1
let section = {
  providers: {
    reseller: {
      baseURL: providerUrl,
      apiKeyEnv: 'TEST_KEY',
      api: 'openai-responses',
      models: [
        { id: 'gpt-5.6', name: 'GPT-5.6', contextWindow: 111 },
        { id: 'custom-plain', name: 'Custom Plain', reasoningEfforts: false },
      ],
    },
  },
}

const ctx = {
  logger: { info() {}, warn() {} },
  settings: {
    describe: () => [{ ns: 'llm-pi-ai', revision, value: structuredClone(section) }],
    mutate: async (ns, ops) => {
      assert.equal(ns, 'llm-pi-ai')
      for (const op of ops) {
        assert.equal(op.op, 'set')
        const [root, providerId, field] = op.path
        section[root][providerId][field] = structuredClone(op.value)
      }
      revision += 1
    },
  },
  get: (service) => (service === 'credentials' ? { resolve: async () => ({ value: 'test-key' }) } : undefined),
}

const config = internals.normalizeConfig({
  catalogUrl,
  cacheFile,
  transport: 'fetch',
  debounceMs: 10,
  bootDelayMs: 10,
})

const changed = await internals.reconcile(ctx, config)
assert.equal(changed, true, 'first reconcile must write')

const models = section.providers.reseller.models
const byId = Object.fromEntries(models.map((model) => [model.id, model]))

assert.ok(byId['deepseek-v4-pro-0901'], 'discovered model added through stem matching')
assert.deepEqual(byId['deepseek-v4-pro-0901'].reasoningEfforts, { off: null, low: 'low', high: 'high', max: 'max' })
assert.equal(byId['deepseek-v4-pro-0901'].contextWindow, 256000)
assert.equal(byId['deepseek-v4-pro-0901'].maxTokens, 65536)

assert.equal(byId['gpt-5.6'].contextWindow, 111, 'explicit contextWindow is preserved')
assert.deepEqual(byId['gpt-5.6'].reasoningEfforts, { off: null, low: 'low', medium: 'medium', high: 'high' })
assert.deepEqual(byId['gpt-5.6'].input, ['text', 'image'])

assert.equal(byId['custom-plain'].reasoningEfforts, false, 'explicit false is preserved')

assert.ok(!byId['text-embedding-3'], 'embedding models are filtered')
assert.ok(!byId['speech-tts-1'], 'speech models are filtered')
assert.ok(!byId['retired-model'], 'retired models are filtered')

const before = JSON.stringify(section)
const second = await internals.reconcile(ctx, config)
assert.equal(second, false, 'second reconcile is a no-op')
assert.equal(JSON.stringify(section), before, 'no settings write when nothing changed')

assert.equal(internals.effortsFromModel(catalog.qwen.models['qwen3-toggle']), undefined, 'toggle-only reasoning is not mapped')
assert.equal(internals.effortsFromModel(catalog.deepseek.models['deepseek-v4-pro']).max, 'max')
assert.equal(internals.effortsFromModel({ reasoning: false }), false)
assert.equal(internals.matchId('gpt-5.6', internals.buildIndex(internals.indexCatalog(catalog))).name, 'GPT-5.6')

assert.ok(fetchCalls.includes(catalogUrl), 'catalog fetched once')
console.log('ok — discovery, matching, reasoning mapping, and idempotency verified')
