/**
 * jsdom smoke test for the browser half (lib/client.js).
 * Run: npm run test:smoke  (needs the jsdom devDependency)
 */
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import vm from 'node:vm'
import { JSDOM } from 'jsdom'

const bundle = await readFile(new URL('../lib/client.js', import.meta.url), 'utf8')
const SETTINGS_KEY = 'dsh.whale-font.settings.v1'

function createHarness(html, storedSettings) {
  const dom = new JSDOM(`<!doctype html><body>${html}</body>`, {
    url: 'http://localhost/',
    pretendToBeVisual: true,
    runScripts: 'outside-only',
  })
  const { window } = dom
  if (storedSettings !== undefined) {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(storedSettings))
  }

  let factory
  window.__ModuleLoader__ = {
    load({ id, factory: bundleFactory }) {
      if (id !== 'dsh-whale-font') throw new Error(`unexpected plugin id ${id}`)
      factory = bundleFactory
    },
  }
  vm.runInContext(bundle, dom.getInternalVMContext(), { filename: 'dsh-whale-font.client.js' })
  assert.ok(factory, 'bundle registered its factory')

  const react = {
    createElement: () => ({ $$typeof: Symbol.for('react.element'), type: 'div', props: {} }),
    useEffect: () => {},
    useRef: () => ({ current: null }),
  }
  const plugin = factory((spec) => {
    if (spec === 'react') return react
    throw new Error(`unexpected require(${JSON.stringify(spec)})`)
  })
  assert.equal(plugin.name, 'dsh-whale-font')
  assert.equal(plugin.inject.join(','), 'slots')

  const registrations = []
  const ctx = {
    effect(callback) {
      this.cleanup = callback()
    },
    slots: {
      inject(_slot, callback) {
        this.slotCallback = callback
      },
      register(options, component) {
        registrations.push({ options, component })
        return () => {}
      },
    },
  }
  plugin.apply(ctx)
  assert.ok(ctx.cleanup, 'whale engine started and returned cleanup')
  ctx.slots.slotCallback()
  assert.equal(registrations.length, 1, 'one slot registration')
  assert.equal(registrations[0].options.name, 'settings.section')
  assert.equal(registrations[0].options.id, 'whale-font')

  return { window, dom }
}

// Case 1: new-DOM assistant row — I/me become whale icons; style covers both
// new and old selectors; 我 stays as text for the font layer.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>我是助手，I am me。</p></div>
    </div>`)
  const style = window.document.querySelector('style[data-whale-font]')
  assert.ok(style, 'whale style injected')
  assert.match(style.textContent, /unicode-range:U\+6211/, 'WhaleWo covers 我')
  assert.match(style.textContent, /unicode-range:U\+4F60/, 'WhaleNi covers 你')
  assert.match(style.textContent, /data-chat-flow-kind="assistant-step"/, 'new assistant selector in style')
  assert.match(style.textContent, /\.Sxvs8a_root/, 'old assistant selector also present')
  assert.match(style.textContent, /\.gdEzaW_bubble/, 'old user selector also present')
  const p = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 2, 'I and me replaced by whale icons')
  assert.ok(p.textContent.includes('我'), '我 stays as text for the font layer')
  dom.window.close()
}

// Case 2: quoted 我/你 get base-font spans; user-row 你 outside quotes stays text.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>他说“我是我”。</p></div>
      <div data-chat-flow-kind="user"><p>你说“你”吧。</p></div>
    </div>`)
  const quoted = window.document.querySelectorAll('[data-whale-quoted="1"]')
  assert.equal(quoted.length, 3, 'quoted 我/你 wrapped with base font (2 我 + 1 你)')
  const assistant = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  assert.equal(assistant.querySelectorAll('[data-whale-i="1"]').length, 0, 'no icons in quoted-only text')
  dom.window.close()
}

// Case 3: code blocks and content outside any message row are untouched.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step">
        <p>我</p>
        <pre>I am me 我</pre>
      </div>
    </div>
    <div><p>我 I me</p></div>`)
  const icons = window.document.querySelectorAll('[data-whale-i="1"]')
  assert.equal(icons.length, 0, 'no icons outside assistant prose')
  const pre = window.document.querySelector('pre')
  assert.equal(pre.querySelectorAll('[data-whale-i="1"]').length, 0, 'code block untouched')
  const outside = window.document.querySelector('body > div:last-child p')
  assert.equal(outside.textContent, '我 I me', 'outside scope untouched')
  dom.window.close()
}

// Case 4: old-DOM rows (Sxvs8a_ assistant / gdEzaW_ user classes) still work.
{
  const { window, dom } = createHarness(`
    <div class="Sxvs8a_root"><p>我是助手，I am me。</p></div>
    <div class="gdEzaW_bubble"><p>你是用户。</p></div>`)
  const p = window.document.querySelector('.Sxvs8a_root p')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 2, 'old assistant row: I/me icons')
  assert.ok(p.textContent.includes('我'), 'old assistant row: 我 stays text')
  const userP = window.document.querySelector('.gdEzaW_bubble p')
  assert.ok(userP.textContent.includes('你'), 'old user row: 你 stays text for the font layer')
  dom.window.close()
}

// Case 5: cjkFont off — no whale font style, no quote wrapping, I/me icons still work.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>他说“我是我”，I am me fine。</p></div>
    </div>`, { cjkFont: false })
  const style = window.document.querySelector('style[data-whale-font]')
  assert.equal(style, null, 'no whale font style when cjkFont off')
  const quoted = window.document.querySelectorAll('[data-whale-quoted="1"]')
  assert.equal(quoted.length, 0, 'no quote wrapping when the font layer is off')
  const p = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 2, 'I/me icons still work when cjkFont off')
  assert.ok(p.textContent.includes('我'), '我 stays plain text when cjkFont off')
  dom.window.close()
}

// Case 6: extra words become icons outside quotes; quoted occurrences stay text.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>DeepSeek 帮助我，他说“DeepSeek 帮助”。</p></div>
    </div>`, { assistantWords: ['DeepSeek', '帮助'] })
  const p = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  const icons = p.querySelectorAll('[data-whale-i="1"]')
  assert.equal(icons.length, 2, 'extra words outside quotes become icons (DeepSeek, 帮助)')
  assert.ok(p.textContent.includes('我'), '我 stays as text')
  assert.ok(p.textContent.includes('“DeepSeek 帮助”'), 'quoted extra words stay as text')
  dom.window.close()
}

// Case 7: quote pair split across two text nodes — quoted 我 still protected,
// unquoted 我 untouched by the DOM layer.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>他说“我</p><p>是”我。</p></div>
    </div>`)
  const first = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p:first-child')
  const second = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p:last-child')
  assert.equal(first.querySelectorAll('[data-whale-quoted="1"]').length, 1, 'quoted 我 wrapped despite split nodes')
  assert.equal(second.querySelectorAll('[data-whale-quoted="1"]').length, 0, '是 and unquoted 我 not wrapped')
  assert.equal(second.textContent, '是”我。', 'unquoted text preserved')
  dom.window.close()
}

// Case 8: quoted I/me and quoted extra word are never iconified.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>他说“I am me expend”。</p></div>
    </div>`, { assistantWords: ['expend'] })
  const p = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 0, 'quoted I/me/expend stay as text')
  assert.ok(p.textContent.includes('“I am me expend”'), 'quoted content preserved verbatim')
  dom.window.close()
}

// Case 9: code blocks never get icons or quote wraps, extra words included.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step">
        <p>expend 我。</p>
        <pre>expend “我” I me</pre>
      </div>
    </div>`, { assistantWords: ['expend'] })
  const pre = window.document.querySelector('pre')
  assert.equal(pre.querySelectorAll('[data-whale-i="1"]').length, 0, 'code block: no icons')
  assert.equal(pre.querySelectorAll('[data-whale-quoted="1"]').length, 0, 'code block: no quote wraps')
  assert.equal(pre.textContent, 'expend “我” I me', 'code block preserved verbatim')
  const p = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 1, 'outside code: extra word still becomes an icon')
  dom.window.close()
}

// Case 10: streaming mutation re-processes with fresh pairing and settles.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>我 I</p></div>
    </div>`)
  const p = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 1, 'initial: I becomes an icon')
  // simulate streaming: the row content is replaced with a quote split across nodes
  p.replaceChildren(window.document.createTextNode('他说“我'), window.document.createTextNode('是”我。'))
  await new Promise((resolve) => setTimeout(resolve, 80))
  assert.equal(p.querySelectorAll('[data-whale-quoted="1"]').length, 1, 'streamed quoted 我 wrapped')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 0, 'no icons inside/after the quote')
  await new Promise((resolve) => setTimeout(resolve, 80))
  assert.equal(p.querySelectorAll('[data-whale-quoted="1"]').length, 1, 'idempotent after settling (no runaway loop)')
  dom.window.close()
}

// Case 11: brackets protect content by default (（）、【】、[]、{}).
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>（我）【us】[I] {me} 我 us</p></div>
    </div>`, { assistantWords: ['us'] })
  const p = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 1, 'only the trailing unquoted us becomes an icon')
  assert.equal(p.querySelectorAll('[data-whale-quoted="1"]').length, 1, 'bracketed 我 gets the base-font wrap')
  assert.ok(p.textContent.includes('【us】[I] {me}'), 'bracketed words preserved verbatim')
  dom.window.close()
}

// Case 12: brackets setting off → bracketed words are replaced again.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>（我）[I]（us）</p></div>
    </div>`, { assistantWords: ['us', 'I'], brackets: false })
  const p = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 2, 'I and us inside brackets replaced when brackets off')
  assert.equal(p.querySelectorAll('[data-whale-quoted="1"]').length, 0, 'no bracket protection when off')
  dom.window.close()
}

// Case 13: nested brackets protect inner content; quote + bracket interaction.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>（（我）说）us 我</p></div>
    </div>`, { assistantWords: ['us'] })
  const p = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  assert.equal(p.querySelectorAll('[data-whale-quoted="1"]').length, 1, 'nested bracketed 我 wrapped once')
  assert.equal(p.querySelectorAll('[data-whale-i="1"]').length, 1, 'us outside brackets becomes an icon')
  dom.window.close()
}

// Case 14: assistant words and user words apply only in their own rows.
{
  const { window, dom } = createHarness(`
    <div data-chat-flow>
      <div data-chat-flow-kind="assistant-step"><p>us Deepseek 我</p></div>
      <div data-chat-flow-kind="user"><p>us Deepseek 你</p></div>
    </div>`, { assistantWords: ['us'], userWords: ['Deepseek'] })
  const assistant = window.document.querySelector('[data-chat-flow-kind="assistant-step"] p')
  const user = window.document.querySelector('[data-chat-flow-kind="user"] p')
  assert.equal(assistant.querySelectorAll('[data-whale-i="1"]').length, 1, 'assistant row: us (assistant word) becomes an icon')
  assert.equal(user.querySelectorAll('[data-whale-i="1"]').length, 1, 'user row: Deepseek (user word) becomes an icon')
  dom.window.close()
}

console.log('smoke: ok')
