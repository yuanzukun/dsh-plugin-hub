/**
 * Host loader entry for the dsh-timer-agent plugin — the host-authoritative
 * engine (hermes-agent cron shape): a 60s in-process ticker that fires due
 * jobs through the real agent registry (GUI open or not), a file-backed
 * ledger at ~/.dsh/timer-agent/jobs.json, the `timer_agent` model tool so
 * any conversation can create/manage jobs, and /api/dsh-timer-agent routes
 * the web UI reads and writes through.
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type {} from '@deepseek-ai/dsh-system-prompt'
import type { HostPluginContext } from './host/contracts.ts'
import { HostJobStore } from './host/store.ts'
import { TimerRunner } from './host/runner.ts'
import { registerTimerTool } from './host/tools.ts'
import { makeRoutes } from './host/routes.ts'

/** Order of the announcement section within the tool-guidance band. */
const SECTION_ORDER = 201

/** Plugin name: used for logs, diagnostics, and Fiber identity. */
export const name = 'dsh-timer-agent'

export const inject = ['webServer', 'tools', 'systemPrompt', 'agents']

/** Model-facing announcement: plugin presence, capabilities, and limits. */
export const TIMER_AGENT_GUIDANCE = '本机已安装 dsh-timer-agent 插件（DSH 定时任务引擎，host 常驻，参考 hermes-agent cron）：60 秒 ticker 在 dsh web 服务进程内常驻运行，dsh web 服务启动即生效（GUI 页面关闭也照常触发）。任务台账存于 ~/.dsh/timer-agent/jobs.json。任务分两类：kind=agent（默认，AI Agent 任务）到点通过真实 agent 会话执行 prompt；kind=command（普通任务）不经过 AI，直接 spawn command+args 执行脚本，不消耗 API 额度。任务支持 5 段 cron（如 0 9 * * *）；agent 任务可指定项目 workdir（任务会话在该目录运行并加载其 AGENTS.md）、可指定已有会话 session（每次触发继续该对话，具备上下文连续性）；两者都留空则每次触发在默认工作空间新建会话发起新对话；command 任务只需标题、命令、参数与定时器（workdir 作为进程工作目录，超时同样生效，退出码非 0 记为失败并保留输出尾部）。对话中可用 timer_agent 工具直接 create/list/update/pause/resume/remove/run 定时任务（create/update 支持 kind/command/args 参数）；Web GUI 侧边栏「定时任务」面板管理同一批任务。定时执行无人在场，agent 任务的 prompt 必须自包含、不可提问。用户提到「定时任务 / 定时器 / cron」时即指本插件，请据此协作。'

/** Plugin config, declared to the loader by the same-named schemastery schema. */
export interface Config {
  /** When true (default), a system-prompt section announces the plugin. */
  announceToAgent?: boolean
  /** Master switch for the plugin (ticker + tool + routes). */
  enabled?: boolean
}

export const Config: z<Config> = z.object({
  announceToAgent: z.boolean().default(true),
  enabled: z.boolean().default(true),
})

/** Schema default, re-read for hand-built test contexts. */
const DEFAULT_ANNOUNCE = true

/**
 * Mount the engine: ticker + runner, tool, routes, announcement.
 * @param ctx - host plugin context (webServer/tools/systemPrompt/agents).
 * @param config - the loader entry's Config, declared by the exported
 *   `Config` schema and injected by cordis (dsh 0.2.0+: the SettingsForms
 *   service projects plugin Config schemas straight from profile entries —
 *   no runtime section registration, and a config edit reloads this fiber).
 */
export function apply(ctx: Context, config?: Config): void {
  const host = ctx as unknown as HostPluginContext
  const cfg: Config = config ?? {}
  let disposeEngine: (() => void) | undefined
  let disposeTool: (() => void) | undefined
  let disposeSection: (() => void) | undefined

  const sync = (): void => {
    for (const dispose of [disposeEngine, disposeTool, disposeSection]) dispose?.()
    disposeEngine = undefined
    disposeTool = undefined
    disposeSection = undefined
    if ((cfg.enabled ?? true) === false) return

    const store = new HostJobStore()
    const runner = new TimerRunner({ ctx: host, store })
    runner.start()

    disposeTool = ctx.effect(() => registerTimerTool(ctx.tools!, {
      store,
      runner,
      now: () => Date.now(),
    }), 'dsh-timer-agent: tool')

    const routes = makeRoutes({ store, runner, ctx: host, now: () => Date.now() })
    disposeEngine = () => {
      void runner.dispose()
      for (const route of routes) void route
    }
    const disposeRoutes = ctx.effect(() => {
      const disposers = routes.map(route => ctx.webServer.register(route))
      return () => { for (const dispose of disposers) dispose() }
    }, 'dsh-timer-agent: routes')
    // Routes unregister with the engine (single teardown path).
    const engineTeardown = disposeEngine
    disposeEngine = () => {
      engineTeardown()
      disposeRoutes()
    }

    if ((cfg.announceToAgent ?? DEFAULT_ANNOUNCE) === true) {
      disposeSection = ctx.systemPrompt.section({
        name: 'plugin:timer-agent',
        order: SECTION_ORDER,
        text: TIMER_AGENT_GUIDANCE,
      })
    }
  }

  sync()
}
