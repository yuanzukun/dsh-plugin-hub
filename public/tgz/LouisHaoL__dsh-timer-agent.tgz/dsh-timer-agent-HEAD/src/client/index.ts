/**
 * Timer-agent client plugin (host-authoritative edition): mounts the two
 * DOM surfaces over the REMOTE controller — the sidebar entry row and the
 * board view in the center column. All state lives in the host engine
 * (~/.dsh/timer-agent/jobs.json); this half is a polled mirror + HTTP
 * command sender. The scheduler/execution core the browser used to own is
 * retired: the dsh web host process ticks and fires jobs with or without
 * this page open.
 *
 * Failure policy: DOM mounting problems are logged, never thrown — the web
 * shell fails the whole boot when a plugin apply throws, and an external
 * plugin must not take the GUI down.
 */
import { RemoteBoardController } from './remote-controller.ts'
import { sessionsFaceOf, type SessionsServiceShape } from './sessions-face.ts'
import { mountBoard } from './board-mount.tsx'
import { mountSidebarEntry } from './sidebar-entry.ts'
import { listTargetOptions } from './target-options.ts'

/** Required services (fiber inject waiting — the runtime must be up first). */
export const inject = ['slots', 'sessions']

/**
 * Mount the timer-agent board.
 * @param ctx - client root context (services: sessions).
 */
export function apply(ctx: unknown): void {
  // Resolve the sessions SERVICE once through the inject declaration. The
  // ctx object is a Cordis proxy where only `inject` names resolve — reading
  // service members (list/open/refresh) straight off it throws "cannot get
  // property ... without inject", and an eager read at apply time fails the
  // whole web boot. Everything downstream works on the plain service object.
  const ctxTyped = ctx as { sessions?: SessionsServiceShape }
  const sessions = ctxTyped.sessions

  // Fallback when sessions service is missing (e.g., when dsh-web plugin is removed)
  const sessionsFace = sessions !== undefined
    ? sessionsFaceOf(sessions)
    : {
        list: {
          getSnapshot: () => ({ current: undefined }),
          subscribe: () => () => {},
        },
        open: (_id: string) => {
          console.warn('[dsh-timer-agent] sessions.open called but sessions service is unavailable')
        },
      }

  const controller = new RemoteBoardController(sessionsFace)
  controller.start()

  const disposers: Array<() => void> = []
  try {
    // Session-target dropdown data source: rebuilt on each modal open.
    const targetOptions = (): ReturnType<typeof listTargetOptions> => {
      try {
        return listTargetOptions(ctx as never)
      } catch (error) {
        console.warn('[dsh-timer-agent] target-options failed, returning empty:', error)
        return Promise.resolve([])
      }
    }
    disposers.push(mountSidebarEntry(controller))
    disposers.push(mountBoard(controller, targetOptions))
  } catch (error) {
    // DOM failures degrade the board, never the GUI.
    console.error('[dsh-timer-agent] mount failed:', error)
  }

  // Teardown: Cordis effect when available (client runtime), otherwise direct disposal.
  const effectFn = (ctxTyped as { effect?(setup: () => () => void, key: string): unknown }).effect
  if (typeof effectFn === 'function') {
    effectFn(() => {
      return () => {
        for (const dispose of disposers.splice(0)) dispose()
        controller.dispose()
      }
    }, 'dsh-timer-agent: unmount')
  }
}
