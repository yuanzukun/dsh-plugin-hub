import type { SourceConfig, SyncProgress } from '../types.js';
import type { IngestorResult, RawFeedItem } from './types.js';
export declare function getSourceDisplayName(source: SourceConfig): string;
export declare class IngestorManager {
    private configPath;
    private sources;
    constructor(configPath: string);
    getSources(): SourceConfig[];
    loadOrCreateSources(): SourceConfig[];
    /**
     * Fetch a single source by configuration.
     */
    fetchSource(config: SourceConfig): Promise<IngestorResult>;
    /**
     * Fetch all enabled sources concurrently with total error isolation.
     */
    syncAll(filterSourceIds?: string[], onProgress?: (progress: SyncProgress) => void): Promise<{
        items: RawFeedItem[];
        results: IngestorResult[];
    }>;
}
//# sourceMappingURL=manager.d.ts.map