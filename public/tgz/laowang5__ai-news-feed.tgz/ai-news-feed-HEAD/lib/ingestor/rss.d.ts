import type { SourceConfig } from '../types.js';
import type { IngestorResult } from './types.js';
/**
 * Universal RSS / Atom feed fetcher.
 * Handles timeouts, error isolation, per-source truncation.
 */
export declare function fetchRssFeed(config: SourceConfig): Promise<IngestorResult>;
//# sourceMappingURL=rss.d.ts.map