export interface DigestChild {
    title: string;
    url: string;
    section: string;
    published_at: string;
    parent_digest: string;
}
/**
 * Format a timestamp into YYYY-MM-DD in Asia/Shanghai (CST).
 * Returns '' if an explicit invalid value is provided.
 */
export declare function toLocalDateString(input?: string | number | Date): string;
/**
 * Unpack an AIHot daily digest HTML description into individual child news items.
 * Rules (§2.2):
 * 1. Scan <p> and <li> in order; <p> updates current section (default '未分类').
 * 2. Each <li> produces a DigestChild with tag-stripped collapsed title and first <a href> absolute URL.
 * 3. Skip <li> without <a>.
 * 4. Return [] if HTML contains no <li> (caller falls back to keeping only parent digest).
 * 5. Deduplicate by title within the same digest (keep first).
 */
export declare function parseDigestItems(html: string, guid: string, pubDate: string): DigestChild[];
//# sourceMappingURL=aihot-digest.d.ts.map