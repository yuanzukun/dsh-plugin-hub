import type { SourceConfig } from '../types.js';
import type { IngestorResult } from './types.js';
export declare function fetchHackerNews(config: SourceConfig): Promise<IngestorResult>;
//# sourceMappingURL=hn.d.ts.map