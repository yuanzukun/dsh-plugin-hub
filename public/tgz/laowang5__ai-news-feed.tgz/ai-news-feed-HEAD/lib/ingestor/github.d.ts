import type { SourceConfig } from '../types.js';
import type { IngestorResult } from './types.js';
export declare function fetchGitHubReleases(config: SourceConfig): Promise<IngestorResult>;
//# sourceMappingURL=github.d.ts.map