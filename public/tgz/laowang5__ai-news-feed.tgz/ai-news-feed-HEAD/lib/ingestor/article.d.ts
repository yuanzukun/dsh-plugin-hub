/**
 * Extract readable article text from HTML with priority:
 * og:description -> <article>/<main> -> meta[name=description], picking first >= 200 chars.
 * When both og:description and <article>/<main> are >= 200 chars, combines them so full body text is preserved.
 */
export declare function extractContentFromHtml(html: string, minChars?: number): string;
export interface FetchArticleOptions {
    timeoutMs?: number;
    retries?: number;
    fetchImpl?: typeof fetch;
}
/**
 * Fetch an article URL and extract clean text content.
 * Retries once on failure/timeout and silently returns '' without throwing.
 */
export declare function fetchArticleContent(url: string, opts?: FetchArticleOptions): Promise<string>;
//# sourceMappingURL=article.d.ts.map