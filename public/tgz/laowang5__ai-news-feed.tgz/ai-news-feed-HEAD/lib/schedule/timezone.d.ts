/**
 * Resolves system IANA time zone with fallback to Asia/Shanghai.
 */
export declare function resolveTimeZone(customTz?: string): string;
//# sourceMappingURL=timezone.d.ts.map