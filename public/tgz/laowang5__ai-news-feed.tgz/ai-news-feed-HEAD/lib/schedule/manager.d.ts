import { type BriefingKind } from './prompt.js';
export declare const TITLE_MORNING = "ai-news-feed:briefing:morning";
export declare const TITLE_EVENING = "ai-news-feed:briefing:evening";
export declare const TITLE_PREFIX = "ai-news-feed:briefing:";
export interface EnableBriefingOptions {
    morning?: string;
    evening?: string;
    timeZone?: string;
}
export interface BriefingTaskSummary {
    id: string;
    kind: BriefingKind;
    title: string;
    time: string;
    timeZone: string;
}
export declare class ScheduleManager {
    private ctx;
    constructor(ctx: any);
    private getScheduleService;
    isAvailable(): boolean;
    /**
     * Helper to query tasks for a given sessionId across different method signatures.
     */
    private listSessionTasks;
    /**
     * Helper to create or update a single briefing task with compare-and-set and conflict retry.
     */
    private upsertTask;
    /**
     * Enable morning & evening briefings for a session (Path A).
     */
    enableBriefing(sessionId: string, options?: EnableBriefingOptions): Promise<{
        success: boolean;
        timeZone: string;
        tasks: BriefingTaskSummary[];
        error?: undefined;
        message?: undefined;
    } | {
        success: boolean;
        error: string;
        message: any;
        timeZone?: undefined;
        tasks?: undefined;
    }>;
    /**
     * Disable briefings for a session and delete scheduled tasks to unblock session archiving.
     */
    disableBriefing(sessionId: string): Promise<{
        success: boolean;
        error: string;
        message: string;
        deletedCount?: undefined;
    } | {
        success: boolean;
        deletedCount: number;
        error?: undefined;
        message?: undefined;
    }>;
}
//# sourceMappingURL=manager.d.ts.map