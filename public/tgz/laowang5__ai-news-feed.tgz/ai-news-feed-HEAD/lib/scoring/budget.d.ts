import type { BudgetSnapshot } from '../types.js';
export interface BudgetRecord {
    date: string;
    calls: number;
    items: number;
    exhausted_at?: string | null;
}
export declare function getLocalDateString(d?: Date): string;
export declare class BudgetTracker {
    private filePath;
    private dailyLimit;
    private state;
    constructor(filePath: string, dailyLimit?: number);
    private loadOrCreate;
    private checkMidnightReset;
    private saveDirect;
    canSpend(cost?: number): boolean;
    recordSpend(calls?: number, items?: number): void;
    getSnapshot(): BudgetSnapshot;
    setLimit(limit: number): void;
    /**
     * For testing purpose: simulates date change across midnight.
     */
    _simulateDateChange(dateStr: string): void;
}
//# sourceMappingURL=budget.d.ts.map