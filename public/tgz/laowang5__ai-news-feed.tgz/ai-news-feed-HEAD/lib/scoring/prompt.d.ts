/**
 * Converts a date string to Beijing Time (+08:00) ISO8601 string.
 * Unknown or invalid dates fallback to "未知（收录时间不代表发布时间）".
 */
export declare function formatToBeijingTime(dateStr?: string): string;
/**
 * Builds the user prompt input for scoring.
 * Strict constraint: ONLY contains 发布时间, 标题, 正文.
 * Must NOT leak source id, name, source_type, tier, old scores, thresholds, or tags.
 */
export declare function buildScoreInput(item: {
    title: string;
    raw_content?: string | null;
    summary?: string;
    published_at?: string;
}): string;
//# sourceMappingURL=prompt.d.ts.map