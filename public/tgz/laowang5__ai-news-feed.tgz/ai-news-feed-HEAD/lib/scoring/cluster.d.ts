import type { SignalItem } from '../types.js';
export interface MergePair {
    primaryId: number;
    mergedIds: number[];
}
/**
 * Cluster same-day cross-source items representing the same event (zero LLM calls).
 */
export declare function clusterSignals(items: SignalItem[]): MergePair[];
//# sourceMappingURL=cluster.d.ts.map