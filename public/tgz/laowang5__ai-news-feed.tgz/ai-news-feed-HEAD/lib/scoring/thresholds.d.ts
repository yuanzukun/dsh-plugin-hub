export interface Thresholds {
    featuredMinScore: number;
    sTierScore: number;
    browseMinScore: number;
}
export declare const DEFAULT_THRESHOLDS: Thresholds;
export declare function resolveThresholds(input?: Partial<Thresholds>): {
    thresholds: Thresholds;
    error?: 'invalid_thresholds';
};
export declare function resolveFeaturedMaxItems(input?: number): number;
//# sourceMappingURL=thresholds.d.ts.map