import type { Thresholds } from './thresholds.js';
import type { DisplayLanguage } from '../types.js';
export interface WriteCopyOptions {
    mean: number;
    thresholds: Thresholds;
    /** Language the summary must be written in. Defaults to 'zh'. */
    lang?: DisplayLanguage;
}
export declare function getWordCountTarget(score: number): {
    min: number;
    max: number;
    label: string;
};
export interface WriteCopyOutput {
    summary: string;
    tags: string[];
    title_zh: string | null;
    title_en: string | null;
    why_it_matters: string | null;
}
/**
 * Generates a summary in the configured language, localized titles, a "why it matters"
 * one-liner, and topic tags.
 *
 * Summaries are NOT bilingual on purpose: the copy is written in `opts.lang`, so one
 * generation already matches the reader's language and costs half the output tokens.
 * Only the titles are dual (title_zh / title_en) because a Chinese source item has no
 * English title to fall back to.
 *
 * Only executes if mean >= thresholds.browseMinScore.
 */
export declare function writeCopy(item: {
    title: string;
    summary?: string;
    raw_content?: string | null;
}, opts: WriteCopyOptions, callLlm: (systemPrompt: string, userPrompt: string) => Promise<string | null>): Promise<WriteCopyOutput | null>;
//# sourceMappingURL=write.d.ts.map