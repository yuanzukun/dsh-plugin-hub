export declare const TOPICS: readonly [{
    readonly id: "agent-infra";
    readonly label: "Agent 基建";
}, {
    readonly id: "model-release";
    readonly label: "模型发布";
}, {
    readonly id: "open-source";
    readonly label: "开源工具";
}, {
    readonly id: "business";
    readonly label: "融资与商业";
}];
export type TopicId = (typeof TOPICS)[number]['id'];
export declare const DEFAULT_TOPICS: TopicId[];
/**
 * Resolve configured topics. Defaults to ['agent-infra', 'model-release'] when undefined.
 * Preserves [] when user explicitly disables all topics.
 */
export declare function resolveTopics(topics?: string[] | null): TopicId[];
export declare function getTopicLabel(topicId: string): string | null;
/**
 * Compute capped post-hoc boost: min(5, matchedCount * 3).
 * Returns 0 when activeTopics is empty.
 */
export declare function computeTopicBoost(topicMatch?: string[], activeTopics?: string[]): number;
//# sourceMappingURL=topics.d.ts.map