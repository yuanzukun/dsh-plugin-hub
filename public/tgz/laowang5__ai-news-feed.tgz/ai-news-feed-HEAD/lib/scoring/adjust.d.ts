export declare const SOURCE_WEIGHTS: {
    readonly tier_a: 1.15;
    readonly tier_b: 1;
    readonly tier_c: 0.75;
    readonly default: 0.9;
};
export type SourceTier = keyof typeof SOURCE_WEIGHTS;
export declare function sourceWeight(tier?: string | null): number;
export declare const FOLLOW_UP_PENALTY = -15;
export interface AdjustScoreResult {
    adjusted: number;
    base_adjusted: number;
    source_weight: number;
    tracking_penalty: number;
    topic_boost: number;
    is_s_tier: boolean;
}
/**
 * Adjusts the mean score with tracking penalty, source weight, and capped topic boost.
 * Formula:
 *   base_adjusted = clamp(0, 100, Math.round((mean + penalty) * weight))
 *   adjusted = clamp(0, 100, base_adjusted + topic_boost)
 *   is_s_tier = base_adjusted >= sTierScore (strictly pre-boost per §5.3)
 */
export declare function adjustScore(mean: number, opts?: {
    tier?: string | null;
    isFollowUp?: boolean;
    topicMatch?: string[];
    activeTopics?: string[];
    sTierScore?: number;
}): AdjustScoreResult;
//# sourceMappingURL=adjust.d.ts.map