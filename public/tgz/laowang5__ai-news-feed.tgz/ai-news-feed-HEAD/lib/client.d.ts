/**
 * Client-side Web UI extension for DeepSeek Harness (DSH).
 * Provides a Medium-Density AI News Feed sidebar drawer & composer entry.
 * Follows specs defined in docs/spec/v0.1-spec.md and docs/spec/v0.9-experience-fixes.md.
 */
export {};
//# sourceMappingURL=client.d.ts.map