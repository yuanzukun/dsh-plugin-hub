import type { PluginConfig, FeedHealthSnapshot } from './types.js';
import { JsonStore } from './store/json-store.js';
import { IngestorManager } from './ingestor/manager.js';
import { NewsEvaluator } from './evaluator/evaluator.js';
import { BudgetTracker } from './scoring/budget.js';
import { ScheduleManager } from './schedule/manager.js';
export declare const name = "ai-news-feed";
export declare const inject: string[];
export declare function resolveDataDir(_ctx: any, config: PluginConfig): string;
export declare function apply(ctx: any, config?: PluginConfig): {
    store: JsonStore;
    ingestor: IngestorManager;
    evaluator: NewsEvaluator;
    budgetTracker: BudgetTracker;
    scheduleManager: ScheduleManager;
    runSync: (options?: {
        sources?: string[];
        forceScore?: boolean;
        skipIngest?: boolean;
    }) => Promise<{
        accepted: boolean;
        reason: string;
        run_id?: undefined;
        timestamp?: undefined;
    } | {
        accepted: boolean;
        run_id: string;
        timestamp: string;
        reason?: undefined;
    }>;
    waitForSync: () => Promise<void>;
    getHealthSnapshot: () => FeedHealthSnapshot;
};
//# sourceMappingURL=index.d.ts.map