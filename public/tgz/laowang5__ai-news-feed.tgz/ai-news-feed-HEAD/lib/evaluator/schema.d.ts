import { z } from 'zod';
export declare const ScoreOnlySchema: z.ZodObject<{
    score: z.ZodNumber;
    topic_match: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export type ScoreOnly = z.infer<typeof ScoreOnlySchema>;
export declare const CopywritingSchema: z.ZodObject<{
    summary: z.ZodString;
    tags: z.ZodDefault<z.ZodArray<z.ZodString>>;
    title_zh: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    title_en: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    why_it_matters: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
export type CopywritingResult = z.infer<typeof CopywritingSchema>;
//# sourceMappingURL=schema.d.ts.map