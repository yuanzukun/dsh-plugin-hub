import type { SignalItem, SourceConfig } from '../types.js';
import { type Thresholds } from '../scoring/thresholds.js';
export interface EvaluatorOptions {
    ctx?: any;
    llmBaseUrl?: string;
    llmApiKey?: string;
    llmModel?: string;
    llmProvider?: string;
    llmTimeoutMs?: number;
    maxScoresPerRun?: number;
    scoreCalls?: number;
    thresholds?: Partial<Thresholds>;
    sourcesMap?: Map<string, SourceConfig>;
}
/**
 * How the evaluator reaches a model. `host-stream` drives the DSH LLM runtime
 * (no user configuration required), `host-call` is the legacy
 * `ctx.llm.call()` shape some older hosts exposed, `fetch` posts straight to an
 * OpenAI-compatible endpoint, and `none` means scoring cannot run at all.
 */
export type LlmBackend = 'host-stream' | 'host-call' | 'fetch' | 'none';
/** Last failure observed by {@link NewsEvaluator}, surfaced through health. */
export interface LlmDiagnostics {
    backend: LlmBackend;
    route?: {
        provider: string;
        model: string;
    };
    last_error?: string;
    last_error_at?: string;
    failed_calls: number;
    ok_calls: number;
}
export interface EvaluatedBatchItem {
    url_key: string;
    rawScores: number[];
    mean: number;
    adjusted: number;
    source_weight: number;
    tracking_penalty: number;
    is_s_tier: boolean;
    prompt_version: string;
    status: 'scored';
}
export declare const DEFAULT_MAX_SCORES_PER_RUN = 10;
export declare class NewsEvaluator {
    private ctx?;
    private llmBaseUrl?;
    private llmApiKey?;
    private llmModel?;
    private llmProvider?;
    private maxScoresPerRun;
    private scoreCalls;
    private llmTimeoutMs;
    private thresholds;
    private sourcesMap;
    private diagnostics;
    /** Resolved host route, cached after the first successful resolution. */
    private routeCache?;
    constructor(options?: EvaluatorOptions);
    getMaxScoresPerRun(): number;
    private getLlmService;
    /** The host service that owns the user's selected default model, if any. */
    private getDefaultModelService;
    /**
     * Pick the transport that can actually run. The host `llm` service is a
     * streaming runtime (`prepareCall` + `stream`); it never exposed `call()`, so
     * probing only for the service's existence reported "available" while every
     * score silently failed.
     */
    getBackend(): LlmBackend;
    isAvailable(): boolean;
    getDiagnostics(): LlmDiagnostics;
    private recordFailure;
    /**
     * Resolve the exact provider/model route to call on the host runtime.
     * Preference: explicit config, then the host's default model selection, then
     * the single registered provider's own model list.
     */
    private resolveRoute;
    private listProviderModels;
    private findProviderForModel;
    /** Call the DSH LLM runtime through its real streaming API. */
    private callHostStream;
    getThresholds(): Thresholds;
    setSourcesMap(map: Map<string, SourceConfig>): void;
    evaluateItem(item: {
        title: string;
        summary?: string;
        raw_content?: string | null;
        source?: string;
    }): Promise<EvaluatedBatchItem | null>;
    /**
     * Invokes LLM with system prompt (rubric) and user prompt.
     */
    callLlmRaw(systemPrompt: string, userPrompt: string): Promise<string | null>;
    private callWithBackend;
    /** POST straight to an OpenAI-compatible `/chat/completions` endpoint. */
    private callFetch;
    /**
     * Evaluates an item by making scoreCalls serial requests, returning raw scores + matched topic IDs.
     * If ANY call fails, returns null (cannot use partial results).
     */
    scoreItemDetailed(item: {
        title: string;
        raw_content?: string | null;
        summary?: string;
        published_at?: string;
    }, rubricText: string, opts?: {
        scoreCalls?: number;
    }): Promise<{
        rawScores: number[];
        topicMatch: string[];
    } | null>;
    /**
     * Evaluates an item by making scoreCalls serial requests.
     * If ANY call fails, returns null (cannot use partial results).
     */
    scoreItem(item: {
        title: string;
        raw_content?: string | null;
        summary?: string;
        published_at?: string;
    }, rubricText: string, opts?: {
        scoreCalls?: number;
    }): Promise<number[] | null>;
    /**
     * Processes a batch of pending items up to maxScoresPerRun.
     */
    evaluateBatch(pendingItems: SignalItem[], opts?: {
        scoreCalls?: number;
        rubricCwd?: string;
        isFollowUp?: boolean;
    }): Promise<EvaluatedBatchItem[]>;
}
//# sourceMappingURL=evaluator.d.ts.map