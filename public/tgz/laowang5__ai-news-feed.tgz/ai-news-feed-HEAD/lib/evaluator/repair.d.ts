import { type CopywritingResult } from './schema.js';
export interface ParsedScoreResult {
    score: number;
    topic_match: string[];
}
/**
 * Attempts to repair and validate malformed JSON strings returned by LLMs for score + optional topic_match.
 */
export declare function repairAndParseScoreResult(raw: string): ParsedScoreResult | null;
/**
 * Attempts to repair and validate malformed JSON strings returned by LLMs for score only.
 * Removes markdown code fences, trailing commas, extracts core JSON, normalizes 0-10 -> 0-100 if needed.
 */
export declare function repairAndParseScore(raw: string): number | null;
/**
 * Parses copywriting result { summary, tags, title_zh, title_en, why_it_matters }
 * Also supports standalone `WHY: <one sentence>` lines per spec §6.
 */
export declare function repairAndParseCopy(raw: string): CopywritingResult | null;
/**
 * Backward compatibility helper for combined evaluation.
 */
export declare function repairAndParseEvaluation(raw: string): {
    score: number;
    summary: string;
    tags: string[];
} | null;
//# sourceMappingURL=repair.d.ts.map