import type { SignalItem } from '../types.js';
/** Detect digest / multi-news aggregation posts that should not compete in single-item S-tier rankings. */
export declare function isDigestItem(item: {
    source?: string;
    source_type?: string;
    title?: string;
    parent_digest?: string;
}): boolean;
export interface StoreOptions {
    storePath: string;
    maxItems?: number;
}
export declare class JsonStore {
    private filePath;
    private maxItems;
    private items;
    private itemMap;
    private maxId;
    private writeQueue;
    constructor(options: StoreOptions);
    getFilePath(): string;
    getItemsCount(): number;
    getPendingCount(): number;
    getScoredCount(): number;
    /** Count pending items skipped from LLM scoring due to insufficient article content. */
    getInsufficientContentCount(): number;
    /**
     * Count pending items whose LLM scoring call failed.
     *
     * These are separable from `getInsufficientContentCount()` on purpose: a
     * content problem is permanent and expected, whereas a scoring failure means
     * the configured model route is broken and the user needs to be told.
     */
    getFailedCount(): number;
    getFileSizeBytes(): number;
    /**
     * Load JSON file from disk into memory.
     * If file does not exist or is invalid, initialize with empty array.
     */
    private loadFromDisk;
    private sortInMemory;
    /**
     * Query signals from memory index in <1ms.
     */
    querySignals(options?: {
        minScore?: number;
        limit?: number;
        category?: string;
        sortByScore?: boolean;
        sortByWeightAndDate?: boolean;
        /** Group scored items (sorted by score desc, date desc) ahead of pending items (sorted by date desc). */
        groupByStatus?: boolean;
        /** Exclude multi-item digest posts (e.g. aihot daily roundups) from single-item rankings. */
        excludeDigest?: boolean;
        sTierScore?: number;
        status?: 'pending' | 'scored' | 'all';
    }): SignalItem[];
    /**
     * Recompute cross-source clusters across all items in memory.
     */
    recomputeClusters(): void;
    /**
     * Query today's top unread high-signal briefing items (Layer 1: 今日必看).
     * Strict hard cap of 5 items per day.
     */
    queryDailyBriefing(opts: {
        date: string;
        includeRead?: boolean;
        limit?: number;
        featuredMinScore?: number;
        digestMinScore?: number;
    }): SignalItem[];
    /**
     * Mark item IDs as read idempotently (preserves original read_at timestamp if already read).
     */
    markRead(ids: number[], nowMs?: number): Promise<number>;
    /**
     * Add raw items into store.
     * Duplicate URLs are ignored (idempotent).
     * Returns the array of newly added items.
     */
    addItems(rawItems: Array<{
        source: string;
        source_type: string;
        url: string;
        title: string;
        summary?: string;
        published_at?: string;
        raw_content?: string | null;
        score?: number;
        source_weight?: number;
        tags?: string[];
        status?: 'pending' | 'scored' | 'failed';
        parent_digest?: string;
        digest_section?: string;
        digest_date?: string;
        topic_match?: string[];
        topic_boost?: number;
        title_zh?: string | null;
        title_en?: string | null;
        why_it_matters?: string | null;
        read_at?: number;
    }>): Promise<SignalItem[]>;
    /**
     * Update pending item fields (e.g. hydrated raw_content or skip_reason) before/without scoring.
     */
    updatePendingItem(urlKey: string, patch: {
        raw_content?: string | null;
        skip_reason?: string | null;
    }): Promise<void>;
    /**
     * Update scored items.
     */
    updateScoredItems(updates: Array<{
        url_key: string;
        score: number;
        score_mean?: number;
        score_raw?: number[];
        source_weight?: number;
        tracking_penalty?: number;
        is_s_tier?: boolean;
        prompt_version?: string;
        title_zh?: string | null;
        title_en?: string | null;
        summary?: string;
        tags?: string[];
        topic_match?: string[];
        topic_boost?: number;
        why_it_matters?: string | null;
        status?: 'pending' | 'scored' | 'failed';
    }>): Promise<void>;
    /**
     * Rolling prune to keep at most maxItems and delete items older than 90 days.
     */
    private prune;
    /**
     * Enqueues an atomic write to disk.
     * Write .tmp -> fsync -> rename
     */
    saveAsync(): Promise<void>;
    private atomicWrite;
}
//# sourceMappingURL=json-store.d.ts.map