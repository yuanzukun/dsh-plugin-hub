/**
 * Normalizes URL and produces a deterministic sha256 url_key.
 * Rules:
 * 1. Host lowercase.
 * 2. Strip 'www.' prefix, normalize 'm.' and 'amp.' subdomains to root domain.
 * 3. Strip fragment (#...).
 * 4. Remove trailing slash (except root '/').
 * 5. Strip marketing/tracking query params (utm_*, fbclid, gclid, ref, spm).
 * 6. Sort remaining query params alphabetically.
 */
export declare function normalizeUrl(rawUrl: string): {
    normalizedUrl: string;
    urlKey: string;
};
//# sourceMappingURL=url-normalize.d.ts.map