# 贡献指南

感谢你愿意改进 `dsh-douyin`。

这个项目是「非官方接口 + 浏览器自动化」的工具，所以有两条比代码本身更重要的前提：

> **不要提交任何凭证**（cookie、`.env`、`data/`、截图里的账号信息）
> **不要实现绕过风控的东西**（验证码破解、打码平台、伪造设备指纹、多账号矩阵）

---

## 快速开始

```bash
git clone https://github.com/JianHeShui/dsh-douyin.git
cd dsh-douyin

python3 -m venv .venv
.venv/bin/pip install -r python/requirements-http.txt   # requirements.txt 是子集
.venv/bin/playwright install chromium                   # Linux / macOS；Windows 可用 Edge

npm run check             # JS 语法检查
python tests/test_fixture.py   # 私信逻辑离线测试（不联网、不发真实消息）
```

环境变量见 [`.env.example`](.env.example)，登录与 cookie 导出见 [`docs/COOKIE-GUIDE.md`](docs/COOKIE-GUIDE.md)。

---

## 项目结构

```text
index.js              DSH 入口：注册工具（TOOL_SWITCH）
lib/tools.js          defineTool 定义（工具的 name / description / 参数）
lib/backend.js        子进程调用、限频、配额、脱敏、浏览器发现
lib/normalize.js      响应归一化（缺失即 null）
python/douyin_bridge.py  登录状态机 / 评论
python/douyin_im.py      私信 / 群聊驱动（dry-run 默认）
python/douyin_http.py    FastAPI HTTP API
tools/export_login_state.py  本地扫码登录 → 导出 storage_state
tools/probe_im.py            DOM 探测（前端改版后重新采集选择器）
tests/                 仿真 DOM 的离线测试
```

---

## 加一个工具：四处同步

新增 DSH 工具时，下面四处必须一起改，否则会出现「工具存在但开关无效」或「文档里有、实际没有」：

1. `lib/tools.js` 的 `createTools()` 里 `defineTool({ ... })`
2. `index.js` 的 `TOOL_SWITCH`（工具名 → 配置开关）
3. `cordis.patch.yml` 的 `toolEnabled`（默认值）
4. `README.md` 的工具表 / 特性表

如果这个工具是写操作（评论、发布、私信），**默认必须是关闭或 dry-run**，并在 README 里写清楚需要哪几道闸。

---

## 改 DOM 选择器

抖音前端改版会让私信/评论失效。流程：

```bash
python tools/probe_im.py        # 采集当前页面的 class / placeholder / 文本
```

对照输出，改 `python/douyin_im.py` 顶部的选择器常量，然后跑离线测试：

```bash
python tests/test_fixture.py
```

`tests/fixture_chat.html` 是仿真页，新增选择器时最好同步更新它，让测试可复现。

---

## 提交前自检

```bash
npm run check                                  # 4 个 JS 文件 node --check
python -m py_compile python/*.py tools/*.py tests/*.py
python tests/test_fixture.py                   # 期望 7 项通过
```

再自查一遍：

- [ ] `git status` 里**没有** `data/`、`.env`、cookie、截图、`*.log`
- [ ] 没有把服务器 IP、绝对路径、账号昵称写死进代码或文档（占位符用 `/opt/dsh-douyin`、`CHANGE_ME`、`user@server`）
- [ ] 新增/修改的报错信息不包含 cookie、`sessionid`、`passport_*`、`storage_state`
- [ ] 写操作仍然是 dry-run 默认（除非这个改动本身就是在改默认值，那就必须在 PR 里说明理由）

---

## 提交信息

用一句话说清楚「改了什么、为什么」即可，不强制 Conventional Commits：

```text
fix: 会话标题匹配支持带后缀的群名
feat: /frames 支持自定义抽帧数量
docs: 补充 cookie 过期后的重新导出步骤
```

---

## Pull Request

开 PR 前请确认：

- 一个 PR 只做一件事（重构和功能分开）
- 说明**怎么测的**（跑了哪条命令、看到什么结果）
- 如果改动涉及浏览器自动化，说明是否在真实抖音上验证过；如果没有，标注「仅离线测试」
- 涉及安全模型的改动（dry-run、闸门、白名单、脱敏）请单独在描述里点出来

PR 模板会自动提示这些，照着填就行。

---

## 不接受的改动

- 任何形式的验证码绕过、打码平台接入、设备指纹伪造
- 批量点赞 / 关注 / 养号 / 多账号矩阵 / 自动发布这类「刷量」功能
- 把凭证写进代码、示例、测试或文档
- 把「默认 dry-run」改成默认真实发送（可以加开关，但不能改默认）
- 提交与改动无关的格式化/重排（会让 review 无法进行）

---

## 行为准则

参与本项目即表示同意遵守 [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md)。
