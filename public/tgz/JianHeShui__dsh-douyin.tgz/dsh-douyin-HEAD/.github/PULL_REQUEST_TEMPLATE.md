## 改动说明

<!-- 这个 PR 做了什么、为什么做。一个 PR 只做一件事。 -->

## 怎么测的

<!-- 跑了哪条命令、看到什么结果；如果涉及真实抖音，说明场景；没有就写「仅离线测试」 -->

```bash
npm run check
python -m py_compile python/*.py tools/*.py tests/*.py
python tests/test_fixture.py
```

## 检查清单

- [ ] `git status` 里没有 `data/`、`.env`、cookie、截图、日志
- [ ] 没有把服务器 IP / 绝对路径 / 账号昵称写死（占位符用 `CHANGE_ME`、`/opt/dsh-douyin`、`user@server`）
- [ ] 新增或修改的报错不包含 cookie、`sessionid`、`passport_*`、`storage_state`
- [ ] 如果新增工具：`lib/tools.js`、`index.js` 的 `TOOL_SWITCH`、`cordis.patch.yml` 的 `toolEnabled`、README 工具表**四处已同步**
- [ ] 写操作仍然保持 dry-run 默认（如果改的就是默认值，已在描述里说明理由与风险）
- [ ] 涉及 DOM/选择器改动时，`tests/fixture_chat.html` 与 `tests/test_fixture.py` 已同步更新
- [ ] 文档已更新（README / docs/ / CHANGELOG）

## 是否涉及安全模型

<!-- dry-run、闸门、白名单、脱敏、账号指纹 —— 动到其中任何一项请单独说明 -->

- [ ] 不涉及
- [ ] 涉及，说明：__________
