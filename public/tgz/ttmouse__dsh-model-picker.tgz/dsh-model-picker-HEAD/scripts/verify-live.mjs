// Real-browser verification against the live dsh web GUI.
//
// Forges the same signed browser-session cookie the host mints (the secret is
// the durable credential record at client-connection/browser-session), then
// drives the real page with Playwright: reads the composer tool row, opens the
// model popup, and reports what the user actually sees — including computed
// widths, which is what a jsdom test cannot show.
//
// Run: node scripts/verify-live.mjs
//      DSH_LIVE_ORIGIN=http://127.0.0.1:19387 node scripts/verify-live.mjs
import { createHash, createHmac } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { homedir } from 'node:os'
import { join } from 'node:path'

// The surface under test. 3080 is the `web` profile, which links this repo, so
// the file on disk is what that shell serves. DSH_LIVE_ORIGIN points the same
// run at another live shell: the desktop app's 19387 is the one the user looks
// at, and it serves its own installed copy of lib/client.js, so a change has to
// be carried into that profile before it can be seen there at all.
const ORIGIN = process.env.DSH_LIVE_ORIGIN ?? 'http://127.0.0.1:3080'
const AUTHORITY = new URL(ORIGIN).host
const CREDENTIALS = join(homedir(), '.dsh/.credentials.yaml')

/** The durable signing secret written by the host's browser-auth initialization. */
function readSecret() {
  const text = readFileSync(CREDENTIALS, 'utf8')
  const at = text.indexOf('client-connection/browser-session:')
  if (at === -1) throw new Error('no browser-session credential record')
  const match = /secret:\s*(\S+)/.exec(text.slice(at))
  if (match === null) throw new Error('no secret in the credential record')
  // The record stores base64url text of the raw key bytes; the host signs with
  // the decoded bytes, so signing with the text would fail verification.
  return Buffer.from(match[1].replaceAll('-', '+').replaceAll('_', '/') + '=', 'base64')
}

const b64url = (value) => Buffer.from(value).toString('base64')
  .replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/u, '')

const secret = readSecret()
const cookieName = `dsh-auth-${b64url(createHash('sha256').update(AUTHORITY).digest())}`
const now = Date.now()
const body = b64url(JSON.stringify({ version: 1, authority: AUTHORITY, issuedAt: now, expiresAt: now + 3_600_000 }))
const cookieValue = `v1.${body}.${b64url(createHmac('sha256', secret).update(body).digest())}`
console.log('cookie name :', cookieName)

const { chromium } = createRequire(join(homedir(), '.npm-global/lib/node_modules/playwright/index.js'))('playwright')

// The globally installed Playwright expects a browser build this machine has
// not downloaded; an installed headless shell is used directly instead.
const HEADLESS_SHELL = join(homedir(), 'Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell')

const browser = await chromium.launch({ executablePath: HEADLESS_SHELL })
const context = await browser.newContext({ viewport: { width: 1600, height: 900 } })
// The browser cookie jar path is rejected by the host while an explicit header
// is accepted (see scripts/probe-transport.mjs), so the credential is injected
// as a request header for every request instead.
await context.setExtraHTTPHeaders({ cookie: `${cookieName}=${cookieValue}` })
const page = await context.newPage()
const consoleErrors = []
page.on('console', (msg) => { if (msg.type() === 'error') consoleErrors.push(msg.text()) })
page.on('pageerror', (err) => { consoleErrors.push(`pageerror: ${err.message}`) })
page.on('request', async (request) => {
  if (request.resourceType() !== 'document') return
  const headers = await request.allHeaders()
  console.log('doc request :', request.url())
  console.log('  host      :', headers.host)
  console.log('  cookie    :', (headers.cookie ?? '(none)').slice(0, 60) + '…')
  console.log('  cookie ok :', headers.cookie === `${cookieName}=${cookieValue}`)
  console.log('  expect len:', `${cookieName}=${cookieValue}`.length, 'actual len:', (headers.cookie ?? '').length)
})
page.on('console', (msg) => { if (msg.type() === 'error') consoleErrors.push(msg.text()) })
page.on('pageerror', (err) => { consoleErrors.push(`pageerror: ${err.message}`) })

const response = await page.goto(ORIGIN, { waitUntil: 'domcontentloaded' })
console.log('http status :', response?.status())
console.log('title       :', await page.title())
// The composer chrome and client plugins arrive over the boot graph.
try {
  await page.waitForSelector('[data-composer-card], textarea', { timeout: 30_000 })
} catch {
  console.log('--- composer did not appear; page diagnostics ---')
  console.log('url    :', page.url())
  console.log('body   :', (await page.evaluate(() => document.body.innerText)).slice(0, 800))
  console.log('boot   :', await page.evaluate(() => JSON.stringify(window.__DSH_BOOT__ ?? null).slice(0, 600)))
  console.log('errors :', consoleErrors.join('\n') || '(none)')
  await page.screenshot({ path: join(process.cwd(), 'live-failed.png'), fullPage: true })
  await browser.close()
  process.exit(1)
}
await page.waitForTimeout(4000)

// ── What is in the composer tool row? ──────────────────────────────────────
const seat = await page.evaluate(() => {
  const rows = [...document.querySelectorAll('button')]
  const found = {
    trigger: document.querySelector('.dsh-mp2-trigger') !== null,
    triggerHtml: document.querySelector('.dsh-mp2-trigger')?.outerHTML?.slice(0, 400) ?? null,
    triggerRect: (() => {
      const el = document.querySelector('.dsh-mp2-trigger')
      if (el === null) return null
      const r = el.getBoundingClientRect()
      return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }
    })(),
    leftRect: (() => {
      const el = document.querySelector('.dsh-mp2-triggerLeft')
      if (el === null) return null
      const r = el.getBoundingClientRect()
      return { w: Math.round(r.width), h: Math.round(r.height) }
    })(),
    leftText: document.querySelector('.dsh-mp2-triggerLeft')?.textContent ?? null,
    rightText: document.querySelector('.dsh-mp2-triggerRight')?.textContent ?? null,
    seatError: document.querySelector('[data-dsh-ms-seat-error]')?.textContent ?? null,
    toolRowButtons: rows.map(b => (b.textContent ?? '').trim()).filter(t => t !== '').slice(0, 20),
  }
  return found
})
console.log('--- composer model seat ---')
console.log(JSON.stringify(seat, null, 2))

// ── Open the popup and check the search-first layout ───────────────────────
if (seat.trigger) {
  await page.click('.dsh-mp2-triggerLeft')
  await page.waitForTimeout(600)
  const open = await page.evaluate(() => {
    const search = document.querySelector('.dsh-mp2-search')
    const menu = document.querySelector('.dsh-mp2-menu')
    return {
      searchPresent: search !== null,
      searchFocused: search !== null && document.activeElement === search,
      menuRect: menu === null ? null : (() => {
        const r = menu.getBoundingClientRect(); return { w: Math.round(r.width), h: Math.round(r.height) }
      })(),
      providers: [...document.querySelectorAll('.dsh-mp2-providerName')].map(n => n.textContent),
      models: [...document.querySelectorAll('.dsh-mp2-list .dsh-mp2-modelName')].map(n => n.textContent),
    }
  })
  console.log('--- popup after click ---')
  console.log(JSON.stringify(open, null, 2))
  if (!open.searchFocused) throw new Error('the popup must open with the caret in the search box')

  // ── The avatar is a brand mark, and it paints ────────────────────────────
  // The marks are inlined SVG paths filled with `currentColor`, so a real
  // browser is the only place that can answer the question jsdom cannot: does
  // the mark have a size, and does it paint in the row's own ink rather than
  // coming out invisible? The row this reads is the live model's, which is what
  // the closed trigger wears.
  const avatar = await page.evaluate(() => {
    const option = document.querySelector('.dsh-mp2-list .dsh-mp2-option')
    const chip = option?.querySelector('.dsh-mp2-avatar')
    const svg = chip?.querySelector('svg')
    const path = svg?.querySelector('path')
    if (chip === null || chip === undefined || svg == null || path == null) {
      return { present: false, model: option?.querySelector('.dsh-mp2-modelName')?.textContent ?? null }
    }
    const chipBox = chip.getBoundingClientRect()
    const svgBox = svg.getBoundingClientRect()
    const chipStyle = getComputedStyle(chip)
    const svgStyle = getComputedStyle(svg)
    return {
      present: true,
      model: option.querySelector('.dsh-mp2-modelName').textContent,
      brand: chip.classList.contains('dsh-mp2-avatarBrand'),
      letter: chip.textContent,
      chipBackground: chipStyle.backgroundColor,
      svgFill: svgStyle.fill,
      svgBoxShadow: svgStyle.boxShadow,
      pathLength: path.getAttribute('d')?.length ?? 0,
      fillRule: svg.getAttribute('fill-rule') ?? svgStyle.fillRule,
      chipSize: [Math.round(chipBox.width), Math.round(chipBox.height)],
      svgSize: [Math.round(svgBox.width), Math.round(svgBox.height)],
    }
  })
  console.log('--- row avatar ---')
  console.log(JSON.stringify(avatar, null, 2))
  if (!avatar.present) throw new Error('a model row rendered no avatar at all')
  if (avatar.brand) {
    if (avatar.pathLength === 0) throw new Error('the brand mark carried an empty path')
    if (avatar.letter !== '') throw new Error(`a brand mark also rendered a letter: ${JSON.stringify(avatar.letter)}`)
    if (avatar.chipBackground !== 'rgba(0, 0, 0, 0)') {
      throw new Error(`a brand mark must not wear the fallback chip tint: ${avatar.chipBackground}`)
    }
    if (avatar.svgSize[0] === 0 || avatar.svgSize[1] === 0) {
      throw new Error(`the brand mark painted at zero size: ${JSON.stringify(avatar.svgSize)}`)
    }
    if (avatar.svgSize[0] > avatar.chipSize[0]) {
      throw new Error(`the brand mark overflows its box: ${JSON.stringify([avatar.svgSize, avatar.chipSize])}`)
    }
    if (avatar.fillRule !== 'evenodd') {
      throw new Error(`the brand mark dropped its fill-rule and would fill its own counters: ${avatar.fillRule}`)
    }
    if (/rgba\(0, 0, 0, 0\)/.test(avatar.svgFill)) {
      throw new Error(`the brand mark painted in no colour: ${avatar.svgFill}`)
    }
  } else if ((avatar.letter ?? '') === '') {
    throw new Error('a row fell back to a chip with no letter in it')
  }

  // ── The search box carries no focus highlight ────────────────────────────
  // The field is focused for the whole life of the popup, so an accent border
  // would be lit from the moment the panel opens and read as a state to clear;
  // the caret is the cue. The painted border is compared against both tokens,
  // measured on probe elements rather than by blurring the field — blur is this
  // popup's dismiss gesture, so reading the unfocused state that way closes it.
  const ring = await page.evaluate(() => {
    const search = document.querySelector('.dsh-mp2-search')
    const token = (name) => {
      const probe = document.createElement('div')
      probe.style.cssText = `position:absolute;width:0;height:0;border:1px solid var(${name})`
      search.parentElement.appendChild(probe)
      const color = getComputedStyle(probe).borderTopColor
      probe.remove()
      return color
    }
    return {
      painted: getComputedStyle(search).borderTopColor,
      resting: token('--dsw-alias-border-l1'),
      brand: token('--dsw-alias-brand-primary'),
      focused: document.activeElement === search,
    }
  })
  console.log('--- search focus ring ---')
  console.log(JSON.stringify(ring))
  if (!ring.focused) throw new Error('the focus probe ran with the caret outside the search box')
  if (ring.painted !== ring.resting) {
    throw new Error(`the search box does not wear its resting border: ${ring.painted} ≠ ${ring.resting}`)
  }
  if (ring.painted === ring.brand) {
    throw new Error(`the search box lights its border on focus: ${ring.painted}`)
  }

  // Search a provider name: both columns must narrow.
  await page.fill('.dsh-mp2-search', 'deep')
  await page.waitForTimeout(400)
  const searched = await page.evaluate(() => ({
    providers: [...document.querySelectorAll('.dsh-mp2-providerName')].map(n => n.textContent),
    models: [...document.querySelectorAll('.dsh-mp2-list .dsh-mp2-modelName')].map(n => n.textContent),
  }))
  console.log('--- after typing "deep" ---')
  console.log(JSON.stringify(searched, null, 2))
  await page.screenshot({ path: join(process.cwd(), 'live-popup.png') })

  // ── Keyboard-only operation ──────────────────────────────────────────────
  // The panel must be usable without the mouse: it opens with the first row
  // already under the cursor, arrows move it, and Enter commits it.
  await page.fill('.dsh-mp2-search', '')
  await page.waitForTimeout(300)
  const cursor = () => page.evaluate(() => {
    const row = document.querySelector('.dsh-mp2-list .dsh-mp2-optionActive')
    const search = document.querySelector('.dsh-mp2-search')
    const style = row === null ? null : getComputedStyle(row)
    return {
      name: row?.querySelector('.dsh-mp2-modelName')?.textContent ?? null,
      id: row?.id ?? null,
      inUse: row?.querySelector('.dsh-mp2-check svg') !== null,
      listed: document.querySelectorAll('.dsh-mp2-list .dsh-mp2-option').length,
      activeDescendant: search?.getAttribute('aria-activedescendant') ?? null,
      searchFocused: document.activeElement === search,
      // The cursor is a background surface and nothing else: no left rail, no
      // border, no outline. The user rejected an accent bar on the left edge.
      background: style?.backgroundColor ?? null,
      decoration: style === null ? null : [style.boxShadow, style.borderLeftWidth, style.outlineStyle].join(' | '),
    }
  })
  console.log('--- keyboard ---')
  const onOpen = await cursor()
  console.log('cursor on open :', JSON.stringify(onOpen))
  // The cursor must be readable without any left-edge decoration: a background
  // surface marks it, and nothing else does.
  if (onOpen.background === null || onOpen.background === 'rgba(0, 0, 0, 0)') {
    throw new Error('the cursor row has no background surface to mark it')
  }
  if (onOpen.decoration !== 'none | 0px | none') {
    throw new Error(`the cursor row carries left-edge decoration: ${onOpen.decoration}`)
  }
  await page.keyboard.press('ArrowDown')
  await page.waitForTimeout(150)
  const moved = await cursor()
  console.log('after ArrowDown:', JSON.stringify(moved))
  await page.keyboard.press('Home')
  await page.waitForTimeout(150)
  console.log('after Home     :', JSON.stringify(await cursor()))
  await page.screenshot({ path: join(process.cwd(), 'live-model-picker-keyboard.png') })

  // Walk the cursor onto the model already in use, then Enter: that closes the
  // popup and hands focus back without touching the live selection, which is
  // what makes this safe to run against the user's own session.
  let steps = 0
  let inUse = onOpen
  while (!inUse.inUse && steps < onOpen.listed + 2) {
    await page.keyboard.press('ArrowDown')
    await page.waitForTimeout(80)
    inUse = await cursor()
    steps += 1
  }
  if (!inUse.inUse) {
    console.log('the model in use is not in the list; skipped the Enter check')
  } else {
    await page.keyboard.press('Enter')
    await page.waitForTimeout(600)
    console.log('after Enter    :', JSON.stringify(await page.evaluate(() => ({
      menuClosed: document.querySelector('.dsh-mp2-menu') === null,
      triggerText: document.querySelector('.dsh-mp2-triggerLeft')?.textContent ?? null,
      focusBack: document.activeElement === document.querySelector('.dsh-mp2-triggerLeft'),
    }))))
  }

  // ── Elevator: a supplier click jumps, it does not ride ───────────────────
  // Read `scrollTop` in the same turn as the click. An animated scroll would
  // still be at (or near) its starting offset at that instant; a jump is
  // already at the target. The panel is left open by the keyboard section
  // above unless Enter landed on the model in use, so open it only if needed.
  if (await page.evaluate(() => document.querySelector('.dsh-mp2-menu') === null)) {
    await page.click('.dsh-mp2-triggerLeft')
    await page.waitForTimeout(500)
  }
  const jump = await page.evaluate(() => {
    const rows = [...document.querySelectorAll('.dsh-mp2-providers .dsh-mp2-provider')]
    const groups = [...document.querySelectorAll('.dsh-mp2-list .dsh-mp2-group')]
    const list = document.querySelector('.dsh-mp2-list')
    // The last supplier floor: a long jump, so an animation would be obvious.
    const row = rows[rows.length - 1]
    const group = groups[groups.length - 1]
    const target = group.offsetTop
    const before = list.scrollTop
    row.click()
    return {
      floor: row.querySelector('.dsh-mp2-providerName')?.textContent ?? null,
      before,
      target,
      // A floor near the end cannot be scrolled to the top edge: the list runs
      // out of content, so the landing offset is clamped there.
      expected: Math.min(target, list.scrollHeight - list.clientHeight),
      immediate: list.scrollTop,
    }
  })
  console.log('--- elevator jump ---')
  console.log(JSON.stringify(jump))
  await page.waitForTimeout(500)
  const settled = await page.evaluate(() => document.querySelector('.dsh-mp2-list').scrollTop)
  console.log('after 500ms :', settled)
  if (jump.before === jump.expected) throw new Error('the elevator test picked a floor the list was already on')
  if (jump.immediate !== jump.expected) {
    throw new Error(`a supplier click must jump to its group, not animate: expected ${jump.expected}, got ${jump.immediate}`)
  }
  if (settled !== jump.expected) {
    throw new Error(`the list kept moving after the click: settled at ${settled}, expected ${jump.expected}`)
  }

  // ── Footer: the way out to Settings → 模型 ────────────────────────────────
  // The picker can only list what the configured providers offer, so it carries
  // one fixed row that opens the page which configures them. This crosses two
  // plugins — the picker writes the settings shell's own store — so only a real
  // shell proves the store is reachable, which is why it is checked live.
  if (await page.evaluate(() => document.querySelector('.dsh-mp2-menu') === null)) {
    await page.click('.dsh-mp2-triggerLeft')
    await page.waitForTimeout(500)
  }
  const footer = await page.evaluate(() => {
    const row = document.querySelector('.dsh-mp2-footer')
    const cluster = document.querySelector('.dsh-mp2-footerCluster')
    const button = document.querySelector('.dsh-mp2-footerSettings')
    const menu = document.querySelector('.dsh-mp2-menu')
    const box = (node) => {
      if (node === null) return null
      const r = node.getBoundingClientRect()
      return { left: Math.round(r.left), right: Math.round(r.right), width: Math.round(r.width) }
    }
    return {
      present: row !== null,
      parent: row?.parentElement?.className ?? null,
      insideList: row?.closest('.dsh-mp2-list') !== null,
      label: button?.textContent ?? null,
      svgs: button?.querySelectorAll('svg').length ?? 0,
      // The pair must read as one group at the trailing edge: contiguous boxes,
      // both right-aligned with the popup's own edge, and clear of the fold
      // toggle that leads the row. Measured here, not in jsdom, because only a
      // real layout settles the free space a cluster claims.
      clusterEntries: [...(cluster?.querySelectorAll('button') ?? [])].map((b) => ({
        label: b.textContent,
        svgs: b.querySelectorAll('svg').length,
        ...box(b),
      })),
      cluster: box(cluster),
      fold: box(document.querySelector('.dsh-mp2-footerIcon')),
      // 0 means the row sits on the popup's own bottom edge, under the body.
      gapToBottom: row === null || menu === null
        ? null
        : Math.round(menu.getBoundingClientRect().bottom - row.getBoundingClientRect().bottom),
    }
  })
  console.log('--- settings footer ---')
  console.log(JSON.stringify(footer))
  if (!footer.present) throw new Error('the model popup carries no settings footer')
  if (footer.insideList) throw new Error('the footer scrolls with the list instead of sitting under it')
  if (footer.parent !== 'dsh-mp2-menu') throw new Error(`the footer is not a direct child of the popup: ${footer.parent}`)
  if (footer.svgs !== 1) throw new Error(`the footer entry is one glyph and one label, got ${footer.svgs} svg`)
  if (footer.clusterEntries.length !== 2) {
    throw new Error(`the two settings entries must share one cluster, got ${footer.clusterEntries.length}`)
  }
  for (const entry of footer.clusterEntries) {
    if (entry.svgs !== 1) throw new Error(`${entry.label}: one glyph and one label`)
    if (entry.label.trim() === '') throw new Error('a footer entry rendered with no label')
  }
  // Contiguous: the gap between the pair is the cluster's own padding, not the
  // leftover space of a row that pushed them to opposite ends.
  const [first, second] = footer.clusterEntries
  const gap = second.left - first.right
  if (gap < 0 || gap > 12) throw new Error(`the two settings entries are not adjacent, gap ${gap}px`)
  // Trailing edge: the pair ends where the popup ends, and the fold toggle keeps
  // the opposite end to itself.
  if (second.right !== footer.cluster.right) {
    throw new Error(`the cluster must hug the trailing edge, got ${second.right} vs ${footer.cluster.right}`)
  }
  if (footer.fold !== null && footer.fold.right > first.left) {
    throw new Error('the fold toggle has drifted into the settings cluster')
  }

  await page.click('.dsh-mp2-footerSettings')
  await page.waitForTimeout(1200)
  const handedOff = await page.evaluate(() => {
    const panel = document.querySelector('[data-shortcut-modal="settings"]')
    const active = panel?.querySelector('nav button[aria-current="true"]')
    return {
      pickerClosed: document.querySelector('.dsh-mp2-menu') === null,
      settingsOpen: panel !== null,
      activeSection: active?.textContent?.trim() ?? null,
      sections: panel === null ? [] : [...panel.querySelectorAll('nav button')].map((b) => b.textContent.trim()),
      // The Models page is the only section whose copy talks about API keys.
      bodyMentionsApi: panel !== null && /API/.test(panel.innerText),
    }
  })
  console.log(JSON.stringify(handedOff))
  if (!handedOff.settingsOpen) throw new Error('the footer did not open the settings panel')
  if (!handedOff.pickerClosed) throw new Error('the footer left the picker open over the settings panel')
  if (handedOff.activeSection === null) throw new Error('the settings panel opened with no active section')
  if (!handedOff.bodyMentionsApi) {
    throw new Error(`the footer must land on the models section, got "${handedOff.activeSection}"`)
  }
  await page.screenshot({ path: join(process.cwd(), 'live-settings-models.png') })
  // Close it again: a verification run leaves the session as it found it.
  await page.keyboard.press('Escape')
  await page.waitForTimeout(400)
  if (await page.evaluate(() => document.querySelector('[data-shortcut-modal="settings"]') !== null)) {
    throw new Error('the settings panel did not close on Escape')
  }

  // ── The panel speaks the app's language ──────────────────────────────────
  // DSH's UI language is a product preference (Settings → General → Language),
  // not a browser fact: the panel must read the app's own source — the `locale`
  // service the whole shell reads — and only fall back to the document, then the
  // navigator. The two probes below pin both halves of that rule.
  await page.click('.dsh-mp2-triggerLeft')
  await page.waitForTimeout(600)
  const appCopy = () => page.evaluate(() => ({
    declared: document.documentElement.lang,
    search: document.querySelector('.dsh-mp2-search')?.placeholder ?? null,
    footer: document.querySelector('.dsh-mp2-footerSettings .dsh-mp2-footerLabel')?.textContent ?? null,
    footerFallback: document.querySelector('.dsh-mp2-footerFallback .dsh-mp2-footerLabel')?.textContent ?? null,
  }))
  const before = await appCopy()
  console.log('--- language ---')
  console.log('app declares :', JSON.stringify(before))
  // 1. The copy agrees with the language the app declares it is rendering.
  const zhCopy = before.declared.toLowerCase().startsWith('zh')
  if (zhCopy !== (before.search === '搜索模型或提供商…')) {
    throw new Error(`the panel's language does not match the app's (${before.declared}): ${JSON.stringify(before.search)}`)
  }
  // 2. A stray attribute does not move it: the app's own preference outranks the
  //    document, so forcing <html lang> while the locale service says otherwise
  //    must change nothing. This is the live twin of the jsdom precedence test.
  const stray = before.declared.toLowerCase().startsWith('zh') ? 'en' : 'zh-CN'
  await page.evaluate((tag) => { document.documentElement.lang = tag }, stray)
  await page.waitForTimeout(500)
  const after = await appCopy()
  console.log(`forced lang=${stray} :`, JSON.stringify(after))
  if (after.search !== before.search || after.footer !== before.footer) {
    throw new Error(`a forced <html lang> moved the copy, so the app's own preference is not what is read: ${JSON.stringify(after)}`)
  }
  await page.evaluate((tag) => { document.documentElement.lang = tag }, before.declared)
  await page.keyboard.press('Escape')
  await page.waitForTimeout(300)
}

await page.screenshot({ path: join(process.cwd(), 'live-composer.png') })
console.log('--- console errors ---')
console.log(consoleErrors.length === 0 ? '(none)' : consoleErrors.join('\n'))

await browser.close()
