/* dsh-neo-skin — zero-dependency build script.
 *
 * Reads package.json (plugin id), then every scheme under src/schemes/
 * (blue, newspaper, …): <name>.tokens.json = the light/dark token table,
 * <name>.meta.json = { label }, <name>.css = scheme structure extras.
 * Injects the compiled SCHEMES map into src/bundle.template.js and writes
 * the final self-contained browser bundle to client.js.
 *
 *   node scripts/build.mjs     (or: npm run build)
 */
import { readFileSync, readdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");

const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
const schemesDir = join(root, "src", "schemes");

const names = readdirSync(schemesDir)
	.filter((f) => f.endsWith(".tokens.json"))
	.map((f) => f.replace(/\.tokens\.json$/, ""))
	.sort();

if (names.length === 0) throw new Error("no schemes found under src/schemes/");

const schemes = {};
for (const name of names) {
	const tokens = JSON.parse(readFileSync(join(schemesDir, `${name}.tokens.json`), "utf8"));
	const meta = JSON.parse(readFileSync(join(schemesDir, `${name}.meta.json`), "utf8"));
	let css = "";
	try {
		css = readFileSync(join(schemesDir, `${name}.css`), "utf8").trim();
	} catch {}
	schemes[name] = { label: meta.label || name, css, tokens };
}

const template = readFileSync(join(root, "src", "bundle.template.js"), "utf8");
const bundle = template
	.replaceAll("__PKG_NAME__", JSON.stringify(pkg.name))
	.replaceAll("__SCHEMES__", JSON.stringify(schemes));

const out = join(root, "client.js");
writeFileSync(out, bundle);

const summary = names.map((n) => `${n}(${Object.keys(schemes[n].tokens).length})`).join(", ");
console.log(`dsh-neo-skin: built client.js — schemes: ${summary}, source "${pkg.name}"`);
