# Changelog

## v1.7.5 — 2026-11-25

- **修模型/推理等级不同步**：客户端把等级切到 `Max` 再切回 `High` 后，侧边栏一直停在 `Max`。
  根因是宿主只从 follow 的 `snapshot` 帧读 `modelSelection`，而客户端的等级变更是
  `model/selection` **事件**，从未被跟踪；桥接因此一直广播旧值。
  现在宿主监听该事件并 `updateModelState()`，桥接广播 `engine.modelCurrent`，
  侧边栏收到后立刻刷新选择器标签（客户端 High ↔ 插件 High 实时一致）。
- 新增回归测试 `verify-model-sync.cjs` 思路（预览页注入 engine 帧，校验 High→Max→High）；
  预览 fixture 补全 `reasoning.efforts`，避免标签查不到名字。
- **新增 `scripts/update-extension-refs.cjs`**：改 manifest 版本与 `sidepanel-x.y.z` 引用一律用它。
  原因：PowerShell 5.1 的 `Get-Content -Raw` 按 ANSI 解码 UTF-8，会把 manifest/HTML 里的中文写坏
  （本次实际踩到并已用 git 恢复）——和之前的 BOM 事故一样，禁止用 PS 改写这些文件。
- 扩展 1.4.3（`sidepanel-1.4.3.js/.css`，需重新加载扩展）、宿主插件 2.4.5、安装包 1.7.5
  （桥接 1.3.6 不变）。

## v1.7.4 — 2026-11-25

- **修一次真实崩溃/失效的根因**：用 PowerShell `Set-Content -Encoding UTF8` 改版本号时，给
  `package.json` 写进了 BOM。DSH 的 bundle 加载器 `JSON.parse` 直接失败，把插件标成
  `availability: missing` 静默丢弃 —— 于是宿主永远连不上、只剩旧的 1.3.3 桥在跑，
  所以前面几版的修复"看起来完全没生效"。现已去掉 BOM，并通过把 bundle 关→开重新加载成功：
  当前 `GET /status` 为 *bridge 1.3.6 / host connected / warnings.zcodeBridge=false*。
- 新增 `scripts/check-encoding.cjs`（扫描 BOM，发现即失败）与 `scripts/bump-version.cjs`
  （改版本号且绝不写 BOM），以后改版本号一律用后者。
- **注记改为每会话一次**：实测 `agent/pre-step` 追加的文本会随 DSH 的 `time-context` 快照落进
  Session log（`source.kind=time-context`，客户端按内部上下文渲染、不当用户气泡显示）。
  为避免每轮重复写日志，现在每个会话只注入一次；注记落库后模型后续轮次仍可见。
- 宿主握手版本对齐 2.4.4。
- 验证（真实运行）：新会话 `session-79a711f0` 的 cwd 已是
  `C:\Users\a\Documents\deepseek-harness\default-workspace`；带 1×1 PNG 的指令送达模型
  （`user/message` 内含 `image/png 1×1, 70B, selftest.png`）。

## v1.7.3 — 2026-11-25

- **图片也能排队**：DSH 客户端未连接时发送带图片的指令，以前直接报"图片无法发送（无头引擎不支持图片）"；
  现在把图片 base64 一并存进指令队列，提示"指令（含 N 张图片）已排队，客户端连上后自动发送"，
  客户端连上后由 `flushPendingToHost()` 按条补发（文字 + 图片，保持原顺序）。
- **桥接热替换**：插件新增版本看门狗（每 20 秒对比 `bridge/bridge.mjs` 的 `VERSION` 与运行中 `/status`），
  发现不一致就自动 shutdown + 重启桥接——以后只改桥接代码不需要重启整个 DSH。
  首次升级到本版仍需要一次 DSH 重启（让新插件代码加载进来）。
- 宿主插件 2.4.3、桥接 1.3.6、安装包 1.7.3（扩展 1.4.2 不变）。

## v1.7.2 — 2026-11-25

- **修 headless 误续接桌面会话**：DSH 客户端断开时，桥接会用 one-shot headless runner 去续接当前会话，
  而带 agent preset 的会话（如 `cordis`）无法被 one-shot 组合，于是报
  `runs under agent preset "cordis", which the one-shot runner does not compose`。
  现在检测到会话有 agent preset 时**不再 headless 续接**，指令留在队列并提示
  "DSH 客户端未连接…指令已排队"，客户端连上后由 `flushPendingToHost()` 自动补发。
- 门禁逻辑抽到 `bridge/resume-gate.mjs`，`test/resume-gate.test.cjs` 覆盖 cordis/standard/无 preset。
- 宿主插件 2.4.2、桥接 1.3.5、安装包 1.7.2（扩展 1.4.2 不变）。

## v1.7.1 — 2026-11-25

- **修 v1.7.0 的工作区兜底缺陷**：兜底逻辑曾取"最近会话的 cwd"，而旧插件创建的会话本身就在
  `%USERPROFILE%\.dsh\profiles\desktop`，于是新会话继续落到 profile 目录、客户端仍看不到。
  现在只认 `storages/workspace.json` 里已注册的 workspace 路径：
  当前会话 cwd（已注册才用）→ 默认 workspace → 任一已注册 workspace → 空（交宿主默认）。
  抽成 `bridge/workdir.mjs` 并加单测。
- **ZCode 告警误报修复**：以前只看 8765 端口是否监听，只要 ZCode 主程序开着就告警；
  现在改为请求 `http://127.0.0.1:8765/status`，只有 `extension.connected === true`
  （ZCode 扩展真的连着）才提示，扩展停用后不再误报。
- 宿主插件 2.4.1、桥接 1.3.4、安装包 1.7.1（扩展 1.4.2 不变）。

## v1.7.0 — 2026-11-25

- **插件发起的会话现在落在客户端 workspace 里**：以前插件新建会话的 cwd 是 DSH profile 目录
  （`%USERPROFILE%\.dsh\profiles\desktop`），不属于任何客户端工作区，所以客户端"识别不到"，
  表现为一直重连。现在按「当前跟随会话 cwd → 默认 workspace path → 宿主默认目录」顺序解析，
  会话会出现在客户端对应工作区的会话列表里（侧边栏也会提示具体工作区）。
- **隐藏声明（不落库、客户端不显示）**：宿主拦截 `agent/pre-step`，把一行注记追加到本步进入模型的
  最后一条用户消息上：本会话由 DSH Edge Bridge 侧边栏发起、桥接是 `ws://127.0.0.1:8766/ws`、
  侧边栏已连接及扩展版本；8765 属于 ZCode 旧桥、禁止探测使用。这样模型不会再把插件当成 ZCode
  桥接、也不会去连旧端口。pre-step 只改当次请求输入，不写 Session log，UI 上看不到。
- 侧边栏"新建会话"的提示会带上工作区路径；`/sessions` 返回 `cwd` 便于核对。
- 宿主插件 2.4.0、桥接 1.3.3、安装包 1.7.0（扩展 1.4.2 不变）。
- 新增 `test/edge-marker.test.cjs`：校验注记结构、幂等、不伪造用户轮次、默认 workspace 存在。
- 发版脚本护栏：`scripts/finalize-release.cjs` 现在校验 tag 必须指向远端 main 的 HEAD，
  本地未推送（`local-not-pushed`）或 tag 指向旧提交（`tag-points-elsewhere`）时直接拒绝收尾，
  避免网络超时导致"release 打的是旧代码"。

## v1.6.1 — 2026-11-20

- 修复 v1.6.0 的接管顺序：Cordis 的 waterfall 按注册顺序执行，客户端应答者先注册，导致审批/提问仍被
  客户端先领走。两个监听改为 `ctx.on(name, handler, { prepend: true })`，侧边栏在线时先由侧边栏作答；
  其余情况（侧边栏离线、非当前会话、超时）仍原样交回客户端。
- 宿主插件 2.3.1、安装包 1.6.1（扩展 1.4.2 / 桥接 1.3.2 不变）。

## v1.6.0 — 2026-11-20

- **侧边栏可以直接审批与回答提问**（以前只能在 DSH 客户端窗口里做）：宿主插件拦截 DSH 的
  `approval/request` 与 `user-questions/request` 两个 waterfall，转发给侧边栏作答并回填结果；
  侧边栏不在线或不是当前跟随会话时原样 `next()`，客户端行为完全不变。
- 审批卡片照客户端 `ApprovalCard`：等待审批条 + "工具 X 请求越权执行" + 原因 + `拒绝` / `允许一次`
  按钮（回填 `'allowed-once' | 'rejected'`）；提问卡片照 `QuestionComposer`：单选 / 多选 / 自定义输入、
  审批式问题（接近 `intent.kind === 'approval'`）显示"允许/拒绝"两个选项，空答提交给出
  "请选择一个选项或填写自定义答案。"。
- 失败闭环：侧边栏断开或切换会话时取消挂起请求（审批回 `cancelled`）；审批 5 分钟、提问 10 分钟超时后
  回退给客户端应答者，不会把任务永久挂死。
- 扩展 1.4.2（`sidepanel-1.4.2.js/.css`，再次改名绕开 MV3 页面缓存）、桥接 1.3.2、宿主插件 2.3.0、安装包 1.6.0。

## v1.5.2 — 2026-11-19

- **长会话不再"一直往下加载"**：切换会话时只取最新一页（30 条）渲染，向上滚动再按需加载更早的一页
  （桥接 `GET /session/events?tail=N` 返回 `hasMore`/`total`），并保持阅读位置不跳动。
- **状态不再闪断**：桥接短暂重连时不再立刻弹"正在自动重连"横幅/禁用输入（1.2 秒防抖），恢复立即生效；
  发送时若恰好断线，自动等套接字恢复后重试一次，不用手动重发。
- **卡住自愈**：界面显示"正在执行"但 60 秒没有任何事件时向宿主核对真实状态；超过 5 分钟提示可停止/重开侧边栏。
- **ZCode 冲突可见**：桥接探测到 8765 上的 ZCode 桥接时，侧边栏会提示两套扩展抢同一调试会话（任务卡住的主因），
  建议停用 "ZCode Edge Bridge" 扩展。
- 扩展 1.4.1（静态资源改名以绕开 MV3 页面缓存：`sidepanel-1.4.1.js/.css`）、桥接 1.3.1、宿主插件 2.2.2、安装包 1.5.2。

## v1.5.1 — 2026-11-18

- 修复：侧边栏能拖入图片但发不出去。根因是宿主插件把桥接版本写死成 `1.2.5`，与
  `bridge.mjs` 的 `1.3.0` 不一致；重启 DSH 时插件无法识别旧桥、直接复用，导致图片在桥接层被丢。
  现在 `dsh-plugin/index.js` 的 `BRIDGE_VERSION` 与桥接同步为 `1.3.0`，插件会在启动时替换过期桥接。
- 宿主插件 2.2.1、安装包 1.5.1（扩展 1.4.0 / 桥接 1.3.0 不变）。

## v1.5.0 — 2026-11-18

- 侧边栏支持**发送图片**，逻辑对齐客户端 composer：`Ctrl/Cmd+V` 粘贴截图、拖入文件均可；
  附件以缩略图托盘显示，右上角 ✕ 移除；单张 ≤4MB、最多 8 张。
- 链路打通三层：扩展 → 桥接 `POST /session/say {text, images}` → 宿主 `hostPrompt`。宿主按
  DSH 的 `EncodedImageAttachment` 规范组装 `{type:'image', mediaType, data}` prompt content，
  并在发送前用部署的 `attachments.imageLimits` 预检（数量 / 单张 / 总量），拒绝时给出可读错误。
- 已发送的用户消息在侧边栏显示图片标签（名称 + 大小）；没有桌面宿主时明确拒绝图片，不静默丢弃。
- 扩展 1.4.0、桥接 1.3.0、插件 2.2.0、安装包 1.5.0。

## v1.4.4 — 2026-11-15

- 仓库根新增 `package.json` 与 `cordis.patch.yml`，声明 `dsh.bundle`，可直接通过
  `dsh plugin add github:airainal/dsh-edge-companion` 安装；插件实现仍在 `dsh-plugin/`。
- 扩展名统一为 **DSH Edge Bridge**（`short_name` 同步），扩展版本 1.3.4；manifest 名称
  与 Edge 扩展页、调试横幅一致。
- 安装包 1.4.4。

## v1.4.3 — 2026-10-29

- 模型选择触发器改成**新拟态（neumorphic）凸起胶囊**：同底色 + 双向柔光阴影，展开时转为内凹，
  菜单也使用新拟态卡片；不再是无框裸文字。
- 扩展 1.3.3（静态文件名同步更新）、桥接 1.2.5、插件 2.1.0、安装包 1.4.3。

## v1.4.2 — 2026-10-29

- 侧边栏模型选择改为**读取客户端真实目录**：`sessionController.modelCatalog()`，按 provider 分组展示
  DeepSeek Account 与自定义 provider（GLM 等）的全部模型，不再写死两个。
- 选择器改成**客户端同款二级菜单**：根页「模型 / 推理等级」，模型页按 API/provider 分组并带勾选，
  推理页列出当前模型的 Off / Low / High / Max 档位。
- 模型/推理选择**双端同步**：侧边栏切换立即写入当前会话并保存默认；客户端切换后，宿主每 2 秒读
  `modelSelection` projection，实时推回侧边栏。
- **新 provider/模型自动同步**：桥接每 20 秒刷新一次目录，打开选择器时强制刷新，无需改代码。
- 扩展 1.3.2、桥接 1.2.5、插件 2.1.0、安装包 1.4.2。

## v1.4.1 — 2026-10-28

- **合并回一个插件**：删除独立 `dsh-agent-host` bundle，把宿主通道并入 `dsh-plugin`（2.0.0）；
  仍是一个 **DSH Edge Bridge** 卡片，升级版本即可，不再新增插件。
- 停止交互改为 **DSH 同款**：不再新增停止按钮，发送键在执行中变成红色停止方块，结束后恢复箭头。
- **移除插件里的 Codex 开关**：顶部 `DSH · Codex` 只同步显示客户端状态，切换仍在 DSH 客户端完成。
- 修新建会话标题显示原始 `session-...`：无标题统一显示「新会话」。
- 去掉系统消息里会变方块的 emoji（新建/切换/停止/恢复）。
- 扩展静态资源改为带版本文件名（`sidepanel-1.3.1.*`），避免旧 sidepanel 页面继续跑旧 JS/CSS。
- 扩展 1.3.1、桥接 1.2.2、安装包 1.4.1。

## v1.4.0 — 2026-10-28

- 新增 **`dsh-agent-host`** 宿主插件：侧边栏直接驱动客户端**同一个** `sessionController`，不再另起 agent；
  - `prompt` 提交普通用户消息、`follow` 转发 durable 事件 + `assistant-stream` 文本/思考增量、`cancel` 停止同一 turn；
  - 侧边栏与客户端实时同步（逐字），停止状态一致；Codex 模式/权限/模型/上下文完全一致；
  - 侧边栏新增 **Codex 徽标 + 开关**，通过 `/codex-mode on|off` 与客户端全局状态双向同步。
- 侧边栏新增 **停止按钮**，执行中显示，调用同一个 `sessionController.cancel`。
- 桥接新增宿主通道与校验：多插件实例重连时用 `hostPing` 验活，只接纳 active context；旧连接只切换不关闭，避免重连风暴。
- 会话列表合并客户端 live 会话（不再受 headless cwd 过滤）；`ask_user_question` 会在侧边栏提示回客户端回答。
- 扩展 1.3.0、桥接 1.2.0、安装包 1.4.0（含 Word 教程与两个插件）。

## v1.3.0 — 2026-10-24

- 新增 **DSH 宿主插件** `dsh-plugin/`：随 DeepSeek Harness 启动自动拉起桥接（零操作）；
  - 使用 DSH 自带 Node 隐藏启动，注入 `DSHEDGE_CWD`；
  - DSH 退出后桥接继续运行，下次启动复用；重复实例检测到端口占用后安静退出。
- 新增 `安装插件.md`、`安装到新电脑.md` 插件优先安装流程。
- 新增一键分发脚本 `scripts/pack-portable.ps1`（带 SHA256SUMS）。
- 桥接支持 `DSHEDGE_CWD` 环境变量；端口占用时干净退出。
- README 重构：先讲原理再讲安装，补充架构图、界面截图与发布素材。

## v1.2.0 — 2026-10-24

- 侧边栏改为 **浅色主题**，新图标（蓝发鲸鱼少女）。
- 会话 / 模型选择改为 **自定义圆角浮层下拉**（阴影、层级、展开动画）。
- 会话与标签页切换加入 **横向滑动动画**。
- 输入框占位改为「询问DeepSeek Harness」；发送按钮换成居中 SVG 上箭头。
- 会话双向同步：侧边栏读取真实 DSH 会话日志（多帧 zstd 自解析），DSH 桌面版继续同一会话时消息回投侧边栏。
- 新增会话列表 / 接力 / 新建、模型切换（写回 `engines.json`）。
- 扩展 hello 带 `installId`，桥接握手后决定接管，避免多浏览器互相顶替。

## v1.1.0 — 2026-10-24

- 修复 `.cmd` 启动器在中文代码页下的解析问题（ASCII-only）。
- 新开/导航后回填真实标题；`GET /tabs/{id}/text`。
- 修复「读不到会话日志时回退到 --json 投影」的兜底与去重时序。

## v1.0.0 — 2026-10-23

- 首个可用版本：Edge MV3 扩展 + 零依赖桥接 + `dsh --profile headless` 自动唤醒；
- CDP 直通、快照、点击/填表/按键/滚动、截图、结构化爬题与填答验证。
