// DSH Agent Host - runs inside the DeepSeek Harness desktop process.
//
// It gives the Edge bridge a live control channel into the *same* desktop
// Session Controller the client uses:
//   - prompt:  submit a normal user turn to the selected session
//   - stop:    cancel that session's active turn (same as the client stop)
//   - follow:  stream durable events plus assistant text/reasoning deltas
//
// There is no second agent and no headless CLI in this path. When this plugin
// is connected the bridge routes sidebar actions here; the headless path stays
// as a fallback.
const PORT = Number(process.env.DSHEDGE_PORT || 8766);
const WS_URL = `ws://127.0.0.1:${PORT}/ws`;
const VERSION = "2.4.5";

let ctx = null;
let ws = null;
let connecting = false;
let helloOk = false;
let reconnectTimer = null;
let nextId = 1;
let generation = 0;
const pending = new Map(); // bridge request id -> {resolve,reject,timer}

let followAbort = null;
let followSessionId = null;
let followActive = false;
let running = false;

// ---- 审批 / 提问：让 Edge 侧边栏也能像客户端一样作答 ----
// 客户端通过 `approval/request`、`user-questions/request` 两个 waterfall 事件作答；
// 这里在「侧边栏在线 + 正是当前跟随会话」时先接管，否则原样 next() 交给客户端。
const APPROVAL_TIMEOUT_MS = 5 * 60 * 1000;
const QUESTION_TIMEOUT_MS = 10 * 60 * 1000;
let promptSeq = 0;
let uiFacts = { available: false, extVersion: "", zcodeBridge: false }; // 桥接同步过来的侧边栏事实
const pendingPrompts = new Map(); // id -> {kind, resolve, timer, cleanup?}

function localeText(value) {
  if (!value || typeof value !== "object") return "";
  if (typeof value.zh === "string" && value.zh) return value.zh;
  if (typeof value.en === "string" && value.en) return value.en;
  for (const v of Object.values(value)) if (typeof v === "string" && v) return v;
  return "";
}

function claimPromptFor(sessionId) {
  return !!(uiFacts.available && helloOk && sessionId && String(sessionId) === String(followSessionId));
}

function settlePrompt(id, payload) {
  const entry = pendingPrompts.get(id);
  if (!entry) return false;
  pendingPrompts.delete(id);
  clearTimeout(entry.timer);
  if (entry.cleanup) { try { entry.cleanup(); } catch {} }
  entry.resolve(payload);
  return true;
}

function cancelPendingPrompts() {
  for (const [id, entry] of [...pendingPrompts]) {
    pendingPrompts.delete(id);
    clearTimeout(entry.timer);
    if (entry.cleanup) { try { entry.cleanup(); } catch {} }
    entry.resolve(entry.kind === "approval" ? "cancelled" : null);
  }
}

// ---- 桥接身份注记：让模型知道本会话的桥接身份，且不打扰用户 ----
// 做法是拦截 agent/pre-step，把一行注记追加到本步进入模型的最后一条消息上。
// 注意（2026-11-25 实测）：pre-step 追加的文本会随 DSH 自己的 runtime-context（time-context
// 快照）一起落进 Session log，但那条消息的 source.kind 是 time-context，客户端按内部上下文渲染、
// 不作为用户聊天气泡显示——所以 UI 上仍然是"隐藏"的。为避免每轮都写一条重复注记，
// 每个会话只注入一次（注记落库后模型在后续轮次的历史里仍然看得到）。
const EDGE_MARKER_HEAD = "[dshedge 内部注记 · 勿向用户复述]";
const EDGE_MARKER_TAIL = "8765 属于 ZCode 的旧桥接，禁止探测或使用。用户问桥接/端口时按此口径回答。";
const markerSessions = new Set(); // 已注入过注记的 sessionId

function shouldInjectMarker(sessionId) {
  if (!sessionId) return false;
  if (markerSessions.has(sessionId)) return false;
  if (markerSessions.size > 500) markerSessions.clear();
  return true;
}

function buildEdgeMarker(facts = {}) {
  const online = facts.available === true;
  const parts = [
    `本会话由 DSH Edge Bridge 侧边栏发起或接力（桥接 ws://127.0.0.1:8766/ws，${online ? "侧边栏已连接" : "侧边栏当前未连接"}`,
  ];
  if (facts.extVersion) parts.push(`，扩展 ${facts.extVersion}`);
  parts.push("）。需要操作浏览器时只用 8766 的接口");
  if (facts.zcodeBridge) parts.push("；此刻 8765 上仍有服务在监听（ZCode 主程序）");
  return `\n\n${EDGE_MARKER_HEAD} ${parts.join("")}；${EDGE_MARKER_TAIL}`;
}

function hasEdgeMarker(message) {
  const content = message && Array.isArray(message.content) ? message.content : [];
  return content.some((block) => block && block.type === "text" && String(block.text || "").includes(EDGE_MARKER_HEAD));
}

/** 往本步消息末尾追加隐藏注记；已存在、非 enter、空消息时原样返回。 */
export function injectEdgeMarker(decision, facts = {}) {
  if (!decision || decision.kind !== "enter") return decision;
  const messages = Array.isArray(decision.messages) ? decision.messages : [];
  if (!messages.length) return decision;
  if (messages.some(hasEdgeMarker)) return decision;
  const last = messages[messages.length - 1];
  if (!last || typeof last !== "object") return decision;
  const content = Array.isArray(last.content) ? last.content : [];
  const marker = { type: "text", text: buildEdgeMarker(facts) };
  return { ...decision, messages: [...messages.slice(0, -1), { ...last, content: [...content, marker] }] };
}

export { buildEdgeMarker };

function registerPromptBridge(rootCtx) {
  if (!rootCtx || typeof rootCtx.on !== "function") return;
  try {
    // prepend：必须排在客户端自己的应答者之前，否则请求会被客户端先领走。
    const on = (name, handler) => rootCtx.on(name, handler, { prepend: true });
    on("approval/request", async (req, next) => {
      try {
        const sessionId = req && req.agent ? String(req.agent.id) : "";
        if (!claimPromptFor(sessionId)) return await next();
        if (req.signal && req.signal.aborted) return "cancelled";
        const id = `ap-${Date.now()}-${++promptSeq}`;
        const decision = await new Promise((resolve) => {
          const timer = setTimeout(() => { pendingPrompts.delete(id); resolve("cancelled"); }, APPROVAL_TIMEOUT_MS);
          pendingPrompts.set(id, { kind: "approval", resolve, timer });
          const delivered = send("hostApproval", {
            id,
            sessionId,
            toolName: String(req.toolName || ""),
            callId: req.callId ? String(req.callId) : "",
            reason: localeText(req.displayReason) || String(req.reason || ""),
            expiresAt: Date.now() + APPROVAL_TIMEOUT_MS,
          });
          if (!delivered) { pendingPrompts.delete(id); clearTimeout(timer); resolve("cancelled"); }
        });
        return decision === "allowed-once" || decision === "rejected" || decision === "cancelled" ? decision : "cancelled";
      } catch (e) {
        log("approval bridge error:", String(e && e.message ? e.message : e));
        return "cancelled";
      }
    });

    on("user-questions/request", async (request, next) => {
      try {
        const sessionId = request && request.agent ? String(request.agent.id) : "";
        if (!claimPromptFor(sessionId)) return await next();
        const questions = Array.isArray(request.questions) ? request.questions : [];
        if (!questions.length) return await next();
        if (request.signal && request.signal.aborted) return await next();
        const id = `q-${Date.now()}-${++promptSeq}`;
        const answer = await new Promise((resolve) => {
          const timer = setTimeout(() => { pendingPrompts.delete(id); resolve(null); }, QUESTION_TIMEOUT_MS);
          const onAbort = () => { pendingPrompts.delete(id); clearTimeout(timer); resolve(null); };
          let cleanup;
          try {
            if (request.signal && request.signal.addEventListener) {
              request.signal.addEventListener("abort", onAbort, { once: true });
              cleanup = () => request.signal.removeEventListener("abort", onAbort);
            }
          } catch {}
          pendingPrompts.set(id, { kind: "question", resolve, timer, cleanup });
          const delivered = send("hostQuestion", {
            id,
            sessionId,
            callId: request.wait && request.wait.callId ? String(request.wait.callId) : "",
            timed: !!(request.wait && request.wait.timed),
            questions: questions.map((q) => ({
              id: String(q.id || ""),
              question: String(q.question || ""),
              detail: q.detail ? String(q.detail) : "",
              header: q.header ? String(q.header) : "",
              multiSelect: q.multiSelect === true,
              options: (Array.isArray(q.options) ? q.options : []).map((o) => ({
                label: String(o.label || ""),
                description: o.description ? String(o.description) : "",
              })),
              intent: q.intent ? {
                kind: String(q.intent.kind || ""),
                approve: String(q.intent.approve || ""),
                reject: String(q.intent.reject || ""),
                always: String(q.intent.always || ""),
                question: localeText(q.intent.display && q.intent.display.question),
                detail: localeText(q.intent.display && q.intent.display.detail),
                approveLabel: localeText(q.intent.display && q.intent.display.approve),
              } : null,
            })),
          });
          if (!delivered) { pendingPrompts.delete(id); clearTimeout(timer); resolve(null); }
        });
        if (!answer) return await next();
        return answer;
      } catch (e) {
        log("question bridge error:", String(e && e.message ? e.message : e));
        return await next();
      }
    });
    on("agent/pre-step", async (payload, next) => {
      const decision = await next();
      try {
        const sessionId = payload && payload.agent ? String(payload.agent.id) : "";
        if (!sessionId || sessionId !== String(followSessionId)) return decision;
        if (!uiFacts.available) return decision;
        if (!shouldInjectMarker(sessionId)) return decision;
        const injected = injectEdgeMarker(decision, uiFacts);
        if (injected !== decision) markerSessions.add(sessionId);
        return injected;
      } catch (e) {
        log("pre-step marker failed:", String(e && e.message ? e.message : e));
        return decision;
      }
    });

    log("prompt bridge armed (approval + user questions)");
  } catch (e) {
    log("prompt bridge registration failed:", String(e && e.message ? e.message : e));
  }
}

function log(...args) {
  console.log("[dsh-agent-host]", ...args);
}

function scheduleReconnect(my) {
  if (my !== generation || reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    if (my === generation) connect(my);
  }, 1500);
}

function send(method, params = {}) {
  if (!ws || ws.readyState !== 1) return false;
  try {
    ws.send(JSON.stringify({ method, params }));
    return true;
  } catch {
    return false;
  }
}

function connect(my) {
  if (my !== generation) return;
  if (connecting || helloOk) return;
  if (typeof WebSocket === "undefined") {
    log("WebSocket global unavailable in this runtime; retrying");
    scheduleReconnect(my);
    return;
  }
  connecting = true;
  let socket;
  try {
    socket = new WebSocket(WS_URL);
  } catch (e) {
    connecting = false;
    log("connect failed:", String(e && e.message ? e.message : e));
    scheduleReconnect(my);
    return;
  }
  ws = socket;

  socket.onopen = () => {
    if (my !== generation) { try { socket.close(); } catch {} return; }
    connecting = false;
    log("bridge connected, sending agentHello");
    socket.send(JSON.stringify({
      id: nextId++,
      method: "agentHello",
      params: { version: VERSION, capabilities: { stream: true, stop: true, codex: true } },
    }));
  };

  socket.onmessage = (event) => {
    if (my !== generation) return;
    let msg;
    try { msg = JSON.parse(typeof event.data === "string" ? event.data : String(event.data)); } catch { return; }
    if (!msg || typeof msg !== "object") return;

    if (msg.id != null && msg.method == null && (msg.result !== undefined || msg.error !== undefined)) {
      const p = pending.get(msg.id);
      if (p) {
        pending.delete(msg.id);
        clearTimeout(p.timer);
        if (msg.error !== undefined) p.reject(new Error(String(msg.error)));
        else p.resolve(msg.result);
      }
      return;
    }

    if (msg.method === "agentReady") {
      if (my !== generation) return;
      helloOk = true;
      log("bridge accepted agent host");
      send("hostStatus", { sessionId: followSessionId, running });
      void refreshCodex();
      return;
    }

    if (msg.method && msg.id != null) {
      handleBridgeRequest(msg.method, msg.params || {})
        .then((result) => {
          if (my === generation && ws && ws.readyState === 1) ws.send(JSON.stringify({ id: msg.id, result }));
        })
        .catch((e) => {
          const text = String(e && e.message ? e.message : e);
          if (my === generation && ws && ws.readyState === 1) {
            ws.send(JSON.stringify({ id: msg.id, error: text }));
          }
          if (/inactive context|required service|disposed/i.test(text)) {
            log("plugin context inactive; dropping host socket");
            try { socket.close(); } catch {}
          }
        });
    }
  };

  socket.onclose = () => {
    if (my !== generation) return;
    connecting = false;
    helloOk = false;
    uiAvailable = false;
    cancelPendingPrompts();
    ws = null;
    followAbort?.abort();
    followAbort = null;
    log("bridge disconnected; will retry");
    scheduleReconnect(my);
  };

  socket.onerror = () => {
    // onclose handles reconnection
  };
}

async function handleBridgeRequest(method, params) {
  switch (method) {
    case "hostPing": {
      await ctx.sessionController.list({}, AbortSignal.timeout(3000));
      return { pong: true };
    }
    case "hostCreate": {
      const sessionId = await createSession(String(params.cwd || ""));
      return { sessionId };
    }
    case "hostPrompt": {
      const sessionId = String(params.sessionId || "");
      await prompt(String(params.text || ""), sessionId, params.images, String(params.cwd || ""));
      return { accepted: true, sessionId: followSessionId };
    }
    case "hostPromptAnswer": {
      const id = String(params.id || "");
      const entry = pendingPrompts.get(id);
      if (!entry) return { ok: false, error: "not pending" };
      if (entry.kind === "approval") {
        settlePrompt(id, String(params.decision || "cancelled"));
      } else {
        const answer = params.answer;
        if (!answer || typeof answer !== "object" || !Array.isArray(answer.answers)) {
          return { ok: false, error: "bad answer" };
        }
        settlePrompt(id, { answers: answer.answers });
      }
      log("prompt answered from side panel", entry.kind);
      return { ok: true };
    }
    case "hostUi": {
      uiFacts = {
        available: params.available === true,
        extVersion: String(params.extVersion || ""),
        zcodeBridge: params.zcodeBridge === true,
      };
      return { ok: true };
    }
    case "hostStop": {
      const sessionId = String(params.sessionId || followSessionId || "");
      return await stop(sessionId);
    }
    case "hostFollow": {
      const sessionId = String(params.sessionId || "");
      await follow(sessionId, true);
      return { following: followSessionId };
    }
    case "hostSessions": {
      const value = await ctx.sessionController.list({}, AbortSignal.timeout(8000));
      const items = (value.items || []).map((s) => ({
        sessionId: s.sessionId,
        running: s.running === true,
        agentAvailable: s.agentAvailable === true,
        blank: s.blank === true,
        updatedAt: s.updatedAt,
        cwd: s.cwd,
      }));
      return { sessions: items };
    }
    case "hostModels": {
      return await hostModels(params.force === true);
    }
    case "hostModelSet": {
      return await hostModelSet(params);
    }
    case "hostStatus": {
      const live = await refreshRunning();
      return { sessionId: followSessionId, running: live, codex: await readCodex() };
    }
    default:
      throw new Error("unknown host request: " + method);
  }
}

async function createSession(cwdOverride = "") {
  const preset = await ctx.agentPresets.resolve().catch(() => undefined);
  // cwd 决定会话属于哪个 workspace：必须落在客户端已注册的工作区里，
  // 否则客户端会话列表根本看不到它（表现为"插件新建的会话识别不到"）。
  const preferred = String(cwdOverride || "").trim();
  const cwd = preferred || ctx.workingDirectory?.defaultDirectory || undefined;
  const request = {};
  if (cwd) request.cwd = cwd;
  if (preset && preset.id) request.agentPreset = preset.id;
  const created = await ctx.sessionController.create(request);
  const sessionId = String(created.sessionId);
  log("created desktop session", sessionId, "preset", created.agentPreset || preset?.id || "?", "cwd", cwd || "?");
  running = false;
  await follow(sessionId);
  send("hostSession", { sessionId, preset: created.agentPreset || preset?.id || "" });
  return sessionId;
}

async function sessionRunning(id) {
  if (!id) return false;
  try {
    const value = await ctx.sessionController.list({}, AbortSignal.timeout(4000));
    const row = (value.items || []).find((s) => s.sessionId === id);
    if (row) return row.running === true;
  } catch {}
  return running;
}

async function refreshRunning() {
  if (!followSessionId) return running;
  const next = await sessionRunning(followSessionId);
  if (next !== running) {
    running = next;
    send("hostStatus", { sessionId: followSessionId, running: next, codex: await readCodex() });
  }
  return running;
}

// Prompt image parts follow the Host contract (`EncodedImageAttachment`):
// `{ type: 'image', mediaType, data: <canonical base64>, name? }`. The Client
// composer sends the same shape, so the side panel reuses it verbatim.
const PROMPT_IMAGE_MEDIA_TYPES = new Set(["image/png", "image/jpeg", "image/webp", "image/gif"]);
const PROMPT_MAX_IMAGES = 8;

function base64Bytes(data) {
  const clean = String(data || "");
  if (!clean) return 0;
  const padding = clean.endsWith("==") ? 2 : clean.endsWith("=") ? 1 : 0;
  return Math.max(0, Math.floor((clean.length * 3) / 4) - padding);
}

/** Keep only parts this Host can admit, in submission order; text first, then images. */
function buildPromptContent(text, images) {
  const parts = [];
  const trimmed = typeof text === "string" ? text.trim() : "";
  if (trimmed) parts.push({ type: "text", text: trimmed });
  const list = Array.isArray(images) ? images : [];
  for (const raw of list) {
    if (parts.filter((p) => p.type === "image").length >= PROMPT_MAX_IMAGES) break;
    if (!raw || typeof raw !== "object") continue;
    const mediaType = typeof raw.mediaType === "string" ? raw.mediaType.trim().toLowerCase() : "";
    const data = typeof raw.data === "string" ? raw.data.replace(/^data:[^;]+;base64,/, "") : "";
    if (!PROMPT_IMAGE_MEDIA_TYPES.has(mediaType) || !data) continue;
    const name = typeof raw.name === "string" && raw.name.trim() ? raw.name.trim().slice(0, 120) : undefined;
    parts.push(name ? { type: "image", mediaType, data, name } : { type: "image", mediaType, data });
  }
  if (!parts.length) throw new Error("prompt 既没有文本也没有可用图片");
  return parts;
}

/** Pre-flight the deployment's image policy so a refusal is a readable message. */
function checkImageLimits(content) {
  const limits = ctx.attachments?.imageLimits;
  if (!limits) return;
  const images = content.filter((p) => p.type === "image");
  if (images.length > limits.maxImagesPerMessage) {
    throw new Error(`图片数量超限：最多 ${limits.maxImagesPerMessage} 张`);
  }
  let total = 0;
  for (const part of images) {
    const bytes = base64Bytes(part.data);
    if (bytes > limits.maxImageBytes) {
      throw new Error(`单张图片过大：上限 ${Math.round(limits.maxImageBytes / 1024 / 1024)}MB，当前 ${(bytes / 1024 / 1024).toFixed(1)}MB`);
    }
    total += bytes;
  }
  if (total > limits.maxMessageImageBytes) {
    throw new Error(`图片总量过大：上限 ${Math.round(limits.maxMessageImageBytes / 1024 / 1024)}MB，当前 ${(total / 1024 / 1024).toFixed(1)}MB`);
  }
}

async function prompt(text, sessionId, images, cwd = "") {
  const id = sessionId || await createSession(cwd);
  const resolved = await ctx.sessionController.resolveAgent(id);
  if (resolved && resolved.error) {
    throw new Error("session resolve failed: " + String(resolved.error.code || resolved.error.message || resolved.error));
  }

  // Interrupt-style input: if the turn is actually running, stop it first so the
  // new message is admitted immediately and becomes visible in the client.
  try {
    if (await sessionRunning(id)) {
      log("interrupting running turn before prompt", id);
      await ctx.sessionController.cancel({ sessionId: id }).catch((e) => log("cancel before prompt failed:", String(e && e.message ? e.message : e)));
      for (let i = 0; i < 32; i++) {
        await new Promise((r) => setTimeout(r, 250));
        if (!(await sessionRunning(id))) break;
      }
    }
  } catch (e) {
    log("interrupt before prompt threw:", String(e && e.message ? e.message : e));
  }

  const content = buildPromptContent(text, images);
  checkImageLimits(content);
  const requestId = `edge-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  await ctx.sessionController.prompt({
    requestId,
    sessionId: id,
    mode: "queue",
    content,
  }, AbortSignal.timeout(60000));
  running = true;
  send("hostStatus", { sessionId: id, running: true, codex: await readCodex() });
  await follow(id, true);
  const imageCount = content.filter((p) => p.type === "image").length;
  log("prompt accepted", id, text.slice(0, 60), imageCount ? `+${imageCount} image(s)` : "");
}

async function stop(sessionId) {
  const id = sessionId || followSessionId;
  if (!id) return { accepted: false, reason: "no session" };
  const result = await ctx.sessionController.cancel({ sessionId: id });
  running = false;
  send("hostStatus", { sessionId: id, running: false });
  log("cancel requested", id);
  return result;
}

async function follow(sessionId, force = false) {
  if (!sessionId) return;
  if (!force && followSessionId === sessionId && followAbort && !followAbort.signal.aborted && followActive) return;

  try {
    const resolved = await ctx.sessionController.resolveAgent(sessionId);
    if (resolved && resolved.error) log("resolve before follow failed:", String(resolved.error.code || resolved.error.message || resolved.error));
  } catch (e) {
    log("resolve before follow threw:", String(e && e.message ? e.message : e));
  }

  followAbort?.abort();
  followAbort = new AbortController();
  followSessionId = sessionId;
  followActive = true;
  cancelPendingPrompts();
  modelState = null;
  const my = followAbort;
  const signal = my.signal;
  log("following", sessionId);
  refreshModelState(true).catch(() => {});
  refreshRunning().catch(() => {});

  (async () => {
    try {
      const frames = ctx.sessionController.follow({
        address: { kind: "session", sessionId },
        assistantStream: true,
        maxMessages: 120,
      }, signal);
      for await (const frame of frames) {
        if (signal.aborted) break;
        send("hostFrame", { sessionId, frame });
        if (frame && frame.type === "snapshot" && frame.projections && frame.projections.values) {
          updateModelState(frame.projections.values.modelSelection);
        }
        const event = frame && frame.type === "event" ? frame.event : null;
        // 客户端切换模型/推理等级会写入 model/selection 事件；只跟 snapshot 会导致
        // 侧边栏一直显示旧等级（例如客户端已 High，插件仍停在 Max）。
        if (event && event.type === "model/selection") {
          updateModelState(event.data);
        }
        if (event && event.type === "turn/start") {
          running = true;
          send("hostStatus", { sessionId, running: true });
        } else if (event && event.type === "turn/end") {
          running = false;
          send("hostStatus", { sessionId, running: false });
        }
      }
    } catch (e) {
      if (!signal.aborted) {
        log("follow ended:", String(e && e.message ? e.message : e));
        send("hostError", { sessionId, error: String(e && e.message ? e.message : e) });
      }
    } finally {
      if (followAbort === my) followActive = false;
    }
  })();
}

let codexCache = { at: 0, enabled: false };

// ---- model catalog / current selection (synced with the desktop client) ----
let modelState = null; // { provider, model, reasoningEffort? }
let modelCatalogCache = { at: 0, value: null };
let modelSetAt = 0;

function sameSelection(a, b) {
  if (!a || !b) return a === b;
  return a.provider === b.provider && a.model === b.model && (a.reasoningEffort || "") === (b.reasoningEffort || "");
}

function cleanSelection(value) {
  if (!value || typeof value !== "object") return null;
  const provider = String(value.provider || "");
  const model = String(value.model || "");
  if (!provider || !model) return null;
  const out = { provider, model };
  if (value.reasoningEffort !== undefined && value.reasoningEffort !== null && String(value.reasoningEffort) !== "") {
    out.reasoningEffort = String(value.reasoningEffort);
  }
  return out;
}

function updateModelState(next, force = false) {
  const sel = cleanSelection(next);
  if (!sel) return;
  if (!force && sameSelection(sel, modelState)) return;
  modelState = sel;
  send("hostModel", { current: sel });
}

async function readModelSelection() {
  if (!followSessionId) return null;
  try {
    const res = await ctx.sessionController.projections({ sessionId: followSessionId }, AbortSignal.timeout(4000));
    const values = res && res.values ? res.values : null;
    return cleanSelection(values && values.modelSelection);
  } catch {
    return null;
  }
}

async function refreshModelState(force = false) {
  if (!helloOk || !followSessionId) return;
  if (!force && Date.now() - modelSetAt < 3000) return; // our own selection may not be projected yet
  const sel = await readModelSelection();
  if (sel) updateModelState(sel, force);
}

function normalizeModelCatalog(cat) {
  const groups = (cat && Array.isArray(cat.groups) ? cat.groups : []).map((g) => ({
    id: String(g.id || ""),
    name: String(g.name || g.id || ""),
    models: (Array.isArray(g.models) ? g.models : []).map((m) => {
      const model = {
        id: String(m.id || ""),
        name: String(m.name || m.id || ""),
      };
      if (m.description) model.description = String(m.description);
      if (m.reasoning && Array.isArray(m.reasoning.efforts)) {
        model.reasoning = {
          defaultEffort: m.reasoning.defaultEffort ? String(m.reasoning.defaultEffort) : undefined,
          efforts: m.reasoning.efforts.map((e) => ({ id: String(e.id || ""), name: String(e.name || e.id || "") })),
        };
      }
      return model;
    }),
  }));
  const out = { groups };
  const def = cleanSelection(cat && cat.default);
  if (def) out.default = def;
  if (cat && Array.isArray(cat.failures)) {
    out.failures = cat.failures.map((f) => ({ id: String(f.id || ""), name: String(f.name || ""), message: String(f.message || "") }));
  }
  return out;
}

async function hostModels(force = false) {
  if (force || !modelCatalogCache.value || Date.now() - modelCatalogCache.at > 15000) {
    const cat = await ctx.sessionController.modelCatalog();
    modelCatalogCache = { at: Date.now(), value: normalizeModelCatalog(cat) };
  }
  const current = modelState || (await readModelSelection()) || modelCatalogCache.value.default || null;
  if (current && !modelState) modelState = current;
  return { catalog: modelCatalogCache.value, current };
}

async function hostModelSet(params) {
  if (!followSessionId) throw new Error("no active session");
  const provider = String(params.provider || "");
  const model = String(params.model || "");
  if (!provider || !model) throw new Error("provider and model are required");
  const request = { sessionId: followSessionId, provider, model };
  if (params.reasoningEffort !== undefined && params.reasoningEffort !== null && String(params.reasoningEffort) !== "") {
    request.reasoningEffort = String(params.reasoningEffort);
  }
  const result = await ctx.sessionController.selectModel(request);
  const selected = cleanSelection(result && result.selected) || cleanSelection(request);
  modelSetAt = Date.now();
  updateModelState(selected, true);
  modelCatalogCache = { at: 0, value: null };
  log("model selected", selected.provider + "/" + selected.model + (selected.reasoningEffort ? " effort=" + selected.reasoningEffort : ""));
  return { current: modelState };
}

async function readCodex() {
  if (Date.now() - codexCache.at < 3000) return codexCache.enabled;
  let enabled = false;
  try {
    const id = followSessionId;
    if (id) {
      const resolved = await ctx.sessionController.resolveAgent(id);
      const agent = resolved && resolved.agent;
      if (agent) {
        const preset = ctx.permissionPresets.current(agent.session);
        enabled = String(preset || "").startsWith("codex-");
      }
    }
  } catch {}
  codexCache = { at: Date.now(), enabled };
  return enabled;
}

async function refreshCodex() {
  const enabled = await readCodex();
  send("hostCodex", { enabled });
}

export function startAgentHost(pluginCtx) {
  const get = (name) => {
    try {
      if (pluginCtx[name]) return pluginCtx[name];
      return pluginCtx.get ? pluginCtx.get(name) : undefined;
    } catch {
      return undefined;
    }
  };
  const sessionController = get("sessionController");
  if (!sessionController) {
    log("no sessionController in this profile; headless fallback only");
    return;
  }
  ctx = {
    sessionController,
    agentPresets: get("agentPresets"),
    permissionPresets: get("permissionPresets"),
    workingDirectory: get("workingDirectory"),
  };

  generation += 1;
  const my = generation;

  registerPromptBridge(pluginCtx);

  // A HMR reload reuses this module. Tear down the previous socket so the
  // bridge never keeps routing to a disposed plugin context.
  try { ws?.close(); } catch {}
  ws = null;
  helloOk = false;
  connecting = false;
  pending.clear();
  followAbort?.abort();
  followAbort = null;
  followSessionId = null;
  running = false;
  codexCache = { at: 0, enabled: false };
  modelState = null;
  modelCatalogCache = { at: 0, value: null };

  log("starting; bridge", WS_URL);
  connect(my);

  const timer = setInterval(async () => {
    if (my !== generation || !helloOk) return;
    try {
      const value = await ctx.sessionController.list({}, AbortSignal.timeout(5000));
      const sessions = (value.items || []).map((s) => ({
        sessionId: s.sessionId,
        running: s.running === true,
        agentAvailable: s.agentAvailable === true,
        blank: s.blank === true,
        updatedAt: s.updatedAt,
        cwd: s.cwd,
      }));
      send("hostSessions", { sessions });
      const row = (value.items || []).find((s) => s.sessionId === followSessionId);
      if (row && (row.running === true) !== running) {
        running = row.running === true;
        send("hostStatus", { sessionId: followSessionId, running, codex: await readCodex() });
      }
    } catch {}
  }, 5000);

  // Model/reasoning is session-projected; poll keeps the side panel in sync
  // when the desktop client changes it (selection writes no session event).
  const modelTimer = setInterval(() => {
    if (my !== generation || !helloOk || !followSessionId) return;
    refreshModelState(false).catch(() => {});
  }, 2000);

  pluginCtx.effect(() => () => {
    if (my !== generation) return;
    generation += 1; // make the closing socket's onclose stop reconnecting
    clearInterval(timer);
    clearInterval(modelTimer);
    try { ws?.close(); } catch {}
    followAbort?.abort();
  }, "dsh-edge-bridge agent host lifecycle");
}
