# dsh-plugin-toggle

[English](README.md) | 中文

DeepSeek Harness (DSH) Web GUI 的**插件开关**面板。

打开 **设置 → 插件 → 插件开关**。每个已加载插件一张卡片，包含：

- 简述（来自该包 `package.json` 的 `description`）
- 已启用 / 已禁用 + 运行阶段（运行中 / 待启动 / 失败 / …）
- **启动 / 关闭**（仅运行时生效，**不改写** `cordis.yml`）
- 模糊搜索（名称 / 模块 / ID / 简述；支持子串与子序列）

核心 / 界面插件（`webserver`、`connection`、`session`、`agent` 等）标为 **核心插件**，禁止从此处关闭，避免页面失联。

## 安装

```sh
dsh plugin --profile web add github:DamonKoy/dsh-plugin-toggle
```

重启 `dsh web`，打开 **设置 → 插件 → 插件开关**。

或把仓库加进 profile 依赖并声明 bundle：

```json
{
  "dependencies": {
    "dsh-plugin-toggle": "github:DamonKoy/dsh-plugin-toggle"
  },
  "dsh": {
    "profile": {
      "bundles": ["dsh-plugin-toggle"]
    }
  }
}
```

在 profile 目录执行 `pnpm install`，然后重启 `dsh web`。

## 你会得到

| 功能 | 说明 |
|---|---|
| 插件卡片 | 标题、条目 ID、简述、启用标签、运行阶段 |
| 分类分组 | 核心系统 / 界面增强 / 主题外观 / 工具与集成 / 娱乐 / 其他，可折叠 |
| 组内排序 | 可切换的在前 → 按状态（运行中优先）→ 按名称 |
| 模糊搜索 | 关键词按子串或子序列跨字段匹配（含分类） |
| 启动 / 关闭 | `entry.update({ disabled })`，仅运行时，不触发 `tree.write()` |
| 核心保护 | 界面/运行时条目禁止关闭（按 id 与模块名双重判定）；其余关闭需两步确认 |
| 使用记录 | 每次启停持久化到 `~/.dsh/dsh-plugin-toggle.jsonl`（保留最近 1000 条），折叠式「使用记录」分区展示 |
| 持久化 | 作为组合插件安装，`dsh web` 重启后仍在 |

## HTTP 接口（同源）

| 方法 | 路径 | 作用 |
|---|---|---|
| `GET` | `/plugin-toggle/list` | `{ entries: [...] }` |
| `GET` | `/plugin-toggle/logs` | `{ records: [...] }`（最近使用记录，新的在前） |
| `POST` | `/plugin-toggle/set` | `{ entryId, enabled }` → `{ ok, entry? \| message? }` |

`POST` 仅接受同源请求。

## 目录

```
dsh-plugin-toggle/
  lib/index.js          宿主：基于 Cordis Loader 的 list / set 路由
  client/client.js      客户端：设置页标签（ModuleLoader factory）
  cordis.patch.yml      Bundle 插入（`id: plugin-toggle`）
```

客户端 `exports.inject` 必须是**服务名** `slots`（不是包名）。写成包名会导致 client fiber 永久 pending。

## 许可

MIT
