window.__ModuleLoader__.load({ id: "dsh-plugin-toggle", factory: (require) => {
  "use strict";

  var module = { exports: {} };
  var exports = module.exports;
  Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
  var react = require("react");

  var name = "dsh-plugin-toggle";
  // Cordis Client Plugin inject: service names on ctx (NOT package names).
  // Package-name injects park the fiber forever (web boot pending).
  var inject = ["slots"];

  var CSS = [
    ".pst-root{display:flex;flex-direction:column;gap:10px;padding:4px 2px;font-size:13px;color:var(--dsw-alias-label-primary)}",
    ".pst-tip{margin:0;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:1.6}",
    ".pst-search{display:flex;align-items:center;gap:6px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;padding:6px 10px;background:var(--dsw-alias-bg-layer-1)}",
    ".pst-search input{flex:1;min-width:0;border:none;outline:none;background:transparent;color:var(--dsw-alias-label-primary);font-size:13px}",
    ".pst-search input::placeholder{color:var(--dsw-alias-label-secondary)}",
    ".pst-searchIcon{color:var(--dsw-alias-label-secondary);font-size:13px}",
    ".pst-header{display:flex;align-items:center;justify-content:space-between;gap:8px}",
    ".pst-count{color:var(--dsw-alias-label-secondary);font-size:12px}",
    ".pst-note{color:var(--dsw-alias-label-secondary);font-size:13px;padding:12px 0}",
    ".pst-group{border:1px solid var(--dsw-alias-border-l1);border-radius:8px;overflow:hidden;background:var(--dsw-alias-bg-layer-1)}",
    ".pst-group + .pst-group{margin-top:10px}",
    ".pst-groupHead{display:flex;align-items:center;gap:8px;width:100%;padding:9px 12px;border:none;background:transparent;color:var(--dsw-alias-label-primary);font-size:13px;font-weight:600;cursor:pointer;text-align:left}",
    ".pst-groupHead:hover{background:var(--dsw-alias-bg-layer-2)}",
    ".pst-groupName{flex:1}",
    ".pst-groupCount{color:var(--dsw-alias-label-secondary);font-size:12px;font-weight:400}",
    ".pst-chevron{transition:transform .15s ease;color:var(--dsw-alias-label-secondary);font-size:11px}",
    ".pst-chevron.pst-open{transform:rotate(180deg)}",
    ".pst-list{list-style:none;margin:0;padding:0;border-top:1px solid var(--dsw-alias-border-l1)}",
    ".pst-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 12px;border-bottom:1px solid var(--dsw-alias-border-l1)}",
    ".pst-row:last-child{border-bottom:none}",
    ".pst-rowMain{display:flex;flex-direction:column;gap:4px;min-width:0}",
    ".pst-rowTitle{display:flex;align-items:baseline;gap:8px}",
    ".pst-name{font-size:13px;font-weight:600}",
    ".pst-id{color:var(--dsw-alias-label-secondary);font-size:11px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
    ".pst-desc{margin:0;font-size:12px;line-height:1.5;color:var(--dsw-alias-label-secondary);overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-word}",
    ".pst-rowMeta{display:flex;align-items:center;gap:10px;font-size:12px}",
    ".pst-status{color:var(--dsw-alias-state-success-primary)}",
    ".pst-status[data-enabled='false']{color:var(--dsw-alias-label-secondary)}",
    ".pst-phase{display:inline-flex;align-items:center;gap:5px;color:var(--dsw-alias-label-secondary)}",
    ".pst-dot{width:7px;height:7px;border-radius:50%;background:var(--dsw-alias-label-secondary);display:inline-block}",
    ".pst-ok .pst-dot{background:var(--dsw-alias-state-success-primary)}",
    ".pst-err .pst-dot{background:var(--dsw-alias-state-error-primary)}",
    ".pst-warn .pst-dot{background:var(--dsw-alias-state-warn-primary)}",
    ".pst-info .pst-dot{background:var(--dsw-alias-brand-primary)}",
    ".pst-idle .pst-dot{background:var(--dsw-alias-border-l2)}",
    ".pst-rowAction{flex-shrink:0}",
    ".pst-btn{border:1px solid var(--dsw-alias-border-l2);background:transparent;color:var(--dsw-alias-label-primary);border-radius:6px;padding:4px 12px;font-size:12px;cursor:pointer}",
    ".pst-btn:disabled{opacity:.5;cursor:default}",
    ".pst-btn-primary{border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-brand-primary)}",
    ".pst-btn-danger{border-color:var(--dsw-alias-state-error-primary);color:var(--dsw-alias-state-error-primary)}",
    ".pst-btn-ghost{color:var(--dsw-alias-label-secondary)}",
    ".pst-badge{font-size:11px;color:var(--dsw-alias-label-secondary);border:1px solid var(--dsw-alias-border-l2);border-radius:999px;padding:2px 10px}",
    ".pst-confirm{display:inline-flex;align-items:center;gap:6px}",
    ".pst-confirmText{font-size:12px;color:var(--dsw-alias-state-error-primary);margin-right:2px}",
    ".pst-rowError{margin:0;font-size:12px;color:var(--dsw-alias-state-error-primary)}"
  ].join("\n");

  var PHASE_LABELS = { active: "运行中", pending: "待启动", loading: "加载中", failed: "失败", idle: "未运行", unloading: "卸载中" };
  var PHASE_CLASS = { active: "pst-ok", pending: "pst-info", loading: "pst-warn", failed: "pst-err", idle: "pst-idle", unloading: "pst-warn" };

  // 分类展示顺序与标签（客户端按 moduleName + description 计算；宿主端若已下发 category 则优先使用）。
  var CATEGORIES = [
    { key: "core", label: "核心系统（官方）" },
    { key: "ui", label: "界面增强" },
    { key: "theme", label: "主题外观" },
    { key: "tools", label: "工具与集成" },
    { key: "fun", label: "娱乐" },
    { key: "other", label: "其他" }
  ];

  // 状态排序权重：运行中优先，其次待启动/加载中，再失败/卸载中，最后未运行。
  var STATUS_RANK = { active: 0, loading: 1, pending: 1, failed: 2, unloading: 3, idle: 4 };

  function statusRank(entry) {
    var r = STATUS_RANK[entry.phase];
    return r === undefined ? 4 : r;
  }

  function fmtTime(ts) {
    var d = new Date(ts);
    var p = function (n) { return (n < 10 ? "0" : "") + n; };
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate())
      + " " + p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds());
  }

  function categorize(entry) {
    if (entry.category) return entry.category;
    var moduleName = entry.moduleName || "";
    var description = entry.description || "";
    var h = (moduleName + " " + description).toLowerCase();
    if (moduleName.indexOf("@deepseek-ai/") === 0) return "core";
    if (/(skin|theme|皮肤|主题)/.test(h)) return "theme";
    if (/(pet|whale|宠物|娱乐|桌宠)/.test(h)) return "fun";
    if (/(client-ui|ui-|界面|面板|侧边栏|设置|compat)/.test(h)) return "ui";
    if (/(ssh|market|search|modlens|modsearch|visualize|agent-teams|notify|stats|remote|工具|搜索|集成|团队)/.test(h)) return "tools";
    return "other";
  }

  function catKey(entry) {
    var k = categorize(entry);
    return CATEGORIES.some(function (c) { return c.key === k; }) ? k : "other";
  }

  // 核心保护：优先用宿主下发的 protected；再按模块名兜底（覆盖自动生成 id 的条目）。
  var NAME_PROTECTED = /(^|[-/])(hmr|client-hmr|webserver|web-runtime|web-startup|startup|connection|modules|api-gateway|api-remotes|typert|typert-loader|typert-gateway|loader|cordis-host-runner|host-runner|runner|timer)([-/]|$)/;
  function isProtected(entry) {
    if (entry.protected) return true;
    return NAME_PROTECTED.test(entry.moduleName || "");
  }

  function shortName(moduleName) {
    var n = moduleName;
    if (n.startsWith("@")) n = n.slice(n.indexOf("/") + 1);
    return n.replace(/^cordis:/, "").replace(/^cordis-plugin-/, "").replace(/^dsh-(?:host-|client-)?/, "");
  }

  function fuzzyMatch(haystack, token) {
    var h = haystack.toLowerCase();
    var t = token.toLowerCase();
    if (t.length === 0) return true;
    if (h.indexOf(t) !== -1) return true;
    var i = 0;
    for (var j = 0; j < h.length && i < t.length; j++) {
      if (h[j] === t[i]) i++;
    }
    return i === t.length;
  }

  function matches(entry, query) {
    var tokens = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
    if (tokens.length === 0) return true;
    var haystacks = [
      entry.moduleName || "",
      entry.entryId || "",
      shortName(entry.moduleName),
      entry.description || "",
      catKey(entry)
    ];
    return tokens.every(function (token) {
      return haystacks.some(function (hay) { return fuzzyMatch(hay, token); });
    });
  }

  // 组内排序：可切换（非核心/界面保护）在前 → 按状态（运行中优先）→ 按模块名。
  function sortEntries(list) {
    return list.slice().sort(function (a, b) {
      var pa = isProtected(a) ? 1 : 0;
      var pb = isProtected(b) ? 1 : 0;
      if (pa !== pb) return pa - pb;
      var ra = statusRank(a);
      var rb = statusRank(b);
      if (ra !== rb) return ra - rb;
      return (a.moduleName || "").localeCompare(b.moduleName || "");
    });
  }

  function ToggleTab() {
    var state = react.useState(null);
    var entries = state[0];
    var setEntries = state[1];
    var loadingState = react.useState(true);
    var loading = loadingState[0];
    var setLoading = loadingState[1];
    var errorState = react.useState(null);
    var error = errorState[0];
    var setError = errorState[1];
    var busyState = react.useState(null);
    var busyId = busyState[0];
    var setBusyId = busyState[1];
    var confirmState = react.useState(null);
    var confirmId = confirmState[0];
    var setConfirmId = confirmState[1];
    var rowErrState = react.useState({});
    var rowErrors = rowErrState[0];
    var setRowErrors = rowErrState[1];
    var versionState = react.useState(0);
    var version = versionState[0];
    var setVersion = versionState[1];
    var queryState = react.useState("");
    var query = queryState[0];
    var setQuery = queryState[1];
    var logsState = react.useState(null);
    var logs = logsState[0];
    var setLogs = logsState[1];
    // 默认折叠「核心系统（官方）」与「使用记录」，其余展开。
    var collapsedState = react.useState({ core: true, logs: true });
    var collapsed = collapsedState[0];
    var setCollapsed = collapsedState[1];

    react.useEffect(function () {
      var alive = true;
      setLoading(true);
      fetch("/plugin-toggle/list").then(function (res) { return res.json(); }).then(
        function (result) { if (!alive) return; setEntries(result.entries); setError(null); },
        function (err) { if (!alive) return; setError(err instanceof Error ? err.message : String(err)); }
      ).finally(function () { if (alive) setLoading(false); });
      // 使用记录：路由不存在（宿主旧版本）时静默置空，不打扰用户。
      fetch("/plugin-toggle/logs").then(function (res) { return res.json(); }).then(
        function (result) { if (alive) setLogs(Array.isArray(result.records) ? result.records : []); },
        function () { if (alive) setLogs(null); }
      );
      return function () { alive = false; };
    }, [version]);

    function act(entry, enabled) {
      setBusyId(entry.entryId);
      setRowErrors(function (cur) { var n = Object.assign({}, cur); delete n[entry.entryId]; return n; });
      fetch("/plugin-toggle/set", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ entryId: entry.entryId, enabled: enabled })
      }).then(function (res) { return res.json(); }).then(
        function (result) {
          if (result.ok !== true) {
            setRowErrors(function (cur) { var n = Object.assign({}, cur); n[entry.entryId] = result.message || "操作失败"; return n; });
          } else {
            setConfirmId(null);
            setVersion(function (v) { return v + 1; });
          }
        },
        function (err) {
          setRowErrors(function (cur) { var n = Object.assign({}, cur); n[entry.entryId] = err instanceof Error ? err.message : String(err); return n; });
        }
      ).finally(function () { setBusyId(null); });
    }

    function renderRow(entry) {
      var phaseLabel = entry.phase === null ? "未运行" : (PHASE_LABELS[entry.phase] || entry.phase);
      var phaseClass = entry.phase === null ? "pst-idle" : (PHASE_CLASS[entry.phase] || "pst-info");
      var busy = busyId === entry.entryId;
      var confirming = confirmId === entry.entryId;
      var rowError = rowErrors[entry.entryId];
      var desc = (typeof entry.description === "string" && entry.description.trim() !== "")
        ? entry.description.trim()
        : entry.moduleName;

      var action = null;
      if (entry.enabled) {
        if (isProtected(entry)) {
          action = react.createElement("span", { className: "pst-badge" }, "核心插件");
        } else if (confirming) {
          action = react.createElement("span", { className: "pst-confirm" },
            react.createElement("span", { className: "pst-confirmText" }, "确认关闭?"),
            react.createElement("button", { type: "button", className: "pst-btn pst-btn-danger", disabled: busy, onClick: function () { act(entry, false); } }, "确认关闭"),
            react.createElement("button", { type: "button", className: "pst-btn pst-btn-ghost", disabled: busy, onClick: function () { setConfirmId(null); } }, "取消")
          );
        } else {
          action = react.createElement("button", { type: "button", className: "pst-btn pst-btn-danger", disabled: busy, onClick: function () { setConfirmId(entry.entryId); } }, "关闭");
        }
      } else {
        action = react.createElement("button", { type: "button", className: "pst-btn pst-btn-primary", disabled: busy, onClick: function () { act(entry, true); } }, "启动");
      }

      return react.createElement("li", { key: entry.entryId, className: "pst-row" },
        react.createElement("div", { className: "pst-rowMain" },
          react.createElement("div", { className: "pst-rowTitle" },
            react.createElement("strong", { className: "pst-name" }, shortName(entry.moduleName)),
            react.createElement("span", { className: "pst-id" }, entry.entryId)
          ),
          react.createElement("p", { className: "pst-desc", title: entry.description || undefined }, desc),
          react.createElement("div", { className: "pst-rowMeta" },
            react.createElement("span", { className: "pst-status", "data-enabled": entry.enabled ? "true" : "false" }, entry.enabled ? "已启用" : "已禁用"),
            react.createElement("span", { className: "pst-phase " + phaseClass },
              react.createElement("span", { className: "pst-dot" }),
              phaseLabel
            )
          )
        ),
        react.createElement("div", { className: "pst-rowAction" }, action),
        rowError !== undefined ? react.createElement("p", { className: "pst-rowError", role: "alert" }, rowError) : null
      );
    }

    function renderGroup(cat) {
      var items = sortEntries((entries || []).filter(function (e) { return catKey(e) === cat.key && matches(e, query); }));
      if (items.length === 0) return null;
      var isCollapsed = collapsed[cat.key] === true;
      var children = [react.createElement("button", {
        key: "head",
        type: "button",
        className: "pst-groupHead",
        "aria-expanded": isCollapsed ? "false" : "true",
        onClick: function () {
          setCollapsed(function (cur) {
            var n = Object.assign({}, cur);
            if (n[cat.key] === true) delete n[cat.key]; else n[cat.key] = true;
            return n;
          });
        }
      },
        react.createElement("span", { className: "pst-groupName" }, cat.label),
        react.createElement("span", { className: "pst-groupCount" }, items.length + " 个"),
        react.createElement("span", { className: "pst-chevron" + (isCollapsed ? "" : " pst-open"), "aria-hidden": "true" }, "▾")
      )];
      if (!isCollapsed) {
        children.push(react.createElement("ul", { key: "list", className: "pst-list" }, items.map(renderRow)));
      }
      return react.createElement("section", { key: cat.key, className: "pst-group" }, children);
    }

    function renderLogs() {
      if (logs === null) return null;
      var isCollapsed = collapsed.logs === true;
      var children = [react.createElement("button", {
        key: "head",
        type: "button",
        className: "pst-groupHead",
        "aria-expanded": isCollapsed ? "false" : "true",
        onClick: function () {
          setCollapsed(function (cur) {
            var n = Object.assign({}, cur);
            if (n.logs === true) delete n.logs; else n.logs = true;
            return n;
          });
        }
      },
        react.createElement("span", { className: "pst-groupName" }, "使用记录"),
        react.createElement("span", { className: "pst-groupCount" }, logs.length + " 条"),
        react.createElement("span", { className: "pst-chevron" + (isCollapsed ? "" : " pst-open"), "aria-hidden": "true" }, "▾")
      )];
      if (!isCollapsed) {
        var rows;
        if (logs.length === 0) {
          rows = react.createElement("p", { className: "pst-note", style: { padding: "10px 12px" } }, "暂无使用记录");
        } else {
          rows = react.createElement("ul", { className: "pst-list" }, logs.map(function (rec) {
            var label = rec.action === "start" ? "启动" : "关闭";
            return react.createElement("li", { key: rec.ts + rec.entryId, className: "pst-row" },
              react.createElement("div", { className: "pst-rowMain" },
                react.createElement("div", { className: "pst-rowTitle" },
                  react.createElement("strong", { className: "pst-name" }, shortName(rec.moduleName || rec.entryId || "")),
                  react.createElement("span", { className: "pst-id" }, rec.entryId || "")
                ),
                react.createElement("div", { className: "pst-rowMeta" },
                  react.createElement("span", { className: "pst-status" }, label),
                  react.createElement("span", { className: "pst-phase" }, fmtTime(rec.ts))
                )
              )
            );
          }));
        }
        children.push(react.createElement("div", { key: "list" }, rows));
      }
      return react.createElement("section", { key: "logs", className: "pst-group" }, children);
    }

    var searching = query.trim() !== "";
    var filteredTotal = entries === null ? 0 : entries.filter(function (e) { return matches(e, query); }).length;
    var enabledCount = entries === null ? 0 : entries.filter(function (e) { return e.enabled; }).length;

    var header = react.createElement("div", { className: "pst-header" },
      react.createElement("span", { className: "pst-count" },
        entries === null
          ? "—"
          : (searching
            ? "匹配 " + filteredTotal + " / " + entries.length + " 个插件"
            : enabledCount + "/" + entries.length + " 已启用")
      ),
      react.createElement("button", { type: "button", className: "pst-btn pst-btn-ghost", disabled: loading, onClick: function () { setVersion(function (v) { return v + 1; }); } }, "刷新")
    );

    var search = react.createElement("label", { className: "pst-search" },
      react.createElement("span", { className: "pst-searchIcon", "aria-hidden": "true" }, "⌕"),
      react.createElement("input", {
        type: "search",
        value: query,
        placeholder: "搜索插件名 / 模块名 / ID / 描述 / 分类（支持模糊匹配）",
        "aria-label": "搜索插件",
        onChange: function (event) { setQuery(event.currentTarget.value); }
      })
    );

    var body;
    if (loading && entries === null) {
      body = react.createElement("p", { className: "pst-note" }, "加载中…");
    } else if (error !== null) {
      body = react.createElement("p", { className: "pst-rowError", role: "alert" }, "读取失败: " + error);
    } else if (entries === null || entries.length === 0) {
      body = react.createElement("p", { className: "pst-note" }, "没有可操作的插件条目");
    } else if (searching && filteredTotal === 0) {
      body = react.createElement("p", { className: "pst-note" }, "没有匹配的插件");
    } else {
      body = react.createElement("div", { className: "pst-groups" },
        CATEGORIES.map(renderGroup).concat(renderLogs())
      );
    }

    return react.createElement("div", { className: "pst-root" },
      react.createElement("p", { className: "pst-tip" }, "插件按分类分组展示（点击分组标题折叠/展开），组内可切换的在前、运行中优先；启动/关闭仅运行时生效，并记录到使用记录（~/.dsh/dsh-plugin-toggle.jsonl）。"),
      search,
      header,
      body
    );
  }

  function apply(ctx) {
    ctx.effect(function () {
      var el = document.createElement("style");
      el.textContent = CSS;
      document.head.appendChild(el);
      return function () { el.remove(); };
    }, "dsh-plugin-toggle: styles");
    ctx.slots.inject("settings.plugins.tab", function () {
      return ctx.slots.register(
        { name: "settings.plugins.tab", id: "plugin-toggle", order: 15, label: "插件开关" },
        function () { return react.createElement(ToggleTab); }
      );
    });
  }

  exports.apply = apply;
  exports.inject = inject;
  exports.name = name;
  return module.exports;
}});
