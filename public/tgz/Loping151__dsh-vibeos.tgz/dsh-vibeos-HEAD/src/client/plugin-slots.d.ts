/** `plugins.bundle.config` is declared by ui-plugin-manager, which is not a build dependency. */
export {};

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    'plugins.bundle.config': { kind: 'keyed'; scope: 'root'; owner: { view: 'page' } };
  }
}
