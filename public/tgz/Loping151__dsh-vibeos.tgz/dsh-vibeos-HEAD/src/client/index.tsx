/** Client bundle entry: wires the takeover, the ws→store boot dispatch and the
 * DSH theme bridge, and exposes the public `vibeos` registry API. Everything is
 * reverted through the fiber effect (classic toggle, HMR drain, plugin disable). */

import type { Context } from '@deepseek-ai/cordis';
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client';
import type {} from '@deepseek-ai/dsh-client-ui-theme/client';
import type {} from '@deepseek-ai/dsh-client-ui-settings/client';

import { VIBEOS_CSS } from './styles/index';
import { injectStyles, removeStyles } from './lib/cssInject';
import { themeBridge } from './themeBridge';
import { createModeManager } from './takeover';
import { registerBootWiring } from './boot';
import { wsClient } from './ws';
import { VibeosSection } from './components/dshSettings/VibeosSection';

export { vibeos, type VibeosClientApi } from './registry/index';

export const inject = ['slots', 'theme'];

/** Config page on the sidebar Plugins page; settings section only on older DSH without it. */
function registerConfigPage(ctx: Context): void {
  let pageLive = false;
  let offSection: (() => void) | undefined;
  ctx.slots.inject('plugins.bundle.config', () => {
    pageLive = true;
    offSection?.();
    return ctx.slots.register({ name: 'plugins.bundle.config', key: 'dsh-vibeos' }, VibeosSection);
  });
  ctx.slots.inject('settings.section', () => {
    if (pageLive) return () => {};
    const off = ctx.slots.register(
      { name: 'settings.section', id: 'vibeos', order: 82, label: () => 'VibeOS' },
      VibeosSection,
    );
    offSection = () => {
      offSection = undefined;
      off();
    };
    return () => offSection?.();
  });
}

export function apply(ctx: Context): void {
  injectStyles(VIBEOS_CSS);
  themeBridge.init(ctx);
  const mode = createModeManager(ctx);
  const unwire = registerBootWiring();
  registerConfigPage(ctx);
  wsClient.connect();
  ctx.effect(() => () => {
    unwire();
    wsClient.dispose();
    mode.dispose();
    themeBridge.dispose();
    removeStyles();
  }, 'vibeos: client teardown');
}
