import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  attempt,
  DISABLED_KEY,
  GUARD_LIMIT,
  initialRec,
  isEligible,
  MAX_PAGES_KEY,
  settingsFrom,
} from '../src/core.mjs'

function snap(overrides = {}) {
  return { openState: 'open', hasMore: true, loadingOlder: false, nodes: [], ...overrides }
}

test('isEligible: 只有 open + hasMore + 未在翻页才可加载', () => {
  assert.equal(isEligible(snap()), true)
  assert.equal(isEligible(snap({ openState: 'loading' })), false)
  assert.equal(isEligible(snap({ openState: 'closed' })), false)
  assert.equal(isEligible(snap({ hasMore: false })), false)
  assert.equal(isEligible(snap({ loadingOlder: true })), false)
  assert.equal(isEligible(null), false)
  assert.equal(isEligible(undefined), false)
  assert.equal(isEligible('oops'), false)
})

test('attempt: 有进展时失败计数清零并继续加载', () => {
  const rec = initialRec(50)
  assert.equal(attempt(rec, 50), 'load') // 首次:计数相同 → failures=1,但仍加载
  assert.equal(attempt(rec, 100), 'load') // 进展:清零
  assert.equal(rec.failures, 0)
  assert.equal(rec.lastCount, 100)
})

test('attempt: 连续无进展达到上限后放弃,进展恢复后自愈', () => {
  const rec = initialRec(50)
  assert.equal(attempt(rec, 50), 'load')
  assert.equal(attempt(rec, 50), 'load')
  assert.equal(attempt(rec, 50), 'giveup') // 第 3 次无进展
  // 放弃状态下继续空转不再放行
  assert.equal(attempt(rec, 50), 'giveup')
  assert.equal(attempt(rec, 50), 'giveup')
  // 快照节点数变化(哪怕只多 1 条)→ 自愈,重新开始加载
  assert.equal(attempt(rec, 51), 'load')
  assert.equal(rec.failures, 0)
})

test('attempt: GUARD_LIMIT 为 3,自定义 limit 生效', () => {
  assert.equal(GUARD_LIMIT, 3)
  const rec = initialRec(0)
  assert.equal(attempt(rec, 0, 1), 'giveup')
  const rec2 = initialRec(0)
  assert.equal(attempt(rec2, 0, 5), 'load')
  assert.equal(attempt(rec2, 0, 5), 'load')
  assert.equal(attempt(rec2, 0, 5), 'load')
  assert.equal(attempt(rec2, 0, 5), 'load')
  assert.equal(attempt(rec2, 0, 5), 'giveup')
})

test('settingsFrom: 默认启用且不限页数', () => {
  assert.deepEqual(settingsFrom(() => null), { disabled: false, maxPages: 0 })
  assert.deepEqual(settingsFrom(undefined), { disabled: false, maxPages: 0 })
  // getter 抛错(隐私模式)也回落默认
  assert.deepEqual(settingsFrom(() => { throw new Error('blocked') }), { disabled: false, maxPages: 0 })
})

test('settingsFrom: disabled 开关只认字符串 "1"', () => {
  assert.equal(settingsFrom((k) => (k === DISABLED_KEY ? '1' : null)).disabled, true)
  assert.equal(settingsFrom((k) => (k === DISABLED_KEY ? 'true' : null)).disabled, false)
  assert.equal(settingsFrom((k) => (k === DISABLED_KEY ? '0' : null)).disabled, false)
})

test('settingsFrom: maxPages 只接受正整数,其余一律不限页', () => {
  const get = (v) => (k) => (k === MAX_PAGES_KEY ? v : null)
  assert.equal(settingsFrom(get('5')).maxPages, 5)
  assert.equal(settingsFrom(get('2.9')).maxPages, 2)
  assert.equal(settingsFrom(get('0')).maxPages, 0)
  assert.equal(settingsFrom(get('-3')).maxPages, 0)
  assert.equal(settingsFrom(get('abc')).maxPages, 0)
  assert.equal(settingsFrom(get('')).maxPages, 0)
})

test('attempt: 不同会话的守卫记录互不影响(调用方按 sessionId 分 Map 键)', () => {
  const a = initialRec(10)
  const b = initialRec(10)
  attempt(a, 10); attempt(a, 10) // a 再失败一次就放弃
  assert.equal(attempt(b, 10), 'load') // b 不受 a 影响
  assert.equal(a.failures, 2)
  assert.equal(b.failures, 1)
})
