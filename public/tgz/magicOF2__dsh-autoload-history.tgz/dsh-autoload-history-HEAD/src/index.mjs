// dsh-autoload-history Node half: pure client plugin — an empty apply lets
// the bundle mount; all behavior lives in the browser half (lib/client.js).
export default function apply() {}
