// dsh-autoload-history browser half: auto-load the whole conversation history
// when a session opens, so older messages are already there — no more
// clicking "Load earlier" in the DSH Web UI.
//
// Mechanism: an invisible entry in the additive session-scoped slot
// `conversation.composer.dock`. Its standard props expose the session id and
// the conversation snapshot (`useSession`, a selector hook). Whenever the
// snapshot reports openState === 'open' with hasMore === true and no page
// load in flight, we call session.loadOlder() — 50 messages per page. Each
// page updates the snapshot, which re-runs the effect, so pages cascade until
// hasMore === false (the whole history sits in the window). A per-session
// no-progress guard stops after 3 consecutive attempts that added no nodes,
// so a failing host can never hot-loop. Nothing is rendered (returns null).
//
// The load/no-load decision itself lives in src/core.mjs (pure, unit-tested).
import React from 'react'
import {
  attempt,
  GUARD_LIMIT,
  initialRec,
  isEligible,
  MAX_PAGES_KEY,
  settingsFrom,
} from '../core.mjs'

export default {
  name: 'autoload-history',
  apply(ctx: any) {
    const sessions = ctx.get('sessions')
    const slots = ctx.get('slots')
    if (sessions === undefined || slots === undefined) return

    // localStorage 安全读取(隐私模式等场景下访问可能直接抛错)
    const safeGet = (key: string): string | null => {
      try {
        return window.localStorage.getItem(key)
      } catch {
        return null
      }
    }

    // sessionId -> { lastCount, failures }: no-progress guard state.
    const progress = new Map<string, { lastCount: number; failures: number }>()
    // sessionId -> 本轮打开已自动翻过的页数(会话不可加载时清零)
    const pagesLoaded = new Map<string, number>()

    slots.inject('conversation.composer.dock', () => {
      const dispose = slots.register(
        {
          name: 'conversation.composer.dock',
          id: 'autoload-history',
          order: 100,
        },
        (props: any) => {
          const snapshot = props.useSession((s: any) => s)
          const sessionId: string = props.sessionId
          React.useEffect(() => {
            if (!isEligible(snapshot)) {
              // 会话关闭/加载完/翻页中:本轮打开的页数计数不再有意义
              pagesLoaded.delete(sessionId)
              return
            }
            const settings = settingsFrom(safeGet)
            if (settings.disabled) return
            const binding = sessions.binding(sessionId)
            if (binding === undefined) return
            const count = snapshot.nodes.length
            const done = pagesLoaded.get(sessionId) ?? 0
            if (settings.maxPages > 0 && done >= settings.maxPages) {
              console.warn(
                `[autoload-history] page cap ${settings.maxPages} reached for ${sessionId}; ` +
                  `raise or remove ${MAX_PAGES_KEY} to load more`,
              )
              return
            }
            let rec = progress.get(sessionId)
            if (rec === undefined) {
              rec = initialRec(count)
              progress.set(sessionId, rec)
            }
            const decision = attempt(rec, count)
            if (decision !== 'load') {
              console.warn(
                `[autoload-history] giving up on ${sessionId}: no progress after ${GUARD_LIMIT} attempts`,
              )
              return
            }
            // loadOlder 同步抛错或返回的 Promise 被拒绝都不能打进 React
            // 渲染树(effect 异常会炸掉整个应用);失败页交给无进展守卫兜底。
            try {
              const r: unknown = binding.session.loadOlder()
              pagesLoaded.set(sessionId, done + 1)
              if (r !== null && r !== undefined && typeof (r as Promise<void>).catch === 'function') {
                ;(r as Promise<void>).catch((err: unknown) => {
                  console.warn('[autoload-history] loadOlder rejected:', err)
                })
              }
            } catch (err) {
              console.warn('[autoload-history] loadOlder threw:', err)
            }
          }, [sessionId, snapshot])
          return null
        },
      )
      return () => {
        dispose()
      }
    })
  },
}
