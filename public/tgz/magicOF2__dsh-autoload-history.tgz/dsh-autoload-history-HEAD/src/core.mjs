/**
 * dsh-autoload-history 纯决策核心(无 React / 无 DOM / 无 IO)。
 *
 * 客户端半身的全部"要不要再翻一页"的判断都集中在这里,便于用
 * node:test 直接覆盖;浏览器半身(src/client/index.ts)通过相对导入
 * 把它一起打进 CJS bundle。
 *
 * 语义与原始内联实现逐条等价:
 *   - openState === 'open' 且 hasMore === true 且未在翻页时才考虑加载;
 *   - 连续 GUARD_LIMIT 次页面节点数无增长 → 放弃(防故障热循环);
 *   - 一旦有进展,失败计数立即清零。
 */

/** 连续无进展多少次后放弃。 */
export const GUARD_LIMIT = 3

/** localStorage 键:置 '1' 时整体停用自动加载(逃生开关)。 */
export const DISABLED_KEY = 'dsh-autoload-history.disabled'

/** localStorage 键:单次打开会话最多自动翻页数(正整数;'0'/缺失 = 不限)。 */
export const MAX_PAGES_KEY = 'dsh-autoload-history.maxPages'

/**
 * 从 localStorage 形态的 getter(key -> string | null)读取设置。
 * 任何异常/非法值都回落到默认:启用、不限页数 —— 保持"零配置即用"。
 */
export function settingsFrom(getItem) {
  let disabled = false
  let maxPages = 0
  try {
    if (typeof getItem === 'function') {
      disabled = getItem(DISABLED_KEY) === '1'
      const raw = getItem(MAX_PAGES_KEY)
      if (raw !== null && raw !== undefined && raw !== '') {
        const n = Number(raw)
        if (Number.isFinite(n) && n > 0) maxPages = Math.floor(n)
      }
    }
  } catch {
    // localStorage 不可用时保持默认行为
  }
  return { disabled, maxPages }
}

/** 快照是否处于"可以再翻一页"的状态。 */
export function isEligible(snapshot) {
  return (
    snapshot !== null &&
    typeof snapshot === 'object' &&
    snapshot.openState === 'open' &&
    snapshot.hasMore === true &&
    snapshot.loadingOlder !== true
  )
}

/** 某个会话第一次进入可加载状态时的守卫记录。 */
export function initialRec(count) {
  return { lastCount: count, failures: 0 }
}

/**
 * 记录一次尝试并给出决定:
 *   'load'   —— 继续调 loadOlder()
 *   'giveup' —— 连续无进展达到上限,停止(与原实现一致:计数继续累积,
 *               但不再发起调用;一旦 count 变化立即自愈)
 * rec 为原地更新(调用方持有 Map 中的同一对象)。
 */
export function attempt(rec, count, limit = GUARD_LIMIT) {
  if (count === rec.lastCount) {
    rec.failures += 1
    return rec.failures >= limit ? 'giveup' : 'load'
  }
  rec.failures = 0
  rec.lastCount = count
  return 'load'
}
