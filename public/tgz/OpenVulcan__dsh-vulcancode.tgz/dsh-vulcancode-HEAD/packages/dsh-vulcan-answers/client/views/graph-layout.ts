/**
 * Layered graph layout shared by `ui-flow` and `ui-er`: dagre ranks and orders the nodes, this module
 * measures labels and turns dagre's edge points into smooth SVG paths. Ported from VulcanCode
 * `answer-graph-layout.ts`.
 */

import { layout } from 'dagre-d3-es/src/dagre/index.js'
import { Graph } from 'dagre-d3-es/src/graphlib/index.js'

/** A point in diagram coordinates. */
export interface GraphPoint {
  x: number
  y: number
}

/** A node to place: its outer size and an id the caller maps back. */
export interface GraphLayoutNode {
  id: string
  width: number
  height: number
}

/** An edge to route, with the size reserved for its label. */
export interface GraphLayoutEdge {
  from: string
  to: string
  labelWidth?: number | undefined
  labelHeight?: number | undefined
}

/** Placed graph: node centers, edge points, label centers and the drawing size. */
export interface GraphLayout {
  width: number
  height: number
  nodes: Map<string, GraphPoint>
  edges: { points: GraphPoint[]; label?: GraphPoint | undefined }[]
}

/** Spacing of one layout direction. */
export interface GraphSpacing {
  horizontal: boolean
  nodeGap: number
  rankGap: number
}

/** Margin around the drawing so strokes and arrowheads are never clipped. */
const GRAPH_MARGIN = 6

/** Rank, order and route the graph; edges keep the input order. */
export function layoutGraph(nodes: GraphLayoutNode[], edges: GraphLayoutEdge[], spacing: GraphSpacing): GraphLayout {
  const graph = new Graph({ multigraph: true })
  graph.setGraph({
    rankdir: spacing.horizontal ? 'LR' : 'TB',
    nodesep: spacing.nodeGap,
    ranksep: spacing.rankGap,
    edgesep: 12,
    marginx: GRAPH_MARGIN,
    marginy: GRAPH_MARGIN,
  })
  graph.setDefaultEdgeLabel(() => ({}))
  for (const node of nodes) graph.setNode(node.id, { width: node.width, height: node.height })
  edges.forEach((edge, index) => {
    graph.setEdge(edge.from, edge.to, { width: edge.labelWidth ?? 0, height: edge.labelHeight ?? 0, labelpos: 'c' }, String(index))
  })
  layout(graph, {})
  const placed = new Map<string, GraphPoint>()
  for (const node of nodes) {
    const value = graph.node(node.id) as GraphPoint
    placed.set(node.id, { x: value.x, y: value.y })
  }
  const routed = edges.map((edge, index) => {
    const value = graph.edge({ v: edge.from, w: edge.to, name: String(index) }) as { points: GraphPoint[]; x?: number; y?: number }
    const label = edge.labelWidth && value.x !== undefined && value.y !== undefined ? { x: value.x, y: value.y } : undefined
    return { points: value.points.map((point) => ({ x: point.x, y: point.y })), label }
  })
  const size = graph.graph() as { width?: number; height?: number }
  return fitEdges({ width: size.width ?? 0, height: size.height ?? 0, nodes: placed, edges: routed })
}

/**
 * dagre sizes the drawing to nodes and edge labels but not to edge points, so an edge routed around
 * the outside can leave it. Grow and shift the drawing until every point keeps the margin.
 */
function fitEdges(placed: GraphLayout): GraphLayout {
  const points = placed.edges.flatMap((edge) => edge.points)
  const left = Math.max(0, GRAPH_MARGIN - Math.min(GRAPH_MARGIN, ...points.map((point) => point.x)))
  const top = Math.max(0, GRAPH_MARGIN - Math.min(GRAPH_MARGIN, ...points.map((point) => point.y)))
  const right = Math.max(placed.width, ...points.map((point) => point.x + GRAPH_MARGIN)) + left
  const bottom = Math.max(placed.height, ...points.map((point) => point.y + GRAPH_MARGIN)) + top
  const shift = (point: GraphPoint): GraphPoint => ({ x: point.x + left, y: point.y + top })
  return {
    width: Math.ceil(right),
    height: Math.ceil(bottom),
    nodes: new Map([...placed.nodes].map(([id, point]) => [id, shift(point)])),
    edges: placed.edges.map((edge) => ({ points: edge.points.map(shift), label: edge.label && shift(edge.label) })),
  }
}

/** Smooth path through `points` (uniform B-spline, as d3's curveBasis). */
export function splinePath(points: GraphPoint[]): string {
  const format = (value: number) => Number(value.toFixed(1))
  const first = points[0]
  const second = points[1]
  if (first === undefined) return ''
  if (second === undefined || points.length < 3) return points.map((point, index) => `${index ? 'L' : 'M'}${format(point.x)},${format(point.y)}`).join(' ')
  const parts = [`M${format(first.x)},${format(first.y)}`]
  let [x0, y0, x1, y1] = [first.x, first.y, second.x, second.y]
  parts.push(`L${format((5 * x0 + x1) / 6)},${format((5 * y0 + y1) / 6)}`)
  const curve = (x: number, y: number) => {
    parts.push(`C${format((2 * x0 + x1) / 3)},${format((2 * y0 + y1) / 3)} ${format((x0 + 2 * x1) / 3)},${format((y0 + 2 * y1) / 3)} ${format((x0 + 4 * x1 + x) / 6)},${format((y0 + 4 * y1 + y) / 6)}`)
  }
  for (const point of points.slice(2)) {
    curve(point.x, point.y)
    ;[x0, y0, x1, y1] = [x1, y1, point.x, point.y]
  }
  curve(x1, y1)
  parts.push(`L${format(x1)},${format(y1)}`)
  return parts.join(' ')
}

/** Where the segment from `outside` toward `center` crosses a diamond of half sizes `rx`, `ry`. */
export function diamondBoundary(center: GraphPoint, rx: number, ry: number, outside: GraphPoint): GraphPoint {
  const dx = outside.x - center.x
  const dy = outside.y - center.y
  const scale = 1 / (Math.abs(dx) / rx + Math.abs(dy) / ry || 1)
  return { x: center.x + dx * scale, y: center.y + dy * scale }
}

/** Canvas context used to measure label text, created on first use. */
let measureContext: CanvasRenderingContext2D | null | undefined

/** Width of `text` in `font`; estimated when no canvas is available. */
export function measureText(text: string, font: string, fontSize: number): number {
  if (measureContext === undefined) {
    measureContext = typeof document === 'undefined' ? null : document.createElement('canvas').getContext('2d')
  }
  if (measureContext) {
    measureContext.font = font
    return measureContext.measureText(text).width
  }
  return [...text].reduce((width, ch) => width + (/[⺀-￯]/u.test(ch) ? fontSize : fontSize * 0.56), 0)
}

/** Break `text` into lines no wider than `maxWidth`: at spaces, or between characters of CJK text. */
export function wrapText(text: string, maxWidth: number, measure: (text: string) => number): string[] {
  if (measure(text) <= maxWidth) return [text]
  const tokens = text.match(/[⺀-￯]|[^\s⺀-￯]+|\s+/gu) ?? [text]
  const lines: string[] = []
  let line = ''
  for (const token of tokens) {
    const next = line + token
    if (line.trim() && measure(next.trimEnd()) > maxWidth) {
      lines.push(line.trim())
      line = token.trimStart()
    } else {
      line = next
    }
  }
  if (line.trim()) lines.push(line.trim())
  return lines
}
