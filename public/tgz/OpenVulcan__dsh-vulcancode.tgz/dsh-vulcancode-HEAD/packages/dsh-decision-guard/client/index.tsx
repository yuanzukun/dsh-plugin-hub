/**
 * Browser half of the dsh plugin:
 *
 * - Settings › Auto approval: the whole configuration, in VulcanCode's look (`settings.tsx`).
 * - The composer pill left of the model selector, with a card for the category grants, the
 *   session's review prompt and unattended mode, and the settings changed most often (`quick.tsx`).
 * - The approval card that takes over the composer while one of this plugin's prompts waits.
 * - On the suite's Plugins page entry: the Auto review conflict notice. dsh's own
 *   Auto review and Vulcan Decision both review every tool call before it runs and only one of
 *   them can provide the Auto permission preset, so the pair is a conflict, not a combination.
 *
 * dsh loads these files as one lazy factory; they may import only modules dsh serves to plugins.
 */

import { ApprovalCard, ConflictBadge, ConflictSection, guardApprovalOf } from './approval'
import { en, NAMESPACE, zh, type Translate } from './i18n'
import { QuickSetting, type QuickInjected } from './quick'
import { SettingsPage } from './settings'
import {
  ACCOUNT_SECTION, AUTO_PRESET, AUTO_REVIEW_PACKAGE, autoReviewEnabled, callPanel, ENTRY_ID, HostWatch, messageOf, SETTINGS_SECTION,
  type EndpointSnapshot, type GuardSettings, type ModelList, type PanelState, type Services,
} from './shared'
import { installStyle } from './style'
import type { ClientContext, LocalizedText, ModelCatalog, SettingsShell } from './dsh-client'

export const inject = [
  'slots', 'locale', 'sessions', 'remote', 'remote.pluginManager', 'remote.permissionPresets', 'remote.session', 'configForms',
]

/** Mirror `UNATTENDED_COMMAND` and `REVIEW_PROMPT_COMMAND` in `src/session-state.ts`. */
const UNATTENDED_COMMAND = 'vulcan-unattended'
const REVIEW_PROMPT_COMMAND = 'vulcan-review-prompt'

/** Install the settings section, the composer pill, the approval card and the Plugins page notices. */
export function apply(ctx: ClientContext): void {
  const services: Services = {
    form: ctx.configForms.get<GuardSettings>(ENTRY_ID),
    autoReview: new HostWatch<boolean>(async () => {
      const result = await ctx.remote.pluginManager.listBundles()
      return result.ok ? autoReviewEnabled(result.value) : undefined
    }),
    autoListed: new HostWatch<boolean>(async () => {
      const result = await ctx.remote.permissionPresets.catalog()
      return result.ok ? result.value.options.some(option => option.value === AUTO_PRESET) : undefined
    }),
    panel: new HostWatch<PanelState | null>(() => callPanel<PanelState>('GET', 'state').catch(() => null)),
    endpoints: new HostWatch<EndpointSnapshot>(() => callPanel<EndpointSnapshot>('GET', 'cloud/endpoints')),
    cloudModels: new HostWatch<ModelList>(() => callPanel<string[]>('GET', 'cloud/models').then(
      (models): ModelList => ({ kind: 'ready', models }),
      (error: unknown): ModelList => ({ kind: 'failed', error: messageOf(error) }),
    )),
    modelCatalog: new HostWatch<ModelCatalog>(async () => {
      const result = await ctx.remote.session.modelCatalog()
      return result.ok ? result.value : undefined
    }),
    openSettings: () => {
      const shell = ctx.slots.entries('sidebar.settings')[0]?.store?.create() as SettingsShell | undefined
      shell?.actions.openSection(SETTINGS_SECTION)
    },
    openAccount: () => {
      const shell = ctx.slots.entries('sidebar.settings')[0]?.store?.create() as SettingsShell | undefined
      shell?.actions.openSection(ACCOUNT_SECTION)
    },
  }
  const watches = [services.autoReview, services.autoListed, services.panel, services.endpoints, services.cloudModels, services.modelCatalog]

  ctx.effect(() => installStyle(), 'vulcan-decision-guard: stylesheet')
  ctx.effect(() => ctx.locale.register(NAMESPACE, { zh, en }), 'vulcan-decision-guard: dictionaries')
  ctx.effect(() => {
    let accountKey: string | null | undefined
    // A reconnect can keep the same authorization ID while replacing the backend.
    // 重连可能更换宿主，但仍保留相同的授权标识。
    let refreshCloud = true
    /**
     * Invalidate account-scoped data and read the new Host state after reconnect or plugin changes.
     * 重连或插件变更后清除账号相关数据，并读取新的宿主状态。
     */
    const refreshAll = (): void => {
      refreshCloud = true
      services.panel.reset()
      services.cloudModels.reset()
      services.endpoints.reset()
      services.autoReview.refresh()
      services.autoListed.refresh()
      services.panel.refresh()
    }
    const stops = [
      ctx.remote.$on('plugin-manager/changed', refreshAll),
      ctx.remote.$on('permission-presets/catalog-changed', () => { services.autoListed.refresh() }),
      ctx.on('connection/reset', refreshAll),
      // Load the model list when the first signed-in account arrives, without opening any UI.
      // 首次确认账号已登录时主动加载模型目录，无需打开界面。
      services.panel.subscribe(() => {
        const account = services.panel.getSnapshot()?.account
        if (account === undefined) return
        const key = account.signedIn ? `${account.site ?? ''}:${account.authorizationId ?? ''}` : null
        if (!refreshCloud && key === accountKey) return
        const hadAccount = accountKey !== undefined
        accountKey = key
        refreshCloud = false
        services.cloudModels.reset()
        services.endpoints.reset()
        if (account.signedIn) {
          services.cloudModels.refresh()
          if (hadAccount) services.endpoints.refresh()
        }
      }),
    ]
    refreshAll()
    return () => {
      for (const stop of stops) stop()
      for (const watch of watches) watch.close()
    }
  }, 'vulcan-decision-guard: Host state')

  const withServices = () => ({ services })

  // After Agent presets (20), before Market (40).
  ctx.slots.inject('settings.section', () => ctx.slots.register<{ services: Services }>({
    name: 'settings.section',
    id: SETTINGS_SECTION,
    order: 22,
    label: () => ctx.locale.bind(NAMESPACE)('nav'),
    locale: NAMESPACE,
    inject: withServices,
  }, ({ t, services: injected }) => <SettingsPage services={injected} t={t as Translate} />))
  // dsh 0.2.2 declares this optional slot. The injection waits on older hosts.
  // dsh 0.2.2 声明了此可选插槽，旧版宿主上的注入会保持等待。
  ctx.slots.inject('settings.section.icon', () => ctx.slots.register({
    name: 'settings.section.icon',
    id: SETTINGS_SECTION,
  }, SettingsIcon))
  ctx.slots.inject('plugins.detail.badge', () => ctx.slots.register({
    name: 'plugins.detail.badge',
    id: 'vulcan-decision-guard-conflict',
    locale: NAMESPACE,
    inject: withServices,
  }, ConflictBadge))
  ctx.slots.inject('plugins.detail.section', () => ctx.slots.register({
    name: 'plugins.detail.section',
    id: 'vulcan-decision-guard-conflict',
    locale: NAMESPACE,
    inject: () => ({ services, disableAutoReview: () => ctx.remote.pluginManager.setBundleEnabled(AUTO_REVIEW_PACKAGE, false) }),
  }, ConflictSection))
  // Ahead of dsh's own approval card (priority 1), and only for this plugin's prompts.
  ctx.slots.inject('conversation.composer', () => ctx.slots.register({
    name: 'conversation.composer',
    priority: 0,
    locale: NAMESPACE,
    select: ({ pendingInteraction }) => guardApprovalOf(pendingInteraction),
    inject: () => ({ resolveText: (text: LocalizedText) => ctx.locale.resolveText(text) }),
  }, ApprovalCard))
  // Left of the model selector, before other plugins' pills (liangshen uses 20).
  ctx.slots.inject('conversation.input.right', () => ctx.slots.register({
    name: 'conversation.input.right',
    id: 'vulcan-decision-guard-quick',
    order: 10,
    locale: NAMESPACE,
    inject: (sessionId: string): QuickInjected => {
      // The commands keep newlines after their first word, so a multi-line prompt arrives whole.
      const run = async (command: string, input: string): Promise<void> => {
        const session = ctx.sessions.binding(sessionId)?.session
        if (session === undefined) throw new Error('this session is not materialized yet')
        const result = await session.command(`/${command} ${input}`)
        if (!result.ok) throw new Error(`${result.error.code}: ${result.error.message}`)
        if (!result.value.matched) throw new Error(`the Host offers no /${command} command`)
      }
      return {
        services,
        setUnattended: policy => run(UNATTENDED_COMMAND, policy === null ? 'off' : `on ${policy}`.trimEnd()),
        setReviewPrompt: prompt => run(REVIEW_PROMPT_COMMAND, prompt === null ? 'default' : `set ${prompt}`.trimEnd()),
      }
    },
  }, QuickSetting))
}

/**
 * Render the approval shield at the square size requested by dsh's settings navigation.
 * 按 dsh 设置导航请求的方形尺寸渲染审批盾牌图标。
 */
function SettingsIcon({ size }: { readonly size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
      <path d="M12 3 20 6v5c0 4.7-2.8 7.9-8 10-5.2-2.1-8-5.3-8-10V6l8-3Z" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  )
}
