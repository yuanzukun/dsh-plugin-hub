import { readFileSync, readdirSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { ErrorStore } from '../src/core/store.js'
import { LogProcessor } from '../src/core/processor.js'
import { ErrorBlockCollector } from '../src/core/block-collector.js'
import { buildPrompt } from '../src/core/diagnosis.js'
import { commandFamily } from '../src/core/sanitize.js'

const folder = new URL('../examples/fixtures/go/', import.meta.url)
const fixture = (name: string) => readFileSync(new URL(`${name}.txt`, folder), 'utf8')
const cases = readdirSync(folder).map((file) => file.replace('.txt', ''))
function process(text: string, command = 'go run .') { const store = new ErrorStore(); new LogProcessor(store).finish('s', text, { command, captureMode: 'tool-result', exitCode: 1 }); return store.snapshot('s') }

describe('Go official toolchain', () => {
  it.each(cases)('%s', (name) => {
    const command = name.startsWith('test-') ? 'go test ./...' : name.startsWith('vet-') ? 'go vet ./...' : name.startsWith('compile-') ? 'go build .' : 'go run .'
    const category = name.startsWith('module-') || name.startsWith('install-') ? 'GO_MODULE' : name.startsWith('test-') ? 'GO_TEST_FAILURE' : name.startsWith('vet-') ? 'GO_STATIC_ANALYSIS' : name.startsWith('compile-') ? 'GO_COMPILE' : name === 'listen-port' ? 'APPLICATION_STARTUP' : 'GO_RUNTIME'
    const snapshot = process(fixture(name), command)
    expect(snapshot.active).toHaveLength(1)
    expect(snapshot.active[0]).toMatchObject({ category, language: 'go', runtime: 'go', parserId: 'go' })
  })
  it('selects the business frame, package and test', () => {
    expect(process(fixture('fatal-map')).active[0]).toMatchObject({ file: '/work/app/cache.go', line: 18, symbol: 'main.update' })
    expect(process(fixture('test-assert'), 'go test ./...').active[0]).toMatchObject({ testName: 'TestAdd', packageName: 'example/app', line: 12 })
    expect(process(fixture('compile-win'), 'go build .').active[0]).toMatchObject({ file: 'R:\\demo\\main.go', line: 5, column: 2 })
  })
  it('accepts every chunk boundary, ANSI and CRLF', () => {
    const text = '\u001b[31m' + fixture('panic-user').replaceAll('\n', '\r\n') + '\u001b[0m'
    const baseline = process(text).active[0]
    for (let split = 0; split <= text.length; split++) {
      const store = new ErrorStore(); const processor = new LogProcessor(store); const input = { command: 'go run .', captureMode: 'streaming-tool' as const }
      processor.push('s', text.slice(0, split), input); processor.finish('s', text.slice(split), input)
      expect(store.snapshot('s').active.map((e) => e.fingerprint)).toEqual([baseline!.fingerprint])
    }
  })
  it('deduplicates 1000 repetitions despite goroutine IDs and offsets', () => {
    const store = new ErrorStore(); const processor = new LogProcessor(store)
    for (let index = 0; index < 1000; index++) processor.finish('s', fixture('panic-user').replace('goroutine 1', `goroutine ${index + 1}`).replace('0xff', `0x${index.toString(16)}`), { command: 'go run .', captureMode: 'tool-result' })
    expect(store.snapshot('s').active).toHaveLength(1); expect(store.snapshot('s').active[0]?.occurrences).toBe(1000)
  })
  it('keeps separate consecutive panics and bounds huge lines', () => {
    expect(process(fixture('panic-user') + '\n' + fixture('panic-index')).active).toHaveLength(2)
    const collector = new ErrorBlockCollector(); collector.push('x'.repeat(1000000)); expect(collector.finish()).toEqual([])
  })
  it('redacts goroutine label values before manual AI', () => {
    const event = process(fixture('panic-labels')).active[0]!
    expect(buildPrompt(event, true)).not.toContain('private-customer')
  })
  it('recognizes Windows and Unix Go command families', () => {
    expect(commandFamily('& "C:\\Go\\bin\\go.exe" test ./...')).toBe('go:test')
    expect(commandFamily('/usr/local/go/bin/go vet ./...')).toBe('go:vet')
  })
})
