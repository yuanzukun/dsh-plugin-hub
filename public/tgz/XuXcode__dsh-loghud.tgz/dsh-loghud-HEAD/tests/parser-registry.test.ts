import { Context } from '@deepseek-ai/cordis'
import { describe, expect, it } from 'vitest'
import { LogHudParserRegistry, type LogErrorExtension } from '../src/host/parser-registry.js'
import { ErrorStore } from '../src/core/store.js'
import { LogProcessor } from '../src/core/processor.js'

function extension(id: string, priority = 100): LogErrorExtension {
  return { parser: { id, priority, supports: () => true, parse: (block) => ({ category: 'custom:rust', language: 'custom:rust', runtime: 'custom:rust', toolchain: 'custom:cargo', exceptionType: 'RustFailure', summary: block.lines[0]!, rawContext: block.lines, exceptionChain: [] }) }, rules: [{ id: `rule-${id}`, category: 'custom:rust', severity: 'warning', startPatterns: [/^CUSTOM FAULT/] }] }
}

describe('public Host parser registry', () => {
  it('captures custom text without the built-in prefilter and unloads with its owner', async () => {
    const ctx = new Context(); const registry = new LogHudParserRegistry(ctx)
    const owner = await ctx.plugin((owner) => { registry.register(owner, extension('rust')) })
    const store = new ErrorStore(); new LogProcessor(store, registry).finish('s', 'CUSTOM FAULT: failure\n', { captureMode: 'tool-result' })
    expect(store.snapshot('s').active[0]).toMatchObject({ parserId: 'rust', language: 'custom:rust', severity: 'warning' })
    await owner.dispose()
    expect(registry.parsers.some((parser) => parser.id === 'rust')).toBe(false)
  })
  it('rejects duplicate parser and rule IDs atomically', () => {
    const ctx = new Context(); const registry = new LogHudParserRegistry(ctx)
    registry.register(ctx, extension('rust'))
    expect(() => registry.register(ctx, extension('rust'))).toThrow('Duplicate')
    const invalid = extension('other'); invalid.rules = extension('rust').rules
    expect(() => registry.register(ctx, invalid)).toThrow('duplicate')
    expect(registry.parsers.some((parser) => parser.id === 'other')).toBe(false)
  })
  it('keeps stable priorities, Generic last, and falls through exceptions', () => {
    const ctx = new Context(); const registry = new LogHudParserRegistry(ctx)
    registry.register(ctx, { ...extension('broken', 900), parser: { ...extension('broken').parser, priority: 900, parse: () => { throw new Error('extension failed') } } })
    registry.register(ctx, extension('fallback', -100))
    expect(registry.parsers.at(-1)?.id).toBe('generic')
    const store = new ErrorStore(); new LogProcessor(store, registry).finish('s', 'CUSTOM FAULT: failure\n', { captureMode: 'tool-result' })
    expect(store.snapshot('s').active[0]?.parserId).toBe('fallback')
  })
})
