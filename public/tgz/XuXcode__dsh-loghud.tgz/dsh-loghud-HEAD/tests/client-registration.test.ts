import { describe, expect, it, vi } from 'vitest'
import type { Context } from '@deepseek-ai/cordis'
import { apply } from '../src/client/index.js'

describe('client slot lifecycle', () => {
  it('waits for parent declarations before registering both contributions', () => {
    const deferred = new Map<string, () => unknown>()
    const register = vi.fn((_options: unknown, _component: unknown) => () => {})
    const ctx = {
      slots: { inject: (name: string, callback: () => unknown) => deferred.set(name, callback), register },
      settingsScope: { bind: () => ({}) }, locale: {},
    } as unknown as Context
    apply(ctx)
    expect(register).not.toHaveBeenCalled()
    deferred.get('shell.overlay')!()
    deferred.get('settings.plugin.item')!()
    expect(register.mock.calls.map((args) => args[0])).toEqual([
      { name: 'shell.overlay', id: 'dsh-loghud', order: 30 },
      { name: 'settings.plugin.item', key: 'dsh-loghud' },
    ])
  })
})
