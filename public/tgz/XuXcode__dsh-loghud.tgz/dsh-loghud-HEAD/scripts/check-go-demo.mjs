import { spawnSync } from 'node:child_process'
const cwd = new URL('../examples/go-demo', import.meta.url)
const cases = [
  { args: ['run', '.', 'panic'], pattern: /panic:/ },
  { args: ['run', '.', 'port'], pattern: /address already in use|Only one usage of each socket address/i },
  { args: ['build', '-tags', 'loghud_compile_failure', '.'], pattern: /cannot use/ },
  { args: ['test', '-count=1', './...'], pattern: /--- FAIL: TestExample/ },
]
for (const item of cases) {
  const result = spawnSync('go', item.args, { cwd, encoding: 'utf8', timeout: 120000, env: { ...process.env, LOGHUD_FAIL: '1' } })
  if (result.error) throw result.error
  if (result.status === 0 || !item.pattern.test(result.stdout + result.stderr)) throw new Error(`Unexpected Go demo result: ${item.args.join(' ')}\n${result.stdout}${result.stderr}`)
  console.log(`Verified expected failure: go ${item.args.join(' ')}`)
}
