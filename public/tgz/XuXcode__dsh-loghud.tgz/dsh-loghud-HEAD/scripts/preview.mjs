// Local visual QA harness, never shipped in the plugin package.
import http from 'node:http'
import { readFileSync } from 'node:fs'
import { ErrorStore, LogProcessor } from '../lib/core.mjs'
const root = new URL('../', import.meta.url)
const store = new ErrorStore()
new LogProcessor(store).finish('preview', readFileSync(new URL('examples/fixtures/go/test-assert.txt', root), 'utf8'), { command: 'go test ./...', captureMode: 'tool-result', exitCode: 1 })
new LogProcessor(store).finish('preview', readFileSync(new URL('examples/fixtures/go/panic-user.txt', root), 'utf8'), { command: 'go run .', captureMode: 'streaming-tool', exitCode: 1 })
const routes = {
  '/react.js': new URL('node_modules/react/umd/react.development.js', root),
  '/react-dom.js': new URL('node_modules/react-dom/umd/react-dom.development.js', root),
  '/jsx.js': new URL('node_modules/react/cjs/react-jsx-runtime.development.js', root),
  '/client.js': new URL('lib/client.js', root),
}
const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LogHUD local UI verification</title>
<style>body{margin:0;padding:24px;font:14px system-ui;background:var(--dsw-alias-bg-layer-1,#f7f8fa);color:var(--dsw-alias-label-primary,#17212e)}body[data-theme=dark]{--dsw-alias-bg-layer-1:#17191c;--dsw-alias-bg-layer-2:#202327;--dsw-alias-bg-layer-3:#2a2e33;--dsw-alias-label-primary:#eee;--dsw-alias-label-secondary:#a6acb5;--dsw-alias-border-l2:#3a4149}body[data-theme=light]{--dsw-alias-bg-layer-2:#fff;--dsw-alias-bg-layer-3:#f1f3f5;--dsw-alias-border-l2:#d9dfe6;--dsw-alias-label-secondary:#657080}.preview{max-width:640px;margin:80px 40px}#settings{margin-top:100px;max-width:700px}</style></head><body data-theme="light"><nav>LogHUD — isolated visual QA <button id="theme">Light / Dark</button> <button id="language">English / 中文</button></nav><main class="preview"><h1>Local development session</h1><p>This page mounts the actual built client bundle with deterministic Go fixtures. It is not the Harness shell.</p><pre>go test ./...<br>--- FAIL: TestAdd (0.00s)<br>    add_test.go:12: got 4, want 5</pre><div id="settings"></div></main><div id="hud"></div><script src="/react.js"></script><script src="/react-dom.js"></script><script>window.process={env:{NODE_ENV:'development'}};window.exports={};window.require=()=>React;</script><script src="/jsx.js"></script><script>
const jsx=window.exports;const callbacks=new Set();let lang='zh';let localeSnapshot={active:lang};const locale={getSnapshot:()=>localeSnapshot,subscribe:fn=>{callbacks.add(fn);return()=>callbacks.delete(fn)}};
document.getElementById('theme').onclick=()=>document.body.dataset.theme=document.body.dataset.theme==='light'?'dark':'light';document.getElementById('language').onclick=()=>{lang=lang==='zh'?'en':'zh';localeSnapshot={active:lang};callbacks.forEach(fn=>fn())};
const listeners=new Set();let settings={enabled:true,enableAiAnalysis:true,secretRedaction:true,beginnerFriendly:true,maxActiveErrors:100,maxErrorContextLines:120,maxResolvedHistory:50,maxIgnoredHistory:50};let state={status:'ready',value:settings,base:settings,user:{},revision:1,writable:true,mode:'host'};const scope={getSnapshot:()=>state,subscribe:fn=>{listeners.add(fn);return()=>listeners.delete(fn)},mutate:async(ops,revision)=>{if(revision!==state.revision)throw Error('Revision conflict');const user={...state.user};for(const op of ops)op.op==='unset'?delete user[op.path[0]]:user[op.path[0]]=op.value;state={...state,user,value:{...settings,...user},revision:state.revision+1};listeners.forEach(fn=>fn())}};
window.__ModuleLoader__={load:entry=>{const plugin=entry.factory(name=>name==='react'?React:jsx);plugin.apply({locale,settingsScope:{bind:()=>scope},slots:{inject:(_,fn)=>fn(),register:(options,Component)=>{const target=options.name==='shell.overlay'?'hud':'settings';ReactDOM.createRoot(document.getElementById(target)).render(React.createElement(Component,{useSessions:selector=>selector({current:'preview'})}));return()=>{}}}})}};</script><script src="/client.js"></script></body></html>`
const server = http.createServer((req, res) => {
  if (req.url === '/') { res.setHeader('content-type', 'text/html; charset=utf-8'); res.end(html); return }
  if (routes[req.url]) { res.setHeader('content-type', 'text/javascript'); res.end(readFileSync(routes[req.url])); return }
  if (req.url?.endsWith('/events')) { res.writeHead(200, { 'content-type': 'text/event-stream' }); res.write(`event: snapshot\ndata: ${JSON.stringify(store.snapshot('preview'))}\n\n`); const timer=setInterval(()=>res.write(`event: heartbeat\ndata: {}\n\n`),15000); req.on('close',()=>clearInterval(timer));return }
  if (req.url?.endsWith('/snapshot')) { res.setHeader('content-type','application/json');res.end(JSON.stringify(store.snapshot('preview')));return }
  res.writeHead(404);res.end()
})
server.listen(0, '127.0.0.1', () => console.log(`Preview: http://127.0.0.1:${server.address().port}`))
