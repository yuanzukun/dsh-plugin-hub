import { readFileSync } from 'node:fs'
const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'))
const plugin = JSON.parse(readFileSync(new URL('../dsh.plugin.json', import.meta.url), 'utf8'))
if (pkg.version !== plugin.version) throw new Error('Package and plugin versions disagree')
for (const dependencies of [pkg.dependencies, pkg.peerDependencies, pkg.devDependencies]) {
  for (const [name, version] of Object.entries(dependencies ?? {})) if (name.startsWith('@deepseek-ai/dsh-') && version !== '0.1.2-rc.1') throw new Error(`Mixed Harness dependency: ${name}@${version}`)
}
if (process.env.GITHUB_REF_TYPE === 'tag' && process.env.GITHUB_REF_NAME !== `v${pkg.version}`) throw new Error('Tag and package versions disagree')
console.log(`Release metadata verified: v${pkg.version}`)
