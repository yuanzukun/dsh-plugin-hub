import type { ParsedError } from '../shared/types.js'
import type { LogErrorParser } from './parser.js'

const LOCATION = /^\s*(.+\.go):(\d+)(?::(\d+))?(?:\s+\+0x[\da-f]+)?(?::\s*(.*))?$/i
const dependency = (file: string) => /(?:\/|^)(?:pkg\/mod|vendor|go\/src|goroot\/src)\//i.test(file.replace(/\\/g, '/'))

export const goParser: LogErrorParser = {
  id: 'go', priority: 325,
  supports: (block, context) => block.rule.language === 'go' || /^go:/.test(context.commandFamily ?? '')
    || block.lines.some((line) => /^(?:panic:|fatal error:|goroutine \d+ \[)|\.go:\d+/.test(line)),
  parse(block, context) {
    const lines = block.lines.map((line) => line.trimEnd())
    const text = lines.join('\n')
    const locations = lines.flatMap((line, index) => {
      const match = line.match(LOCATION)
      if (!match?.[1]) return []
      const previous = lines[index - 1]?.trim().replace(/^created by /, '')
      const symbol = previous?.match(/^(.+?)\(/)?.[1]
      return [{ file: match[1].trim(), line: Number(match[2]), ...(match[3] ? { column: Number(match[3]) } : {}), ...(symbol ? { symbol } : {}), message: match[4] }]
    })
    const frame = locations.find((item) => !dependency(item.file)) ?? locations[0]
    const panic = text.match(/^(panic|fatal error):\s*(.+)$/m)
    const testName = text.match(/--- FAIL: (\S+)/)?.[1]
    const packageName = text.match(/^#[ \t]+([^\s[]+)|^FAIL[ \t]+([^\s[]+)/m)?.slice(1).find(Boolean)
    const moduleFailure = /^go:\s|missing go.sum entry|no required module provides package|checksum mismatch|SECURITY ERROR|unrecognized import path/m.test(text)
    const category: ParsedError['category'] = /address already in use|Only one usage of each socket address/i.test(text) ? 'APPLICATION_STARTUP'
      : moduleFailure ? 'GO_MODULE' : testName || /^go:test/.test(context.commandFamily ?? '') ? 'GO_TEST_FAILURE'
        : /^go:vet/.test(context.commandFamily ?? '') ? 'GO_STATIC_ANALYSIS' : panic ? 'GO_RUNTIME' : frame ? 'GO_COMPILE' : 'GO_RUNTIME'
    const exceptionType = category === 'APPLICATION_STARTUP' ? 'GoAddressInUse' : panic?.[1] === 'fatal error' ? 'GoFatalError'
      : panic ? 'GoPanic' : category === 'GO_MODULE' ? 'GoModuleError' : category === 'GO_TEST_FAILURE' ? 'GoTestFailure'
        : category === 'GO_STATIC_ANALYSIS' ? 'GoVetError' : category === 'GO_COMPILE' ? 'GoCompileError' : 'GoRuntimeError'
    const summary = panic?.[2] ?? frame?.message ?? lines.find((line) => /^(?:go:|--- FAIL:)|missing go.sum|checksum mismatch/.test(line)) ?? lines.find(Boolean) ?? exceptionType
    const port = text.match(/(?:listen|dial) tcp(?:\d)? [^\s]*:(\d+)/)?.[1]
    const target = text.match(/(?:provides package|go.sum entry for module providing package)\s+(\S+)/)?.[1]
    return { category, language: 'go', runtime: 'go', toolchain: 'go', exceptionType, summary, rootMessage: summary,
      ...(frame ? { file: frame.file, line: frame.line, ...(frame.column ? { column: frame.column } : {}), ...(frame.symbol ? { symbol: frame.symbol } : {}) } : {}),
      ...(packageName ? { packageName } : {}), ...(testName ? { testName } : {}), ...(port ? { port: Number(port) } : {}), ...(target ? { target } : {}),
      exceptionChain: lines.filter((line) => /^(panic|fatal error):/.test(line)).map((line) => line.replace(/\s*\[recovered.*$/, '')),
      rawContext: lines,
    }
  },
}
