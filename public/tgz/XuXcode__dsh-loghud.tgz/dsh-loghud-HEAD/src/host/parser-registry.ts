import { Service, type Context } from '@deepseek-ai/cordis'
import { DEFAULT_PARSERS, type LogErrorParser } from '../core/parser.js'
import { DEFAULT_RULES } from '../core/rules.js'
import type { ErrorDetectionRule } from '../shared/types.js'

export interface LogErrorExtension {
  parser: LogErrorParser
  rules: readonly ErrorDetectionRule[]
}

declare module '@deepseek-ai/cordis' {
  interface Context { loghudParsers: LogHudParserRegistry }
}

/** Trusted Host extensions only. Each registration belongs to its Cordis owner. */
export class LogHudParserRegistry extends Service {
  private readonly entries = new Map<string, LogErrorExtension>()
  constructor(ctx: Context) { super(ctx, 'loghudParsers') }

  register(owner: Context, extension: LogErrorExtension): () => void {
    const { parser, rules } = extension
    if (!parser.id || !Number.isFinite(parser.priority) || typeof parser.supports !== 'function' || typeof parser.parse !== 'function') throw new Error('Invalid LogHUD parser')
    if (this.entries.has(parser.id) || DEFAULT_PARSERS.some((item) => item.id === parser.id)) throw new Error(`Duplicate LogHUD parser: ${parser.id}`)
    const ids = new Set(this.rules.map((rule) => rule.id))
    for (const rule of rules) {
      if (!rule.id || ids.has(rule.id) || !rule.startPatterns.length || rule.startPatterns.some((pattern) => !(pattern instanceof RegExp))) throw new Error(`Invalid or duplicate LogHUD rule: ${rule.id}`)
      ids.add(rule.id)
    }
    const safeParser: LogErrorParser = {
      id: parser.id, priority: parser.priority,
      supports: (block, context) => { try { return parser.supports(block, context) } catch { this.ctx.logger.warn(`LogHUD parser ${parser.id}: supports failed`); return false } },
      parse: (block, context) => { try { const result = parser.parse(block, context); if (result && (!result.exceptionType || !Array.isArray(result.rawContext) || !Array.isArray(result.exceptionChain))) throw new Error('Invalid result'); return result } catch { this.ctx.logger.warn(`LogHUD parser ${parser.id}: parse failed`); return undefined } },
    }
    const registration = { parser: safeParser, rules: rules.map((rule) => ({ ...rule, startPatterns: [...rule.startPatterns] })) }
    this.entries.set(parser.id, registration)
    const dispose = () => { if (this.entries.get(parser.id) === registration) this.entries.delete(parser.id) }
    owner.effect(() => dispose, `loghud parser: ${parser.id}`)
    return dispose
  }

  get rules(): readonly ErrorDetectionRule[] { return this.entries.size ? [...this.entries.values()].flatMap((item) => item.rules).concat(DEFAULT_RULES) : DEFAULT_RULES }
  get parsers(): readonly LogErrorParser[] {
    return [...DEFAULT_PARSERS.filter((parser) => parser.id !== 'generic'), ...[...this.entries.values()].map((item) => item.parser)]
      .sort((a, b) => b.priority - a.priority).concat(DEFAULT_PARSERS.filter((parser) => parser.id === 'generic'))
  }
}
