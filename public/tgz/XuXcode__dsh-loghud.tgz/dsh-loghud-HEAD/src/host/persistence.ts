import { defineDomain, domainTable, type DomainFacility } from '@deepseek-ai/dsh-storage-domain'
import { z } from 'zod'
import type { ErrorStore } from '../core/store.js'
import { DEFAULT_SETTINGS, type LogHudSettings, type SessionSnapshot } from '../shared/types.js'

const settingsSchema = z.object({
  enabled: z.boolean(), enableAiAnalysis: z.boolean(), maxErrorContextLines: z.number().int().min(10).max(1000),
  maxActiveErrors: z.number().int().min(10).max(500).default(100),
  maxResolvedHistory: z.number().int().min(0).max(500), maxIgnoredHistory: z.number().int().min(0).max(500).default(50),
  secretRedaction: z.boolean(), beginnerFriendly: z.boolean(),
})
import { snapshotSchema } from '../shared/snapshot.js'
export { migrateSessionSnapshot } from '../shared/snapshot.js'

const LOGHUD_DOMAIN = defineDomain({
  name: 'dsh_loghud', version: 1,
  global: { schema: z.object({ initialized: z.boolean(), settings: settingsSchema }), initial: { initialized: false, settings: DEFAULT_SETTINGS } },
  tables: { sessions: domainTable<string, SessionSnapshot>(snapshotSchema) },
})

export async function openPersistence(facility: DomainFacility, store: ErrorStore): Promise<() => Promise<void>> {
  const domain = await facility.open(LOGHUD_DOMAIN)
  const persisted = domain.global.get()
  if (!persisted.initialized) await domain.global.set({ initialized: true, settings: { ...store.settings } as LogHudSettings })
  const sessions = domain.table('sessions')
  for (const [, snapshot] of sessions.entries()) store.restore(snapshot)
  const dispose = store.subscribeAll((snapshot) => { void sessions.put(snapshot.sessionId, snapshot).catch(() => undefined) })
  return async () => { dispose(); await domain.close() }
}
