import type { Context as ClientContext } from '@deepseek-ai/cordis'
import { createElement } from 'react'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings-plugins/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
import { decodeLogHudSettings } from '../shared/validation.js'
import { LogHudOverlay } from './LogHud.js'
import { LogHudSettingsPage } from './SettingsPage.js'

export const inject = ['slots', 'settingsScope', 'locale']

export function apply(ctx: ClientContext): void {
  const scope = ctx.settingsScope.bind({ namespace: 'dsh-loghud', decode: decodeLogHudSettings })
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({ name: 'shell.overlay', id: 'dsh-loghud', order: 30 },
    (props) => createElement(LogHudOverlay, { ...props, locale: ctx.locale, settingsScope: scope })))
  ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({ name: 'settings.plugin.item', key: 'dsh-loghud' },
    () => createElement(LogHudSettingsPage, { scope, locale: ctx.locale })))
}
