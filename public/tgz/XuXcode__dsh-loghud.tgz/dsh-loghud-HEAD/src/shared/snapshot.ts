import { z } from 'zod'
import type { LogHudSettings, SessionSnapshot } from './types.js'
import { decodeLogHudSettings } from './validation.js'

const categorySchema = z.enum(['SPRING_IOC', 'MYBATIS', 'DATABASE', 'REDIS', 'HTTP', 'JAVA_RUNTIME', 'NODE_RUNTIME', 'TYPESCRIPT_COMPILE', 'MODULE_RESOLUTION', 'BUILD_FAILURE', 'PYTHON_RUNTIME', 'PYTHON_IMPORT', 'PYTHON_TEST_FAILURE', 'APPLICATION_STARTUP', 'GO_RUNTIME', 'GO_COMPILE', 'GO_TEST_FAILURE', 'GO_MODULE', 'GO_STATIC_ANALYSIS', 'UNKNOWN']).or(z.templateLiteral(['custom:', z.string()]))
export const eventSchema = z.object({
  id: z.string(), fingerprint: z.string(), version: z.number().int(), status: z.enum(['active', 'resolved', 'ignored']), severity: z.enum(['error', 'warning']),
  framework: z.string().optional(), language: z.enum(['java', 'javascript', 'typescript', 'python', 'go', 'unknown']).or(z.templateLiteral(['custom:', z.string()])).optional(), runtime: z.enum(['jvm', 'node', 'python', 'go', 'unknown']).or(z.templateLiteral(['custom:', z.string()])).optional(),
  toolchain: z.enum(['java', 'maven', 'gradle', 'node', 'npm', 'pnpm', 'yarn', 'typescript', 'vite', 'rollup', 'webpack', 'next', 'vitest', 'jest', 'python', 'pip', 'pytest', 'uv', 'poetry', 'pipenv', 'go', 'unknown']).or(z.templateLiteral(['custom:', z.string()])).optional(),
  packageName: z.string().optional(), testName: z.string().optional(), parserId: z.string().optional(), errorCode: z.string().optional(), category: categorySchema,
  exceptionType: z.string(), summary: z.string(), rootMessage: z.string().optional(), target: z.string().optional(), file: z.string().optional(), line: z.number().int().optional(), column: z.number().int().optional(),
  symbol: z.string().optional(), port: z.number().int().optional(), command: z.string().optional(), commandFamily: z.string().optional(), captureMode: z.enum(['tool-result', 'streaming-tool']),
  firstSeenAt: z.number(), lastSeenAt: z.number(), resolvedAt: z.number().optional(), ignoredAt: z.number().optional(), occurrences: z.number().int(), exceptionChain: z.array(z.string()), rawContext: z.array(z.string()),
  diagnosis: z.object({ simpleExplanation: z.string(), likelyCauses: z.array(z.string()), suggestedChecks: z.array(z.string()), confidence: z.enum(['high', 'medium', 'low']), locale: z.enum(['en', 'zh-CN']).optional() }).optional(),
  diagnosisError: z.string().optional(),
})
export const snapshotSchema = z.object({
  schemaVersion: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4)]).default(1), sessionId: z.string(), health: z.enum(['HEALTHY', 'BROKEN', 'UNKNOWN']), observedCommand: z.boolean(),
  active: z.array(eventSchema), resolved: z.array(eventSchema), ignored: z.array(eventSchema).default([]), droppedActiveErrors: z.number().int().min(0).default(0), revision: z.number().int(), settings: z.custom<LogHudSettings>((value) => decodeLogHudSettings(value) !== undefined).optional(),
}).transform((snapshot): SessionSnapshot => ({ ...snapshot, schemaVersion: 4 }))

export function migrateSessionSnapshot(value: unknown): SessionSnapshot { return snapshotSchema.parse(value) }
