package main

import (
	"fmt"
	"net"
	"os"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Choose panic or port")
		return
	}
	switch os.Args[1] {
	case "panic":
		var value *int
		fmt.Println(*value)
	case "port":
		listener, err := net.Listen("tcp", "127.0.0.1:0")
		if err != nil { panic(err) }
		defer listener.Close()
		second, err := net.Listen("tcp", listener.Addr().String())
		if err != nil { panic(err) }
		second.Close()
	}
}
