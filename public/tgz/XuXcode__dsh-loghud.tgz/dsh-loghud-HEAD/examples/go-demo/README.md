# Go demo / Go 演示

Requires Go 1.26 or newer. Standard library only; no external dependencies. Run from this directory through Harness's shell or `loghud_run`.

需要 Go 1.26 或更新版本，只使用标准库。在本目录通过 Harness Shell 或 `loghud_run` 执行。

```sh
go run . panic
go run . port
go build -tags loghud_compile_failure .
```

The port demo binds an ephemeral loopback port and immediately attempts to bind it again. It does not kill or interfere with another application.

端口演示自行申请本机临时端口后再次绑定，不需要停止其他程序。

Test failure / 测试失败：

```sh
LOGHUD_FAIL=1 go test -count=1 ./...
```

PowerShell:

```powershell
$env:LOGHUD_FAIL='1'
go test -count=1 ./...
Remove-Item Env:LOGHUD_FAIL
```

Without Go installed, use the deterministic text samples in `../fixtures/go`.

没有 Go 环境时，可使用 `../fixtures/go` 中的文本样例。
