module example.com/loghud-demo

go 1.26
