package main

import (
	"os"
	"testing"
)

func TestExample(t *testing.T) {
	if os.Getenv("LOGHUD_FAIL") != "1" { t.Skip("Set LOGHUD_FAIL=1 to demonstrate an assertion failure") }
	t.Fatal("got 4, want 5")
}
