//go:build loghud_compile_failure

package main

var compileFailure int = "deliberate type mismatch"
