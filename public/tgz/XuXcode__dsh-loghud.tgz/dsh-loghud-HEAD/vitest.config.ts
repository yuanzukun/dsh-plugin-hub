import { defineConfig } from 'vitest/config'

export default defineConfig({ test: { include: ['tests/**/*.test.{ts,tsx}'], coverage: { reporter: ['text', 'html'] } } })
