import { describe, expect, it } from 'vitest'
import { Config, type Config as PluginConfig } from '../../src/plugin-market/index.ts'

describe('plugin market configuration', () => {
  it('provides bounded defaults', () => {
    expect(Config({} as PluginConfig)).toMatchObject({
      topic: 'dsh-plugin',
      channelUrl: 'https://raw.githubusercontent.com/sky-unicorn/dsh-enhanced-plugins/market-index/plugins-cache.json',
      pageSize: 12,
    })
  })

  it('rejects an excessive discovery page', () => {
    expect(() => Config({ pageSize: 31 } as PluginConfig)).toThrow()
  })
})
