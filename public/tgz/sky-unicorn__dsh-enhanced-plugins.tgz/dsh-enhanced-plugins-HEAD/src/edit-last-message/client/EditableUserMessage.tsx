import {
  Fragment, useCallback, useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent,
} from 'react'
import type { UserMessageNode } from '@deepseek-ai/dsh-client-ui-chat/client'
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import {
  Button, IconCheckOutlineRegular, IconCopyOutlineRegular, IconEditOutlineRegular, IconLoadingOutlineRegular,
  IconSendOutlineRegular, JsonBlock, projectUserText, Tooltip, writeClipboard, FileTypeIcon, fileSizeText,
} from '@deepseek-ai/dsh-client-ui-primitives'
import type { EditLastMessageRequest } from './edit-session.ts'
import {
  isLatestRootEdit, latestEditableMessageSeq, loadedEditSkills, type EditedUserChatData,
} from './conversation-nodes.ts'
import type { EditLastMessageLocaleKey } from './locales.ts'
import css from './EditableUserMessage.module.css'

type UserImage = Extract<UserMessageNode['content'][number], { type: 'image' }>
interface UserFileAttachment {
  readonly name: string
  readonly bytes: number
}
type PresentedAttachment =
  | { readonly type: 'image'; readonly image: { attachment: UserImage['attachment'] } }
  | { readonly type: 'file'; readonly file: UserFileAttachment }

/** Actions injected by the slot registration for one session. */
export interface EditableUserMessageInjected {
  editAndResend(request: EditLastMessageRequest): Promise<void>
}

/** Full props for the shadowing user-message renderer. */
export type EditableUserMessageProps = PropsRuntime<'conversation.chat.node', 'user'>
  & PropsLocale<'edit-last-message'>
  & EditableUserMessageInjected

/** Props for the replacement projection rendered at the original bubble position. */
export type EditedUserMessageProps = PropsRuntime<'conversation.chat.node', 'edited-user'>
  & PropsLocale<'edit-last-message'>
  & EditableUserMessageInjected

/** Props for the invisible durable end marker of one discarded raw range. */
export type EditCutEndProps = PropsRuntime<'conversation.chat.node', 'edit-cut-end'>

/** Return complete editable text, or undefined when any block is non-text. */
export function editableText(content: UserMessageNode['content']): string | undefined {
  if (content.some(block => block.type !== 'text')) return undefined
  const text = content.map(block => block.type === 'text' ? block.text : '').join('')
  return text.trim().length === 0 ? undefined : text
}

function contentParts(content: readonly unknown[]): {
  text: string
  attachments: PresentedAttachment[]
  rest: unknown[]
} {
  const texts: string[] = []
  const attachments: PresentedAttachment[] = []
  const rest: unknown[] = []
  for (const value of content) {
    const block = value as { readonly type?: string; readonly text?: string; readonly attachment?: unknown }
    if (block.type === 'text' && typeof block.text === 'string') texts.push(block.text)
    else if (block.type === 'image' && block.attachment !== undefined) {
      attachments.push({ type: 'image', image: { attachment: block.attachment as UserImage['attachment'] } })
    } else if (block.type === 'file' && block.attachment !== undefined) {
      attachments.push({ type: 'file', file: block.attachment as UserFileAttachment })
    } else rest.push(value)
  }
  return { text: texts.join(''), attachments, rest }
}

function extensionOf(name: string): string {
  const dot = name.lastIndexOf('.')
  if (dot <= 0 || dot === name.length - 1) return ''
  return name.slice(dot + 1).toUpperCase().slice(0, 8)
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

const EDITOR_MAX_HEIGHT_PX = 192

interface EditableBubbleProps extends EditableUserMessageInjected {
  readonly data: Pick<UserMessageNode, 'seq' | 'time' | 'content' | 'source'> & {
    readonly referenceLabels?: readonly string[]
    readonly skillNames?: readonly string[]
  }
  readonly renderMessageImages: EditableUserMessageProps['renderMessageImages']
  readonly useSession: EditableUserMessageProps['useSession']
  readonly useChat: EditableUserMessageProps['useChat']
  readonly openFile: EditableUserMessageProps['openFile']
  readonly openSkill: EditableUserMessageProps['openSkill']
  readonly t: EditableUserMessageProps['t']
}

/** Shared bubble body for an append-origin or replacement-projected user message. */
function EditableUserBubble({ data, renderMessageImages, useSession, useChat, openFile, openSkill, editAndResend, t }: EditableBubbleProps) {
  const { text, attachments, rest } = contentParts(data.content)
  const compactImages = attachments.length > 1
  const candidate = editableText(data.content)
  const running = useSession(snapshot => snapshot.running)
  const subagent = useSession(snapshot => snapshot.subagent !== null)
  const latestSeq = useChat(snapshot => latestEditableMessageSeq(snapshot))
  const canEdit = !running && !subagent && candidate !== undefined && latestSeq === data.seq
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(candidate ?? '')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const copyTimer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => () => {
    if (copyTimer.current !== null) clearTimeout(copyTimer.current)
  }, [])
  useEffect(() => {
    if (!editing) return
    const textarea = textareaRef.current
    if (textarea === null) return
    textarea.focus()
    textarea.setSelectionRange(textarea.value.length, textarea.value.length)
  }, [editing])
  useLayoutEffect(() => {
    if (!editing) return
    const textarea = textareaRef.current
    if (textarea === null) return
    textarea.style.height = '0px'
    const nextHeight = Math.min(textarea.scrollHeight, EDITOR_MAX_HEIGHT_PX)
    textarea.style.height = `${Math.max(24, nextHeight)}px`
    textarea.style.overflowY = textarea.scrollHeight > EDITOR_MAX_HEIGHT_PX ? 'auto' : 'hidden'
  }, [draft, editing])
  useEffect(() => {
    if (!canEdit && editing) setEditing(false)
  }, [canEdit, editing])

  const onCopy = useCallback(() => {
    void writeClipboard(text).then((ok) => {
      if (!ok) return
      setCopied(true)
      if (copyTimer.current !== null) clearTimeout(copyTimer.current)
      copyTimer.current = setTimeout(() => { setCopied(false) }, 1_000)
    })
  }, [text])
  const beginEdit = useCallback(() => {
    if (!canEdit || candidate === undefined) return
    setDraft(candidate)
    setError(null)
    setEditing(true)
  }, [canEdit, candidate])
  const cancelEdit = useCallback(() => {
    if (saving) return
    setEditing(false)
    setError(null)
  }, [saving])
  const save = useCallback(async () => {
    if (saving) return
    if (draft.trim().length === 0) {
      setError(t('error.empty'))
      return
    }
    setSaving(true)
    setError(null)
    try {
      await editAndResend({ messageSeq: data.seq, text: draft })
    } catch (cause) {
      setError(t('error.failed', { message: errorMessage(cause) }))
      setSaving(false)
    }
  }, [data.seq, draft, editAndResend, saving, t])
  const onEditorKeyDown = useCallback((event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Escape') {
      event.preventDefault()
      cancelEdit()
    } else if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
      event.preventDefault()
      void save()
    }
  }, [cancelEdit, save])

  return (
    <div className={css.userRow} data-time-hover-root>
      <div className={css.userStack}>
        {attachments.length > 0 && (
          <div className={css.attachmentRow} data-message-attachments>
            {attachments.map((attachment, index) => attachment.type === 'image'
              ? (
                  <Fragment key={`image:${index}`}>
                    {renderMessageImages({
                      images: [attachment.image],
                      align: 'end',
                      compact: compactImages,
                    } as Parameters<typeof renderMessageImages>[0])}
                  </Fragment>
                )
              : (
                  <span key={`file:${index}`} className={css.fileCard} title={attachment.file.name}>
                    <FileTypeIcon path={attachment.file.name} className={css.fileIcon} />
                    <span className={css.fileContent}>
                      <span className={css.fileName}>{attachment.file.name}</span>
                      <span className={css.fileMeta}>
                        {[extensionOf(attachment.file.name), fileSizeText(attachment.file.bytes)]
                          .filter(Boolean).join(' ')}
                      </span>
                    </span>
                  </span>
                ))}
          </div>
        )}
        {(text !== '' || rest.length > 0) && (
          <div className={css.bubble} data-editing={editing || undefined}>
            {editing
              ? (
                  <div className={css.editorPanel} aria-busy={saving || undefined}>
                    <textarea
                      ref={textareaRef}
                      className={css.editor}
                      aria-label={t('editor.label')}
                      value={draft}
                      disabled={saving}
                      rows={1}
                      onChange={event => { setDraft(event.currentTarget.value) }}
                      onKeyDown={onEditorKeyDown}
                    />
                    {error !== null && <div className={css.editorError} role="alert">{error}</div>}
                    <div className={css.editorFooter}>
                      <span className={css.editorHint}>{t('editor.hint')}</span>
                      <div className={css.editorButtons}>
                        <Button
                          className={css.editorButton}
                          variant="ghost"
                          size="sm"
                          aria-label={t('action.cancel')}
                          disabled={saving}
                          onClick={cancelEdit}
                        >
                          {t('button.cancel')}
                        </Button>
                        <Button
                          className={css.editorButton}
                          variant="primary"
                          size="sm"
                          icon={saving
                            ? <IconLoadingOutlineRegular className={css.loadingIcon} />
                            : <IconSendOutlineRegular size={16} />}
                          aria-label={saving ? t('action.saving') : t('action.save')}
                          disabled={saving}
                          onClick={() => { void save() }}
                        >
                          {saving ? t('button.saving') : t('button.resend')}
                        </Button>
                      </div>
                    </div>
                  </div>
                )
              : (
                  <>
                    {projectUserText(text, data.referenceLabels ?? [], data.skillNames ?? [], 'skill', { openFile, openSkill })}
                    {rest.map((block, index) => (
                      <JsonBlock
                        key={index}
                        label={t('content.extraBlock')}
                        payload={block}
                        truncatedLabel={total => t('content.truncated', { total })}
                      />
                    ))}
                  </>
                )}
          </div>
        )}
      </div>
      {!editing && (
        <div className={css.actions}>
          <span className={css.time}>{new Date(data.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          <Tooltip label={copied ? t('action.copied') : t('action.copy')} side="bottom">
            <button type="button" className={css.action} aria-label={copied ? t('action.copied') : t('action.copy')} onClick={onCopy}>
              {copied ? <IconCheckOutlineRegular /> : <IconCopyOutlineRegular />}
            </button>
          </Tooltip>
          {canEdit && (
            <Tooltip label={t('action.edit')} side="bottom">
              <button type="button" className={css.action} aria-label={t('action.edit')} onClick={beginEdit}>
                <IconEditOutlineRegular />
              </button>
            </Tooltip>
          )}
        </div>
      )}
    </div>
  )
}

/** User bubble with inline edit-and-resend support on the stopped transcript tail. */
export function EditableUserMessage({
  node, renderMessageImages, useSession, useChat, openFile, openSkill, editAndResend, t,
}: EditableUserMessageProps) {
  return (
    <EditableUserBubble
      data={node.data}
      renderMessageImages={renderMessageImages}
      useSession={useSession}
      useChat={useChat}
      openFile={openFile}
      openSkill={openSkill}
      editAndResend={editAndResend}
      t={t}
    />
  )
}

function flowItemOf(node: HTMLElement | null): HTMLElement | null {
  return node?.closest<HTMLElement>('[data-chat-flow-key]') ?? null
}

function matchingFlowItem(flow: HTMLElement, attribute: 'chatFlowKey' | 'editCutEnd', value: string): HTMLElement | null {
  const selector = attribute === 'chatFlowKey' ? '[data-chat-flow-key]' : '[data-edit-cut-end]'
  for (const candidate of flow.querySelectorAll<HTMLElement>(selector)) {
    const actual = candidate.dataset[attribute]
    const matches = attribute === 'chatFlowKey'
      // DSH prefixes the opaque flow key and currently concatenates the
      // message id directly after `input-message`; match only that stable
      // identity suffix so prefix/order changes do not expose the old bubble.
      ? actual?.endsWith(`input-message${value}`) === true
      : actual === value
    if (!matches) continue
    return attribute === 'chatFlowKey' ? candidate : flowItemOf(candidate)
  }
  return null
}

/**
 * Hide only raw Chat rows shadowed by this durable replacement. The model
 * surface is authoritative; this DOM range is its presentation counterpart
 * because the built-in Chat builder intentionally retains append-origin rows.
 */
function useDiscardedRange(
  markerRef: { readonly current: HTMLDivElement | null },
  data: EditedUserChatData,
  active: boolean,
  flowRevision: string,
): void {
  useLayoutEffect(() => {
    if (!active) return
    const display = flowItemOf(markerRef.current)
    const flow = display?.parentElement
    if (display === null || flow === null || flow === undefined) return
    let hidden: HTMLElement[] = []
    const restore = () => {
      for (const item of hidden) item.hidden = false
      hidden = []
    }
    const project = () => {
      restore()
      const end = matchingFlowItem(flow, 'editCutEnd', data.transactionId)
      if (end === null) return
      const original = matchingFlowItem(flow, 'chatFlowKey', data.rootMessageId)
      // Chat can group raw rows into separate wrappers during cold replay or
      // turn folding. Document order, not sibling order, defines the cut.
      const rows = Array.from(flow.querySelectorAll<HTMLElement>('[data-chat-flow-key]'))
      const start = rows.indexOf(original ?? display)
      const finish = rows.indexOf(end)
      if (start < 0 || finish <= start) return
      for (const item of rows.slice(start, finish)) {
        if (item.contains(display) || item.contains(end) || item.hidden) continue
        item.hidden = true
        hidden.push(item)
      }
    }
    project()
    // Fold/unfold and deferred renderer mounts can replace DOM without changing
    // the Chat key order. Observe children only; our hidden writes cannot loop.
    const observer = new MutationObserver(project)
    observer.observe(flow, { childList: true, subtree: true })
    return () => { observer.disconnect(); restore() }
  }, [active, data.rootMessageId, data.transactionId, flowRevision, markerRef])
}

/** Edited bubble projected at the first version's position in this same session. */
export function EditedUserMessage({
  node, renderMessageImages, useSession, useChat, openFile, openSkill, editAndResend, t,
}: EditedUserMessageProps) {
  const data = node.data
  const latest = useChat(snapshot => isLatestRootEdit(snapshot, data))
  const skillNames = useChat(snapshot => loadedEditSkills(snapshot, data.stepLocation, data.messageSeq))
  const flowRevision = useChat(snapshot => {
    const order = snapshot.order
    return `${order.length}:${order[0] ?? ''}:${order.at(-1) ?? ''}`
  })
  const markerRef = useRef<HTMLDivElement>(null)
  useDiscardedRange(markerRef, data, latest, flowRevision)
  if (!latest) return null
  return (
    <div ref={markerRef} data-edit-cut-start={data.transactionId}>
      <EditableUserBubble
        data={{
          seq: data.messageSeq,
          time: data.time,
          content: data.content,
          source: data.source,
          skillNames,
        }}
        renderMessageImages={renderMessageImages}
        useSession={useSession}
        useChat={useChat}
        openFile={openFile}
        openSkill={openSkill}
        editAndResend={editAndResend}
        t={t}
      />
    </div>
  )
}

/** DOM landmark delimiting the raw rows hidden by one replacement. */
export function EditCutEnd({ node }: EditCutEndProps) {
  return <span data-edit-cut-end={node.data.transactionId} hidden aria-hidden />
}

// Retain the key union in the generated declaration for locale consumers.
export type { EditLastMessageLocaleKey }
