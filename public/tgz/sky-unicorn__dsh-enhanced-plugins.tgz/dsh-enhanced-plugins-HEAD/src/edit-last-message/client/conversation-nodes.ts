import type {
  ChatConversationViewNode, ChatNodeDataMap, ChatSnapshot, UserMessageNode,
} from '@deepseek-ai/dsh-client-ui-chat/client'
import type { ContextMessageNode, ConversationLocation, ConversationNodeDefinition } from '@deepseek-ai/dsh-client-ui-conversation/client'
import { editLastMessageSource } from '../shared.ts'

/** Payload rendered at the original user-message position after a semantic rewind. */
export interface EditedUserChatData {
  readonly transactionId: string
  readonly rootSeq: number
  readonly rootMessageId: string
  readonly messageSeq: number
  readonly time: number
  readonly content: UserMessageNode['content']
  readonly source: UserMessageNode['source']
  /** Actual replay step, retained while the bubble itself stays outside folded process groups. */
  readonly stepLocation: ConversationLocation
}

/** Invisible durable boundary delimiting the discarded raw transcript range. */
export interface EditCutEndChatData {
  readonly transactionId: string
  readonly rootMessageId: string
  readonly messageSeq: number
}

declare module '@deepseek-ai/dsh-client-ui-chat/client' {
  interface ChatNodeDataMap {
    /** Latest edited text projected back onto the original user-bubble position. */
    'edited-user': EditedUserChatData
    /** Invisible end of the raw rows shadowed by one edit transaction. */
    'edit-cut-end': EditCutEndChatData
  }
}

interface EditEventState {
  readonly transactionId: string
  readonly rootSeq: number
  readonly rootMessageId: string
  readonly messageSeq: number
  readonly time: number
  readonly content: UserMessageNode['content']
  readonly source: UserMessageNode['source']
  readonly location: ChatConversationViewNode['location']
}

interface RootIdentity { readonly rootSeq: number; readonly rootMessageId: string }

/** Track the latest human root in current coordinates, including after V2-to-V3 migration. */
export const editRootDefinition: ConversationNodeDefinition<RootIdentity> = {
  kind: 'edit-last-message-root',
  match: event => event.type === 'user/message'
    && (event.data.source.kind === 'user' || editLastMessageSource(event.data.source) !== undefined)
    ? { id: String(event.data.id), role: 'start' } : null,
  start: (_context, match, reader) => {
    const event = match.event
    if (event.type !== 'user/message') throw new Error('edit root requires a user message')
    const marker = editLastMessageSource(event.data.source)
    const previous = reader.previous<RootIdentity>('edit-last-message-root')?.state
    if (marker !== undefined && previous?.rootMessageId === marker.rootMessageId) return previous
    return {
      rootMessageId: marker?.rootMessageId ?? String(event.data.id),
      rootSeq: marker === undefined ? event.seq
        : event.surfaceOp !== undefined && event.surfaceOp !== 'append' ? event.surfaceOp.startSeq : event.seq,
    }
  },
  update: context => context.state,
}

function editEvent(event: Parameters<ConversationNodeDefinition['match']>[0]): EditEventState | undefined {
  if (event.type !== 'user/message' || event.surfaceOp === undefined || event.surfaceOp === 'append') return
  const source = editLastMessageSource(event.data.source)
  if (source === undefined) return
  return {
    transactionId: String(event.data.id),
    rootSeq: event.surfaceOp.startSeq,
    rootMessageId: source.rootMessageId,
    messageSeq: event.seq,
    time: event.time,
    content: event.data.content,
    source: event.data.source,
    location: { kind: 'unresolved' },
  }
}

function stateFromMatch(
  match: Parameters<ConversationNodeDefinition<EditEventState>['start']>[1],
  reader: Parameters<ConversationNodeDefinition<EditEventState>['start']>[2],
): EditEventState {
  const state = editEvent(match.event)
  if (state === undefined) throw new Error('edit-last-message node requires a replacement user event')
  const root = reader.previous<RootIdentity>('edit-last-message-root')?.state
  return { ...state, rootSeq: root?.rootMessageId === state.rootMessageId ? root.rootSeq : state.rootSeq, location: match.location }
}

function chatNode<Kind extends keyof ChatNodeDataMap & string>(
  context: Parameters<NonNullable<ConversationNodeDefinition<EditEventState>['buildViewNode']>>[0],
  kind: Kind,
  anchorSeq: number,
  data: ChatNodeDataMap[Kind],
): ChatConversationViewNode & { readonly kind: Kind; readonly data: ChatNodeDataMap[Kind] } {
  return {
    key: context.key,
    kind,
    id: context.id,
    target: 'chat',
    anchorSeq,
    // A replacement is displayed at the original user-bubble coordinate. Its
    // actual step is kept in data, while an unresolved view location prevents
    // DSH's process grouping from folding this user-facing row on cold replay.
    location: { kind: 'unresolved' },
    visibility: 'visible',
    data,
  }
}

/** One independent display Context per replacement event; the renderer selects the latest per root. */
export const editedUserDefinition: ConversationNodeDefinition<EditEventState> = {
  kind: 'edit-last-message-display',
  target: 'chat',
  match: (event) => {
    const state = editEvent(event)
    return state === undefined ? null : { id: state.transactionId, role: 'start' }
  },
  start: (_context, match, reader) => stateFromMatch(match, reader),
  update: context => context.state,
  buildViewNode: (context) => {
    const state = context.state
    if (state === undefined) return null
    return chatNode(context, 'edited-user', state.rootSeq, {
      transactionId: state.transactionId,
      rootSeq: state.rootSeq,
      rootMessageId: state.rootMessageId,
      messageSeq: state.messageSeq,
      time: state.time,
      content: state.content,
      source: state.source,
      stepLocation: state.location,
    })
  },
}

/** End marker for exact DOM-range projection of the append-only raw transcript. */
export const editCutEndDefinition: ConversationNodeDefinition<EditEventState> = {
  kind: 'edit-last-message-end',
  target: 'chat',
  match: (event) => {
    const state = editEvent(event)
    return state === undefined ? null : { id: state.transactionId, role: 'start' }
  },
  start: (_context, match, reader) => stateFromMatch(match, reader),
  update: context => context.state,
  buildViewNode: (context) => {
    const state = context.state
    if (state === undefined) return null
    return chatNode(context, 'edit-cut-end', state.messageSeq, {
      transactionId: state.transactionId,
      rootMessageId: state.rootMessageId,
      messageSeq: state.messageSeq,
    })
  },
}

function legacyHumanSeq(nodes: ChatSnapshot['legacy']['nodes']): number | undefined {
  for (let index = nodes.length - 1; index >= 0; index -= 1) {
    const node = nodes[index]
    if (node?.kind === 'user' || node?.kind === 'steering') return node.seq
  }
  return undefined
}

/** Latest editable durable user input across built-in and replacement projections. */
export function latestEditableMessageSeq(
  snapshot: Pick<ChatSnapshot, 'legacy' | 'nodes'>,
): number | undefined {
  let latest = legacyHumanSeq(snapshot.legacy.nodes)
  for (const raw of snapshot.nodes.values()) {
    if (raw.kind !== 'edited-user') continue
    const data = raw.data as EditedUserChatData
    if (latest === undefined || data.messageSeq > latest) latest = data.messageSeq
  }
  return latest
}

/** Whether this transaction is the newest replacement for its original bubble. */
export function isLatestRootEdit(snapshot: Pick<ChatSnapshot, 'nodes'>, data: EditedUserChatData): boolean {
  for (const raw of snapshot.nodes.values()) {
    if (raw.kind !== 'edited-user') continue
    const candidate = raw.data as EditedUserChatData
    if (candidate.rootMessageId === data.rootMessageId && candidate.messageSeq > data.messageSeq) return false
  }
  return true
}

/**
 * Read Skill invocation evidence following this edit in its own step.
 * @param snapshot - current public Chat projection, including loaded context nodes.
 * @param location - the edited message's new step, not its visual position at the original bubble.
 * @param messageSeq - sequence of the admitted replacement message.
 * @returns distinct loaded names; discarded turns and other steps cannot contribute.
 */
export function loadedEditSkills(
  snapshot: Pick<ChatSnapshot, 'nodes'>,
  location: ConversationLocation,
  messageSeq: number,
): readonly string[] {
  if (location.kind !== 'step') return []
  const names = new Set<string>()
  for (const node of snapshot.nodes.values()) {
    if (node.kind !== 'context' || node.anchorSeq <= messageSeq || node.location.kind !== 'step'
      || node.location.turn.turn !== location.turn.turn || node.location.step.step !== location.step.step) continue
    const { source } = node.data as ContextMessageNode
    if (source !== null && typeof source === 'object' && 'kind' in source
      && source.kind === 'skill-invocation' && 'name' in source && typeof source.name === 'string') names.add(source.name)
  }
  return [...names].sort()
}
