/** Check against the chosen built DSH checkout; never silently validate against stale Session declarations. */
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { resolve } from 'node:path'
import { spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('..', import.meta.url))
const dsh = resolve(process.env.DSH_VERIFY_CHECKOUT ?? resolve(root, '../deepseek-harness'))
const formatVersion = path => readFileSync(path, 'utf8').match(/SESSION_FORMAT_VERSION\s*=\s*(\d+)/)?.[1]
const source = formatVersion(resolve(dsh, 'packages/core/session/src/types.ts'))
const built = formatVersion(resolve(dsh, 'packages/core/session/lib/types/types.d.ts'))
if (source !== '4' || source !== built) throw new Error(`DSH Session declarations are stale or incompatible (source=${source}, built=${built}); build the DSH 0.1.7-alpha.1 target checkout or set DSH_VERIFY_CHECKOUT to a freshly built copy.`)
const chatOwner = readFileSync(resolve(dsh, 'packages/client/ui-chat/lib/types/client/contract/slots.d.ts'), 'utf8')
if (!chatOwner.includes('openSkill:')) throw new Error('DSH Chat declarations predate sent-reference previews; build the target checkout or set DSH_VERIFY_CHECKOUT to a freshly built copy.')
const requiredContracts = [
  ['packages/client/ui-plugin-manager/lib/types/client/slot-contract.d.ts', "'plugins.row.config'"],
  ['packages/api/session-controller/lib/types/client/contract/sessions.d.ts', 'retain(target:'],
  ['packages/client/ui-workspace/lib/types/client/navigation.d.ts', 'openSession(target:'],
]
for (const [relative, signature] of requiredContracts) {
  const path = resolve(dsh, relative)
  if (!existsSync(path) || !readFileSync(path, 'utf8').includes(signature)) {
    throw new Error(`DSH declarations predate the 0.1.7-alpha.1 plugin/session APIs: ${relative}; build the target checkout or set DSH_VERIFY_CHECKOUT to a freshly built copy.`)
  }
}
const scratch = mkdtempSync(resolve(tmpdir(), 'dsh-enhanced-typecheck-'))
try {
  for (const name of ['tsconfig.json', 'tsconfig.client.json']) {
    const config = JSON.parse(readFileSync(resolve(root, name), 'utf8'))
    const paths = Object.fromEntries(Object.entries(config.compilerOptions.paths).map(([key, values]) => [
      key, values.map(value => resolve(dsh, value.replace('../deepseek-harness/', ''))),
    ]))
    const path = resolve(scratch, name)
    writeFileSync(path, JSON.stringify({ extends: resolve(root, name), compilerOptions: { paths } }))
    const result = spawnSync(process.execPath, [resolve(root, 'node_modules/typescript/bin/tsc'), '--project', path, '--noEmit'], { cwd: root, stdio: 'inherit', windowsHide: true })
    if (result.error) throw result.error
    if (result.status !== 0) { process.exitCode = result.status ?? 1; break }
  }
} finally { rmSync(scratch, { recursive: true, force: true }) }
