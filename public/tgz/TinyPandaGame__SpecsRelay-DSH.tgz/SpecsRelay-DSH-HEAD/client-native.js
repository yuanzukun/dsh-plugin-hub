(function registerSpecsRelayDeepSeekClient() {
  const PLUGIN_ID = "@specsrelay/dsh-deepseek";
  globalThis.__ModuleLoader__.load({
    id: PLUGIN_ID,
    factory: (require) => {
      const React = require("react");
      const {
        createElement: h,
        useEffect,
        useMemo,
        useRef,
        useState,
        useSyncExternalStore
      } = React;
      const primitives = require("@deepseek-ai/dsh-client-ui-primitives");
      const {
        Button,
        Pill,
        StateDot,
        Toast,
        IconArchiveOutline20 = primitives.IconArchiveOutlineRegular,
        IconChevronLeftOutline14 = primitives.IconChevronLeftOutlineRegular,
        IconCloseOutline16 = primitives.IconCloseOutlineRegular,
        IconEditOutline16 = primitives.IconEditOutlineRegular,
        IconEnhanceOutline16 = primitives.IconEnhanceOutlineRegular,
        IconRefreshOutline16 = primitives.IconRefreshOutlineRegular,
        IconSendOutline14 = primitives.IconSendOutlineRegular,
        IconTrashOutline16 = primitives.IconTrashOutlineRegular,
        IconWarningOutline16 = primitives.IconWarningOutlineRegular
      } = primitives;

      const API = "/specsrelay/v1";
      const officialBridge = window.dshDesktop?.protocolVersion === 1
        && typeof window.dshDesktop.browser?.acquire === "function"
        && typeof window.dshDesktop.browser?.release === "function"
        && typeof window.dshDesktop.browser?.onOpenRequested === "function"
        ? window.dshDesktop.browser : null;
      async function browserRequest(route, value) {
        const response = await fetch(`${API}${route}`, value === undefined
          ? { cache: "no-store" }
          : { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(value) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
        return data;
      }
      const MAX_EXECUTION_SNAPSHOTS = 12;
      const MAX_REQUIREMENT_SOURCE_CHARS = 500000;
      const MAX_WORKSPACE_HISTORY = 3;
      const STATUS_MESSAGE_DURATION_MS = 4000;
      // DSH Desktop enhanced mode reserves a 32px native caption row on macOS and Windows.
      const DSH_ENHANCED_TITLEBAR_HEIGHT = 32;
      const WORKSPACE_STORAGE_PREFIX = "specsrelay.dsh.workspace.v1:";
      const SPECSRELAY_ICON = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAGGElEQVR42s2Xf2xVZxnHP897zj33Z7m3hd16W1rGjyEwhamkWn6YkVE7/L3gsikzJm5CdOBiFJeYxcSYkcBMHX+YBRKjhh9h0zm00VHNmBAGcRmbpTBG+TXWUtpbaGlv7217zz3v6x/3UqDrLbSSuDe5ObnJe87zfb7v83yf7wv/5yV3aM94y0wWmH0HE7WLJXLL7KLRGTGiZnIs9Inp67twdVQ8Mx6Akf9l8cqnsOXbglQZgwV5EAIYbTBaX99txkzNgHggFzFmV293RwOgR4OQUcEFkFg88aJl2auzAxm8rAtyfZsxBtvv4Av6McaMldTNOEQQUWgv19jbfWk14BVeMKMB2EAuVp74oaXsre7QcLZ62SK7bM50yQ1lEaXAGCy/j853WulqOYPtOJhCcOPp8YrQVcryay/3dG/3pS3XYo3JQNnHKptzQ+6C0lkVZk3TVssJBTAYjM5nawccuo+f5XfL16HdHKaQpX9KOM+UGZMNLSIYo8/2Ji8tKLAAYKwbiyM6Y0ZUefqZ3FA2NHVutdx9/6el8fFn8UcjHPzlb7EdH68/s40Fj6xk1gOLufeROuavXoETDpI8dgaQPFNjL2UQxy4Jb88ODKSvJX9zqxkjgAiCznmEy8uo3fgYsZkJpkyPE46XEptViWVb9J67SG7IJRCLsHLLeqqX38ffn3wOy3LGFwVzc0d9qNeNNlgBh95zF2k71MycLy6h53Qbls8mc/kqgWiEYzub+MdPtuIE/OSGshzdvpc1+57n/Gtv0bK7iWBpCbp4TTAuAIxB+WwyyV7e2LwDlLBvQwPZVBpl2xijcQeHiVbEGUinsUIOHUeO09p4iDmrajm249UJSd+YB2Y8DycSpK+ti8YnNjF4pQ9E8HI5tKcJloS5cvkyy5csobamhkE9SDQxjWx6sFBQMiGJLNbAuOkhRMAOOhhtUJbCsm2SyW4eWLGCl/bsoiQYZs1T38fESzj1/B4sxy7ow//AwAgGJaAEow2iFNr16LnYRX1dHX98cTfRkgh/2vsKD3/hy+id/6Z1/5v4I6G8St4JANdkRJTCzQwSrSqn5sffpOHXv+I/7zTz0OqH+c0L2/hczWLWfv3RfOYysbFxSwAigpd1Cd9VyjdeepZ7H1rB2g1PEovF+Pi8eezZvQNRirUb1uMEAohSiJX/qcJzcjUwcgyKbCrD53/+XXKuy8tf/Sl9/X08vm4dhw8eoD/Vz8r6VbS83UwkGCKdyuRLsMCEKIUTDhadu7cEYIxG+WwSn5nHqb8cJHM1RbyqghMn3qVmyTIs2+LkiXf5xIPLiFSXo90cooTcsAuAmx6k/XBLYXrKJBiQvCqmO3soX3gP2suR7ukj5A9w+r1W3MwQM2sXsmrb0/S0foAd8JNND1K1dCHByBQAGn+wiebf/w1/LALamygDYDk2R7fv5dG/Pkd9w49o2bkPRCizbbKpAeKfmksm2cupxkP4gn5ECZdPnscdHKZ62X2Uzq5Ee94kj0BrnEiI9iMtND6xift/8T0++a16tOfl2fE8gmVR9v/sBVp2NRGdHkf5LBKL53Pyz6/z/v6jzKqrKdodt+X78iCCvPfKAc6/9haxmQmUZYEI2VSa2Q/WgsDSjY+RPH6WkoppXDndRt3m9bz/r7fxsi5yWwBETDF7Y7TBHw2jcx7dJ86N6MNgXz/T5t/NlMo4hzb/gdl1n6W/PUnbG8fob0viCwcoX3TPiDhJPsaHABhA+i5cSMXiFZ1KJGbyemrdPCM0ohS+UKDwMQUCqfZuFn3nS4itcMIhbL+PqXOrGU6lqVq6iHP/fNMoyzIgXQOdnb03GiFrFBgvGC4JKmXVG2PcokJV4MkYg2XbpDq66Wn9AF8oSCbZw0BXL0P9aTw3R/vhFnP21SOuEwr6tPYahtKpA4VYupgptUrvSrysLPsrxujbGiyiBDczTN47yghIg8GyLfwlETztNV2dEvoaZ864xUzpjb7dKi1PbBQjawxMN6OOohiIvO+7/lWV934dxtO7e5IdWwB3PFs+1uVBIonE1LDWamCCd5IIkBYxA52dV67RfUsP/1G8mskdAmD4qK7/Aogcgw2IpLcjAAAAAElFTkSuQmCC";
      const listeners = new Set();
      let snapshot = Object.freeze({ items: [], loading: false, error: "" });

      function publish(patch) {
        snapshot = Object.freeze({ ...snapshot, ...patch });
        for (const listener of listeners) listener();
      }

      const inbox = {
        subscribe(listener) {
          listeners.add(listener);
          return () => listeners.delete(listener);
        },
        getSnapshot() {
          return snapshot;
        },
        async refresh() {
          publish({ loading: true, error: "" });
          try {
            const response = await fetch(`${API}/handoffs`, {
              cache: "no-store"
            });
            const data = await response.json();
            if (!response.ok) {
              throw new Error(data.error || `HTTP ${response.status}`);
            }
            const items = Array.isArray(data.items) ? data.items : [];
            publish({ items, loading: false, error: "" });
            return items;
          } catch (error) {
            publish({
              loading: false,
              error: error instanceof Error ? error.message : String(error)
            });
            return [];
          }
        },
        async latest() {
          const response = await fetch(`${API}/handoffs/latest`, {
            cache: "no-store"
          });
          const data = await response.json();
          if (!response.ok) {
            throw new Error(data.error || `HTTP ${response.status}`);
          }
          return data.item || null;
        },
        async receipt(item, sessionId) {
          const response = await fetch(`${API}/receipts`, {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ handoffId: item.handoffId, sessionId })
          });
          const data = await response.json();
          if (!response.ok) {
            throw new Error(data.error || `HTTP ${response.status}`);
          }
          publish({
            items: snapshot.items.map((candidate) =>
              candidate.handoffId === item.handoffId
                ? {
                    ...candidate,
                    state: "loaded",
                    loadedAt: data.loadedAt || new Date().toISOString(),
                    sessionId
                  }
                : candidate
            )
          });
          return data;
        }
      };

      async function readWorkspaceState(key) {
        const response = await fetch(
          `${API}/workspace-state?key=${encodeURIComponent(key)}`,
          { cache: "no-store" }
        );
        const data = await response.json();
        if (!response.ok) {
          throw new Error(data.error || `HTTP ${response.status}`);
        }
        return data.item?.state ?? null;
      }

      async function writeWorkspaceState(key, state) {
        const response = await fetch(`${API}/workspace-state`, {
          method: "PUT",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ key, state })
        });
        const data = await response.json();
        if (!response.ok) {
          throw new Error(data.error || `HTTP ${response.status}`);
        }
        return data;
      }

      function useInbox() {
        return useSyncExternalStore(
          inbox.subscribe,
          inbox.getSnapshot,
          inbox.getSnapshot
        );
      }

      function listLines(values) {
        return Array.isArray(values) && values.length
          ? values.map((value) => `- ${value}`).join("\n")
          : "- 无";
      }

      function formatHandoffPrompt(handoff) {
        return `请根据以下由 SpecsRelay 从 DeepSeek 当前对话整理出的需求继续工作。先核对本地项目事实，再执行；不要假设对话中未确认的路径或实现。

标题：${handoff.title}

目标：
${handoff.objective}

背景：
${handoff.context}

已确认决策：
${listLines(handoff.decisions)}

实施建议：
${listLines(handoff.implementation_plan)}

验收标准：
${listLines(handoff.acceptance_criteria)}

约束：
${listLines(handoff.constraints)}

非目标：
${listLines(handoff.non_goals)}

需要本地核查：
${listLines(handoff.local_context_needed)}

未解决问题：
${listLines(handoff.open_questions)}`;
      }

      function normalizedPath(value) {
        const text = String(value || "")
          .trim()
          .replaceAll("\\", "/")
          .replace(/\/+$/, "");
        return /^[A-Za-z]:\//.test(text) ? text.toLowerCase() : text;
      }

      function relativeTime(value) {
        const time = Date.parse(value);
        return Number.isFinite(time) ? new Date(time).toLocaleString() : "";
      }

      function normalizeImportedText(value) {
        const text = String(value || "").trim();
        if (!text) throw new Error("没有读取到对话内容，请打开有内容的 DeepSeek 对话后重试。");
        if (text.length > MAX_REQUIREMENT_SOURCE_CHARS) {
          throw new Error(
            `DeepSeek 对话不能超过 ${MAX_REQUIREMENT_SOURCE_CHARS.toLocaleString()} 个字符。`
          );
        }
        return text;
      }

      function stableHash(value) {
        let hash = 0x811c9dc5;
        const source = String(value ?? "");
        for (let index = 0; index < source.length; index += 1) {
          hash ^= source.charCodeAt(index);
          hash = Math.imul(hash, 0x01000193);
        }
        return (hash >>> 0).toString(16).padStart(8, "0");
      }

      function normalizeSources(value) {
        if (!Array.isArray(value)) return [];
        const seen = new Set();
        const normalized = [];
        for (const item of value) {
          const transcript = String(item?.transcript || "").trim();
          if (!transcript || transcript.length > MAX_REQUIREMENT_SOURCE_CHARS) continue;
          const kind = item?.kind === "chatbot" ? "chatbot" : "paste";
          const identity = `${kind}:${stableHash(transcript)}`;
          if (seen.has(identity)) continue;
          seen.add(identity);
          normalized.push({
            id: String(item?.id || `source_${stableHash(identity)}`).slice(0, 120),
            identity,
            kind,
            provider: String(item?.provider || "DeepSeek").slice(0, 120),
            title: String(item?.title || "DeepSeek 对话").slice(0, 500),
            transcript,
            message_count: Number.isInteger(item?.message_count)
              ? Math.max(0, item.message_count)
              : 0,
            primary: Boolean(item?.primary),
            created_at: item?.created_at || new Date().toISOString(),
            updated_at: item?.updated_at || new Date().toISOString()
          });
          break;
        }
        return normalized.map((source) => ({
          ...source,
          primary: true
        }));
      }

      function addCapturedRequirementSource(capture) {
        const transcript = normalizeImportedText(capture?.transcript);
        const identity = `capture:${stableHash(transcript)}`;
        const now = new Date().toISOString();
        return normalizeSources([
          {
            id: `source_${stableHash(`${identity}:${capture?.captureId || now}`)}`,
            identity,
            kind: "chatbot",
            provider: "DeepSeek",
            title: String(capture?.title || "当前 DeepSeek 网页对话").slice(0, 500),
            transcript,
            message_count: Number.isInteger(capture?.messageCount)
              ? capture.messageCount
              : 0,
            primary: true,
            created_at: capture?.capturedAt || now,
            updated_at: now
          }
        ]);
      }

      function sourcesFingerprint(sources) {
        const normalized = normalizeSources(sources);
        return normalized.length
          ? `sources:${stableHash(
              JSON.stringify(
                normalized.map((source) => ({
                  id: source.id,
                  primary: source.primary,
                  hash: stableHash(source.transcript)
                }))
              )
            )}`
          : "";
      }

      function formatSourcesTranscript(sources) {
        return normalizeSources(sources)[0]?.transcript ?? "";
      }

      function normalizeWorkspace(value) {
        const source = value && typeof value === "object" ? value : {};
        return {
          sources: normalizeSources(source.sources),
          integratedFingerprint:
            typeof source.integratedFingerprint === "string"
              ? source.integratedFingerprint
              : "",
          handoff:
            source.handoff && typeof source.handoff === "object"
              ? source.handoff
              : null,
          answers: Array.isArray(source.answers)
            ? source.answers.map((answer) => String(answer || ""))
            : [],
          history: Array.isArray(source.history)
            ? source.history.slice(0, MAX_WORKSPACE_HISTORY)
            : [],
          executionHistory: normalizeExecutionHistory(source.executionHistory),
          organizerRoute:
            source.organizerRoute && typeof source.organizerRoute === "object"
              ? {
                  provider: String(source.organizerRoute.provider || ""),
                  model: String(source.organizerRoute.model || "")
                }
              : { provider: "", model: "" }
        };
      }

      function workspaceSnapshot(sources, integratedFingerprint, handoff, answers) {
        return {
          savedAt: new Date().toISOString(),
          sources: normalizeSources(sources),
          integratedFingerprint,
          handoff,
          answers
        };
      }

      function snapshotHasContent(snapshot) {
        return Boolean(snapshot.sources.length || snapshot.handoff);
      }

      function normalizeExecutionHistory(value) {
        if (!Array.isArray(value)) return [];
        return value
          .filter(
            (item) =>
              item &&
              typeof item === "object" &&
              item.handoff &&
              typeof item.handoff === "object" &&
              typeof item.prompt === "string" &&
              item.prompt.trim()
          )
          .slice(0, MAX_EXECUTION_SNAPSHOTS)
          .map((item) => ({
            id: String(item.id || crypto.randomUUID()).slice(0, 160),
            createdAt: String(item.createdAt || new Date().toISOString()),
            handoff: item.handoff,
            projectPath: String(item.projectPath || ""),
            prompt: item.prompt,
            sources: normalizeSources(item.sources),
            status:
              item.status === "submitted"
                ? "submitted"
                : item.status === "loaded"
                  ? "loaded"
                  : "snapshot",
            fingerprint: String(item.fingerprint || "")
          }));
      }

      function createExecutionSnapshot(handoff, projectPath, prompt, sources) {
        return {
          id: crypto.randomUUID(),
          createdAt: new Date().toISOString(),
          handoff,
          projectPath,
          prompt,
          sources: normalizeSources(sources),
          status: "submitted",
          fingerprint: stableHash(`${projectPath}\n${prompt}`)
        };
      }

      const textAreaStyle = {
        background: "var(--dsw-alias-bg-layer-1)",
        border: "1px solid var(--dsw-alias-border-l2)",
        borderRadius: 8,
        color: "var(--dsw-alias-label-primary)",
        font: "inherit",
        outline: "none",
        padding: 10,
        resize: "vertical",
        width: "100%"
      };

      function selectedSessionId(sessions) {
        return sessions.current || Object.values(sessions.byId).find(
          (session) => (session.retainedBy?.mainView || 0) > 0
        )?.id || "";
      }

      function navigateSession(ctx, sessionId) {
        if (officialBridge) ctx.get("uiWorkspace").openSession(sessionId);
        else ctx.sessions.open(sessionId);
      }

      async function withSession(ctx, sessionId, operation) {
        if (!officialBridge) return operation();
        const reference = ctx.sessions.retain(sessionId, { source: "controllerOperation" });
        try {
          await reference.ready;
          return await operation();
        } finally {
          reference.release();
        }
      }

      function loadIntoSession(ctx, sessionId, item) {
        const list = ctx.sessions.list.getSnapshot();
        const summary = list.byId[sessionId];
        const actual = normalizedPath(summary?.cwd);
        const expected = normalizedPath(item.projectPath);
        if (!actual || actual !== expected) {
          return {
            ok: false,
            message: `请先在 DSH 选择项目：${item.projectPath}`
          };
        }
        const scope = ctx.sessions.scope(sessionId);
        if (!scope) {
          return { ok: false, message: "当前 DSH 会话尚未准备好。" };
        }
        const input = ctx.conversation.input.for(scope);
        input.setDraft(item.prompt);
        if (item.submit === true) input.submit();
        return { ok: true, sessionId, submitted: item.submit === true };
      }

      function loadClarificationDraft(ctx, sessionId, projectPath, prompt) {
        const sessions = ctx.sessions.list.getSnapshot();
        if (selectedSessionId(sessions) !== sessionId) {
          return { ok: false, message: "请先切回发起澄清的 DSH 会话。" };
        }
        if (normalizedPath(sessions.byId[sessionId]?.cwd) !== normalizedPath(projectPath)) {
          return { ok: false, message: "当前项目已变化，请切回原项目。" };
        }
        const pendingQuestion = ctx.get?.("uiSession")?.sessionStatus
          ?.getSnapshot?.().get(sessionId)?.pendingInteraction;
        if (pendingQuestion) {
          return {
            ok: false,
            pendingQuestion: true,
            message: "当前 DSH 正等待问题卡片的回答。请把你确认的决定填入该卡片；不要发送整段 DeepSeek 讨论。"
          };
        }
        const scope = ctx.sessions.scope(sessionId);
        if (!scope) return { ok: false, message: "当前 DSH 会话尚未准备好。" };
        const input = ctx.conversation.input.for(scope);
        const state = input.state?.getSnapshot?.();
        if (!state || typeof state.draft !== "string" ||
            !Array.isArray(state.attachmentIds) || typeof state.phase !== "string") {
          return { ok: false, message: "此桌面客户端暂不支持安全写入澄清草稿。请复制下方内容，并在原 DSH 会话中手动粘贴。" };
        }
        if (state.draft.trim() || state.attachmentIds.length || state.phase !== "plain") {
          return { ok: false, message: "当前输入框已有内容，请先处理原草稿，再放入澄清结果。" };
        }
        input.setDraft(prompt);
        input.focus?.();
        return { ok: true };
      }

      function pendingQuestionText(ctx, sessionId) {
        const pending = ctx.get?.("uiSession")?.sessionStatus
          ?.getSnapshot?.().get(sessionId)?.pendingInteraction;
        if (pending?.kind !== "question" || !Array.isArray(pending.questions)) return "";
        const questions = pending.questions.map((item) => {
          if (typeof item?.question !== "string") return "";
          const options = Array.isArray(item.options)
            ? item.options.map((option) => option.label).filter((label) => typeof label === "string")
            : [];
          return [item.question, ...options.map((option) => `- ${option}`)].join("\n");
        }).filter(Boolean);
        const combined = questions.join("\n\n");
        if (combined.length <= 1800) return combined;
        const first = questions[0] || "";
        return first.length <= 1800 ? first : "";
      }

      async function prepareProjectTarget(ctx, projectPath) {
        const expected = normalizedPath(projectPath);
        if (!expected) {
          return { ok: false, message: "请先选择项目目录。" };
        }
        const sessions = ctx.sessions.list.getSnapshot();
        const currentSessionId = selectedSessionId(sessions);
        const currentSession = currentSessionId
          ? sessions.byId[currentSessionId]
          : undefined;
        if (
          currentSessionId &&
          normalizedPath(currentSession?.cwd) === expected
        ) {
          return {
            ok: true,
            projectPath: currentSession.cwd,
            sessionId: currentSessionId
          };
        }
        let workspace = ctx.workspaces.list
          .getSnapshot()
          .items.find((candidate) => normalizedPath(candidate.path) === expected);
        if (!workspace) {
          workspace = await ctx.workspaces.create({ path: projectPath });
        }
        const navigation = officialBridge ? ctx.get("uiWorkspace") : ctx.workspaces;
        const sessionId = await navigation.connectWorkspace(
          workspace.workspaceId
        );
        return { ok: true, projectPath: workspace.path, sessionId };
      }

      async function loadIntoProject(ctx, item) {
        const expected = normalizedPath(item.projectPath);
        const preparedSessionId = String(item.preparedSessionId || "");
        const sessions = ctx.sessions.list.getSnapshot();
        const prepared =
          preparedSessionId &&
          normalizedPath(item.preparedProjectPath) === expected &&
          sessions.byId[preparedSessionId]
            ? {
                ok: true,
                projectPath: item.preparedProjectPath,
                sessionId: preparedSessionId
              }
            : await prepareProjectTarget(ctx, item.projectPath);
        if (!prepared.ok) return prepared;
        const submitStartedAt = performance.now();
        const result = await withSession(ctx, prepared.sessionId, async () => {
          if (officialBridge && item.submit === true) {
            const summary = ctx.sessions.list.getSnapshot().byId[prepared.sessionId];
            if (normalizedPath(summary?.cwd) !== expected) {
              return { ok: false, message: "目标会话的项目已变化，请重新选择项目。" };
            }
            const binding = ctx.sessions.binding(prepared.sessionId);
            const accepted = await binding.session.prompt([{ type: "text", text: item.prompt }], "queue");
            if (!accepted.ok) return { ok: false, message: "DSH 未接收需求，请检查会话状态后重试。" };
            navigateSession(ctx, prepared.sessionId);
            return { ok: true, sessionId: prepared.sessionId, submitted: true };
          }
          if (officialBridge) navigateSession(ctx, prepared.sessionId);
          return loadIntoSession(ctx, prepared.sessionId, {
            ...item,
            projectPath: prepared.projectPath
          });
        });
        return result.ok
          ? {
              ...result,
              projectPath: prepared.projectPath,
              submitLatencyMs: performance.now() - submitStartedAt
            }
          : result;
      }

      const stepCardStyle = {
        background: "var(--dsw-alias-bg-layer-1)",
        border: "1px solid var(--dsw-alias-border-subtle)",
        borderRadius: 14,
        display: "grid",
        gap: 14,
        padding: 14
      };

      function WorkflowStep({ children, description, number, title }) {
        return h(
          "section",
          { style: stepCardStyle },
          h(
            "header",
            { style: { alignItems: "flex-start", display: "flex", gap: 10 } },
            h(
              "span",
              {
                style: {
                  alignItems: "center",
                  background: "color-mix(in srgb, var(--dsw-alias-brand-primary, #35d39a) 14%, transparent)",
                  border: "1px solid var(--dsw-alias-brand-primary, #35d39a)",
                  borderRadius: 7,
                  color: "var(--dsw-alias-brand-primary, #35d39a)",
                  display: "inline-flex",
                  flex: "0 0 24px",
                  fontSize: 12,
                  fontWeight: 700,
                  height: 24,
                  justifyContent: "center"
                }
              },
              String(number)
            ),
            h(
              "div",
              { style: { display: "grid", gap: 3, minWidth: 0 } },
              h("h2", { style: { fontSize: 16, margin: 0 } }, title),
              description &&
                h(
                  "p",
                  {
                    style: {
                      color: "var(--dsw-alias-text-tertiary)",
                      fontSize: 12,
                      lineHeight: 1.5,
                      margin: 0
                    }
                  },
                  description
                )
            )
          ),
          children
        );
      }

      function HandoffSummaryPanel({
        answers,
        browserReady,
        busy,
        handoff,
        onAnswer,
        onClarify,
        onRecapture
      }) {
        const [copyStatus, setCopyStatus] = useState("");
        useEffect(() => setCopyStatus(""), [handoff]);
        const questions = Array.isArray(handoff.open_questions)
          ? handoff.open_questions
          : [];
        const copyQuestions = async () => {
          if (busy || questions.length === 0) return;
          const prompt = [
            "请基于我们前面的完整对话，继续帮我澄清以下问题。请逐条与我确认，不要替我假设答案：",
            "",
            ...questions.map((question, index) => `${index + 1}. ${question}`)
          ].join("\n");
          try {
            await navigator.clipboard.writeText(prompt);
            setCopyStatus("copied");
          } catch {
            setCopyStatus("error");
          }
        };
        return h(
          React.Fragment,
          null,
          questions.length > 0 &&
            h(
              "section",
              {
                "aria-label": "AskQuestion · 需求补充",
                style: {
                  background: "var(--dsw-alias-bg-layer-2)",
                  border: "1px solid var(--dsw-alias-brand-primary, #35d39a)",
                  borderRadius: 10,
                  display: "grid",
                  gap: 10,
                  padding: 12
                }
              },
              h("strong", null, "需要你确认"),
              h(
                "p",
                { style: { color: "var(--dsw-alias-text-secondary)", fontSize: 12, lineHeight: 1.5, margin: 0 } },
                "以下问题会影响需求范围或产品行为。你可以回到左侧 DeepSeek 继续讨论，也可以直接在这里回答。"
              ),
              h(
                "div",
                { style: { display: "grid", gap: 8 } },
                h("strong", { style: { fontSize: 12 } }, "回到 DeepSeek 讨论"),
                h("p", {
                  style: { color: "var(--dsw-alias-text-secondary)", fontSize: 12, lineHeight: 1.5, margin: 0 }
                }, "复制问题后，粘贴到左侧原对话继续讨论；确认决定后，再重新获取并整理。"),
                h(Button, {
                  disabled: Boolean(busy),
                  variant: "secondary",
                  onClick: copyQuestions
                }, copyStatus === "copied" ? "已复制问题" : "复制问题，回网页讨论"),
                h(Button, {
                  disabled: Boolean(busy) || !browserReady,
                  variant: "ghost",
                  onClick: onRecapture
                }, "重新获取并整理"),
                copyStatus && h("p", {
                  role: copyStatus === "error" ? "alert" : "status",
                  style: { fontSize: 12, lineHeight: 1.5, margin: 0 }
                }, copyStatus === "error"
                  ? "复制失败，请手动复制下面的问题，粘贴到左侧原对话继续讨论。"
                  : "已复制。请粘贴到左侧原对话；讨论确认后，点击“重新获取并整理”。")
              ),
              h("strong", { style: { fontSize: 12 } }, "直接在这里回答"),
              ...questions.map((question, index) =>
                h(
                  "label",
                  { key: question, style: { display: "grid", gap: 6 } },
                  h("span", { style: { fontSize: 12 } }, `${index + 1}. ${question}`),
                  h("textarea", {
                    rows: 3,
                    value: answers[index] || "",
                    placeholder: "输入你的决定、偏好或补充背景…",
                    style: textAreaStyle,
                    onChange: (event) => onAnswer(index, event.target.value)
                  })
                )
              ),
              h(
                "div",
                { style: { display: "grid", gap: 8 } },
                h(
                  Button,
                  {
                    disabled: Boolean(busy) || questions.some((_, index) => !answers[index]?.trim()),
                    icon: h(IconEnhanceOutline16),
                    variant: "primary",
                    onClick: onClarify
                  },
                  busy === "clarify" ? "继续整理中…" : "提交回答并继续整理"
                )
              )
            )
        );
      }

      function RequirementCheckStep({ children, handoff }) {
        const questions = Array.isArray(handoff?.open_questions)
          ? handoff.open_questions
          : [];
        if (!handoff || questions.length === 0) return null;
        const prompt = handoff ? formatHandoffPrompt(handoff) : "";
        return h(
          WorkflowStep,
          {
            number: 2,
            title: "检查并补充需求",
            description: "检查整理结果；如有待确认问题，补充完整后再进入载入步骤。"
          },
          h("textarea", {
            readOnly: true,
            rows: 12,
            value: prompt,
            placeholder: "整理当前 DeepSeek 对话后，这里会显示完整需求。",
            style: {
              ...textAreaStyle,
              color: "var(--dsw-alias-label-secondary)",
              fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
              fontSize: 11,
              lineHeight: 1.5,
              minHeight: 220
            }
          }),
          children
        );
      }

      function DeliveryStep({
        alreadyLoaded,
        busy,
        handoff,
        onLoad,
        onSelectProject,
        projectPath,
        projectPreparing,
        sourcesChanged
      }) {
        const [confirmed, setConfirmed] = useState(false);
        const [loading, setLoading] = useState(false);
        const [message, setMessage] = useState("");
        const [selecting, setSelecting] = useState(false);
        const prompt = handoff ? formatHandoffPrompt(handoff) : "";
        const questions = Array.isArray(handoff?.open_questions)
          ? handoff.open_questions
          : [];
        const ready = Boolean(
          projectPath &&
            handoff?.ready_for_execution === true &&
            questions.length === 0 &&
            !sourcesChanged
        );
        useEffect(() => setConfirmed(false), [projectPath, prompt]);
        const selectProject = async () => {
          setSelecting(true);
          setMessage("");
          try {
            await onSelectProject();
          } catch (error) {
            setMessage(
              error instanceof Error ? error.message : String(error)
            );
          } finally {
            setSelecting(false);
          }
        };
        const load = async () => {
          setLoading(true);
          setMessage("");
          try {
            const result = await onLoad(prompt);
            setMessage(
              result.ok
                ? "已发送到 DSH；Agent 已开始处理。"
                : result.message
            );
            if (result.ok) setConfirmed(false);
          } catch (error) {
            setMessage(
              error instanceof Error ? error.message : String(error)
            );
          } finally {
            setLoading(false);
          }
        };
        return h(
          WorkflowStep,
          {
            number: questions.length > 0 ? 3 : 2,
            title: "发送到 DSH",
            description: ""
          },
          h(
            "div",
            {
              style: {
                alignItems: "stretch",
                display: "grid",
                gap: 8,
                gridTemplateColumns: "minmax(0, 1fr) auto"
              }
            },
            h(
              "code",
              {
                title: projectPath,
                style: {
                  alignItems: "center",
                  background: "var(--dsw-alias-bg-layer-2)",
                  border: "1px solid var(--dsw-alias-border-subtle)",
                  borderRadius: 9,
                  color: projectPath
                    ? "var(--dsw-alias-text-secondary)"
                    : "var(--dsw-alias-state-warning-primary)",
                  display: "flex",
                  fontSize: 11,
                  lineHeight: 1.5,
                  minWidth: 0,
                  overflowWrap: "anywhere",
                  padding: 10
                }
              },
              projectPath || "尚未选择项目目录"
            ),
            h(
              Button,
              {
                disabled:
                  Boolean(busy) ||
                  loading ||
                  selecting ||
                  projectPreparing ||
                  alreadyLoaded,
                size: "sm",
                variant: "outline",
                onClick: () => void selectProject()
              },
              selecting ? "选择中…" : "选择…"
            )
          ),
          alreadyLoaded &&
            h(
              "p",
              { style: { color: "var(--dsw-alias-brand-primary, #35d39a)", fontSize: 11, lineHeight: 1.45, margin: 0 } },
              "当前版本已经发送过。需要重开时请先从下方冻结快照恢复草稿；需要改需求时请基于快照继续修改。"
            ),
          h(
            "label",
            { style: { alignItems: "flex-start", display: "flex", fontSize: 12, gap: 7, lineHeight: 1.5 } },
            h("input", {
              type: "checkbox",
              checked: confirmed,
              disabled:
                !ready ||
                Boolean(busy) ||
                loading ||
                selecting ||
                projectPreparing ||
                alreadyLoaded,
              onChange: (event) => setConfirmed(event.target.checked)
            }),
            "我已核对项目目录和需求；发送后将立即启动 Agent。"
          ),
          h(
            Button,
            {
              disabled:
                !ready ||
                !confirmed ||
                Boolean(busy) ||
                loading ||
                selecting ||
                projectPreparing ||
                alreadyLoaded,
              icon: h(IconSendOutline14),
              variant: "primary",
              onClick: () => void load()
            },
            alreadyLoaded
              ? "当前版本已发送"
              : projectPreparing
                ? "正在准备 DSH…"
              : loading
                ? "正在发送…"
                : "发送到 DSH 并开始处理"
          ),
          message && h(Toast, { text: message, onDone: () => setMessage("") })
        );
      }

      function ExecutionSnapshotPanel({
        busy,
        history,
        onReload,
        onRevise
      }) {
        const [selectedId, setSelectedId] = useState(history[0]?.id || "");
        const [revisionOpen, setRevisionOpen] = useState(false);
        const [revisionInstruction, setRevisionInstruction] = useState("");
        const [message, setMessage] = useState("");
        useEffect(() => {
          if (!history.some((item) => item.id === selectedId)) {
            setSelectedId(history[0]?.id || "");
          }
        }, [history, selectedId]);
        if (history.length === 0) return null;
        const snapshot =
          history.find((item) => item.id === selectedId) || history[0];
        return h(
          "section",
          {
            "aria-label": "执行快照",
            style: {
              ...stepCardStyle,
              borderColor: "var(--dsw-alias-brand-primary, #35d39a)"
            }
          },
          h(
            "header",
            { style: { alignItems: "flex-start", display: "flex", gap: 8, justifyContent: "space-between" } },
            h(
              "div",
              null,
              h("div", { style: { color: "var(--dsw-alias-brand-primary, #35d39a)", fontSize: 11, fontWeight: 700 } }, "执行快照"),
              h("h2", { style: { fontSize: 16, lineHeight: 1.35, margin: "3px 0 0" } }, snapshot.handoff.title)
            ),
            h(
              Pill,
              { active: snapshot.status === "submitted" },
              snapshot.status === "submitted" ? "已发送" : "仅载入"
            )
          ),
          h(
            "p",
            { style: { color: "var(--dsw-alias-text-tertiary)", fontSize: 11, lineHeight: 1.45, margin: 0 } },
            snapshot.status === "submitted"
              ? "已发送到 DSH 的版本会被冻结；之后继续修改不会改变这一版。"
              : "这是旧版仅载入草稿的记录；重新载入不会启动 Agent。"
          ),
          h("strong", { style: { fontSize: 12 } }, "执行版本"),
          h(
            "select",
            {
              value: snapshot.id,
              style: { ...textAreaStyle, minHeight: 38, padding: "0 9px" },
              onChange: (event) => setSelectedId(event.target.value)
            },
            ...history.map((item) =>
              h(
                "option",
                { key: item.id, value: item.id },
                `${relativeTime(item.createdAt)} · ${item.handoff.title}`
              )
            )
          ),
          h(
            "div",
            { style: { color: "var(--dsw-alias-text-tertiary)", fontSize: 11, overflowWrap: "anywhere" } },
            `${relativeTime(snapshot.createdAt)} · DSH · ${snapshot.projectPath}`
          ),
          h(
            "section",
            {
              style: {
                background: "color-mix(in srgb, var(--dsw-alias-brand-primary, #35d39a) 8%, var(--dsw-alias-bg-layer-2))",
                border: "1px solid var(--dsw-alias-brand-primary, #35d39a)",
                borderRadius: 10,
                display: "grid",
                gap: 9,
                padding: 10
              }
            },
            h("p", { style: { color: "var(--dsw-alias-text-secondary)", fontSize: 11, lineHeight: 1.5, margin: 0 } }, "这份冻结快照可以重新载入为当前 DSH 草稿。"),
            h(
              Button,
              {
                disabled: Boolean(busy),
                icon: h(IconRefreshOutline16),
                variant: "primary",
                onClick: () => {
                  const result = onReload(snapshot);
                  setMessage(result.ok ? "已重新载入这份冻结快照。" : result.message);
                }
              },
              "重新载入此快照"
            )
          ),
          h(
            Button,
            { disabled: Boolean(busy), icon: h(IconEditOutline16), variant: "outline", onClick: () => setRevisionOpen((value) => !value) },
            "基于此版本继续修改"
          ),
          revisionOpen &&
            h(
              "section",
              { style: { display: "grid", gap: 8 } },
              h("textarea", {
                rows: 5,
                value: revisionInstruction,
                maxLength: 12000,
                placeholder: "例如：增加 iPad 横屏适配，但保留当前 DSH 范围。",
                style: textAreaStyle,
                onChange: (event) => setRevisionInstruction(event.target.value)
              }),
              h(
                Button,
                {
                  disabled: Boolean(busy) || !revisionInstruction.trim(),
                  icon: h(IconEnhanceOutline16),
                  variant: "primary",
                  onClick: () => {
                    onRevise(snapshot, revisionInstruction);
                    setRevisionOpen(false);
                    setRevisionInstruction("");
                  }
                },
                busy === "revision" ? "正在生成新版本…" : "生成新的需求版本"
              )
            ),
          message && h(Toast, { text: message, onDone: () => setMessage("") })
        );
      }

      function InboxCard({ item, loadDraft }) {
        const [message, setMessage] = useState("");
        const load = async () => {
          const result = loadDraft(item);
          if (!result.ok) {
            setMessage(result.message);
            return;
          }
          try {
            await inbox.receipt(item, result.sessionId);
            setMessage("已载入当前会话草稿，请检查后发送。");
          } catch (error) {
            setMessage(
              `草稿已载入，但回执失败：${
                error instanceof Error ? error.message : String(error)
              }`
            );
          }
        };
        return h(
          "article",
          {
            style: {
              background: "var(--dsw-alias-bg-layer-2)",
              borderRadius: 10,
              display: "grid",
              gap: 9,
              padding: 12
            }
          },
          h("strong", null, item.title),
          h(
            "div",
            {
              style: {
                color: "var(--dsw-alias-text-tertiary)",
                fontSize: 12,
                wordBreak: "break-all"
              }
            },
            `${item.sourceProvider || "DeepSeek"} · ${relativeTime(item.receivedAt)}`
          ),
          h(
            "p",
            {
              style: {
                color: "var(--dsw-alias-text-secondary)",
                fontSize: 13,
                lineHeight: 1.55,
                margin: 0
              }
            },
            item.objective
          ),
          h(
            Button,
            {
              icon: h(IconSendOutline14),
              variant: "outline",
              onClick: () => void load()
            },
            item.state === "loaded" ? "重新载入草稿" : "载入当前会话草稿"
          ),
          message && h(Toast, { text: message, onDone: () => setMessage("") })
        );
      }

      function InboxPanel({ items, loadDraft, loading, onBack, onRefresh }) {
        return h(
          "section",
          { style: { display: "grid", gap: 12 } },
          h(
            "header",
            {
              style: {
                alignItems: "center",
                display: "flex",
                gap: 8,
                justifyContent: "space-between"
              }
            },
            h("strong", null, "交接记录"),
            h(
              "div",
              { style: { display: "flex", gap: 6 } },
              h(
                Button,
                {
                  icon: h(IconRefreshOutline16),
                  size: "sm",
                  variant: "toolbar",
                  onClick: onRefresh
                },
                loading ? "刷新中…" : "刷新"
              ),
              h(
                Button,
                {
                  icon: h(IconChevronLeftOutline14),
                  size: "sm",
                  variant: "ghost",
                  onClick: onBack
                },
                "返回"
              )
            )
          ),
          items.length === 0
            ? h(
                "div",
                {
                  style: {
                    border: "1px dashed var(--dsw-alias-border-subtle)",
                    borderRadius: 10,
                    color: "var(--dsw-alias-text-tertiary)",
                    padding: 20,
                    textAlign: "center"
                  }
                },
                loading ? "正在读取…" : "暂无已整理的交接记录。"
              )
            : h(
                "div",
                { style: { display: "grid", gap: 10 } },
                ...items.map((item) =>
                  h(InboxCard, {
                    key: item.handoffId,
                    item,
                    loadDraft
                  })
                )
              )
        );
      }

      function SpecsRelayClarificationPanel({
        browserState,
        officialBrowser,
        draftClarification,
        onComplete,
        pendingQuestion,
        projectPath,
        sessionId
      }) {
        const [question, setQuestion] = useState("");
        const [pending, setPending] = useState(null);
        const [result, setResult] = useState(null);
        const [busy, setBusy] = useState("");
        const [error, setError] = useState("");
        const [draftCopied, setDraftCopied] = useState(false);
        const [pendingCard, setPendingCard] = useState(false);
        const [cardAnswer, setCardAnswer] = useState("");
        const [cardCopied, setCardCopied] = useState(false);
        const storageKey = `specsrelay.dsh.clarification.v4:${encodeURIComponent(sessionId)}`;

        useEffect(() => {
          let active = true;
          if (pendingQuestion) setQuestion((current) => current || pendingQuestion);
          const restore = (value) => {
            const packet = value?.baseline;
            if (active && packet?.version === 4 && packet.sessionId === sessionId &&
                normalizedPath(packet.projectPath) === normalizedPath(projectPath)) {
              setPending(packet);
              setQuestion(packet.question || "");
            }
          };
          let cached = null;
          try { cached = JSON.parse(localStorage.getItem(storageKey) || "null"); } catch {}
          if (cached?.version === 4) restore(cached);
          else void readWorkspaceState(storageKey).then(restore).catch(() => {});
          void fetch(`${API}/clarification/question?sessionId=${encodeURIComponent(sessionId)}`, {
            cache: "no-store"
          }).then(async (response) => {
            const data = await response.json();
            if (active && response.ok) setQuestion((current) => current || data.question || "");
          }).catch(() => {});
          return () => { active = false; };
        }, [pendingQuestion, projectPath, sessionId, storageKey]);

        const savePending = async (packet) => {
          const state = { version: 4, baseline: packet };
          let cached = false;
          try {
            localStorage.setItem(storageKey, JSON.stringify(state));
            cached = true;
          } catch {
            // Host persistence may still be available.
          }
          try {
            await writeWorkspaceState(storageKey, state);
          } catch (cause) {
            if (!cached) throw cause;
          }
        };

        const request = async (route, value) => {
          const response = await fetch(`${API}/clarification/${route}`, {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify(value)
          });
          const data = await response.json();
          if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
          return data;
        };

        const begin = async () => {
          setBusy("begin");
          setError("");
          try {
            const capture = officialBrowser ? await (await officialBrowser).capture() : undefined;
            const packet = await request("begin", { sessionId, question, capture });
            if (officialBrowser) {
              await (await officialBrowser).send(packet.sendExpression);
              delete packet.sendExpression;
            }
            await savePending(packet);
            setPending(packet);
            setResult(null);
            setDraftCopied(false);
          } catch (cause) {
            setError(cause instanceof Error ? cause.message : String(cause));
          } finally { setBusy(""); }
        };

        const collect = async () => {
          setBusy("collect");
          setError("");
          try {
            const capture = officialBrowser ? await (await officialBrowser).capture() : undefined;
            setResult(await request("result", { sessionId, baseline: pending, capture }));
            setDraftCopied(false);
          } catch (cause) {
            setError(cause instanceof Error ? cause.message : String(cause));
          } finally { setBusy(""); }
        };

        const draft = async () => {
          const loaded = draftClarification(sessionId, result.projectPath, result.prompt);
          if (!loaded.ok) {
            setPendingCard(Boolean(loaded.pendingQuestion));
            setError(loaded.message);
            return;
          }
          await savePending(null).catch(() => {});
          onComplete();
        };

        const reset = async () => {
          try {
            await savePending(null);
            setPending(null);
            setResult(null);
            setDraftCopied(false);
            setPendingCard(false);
            setCardAnswer("");
            setCardCopied(false);
            setError("");
          } catch (cause) {
            setError(cause instanceof Error ? cause.message : String(cause));
          }
        };

        return h(
          React.Fragment,
          null,
          h("strong", null, "把产品问题带回 DeepSeek"),
          h("p", { style: { color: "var(--dsw-alias-text-secondary)", fontSize: 12, margin: 0 } },
            "在原 DeepSeek 对话里讨论并确认，再把新增决定放回当前 DSH 会话草稿。回填草稿时不会自动发送 Agent。"),
          h("div", { style: { fontSize: 12, overflowWrap: "anywhere" } }, `当前项目：${projectPath || "未关联项目"}`),
          error && h("div", { role: "alert", style: { color: "var(--dsw-alias-state-error-primary)", fontSize: 12 } }, error),
          !pending && h(
            React.Fragment,
            null,
            h("label", { htmlFor: "specsrelay-clarification-question", style: { fontSize: 12 } }, "待确认的问题"),
            h("textarea", {
              id: "specsrelay-clarification-question",
              onChange: (event) => setQuestion(event.target.value),
              placeholder: "写下需要你决定的产品问题；可编辑从当前 DSH 会话提取的建议问题。",
              rows: 5,
              style: textAreaStyle,
              value: question
            }),
            h(Button, {
              disabled: browserState !== "ready" || !projectPath || !question.trim() || Boolean(busy),
              onClick: () => void begin(),
              variant: "primary"
            }, busy === "begin" ? "正在发送到原对话…" : "开始澄清")
          ),
          pending && h(
            React.Fragment,
            null,
            h("div", { style: { display: "flex", gap: 8, justifyContent: "space-between" } },
              h("strong", null, "1 · 已发送到左侧原对话"),
              h(Button, { onClick: () => void reset(), size: "sm", variant: "ghost" }, "重新开始")
            ),
            h("p", { style: { color: "var(--dsw-alias-text-secondary)", fontSize: 12, margin: 0 } },
              "问题已自动发送。请在左侧继续讨论，直到你明确确认决定。"),
            h("strong", null, "2 · 回收新增讨论"),
            h(Button, { disabled: browserState !== "ready" || Boolean(busy),
              onClick: () => void collect(), variant: "outline" },
              busy === "collect" ? "正在读取新增讨论…" : "读取刚才的讨论"),
            result && h(
              React.Fragment,
              null,
              h("p", { style: { fontSize: 12, margin: 0 } },
                `只检测到本次新增的 ${result.newMessageCount} 条消息；请核对下方草稿。`),
              h("textarea", { "aria-label": "待放入 DSH 的澄清草稿", readOnly: true,
                rows: 10, style: textAreaStyle, value: result.prompt }),
              h(Button, { onClick: () => void draft(), variant: "primary" },
                "放入当前 DSH 草稿（不发送）"),
              h(Button, {
                onClick: () => void navigator.clipboard.writeText(result.prompt)
                  .then(() => { setError(""); setDraftCopied(true); })
                  .catch(() => setError("复制失败，请手动选中上方草稿复制。")),
                variant: "outline"
              }, draftCopied ? "已复制草稿" : "复制草稿（备用）"),
              pendingCard && h(
                React.Fragment,
                null,
                cardCopied && h("div", { role: "status", style: { fontSize: 12 } },
                  "已复制。请关闭此页面，在当前 DSH 问题卡片中粘贴并提交。"),
                h("label", { htmlFor: "specsrelay-card-answer", style: { fontSize: 12 } },
                  "DSH 正等待问题卡片：请只写下你确认的最终答案"),
                h("textarea", {
                  id: "specsrelay-card-answer",
                  onChange: (event) => setCardAnswer(event.target.value),
                  rows: 4,
                  style: textAreaStyle,
                  value: cardAnswer
                }),
                h(Button, {
                  disabled: !cardAnswer.trim(),
                  onClick: () => void navigator.clipboard.writeText(cardAnswer.trim())
                    .then(() => { setError(""); setCardCopied(true); })
                    .catch(() => setError("复制失败，请手动将确认的答案填入 DSH 问题卡片。")),
                  variant: "outline"
                }, "复制答案供问题卡片使用")
              )
            )
          )
        );
      }

      function EnhancementSettings({ busy, onSaving }) {
        const [state, setState] = useState({ settings: null, draft: null, error: "", loading: true, saving: false });
        const [reload, setReload] = useState(0);
        useEffect(() => {
          let active = true;
          setState((current) => ({ ...current, loading: true, error: "" }));
          fetch(`${API}/enhancement-settings`, { cache: "no-store", signal: AbortSignal.timeout(10000) })
            .then(async (response) => {
              const data = await response.json();
              if (!response.ok || !data.settings) throw new Error(data.error || "无法读取增强设置");
              if (active) setState({ settings: data.settings, draft: data.settings, error: "", loading: false, saving: false });
            })
            .catch((error) => {
              if (active) setState((current) => ({ ...current, loading: false, error: error.message || "无法读取增强设置" }));
            });
          return () => { active = false; };
        }, [reload]);
        const disabled = Boolean(busy) || state.loading || state.saving;
        const labels = { off: "关闭", jev: "Jev", laya: "Laya" };
        const fieldStyle = {
          background: "var(--dsw-alias-bg-layer-2)", border: "1px solid var(--dsw-alias-border-subtle)",
          borderRadius: 8, boxSizing: "border-box", color: "var(--dsw-alias-text-primary)",
          font: "inherit", minWidth: 0, padding: "8px 10px", width: "100%"
        };
        const edit = (field) => (event) => setState((current) => ({
          ...current, draft: { ...current.draft, [field]: event.target.value }, error: ""
        }));
        const save = async () => {
          if (disabled || !state.draft) return;
          setState((current) => ({ ...current, saving: true, error: "" }));
          onSaving(true);
          try {
            const response = await fetch(`${API}/enhancement-settings`, {
              method: "PUT", headers: { "content-type": "application/json" },
              body: JSON.stringify(state.draft), signal: AbortSignal.timeout(10000)
            });
            const data = await response.json();
            if (!response.ok || !data.settings) throw new Error(data.error || "增强设置保存失败");
            setState({ settings: data.settings, draft: data.settings, error: "", loading: false, saving: false });
          } catch (error) {
            setState((current) => ({ ...current, saving: false, error: error.message || "增强设置保存失败" }));
          } finally { onSaving(false); }
        };
        const changed = state.draft && JSON.stringify(state.draft) !== JSON.stringify(state.settings);
        return h("details", { style: { border: "1px solid var(--dsw-alias-border-subtle)", borderRadius: 9, padding: 10, fontSize: 12, minWidth: 0 } },
          h("summary", { style: { cursor: "pointer" } }, `长对话增强 · ${labels[state.settings?.provider] || "设置"}`),
          h("div", { style: { display: "grid", gap: 10, paddingTop: 10, minWidth: 0 } },
            h("span", null, "短对话直接整理；增强不可用时使用完整对话。保存后，下次整理生效。"),
            state.draft && h("label", null, "增强服务",
              h("select", { "aria-label": "增强服务", value: state.draft.provider, disabled, style: fieldStyle, onChange: edit("provider") },
                h("option", { value: "off" }, "关闭"), h("option", { value: "jev" }, "Jev"), h("option", { value: "laya" }, "Laya")
              )
            ),
            state.draft?.provider === "jev" && h("span", null, "使用 DSH 已配置的 TypeSafe 密钥；Jev 会接收本次对话片段。未配置密钥时直接整理完整对话。"),
            state.draft?.provider === "laya" && h(React.Fragment, null,
              h("label", null, "Laya 服务地址",
                h("input", { "aria-label": "Laya 服务地址", type: "url", value: state.draft.layaUrl, disabled, style: fieldStyle,
                  placeholder: "http://127.0.0.1:8000", onChange: edit("layaUrl"), spellCheck: false })
              ),
              h("label", null, "Laya 模型名称（可选）",
                h("input", { "aria-label": "Laya 模型名称", value: state.draft.layaModel, disabled, style: fieldStyle,
                  placeholder: "multilingual", onChange: edit("layaModel"), spellCheck: false })
              ),
              h("span", null, "填写已启动的 Laya 服务地址，对话片段会发往该服务。本地模型文件由服务端加载。")
            ),
            state.error && h("div", { role: "alert" }, state.error),
            !state.draft && !state.loading && h(Button, { size: "sm", variant: "ghost", disabled: Boolean(busy), onClick: () => setReload((value) => value + 1) }, "重试读取设置"),
            state.draft && h(Button, { size: "sm", disabled: disabled || !changed, onClick: save }, state.saving ? "正在保存…" : changed ? "保存增强设置" : "当前设置已生效")
          )
        );
      }

      function SpecsRelayDeepSeekView({
        dshDesktop,
        loadDraft,
        loadProjectDraft,
        draftClarification,
        getPendingQuestion,
        mode = "workbench",
        onClose,
        openSession,
        pickProject,
        prepareProject,
        sessionId,
        standalone = false,
        useSessions
      }) {
        const [viewMode, setViewMode] = useState(mode);
        const [busy, setBusy] = useState("");
        const [browserState, setBrowserState] = useState("starting");
        const officialContainerRef = useRef(null);
        const browserMounted = useRef(false);
        const officialBrowser = useMemo(() => officialBridge
          ? import(`${API}/official-browser.js`).then(({ createOfficialBrowser }) => createOfficialBrowser(officialBridge, {
              document, request: browserRequest,
              onError: (error) => {
                if (!browserMounted.current) return;
                setBrowserState("error");
                setMessageKind("error");
                setMessage(error instanceof Error ? error.message : String(error));
              }
            })) : null, []);
        const [compactLayout, setCompactLayout] = useState(false);
        const [compactPane, setCompactPane] = useState("web");
        const [sources, setSources] = useState([]);
        const [integratedFingerprint, setIntegratedFingerprint] = useState("");
        const [answers, setAnswers] = useState([]);
        const [executionHistory, setExecutionHistory] = useState([]);
        const [history, setHistory] = useState([]);
        const [loadedStorageKey, setLoadedStorageKey] = useState("");
        const [message, setMessage] = useState("");
        const [messageKind, setMessageKind] = useState("info");
        const [organizerRoute, setOrganizerRoute] = useState({
          provider: "",
          model: ""
        });
        const [panel, setPanel] = useState("workbench");
        const [preparedTarget, setPreparedTarget] = useState(null);
        const [projectPreparing, setProjectPreparing] = useState(false);
        const [summary, setSummary] = useState(null);
        const viewRef = useRef(null);
        const webPanelRef = useRef(null);
        const state = useInbox();
        const currentWorkspace = useSessions(
          (sessions) => sessions.byId[sessionId]?.cwd || ""
        );
        const [projectPath, setProjectPath] = useState(currentWorkspace);
        const storageKey = useMemo(
          () =>
            `${WORKSPACE_STORAGE_PREFIX}${encodeURIComponent(
              currentWorkspace || sessionId || "global"
            )}`,
          [currentWorkspace, sessionId]
        );
        const workspaceState = useMemo(
          () => ({
            version: 3,
            sources,
            integratedFingerprint,
            handoff: summary,
            answers,
            history,
            executionHistory,
            organizerRoute
          }),
          [
            answers,
            executionHistory,
            history,
            integratedFingerprint,
            organizerRoute,
            sources,
            summary
          ]
        );
        const sorted = useMemo(
          () =>
            [...state.items].sort((left, right) =>
              right.receivedAt.localeCompare(left.receivedAt)
            ),
          [state.items]
        );
        const currentFingerprint = sourcesFingerprint(sources);
        const needsIntegration = Boolean(
          (currentFingerprint || summary) &&
            currentFingerprint !== integratedFingerprint
        );
        const currentPrompt = summary ? formatHandoffPrompt(summary) : "";
        const currentExecutionFingerprint =
          projectPath && currentPrompt
            ? stableHash(`${projectPath}\n${currentPrompt}`)
            : "";
        const currentVersionLoaded = Boolean(
          currentExecutionFingerprint &&
            executionHistory.some(
              (item) =>
                item.status === "submitted" &&
                item.fingerprint === currentExecutionFingerprint
            )
        );
        const targetShouldPrepare = Boolean(
          viewMode !== "clarification" &&
          projectPath &&
            summary?.ready_for_execution === true &&
            (!Array.isArray(summary.open_questions) ||
              summary.open_questions.length === 0) &&
            !needsIntegration &&
            !currentVersionLoaded
        );

        useEffect(() => {
          if (dshDesktop) {
            setCompactLayout(false);
            return;
          }
          const node = viewRef.current;
          if (!node || typeof ResizeObserver !== "function") return;
          const observer = new ResizeObserver(([entry]) => {
            if (entry) setCompactLayout(entry.contentRect.width < 1040);
          });
          observer.observe(node);
          return () => observer.disconnect();
        }, [dshDesktop]);

        useEffect(() => {
          setProjectPath(currentWorkspace);
        }, [currentWorkspace]);

        useEffect(() => {
          if (viewMode === "clarification") return;
          let cancelled = false;
          if (!targetShouldPrepare) {
            setPreparedTarget(null);
            setProjectPreparing(false);
            return () => {
              cancelled = true;
            };
          }
          setPreparedTarget(null);
          setProjectPreparing(true);
          void prepareProject(projectPath)
            .then((result) => {
              if (cancelled) return;
              if (!result.ok) throw new Error(result.message);
              setPreparedTarget(result);
            })
            .catch((error) => {
              if (cancelled) return;
              setMessageKind("error");
              setMessage(
                error instanceof Error ? error.message : String(error)
              );
            })
            .finally(() => {
              if (!cancelled) setProjectPreparing(false);
            });
          return () => {
            cancelled = true;
          };
        }, [prepareProject, projectPath, targetShouldPrepare]);

        useEffect(() => {
          if (viewMode === "clarification") return;
          let cancelled = false;
          const restore = (value) => {
            const restored = normalizeWorkspace(value);
            setSources(restored.sources);
            setIntegratedFingerprint(restored.integratedFingerprint);
            setSummary(restored.handoff);
            setAnswers(restored.answers);
            setHistory(restored.history);
            setExecutionHistory(restored.executionHistory);
            setOrganizerRoute(restored.organizerRoute);
          };
          let cached = null;
          try {
            cached = JSON.parse(localStorage.getItem(storageKey) || "null");
          } catch {
            // A malformed or unavailable browser cache does not block host restoration.
          }
          restore(cached);
          setPanel("workbench");
          setLoadedStorageKey("");
          void readWorkspaceState(storageKey)
            .then((durable) => {
              if (!cancelled && durable) restore(durable);
            })
            .catch(() => {
              // Browser cache remains the fallback when host persistence is unavailable.
            })
            .finally(() => {
              if (!cancelled) setLoadedStorageKey(storageKey);
            });
          return () => {
            cancelled = true;
          };
        }, [viewMode, storageKey]);

        useEffect(() => {
          if (viewMode === "clarification") return;
          const controller = new AbortController();
          fetch(
            `${API}/organizer/status?sessionId=${encodeURIComponent(sessionId)}`,
            { cache: "no-store", signal: controller.signal }
          )
            .then(async (response) => {
              const data = await response.json();
              if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
              setOrganizerRoute({
                provider: String(data.provider || ""),
                model: String(data.model || "")
              });
            })
            .catch((error) => {
              if (error?.name !== "AbortError") {
                setOrganizerRoute({ provider: "", model: "" });
              }
            });
          return () => controller.abort();
        }, [viewMode, sessionId]);

        useEffect(() => {
          if (viewMode === "clarification") return;
          if (loadedStorageKey !== storageKey) return;
          try {
            localStorage.setItem(storageKey, JSON.stringify(workspaceState));
          } catch {
            // Host persistence remains available when the browser cache is unavailable.
          }
          const timer = window.setTimeout(() => {
            void writeWorkspaceState(storageKey, workspaceState).catch(() => {
              // Browser cache remains the fallback when host persistence fails.
            });
          }, 250);
          return () => window.clearTimeout(timer);
        }, [
          loadedStorageKey,
          viewMode,
          storageKey,
          workspaceState
        ]);

        useEffect(() => {
          if (!message || messageKind === "error") return;
          const timer = window.setTimeout(
            () => setMessage(""),
            STATUS_MESSAGE_DURATION_MS
          );
          return () => window.clearTimeout(timer);
        }, [message, messageKind]);

        const startBrowser = async ({ reload = false } = {}) => {
          setBrowserState("starting");
          setMessage("");
          try {
            if (officialBrowser) {
              await (await officialBrowser).start(officialContainerRef.current, currentWorkspace || sessionId, reload);
              if (browserMounted.current) setBrowserState("ready");
              return;
            }
            const response = await fetch(
              `${API}/browser/start${reload ? "?reload=1" : ""}`,
              {
              method: "POST"
              }
            );
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
            setBrowserState("ready");
          } catch (error) {
            if (!browserMounted.current) return;
            setBrowserState("error");
            setMessageKind("error");
            setMessage(error instanceof Error ? error.message : String(error));
          }
        };

        useEffect(() => {
          browserMounted.current = true;
          void startBrowser();
          return () => {
            browserMounted.current = false;
            if (officialBrowser) void officialBrowser.then((browser) => browser.dispose()).catch(() => {});
          };
        }, []);

        const closeView = () => {
          if (loadedStorageKey === storageKey) {
            void writeWorkspaceState(storageKey, workspaceState).catch(() => {});
          }
          if (!officialBrowser) void fetch(`${API}/browser/layout`, {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ visible: false }),
            keepalive: true
          }).catch(() => {});
          onClose?.();
        };

        useEffect(() => {
          if (officialBrowser) return;
          const node = webPanelRef.current;
          if (!node) return;
          let active = true;
          let animationFrame = 0;
          const publish = () => {
            cancelAnimationFrame(animationFrame);
            animationFrame = requestAnimationFrame(() => {
              if (!active) return;
              const rect = node.getBoundingClientRect();
              const visible =
                browserState === "ready" &&
                (!compactLayout || compactPane === "web") &&
                rect.width > 0 &&
                rect.height > 0;
              void fetch(`${API}/browser/layout`, {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: JSON.stringify({
                  visible,
                  x: Math.max(0, Math.round(rect.x)),
                  y: Math.max(0, Math.round(rect.y)),
                  width: Math.max(0, Math.round(rect.width)),
                  height: Math.max(0, Math.round(rect.height))
                })
              }).then(async (response) => {
                if (response.ok || !active) return;
                const data = await response.json().catch(() => ({}));
                throw new Error(data.error || `HTTP ${response.status}`);
              }).catch((error) => {
                if (!active) return;
                setBrowserState("error");
                setMessageKind("error");
                setMessage(error instanceof Error ? error.message : String(error));
              });
            });
          };
          const resizeObserver = typeof ResizeObserver === "function"
            ? new ResizeObserver(publish)
            : null;
          resizeObserver?.observe(node);
          window.addEventListener("resize", publish);
          window.addEventListener("scroll", publish, true);
          publish();
          return () => {
            active = false;
            cancelAnimationFrame(animationFrame);
            resizeObserver?.disconnect();
            window.removeEventListener("resize", publish);
            window.removeEventListener("scroll", publish, true);
            void fetch(`${API}/browser/layout`, {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ visible: false }),
              keepalive: true
            }).catch(() => {});
          };
        }, [browserState, compactLayout, compactPane]);

        const organizeSources = async (kind, sourceItems, extra = {}) => {
          if (sourceItems.length === 0) return;
          const fingerprint = sourcesFingerprint(sourceItems);
          setBusy(kind);
          setMessage("");
          try {
            const response = await fetch(`${API}/organize`, {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({
                sessionId,
                text: formatSourcesTranscript(sourceItems),
                ...extra
              }),
              signal: AbortSignal.timeout(190000)
            });
            const data = await response.json();
            if (!response.ok) {
              throw new Error(data.error || `HTTP ${response.status}`);
            }
            setSummary(data.handoff);
            setOrganizerRoute({
              provider: String(data.provider || ""),
              model: String(data.model || "")
            });
            setAnswers(
              Array.isArray(data.handoff?.open_questions)
                ? data.handoff.open_questions.map(() => "")
                : []
            );
            setIntegratedFingerprint(fingerprint);
            setPanel("workbench");
            setMessageKind("success");
            setMessage(
              data.requiresClarification
                ? "需求分析 Skill 已完成强化，但仍有需要你确认的产品决定。"
                : `已使用 ${data.skill?.name || "SpecsRelay 需求分析 Skill"}，并由 DSH 的 ${data.provider} · ${data.model} 完成需求整理。`
            );
          } catch (error) {
            setMessageKind("error");
            setMessage(error instanceof Error ? error.message : String(error));
          } finally {
            setBusy("");
          }
        };

        const organize = (kind, extra = {}) =>
          organizeSources(kind, sources, extra);

        const captureCurrentConversation = async () => {
          if (browserState !== "ready" || busy) return;
          setBusy("capture");
          setMessage("");
          try {
            const rawCapture = officialBrowser ? await (await officialBrowser).capture() : undefined;
            const response = await fetch(`${API}/browser/capture`, rawCapture
              ? { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ capture: rawCapture }) }
              : { method: "POST" });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
            const capture = data.item;
            const nextSources = addCapturedRequirementSource(capture);
            setSources(nextSources);
            setPanel("workbench");
            setMessageKind("info");
            setMessage(
              `已抓取当前完整对话（${capture.messageCount} 条消息），正在自动整理需求…`
            );
            await organizeSources("integrate", nextSources);
          } catch (error) {
            setMessageKind("error");
            setMessage(error instanceof Error ? error.message : String(error));
          } finally {
            setBusy("");
          }
        };

        const clarify = () =>
          organize("clarify", {
            previousHandoff: summary,
            clarifications: (summary?.open_questions || []).map(
              (question, index) => ({ question, answer: answers[index] || "" })
            )
          });

        const newRequirement = () => {
          const snapshot = workspaceSnapshot(
            sources,
            integratedFingerprint,
            summary,
            answers
          );
          const archived = snapshotHasContent(snapshot);
          if (archived) {
            setHistory((items) => [snapshot, ...items].slice(0, MAX_WORKSPACE_HISTORY));
          }
          setSources([]);
          setIntegratedFingerprint("");
          setSummary(null);
          setAnswers([]);
          setPanel("workbench");
          setMessageKind("success");
          setMessage(
            archived
              ? "当前需求已移除，并已保存到本地恢复记录。"
              : "当前没有可移除的需求。"
          );
        };

        const restoreHistory = (index) => {
          const selected = history[index];
          if (!selected) return;
          const current = workspaceSnapshot(
            sources,
            integratedFingerprint,
            summary,
            answers
          );
          const remaining = history.filter((_, itemIndex) => itemIndex !== index);
          setHistory(
            snapshotHasContent(current)
              ? [current, ...remaining].slice(0, MAX_WORKSPACE_HISTORY)
              : remaining
          );
          setSources(normalizeSources(selected.sources));
          setIntegratedFingerprint(selected.integratedFingerprint || "");
          setSummary(selected.handoff || null);
          setAnswers(Array.isArray(selected.answers) ? selected.answers : []);
          setPanel("workbench");
          setMessageKind("success");
          setMessage("已恢复所选需求工作区。");
        };

        const openInbox = () => {
          setPanel("inbox");
          void inbox.refresh();
        };

        const selectProject = async () => {
          const selected = await pickProject();
          if (selected) {
            setPreparedTarget(null);
            setProjectPath(selected);
          }
          return selected;
        };

        const loadCurrentVersion = async (prompt) => {
          if (!summary) {
            return { ok: false, message: "当前还没有可载入的结构化需求。" };
          }
          const handoffStartedAt = performance.now();
          const prepared =
            preparedTarget &&
            normalizedPath(preparedTarget.projectPath) ===
              normalizedPath(projectPath)
              ? preparedTarget
              : null;
          const result = await loadProjectDraft({
            handoffId: `dsh-live-${Date.now()}`,
            objective: summary.objective,
            preparedProjectPath: prepared?.projectPath,
            preparedSessionId: prepared?.sessionId,
            projectPath,
            prompt,
            receivedAt: new Date().toISOString(),
            sourceProvider: "DeepSeek",
            state: "received",
            submit: true,
            title: summary.title
          });
          if (result.ok) {
            console.info("[SpecsRelay] DSH handoff timing", {
              clickToSubmitMs: performance.now() - handoffStartedAt,
              localSubmitMs: result.submitLatencyMs
            });
            const loadedProjectPath = result.projectPath || projectPath;
            const snapshot = createExecutionSnapshot(
              summary,
              loadedProjectPath,
              prompt,
              sources
            );
            const nextExecutionHistory = normalizeExecutionHistory([
              snapshot,
              ...executionHistory.filter(
                (item) => item.fingerprint !== snapshot.fingerprint
              )
            ]);
            setProjectPath(loadedProjectPath);
            setExecutionHistory(nextExecutionHistory);
            const targetStorageKey = `${WORKSPACE_STORAGE_PREFIX}${encodeURIComponent(
              loadedProjectPath || result.sessionId || "global"
            )}`;
            const loadedWorkspaceState = {
              ...workspaceState,
              executionHistory: nextExecutionHistory
            };
            try {
              localStorage.setItem(
                targetStorageKey,
                JSON.stringify(loadedWorkspaceState)
              );
            } catch {
              // Host persistence remains available when the browser cache is unavailable.
            }
            void writeWorkspaceState(
              targetStorageKey,
              loadedWorkspaceState
            ).catch(() => {});
            openSession(result.sessionId);
            closeView();
          }
          return result;
        };

        const reloadExecutionSnapshot = (snapshot) =>
          loadDraft({
            handoffId: `dsh-snapshot-${snapshot.id}`,
            objective: snapshot.handoff.objective,
            projectPath: snapshot.projectPath,
            prompt: snapshot.prompt,
            receivedAt: snapshot.createdAt,
            sourceProvider: "DeepSeek",
            state: "loaded",
            title: snapshot.handoff.title
          });

        const reviseFromSnapshot = (snapshot, revisionInstruction) => {
          const snapshotSources = snapshot.sources.length
            ? snapshot.sources
            : sources;
          setSources(snapshotSources);
          setSummary(snapshot.handoff);
          setIntegratedFingerprint(sourcesFingerprint(snapshotSources));
          setPanel("workbench");
          void organizeSources("revision", snapshotSources, {
            previousHandoff: snapshot.handoff,
            revisionInstruction
          });
        };

        return h(
          "section",
          {
            "aria-label": "SpecsRelay DeepSeek 网页",
            ref: viewRef,
            style: {
              boxSizing: dshDesktop ? "border-box" : undefined,
              color: "var(--dsw-alias-text-primary)",
              display: "flex",
              flexDirection: "column",
              gap: 10,
              height: standalone
                ? (dshDesktop ? "100%" : "100vh")
                : "calc(100vh - 190px)",
              minHeight: dshDesktop && standalone ? 0 : 520,
              minWidth: 0,
              padding: standalone ? 16 : "0 16px 16px"
            }
          },
          h(
            "header",
            {
              style: {
                alignItems: "center",
                display: "flex",
                gap: 8,
                justifyContent: "space-between"
              }
            },
            h(
              "div",
              { style: { minWidth: 0 } },
              h("strong", null, "DeepSeek 网页"),
              h(
                "div",
                {
                  title: currentWorkspace,
                  style: {
                    color: "var(--dsw-alias-text-tertiary)",
                    fontSize: 12,
                    marginTop: 3,
                    maxWidth: "min(62vw, 720px)",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap"
                  }
                },
                currentWorkspace
                  ? `当前 DSH 项目：${currentWorkspace}`
                  : "当前 DSH 会话尚未关联项目"
              )
            ),
          compactLayout &&
            h(
              "div",
              {
                role: "tablist",
                "aria-label": "DeepSeek 与 SpecsRelay",
                style: { display: "flex", gap: 6 }
              },
              h(
                Pill,
                {
                  active: compactPane === "web",
                  role: "tab",
                  "aria-selected": compactPane === "web",
                  onClick: () => setCompactPane("web")
                },
                "DeepSeek 网页"
              ),
              h(
                Pill,
                {
                  active: compactPane === "relay",
                  role: "tab",
                  "aria-selected": compactPane === "relay",
                  onClick: () => setCompactPane("relay")
                },
                "SpecsRelay"
              )
            ),
          h(
            "div",
              { style: { display: "flex", gap: 8 } },
              h(
                Button,
                {
                  icon: h(IconRefreshOutline16),
                  size: "sm",
                  variant: "toolbar",
                  onClick: () => void startBrowser({ reload: true })
                },
                "刷新网页"
              ),
              onClose &&
                h(
                  Button,
                  {
                    icon: h(IconCloseOutline16),
                    size: "sm",
                    variant: "ghost",
                    onClick: closeView
                  },
                  "关闭"
                )
            )
          ),
          h(
            "div",
            {
              style: {
                display: "grid",
                flex: "1 1 auto",
                gap: 10,
                gridTemplateColumns: compactLayout
                  ? "minmax(0, 1fr)"
                  : dshDesktop
                    ? "minmax(0, 1fr) clamp(320px, 38%, 480px)"
                    : "minmax(0, 1fr) minmax(440px, 510px)",
                minHeight: 0
              }
            },
            h(
              "div",
              {
                ref: webPanelRef,
                style: {
                  position: "relative",
                  border: "1px solid var(--dsw-alias-border-subtle)",
                  borderRadius: 12,
                  display: compactLayout && compactPane !== "web" ? "none" : "block",
                  minHeight: 0,
                  overflow: "hidden"
                }
              },
              officialBrowser && h("div", {
                ref: officialContainerRef,
                style: { position: "absolute", inset: 0 }
              }),
              h(
                "div",
                {
                  style: {
                    alignItems: "center",
                    background: "#101114",
                    color: "var(--dsw-alias-text-tertiary)",
                    display: officialBrowser && browserState === "ready" ? "none" : "flex",
                    position: "relative",
                    pointerEvents: "none",
                    height: "100%",
                    justifyContent: "center",
                    minHeight: 500,
                    width: "100%"
                  }
                },
                browserState === "error" ? "DeepSeek 网页启动失败，请查看错误详情后重试" : "正在准备 DeepSeek…"
              )
            ),
            h(
              "aside",
              {
                "aria-label": "SpecsRelay 常驻侧栏",
                style: {
                  background: "var(--dsw-alias-bg-layer-1)",
                  border: "1px solid var(--dsw-alias-border-subtle)",
                  borderRadius: 12,
                  display: compactLayout && compactPane !== "relay" ? "none" : "flex",
                  flexDirection: "column",
                  minHeight: 0,
                  overflow: "hidden"
                }
              },
              h(
                "header",
                {
                  style: {
                    alignItems: "center",
                    borderBottom: "1px solid var(--dsw-alias-border-subtle)",
                    display: "flex",
                    flexWrap: dshDesktop ? "wrap" : undefined,
                    gap: 10,
                    padding: "12px 14px"
                  }
                },
                h("img", {
                  src: SPECSRELAY_ICON,
                  alt: "",
                  "aria-hidden": true,
                  draggable: false,
                  style: { borderRadius: 6, height: 26, width: 26 }
                }),
                h(
                  "div",
                  null,
                  h("strong", null, "SpecsRelay"),
                  h(
                    "div",
                    {
                      style: {
                        color: "var(--dsw-alias-text-tertiary)",
                        fontSize: 11,
                        marginTop: 2
                      }
                    },
                    viewMode === "clarification"
                      ? "DSH 产品问题 → DeepSeek → 当前会话"
                      : "DeepSeek → DSH 需求交接"
                  )
                ),
                h(
                  "div",
                  { style: {
                    display: "flex",
                    flexShrink: dshDesktop ? 0 : undefined,
                    gap: 6,
                    marginLeft: "auto",
                    whiteSpace: dshDesktop ? "nowrap" : undefined
                  } },
                  currentWorkspace && h(Button, {
                    size: "sm",
                    variant: "ghost",
                    onClick: () => {
                      setPanel("workbench");
                      setViewMode((current) => current === "clarification" ? "workbench" : "clarification");
                    }
                  }, viewMode === "clarification" ? "返回交接" : "需求澄清"),
                  viewMode !== "clarification" && h(Pill, { active: true }, "DSH 模型"),
                  viewMode !== "clarification" && h(
                    Button,
                    {
                      icon: h(IconArchiveOutline20, { size: 16 }),
                      size: "sm",
                      variant: "ghost",
                      onClick: openInbox
                    },
                    "记录"
                  )
                )
              ),
              h(
                "div",
                {
                  style: {
                    alignContent: "start",
                    display: "grid",
                    flex: "1 1 auto",
                    gap: 12,
                    gridAutoRows: "max-content",
                    gridTemplateColumns: dshDesktop ? "minmax(0, 1fr)" : undefined,
                    overflow: "auto",
                    padding: 14
                  }
                },
                viewMode === "clarification"
                  ? h(SpecsRelayClarificationPanel, {
                      browserState,
                      officialBrowser,
                      draftClarification,
                      onComplete: closeView,
                      pendingQuestion: getPendingQuestion?.(sessionId) || "",
                      projectPath: currentWorkspace,
                      sessionId
                    })
                  : panel === "inbox"
                  ? h(InboxPanel, {
                      items: sorted,
                      loadDraft,
                      loading: state.loading,
                      onBack: () => setPanel("workbench"),
                      onRefresh: () => void inbox.refresh()
                    })
                  : h(
                      React.Fragment,
                      null,
                      browserState !== "ready" &&
                        h(
                          "div",
                          {
                            role: browserState === "error" ? "alert" : "status",
                            style: {
                              alignItems: "center",
                              background: "color-mix(in srgb, var(--dsw-alias-state-warning-primary, #f4b740) 10%, var(--dsw-alias-bg-layer-2))",
                              border: "1px solid var(--dsw-alias-state-warning-primary, #f4b740)",
                              borderRadius: 9,
                              display: "flex",
                              gap: 8,
                              minHeight: 38,
                              padding: "0 10px"
                            }
                          },
                          h(StateDot, { state: "warning" }),
                          h(
                            "span",
                            { style: { flex: 1, fontSize: 12 } },
                            browserState === "error"
                              ? "暂时无法打开 DeepSeek，请重试。"
                              : "正在准备 DeepSeek…"
                          ),
                          browserState === "error" &&
                            h(Button, { size: "sm", variant: "ghost", onClick: () => void startBrowser({ reload: true }) }, "重试")
                        ),
                      h(
                        "div",
                        {
                          style: {
                            alignItems: "center",
                            background: "color-mix(in srgb, var(--dsw-alias-brand-primary, #35d39a) 8%, var(--dsw-alias-bg-layer-2))",
                            border: "1px solid var(--dsw-alias-brand-primary, #35d39a)",
                            borderRadius: 9,
                            display: "flex",
                            gap: 8,
                            minHeight: 38,
                            padding: "0 10px"
                          }
                        },
                        h(StateDot, { state: organizerRoute.model ? "done" : "warning" }),
                        h(
                          "strong",
                          { style: { fontSize: 12, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } },
                          organizerRoute.model
                            ? `需求模型：DeepSeek · ${organizerRoute.model}`
                            : "正在读取 DSH 当前需求模型"
                        ),
                        h(Pill, { active: true, style: { marginLeft: "auto" } }, "DSH 提供")
                      ),
                      h(EnhancementSettings, { busy, onSaving: (saving) => setBusy(saving ? "enhancement-settings" : "") }),
                      message &&
                        h(
                          "div",
                          {
                            role: messageKind === "error" ? "alert" : "status",
                            style: {
                              alignItems: "flex-start",
                              background:
                                messageKind === "error"
                                  ? "color-mix(in srgb, var(--dsw-alias-state-error-primary, #ed5f74) 10%, var(--dsw-alias-bg-layer-2))"
                                  : "color-mix(in srgb, var(--dsw-alias-brand-primary, #35d39a) 10%, var(--dsw-alias-bg-layer-2))",
                              border: `1px solid ${
                                messageKind === "error"
                                  ? "var(--dsw-alias-state-error-primary, #ed5f74)"
                                  : "var(--dsw-alias-brand-primary, #35d39a)"
                              }`,
                              borderRadius: 9,
                              boxSizing: "border-box",
                              color:
                                messageKind === "error"
                                  ? "var(--dsw-alias-state-error-primary, #ed5f74)"
                                  : "var(--dsw-alias-text-secondary)",
                              display: "flex",
                              gap: 8,
                              maxWidth: "100%",
                              minWidth: 0,
                              minHeight: 42,
                              padding: 10,
                              position: "static"
                            }
                          },
                          messageKind === "error"
                            ? h(IconWarningOutline16)
                            : h(StateDot, { state: "done" }),
                          h(
                            "strong",
                            {
                              style: {
                                flex: 1,
                                fontSize: 12,
                                lineHeight: 1.5,
                                overflowWrap: "anywhere"
                              }
                            },
                            message
                          ),
                          h(
                            Button,
                            {
                              "aria-label": "关闭提示",
                              icon: h(IconCloseOutline16),
                              size: "sm",
                              variant: "ghost",
                              onClick: () => setMessage("")
                            }
                          )
                        ),
                      h(
                        WorkflowStep,
                        {
                          number: 1,
                          title: "建立并强化当前需求",
                          description: "获取当前 DeepSeek 对话后，SpecsRelay 会自动整理并强化为可交接需求。"
                        },
                        (sources.length > 0 || summary) &&
                          h(
                            "div",
                            { style: { display: "flex", justifyContent: "flex-end" } },
                            h(
                              Button,
                              {
                                icon: h(IconTrashOutline16),
                                size: "sm",
                                variant: "ghost",
                                onClick: newRequirement
                              },
                              "移除需求"
                            )
                          ),
                        h(
                          Button,
                          {
                            disabled: browserState !== "ready" || Boolean(busy),
                            icon: h(IconEnhanceOutline16),
                            variant: "primary",
                            onClick: () => void captureCurrentConversation()
                          },
                          busy === "capture"
                            ? "正在抓取完整对话…"
                            : busy === "integrate"
                              ? "正在自动整理需求…"
                            : sources.length
                              ? "重新整理当前对话"
                              : "整理当前对话"
                        ),
                      ),
                      h(
                        RequirementCheckStep,
                        { handoff: summary },
                        summary &&
                          h(HandoffSummaryPanel, {
                            answers,
                            browserReady: browserState === "ready",
                            busy,
                            handoff: summary,
                            onAnswer: (index, value) =>
                              setAnswers((items) => {
                                const next = [...items];
                                next[index] = value;
                                return next;
                              }),
                            onClarify: () => void clarify(),
                            onRecapture: captureCurrentConversation
                          })
                      ),
                      h(DeliveryStep, {
                        alreadyLoaded: currentVersionLoaded,
                        busy,
                        handoff: summary,
                        onLoad: loadCurrentVersion,
                        onSelectProject: selectProject,
                        projectPath,
                        projectPreparing,
                        sourcesChanged: needsIntegration
                      }),
                      h(ExecutionSnapshotPanel, {
                        busy,
                        history: executionHistory,
                        onReload: reloadExecutionSnapshot,
                        onRevise: reviseFromSnapshot
                      })
                    ),
                state.error && panel === "inbox" &&
                  h(
                    "div",
                    {
                      role: "alert",
                      style: {
                        color: "var(--dsw-alias-state-error-primary)",
                        fontSize: 12
                      }
                    },
                    `无法读取交接记录：${state.error}`
                  ),
              )
            )
          ),
          h(
            "p",
            {
              style: {
                color: "var(--dsw-alias-text-tertiary)",
                fontSize: 12,
                margin: 0
              }
            },
            "DeepSeek 登录和对话抓取均在此工作区完成。"
          )
        );
      }

      function SpecsRelayCaptionBackground({ height }) {
        if (!height) return null;
        return h("div", {
          "aria-hidden": true,
          style: {
            background: "var(--dsw-alias-bg-base)",
            height,
            left: 0,
            pointerEvents: "none",
            position: "fixed",
            right: 0,
            top: 0
          }
        });
      }

      function SpecsRelayShortcut({
        dshDesktop,
        desktopTopInset = 0,
        wide,
        draftClarification,
        getPendingQuestion,
        loadDraft,
        loadProjectDraft,
        openSession,
        pickProject,
        prepareProject,
        useSessions
      }) {
        const [open, setOpen] = useState(false);
        const sessionId = useSessions(selectedSessionId);
        const onClick = () => setOpen(true);
        const shortcutIcon = h("img", {
          src: SPECSRELAY_ICON,
          alt: "",
          "aria-hidden": true,
          draggable: false,
          style: {
            borderRadius: officialBridge ? 3 : 5,
            display: "block",
            flex: "none",
            height: officialBridge ? 14 : 22,
            width: officialBridge ? 14 : 22
          }
        });
        return h(
          React.Fragment,
          null,
          officialBridge && h("style", null,
            // The slot wrapper uses display: contents; its parent owns the flex layout.
            'div:has(> [data-slot="sidebar.footer.action"] > [data-specsrelay-footer="official"]) { flex-direction: column; }'
          ),
          h(
            Button,
            {
              icon: officialBridge ? undefined : shortcutIcon,
              "data-specsrelay-footer": officialBridge ? "official" : undefined,
              onClick,
              title: "打开 SpecsRelay",
              "aria-label": "打开 SpecsRelay",
              variant: "ghost",
              style: {
                alignSelf: dshDesktop ? "flex-end" : undefined,
                borderRadius: wide ? 12 : "50%",
                boxSizing: "border-box",
                flex: "none",
                fontSize: 14,
                gap: wide ? 8 : 0,
                height: wide ? 34 : 36,
                justifyContent: wide ? "flex-start" : "center",
                lineHeight: "22px",
                margin: wide ? "4px -4px 4px" : "8px 0 10px",
                overflow: "hidden",
                padding: wide ? "6px 2px 6px 10px" : 0,
                width: wide ? "calc(100% + 8px)" : 36,
                ...(officialBridge ? {
                  alignSelf: wide ? "stretch" : "center",
                  borderRadius: "var(--dsw-radius-md)",
                  height: wide ? 32 : 36,
                  lineHeight: "20px",
                  margin: 0,
                  padding: wide ? "6px 2px 6px 6px" : 0,
                  width: wide ? "100%" : 36
                } : {})
              }
            },
            officialBridge && shortcutIcon,
            wide && h("span", null, "SpecsRelay")
          ),
          open &&
            h(
              "div",
              {
                "aria-label": "DeepSeek 网页入口",
                style: {
                  background: "var(--dsw-alias-bg-base)",
                  inset: 0,
                  position: "fixed",
                  top: desktopTopInset,
                  zIndex: 1000
                }
              },
              h(SpecsRelayDeepSeekView, {
                dshDesktop,
                draftClarification,
                getPendingQuestion,
                loadDraft,
                loadProjectDraft,
                onClose: () => setOpen(false),
                openSession,
                pickProject,
                prepareProject,
                sessionId,
                standalone: true,
                useSessions
              }),
              h(SpecsRelayCaptionBackground, { height: desktopTopInset })
            )
        );
      }

      function SpecsRelayQuickLoad({ loadLatest }) {
        const [status, setStatus] = useState("DeepSeek Relay");
        const onClick = async () => {
          setStatus("读取中…");
          try {
            const item = await inbox.latest();
            if (!item) {
              setStatus("暂无新需求");
              return;
            }
            const result = loadLatest(item);
            if (!result.ok) {
              setStatus("请先切换项目");
              return;
            }
            try {
              await inbox.receipt(item, result.sessionId);
              setStatus("已载入，请检查");
            } catch {
              setStatus("已载入，回执失败");
            }
          } catch {
            setStatus("读取失败");
          }
        };
        return h(
          Button,
          {
            icon: h(IconSendOutline14),
            onClick,
            size: "sm",
            title: "载入最近的 SpecsRelay for DeepSeek 需求",
            variant: "toolbar"
          },
          status
        );
      }

      function SpecsRelayClarificationShortcut({
        dshDesktop,
        desktopTopInset = 0,
        draftClarification,
        getPendingQuestion,
        loadDraft,
        loadProjectDraft,
        openSession,
        pickProject,
        prepareProject,
        sessionId,
        useSessions
      }) {
        const [open, setOpen] = useState(false);
        const projectPath = useSessions((sessions) => sessions.byId[sessionId]?.cwd || "");
        if (!sessionId || !projectPath) return null;
        return h(
          React.Fragment,
          null,
          h(Button, {
            onClick: () => setOpen(true),
            size: "sm",
            title: "把当前会话的产品问题带到 DeepSeek 澄清，再返回本会话草稿",
            variant: "toolbar"
          }, "需求澄清"),
          open && h(
            "div",
            {
              "aria-label": "SpecsRelay 需求澄清",
              style: {
                background: "var(--dsw-alias-bg-base)",
                inset: 0,
                position: "fixed",
                top: desktopTopInset,
                zIndex: 1000
              }
            },
            h(SpecsRelayDeepSeekView, {
              dshDesktop,
              draftClarification,
              getPendingQuestion,
              loadDraft,
              loadProjectDraft,
              mode: "clarification",
              onClose: () => setOpen(false),
              openSession,
              pickProject,
              prepareProject,
              sessionId,
              standalone: true,
              useSessions
            }),
            h(SpecsRelayCaptionBackground, { height: desktopTopInset })
          )
        );
      }

      function SpecsRelayContinuation({ sessionId, continueSession }) {
        const [status, setStatus] = useState(null);
        const [open, setOpen] = useState(false);
        const [busy, setBusy] = useState(false);
        const [sendingBusy, setSendingBusy] = useState(false);
        const [error, setError] = useState("");
        const started = useRef(false);
        const sending = useRef(false);
        const cancelled = useRef(false);
        const controller = useRef(null);

        useEffect(() => {
          let active = true;
          const refresh = async () => {
            try {
              const response = await fetch(
                `${API}/continuation/status?sessionId=${encodeURIComponent(sessionId)}`,
                { cache: "no-store" }
              );
              const data = await response.json();
              if (active) setStatus(response.ok ? data : null);
            } catch {
              if (active) setStatus(null);
            }
          };
          void refresh();
          const timer = setInterval(() => void refresh(), 30000);
          return () => {
            active = false;
            clearInterval(timer);
          };
        }, [sessionId]);

        const onContinue = async () => {
          if (started.current) return;
          started.current = true;
          cancelled.current = false;
          setBusy(true);
          setError("");
          try {
            controller.current = new AbortController();
            const response = await fetch(`${API}/continuation/prepare`, {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ sessionId }),
              signal: controller.current.signal
            });
            const prepared = await response.json();
            if (cancelled.current) return;
            if (!response.ok) {
              throw new Error(prepared.error || `HTTP ${response.status}`);
            }
            sending.current = true;
            setSendingBusy(true);
            await continueSession(sessionId, prepared);
            setOpen(false);
          } catch (cause) {
            if (!cancelled.current) {
              setError(cause instanceof Error ? cause.message : String(cause));
            }
          } finally {
            started.current = false;
            sending.current = false;
            setSendingBusy(false);
            controller.current = null;
            setBusy(false);
          }
        };

        const onCancel = () => {
          if (sending.current) return;
          cancelled.current = true;
          controller.current?.abort();
          setOpen(false);
        };

        if (!status?.available) return null;
        return h(
          React.Fragment,
          null,
          h(
            Button,
            {
              onClick: () => setOpen(true),
              size: "sm",
              title: status.recommended
                ? status.recommendationReason === "compaction"
                  ? "当前会话已自动压缩过上下文，可考虑在本轮完成后接续"
                  : "当前上下文接近模型窗口，适合在本轮完成后接续"
                : "在同一项目中创建新会话并接续当前工作",
              variant: "toolbar"
            },
            status.recommended ? "建议接续" : "接续会话"
          ),
          open && h(
            "div",
            {
              role: "dialog",
              "aria-label": "接续到新会话",
              style: {
                alignItems: "center",
                background: "rgba(0, 0, 0, 0.65)",
                display: "flex",
                inset: 0,
                justifyContent: "center",
                position: "fixed",
                zIndex: 1100
              }
            },
            h(
              "div",
              {
                style: {
                  background: "var(--dsw-alias-bg-layer-1)",
                  border: "1px solid var(--dsw-alias-border-l2)",
                  borderRadius: 12,
                  color: "var(--dsw-alias-label-primary)",
                  maxWidth: 480,
                  padding: 20,
                  width: "calc(100% - 32px)"
                }
              },
              h("h3", { style: { margin: "0 0 12px" } }, "接续到新会话"),
              h("p", { style: { margin: "0 0 10px" } },
                "确认后会整理当前会话，在同一项目创建新会话并发送接续材料。旧会话保持不变。"),
              h("p", { style: { margin: "0 0 10px", overflowWrap: "anywhere" } },
                `项目：${status.projectPath}`),
              status.pressureRatio !== null && h(
                "p",
                { style: { margin: "0 0 10px" } },
                `上下文估算：${Math.round(status.pressureRatio * 100)}%（仅供参考）`
              ),
              error && h("p", { role: "alert", style: { color: "var(--dsw-alias-state-error-primary)" } }, error),
              h("div", { style: { display: "flex", gap: 8, justifyContent: "flex-end" } },
                h(Button, { disabled: sendingBusy, onClick: onCancel, variant: "ghost" }, "取消"),
                h(Button, { disabled: busy, onClick: () => void onContinue() },
                  busy ? "正在整理并接续…" : "确认并接续")
              )
            )
          )
        );
      }

      const inject = ["slots", "sessions", "conversation", "workspaces"];

      function apply(ctx) {
        const locationParams = new URLSearchParams(window.location.search);
        const dshDesktopMode = locationParams.get("dsh-desktop-mode");
        const dshDesktopPlatform = locationParams.get("dsh-desktop-platform");
        const isDshDesktop = Boolean(officialBridge) || ["compatibility", "extended", "advanced"].includes(
          dshDesktopMode
        ) && ["darwin", "win32", "linux"].includes(dshDesktopPlatform);
        if (!isDshDesktop) return;
        const desktopTopInset = officialBridge
          ? (document.documentElement.dataset.platform === "win32" ? 40 : 32)
          : isDshDesktop && dshDesktopMode === "advanced" &&
          ["darwin", "win32"].includes(dshDesktopPlatform)
          ? DSH_ENHANCED_TITLEBAR_HEIGHT
          : 0;
        const continuationAttempts = new Map();
        const loadCurrent = (item) => {
          const sessionId = selectedSessionId(ctx.sessions.list.getSnapshot());
          if (!sessionId) {
            return {
              ok: false,
              message: "请先在 DSH 中选择项目并创建会话。"
            };
          }
          return loadIntoSession(ctx, sessionId, item);
        };
        const loadProject = (item) => loadIntoProject(ctx, item);
        const openSession = (sessionId) => navigateSession(ctx, sessionId);
        const pickProject = () => {
          const desktopPicker = officialBridge ? window.__DSH_DIRECTORY_PICKER__ : window.dshDesktopDirectoryPicker;
          return desktopPicker && typeof desktopPicker.pick === "function"
            ? desktopPicker.pick()
            : (officialBridge ? ctx.get("uiWorkspace") : ctx.workspaces).pickDirectory();
        };
        const prepareProject = (projectPath) =>
          prepareProjectTarget(ctx, projectPath);
        ctx.effect(
          () =>
            ctx.slots.inject("sidebar.footer.action", () =>
              ctx.slots.register(
                {
                  name: "sidebar.footer.action",
                  id: "specsrelay-deepseek",
                  order: 10,
                  inject: () => ({
                    dshDesktop: isDshDesktop,
                    desktopTopInset,
                    draftClarification: (sourceId, projectPath, prompt) =>
                      loadClarificationDraft(ctx, sourceId, projectPath, prompt),
                    getPendingQuestion: (sourceId) => pendingQuestionText(ctx, sourceId),
                    loadDraft: loadCurrent,
                    loadProjectDraft: loadProject,
                    openSession,
                    pickProject,
                    prepareProject
                  })
                },
                SpecsRelayShortcut
              )
            ),
          "specsrelay-deepseek: sidebar shortcut"
        );
        ctx.effect(
          () =>
            ctx.slots.inject("conversation.input.right", () =>
              ctx.slots.register(
                {
                  name: "conversation.input.right",
                  id: "specsrelay-deepseek",
                  order: 40,
                  inject: (sessionId) => ({
                    loadLatest: (item) => loadIntoSession(ctx, sessionId, item)
                  })
                },
                SpecsRelayQuickLoad
              )
            ),
          "specsrelay-deepseek: composer shortcut"
        );
        ctx.effect(
          () =>
            ctx.slots.inject("conversation.input.right", () =>
              ctx.slots.register(
                {
                  name: "conversation.input.right",
                  id: "specsrelay-continuation",
                  order: 41,
                  inject: (sessionId) => ({
                    sessionId,
                    continueSession: async (sourceId, prepared) => {
                      const prior = continuationAttempts.get(sourceId);
                      if (prior) {
                        openSession(prior.targetId);
                        throw new Error("已创建接续会话。请先在新会话核对发送状态，避免重复提交。");
                      }
                      const latestResponse = await fetch(
                        `${API}/continuation/status?sessionId=${encodeURIComponent(sourceId)}`,
                        { cache: "no-store" }
                      );
                      const latest = await latestResponse.json();
                      if (
                        !latestResponse.ok || !latest.available ||
                        latest.sourceFingerprint !== prepared.sourceFingerprint
                      ) {
                        throw new Error("当前会话在整理后发生了变化，请重新接续。");
                      }
                      const sessions = ctx.sessions.list.getSnapshot();
                      const source = sessions.byId[sourceId];
                      const jobs = sessions.jobsBySession?.[sourceId] || [];
                      if (!source || source.running || jobs.length > 0) {
                        throw new Error("当前会话仍有任务在运行，请稍后接续。");
                      }
                      if (normalizedPath(source.cwd) !== normalizedPath(prepared.projectPath)) {
                        throw new Error("项目目录已变化，请重新接续。");
                      }
                      let workspace = ctx.workspaces.list.getSnapshot().items.find(
                        (candidate) =>
                          normalizedPath(candidate.path) === normalizedPath(prepared.projectPath)
                      );
                      if (!workspace) {
                        workspace = await ctx.workspaces.create({ path: prepared.projectPath });
                      }
                      const newId = await ctx.sessions.create({ workspaceId: workspace.workspaceId });
                      continuationAttempts.set(sourceId, { targetId: newId });
                      return withSession(ctx, newId, async () => {
                        const binding = ctx.sessions.binding(newId);
                        if (!binding?.session) {
                          openSession(newId);
                          throw new Error("新会话已创建，但尚未准备好接收任务。请检查会话列表。");
                        }
                        let result;
                        try {
                          result = await binding.session.prompt(
                            [{ type: "text", text: prepared.prompt }],
                            "queue"
                          );
                        } catch {
                          openSession(newId);
                          throw new Error("新会话已创建，发送结果暂不确定。请先核对新会话，避免重复提交。");
                        }
                        if (!result.ok) {
                          const scope = ctx.sessions.scope(newId);
                          if (scope) ctx.conversation.input.for(scope).setDraft(prepared.prompt);
                          openSession(newId);
                          throw new Error("新会话已创建，但未能发送。需求已保留在草稿中，请核对后手动发送。");
                        }
                        openSession(newId);
                      });
                    }
                  })
                },
                SpecsRelayContinuation
              )
            ),
          "specsrelay-deepseek: session continuation"
        );
        ctx.effect(
          () =>
            ctx.slots.inject("conversation.input.right", () =>
              ctx.slots.register(
                {
                  name: "conversation.input.right",
                  id: "specsrelay-clarification",
                  order: 42,
                  inject: (sessionId) => ({
                    dshDesktop: isDshDesktop,
                    desktopTopInset,
                    sessionId,
                    draftClarification: (sourceId, projectPath, prompt) =>
                      loadClarificationDraft(ctx, sourceId, projectPath, prompt),
                    getPendingQuestion: (sourceId) => pendingQuestionText(ctx, sourceId),
                    loadDraft: loadCurrent,
                    loadProjectDraft: loadProject,
                    openSession,
                    pickProject,
                    prepareProject
                  })
                },
                SpecsRelayClarificationShortcut
              )
            ),
          "specsrelay-deepseek: bidirectional clarification"
        );
      }

      return { apply, inject };
    }
  });
})();
