import * as React from 'react'
import type { Kind } from '../types.js'
import type { SettingsState } from './api.js'
import { projectLabel } from './api.js'
import { EmptyState, MemoryCard, PixelIcon, displayName, memoryKindLabels } from './components.js'

export function OverviewPanel({
  state,
  isBusy,
  newMemoryIds,
  onOpenMemories,
  onRetry,
}: {
  state: SettingsState
  isBusy: boolean
  newMemoryIds: Set<string>
  onOpenMemories: (kind?: Kind | 'all') => void
  onRetry: () => void
}) {
  const persona = state.personas.find((entry) => entry.id === state.scope.persona)
  const memories = state.memories.filter((memory) => memory.status === 'active')
  const latestMemories = memories
    .slice()
    .sort((left, right) => right.updatedAt.localeCompare(left.updatedAt))
    .slice(0, 3)
  const mood = state.mood
  const activeAliases = state.memories.filter((memory) => memory.status === 'active' && memory.alias)
  const latestAlias = (kind: string) =>
    activeAliases.filter((memory) => memory.alias!.kind === kind).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0]?.alias!.value
  const naming = { address: latestAlias('user_preferred'), name: latestAlias('assistant_name') }
  // A placeholder companion name gives way to the name she was given in conversation.
  const hasOwnName = displayName(persona?.name) === persona?.name
  const personaLines = state.persona
    ? Object.values(state.persona.sections).reduce((sum, lines) => sum + lines.length, 0) + state.traits.length
    : state.traits.length
  let moodText = '情绪表达已关闭'
  if (mood) moodText = mood.strength ? `${mood.strength}${mood.label}` : mood.label
  const failedJobs = state.jobs.filter((job) => job.status === 'failed').length
  const runningJobs = state.jobs.filter(
    (job) => job.status === 'pending' || job.status === 'running',
  ).length
  let learningStatus = '等待下一次对话'
  let learningTone: 'idle' | 'running' | 'failed' | 'paused' = 'idle'
  if (!state.settings.learning) {
    learningStatus = '暂时不记新的事'
    learningTone = 'paused'
  } else if (runningJobs > 0) {
    learningStatus = '正在回想刚才的事'
    learningTone = 'running'
  } else if (failedJobs > 0) {
    learningStatus = `有 ${failedJobs} 段对话没记下来`
    learningTone = 'failed'
  } else if (state.jobs.length > 0) {
    learningStatus = '刚才的事都记下了'
  }

  return (
    <div>
      <div className="fish-profile">
        <div className="fish-portrait-frame" data-mood={mood?.asset || 'calm'}>
          {/* All four portraits are present; only the current mood is shown, so a mood change
              switches instantly without reloading or flashing. */}
          {portraitMoods.map((asset) => (
            <img
              key={asset}
              className="fish-portrait"
              data-active={asset === (mood?.asset || 'calm') || undefined}
              src={`/fish-brain/assets/portrait-${asset}.png`}
              alt={asset === (mood?.asset || 'calm') ? portraitAlt[asset] : ''}
              aria-hidden={asset === (mood?.asset || 'calm') ? undefined : true}
              width="296"
              height="364"
              decoding="async"
            />
          ))}
        </div>
        <div className="fish-profile-info">
          <div className="fish-eyebrow">
            {state.scope.persona === state.activePersona ? '正在陪你' : '以前的她'}
          </div>
          <h2>{hasOwnName ? persona!.name : naming.name || displayName(undefined)}</h2>
          <span className="fish-status" data-off={!state.settings.enabled || undefined}>
            <i aria-hidden="true" />
            {state.settings.enabled ? '记得你' : '暂时不用记忆'}
          </span>
          <div className="fish-profile-divider" />
          <dl>
            <div>
              <dt>心情</dt>
              <dd className="fish-mood" data-mood={mood?.asset} data-off={!mood || undefined}>
                {moodText}
              </dd>
            </div>
            {mood?.reason && (
              <p className="fish-mood-reason">
                {mood.reason}
                {mood.layer === 'task' && mood.project && (
                  <small title={mood.project}> · {projectLabel(mood.project)}</small>
                )}
              </p>
            )}
            {hasOwnName && naming.name && naming.name !== persona?.name && (
              <div>
                <dt>你叫我</dt>
                <dd>{naming.name}</dd>
              </div>
            )}
            {naming.address && (
              <div>
                <dt>我叫你</dt>
                <dd>{naming.address}</dd>
              </div>
            )}
            <div>
              <dt>性格</dt>
              <dd>{personaLines} 条</dd>
            </div>
            <div>
              <dt title="现在打开着、由我陪着的对话">正在进行的对话</dt>
              <dd>{state.sessions.length} 个</dd>
            </div>
            <div>
              <dt>回想</dt>
              <dd className="fish-learning" data-tone={learningTone}>
                <i aria-hidden="true" />
                {learningStatus}
                {learningTone === 'failed' && (
                  <button
                    type="button"
                    className="fish-text-button"
                    disabled={isBusy}
                    onClick={onRetry}
                  >
                    再想想
                  </button>
                )}
              </dd>
            </div>
          </dl>
        </div>
      </div>
      <div className="fish-memory-counts" aria-label="记忆数量">
        {(Object.entries(memoryKindLabels) as [Kind, string][]).map(([kind, label]) => {
          const count = memories.filter((memory) => memory.kind === kind).length
          return (
            <button
              key={kind}
              type="button"
              className={`fish-counter fish-counter-${kind}`}
              onClick={() => onOpenMemories(kind)}
              aria-label={`${label} ${count} 条，查看`}
            >
              <span className="fish-counter-label">
                <PixelIcon name={kind} />
                {label}
              </span>
              <strong key={count}>{count}</strong>
            </button>
          )
        })}
      </div>
      <div className="fish-section-heading">
        <h3>最近记住的</h3>
        <button type="button" className="fish-text-button" onClick={() => onOpenMemories('all')}>
          全部记忆 <span aria-hidden="true">→</span>
        </button>
      </div>
      {latestMemories.length > 0 ? (
        latestMemories.map((memory, index) => (
          <MemoryCard
            key={memory.id}
            memory={memory}
            state={state}
            compact
            index={index}
            isNew={newMemoryIds.has(memory.id)}
          />
        ))
      ) : (
        <EmptyState title="还没有记住什么">聊过几次之后，我记住的事会出现在这里。</EmptyState>
      )}
      <PersonaFold state={state} />
    </div>
  )
}

const portraitMoods = ['calm', 'happy', 'discouraged', 'annoyed'] as const
const portraitAlt: Record<(typeof portraitMoods)[number], string> = {
  calm: '蓝发鲸鱼娘女仆，抱着笔记本微笑',
  happy: '蓝发鲸鱼娘女仆，笑着挥手',
  discouraged: '蓝发鲸鱼娘女仆，抱着尾巴有些低落',
  annoyed: '蓝发鲸鱼娘女仆，抱着手臂有点不满',
}

const sectionTitles: Record<string, string> = { self: '我是什么样的人', scenes: '我在不同场合', values: '我在意的事' }

/** "Who she is", with how much evidence stands behind each line and progress to the next synthesis. */
function PersonaFold({ state }: { state: SettingsState }) {
  const persona = state.persona
  const sections = persona ? (Object.entries(persona.sections) as [string, { text: string; evidence: string[] }[]][]) : []
  const filled = sections.filter(([, lines]) => lines.length > 0)
  const total = filled.reduce((sum, [, lines]) => sum + lines.length, 0) + state.traits.length
  const latest = persona?.history[0]
  return (
    <details className="fish-fold fish-persona">
      <summary>
        我是什么样的人 <span>{total} 条</span>
      </summary>
      <div className="fish-fold-body">
        {filled.map(([section, lines]) => (
          <section key={section} className="fish-persona-section">
            <h4>{sectionTitles[section]}</h4>
            {lines.map((line, index) => (
              <p key={index} className="fish-trait">
                {line.text}
                <small>{line.evidence.length ? `${line.evidence.length} 次观察` : '初始设定'}</small>
              </p>
            ))}
          </section>
        ))}
        {state.traits.length > 0 && (
          <section className="fish-persona-section">
            <h4>稳定倾向</h4>
            {state.traits.map((trait) => (
              <p key={trait.id} className="fish-trait">{trait.text}</p>
            ))}
          </section>
        )}
        {total === 0 && (
          <p className="fish-muted">还没有形成。我的表现和你的反馈会先攒成印象，在不同场合或好几天里都是这样，才会写进这里。</p>
        )}
        {persona && (
          <p className="fish-muted fish-persona-progress">
            攒着的新印象 {persona.pending} / {persona.threshold}
            {persona.lastSynthesisAt ? ` · 上次回想 ${persona.lastSynthesisAt.slice(0, 10)}` : ' · 还没回想过'}
            {typeof state.selfCount === 'number' && ` · 对自己的观察 ${state.selfCount}/${state.selfLimit}`}
          </p>
        )}
        {latest && (latest.diff.added.length > 0 || latest.diff.updated.length > 0) && (
          <p className="fish-muted">
            最近的变化：
            {[...latest.diff.added.map((text) => `新增「${text}」`), ...latest.diff.updated.map((entry) => `「${entry.from}」→「${entry.to}」`)].join('；')}
          </p>
        )}
      </div>
    </details>
  )
}
