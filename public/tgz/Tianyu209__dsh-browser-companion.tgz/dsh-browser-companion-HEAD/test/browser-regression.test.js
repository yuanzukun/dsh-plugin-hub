import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import os from 'node:os'
import path from 'node:path'
import fs from 'node:fs'
import { runAgentBrowser, isBrowserRunning } from '../src/index.js'

const profilePath = path.join(os.tmpdir(), `dsh-browser-regression-${Date.now()}`)
const config = {
  profilePath,
  headless: true,
  defaultTimeout: 30000,
  agentBrowserPath: '',
  executablePath: '',
  browserArgs: '--disable-blink-features=AutomationControlled',
  visionBaseUrl: 'http://127.0.0.1:1234/v1',
  visionModel: 'your-vision-model',
}

before(async () => {
  fs.mkdirSync(profilePath, { recursive: true })
  await runAgentBrowser(['open', 'https://example.com'], config, undefined)
})

after(async () => {
  try {
    await runAgentBrowser(['close'], config, undefined, { json: false, headed: false })
  } catch {
    // ignore
  }
  fs.rmSync(profilePath, { recursive: true, force: true })
})

test('browser is open and readable after before hook', async () => {
  assert.equal(await isBrowserRunning(config, undefined), true, 'should be running after before hook')

  const urlData = await runAgentBrowser(['get', 'url'], config, undefined, { headed: false })
  assert.match(String(urlData?.url ?? ''), /example\.com/, 'should be on example.com')
})

test('browser close really closes and read-only stays closed', async () => {
  await runAgentBrowser(['close'], config, undefined, { json: false, headed: false })
  assert.equal(await isBrowserRunning(config, undefined), false, 'should be closed after close')

  // 只读工具不应重新拉起浏览器
  assert.equal(await isBrowserRunning(config, undefined), false, 'should still be closed')
})
