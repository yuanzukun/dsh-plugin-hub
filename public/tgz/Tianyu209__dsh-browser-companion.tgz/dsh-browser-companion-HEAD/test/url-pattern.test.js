import { test } from 'node:test'
import assert from 'node:assert/strict'
import { matchUrlPattern } from '../src/url-pattern.js'

test('matchUrlPattern: exact match', () => {
  assert.equal(matchUrlPattern('https://example.com/dashboard', 'https://example.com/dashboard'), true)
  assert.equal(matchUrlPattern('https://example.com/dashboard', 'https://example.com/home'), false)
})

test('matchUrlPattern: ** wildcard', () => {
  assert.equal(matchUrlPattern('https://example.com/a/b/c', 'https://example.com/**'), true)
  assert.equal(matchUrlPattern('https://example.com', 'https://example.com/**'), false)
})

test('matchUrlPattern: * wildcard within a path segment', () => {
  assert.equal(matchUrlPattern('https://example.com/dashboard', 'https://example.com/*'), true)
  assert.equal(matchUrlPattern('https://example.com/a/b', 'https://example.com/*'), false)
})

test('matchUrlPattern: empty pattern means match anything', () => {
  assert.equal(matchUrlPattern('https://anything.example', ''), true)
  assert.equal(matchUrlPattern('https://anything.example', undefined), true)
})
