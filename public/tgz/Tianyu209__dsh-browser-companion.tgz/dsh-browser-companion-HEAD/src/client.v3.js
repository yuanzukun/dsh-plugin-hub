window.__ModuleLoader__.load({
  id: 'dsh-browser-companion',
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });

    let React = require('react');

    const NS = 'dsh-browser-companion';
    const API = '/api/dsh-browser-companion/settings';

    const FIELD_DEFS = [
      { key: 'profilePath', label: 'Profile Path', hint: 'Persistent browser profile directory' },
      { key: 'headless', label: 'Headless', hint: 'Hide browser window (true/false)' },
      { key: 'defaultTimeout', label: 'Default Timeout (ms)', hint: 'Per-operation timeout' },
      { key: 'agentBrowserPath', label: 'Agent Browser Path', hint: 'Optional override for agent-browser CLI' },
      { key: 'executablePath', label: 'Chrome/Edge Path', hint: 'Set to your real browser to avoid login blocks' },
      { key: 'browserArgs', label: 'Browser Args', hint: 'Extra Chrome launch arguments' },
      { key: 'visionBaseUrl', label: 'Vision Base URL', hint: 'Local vision model endpoint' },
      { key: 'visionModel', label: 'Vision Model', hint: 'Local vision model name' },
    ];

    function SettingsCard() {
      const [values, setValues] = React.useState(null);
      const [draft, setDraft] = React.useState({});
      const [status, setStatus] = React.useState('idle'); // idle | saving | saved | error
      const [open, setOpen] = React.useState(false);

      React.useEffect(() => {
        let cancelled = false;
        fetch(API)
          .then((r) => r.json())
          .then((data) => {
            if (cancelled) return;
            const v = data.values || {};
            setValues(v);
            setDraft(v);
          })
          .catch((err) => {
            console.warn('[dsh-browser-companion] failed to load settings:', err);
            if (!cancelled) setValues({});
          });
        return () => { cancelled = true; };
      }, []);

      if (values === null) {
        return React.createElement('li', { style: cardStyle() },
          React.createElement('div', { style: { padding: 12 } }, 'Loading dsh-browser-companion settings...')
        );
      }

      const dirty = JSON.stringify(draft) !== JSON.stringify(values);
      const save = async () => {
        if (status === 'saving') return;
        setStatus('saving');
        try {
          const res = await fetch(API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(draft),
          });
          const data = await res.json();
          if (!res.ok || !data.ok) throw new Error(data.error || 'save failed');
          setValues(data.values || draft);
          setDraft(data.values || draft);
          setStatus('saved');
          setTimeout(() => setStatus('idle'), 2000);
        } catch (err) {
          console.warn('[dsh-browser-companion] failed to save settings:', err);
          setStatus('error');
          setTimeout(() => setStatus('idle'), 3000);
        }
      };

      const discard = () => {
        setDraft(values);
        setStatus('idle');
      };

      const title = 'dsh-browser-companion';
      const description = 'Agent browser settings';
      const blocked = !dirty || status === 'saving';

      return React.createElement('li', { style: cardStyle() },
        React.createElement('button', {
          type: 'button',
          style: headerStyle(),
          onClick: () => setOpen(!open),
        },
          React.createElement('span', null,
            React.createElement('span', { style: { fontWeight: 600 } }, title),
            React.createElement('span', { style: { display: 'block', fontSize: 13, opacity: 0.7 } }, description)
          ),
          React.createElement('span', null, open ? '▴' : '▾')
        ),
        open ? React.createElement('div', { style: bodyStyle() },
          FIELD_DEFS.map((def) => {
            const value = draft[def.key] ?? '';
            return React.createElement('div', { key: def.key, style: fieldStyle() },
              React.createElement('label', { style: labelStyle() }, def.label),
              React.createElement('input', {
                type: 'text',
                style: inputStyle(),
                value: String(value),
                onChange: (e) => setDraft((prev) => ({ ...prev, [def.key]: e.target.value })),
              }),
              React.createElement('div', { style: hintStyle() }, def.hint)
            );
          }),
          status === 'saved'
            ? React.createElement('div', { style: { color: '#0a0', marginBottom: 8 } }, 'Saved ✓')
            : null,
          status === 'error'
            ? React.createElement('div', { style: { color: '#c00', marginBottom: 8 } }, 'Save failed. Please try again.')
            : null,
          React.createElement('div', { style: footerStyle() },
            React.createElement('button', {
              type: 'button',
              disabled: !dirty || status === 'saving',
              onClick: discard,
            }, 'Discard'),
            React.createElement('button', {
              type: 'button',
              disabled: blocked,
              onClick: save,
            }, status === 'saving' ? 'Saving…' : status === 'saved' ? 'Saved ✓' : 'Save')
          )
        ) : null
      );
    }

    function cardStyle() {
      return {
        border: '1px solid var(--dsw-alias-border-l2, #ccc)',
        background: 'var(--dsw-alias-bg-layer-2, #fff)',
        borderRadius: 6,
        listStyle: 'none',
        marginBottom: 8,
        overflow: 'hidden',
      };
    }
    function headerStyle() {
      return {
        width: '100%',
        textAlign: 'left',
        padding: '10px 12px',
        cursor: 'pointer',
        background: 'none',
        border: 'none',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        font: 'inherit',
        color: 'inherit',
      };
    }
    function bodyStyle() {
      return { padding: '2px 12px 12px', borderTop: '1px solid var(--dsw-alias-border-l2, #eee)' };
    }
    function fieldStyle() { return { marginBottom: 10 }; }
    function labelStyle() { return { display: 'block', fontWeight: 600, marginBottom: 4 }; }
    function inputStyle() { return { width: '100%', boxSizing: 'border-box', padding: '6px 8px' }; }
    function hintStyle() { return { fontSize: 12, opacity: 0.7, marginTop: 2 }; }
    function footerStyle() { return { display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8 }; }

    const inject = ['slots', 'locale'];

    function apply(ctx) {
      try {
        ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
          name: 'settings.plugin.item',
          id: 'dsh-browser-companion',
          order: 80,
          locale: NS,
        }, SettingsCard));
      } catch (err) {
        console.warn('[dsh-browser-companion] failed to mount settings card:', err);
      }
    }

    exports.apply = apply;
    exports.inject = inject;
    return module.exports;
  }
});
