export function matchUrlPattern(url, pattern) {
  if (!pattern) return true
  if (pattern === url) return true
  // 支持简单的 ** 通配符
  const escaped = pattern
    .replace(/[.+?^${}()|[\]\\]/g, '\\$&')
    .replace(/\*\*/g, '___DOUBLE_STAR___')
    .replace(/\*/g, '[^/]*')
    .replace(/___DOUBLE_STAR___/g, '.*')
  return new RegExp(`^${escaped}$`).test(url)
}
