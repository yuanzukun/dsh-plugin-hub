import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { createRequire } from 'node:module'
import path from 'node:path'
import os from 'node:os'
import fs from 'node:fs'
import { createHash } from 'node:crypto'

import { defineTool } from '@deepseek-ai/dsh-tools'
import Schema from '@deepseek-ai/schemastery'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'

import { matchUrlPattern } from './url-pattern.js'

const execFileAsync = promisify(execFile)
const require = createRequire(import.meta.url)

export const name = 'dsh-browser-companion'
export const inject = ['tools', 'webServer']

export const Config = Schema.object({
  /** 持久化浏览器 profile 目录，Cookies/登录态都保存在这里 */
  profilePath: Schema.string().default(path.join(os.homedir(), '.dsh', 'browser-profile')),
  /** 是否显示浏览器窗口。个人使用建议保持 false（即显示窗口） */
  headless: Schema.boolean().default(false),
  /** 单次操作的默认超时（毫秒） */
  defaultTimeout: Schema.number().default(30000),
  /** 可选：agent-browser CLI 的绝对路径，通常不需要手动设置 */
  agentBrowserPath: Schema.string().default(''),
  /** 可选：指定 Chrome/Edge 可执行文件路径，解决 Google 等站点“此浏览器或应用可能不安全”的拦截 */
  executablePath: Schema.string().default(''),
  /** 可选：传给浏览器的额外启动参数，逗号分隔。默认隐藏自动化标记 */
  browserArgs: Schema.string().default('--disable-blink-features=AutomationControlled'),
  /** 本地视觉模型地址（OpenAI 兼容），用于 browser_see 让 Agent“看”页面 */
  visionBaseUrl: Schema.string().default('http://127.0.0.1:1234/v1'),
  /** 本地视觉模型名称，请在 examples 中按你的环境配置 */
  visionModel: Schema.string().default('your-vision-model'),
})

function getSession(config) {
  const hash = createHash('sha1').update(config.profilePath || '').digest('hex').slice(0, 8)
  return `dsh-browser-companion-${hash}`
}
export const BROWSER_SETTINGS_NAMESPACE = settingsNamespace('dsh-browser-companion')


// 这段旧逻辑用 settings.yaml 手写 web_settings_namespaces，已改用 dsh-settings 的
// installSettingsSection，不再需要。用 // 逐行注释（不能再用 /* */ 块注释：
// 函数内的正则如 /^\s*/ 自带 */ 会把块注释提前截断，导致语法错误）。
//
// function ensureWebSettingsNamespace() {
//   const file = path.join(os.homedir(), '.dsh', 'settings.yaml')
//   let text = ''
//   try {
//     text = fs.readFileSync(file, 'utf8')
//   } catch {
//     return
//   }
//   if (text.includes('dsh-browser-companion')) return
//
//   const lines = text.split(/\r?\n/)
//   let inserted = false
//   for (let i = 0; i < lines.length; i++) {
//     if (/^\s*web_settings_namespaces\s*:\s*$/.test(lines[i])) {
//       const indent = (lines[i].match(/^\s*/) || [''])[0] + '  '
//       let j = i + 1
//       while (j < lines.length && (/^\s+/.test(lines[j]) || lines[j].trim() === '')) {
//         if (/^\s*-\s*/.test(lines[j]) && lines[j].includes('dsh-browser-companion')) return
//         j++
//       }
//       lines.splice(j, 0, `${indent}- dsh-browser-companion`)
//       inserted = true
//       break
//     }
//   }
//
//   if (!inserted) {
//     if (text.trim() !== '' && !text.endsWith('\n')) text += '\n'
//     text += `\nweb_settings_namespaces:\n  - dsh-browser-companion\n`
//   } else {
//     text = lines.join('\n')
//   }
//
//   try {
//     fs.writeFileSync(file, text, 'utf8')
//   } catch (err) {
//     console.warn('[dsh-browser-companion] could not update settings.yaml:', err)
//   }
// }


function browserConfigPath() {
  return path.join(os.homedir(), '.dsh', 'dsh-browser-companion.json')
}

function readSavedBrowserConfig() {
  try {
    const parsed = JSON.parse(fs.readFileSync(browserConfigPath(), 'utf8')) || {}
    const cleaned = {}
    for (const [key, value] of Object.entries(parsed)) {
      if (value === '' || value === null || value === undefined) continue
      cleaned[key] = typeof value === 'string' ? value.trim() : value
    }
    return cleaned
  } catch {
    return {}
  }
}

function writeSavedBrowserConfig(obj) {
  fs.mkdirSync(path.dirname(browserConfigPath()), { recursive: true })
  fs.writeFileSync(browserConfigPath(), JSON.stringify(obj, null, 2), 'utf8')
}

export async function isBrowserRunning(config, exec) {
  try {
    const data = await runAgentBrowser(['session', 'list'], config, exec, { headed: false })
    const sessions = Array.isArray(data) ? data : (data?.sessions ?? data?.active ?? [])
    return JSON.stringify(sessions).includes(getSession(config))
  } catch {
    return false
  }
}


function isLoopbackRequest(request) {
  const address = request.socket?.remoteAddress
  if (address !== '127.0.0.1' && address !== '::1' && address !== '::ffff:127.0.0.1') return false
  const host = request.headers?.host
  if (typeof host !== 'string') return false
  let hostUrl
  try {
    hostUrl = new URL(`http://${host}`)
  } catch {
    return false
  }
  if (hostUrl.hostname !== '127.0.0.1' && hostUrl.hostname !== 'localhost' && hostUrl.hostname !== '[::1]') return false
  if (request.headers?.['sec-fetch-site'] === 'cross-site') return false
  const origin = request.headers?.origin
  if (origin === undefined) return true
  try {
    return new URL(origin).host === hostUrl.host
  } catch {
    return false
  }
}

function writeJson(res, status, body) {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'referrer-policy': 'no-referrer' })
  res.end(payload)
}

async function readJsonBody(req) {
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    const buffer = chunk
    size += buffer.length
    if (size > 64 * 1024) return undefined
    chunks.push(buffer)
  }
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    return typeof parsed === 'object' && parsed !== null ? parsed : undefined
  } catch {
    return undefined
  }
}



function resolveAgentBrowserCli(config) {
  if (config.agentBrowserPath) {
    if (!fs.existsSync(config.agentBrowserPath)) {
      throw new Error(`agentBrowserPath 不存在: ${config.agentBrowserPath}`)
    }
    return config.agentBrowserPath
  }

  try {
    const pkgPath = require.resolve('agent-browser/package.json')
    const candidate = path.join(path.dirname(pkgPath), 'bin', 'agent-browser.js')
    if (fs.existsSync(candidate)) return candidate
  } catch {
    // ignore
  }

  const candidates = []
  if (process.env.APPDATA) {
    candidates.push(path.join(process.env.APPDATA, 'npm', 'node_modules', 'agent-browser', 'bin', 'agent-browser.js'))
  }
  candidates.push(path.join(os.homedir(), 'AppData', 'Roaming', 'npm', 'node_modules', 'agent-browser', 'bin', 'agent-browser.js'))
  candidates.push(path.join(os.homedir(), '.npm-global', 'node_modules', 'agent-browser', 'bin', 'agent-browser.js'))

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) return candidate
  }

  throw new Error(
    '找不到 agent-browser。请先安装: npm install -g agent-browser 或在插件配置里指定 agentBrowserPath。'
  )
}

export function baseArgs(config, { headed = true } = {}) {
  const args = [
    '--session', getSession(config),
    '--profile', config.profilePath,
  ]
  // 保持可见窗口：只要不是 headless，所有 agent-browser 命令都带 --headed，
  // 避免后续命令（如 status/get url）把已弹出的窗口切走或关闭。
  // 但 close 等特殊命令可以传 headed: false 来真正关闭窗口。
  if (!config.headless && headed) {
    args.push('--headed')
  }
  if (config.executablePath) {
    args.push('--executable-path', config.executablePath)
  }
  if (config.browserArgs) {
    args.push('--args', config.browserArgs)
  }
  return args
}

function parseAgentBrowserOutput(stdout) {
  const text = String(stdout || '').trim()
  if (!text) return {}
  try {
    const parsed = JSON.parse(text)
    if (parsed && typeof parsed === 'object' && 'success' in parsed) {
      if (parsed.success === false) {
        throw new Error(parsed.error || parsed.message || 'agent-browser command failed')
      }
      return parsed.data ?? {}
    }
    return parsed
  } catch (err) {
    if (err instanceof SyntaxError) {
      return { raw: text }
    }
    throw err
  }
}

export async function runAgentBrowser(args, config, exec, { json = true, headed = true } = {}) {
  const cli = resolveAgentBrowserCli(config)
  const fullArgs = [...baseArgs(config, { headed }), ...args]

  if (json && !(args[0] === 'tab' && args[1] === 'close') && !fullArgs.includes('--json')) {
    fullArgs.push('--json')
  }

  const timeout = (config.defaultTimeout || 30000) + 15000
  try {
    const { stdout } = await execFileAsync(process.execPath, [cli, ...fullArgs], {
      timeout,
      maxBuffer: 20 * 1024 * 1024,
      windowsHide: false,
      signal: exec?.signal,
      env: {
        ...process.env,
        AGENT_BROWSER_SESSION: getSession(config),
        AGENT_BROWSER_PROFILE: config.profilePath,
      },
    })
    return parseAgentBrowserOutput(stdout)
  } catch (err) {
    const stderr = err?.stderr ? String(err.stderr) : ''
    const message = stderr || err?.message || 'agent-browser 执行失败'
    throw new Error(`browser error: ${message}`)
  }
}

const stringOutput = {
  schema: { type: 'string' },
  render: (_args, value) => [{ type: 'text', text: String(value) }],
}

async function describeScreenshot(config, imagePath, question) {
  if (!config.visionModel || config.visionModel === 'your-vision-model') {
    return 'browser_see 需要先在设置中配置 visionBaseUrl 和 visionModel（本地视觉模型）。基础浏览功能不受影响。'
  }

  try {
    const base64 = fs.readFileSync(imagePath).toString('base64')
    const dataUrl = `data:image/png;base64,${base64}`
    const payload = {
      model: config.visionModel,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: question || '请描述这个网页页面的主要内容，包括关键信息和可操作元素。' },
            { type: 'image_url', image_url: { url: dataUrl } },
          ],
        },
      ],
      max_tokens: 1024,
    }

    const response = await fetch(`${config.visionBaseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      return `视觉模型请求失败: ${response.status} ${await response.text()}`
    }

    const data = await response.json()
    return data?.choices?.[0]?.message?.content || '(视觉模型没有返回内容)'
  } catch (err) {
    return `browser_see 调用视觉模型失败：${err.message}。请在设置中检查 visionBaseUrl / visionModel。`
  }
}

export function apply(ctx, baseConfig) {
  const config = { ...baseConfig }
  Object.assign(config, readSavedBrowserConfig())

  fs.mkdirSync(config.profilePath, { recursive: true })


  if (ctx.webServer) {
    // 注意：dsh webserver 的 register 按 path 去重（不区分 method），
    // 同一个 path 的 GET/POST 必须合并成一条路由，在 handler 内按 req.method 分发，
    // 否则会报 duplicate route。kind 传 'exact' 表示精确匹配。
    ctx.webServer.register({
      kind: 'exact',
      path: '/api/dsh-browser-companion/settings',
      handler: async (req, res) => {
        if (!isLoopbackRequest(req)) return writeJson(res, 403, { error: 'forbidden: loopback-only' })
        if (req.method === 'POST') {
          const body = await readJsonBody(req)
          if (!body) return writeJson(res, 400, { error: 'invalid json' })
          writeSavedBrowserConfig(body)
          Object.assign(config, body)
          return writeJson(res, 200, { ok: true, values: { ...baseConfig, ...readSavedBrowserConfig() } })
        }
        const saved = readSavedBrowserConfig()
        writeJson(res, 200, { values: { ...baseConfig, ...saved }, saved })
      },
    })
  }



  installSettingsSection(ctx, BROWSER_SETTINGS_NAMESPACE, Config, config, {
    setSource: (source) => {
      Object.assign(config, source())
    },
    onChange: () => {},
  })

  ctx.tools.register(defineTool({
    name: 'browser_open',
    description: '打开（或切换到）一个网页。此操作会弹出一个可见的浏览器窗口（默认 headless=false），用户可以直接看到。如果长时间没有窗口弹出，请先调用 browser_status 检查，或确认设置中 headless 为 false。',
    parameters: {
      url: { type: 'string', required: true, description: '要打开的完整 URL，例如 https://example.com' },
      waitUntil: { type: 'string', description: '等待页面加载完成的状态：load / domcontentloaded / networkidle，默认 domcontentloaded' },
    },
    output: stringOutput,
    async execute(args, exec) {
      const headed = config.headless ? [] : ['--headed']
      const data = await runAgentBrowser(['open', args.url], config, exec)
      if (args.waitUntil && args.waitUntil !== 'domcontentloaded') {
        await runAgentBrowser(['wait', '--load', args.waitUntil], config, exec)
      }
      const url = data?.url || args.url
      return `已打开 ${url}\n标题: ${data?.title || '(未知)'}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_snapshot',
    description: '获取当前页面的可访问性快照（带 @e1、@e2 这样的元素引用），供 Agent 决定下一步点击/输入哪个元素。',
    parameters: {
      interactive: { type: 'boolean', description: '只显示可交互元素，默认 true' },
      compact: { type: 'boolean', description: '压缩空白结构，默认 true' },
      maxDepth: { type: 'number', description: '快照最大深度，默认 8' },
    },
    output: stringOutput,
    async execute(args, exec) {
      if (!(await isBrowserRunning(config, exec))) return '浏览器当前未打开'

      const interactive = args.interactive !== false
      const compact = args.compact !== false
      const depth = args.maxDepth ?? 8
      const data = await runAgentBrowser(
        ['snapshot', interactive ? '-i' : '', compact ? '-c' : '', '--depth', String(depth)].filter(Boolean),
        config,
        exec
      )
      const tree = data?.snapshot ?? data?.tree ?? data?.raw ?? ''
      if (!tree) return '(快照为空)'
      return `当前页面快照:\n${tree}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_click',
    description: '点击页面元素。selector 可以是快照里的 @e1 引用，也可以是 CSS 选择器。',
    parameters: {
      selector: { type: 'string', required: true, description: '例如 @e3 或 #submit' },
      button: { type: 'string', description: '鼠标按键：left / right / middle，默认 left' },
      newTab: { type: 'boolean', description: '是否在新标签页打开，默认 false' },
    },
    output: stringOutput,
    async execute(args, exec) {
      const clickArgs = ['click', args.selector]
      if (args.button) clickArgs.push('--button', args.button)
      if (args.newTab) clickArgs.push('--new-tab')
      await runAgentBrowser(clickArgs, config, exec)
      return `已点击 ${args.selector}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_type',
    description: '在输入框里输入文字。注意：不要用这个工具填写密码框；密码/密钥请让用户在弹出的浏览器窗口中手动输入。',
    parameters: {
      selector: { type: 'string', required: true, description: '例如 @e5 或 input[name="q"]' },
      text: { type: 'string', required: true, description: '要输入的文字' },
      mode: { type: 'string', description: 'fill=直接填入（默认），type=模拟键盘输入' },
      clear: { type: 'boolean', description: '输入前是否清空，默认 true' },
    },
    output: stringOutput,
    async execute(args, exec) {
      try {
        const attr = await runAgentBrowser(['get', 'attr', args.selector, 'type'], config, exec)
        const fieldType = String(attr?.value ?? attr?.attribute ?? attr?.raw ?? '').toLowerCase()
        if (fieldType === 'password') {
          throw new Error('检测到密码框：Agent 不能填写密码/密钥，请由用户在浏览器弹窗中手动登录。')
        }
      } catch (err) {
        if (err instanceof Error && err.message.includes('密码框')) throw err
      }

      const mode = args.mode || 'fill'
      const clear = args.clear !== false
      if (mode === 'type') {
        const typeArgs = ['type', args.selector, args.text]
        if (clear) typeArgs.push('--clear')
        await runAgentBrowser(typeArgs, config, exec)
      } else {
        await runAgentBrowser(['fill', args.selector, args.text], config, exec)
      }
      return `已在 ${args.selector} 输入文字`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_press',
    description: '在当前页面按下键盘按键，例如 Enter、Tab、Escape、Control+a。',
    parameters: {
      key: { type: 'string', required: true, description: '按键名，例如 Enter' },
    },
    output: stringOutput,
    async execute(args, exec) {
      await runAgentBrowser(['press', args.key], config, exec)
      return `已按下 ${args.key}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_screenshot',
    description: '对当前页面截图，保存到本地并返回图片路径。',
    parameters: {
      fullPage: { type: 'boolean', description: '是否截整页，默认 false' },
      name: { type: 'string', description: '截图文件名（不含扩展名），默认自动生成时间戳' },
    },
    output: stringOutput,
    async execute(args, exec) {
      if (!(await isBrowserRunning(config, exec))) return '浏览器当前未打开'

      const dir = path.join(os.homedir(), '.dsh', 'browser-screenshots')
      fs.mkdirSync(dir, { recursive: true })
      const name = args.name || `shot-${Date.now()}`
      const file = path.join(dir, `${name}.png`)
      const shotArgs = ['screenshot', file]
      if (args.fullPage) shotArgs.push('--full')
      await runAgentBrowser(shotArgs, config, exec)
      return `截图已保存: ${file}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_see',
    description: '截取当前页面并用本地视觉模型“看”一眼，返回对页面的文字描述。仅在需要理解图片/视觉布局/复杂界面时使用；平时应优先用 browser_snapshot（更快更便宜）。',
    parameters: {
      question: { type: 'string', description: '可选：你想让视觉模型重点看什么' },
      fullPage: { type: 'boolean', description: '是否截整页，默认 false' },
    },
    output: stringOutput,
    async execute(args, exec) {
        if (!config.visionModel || config.visionModel === 'your-vision-model') {
          return 'browser_see 需要先在设置中配置 visionBaseUrl 和 visionModel（本地视觉模型）。基础浏览功能不受影响。'
        }
      if (!(await isBrowserRunning(config, exec))) return '浏览器当前未打开'


      const dir = path.join(os.homedir(), '.dsh', 'browser-screenshots')
      fs.mkdirSync(dir, { recursive: true })
      const file = path.join(dir, `pic-${Date.now()}.png`)
      const shotArgs = ['screenshot', file]
      if (args.fullPage) shotArgs.push('--full')
      await runAgentBrowser(shotArgs, config, exec)
      const description = await describeScreenshot(config, file, args.question)
      return `页面描述：\n${description}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_get_text',
    description: '获取页面中某个元素的文本内容。',
    parameters: {
      selector: { type: 'string', required: true, description: '例如 @e2 或 .content' },
    },
    output: stringOutput,
    async execute(args, exec) {
      if (!(await isBrowserRunning(config, exec))) return '浏览器当前未打开'

      const data = await runAgentBrowser(['get', 'text', args.selector], config, exec)
      const text = data?.text ?? data?.value ?? data?.raw ?? ''
      return String(text)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_get_url',
    description: '获取当前页面的 URL。',
    parameters: {},
    output: stringOutput,
    async execute(_args, exec) {
      if (!(await isBrowserRunning(config, exec))) return '浏览器当前未打开'
      const data = await runAgentBrowser(['get', 'url'], config, exec)
      return String(data?.url ?? data?.value ?? data?.raw ?? '')
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_get_title',
    description: '获取当前页面的标题。',
    parameters: {},
    output: stringOutput,
    async execute(_args, exec) {
      if (!(await isBrowserRunning(config, exec))) return '浏览器当前未打开'
      const data = await runAgentBrowser(['get', 'title'], config, exec)
      return String(data?.title ?? data?.value ?? data?.raw ?? '')
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_wait',
    description: '等待页面状态：可以等待固定毫秒、等待某个元素出现、或等待 URL 匹配。',
    parameters: {
      ms: { type: 'number', description: '等待毫秒数' },
      selector: { type: 'string', description: '等待该元素可见' },
      url: { type: 'string', description: '等待 URL 匹配该模式，例如 **/dashboard' },
      timeout: { type: 'number', description: '超时毫秒，默认使用插件 defaultTimeout' },
    },
    output: stringOutput,
    async execute(args, exec) {
      const timeout = args.timeout ?? config.defaultTimeout ?? 30000
      if (args.selector) {
        await runAgentBrowser(['wait', args.selector, '--timeout', String(timeout)], config, exec)
        return `已等到元素: ${args.selector}`
      }
      if (args.url) {
        await runAgentBrowser(['wait', '--url', args.url, '--timeout', String(timeout)], config, exec)
        return `已等到 URL: ${args.url}`
      }
      const ms = args.ms ?? 1000
      await new Promise((resolve) => setTimeout(resolve, ms))
      return `已等待 ${ms}ms`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_back',
    description: '后退到上一页。',
    parameters: {},
    output: stringOutput,
    async execute(_args, exec) {
      await runAgentBrowser(['back'], config, exec)
      return '已后退'
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_forward',
    description: '前进到下一页。',
    parameters: {},
    output: stringOutput,
    async execute(_args, exec) {
      await runAgentBrowser(['forward'], config, exec)
      return '已前进'
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_reload',
    description: '刷新当前页面。',
    parameters: {},
    output: stringOutput,
    async execute(_args, exec) {
      await runAgentBrowser(['reload'], config, exec)
      return '已刷新'
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_select',
    description: '选择下拉框选项。',
    parameters: {
      selector: { type: 'string', required: true, description: '下拉框元素，例如 @e3 或 select#country' },
      value: { type: 'string', required: true, description: '要选择的 option 值或文本' },
    },
    output: stringOutput,
    async execute(args, exec) {
      await runAgentBrowser(['select', args.selector, args.value], config, exec)
      return `已选择 ${args.value}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_check',
    description: '勾选复选框。',
    parameters: {
      selector: { type: 'string', required: true, description: '复选框元素' },
    },
    output: stringOutput,
    async execute(args, exec) {
      await runAgentBrowser(['check', args.selector], config, exec)
      return `已勾选 ${args.selector}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_uncheck',
    description: '取消勾选复选框。',
    parameters: {
      selector: { type: 'string', required: true, description: '复选框元素' },
    },
    output: stringOutput,
    async execute(args, exec) {
      await runAgentBrowser(['uncheck', args.selector], config, exec)
      return `已取消勾选 ${args.selector}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_upload',
    description: '上传文件到页面中的文件输入框。',
    parameters: {
      selector: { type: 'string', required: true, description: '文件输入框元素' },
      files: { type: 'string', required: true, description: '文件路径，多个用逗号分隔' },
    },
    output: stringOutput,
    async execute(args, exec) {
      const files = args.files.split(',').map((s) => s.trim()).filter(Boolean)
      await runAgentBrowser(['upload', args.selector, ...files], config, exec)
      return `已上传 ${files.length} 个文件`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_hover',
    description: '鼠标悬停到某个元素上。',
    parameters: {
      selector: { type: 'string', required: true, description: '要悬停的元素' },
    },
    output: stringOutput,
    async execute(args, exec) {
      await runAgentBrowser(['hover', args.selector], config, exec)
      return `已悬停 ${args.selector}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_scroll',
    description: '滚动页面。direction 为 up / down / left / right，px 为像素数。',
    parameters: {
      direction: { type: 'string', required: true, description: 'up / down / left / right' },
      px: { type: 'number', description: '像素数，默认 500' },
      selector: { type: 'string', description: '可选：滚动指定元素' },
    },
    output: stringOutput,
    async execute(args, exec) {
      const px = args.px ?? 500
      const scrollArgs = ['scroll', args.direction, String(px)]
      if (args.selector) scrollArgs.push('--selector', args.selector)
      await runAgentBrowser(scrollArgs, config, exec)
      return `已${args.direction}滚动 ${px}px`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_tabs',
    description: '列出当前浏览器的所有标签页。',
    parameters: {},
    output: stringOutput,
    async execute(_args, exec) {
      if (!(await isBrowserRunning(config, exec))) return '浏览器当前未打开'

      const data = await runAgentBrowser(['tab'], config, exec)
      const tabs = data?.tabs ?? data?.pages ?? data?.raw ?? data
      if (Array.isArray(tabs)) {
        return tabs.map((t, i) => `[${t.id || t.tabId || t.label || i}] ${t.title || ''} ${t.url || ''}`).join('\n') || '(没有标签页)'
      }
      return typeof tabs === 'string' ? tabs : JSON.stringify(tabs, null, 2)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_new_tab',
    description: '新建一个标签页，可选择打开 URL。',
    parameters: {
      url: { type: 'string', description: '可选：新标签页要打开的 URL' },
    },
    output: stringOutput,
    async execute(args, exec) {
      const tabArgs = ['tab', 'new']
      if (args.url) tabArgs.push(args.url)
      await runAgentBrowser(tabArgs, config, exec)
      return args.url ? `已新建标签页并打开 ${args.url}` : '已新建标签页'
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_close_tab',
    description: '关闭指定标签页，默认关闭当前标签页。',
    parameters: {
      tab: { type: 'string', description: '要关闭的标签页 ID（如 t1）或标签名；不填则关闭当前' },
    },
    output: stringOutput,
    async execute(args, exec) {
      const tabArgs = ['tab', 'close']
      if (args.tab) tabArgs.push(args.tab)
      try {
        await runAgentBrowser(tabArgs, config, exec)
        return args.tab ? `已关闭标签页 ${args.tab}` : '已关闭当前标签页'
      } catch (err) {
        // agent-browser 关闭成功后有时会报 not found，实际已关闭
        const msg = err?.message || ''
        if (args.tab && msg.includes('not found')) {
          const tabsData = await runAgentBrowser(['tab'], config, exec)
          const tabs = tabsData?.tabs ?? tabsData?.pages ?? []
          const stillExists = Array.isArray(tabs) && tabs.some((t) => (t.id || t.tabId) === args.tab)
          if (!stillExists) return `已关闭标签页 ${args.tab}`
        }
        throw err
      }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_switch_tab',
    description: '切换到指定标签页（用 t1/t2 或标签名）。',
    parameters: {
      tab: { type: 'string', required: true, description: '标签页 ID（如 t1）或标签名' },
    },
    output: stringOutput,
    async execute(args, exec) {
      await runAgentBrowser(['tab', args.tab], config, exec)
      return `已切换到标签页 ${args.tab}`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_status',
    description: '查看浏览器当前状态：是否打开、当前 URL、标题。此工具只读，不会启动或关闭浏览器。',
    parameters: {},
    output: stringOutput,
    async execute(_args, exec) {
      try {
          const sessionsData = await runAgentBrowser(['session', 'list'], config, exec, { headed: false })
          const sessions = Array.isArray(sessionsData)
            ? sessionsData
            : (sessionsData?.sessions ?? sessionsData?.active ?? [])
          const sessionText = JSON.stringify(sessions)
          const hasSession = sessionText.includes(SESSION)
          if (!hasSession) {
            return '浏览器当前未打开'
          }

        const urlData = await runAgentBrowser(['get', 'url'], config, exec, { headed: false })
        const titleData = await runAgentBrowser(['get', 'title'], config, exec, { headed: false })
        const url = String(urlData?.url ?? urlData?.value ?? '')
        const title = String(titleData?.title ?? titleData?.value ?? '')
        return `浏览器已打开\nURL: ${url}\n标题: ${title}`
      } catch (err) {
        return `浏览器当前未打开或无法连接：${err.message}`
      }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_login',
    description: '打开一个可见的浏览器弹窗让用户手动登录。Agent 看不到密码；用户登录完成后，可以用 browser_wait_login 等待登录完成。',
    parameters: {
      url: { type: 'string', required: true, description: '登录页 URL' },
    },
    output: stringOutput,
    async execute(args, exec) {
      const headed = config.headless ? [] : ['--headed']
      await runAgentBrowser(['open', args.url], config, exec)
      return `已在弹窗中打开 ${args.url}\n请用户手动完成登录（输入密码 / OAuth / 扫码）。完成后告诉我，或调用 browser_wait_login 等待。`
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_wait_login',
    description: '等待用户手动登录完成。可以等待某个 Cookie 出现，或等待 URL 变成某个模式。',
    parameters: {
      cookieName: { type: 'string', description: '登录成功后应出现的 Cookie 名称' },
      urlPattern: { type: 'string', description: '登录成功后 URL 应匹配的模式，例如 **/dashboard' },
      timeout: { type: 'number', description: '超时毫秒，默认 120000' },
    },
    output: stringOutput,
    async execute(args, exec) {
      const timeout = args.timeout ?? 120000
      const started = Date.now()

      while (Date.now() - started < timeout) {
        try {
          if (args.urlPattern) {
            const data = await runAgentBrowser(['get', 'url'], config, exec)
            const url = String(data?.url ?? data?.value ?? '')
            if (matchUrlPattern(url, args.urlPattern)) {
              return `登录成功，当前 URL: ${url}`
            }
          }

          if (args.cookieName) {
            const data = await runAgentBrowser(['cookies'], config, exec)
            const cookies = Array.isArray(data) ? data : (data?.cookies ?? [])
            if (cookies.some((c) => c && c.name === args.cookieName)) {
              return `登录成功，检测到 Cookie: ${args.cookieName}`
            }
          }

          if (!args.urlPattern && !args.cookieName) {
            await new Promise((resolve) => setTimeout(resolve, 2000))
            return '已等待 2 秒。如果用户已登录完成，请继续下一步。'
          }
        } catch (err) {
          if (Date.now() - started >= timeout) throw err
        }

        await new Promise((resolve) => setTimeout(resolve, 1000))
      }

      throw new Error(`等待登录超时（${timeout}ms）`)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'browser_close',
    description: '关闭浏览器（profile 会保留，下次打开仍然是同一份登录态）。',
    parameters: {},
    output: stringOutput,
    async execute(_args, exec) {
      await runAgentBrowser(['close'], config, exec, { json: false, headed: false })
      return '浏览器已关闭，登录态已保存在 profile 中'
    },
  }))
}
