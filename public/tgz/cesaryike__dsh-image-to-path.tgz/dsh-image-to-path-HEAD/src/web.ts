/**
 * dsh-image-to-path backend: an HTTP upload endpoint that receives image
 * bytes from the browser composer, validates them, and saves them into the
 * requesting session's workspace directory under `dsh-image-to-path-uploads/`.
 *
 * Security posture (modeled on the dsh-vision-toolkit web surface):
 * - POST only; cross-site requests rejected via sec-fetch-site/origin checks.
 * - The session is identified by an explicit `sessionId` query parameter
 *   (DSH uses no cookies; custom /_dsh/* routes carry no implicit identity).
 * - Body size capped; image type verified by magic bytes (no client filenames
 *   are ever used on disk).
 * - Content-addressed dedup: output names are SHA-256 digests of the bytes,
 *   so re-dragging the same image returns the existing file instead of
 *   copying it again.
 * - In-place reuse: when the dropped file's name matches a regular file at
 *   the workspace root with identical content, the original path is
 *   returned and no copy is written.
 * - Atomic write: write to a unique staging file, then rename into place.
 *
 * @module dsh-image-to-path/web
 */

import type { Context } from '@deepseek-ai/cordis'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { mkdir, rename, stat, writeFile } from 'node:fs/promises'
import { createHash, randomUUID } from 'node:crypto'
import { join } from 'node:path'
import { SessionId } from '@deepseek-ai/dsh-session'
// Pull in the module augmentation that adds ctx.webServer / ctx.sessions.
import type {} from '@deepseek-ai/dsh-host-webserver'
import type {} from '@deepseek-ai/dsh-session'
import type {} from '@deepseek-ai/dsh-agent-default-model'

/**
 * Self-documenting notice written into the upload directory on first use,
 * so users can tell the directory is plugin-managed and safe to clean.
 */
const UPLOAD_DIR_README = [
  '# dsh-image-to-path 图片目录',
  '',
  '本目录由 dsh-image-to-path 插件自动管理:拖入/粘贴的图片以内容寻址(SHA-256)命名保存,同一张图只保留一份。',
  '',
  '- 可安全清理:删除本目录(或其中文件)不影响插件;再次拖入相同图片会按需重建;',
  '- 工作区根目录中已存在的同名同内容图片会被原位引用,不会拷贝到这里。',
  ''
].join('\n')

/** Exact route used by the browser client. */
export const UPLOAD_ROUTE = '/_dsh/image-to-path/upload'

/** Capability probe: whether the session's current model accepts image parts. */
export const CAPABILITY_ROUTE = '/_dsh/image-to-path/capability'

/** Magic-byte sniffers for the accepted image formats. */
const MAGIC: Array<[string, (b: Uint8Array) => boolean]> = [
  ['png', (b) => b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47],
  ['jpg', (b) => b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff],
  ['gif', (b) => b.length >= 6 && b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38],
  ['webp', (b) => b.length >= 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50],
]

/** Detect the image extension from leading bytes, or undefined. */
function sniff(bytes: Uint8Array): string | undefined {
  for (const [ext, check] of MAGIC) {
    if (check(bytes)) return ext
  }
  return undefined
}

/**
 * Accept only a plain basename (defense in depth: browsers never put path
 * separators in File.name, but a hostile client could). Returns undefined
 * for anything that would escape the workspace root.
 */
function sanitizeName(raw: string | null): string | undefined {
  if (raw === null || raw === undefined) return undefined
  if (raw.length === 0 || raw.length > 255) return undefined
  if (raw === '.' || raw === '..') return undefined
  if (raw.includes('/') || raw.includes('\\')) return undefined
  return raw
}

/** Reject cross-site posts; mirrors dsh-vision-toolkit's sameOriginPost. */
function sameOriginPost(req: IncomingMessage): boolean {
  const fetchSite = req.headers['sec-fetch-site']
  if (fetchSite === 'cross-site') return false
  const origin = req.headers.origin
  if (origin === undefined) {
    return fetchSite === 'same-origin' || fetchSite === 'same-site' || fetchSite === 'none'
  }
  const host = req.headers.host
  if (host === undefined) return false
  try {
    const parsed = new URL(origin)
    return (parsed.protocol === 'http:' || parsed.protocol === 'https:') && parsed.host === host
  } catch {
    return false
  }
}

function responseJson(res: ServerResponse, status: number, body: unknown): void {
  const bytes = Buffer.from(JSON.stringify(body))
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.setHeader('Content-Length', String(bytes.length))
  res.setHeader('Cache-Control', 'no-store')
  res.setHeader('X-Content-Type-Options', 'nosniff')
  res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'")
  res.writeHead(status)
  res.end(bytes)
}

function requestError(res: ServerResponse, status: number, code: string, message: string): void {
  responseJson(res, status, { ok: false, error: { code, message } })
}

/** Collect the raw request body with a byte cap. */
export async function collectBody(req: IncomingMessage, maxBytes: number): Promise<Buffer> {
  const chunks: Buffer[] = []
  let bytes = 0
  for await (const chunk of req) {
    const part = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    bytes += part.length
    if (bytes > maxBytes) throw new RangeError(`request body exceeds ${maxBytes} bytes`)
    chunks.push(part)
  }
  if (chunks.length === 0) throw new TypeError('request body is empty')
  return Buffer.concat(chunks)
}

/**
 * Whether an existing workspace file holds exactly these bytes. Size is
 * compared first so large mismatched files bail out without a read.
 */
async function sameContent(candidate: string, bytes: Buffer): Promise<boolean> {
  let size: number
  try {
    const info = await stat(candidate)
    if (!info.isFile()) return false
    size = info.size
  } catch {
    return false
  }
  if (size !== bytes.length) return false
  const { readFile } = await import('node:fs/promises')
  const existing = await readFile(candidate)
  return existing.equals(bytes)
}

/** Runtime options; reconfigured live via reconfigure(). */
export interface WorkspacePasteOptions {
  /** Subdirectory inside the session workspace that receives uploads. */
  subdir: string
  /** Maximum accepted image size in bytes. */
  maxImageBytes: number
  /** Intercept models with no declared input modalities (default false). */
  interceptUnknownModels: boolean
}

/** Upload endpoint backend. */
export class UploadBackend {
  constructor(
    private ctx: Context,
    private options: WorkspacePasteOptions,
  ) {}

  reconfigure(options: WorkspacePasteOptions): void {
    this.options = options
  }

  /** Bound handler for ctx.webServer.register. */
  handle = (req: IncomingMessage, res: ServerResponse): void => {
    void this.handleInner(req, res)
  }

  /** Capability handler: always 200 + imageSupport (fail-open). */
  handleCapability = (req: IncomingMessage, res: ServerResponse): void => {
    void (async () => {
      // Hoisted above the try so the catch can log too (block-scoped const
      // inside the try would be a ReferenceError in the catch).
      const warn = (message: string) => this.ctx.logger?.warn(`[dsh-image-to-path] ${message}`)
      try {
        if (req.method !== 'GET') {
          res.setHeader('Allow', 'GET')
          return requestError(res, 405, 'method-not-allowed', 'Use GET')
        }
        if (!sameOriginPost(req)) {
          return requestError(res, 403, 'cross-site-forbidden', 'Cross-site requests are not allowed')
        }
        const url = new URL(req.url ?? '/', 'http://dsh.local')
        const sessionId = url.searchParams.get('sessionId')
        // The browser passes its live model selection (the durable header can
        // lag an in-process switch); fall back to header → deployment default
        // when the params are absent.
        const providerParam = url.searchParams.get('provider')
        const modelParam = url.searchParams.get('model')
        let imageSupport: boolean
        // Fail-open is deliberate (an unknown capability must never divert a
        // multimodal user away from the native channel), but a lookup that
        // throws — most often a provider name that no longer matches a
        // registered adapter, e.g. after a deployment rename — would silently
        // disable interception for everyone. Log it so the misconfig is
        // diagnosable instead of looking like "the plugin stopped working".
        if (providerParam && modelParam) {
          imageSupport = await imageSupportForModel(providerParam, modelParam, this.ctx.llm as never, this.options.interceptUnknownModels, warn)
        } else {
          const session = sessionId ? this.ctx.sessions?.get(SessionId(sessionId)) : undefined
          imageSupport = await imageSupportFor(session as never, this.ctx.llm as never, () => this.ctx.agentDefaultModel?.currentSelection?.(), this.options.interceptUnknownModels, warn)
        }
        responseJson(res, 200, { ok: true, value: { imageSupport } })
      } catch (err) {
        warn(`capability probe failed: ${(err as Error).message}`)
        responseJson(res, 200, { ok: true, value: { imageSupport: true } })
      }
    })()
  }

  async handleInner(req: IncomingMessage, res: ServerResponse): Promise<void> {
    try {
      if (req.method !== 'POST') {
        res.setHeader('Allow', 'POST')
        return requestError(res, 405, 'method-not-allowed', 'Use POST')
      }
      if (!sameOriginPost(req)) {
        return requestError(res, 403, 'cross-site-forbidden', 'Cross-site requests are not allowed')
      }
      const url = new URL(req.url ?? '/', 'http://dsh.local')
      const sessionId = url.searchParams.get('sessionId')
      if (!sessionId) {
        return requestError(res, 400, 'missing-session', 'sessionId query parameter is required')
      }
      const session = this.ctx.sessions?.get(SessionId(sessionId))
      const cwd = session?.header.cwd
      if (!cwd) {
        return requestError(res, 404, 'session-not-found', 'Session workspace is unavailable')
      }
      const bytes = await collectBody(req, this.options.maxImageBytes)
      if (bytes.length === 0) {
        return requestError(res, 400, 'empty-body', 'Request body is empty')
      }
      const ext = sniff(bytes)
      if (ext === undefined) {
        return requestError(res, 415, 'unsupported-image', 'Body is not a supported image (png/jpeg/gif/webp)')
      }
      const digest = createHash('sha256').update(bytes).digest('hex')

      // In-place reuse: the dropped file may already live at the workspace
      // root under its own name — reference it instead of copying. The
      // content hash must match, so a same-named but different file can
      // never be mistaken for the original.
      const fileName = sanitizeName(url.searchParams.get('name'))
      if (fileName !== undefined) {
        const candidate = join(cwd, fileName)
        if (await sameContent(candidate, bytes)) {
          return responseJson(res, 200, {
            ok: true,
            value: {
              path: candidate,
              relative: fileName,
              bytes: bytes.length,
              deduplicated: true,
              inPlace: true,
            },
          })
        }
      }

      // Content-addressed dedup: the same bytes always map to the same name,
      // so re-dragging an already-pasted image returns the existing file.
      const dir = join(cwd, this.options.subdir)
      const name = `${digest}.${ext}`
      const target = join(dir, name)
      try {
        await stat(target)
        return responseJson(res, 200, {
          ok: true,
          value: {
            path: target,
            relative: join(this.options.subdir, name),
            bytes: bytes.length,
            deduplicated: true,
          },
        })
      } catch {
        // not present yet — fall through to the write
      }

      await mkdir(dir, { recursive: true })
      try {
        await writeFile(join(dir, 'README.md'), UPLOAD_DIR_README, { flag: 'wx', mode: 0o644 })
      } catch {
        // notice already present
      }
      const staging = `${target}.${randomUUID()}.staging`
      await writeFile(staging, bytes, { flag: 'wx', mode: 0o600 })
      await rename(staging, target)
      responseJson(res, 200, {
        ok: true,
        value: {
          path: target,
          relative: join(this.options.subdir, name),
          bytes: bytes.length,
          deduplicated: false,
        },
      })
    } catch (err) {
      if (err instanceof RangeError) return requestError(res, 413, 'payload-too-large', err.message)
      if (err instanceof TypeError) return requestError(res, 400, 'bad-request', err.message)
      this.ctx.logger?.error('dsh-image-to-path upload failed: %s', (err as Error).message)
      return requestError(res, 500, 'internal', 'Upload failed')
    }
  }
}

/**
 * Whether a session's current model can accept image parts. Mirrors the
 * api-proxy's admission check: resolve the session's request-header model
 * and ask the llm registry for its input modalities. FAIL-OPEN: any
 * unknown (no session, no model, no registry entry, missing modalities)
 * reports image support, so the browser only ever diverts to the
 * path-based flow when text-only is certain — multimodal users keep the
 * native attachment channel untouched.
 */
/**
 * Image support for one explicit provider/model pair (the browser's live
 * model-selection state, which the durable request header can lag).
 */
export async function imageSupportForModel(provider: string | undefined, model: string | undefined, llm: { resolveModelInfo?: (provider: string, model: string) => Promise<{ inputModalities?: readonly string[] } | undefined> } | undefined, interceptUnknown = false, warn?: (message: string) => void): Promise<boolean> {
  try {
    if (!provider || !model) return true
    const info = await llm?.resolveModelInfo?.(provider, model)
    if (info === undefined || info.inputModalities === undefined) return !interceptUnknown
    return info.inputModalities.includes('image')
  } catch (err) {
    warn?.(`model capability lookup failed for ${String(provider)}/${String(model)}: ${(err as Error).message}`)
    return true
  }
}

export function imageSupportFor(session: { requestHeader?: () => { config?: { provider?: string; model?: string } } | undefined } | undefined, llm: { resolveModelInfo?: (provider: string, model: string) => Promise<{ inputModalities?: readonly string[] } | undefined> } | undefined, defaultSelection?: () => { provider?: string; model?: string } | undefined, interceptUnknown = false, warn?: (message: string) => void): Promise<boolean> {
  const config = session?.requestHeader?.()?.config
  let provider = config?.provider
  let model = config?.model
  // New/blank sessions have no request header yet — mirror the api-proxy
  // precedence: fall back to the live deployment default model selection.
  if (!provider || !model) {
    const fallback = defaultSelection?.()
    provider = fallback?.provider
    model = fallback?.model
  }
  return imageSupportForModel(provider, model, llm, interceptUnknown, warn)
}

/**
 * Mount the upload route when a web server is present. Safe in profiles
 * without a web server (the route simply never mounts).
 */
export function installWorkspacePasteWeb(ctx: Context, backend: UploadBackend): () => void {
  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(() => {
      const disposeUpload = webCtx.webServer.register({
        kind: 'exact',
        path: UPLOAD_ROUTE,
        handler: (req, res) => backend.handle(req, res),
      })
      const disposeCapability = webCtx.webServer.register({
        kind: 'exact',
        path: CAPABILITY_ROUTE,
        handler: (req, res) => backend.handleCapability(req, res),
      })
      return () => {
        disposeUpload()
        disposeCapability()
      }
    }, 'dsh-image-to-path: upload route')
  })
  return () => {}
}