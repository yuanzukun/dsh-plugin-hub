/**
 * dsh-image-to-path browser plugin.
 *
 * Intercepts paste and drop of image files at the document capture level
 * (before the conversation composer's attachment channel runs), uploads the
 * bytes to the host endpoint, and inserts the saved workspace path into the
 * current session's draft as text — so a text-only model receives a path it
 * can hand to vision tools instead of an attachment it must reject.
 *
 * The saved files land in the draft as native reference chips: the
 * composer displays the ORIGINAL FILENAME as a distinct chip, and on submit
 * the input pipeline serializes each chip to the absolute workspace path
 * (through the image-to-path reference source registered with
 * inputTriggers), so the model receives usable paths while the user's input
 * stays readable. A short capability hint is shown as a composer status
 * notice (shell.notify, auto-dismissing) based on the environment's visual
 * ability: when a vision-capable client plugin (e.g. dsh-vision-toolkit) is
 * present in the boot manifest the notice points at vision tools; otherwise
 * it explicitly reminds that the image content cannot be viewed.
 *
 * Programmatic draft writes go through the conversation service's session
 * input shell (InputHub.shell(id) -> SessionInputShell.pasteBegin/setDraft),
 * the same machine path the composer keyboard uses. The render-layer
 * "inputActions" props are NOT reachable from plugin code, so the
 * provide-channel props are never read here.
 *
 * This file is shipped verbatim as lib/client.js (no compile step).
 */
window.__ModuleLoader__.load({ id: "dsh-image-to-path", factory: (require) => {
  "use strict";

  // The client module loader invokes the factory with ONLY require() — no
  // module/exports globals — so the CJS surface must be declared here
  // (mirrors the dsh-vision-toolkit client bundle).
  var module = { exports: {} }; var exports = module.exports;

  const UPLOAD_ROUTE = "/_dsh/image-to-path/upload";
  const CAPABILITY_ROUTE = "/_dsh/image-to-path/capability";

  // Per-session cache of "does the current model accept image parts".
  // Only a KNOWN text-only session is diverted to the path flow; unknown or
  // image-capable sessions keep the native attachment channel untouched, so
  // multimodal-model users never lose the original webui experience.
  const imageSupport = new Map();
  const capabilityInflight = new Set();
  const CAPABILITY_POLL_MS = 2000;
  // A probe that never settles (host-side model lookup hang) would otherwise
  // pin the per-session inflight guard forever, blocking every later refresh.
  const CAPABILITY_TIMEOUT_MS = 5000;

  // DshChipCell with a widened U+FFFC advance (4em -> 10em): the composer's
  // chip pill is sized by the placeholder glyph, and the mirror/textarea
  // share the same family, so widening the glyph widens every chip while
  // keeping caret alignment exact. Declared AFTER the composer's font-face
  // (this bundle materializes after ui-conversation), so it wins the
  // cascade. Full file names are also surfaced via the status notice and
  // the chip's title tooltip.
  const CHIP_FONT = "AAEAAAAKAIAAAwAgT1MvMkT8SmIAAAEoAAAAYGNtYXAADQBPAAABkAAAADRnbHlmAAAAAAAAAcwAAAABaGVhZCwtPGoAAACsAAAANmhoZWEDIg7bAAAA5AAAACRobXR4EZQAAAAAAYgAAAAIbG9jYQAAAAAAAAHEAAAABm1heHAAAwACAAABCAAAACBuYW1lvljk2gAAAdAAAABscG9zdNNweNQAAAI8AAAALQABAAAAAQAAdia1tV8PPPUAAwPoAAAAAOaLfcUAAAAA5ot9xQAAAAAAAAAAAAAAAwACAAAAAAAAAAEAAAMg/zgAACcQAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAACAAEAAAACAAAAAAAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAwjKAZAABQAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAAPz8/PwAA//z//AMg/zgAAAMgAMgAAAAAAAAAAAAAAAAAAAAgAAAB9AAAJxAAAAAAAAIAAAADAAAAFAADAAEAAAAUAAQAIAAAAAQABAABAAD//P//AAD//P//AAUAAQAAAAAAAAAAAAAAAAAAAAAAAAAEADYAAQAAAAAAAQALAAAAAQAAAAAAAgAHAAsAAwABBAkAAQAWABIAAwABBAkAAgAOAChEc2hDaGlwQ2VsbFJlZ3VsYXIARABzAGgAQwBoAGkAcABDAGUAbABsAFIAZQBnAHUAbABhAHIAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAABAgZvYmpyZXAAAAA=";

  exports.inject = ["sessions", "conversation", "inputTriggers", "modelDirectories"];

  // Inject the wider chip font + label ellipsis once (the module system
  // claims this style tag and cleans it up with the plugin).
  if (typeof document !== "undefined" && document.querySelector('style[data-plugin-css="dsh-image-to-path/chip-font"]') === null) {
    const tag = document.createElement("style");
    tag.dataset.pluginCss = "dsh-image-to-path/chip-font";
    tag.textContent = "@font-face{font-family:DshChipCell;src:url(data:font/ttf;base64," + CHIP_FONT + ")format(\"truetype\")}"
      + "[data-decoration=\"chip\"]>span{display:block!important;text-overflow:ellipsis!important}";
    document.head.appendChild(tag);
  }

  const REFERENCE_SOURCE = "image-to-path";
  const REFERENCE_SOURCE_LEGACY = "workspace-paste"; // pre-rename drafts keep serializing

  function apply(ctx) {
    // Register the reference source backing our chips: on submit the input
    // pipeline serializes each chip's ref through this codec, so the model
    // receives the absolute path while the composer shows the filename.
    // candidates() returns [] — the slash menu group renders ready-and-empty
    // and auto-closes, so typing "/" is unaffected.
    ctx.effect(() => ctx.get("inputTriggers").registerSource({
      trigger: "/",
      name: REFERENCE_SOURCE,
      order: 100,
      candidates: async () => [],
      onPick: () => undefined,
      codec: {
        clipboardText: (ref) => ref,
        serialize: (ref) => Promise.resolve(ref)
      }
    }), "dsh-image-to-path: reference source");
    ctx.effect(() => ctx.get("inputTriggers").registerSource({
      trigger: "/",
      name: REFERENCE_SOURCE_LEGACY,
      order: 100,
      candidates: async () => [],
      onPick: () => undefined,
      codec: {
        clipboardText: (ref) => ref,
        serialize: (ref) => Promise.resolve(ref)
      }
    }), "dsh-image-to-path: legacy reference source");

    // Warm and track the per-session capability cache: fetch on apply and
    // whenever the current session changes, and opportunistically after each
    // intercepted-or-natural image event.
    let lastWarmed = undefined;
    const selectionListeners = new Map();
    const currentSessionId = () => ctx.sessions?.list?.getSnapshot?.().current;
    // The browser's live model selection (updated instantly on switch by the
    // model seat) — the durable request header can lag an in-process switch.
    const liveSelection = (sessionId) => {
      try {
        const directory = ctx.modelDirectories?.directoryFor?.(sessionId);
        const current = directory?.store?.getSnapshot?.().current;
        if (current && typeof current.provider === "string" && typeof current.model === "string") {
          return { provider: current.provider, model: current.model };
        }
      } catch { /* directory not materialized yet */ }
      return undefined;
    };
    const refreshCapability = (sessionId) => {
      if (!sessionId || capabilityInflight.has(sessionId)) return;
      capabilityInflight.add(sessionId);
      const live = liveSelection(sessionId);
      let url = `${CAPABILITY_ROUTE}?sessionId=${encodeURIComponent(sessionId)}`;
      if (live) url += `&provider=${encodeURIComponent(live.provider)}&model=${encodeURIComponent(live.model)}`;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), CAPABILITY_TIMEOUT_MS);
      fetch(url, { credentials: "same-origin", signal: controller.signal })
        .then((r) => r.json().catch(() => ({})))
        .then((b) => {
          if (b?.ok && typeof b.value?.imageSupport === "boolean") imageSupport.set(sessionId, b.value.imageSupport);
        })
        .catch(() => {})
        .finally(() => {
          clearTimeout(timer);
          capabilityInflight.delete(sessionId);
        });
    };
    // React to model switches immediately: subscribe to the model seat's
    // per-session store (re-attach lazily while the directory materializes).
    // Only the CURRENT session's subscription stays attached — a stale one
    // would refetch capability on every model switch of a session the user
    // already left, and each attach leaks one store subscription.
    const attachSelectionListener = (sessionId) => {
      for (const [sid, off] of selectionListeners) {
        if (sid !== sessionId) {
          try { off(); } catch { /* best-effort */ }
          selectionListeners.delete(sid);
        }
      }
      try {
        const directory = ctx.modelDirectories?.directoryFor?.(sessionId);
        if (!directory?.store?.subscribe) return false;
        if (selectionListeners.has(sessionId)) return true;
        const off = directory.store.subscribe(() => refreshCapability(sessionId));
        selectionListeners.set(sessionId, off);
        return true;
      } catch { return false; }
    };
    // Near-real-time model switching: poll the capability while the tab is
    // visible (a local lightweight GET), so switching to a multimodal model
    // releases the native channel within ~2s and switching back re-engages
    // interception just as fast.
    ctx.effect(() => {
      const poll = () => {
        if (typeof document !== "undefined" && document.visibilityState === "hidden") return;
        const id = currentSessionId();
        if (id) {
          attachSelectionListener(id);
          refreshCapability(id);
        }
      };
      const timer = setInterval(poll, CAPABILITY_POLL_MS);
      const onVisible = () => poll();
      document.addEventListener("visibilitychange", onVisible);
      return () => {
        clearInterval(timer);
        document.removeEventListener("visibilitychange", onVisible);
      };
    }, "dsh-image-to-path: capability poll");
    ctx.effect(() => {
      const id = currentSessionId();
      if (id !== undefined) { lastWarmed = id; refreshCapability(id); attachSelectionListener(id); }
      const unsub = ctx.sessions?.list?.subscribe?.(() => {
        const next = currentSessionId();
        if (next !== undefined && next !== lastWarmed) {
          lastWarmed = next;
          refreshCapability(next);
          attachSelectionListener(next);
        }
      });
      return () => {
        if (unsub) unsub();
        for (const off of selectionListeners.values()) { try { off(); } catch { /* best-effort */ } }
        selectionListeners.clear();
      };
    }, "dsh-image-to-path: capability cache");

    // Capture-phase native listeners run before React's synthetic onPaste and
    // before the conversation composer's document-level bubble drop handler.
    // stopPropagation is required so the composer never sees the event twice.
    ctx.effect(() => {
      const onPaste = (e) => {
        const types = e.clipboardData?.types;
        if (!types || !Array.prototype.includes.call(types, "Files")) return;
        const files = Array.from(e.clipboardData.files ?? [])
          .filter((f) => f.type.startsWith("image/"));
        if (files.length === 0) return;
        const id = currentSessionId();
        if (imageSupport.get(id) !== false) return; // native channel for unknown/image-capable
        e.preventDefault();
        e.stopPropagation();
        void handleFiles(ctx, files);
        if (id) refreshCapability(id);
      };
      const onDrop = (e) => {
        const files = Array.from(e.dataTransfer?.files ?? [])
          .filter((f) => f.type.startsWith("image/"));
        if (files.length === 0) return;
        const id = currentSessionId();
        if (imageSupport.get(id) !== false) return; // native channel for unknown/image-capable
        e.preventDefault();
        e.stopPropagation();
        dismissDropOverlay();
        void handleFiles(ctx, files);
        if (id) refreshCapability(id);
      };
      document.addEventListener("paste", onPaste, true);
      document.addEventListener("drop", onDrop, true);
      return () => {
        document.removeEventListener("paste", onPaste, true);
        document.removeEventListener("drop", onDrop, true);
      };
    }, "dsh-image-to-path: capture paste/drop");
  }

  /**
   * The composer shows its "drag image here" overlay on dragenter and hides
   * it in its own document-level dragleave/drop handlers. Both of those are
   * gated on hasFiles(event) (dataTransfer must carry "Files"), so a bare
   * synthetic dragleave is ignored. The window-level dragend listener calls
   * reset() with no gating, so a synthetic dragend dismisses the overlay
   * deterministically after our capture-phase drop consumed the real event.
   */
  function dismissDropOverlay() {
    try {
      window.dispatchEvent(new DragEvent("dragend"));
    } catch { /* overlay dismissal is best-effort */ }
  }

  async function handleFiles(ctx, files) {
    const current = ctx.sessions?.list?.getSnapshot?.().current;
    if (!current) return;
    const saved = [];
    for (const file of files) {
      try {
        saved.push({ path: await uploadOne(current, file), name: file.name ?? "" });
      } catch (err) {
        console.error("[dsh-image-to-path] upload failed:", err);
      }
    }
    if (saved.length > 0) insertPaths(ctx, current, saved);
  }

  async function uploadOne(sessionId, file) {
    // name lets the backend reuse a same-named, same-content file already
    // present at the workspace root instead of copying it again.
    const url = `${UPLOAD_ROUTE}?sessionId=${encodeURIComponent(sessionId)}&name=${encodeURIComponent(file.name ?? "")}`;
    const res = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      body: file,
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok || !body.ok) throw new Error(body.error?.message ?? `HTTP ${res.status}`);
    return body.value.path;
  }

  /**
   * Detect whether this DSH environment has a vision-capable client plugin
   * (e.g. dsh-vision-toolkit). The boot manifest lists every client bundle
   * id; a /vision/i match is the capability signal. Model modality is not
   * exposed client-side in dsh 0.1.x, so the plugin manifest is the
   * authoritative check.
   */
  function hasVisionCapability() {
    const boot = window.__DSH_BOOT__;
    const entries = Array.isArray(boot?.entries) ? boot.entries : [];
    return entries.some((entry) => typeof entry?.id === "string" && /vision/i.test(entry.id));
  }

  exports.apply = apply;

  /** How long the composer status notice stays visible before auto-dismiss. */
  const NOTICE_MS = 5000;

  /**
   * Insert the saved files into the session draft as reference chips: the
   * composer shows the original filename as a distinct chip, and on submit
   * the input pipeline serializes each chip to the absolute path (via the
   * registered image-to-path source codec), so the model receives usable
   * paths while the user's input stays readable. The capability hint goes
   * to a composer status notice that auto-dismisses after NOTICE_MS.
   */
  function insertPaths(ctx, sessionId, saved) {
    const shell = ctx.conversation?.input?.shell?.(sessionId);
    if (!shell?.pasteBegin) {
      console.warn("[dsh-image-to-path] input shell unavailable; paths not inserted:", saved);
      return;
    }
    const draft = shell.snapshot?.draft ?? "";
    let pos = draft.length;
    let first = true;
    for (const item of saved) {
      const prefix = first ? (pos > 0 ? "\n" : "") : " ";
      first = false;
      const raw = prefix + "\uFFFC";
      const label = item.name.length > 0 ? item.name : (item.path.split("/").pop() ?? item.path);
      shell.pasteBegin(raw, { start: pos, end: pos }, [{
        start: prefix.length,
        end: prefix.length + 1,
        reference: {
          source: REFERENCE_SOURCE,
          ref: item.path,
          label,
          clipboardText: item.path
        }
      }]);
      pos += raw.length;
    }
    if (shell.notify && shell.notices) {
      // Short summary only — full names live on the chips' title tooltip.
      const hint = "已保存 " + saved.length + " 张图片；"
        + (hasVisionCapability()
          ? "当前环境带视觉工具，可用 vision 工具查看"
          : "当前环境没有视觉工具，无法直接查看图片内容");
      shell.notify("info", hint);
      const mySeq = shell.notices.getSnapshot()?.seq;
      if (mySeq !== undefined) {
        setTimeout(() => {
          try {
            // only dismiss our own notice (seq guard) — never a newer one
            if (shell.notices?.getSnapshot()?.seq === mySeq) shell.notices.set(null);
          } catch { /* best-effort dismissal */ }
        }, NOTICE_MS);
      }
    }
  }

  return module.exports;
}});