# Contributors / 贡献者

- [cesaryike](https://github.com/cesaryike) — 作者:产品定义、功能方向、文档与发布 / author: product definition, direction, docs, and release
- DeepSeek AI(DSH agent)— 核心工程实现与修复 / core engineering and fixes(commit history)

> 提交历史中的作者署名即为此分工;DeepSeek AI 未绑定 GitHub 账号,故不出现在账号头像列表中。
