# dsh-image-to-path

**Let DSH text-only-model conversations accept images: saved to the session workspace and handed to the model as a file path.**

[English](README.en.md) | [中文](README.md)

![DSH](https://img.shields.io/badge/DSH-0.1.x-4c1d95) ![Version](https://img.shields.io/badge/version-0.1.0-blue) ![License](https://img.shields.io/badge/license-MIT-green)

## The problem it solves

DSH WebUI sends dropped images to the model as base64 attachments, which text-only models reject outright — **no matter which vision tools you have installed, images simply cannot be sent while the conversation uses a text-only model**. This plugin takes over drag & drop / paste at the browser capture phase, saves the image into the current session's workspace, and inserts a **file path** into the composer, so the model can hand that path to any tool — including vision tools.

- **Multimodal models are untouched**: the plugin probes the current model's capability — image-capable models keep the native attachment channel; only confirmed text-only models get the path-based flow;
- **Works without vision tools**: only path text is sent; a notice honestly states whether the environment can view images;
- **No duplicate copies**: content-addressed dedup keeps exactly one file per unique image; files already in the workspace are referenced in place.

## Install

```sh
# local dev (run pnpm install first to install peer deps)
dsh plugin --profile web add /path/to/dsh-image-to-path

# from GitHub (lib/ is committed — no build authorization needed)
dsh plugin --profile web add github:cesaryike/dsh-image-to-path

# or tarball
pnpm pack && dsh plugin --profile web add ./dsh-image-to-path-0.1.0.tgz
```

Restart your Web Profile after installing.

## Usage

Drag or paste an image into the composer: it is saved under `dsh-image-to-path-uploads/` in the workspace, appears as a **filename chip**, and the model receives the full path on send. The directory is safe to clean at any time.

## Config

| Field | Default | Description |
|---|---|---|
| `subdir` | `dsh-image-to-path-uploads` | save directory in the session workspace |
| `maxImageBytes` | `10485760` | per-image limit (10 MiB) |
| `interceptUnknownModels` | `false` | treat models without declared input modalities as text-only (all shipped adapters declare them; usually leave unchanged). Even when enabled, an unregistered provider or a failed capability lookup still reports image-capable (fail-open), with a warning logged by the host |

Override by row id `image-to-path` in the profile's `cordis.patch.yml`.

## How it works

```
drag/paste → does the model support images? → yes: native attachment channel (unchanged)
                                          → no (text-only): upload → magic-byte check → SHA-256 dedup → atomic write to workspace
                                          → filename chip in the composer → serialized to a full path on send → model / vision tools
```

## Security

Magic-byte validation only, server-generated names, atomic writes, 10 MiB cap, same-origin checks; no remote requests.

## License

[MIT](LICENSE)

## Credits

- [cesaryike](https://github.com/cesaryike): author — product definition, direction, docs, and release;
- DeepSeek AI (DSH agent): core engineering and fixes (see commit history).
