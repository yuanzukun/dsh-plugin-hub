/**
 * dsh-image-to-path plugin entry: a host-side bundle that mounts the image
 * upload endpoint when a web server is present. The browser counterpart
 * (lib/client.js) intercepts composer paste/drop and calls the endpoint.
 *
 * @module dsh-image-to-path
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-image-to-path";
/**
 * Host services this plugin reads. Cordis guards every undeclared service
 * access ("cannot get property ... without inject"), so the sessions
 * registry must be declared here — the upload endpoint resolves the
 * requesting session's workspace via ctx.sessions.
 */
export declare const inject: string[];
/** User-facing configuration; every field has a default. */
export interface WorkspacePasteConfig {
    /** Subdirectory inside the session workspace that receives uploads. */
    subdir?: string;
    /** Maximum accepted image size in bytes. */
    maxImageBytes?: number;
    /**
     * How to treat models whose registry entry declares no input modalities
     * (third-party adapters only — the shipped deepseek/pi-ai adapters always
     * declare). Default false mirrors DSH's own admission semantics (the
     * adapter decides); set true to intercept those as text-only.
     */
    interceptUnknownModels?: boolean;
}
export declare function apply(ctx: Context, config?: WorkspacePasteConfig): () => void;
