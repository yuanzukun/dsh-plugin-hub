/**
 * dsh-image-to-path backend: an HTTP upload endpoint that receives image
 * bytes from the browser composer, validates them, and saves them into the
 * requesting session's workspace directory under `dsh-image-to-path-uploads/`.
 *
 * Security posture (modeled on the dsh-vision-toolkit web surface):
 * - POST only; cross-site requests rejected via sec-fetch-site/origin checks.
 * - The session is identified by an explicit `sessionId` query parameter
 *   (DSH uses no cookies; custom /_dsh/* routes carry no implicit identity).
 * - Body size capped; image type verified by magic bytes (no client filenames
 *   are ever used on disk).
 * - Content-addressed dedup: output names are SHA-256 digests of the bytes,
 *   so re-dragging the same image returns the existing file instead of
 *   copying it again.
 * - In-place reuse: when the dropped file's name matches a regular file at
 *   the workspace root with identical content, the original path is
 *   returned and no copy is written.
 * - Atomic write: write to a unique staging file, then rename into place.
 *
 * @module dsh-image-to-path/web
 */
import type { Context } from '@deepseek-ai/cordis';
import type { IncomingMessage, ServerResponse } from 'node:http';
/** Exact route used by the browser client. */
export declare const UPLOAD_ROUTE = "/_dsh/image-to-path/upload";
/** Capability probe: whether the session's current model accepts image parts. */
export declare const CAPABILITY_ROUTE = "/_dsh/image-to-path/capability";
/** Collect the raw request body with a byte cap. */
export declare function collectBody(req: IncomingMessage, maxBytes: number): Promise<Buffer>;
/** Runtime options; reconfigured live via reconfigure(). */
export interface WorkspacePasteOptions {
    /** Subdirectory inside the session workspace that receives uploads. */
    subdir: string;
    /** Maximum accepted image size in bytes. */
    maxImageBytes: number;
    /** Intercept models with no declared input modalities (default false). */
    interceptUnknownModels: boolean;
}
/** Upload endpoint backend. */
export declare class UploadBackend {
    private ctx;
    private options;
    constructor(ctx: Context, options: WorkspacePasteOptions);
    reconfigure(options: WorkspacePasteOptions): void;
    /** Bound handler for ctx.webServer.register. */
    handle: (req: IncomingMessage, res: ServerResponse) => void;
    /** Capability handler: always 200 + imageSupport (fail-open). */
    handleCapability: (req: IncomingMessage, res: ServerResponse) => void;
    handleInner(req: IncomingMessage, res: ServerResponse): Promise<void>;
}
/**
 * Whether a session's current model can accept image parts. Mirrors the
 * api-proxy's admission check: resolve the session's request-header model
 * and ask the llm registry for its input modalities. FAIL-OPEN: any
 * unknown (no session, no model, no registry entry, missing modalities)
 * reports image support, so the browser only ever diverts to the
 * path-based flow when text-only is certain — multimodal users keep the
 * native attachment channel untouched.
 */
/**
 * Image support for one explicit provider/model pair (the browser's live
 * model-selection state, which the durable request header can lag).
 */
export declare function imageSupportForModel(provider: string | undefined, model: string | undefined, llm: {
    resolveModelInfo?: (provider: string, model: string) => Promise<{
        inputModalities?: readonly string[];
    } | undefined>;
} | undefined, interceptUnknown?: boolean, warn?: (message: string) => void): Promise<boolean>;
export declare function imageSupportFor(session: {
    requestHeader?: () => {
        config?: {
            provider?: string;
            model?: string;
        };
    } | undefined;
} | undefined, llm: {
    resolveModelInfo?: (provider: string, model: string) => Promise<{
        inputModalities?: readonly string[];
    } | undefined>;
} | undefined, defaultSelection?: () => {
    provider?: string;
    model?: string;
} | undefined, interceptUnknown?: boolean, warn?: (message: string) => void): Promise<boolean>;
/**
 * Mount the upload route when a web server is present. Safe in profiles
 * without a web server (the route simply never mounts).
 */
export declare function installWorkspacePasteWeb(ctx: Context, backend: UploadBackend): () => void;
