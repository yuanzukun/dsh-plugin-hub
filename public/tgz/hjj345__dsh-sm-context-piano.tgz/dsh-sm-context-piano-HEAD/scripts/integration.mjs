/** jsdom behavior checks for the Codex-style navigator. */

import { createRequire } from 'node:module'
import assert from 'node:assert/strict'
import { JSDOM } from 'jsdom'

const requireHere = createRequire(import.meta.url)
const waitFrame = () => new Promise(resolve => setTimeout(resolve, 35))
let passed = 0
let failed = 0
const check = async (name, fn) => {
  try {
    await fn()
    passed += 1
    console.log(`  ok  ${name}`)
  } catch (error) {
    failed += 1
    console.error(`FAIL  ${name}`)
    console.error(error)
  }
}

const dom = new JSDOM('<!doctype html><html><body></body></html>', {
  url: 'http://127.0.0.1:3080/',
  pretendToBeVisual: true,
})
const { window } = dom
const { document } = window

globalThis.window = window
globalThis.document = document
globalThis.MutationObserver = window.MutationObserver
globalThis.requestAnimationFrame = window.requestAnimationFrame.bind(window)
globalThis.cancelAnimationFrame = window.cancelAnimationFrame.bind(window)
globalThis.IS_REACT_ACT_ENVIRONMENT = true
globalThis.ResizeObserver = class {
  observe() {}
  disconnect() {}
}
window.matchMedia = () => ({ matches: false })
window.HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', '') }
window.HTMLDialogElement.prototype.close = function () { this.removeAttribute('open') }

const root = document.createElement('div')
Object.defineProperties(root, {
  clientHeight: { value: 900, configurable: true },
  clientWidth: { value: 1280, configurable: true },
  getBoundingClientRect: {
    value: () => ({ left: 0, top: 0, right: 1280, bottom: 900, width: 1280, height: 900 }),
    configurable: true,
  },
})

const scrollport = document.createElement('div')
scrollport.setAttribute('data-conversation-scroll', '')
Object.defineProperties(scrollport, {
  clientHeight: { value: 800, configurable: true },
  clientWidth: { value: 1280, configurable: true },
  scrollTop: { value: 0, writable: true, configurable: true },
  getBoundingClientRect: {
    value: () => ({ left: 0, top: 0, right: 1280, bottom: 800, width: 1280, height: 800 }),
    configurable: true,
  },
})
scrollport.scrollTo = options => { scrollport.scrollTop = typeof options === 'number' ? options : (options?.top ?? 0) }

const flow = document.createElement('div')
flow.setAttribute('data-chat-flow', '')
Object.defineProperty(flow, 'getBoundingClientRect', {
  value: () => ({ left: 300, top: -scrollport.scrollTop, right: 1048, bottom: 1600 - scrollport.scrollTop, width: 748, height: 1600 }),
  configurable: true,
})

const keys = ['user:1', 'assistant:2', 'tool:3', 'assistant:3b', 'command:4', 'partial:5', 'tail:6']
const contentTops = [40, 260, 700, 900, 1100, 1200, 1280]
const appendRow = index => {
  const row = document.createElement('div')
  row.dataset.chatAnchorKey = keys[index]
  Object.defineProperty(row, 'getBoundingClientRect', {
    value: () => ({ left: 300, top: contentTops[index] - scrollport.scrollTop, right: 1048, bottom: contentTops[index] + 160 - scrollport.scrollTop, width: 748, height: 160 }),
    configurable: true,
  })
  flow.appendChild(row)
}
keys.forEach((_, index) => appendRow(index))
root.appendChild(scrollport)
scrollport.appendChild(flow)
document.body.appendChild(root)

const officialSlot = document.createElement('div')
const officialTurnNavigator = document.createElement('nav')
officialTurnNavigator.setAttribute('aria-label', '轮次导航')
const officialTurn = document.createElement('button')
officialTurn.setAttribute('aria-label', '跳转到第 1 轮')
officialTurnNavigator.appendChild(officialTurn)
officialSlot.appendChild(officialTurnNavigator)
document.body.appendChild(officialSlot)

const settingsDialog = document.createElement('div')
settingsDialog.setAttribute('role', 'dialog')
settingsDialog.setAttribute('aria-hidden', 'true')
const settingsSectionOutlet = document.createElement('div')
settingsSectionOutlet.dataset.slot = 'settings.section'
settingsDialog.appendChild(settingsSectionOutlet)
Object.defineProperty(settingsDialog, 'getBoundingClientRect', {
  value: () => ({ left: 0, top: 0, right: 1280, bottom: 900, width: 1280, height: 900 }),
  configurable: true,
})
document.body.appendChild(settingsDialog)

const offscreenDialog = document.createElement('div')
offscreenDialog.setAttribute('role', 'dialog')
offscreenDialog.setAttribute('aria-hidden', 'false')
Object.defineProperty(offscreenDialog, 'getBoundingClientRect', {
  value: () => ({ left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 }),
  configurable: true,
})
document.body.appendChild(offscreenDialog)

const nodeMap = new Map([
  ['user:1', {
    key: 'user:1', kind: 'user', anchorSeq: 1,
    data: { content: [{ type: 'text', text: '修复右侧卡片截断问题\n已按照容器实际宽度重新计算列数。' }] },
  }],
  ['assistant:2', {
    key: 'assistant:2', kind: 'assistant-step', anchorSeq: 2,
    data: { turn: 1, step: 0, blocks: [{ kind: 'text', text: '第二个对话节点\n这里是助手回复的正文预览。' }] },
  }],
  ['tool:3', {
    key: 'tool:3', kind: 'tool-call', anchorSeq: 3,
    data: { root: { name: 'read_file', argsRaw: '{"path":"a.txt"}', content: [{ type: 'text', text: '工具结果' }] } },
  }],
  ['assistant:3b', {
    key: 'assistant:3b', kind: 'assistant-step', anchorSeq: 3.5,
    data: { turn: 1, step: 1, blocks: [{ kind: 'text', text: '工具执行后的助手结论' }] },
  }],
  ['command:4', {
    key: 'command:4', kind: 'command', anchorSeq: 4,
    data: { name: 'compact', args: null },
  }],
  ['partial:5', {
    key: 'partial:5', kind: 'partial', anchorSeq: 5,
    data: { turn: 1, step: 1, blocks: [{ kind: 'text', text: '流式中间状态' }] },
  }],
  ['tail:6', {
    key: 'tail:6', kind: 'turn-tail', anchorSeq: 6,
    data: { turn: 1, closing: null },
  }],
])
const snapshot = { chat: { order: [...keys], nodes: { get: key => nodeMap.get(key) } } }
let snapshotSubscriber = () => {}
const session = {
  getSnapshot: () => snapshot,
  subscribe: fn => { snapshotSubscriber = fn; return () => { snapshotSubscriber = () => {} } },
}
const chatSource = {
  getSnapshot: () => snapshot.chat,
  subscribe: fn => { snapshotSubscriber = fn; return () => { snapshotSubscriber = () => {} } },
}
const defaults = { language: 'zh', enabled: true, keyHeight: 2, keyGap: 12, maxVisible: 20 }
let settingsEntry = {
  ns: 'sm-context-piano', revision: 1,
  value: { ...defaults },
}
let settingsWriteCount = 0
let onSettingsDocumentUpdated = () => {}
const settingsRemote = {
  settings: {
    describe: async () => ({ ok: true, value: { writable: true, namespaces: [settingsEntry] } }),
    mutate: async (ns, ops, expectedRevision) => {
      assert.equal(ns, 'sm-context-piano')
      assert.equal(expectedRevision, settingsEntry.revision)
      settingsWriteCount += 1
      for (const op of ops) {
        settingsEntry = {
          ...settingsEntry,
          value: {
            ...settingsEntry.value,
            [op.path[0]]: op.op === 'set' ? op.value : defaults[op.path[0]],
          },
        }
      }
      settingsEntry = { ...settingsEntry, revision: settingsEntry.revision + 1 }
      onSettingsDocumentUpdated(ns, settingsEntry.revision)
      return { ok: true, value: settingsEntry }
    },
  },
  $on: (event, listener) => {
    assert.equal(event, 'settings/document-updated')
    onSettingsDocumentUpdated = listener
    return () => { onSettingsDocumentUpdated = () => {} }
  },
}
let settingsController
let settingsSection
let sessionProbe
let probeRoot
const ctx = {
  effect: fn => { const disposer = fn(); globalThis.__disposers.push(disposer); return disposer },
  locale: { register: () => {}, bind: () => key => key },
  sessions: {},
  uiConversation: {
    binding: id => ['s1', 's2'].includes(id) ? { target: name => { assert.equal(name, 'chat'); return chatSource } } : undefined,
  },
  remote: settingsRemote,
  slots: {
    inject: (name, callback) => {
      assert.ok(['settings.section', 'conversation.session.header.actions'].includes(name))
      callback()
    },
    register: (options, component) => {
      const registration = { options, component }
      if (options.id === 'sm-context-piano') settingsSection = registration
      if (options.id === 'sm-context-piano-session-probe') sessionProbe = registration
      return () => {
        if (settingsSection === registration) settingsSection = undefined
        if (sessionProbe === registration) sessionProbe = undefined
      }
    },
  },
}
globalThis.__disposers = []

window.__ModuleLoader__ = { load: handoff => { globalThis.__handoff = handoff } }
await import('../lib/client.js')
const exports = globalThis.__handoff.factory(spec => {
  if (spec === 'react') return requireHere('react')
  if (spec === 'react/jsx-runtime') return requireHere('react/jsx-runtime')
  throw new Error(`unexpected require: ${spec}`)
})

await check('mounts only user messages and visible assistant output runs', async () => {
  exports.apply(ctx)
  settingsController = settingsSection.options.inject().scope
  const React = requireHere('react')
  const { act } = React
  const { createRoot } = requireHere('react-dom/client')
  const probeMount = document.createElement('div')
  document.body.appendChild(probeMount)
  probeRoot = createRoot(probeMount)
  await act(async () => {
    probeRoot.render(React.createElement(sessionProbe.component, {
      ...sessionProbe.options.inject(),
      sessionId: 's1',
    }))
    await waitFrame()
  })
  await waitFrame()
  const strip = document.querySelector('.smcp-strip')
  assert.ok(strip)
  assert.equal(document.querySelectorAll('.smcp-bar').length, 3)
  assert.equal([...document.querySelectorAll('.smcp-bar')].filter(bar => !bar.hidden).length, 3)
  assert.equal(document.querySelector('[data-key="tool:3"]'), null)
  assert.equal(document.querySelector('[data-key="command:4"]'), null)
  assert.equal(document.querySelector('[data-key="partial:5"]'), null)
  assert.equal(strip.getAttribute('role'), 'navigation')
  assert.equal(Number.parseFloat(strip.style.height), 230)
  assert.equal(Number.parseFloat(strip.style.left), 218)
  assert.equal(globalThis.__smcpDebug.hiddenReason, null)
  assert.equal(officialSlot.style.display, 'none')
})

await check('follows the Session selected by the session-scoped DSH slot', async () => {
  const React = requireHere('react')
  const { act } = React
  await act(async () => {
    probeRoot.render(React.createElement(sessionProbe.component, {
      ...sessionProbe.options.inject(),
      sessionId: 's2',
    }))
    await waitFrame()
  })
  await waitFrame()
  assert.equal(globalThis.__smcpDebug.sessionId, 's2')
  assert.equal(document.querySelectorAll('.smcp-bar').length, 3)
  assert.equal(officialSlot.style.display, 'none')

  await act(async () => {
    probeRoot.render(React.createElement(sessionProbe.component, {
      ...sessionProbe.options.inject(),
      sessionId: 's1',
    }))
    await waitFrame()
  })
  await waitFrame()
  assert.equal(globalThis.__smcpDebug.sessionId, 's1')
})

await check('suspends the owned rail only while a DSH dialog is visible', async () => {
  const overlay = document.querySelector('.smcp-overlay')
  assert.equal(overlay.hidden, false)

  settingsDialog.setAttribute('aria-hidden', 'false')
  await waitFrame()
  assert.equal(overlay.hidden, true)
  assert.equal(officialSlot.style.display, 'none')

  settingsDialog.setAttribute('aria-hidden', 'true')
  await waitFrame()
  assert.equal(overlay.hidden, false)
  assert.equal(officialSlot.style.display, 'none')
})

await check('registers the first-level settings page directly after Agent Presets', async () => {
  assert.equal(settingsSection.options.id, 'sm-context-piano')
  assert.equal(settingsSection.options.order, 21)
  assert.equal(settingsSection.options.label(), 'settings.nav')
  assert.equal(settingsSection.options.inject().scope, settingsController)

  const React = requireHere('react')
  const { act } = React
  const { createRoot } = requireHere('react-dom/client')
  const mount = document.createElement('div')
  document.body.appendChild(mount)
  const rootView = createRoot(mount)
  let copiedCommand = ''
  Object.defineProperty(window.navigator, 'clipboard', {
    configurable: true,
    value: { writeText: async text => { copiedCommand = text } },
  })
  await act(async () => {
    rootView.render(React.createElement(settingsSection.component, {
      ...settingsSection.options.inject(),
      close: () => {},
      t: key => key,
    }))
    await waitFrame()
  })
  assert.match(mount.textContent, /sm-context-piano/)
  assert.match(mount.textContent, /v1\.2\.8/)
  assert.match(mount.textContent, /2026-09-30/)
  assert.match(mount.textContent, /Jack·Huang/)
  assert.match(mount.textContent, /dsh plugin --profile web add @hjj345345\/dsh-sm-context-piano/)
  assert.match(mount.textContent, /230px/)
  assert.match(mount.textContent, /通用设置/)
  assert.match(mount.textContent, /显示设置/)
  assert.match(mount.textContent, /关于插件/)
  assert.match(mount.textContent, /v1\.2\.8/)
  assert.match(mount.querySelector('.smcp-settings-icon').getAttribute('src'), /^data:image\/png;base64,/)
  const languageSelect = mount.querySelector('.smcp-settings-select')
  assert.equal(languageSelect.value, 'zh')
  assert.deepEqual([...languageSelect.options].map(option => option.textContent), ['简体中文', 'English', '繁體中文'])
  const commandBox = mount.querySelector('.smcp-settings-command-box')
  const installCard = commandBox.closest('.smcp-settings-install')
  assert.equal(mount.querySelectorAll('.smcp-settings-card').length, 4)
  assert.ok(installCard)
  assert.equal(installCard.querySelector('h2').textContent, '安装命令')
  assert.equal(commandBox.closest('.smcp-settings-about'), null)
  const aboutRows = [...mount.querySelectorAll('.smcp-settings-about dl > div')]
    .map(row => [row.querySelector('dt').textContent, row.querySelector('dd').textContent])
  assert.deepEqual(aboutRows.at(-2), ['GitHub', 'https://github.com/hjj345/dsh-sm-context-piano'])
  assert.deepEqual(aboutRows.at(-1), ['npm', '@hjj345345/dsh-sm-context-piano'])
  const githubLink = mount.querySelector('.smcp-settings-about a[href^="https://github.com/"]')
  assert.equal(githubLink.href, 'https://github.com/hjj345/dsh-sm-context-piano')
  assert.equal(githubLink.target, '_blank')
  assert.equal(githubLink.rel, 'noreferrer')
  const npmLink = mount.querySelector('.smcp-settings-about a[href^="https://www.npmjs.com/package/"]')
  assert.equal(npmLink.textContent, '@hjj345345/dsh-sm-context-piano')
  assert.equal(npmLink.href, 'https://www.npmjs.com/package/@hjj345345/dsh-sm-context-piano')
  assert.equal(npmLink.target, '_blank')
  assert.equal(npmLink.rel, 'noreferrer')
  await act(async () => {
    languageSelect.value = 'en'
    languageSelect.dispatchEvent(new window.Event('change', { bubbles: true }))
    await Promise.resolve()
  })
  assert.equal(settingsEntry.value.language, 'en')
  assert.match(mount.textContent, /General settings/)
  assert.match(mount.textContent, /Display/)
  assert.match(mount.textContent, /About/)
  assert.match(mount.textContent, /Install command/)
  assert.equal(settingsSection.options.label(), 'settings.nav')
  assert.equal(document.querySelector('.smcp-strip').getAttribute('aria-label'), 'nav.aria')
  await act(async () => {
    languageSelect.value = 'zh-TW'
    languageSelect.dispatchEvent(new window.Event('change', { bubbles: true }))
    await Promise.resolve()
  })
  assert.equal(settingsEntry.value.language, 'zh-TW')
  assert.match(mount.textContent, /通用設定/)
  assert.match(mount.textContent, /顯示設定/)
  assert.match(mount.textContent, /關於外掛/)
  assert.match(mount.textContent, /安裝命令/)
  assert.equal(settingsSection.options.label(), 'settings.nav')
  assert.equal(document.querySelector('.smcp-strip').getAttribute('aria-label'), 'nav.aria')
  const sliders = [...mount.querySelectorAll('.smcp-settings-range input')]
  assert.equal(sliders.length, 3)
  assert.equal(sliders[2].max, '40')
  const writesBeforeDraft = settingsWriteCount
  const setSliderValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set
  for (const [slider, value] of sliders.map((slider, index) => [slider, ['4', '8', '10'][index]])) {
    await act(async () => {
      setSliderValue.call(slider, value)
      slider.dispatchEvent(new window.Event('input', { bubbles: true }))
      await Promise.resolve()
    })
  }
  assert.equal(settingsWriteCount, writesBeforeDraft)
  assert.deepEqual([...mount.querySelectorAll('.smcp-settings-range output')].map(output => output.textContent), ['4px', '8px', '10'])
  assert.equal(mount.querySelector('.smcp-settings-save').disabled, false)
  await act(async () => {
    mount.querySelector('.smcp-settings-save').click()
    await waitFrame()
  })
  assert.equal(settingsWriteCount, writesBeforeDraft + 1)
  assert.deepEqual(
    [settingsEntry.value.keyHeight, settingsEntry.value.keyGap, settingsEntry.value.maxVisible],
    [4, 8, 10],
  )
  assert.equal(mount.querySelector('.smcp-settings-save').disabled, true)

  const writesBeforeReset = settingsWriteCount
  const resetDialog = mount.querySelector('.smcp-settings-dialog')
  await act(async () => {
    mount.querySelector('.smcp-settings-reset').click()
    await waitFrame()
  })
  assert.equal(resetDialog.open, true)
  assert.match(resetDialog.querySelector('h2').textContent, /确认恢复默认设置|確認恢復預設設定/)
  assert.match(resetDialog.querySelector('p').textContent, /启用状态|啟用狀態/)
  assert.equal(resetDialog.getAttribute('aria-modal'), 'true')
  await act(async () => {
    resetDialog.querySelector('.smcp-settings-dialog-cancel').click()
    await waitFrame()
  })
  assert.equal(resetDialog.open, false)
  assert.equal(settingsWriteCount, writesBeforeReset)
  assert.equal(settingsEntry.value.keyHeight, 4)
  await act(async () => {
    mount.querySelector('.smcp-settings-reset').click()
    await waitFrame()
  })
  assert.equal(resetDialog.open, true)
  await act(async () => {
    resetDialog.querySelector('.smcp-settings-dialog-actions .smcp-settings-reset').click()
    await waitFrame()
  })
  assert.equal(resetDialog.open, false)
  assert.deepEqual(settingsEntry.value, defaults)
  assert.equal(settingsWriteCount, writesBeforeReset + 1)
  assert.match(mount.textContent, /显示设置/)
  await act(async () => {
    commandBox.querySelector('button').click()
    await Promise.resolve()
  })
  assert.equal(copiedCommand, 'dsh plugin --profile web add @hjj345345/dsh-sm-context-piano')
  assert.equal(mount.querySelector('.smcp-settings-command-box button').textContent, '已复制')
  const styles = document.querySelector('#smcp-panel-styles').textContent
  assert.match(styles, /grid-template-columns: minmax\(0, 1fr\) auto/)
  assert.match(styles, /white-space: pre-wrap/)
  assert.match(styles, /background: #f3f3f4/)
  assert.match(styles, /\.smcp-settings-select[\s\S]*border-radius: 9px/)
  assert.match(styles, /\.smcp-settings-save,[\s\S]*\.smcp-settings-reset[\s\S]*background: #161719[\s\S]*color: #fff/)
  assert.match(styles, /\.smcp-settings-dialog::backdrop\s*\{\s*background: rgba\(0, 0, 0, \.42\)/)
  assert.match(styles, /\.smcp-settings-dialog-cancel[\s\S]*border-radius: 9px/)
  assert.match(styles, /\.smcp-settings-command-box button[\s\S]*background: #161719[\s\S]*color: #fff/)
  assert.match(styles, /body\[data-ds-dark-theme\] \.smcp-settings-command-box[\s\S]*background: rgba\(255, 255, 255, \.08\)/)
  assert.match(styles, /body\[data-ds-dark-theme\] \.smcp-settings-command-box code[\s\S]*color: #f1f1f3/)
  assert.match(styles, /\.smcp-overlay[\s\S]*z-index: 10/)
  assert.match(styles, /\.smcp-overlay\[hidden\][\s\S]*display: none !important/)
  assert.doesNotMatch(styles, /body:has\(\[role="dialog"\]\) \.smcp-overlay/)
  assert.match(styles, /@media \(max-width: 520px\)/)
  assert.match(styles, /@media \(max-width: 360px\)/)
  await act(async () => { rootView.unmount() })
  mount.remove()
})

await check('live settings resize, limit, disable, and restore the rail', async () => {
  await settingsController.set('keyHeight', 4)
  await settingsController.set('keyGap', 8)
  await settingsController.set('maxVisible', 5)
  await waitFrame()
  let strip = document.querySelector('.smcp-strip')
  assert.equal(Number.parseFloat(strip.style.height), 36)
  assert.ok([...document.querySelectorAll('.smcp-bar')].every(bar => Number.parseFloat(bar.style.height) === 4))

  await settingsController.set('maxVisible', 40)
  await waitFrame()
  assert.equal(Number.parseFloat(strip.style.height), 316)
  assert.equal(settingsController.getSnapshot().value.maxVisible, 40)

  await settingsController.set('maxVisible', 5)
  await waitFrame()

  await settingsController.set('enabled', false)
  await waitFrame()
  assert.equal(document.querySelector('.smcp-strip'), null)
  assert.equal(officialSlot.style.display, '')
  await settingsController.set('enabled', true)
  await settingsController.set('keyHeight', 2)
  await settingsController.set('keyGap', 12)
  await settingsController.set('maxVisible', 20)
  await waitFrame()
  await waitFrame()
  strip = document.querySelector('.smcp-strip')
  assert.ok(strip)
  assert.equal(Number.parseFloat(strip.style.height), 230)
  assert.equal(officialSlot.style.display, 'none')
})

await check('keeps a compact fixed-pitch stack centered in the rail', () => {
  const strip = document.querySelector('.smcp-strip')
  const bars = [...document.querySelectorAll('.smcp-bar')].filter(bar => !bar.hidden)
  assert.ok(bars.every(bar => Number.parseFloat(bar.style.height) === 2))
  const centers = bars.map(bar => Number.parseFloat(bar.style.top) + Number.parseFloat(bar.style.height) / 2)
  assert.equal(centers[1] - centers[0], 12)
  assert.equal(centers[2] - centers[1], 12)
  assert.equal((centers[0] + centers[2]) / 2, Number.parseFloat(strip.style.height) / 2)
})

await check('the full rail continuously drives the hover wave and preview', async () => {
  const strip = document.querySelector('.smcp-strip')
  const railHeight = Number.parseFloat(strip.style.height)
  Object.defineProperty(strip, 'getBoundingClientRect', {
    value: () => ({ left: 192, top: 250, right: 250, bottom: 250 + railHeight, width: 58, height: railHeight }),
    configurable: true,
  })
  const bars = [...document.querySelectorAll('.smcp-bar')]
  const secondY = Number.parseFloat(bars[1].style.top) + Number.parseFloat(bars[1].style.height) / 2
  strip.dispatchEvent(new window.MouseEvent('pointermove', { clientY: 250 + secondY, bubbles: true }))
  await waitFrame()
  assert.ok(bars[1].classList.contains('smcp-bar-hover'))
  assert.ok(Number.parseFloat(bars[1].style.width) > Number.parseFloat(bars[0].style.width))
  const tooltip = document.querySelector('.smcp-tooltip')
  assert.ok(tooltip.classList.contains('smcp-tooltip-visible'))
  const title = tooltip.querySelector('.smcp-tooltip-title')
  assert.equal(title.tagName, 'DIV')
  assert.equal(window.getComputedStyle(title).fontWeight, '400')
  assert.match(tooltip.textContent, /第二个对话节点/)
  assert.doesNotMatch(tooltip.textContent, /token|工具|read_file|assistant/i)
  tooltip.style.left = '0px'
  const transitionEnd = new window.Event('transitionend')
  Object.defineProperty(transitionEnd, 'propertyName', { value: 'left' })
  strip.dispatchEvent(transitionEnd)
  assert.notEqual(tooltip.style.left, '0px')
})

await check('hover uses actual bar geometry and ignores distant empty rail space', async () => {
  const strip = document.querySelector('.smcp-strip')
  const railHeight = Number.parseFloat(strip.style.height)
  const bars = [...document.querySelectorAll('.smcp-bar')]
  const secondY = Number.parseFloat(bars[1].style.top) + Number.parseFloat(bars[1].style.height) / 2
  Object.defineProperty(bars[1], 'getBoundingClientRect', {
    value: () => ({ left: 192, top: 250 + secondY + 18, right: 250, bottom: 252 + secondY + 18, width: 58, height: 2 }),
    configurable: true,
  })
  strip.dispatchEvent(new window.MouseEvent('pointermove', { clientY: 250 + secondY + 18, bubbles: true }))
  await waitFrame()
  assert.ok(bars[1].classList.contains('smcp-bar-hover'))

  strip.dispatchEvent(new window.MouseEvent('pointermove', { clientY: 250 + railHeight - 1, bubbles: true }))
  await waitFrame()
  assert.equal(document.querySelector('.smcp-tooltip').classList.contains('smcp-tooltip-visible'), false)
  assert.ok(bars.every(bar => !bar.classList.contains('smcp-bar-hover')))
  delete bars[1].getBoundingClientRect
})

await check('clicking the rail jumps to the currently previewed node', () => {
  const strip = document.querySelector('.smcp-strip')
  const bar = document.querySelectorAll('.smcp-bar')[1]
  const localY = Number.parseFloat(bar.style.top) + Number.parseFloat(bar.style.height) / 2
  strip.dispatchEvent(new window.MouseEvent('pointermove', { clientY: 250 + localY, bubbles: true }))
  strip.dispatchEvent(new window.MouseEvent('click', { clientY: 250 + localY, bubbles: true }))
  assert.equal(scrollport.scrollTop, contentTops[1] - 16)
})

await check('scroll updates active color and length immediately', async () => {
  const strip = document.querySelector('.smcp-strip')
  strip.dispatchEvent(new window.MouseEvent('pointerleave'))
  scrollport.scrollTop = 320
  scrollport.dispatchEvent(new window.Event('scroll'))
  await waitFrame()
  const bars = [...document.querySelectorAll('.smcp-bar')]
  assert.ok(bars[1].classList.contains('smcp-bar-current'))
  assert.equal(Number.parseFloat(bars[1].style.width), 24)
  assert.equal(Number.parseFloat(bars[0].style.width), 10)
})

await check('snapshot updates retain existing marker elements', async () => {
  const first = document.querySelector('[data-key="user:1"]')
  keys.push('assistant:7')
  contentTops.push(1420)
  nodeMap.set('assistant:7', {
    key: 'assistant:7', kind: 'assistant-step', anchorSeq: 7,
    data: { turn: 2, step: 0, blocks: [{ kind: 'text', text: '新增回复' }] },
  })
  snapshot.chat.order.push('assistant:7')
  appendRow(7)
  snapshotSubscriber()
  await waitFrame()
  assert.equal(document.querySelectorAll('.smcp-bar').length, 4)
  assert.equal(document.querySelector('[data-key="user:1"]'), first)
})

await check('an open preview follows streaming descriptor updates', async () => {
  const strip = document.querySelector('.smcp-strip')
  const last = document.querySelector('[data-key="assistant:7::output:0"]')
  const y = Number.parseFloat(last.style.top) + Number.parseFloat(last.style.height) / 2
  strip.dispatchEvent(new window.MouseEvent('pointermove', { clientY: 250 + y, bubbles: true }))
  await waitFrame()
  nodeMap.set('assistant:7', {
    key: 'assistant:7', kind: 'assistant-step', anchorSeq: 7,
    data: { turn: 2, step: 0, blocks: [{ kind: 'text', text: '流式更新后的回复\n预览必须同步刷新。' }] },
  })
  snapshotSubscriber()
  await waitFrame()
  assert.match(document.querySelector('.smcp-tooltip').textContent, /流式更新后的回复/)
})

await check('keyboard navigation previews and activates a marker', async () => {
  const strip = document.querySelector('.smcp-strip')
  strip.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'End', bubbles: true }))
  strip.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Enter', bubbles: true }))
  await waitFrame()
  assert.equal(scrollport.scrollTop, contentTops[7] - 16)
})

await check('shows at most 20 keys and recenters after selecting the top boundary', async () => {
  flow.textContent = ''
  keys.splice(0)
  contentTops.splice(0)
  nodeMap.clear()
  snapshot.chat.order.splice(0)
  for (let index = 0; index < 25; index += 1) {
    const key = `user:window:${index}`
    keys.push(key)
    contentTops.push(index * 100)
    nodeMap.set(key, {
      key, kind: 'user', anchorSeq: 100 + index,
      data: { content: [{ type: 'text', text: `用户节点 ${index}` }] },
    })
    snapshot.chat.order.push(key)
    appendRow(index)
  }
  scrollport.scrollTop = 1200
  snapshotSubscriber()
  await waitFrame()
  await waitFrame()
  assert.equal(globalThis.__smcpDebug.total, 25)
  assert.equal(globalThis.__smcpDebug.bars, 20)
  assert.equal(globalThis.__smcpDebug.windowStart, 3)
  assert.equal(document.querySelector('[data-key="user:window:2"]').hidden, true)
  assert.equal(document.querySelector('[data-key="user:window:3"]').hidden, false)

  const strip = document.querySelector('.smcp-strip')
  const top = document.querySelector('[data-key="user:window:3"]')
  const topY = Number.parseFloat(top.style.top) + Number.parseFloat(top.style.height) / 2
  strip.dispatchEvent(new window.MouseEvent('pointermove', { clientY: 250 + topY, bubbles: true }))
  await waitFrame()
  strip.dispatchEvent(new window.MouseEvent('click', { clientY: 250 + topY, bubbles: true }))
  await waitFrame()
  assert.equal(globalThis.__smcpDebug.windowStart, 0)
  assert.equal(document.querySelector('[data-key="user:window:0"]').hidden, false)
})

await check('a single rendered node stays centered on the rail', async () => {
  flow.textContent = ''
  keys.splice(0, keys.length, 'user:solo')
  contentTops.splice(0, contentTops.length, 80)
  nodeMap.clear()
  nodeMap.set('user:solo', {
    key: 'user:solo', kind: 'user', anchorSeq: 999,
    data: { content: [{ type: 'text', text: '单节点' }] },
  })
  snapshot.chat.order.splice(0, snapshot.chat.order.length, 'user:solo')
  appendRow(0)
  scrollport.scrollTop = 0
  snapshotSubscriber()
  await waitFrame()
  const strip = document.querySelector('.smcp-strip')
  const bar = document.querySelector('.smcp-bar')
  const center = Number.parseFloat(bar.style.top) + Number.parseFloat(bar.style.height) / 2
  assert.ok(Math.abs(center - Number.parseFloat(strip.style.height) / 2) < 0.2)
})

await check('restores the owned rail after an external DOM removal', async () => {
  document.querySelector('.smcp-overlay').remove()
  await waitFrame()
  await waitFrame()
  assert.equal(document.querySelectorAll('.smcp-overlay').length, 1)
  assert.equal(document.querySelectorAll('.smcp-strip').length, 1)
})

await check('falls back to the conversation scrollport when the legacy flow marker is absent', async () => {
  flow.removeAttribute('data-chat-flow')
  await waitFrame()
  await waitFrame()
  assert.ok(document.querySelector('.smcp-strip'))
})

await check('session disappearance clears markers without stale content', async () => {
  const React = requireHere('react')
  const { act } = React
  await act(async () => {
    probeRoot.unmount()
    await waitFrame()
  })
  await waitFrame()
  assert.equal(document.querySelectorAll('.smcp-bar').length, 0)
  assert.equal(globalThis.__smcpDebug.sessionId, undefined)
  assert.equal(officialSlot.style.display, '')
})

await check('dispose removes every injected runtime surface', () => {
  for (const disposer of globalThis.__disposers) if (typeof disposer === 'function') disposer()
  assert.equal(document.querySelector('.smcp-strip'), null)
  assert.equal(document.querySelector('.smcp-tooltip'), null)
  assert.equal(globalThis.__smcpDebug, undefined)
})

console.log(`\n${passed} integration checks passed, ${failed} failed`)
process.exit(failed === 0 ? 0 : 1)
