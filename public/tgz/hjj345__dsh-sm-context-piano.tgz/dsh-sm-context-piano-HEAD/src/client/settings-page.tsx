import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react'
import type { ChangeEvent, ReactNode } from 'react'
import type { ClientRemote } from '@deepseek-ai/dsh-api-remotes/client'
import type {
  InjectFace,
  PropsRuntime,
} from '@deepseek-ai/dsh-client-ui-slots'
import iconUrl from '../../images/sm-context-piano-settings-icon.png'
import {
  DEFAULT_SETTINGS,
  SETTINGS_ENTRY_ID,
  SETTINGS_LIMITS,
  decodeSettings,
  isPianoLanguage,
  railHeight,
} from '../core/config.ts'
import type {
  PianoLanguage,
  PianoSettings,
  PianoSettingsSource,
} from '../core/config.ts'
import { translate } from './locales.ts'
import type { SmContextPianoKey } from './locales.ts'

const VERSION = 'v1.2.8'
const RELEASE_DATE = '2026-09-30'
const AUTHOR = 'Jack·Huang'
const EMAIL = 'jack698698@gmail.com'
const GITHUB_URL = 'https://github.com/hjj345/dsh-sm-context-piano'
const NPM_PACKAGE = '@hjj345345/dsh-sm-context-piano'
const NPM_URL = 'https://www.npmjs.com/package/@hjj345345/dsh-sm-context-piano'
const INSTALL_COMMAND = `dsh plugin --profile web add ${NPM_PACKAGE}`
const LANGUAGE_OPTIONS: readonly { value: PianoLanguage; label: string }[] = [
  { value: 'zh', label: '简体中文' },
  { value: 'en', label: 'English' },
  { value: 'zh-TW', label: '繁體中文' },
]
type SettingsErrorKey = 'settings.writeError' | 'settings.copyError'

export interface PianoSettingsPageInjected {
  scope: PianoSettingsScope
}

export type PianoSettingsPageProps =
  PropsRuntime<'settings.section'>
  & InjectFace<PianoSettingsPageInjected>

export interface PianoSettingsSnapshot {
  status: 'loading' | 'ready' | 'unavailable'
  writable: boolean
  revision: number
  value: PianoSettings
}

export interface PianoSettingsScope {
  getSnapshot(): PianoSettingsSnapshot
  subscribe(listener: () => void): () => void
  set<K extends keyof PianoSettings>(field: K, value: PianoSettings[K]): Promise<void>
  saveDisplaySettings(value: Pick<PianoSettings, 'keyHeight' | 'keyGap' | 'maxVisible'>): Promise<void>
  unset(field: keyof PianoSettings): Promise<void>
  reset(): Promise<void>
}

export interface PianoSettingsController {
  scope: PianoSettingsScope
  source: PianoSettingsSource
  dispose(): void
}

export function createPianoSettingsSource(remote: ClientRemote): PianoSettingsController {
  type Entry = { ns: string; revision: number; value: unknown }
  let entry: Entry | undefined
  let snapshot: PianoSettingsSnapshot = {
    status: 'loading',
    writable: false,
    revision: 0,
    value: DEFAULT_SETTINGS,
  }
  let disposed = false
  let readGeneration = 0
  let writeQueue = Promise.resolve()
  const listeners = new Set<() => void>()

  const publish = (status: PianoSettingsSnapshot['status'], writable: boolean): void => {
    if (disposed) return
    snapshot = {
      status,
      writable,
      revision: entry?.revision ?? 0,
      value: entry === undefined ? DEFAULT_SETTINGS : decodeSettings(entry.value) ?? DEFAULT_SETTINGS,
    }
    for (const listener of listeners) listener()
  }

  const refresh = async (): Promise<void> => {
    const generation = ++readGeneration
    try {
      const response = await remote.settings.describe()
      if (disposed || generation !== readGeneration) return
      if (!response.ok) throw new Error('settings describe failed')
      const result = response.value
      entry = result.namespaces.find((candidate: Entry) => candidate.ns === SETTINGS_ENTRY_ID)
      publish(entry === undefined ? 'unavailable' : 'ready', entry !== undefined && result.writable)
    } catch {
      if (disposed || generation !== readGeneration) return
      publish('unavailable', false)
    }
  }

  const write = (ops: { op: 'set'; path: string[]; value: PianoSettings[keyof PianoSettings] }[] | { op: 'unset'; path: string[] }[]): Promise<void> => {
    const operation = writeQueue.then(async () => {
      if (disposed) throw new Error('settings controller disposed')
      if (entry === undefined || !snapshot.writable) await refresh()
      if (entry === undefined || !snapshot.writable) throw new Error('settings unavailable')
      const revision = entry.revision
      try {
        const response = await remote.settings.mutate(SETTINGS_ENTRY_ID, ops, revision)
        if (!response.ok) throw new Error('settings mutation failed')
        entry = response.value
        publish('ready', snapshot.writable)
      } catch (error) {
        await refresh()
        throw error
      }
    })
    writeQueue = operation.catch(() => {})
    return operation
  }

  const scope: PianoSettingsScope = {
    getSnapshot: () => snapshot,
    subscribe: listener => {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    },
    set: (field, value) => write([{ op: 'set', path: [field], value }]),
    saveDisplaySettings: value => write([
      { op: 'set', path: ['keyHeight'], value: value.keyHeight },
      { op: 'set', path: ['keyGap'], value: value.keyGap },
      { op: 'set', path: ['maxVisible'], value: value.maxVisible },
    ]),
    unset: field => write([{ op: 'unset', path: [field] }]),
    reset: () => write((['language', 'enabled', 'keyHeight', 'keyGap', 'maxVisible'] as const).map(field => ({ op: 'unset' as const, path: [field] }))),
  }
  const source: PianoSettingsSource = {
    getSnapshot: () => snapshot.value,
    subscribe: scope.subscribe,
  }
  const stopListening = remote.$on('settings/document-updated', (ns: string) => {
    if (ns === SETTINGS_ENTRY_ID) void refresh()
  })
  void refresh()

  return {
    scope,
    source,
    dispose: () => {
      disposed = true
      readGeneration += 1
      stopListening()
      listeners.clear()
    },
  }
}

interface RangeRowProps {
  label: string
  description: string
  value: number
  min: number
  max: number
  suffix: string
  disabled: boolean
  onChange: (value: number) => void
}

function RangeRow(props: RangeRowProps): ReactNode {
  const { label, description, value, min, max, suffix, disabled, onChange } = props
  const change = (event: ChangeEvent<HTMLInputElement>): void => {
    onChange(Number.parseInt(event.target.value, 10))
  }
  return (
    <label className="smcp-settings-row">
      <span className="smcp-settings-copy">
        <span className="smcp-settings-label">{label}</span>
        <span className="smcp-settings-description">{description}</span>
      </span>
      <span className="smcp-settings-range">
        <input type="range" min={min} max={max} step={1} value={value} disabled={disabled} onChange={change} />
        <output>{value}{suffix}</output>
      </span>
    </label>
  )
}

export function PianoSettingsPage(props: PianoSettingsPageProps): ReactNode {
  const { scope } = props
  const subscribe = useCallback((listener: () => void) => scope.subscribe(listener), [scope])
  const getSnapshot = useCallback(() => scope.getSnapshot(), [scope])
  const snapshot = useSyncExternalStore(subscribe, getSnapshot, getSnapshot)
  const settings = decodeSettings(snapshot.value) ?? DEFAULT_SETTINGS
  const t = (key: SmContextPianoKey): string => translate(settings.language, key)
  const [error, setError] = useState<SettingsErrorKey | null>(null)
  const [copied, setCopied] = useState(false)
  const [busy, setBusy] = useState(false)
  const [showResetConfirm, setShowResetConfirm] = useState(false)
  const resetDialog = useRef<HTMLDialogElement>(null)
  const [draft, setDraft] = useState<Pick<PianoSettings, 'keyHeight' | 'keyGap' | 'maxVisible'> & { dirty: true } | null>(null)
  const savedDisplay = { keyHeight: settings.keyHeight, keyGap: settings.keyGap, maxVisible: settings.maxVisible }
  const display = draft ?? savedDisplay
  const disabled = !snapshot.writable || busy

  useEffect(() => {
    const dialog = resetDialog.current
    if (showResetConfirm && dialog !== null && !dialog.open) dialog.showModal()
    else if (!showResetConfirm && dialog?.open) dialog.close()
  }, [showResetConfirm])

  const write = <K extends keyof PianoSettings>(field: K, value: PianoSettings[K]): void => {
    setError(null)
    void scope.set(field, value).catch(() => { setError('settings.writeError') })
  }
  const reset = (): void => {
    setShowResetConfirm(true)
  }
  const confirmReset = (): void => {
    setShowResetConfirm(false)
    setError(null)
    setBusy(true)
    void scope.reset()
      .then(() => { setDraft(null) })
      .catch(() => { setError('settings.writeError') })
      .finally(() => { setBusy(false) })
  }
  const saveDisplay = (): void => {
    if (draft === null || !draft.dirty) return
    setError(null)
    setBusy(true)
    void scope.saveDisplaySettings(draft)
      .then(() => { setDraft(null) })
      .catch(() => { setError('settings.writeError') })
      .finally(() => { setBusy(false) })
  }
  const changeDisplay = (field: 'keyHeight' | 'keyGap' | 'maxVisible', value: number): void => {
    setDraft(current => {
      const next = { ...(current ?? savedDisplay), [field]: value }
      return next.keyHeight === settings.keyHeight && next.keyGap === settings.keyGap && next.maxVisible === settings.maxVisible
        ? null
        : { ...next, dirty: true }
    })
  }
  const copyCommand = (): void => {
    setError(null)
    setCopied(false)
    void (async () => {
      try {
        if (window.navigator.clipboard === undefined) throw new Error('clipboard unavailable')
        await window.navigator.clipboard.writeText(INSTALL_COMMAND)
        setCopied(true)
      } catch {
        setError('settings.copyError')
      }
    })()
  }

  return (
    <div className="smcp-settings-page">
      <section className="smcp-settings-hero">
        <img src={iconUrl} alt="" className="smcp-settings-icon" />
        <span className="smcp-settings-hero-copy">
          <span className="smcp-settings-title">sm-context-piano</span>
          <span className="smcp-settings-subtitle">{t('settings.subtitle')}</span>
        </span>
        <label className="smcp-settings-switch">
          <input
            type="checkbox"
            checked={settings.enabled}
            disabled={disabled}
            onChange={(event) => { write('enabled', event.target.checked) }}
          />
          <span aria-hidden="true" />
          <b>{settings.enabled ? t('settings.enabled') : t('settings.disabled')}</b>
        </label>
      </section>

      {error !== null && <p className="smcp-settings-error smcp-settings-page-error" role="alert">{t(error)}</p>}

      <section className="smcp-settings-card smcp-settings-general">
        <h2>{t('settings.general')}</h2>
        <label className="smcp-settings-row smcp-settings-language">
          <span className="smcp-settings-label">语言/Language</span>
          <select
            className="smcp-settings-select"
            value={settings.language}
            disabled={disabled}
            onChange={(event) => {
              if (isPianoLanguage(event.target.value)) write('language', event.target.value)
            }}
          >
            {LANGUAGE_OPTIONS.map(option => (
              <option key={option.value} value={option.value}>{option.label}</option>
            ))}
          </select>
        </label>
      </section>

      <section className="smcp-settings-card">
        <h2>{t('settings.appearance')}</h2>
        <RangeRow
          label={t('settings.height')}
          description={t('settings.heightDesc')}
          value={display.keyHeight}
          min={SETTINGS_LIMITS.keyHeight.min}
          max={SETTINGS_LIMITS.keyHeight.max}
          suffix="px"
          disabled={disabled}
          onChange={(value) => { changeDisplay('keyHeight', value) }}
        />
        <RangeRow
          label={t('settings.gap')}
          description={t('settings.gapDesc')}
          value={display.keyGap}
          min={SETTINGS_LIMITS.keyGap.min}
          max={SETTINGS_LIMITS.keyGap.max}
          suffix="px"
          disabled={disabled}
          onChange={(value) => { changeDisplay('keyGap', value) }}
        />
        <RangeRow
          label={t('settings.maxVisible')}
          description={t('settings.maxVisibleDesc')}
          value={display.maxVisible}
          min={SETTINGS_LIMITS.maxVisible.min}
          max={SETTINGS_LIMITS.maxVisible.max}
          suffix=""
          disabled={disabled}
          onChange={(value) => { changeDisplay('maxVisible', value) }}
        />
        <div className="smcp-settings-total">
          <span>{t('settings.totalHeight')}</span>
          <strong>{railHeight({ ...settings, ...display })}px</strong>
        </div>
        <div className="smcp-settings-actions">
          <button type="button" className="smcp-settings-save" disabled={disabled || !draft?.dirty} onClick={saveDisplay}>
            {busy ? t('settings.saving') : t('settings.save')}
          </button>
          <button type="button" className="smcp-settings-reset" disabled={disabled} onClick={reset}>
            {t('settings.reset')}
          </button>
        </div>
        {snapshot.status === 'loading' && <p className="smcp-settings-note">{t('settings.loading')}</p>}
        {snapshot.status === 'unavailable' && <p className="smcp-settings-note">{t('settings.unavailable')}</p>}
      </section>

      <dialog
        ref={resetDialog}
        className="smcp-settings-dialog"
        aria-modal="true"
        aria-labelledby="smcp-reset-dialog-title"
        aria-describedby="smcp-reset-dialog-description"
        onCancel={(event) => { event.preventDefault(); setShowResetConfirm(false) }}
      >
        <h2 id="smcp-reset-dialog-title">{t('settings.resetConfirmTitle')}</h2>
        <p id="smcp-reset-dialog-description">{t('settings.resetConfirm')}</p>
        <div className="smcp-settings-dialog-actions">
          <button type="button" className="smcp-settings-dialog-cancel" autoFocus onClick={() => { setShowResetConfirm(false) }}>
            {t('settings.cancel')}
          </button>
          <button type="button" className="smcp-settings-reset" onClick={confirmReset}>
            {t('settings.reset')}
          </button>
        </div>
      </dialog>

      <section className="smcp-settings-card smcp-settings-about">
        <h2>{t('settings.about')}</h2>
        <dl>
          <div><dt>{t('settings.version')}</dt><dd>{VERSION}</dd></div>
          <div><dt>{t('settings.releaseDate')}</dt><dd>{RELEASE_DATE}</dd></div>
          <div><dt>{t('settings.author')}</dt><dd>{AUTHOR}</dd></div>
          <div><dt>{t('settings.email')}</dt><dd><a href={`mailto:${EMAIL}`}>{EMAIL}</a></dd></div>
          <div><dt>GitHub</dt><dd><a href={GITHUB_URL} target="_blank" rel="noreferrer">{GITHUB_URL}</a></dd></div>
          <div><dt>npm</dt><dd><a href={NPM_URL} target="_blank" rel="noreferrer">{NPM_PACKAGE}</a></dd></div>
        </dl>
      </section>

      <section className="smcp-settings-card smcp-settings-install">
        <h2>{t('settings.install')}</h2>
        <div className="smcp-settings-command-box">
          <code>{INSTALL_COMMAND}</code>
          <button type="button" onClick={copyCommand}>
            {copied ? t('settings.copied') : t('settings.copy')}
          </button>
        </div>
      </section>
    </div>
  )
}
