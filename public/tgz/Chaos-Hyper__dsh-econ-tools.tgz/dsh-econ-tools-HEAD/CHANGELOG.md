# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-08-19

### Added

- Initial release of `dsh-econ-tools` — Econometrics Research Assistant for DeepSeek Harness.
- `econ_method_guide` — recommend econometric models based on research question and data type.
- `econ_data_prep` — data cleaning, missing value handling, outlier detection, and variable transformation with Python code templates.
- `econ_model_spec` — model specification and variable selection (theory-driven, data-driven, hybrid, ML-based).
- `econ_run_analysis` — empirical analysis with auto-generated Python / R / Stata code templates.
- `econ_robustness` — robustness checks across seven dimensions (omitted variables, measurement error, sample selection, model specification, outliers, parallel trends, placebo tests).
- `econ_report` — result reporting (descriptive statistics, baseline regression, robustness summary) in Markdown / LaTeX / HTML.
- Bilingual README (English / 简体中文).
